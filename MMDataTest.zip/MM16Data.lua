MM16DataSavedVariables =
{
    ["Default"] = 
    {
        ["@TholosTB"] = 
        {
            ["$AccountWide"] = 
            {
                ["version"] = 1,
            },
        },
        ["MasterMerchant"] = 
        {
            ["$AccountWide"] = 
            {
                ["version"] = 1,
                ["SalesData"] = 
                {
                },
            },
        },
    },
}
