GS11DataSavedVariables =
{
    ["listingseu"] = 
    {
    },
    ["listingsna"] = 
    {
    },
    ["dataeu"] = 
    {
    },
    ["datana"] = 
    {
        [176129] = 
        {
            ["1:0:2:44:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_pants_heavy.dds",
                ["itemDesc"] = "Companion's Greaves",
                ["oldestTime"] = 1633308262,
                ["wasAltered"] = true,
                ["newestTime"] = 1633308262,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1738,
                        ["guild"] = 1,
                        ["buyer"] = 880,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1633308262,
                        ["quant"] = 1,
                        ["id"] = "1692825481",
                        ["itemLink"] = 2958,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine heavy apparel legs prolific",
            },
        },
        [177154] = 
        {
            ["1:0:3:51:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_helm_light.dds",
                ["itemDesc"] = "Companion's Hat",
                ["oldestTime"] = 1633311928,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311928,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 32,
                        ["wasKiosk"] = true,
                        ["seller"] = 33,
                        ["timestamp"] = 1633311928,
                        ["quant"] = 1,
                        ["id"] = "1692868905",
                        ["itemLink"] = 22,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior light apparel head vigorous",
            },
        },
        [139011] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/justice_stolen_pouch_003.dds",
                ["itemDesc"] = "Waterlogged Psijic Satchel",
                ["oldestTime"] = 1632914234,
                ["wasAltered"] = true,
                ["newestTime"] = 1633155170,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5200,
                        ["guild"] = 1,
                        ["buyer"] = 52,
                        ["wasKiosk"] = false,
                        ["seller"] = 151,
                        ["timestamp"] = 1632979751,
                        ["quant"] = 1,
                        ["id"] = "1690129897",
                        ["itemLink"] = 263,
                    },
                    [2] = 
                    {
                        ["price"] = 5200,
                        ["guild"] = 1,
                        ["buyer"] = 52,
                        ["wasKiosk"] = false,
                        ["seller"] = 151,
                        ["timestamp"] = 1632979752,
                        ["quant"] = 1,
                        ["id"] = "1690129911",
                        ["itemLink"] = 263,
                    },
                    [3] = 
                    {
                        ["price"] = 5200,
                        ["guild"] = 1,
                        ["buyer"] = 52,
                        ["wasKiosk"] = false,
                        ["seller"] = 151,
                        ["timestamp"] = 1632979753,
                        ["quant"] = 1,
                        ["id"] = "1690129921",
                        ["itemLink"] = 263,
                    },
                    [4] = 
                    {
                        ["price"] = 5140,
                        ["guild"] = 1,
                        ["buyer"] = 932,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633096819,
                        ["quant"] = 1,
                        ["id"] = "1690935045",
                        ["itemLink"] = 263,
                    },
                    [5] = 
                    {
                        ["price"] = 5140,
                        ["guild"] = 1,
                        ["buyer"] = 932,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633096821,
                        ["quant"] = 1,
                        ["id"] = "1690935067",
                        ["itemLink"] = 263,
                    },
                    [6] = 
                    {
                        ["price"] = 5140,
                        ["guild"] = 1,
                        ["buyer"] = 932,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633096824,
                        ["quant"] = 1,
                        ["id"] = "1690935089",
                        ["itemLink"] = 263,
                    },
                    [7] = 
                    {
                        ["price"] = 5140,
                        ["guild"] = 1,
                        ["buyer"] = 932,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633096891,
                        ["quant"] = 1,
                        ["id"] = "1690935867",
                        ["itemLink"] = 263,
                    },
                    [8] = 
                    {
                        ["price"] = 5140,
                        ["guild"] = 1,
                        ["buyer"] = 932,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633096892,
                        ["quant"] = 1,
                        ["id"] = "1690935887",
                        ["itemLink"] = 263,
                    },
                    [9] = 
                    {
                        ["price"] = 5140,
                        ["guild"] = 1,
                        ["buyer"] = 932,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633096893,
                        ["quant"] = 1,
                        ["id"] = "1690935903",
                        ["itemLink"] = 263,
                    },
                    [10] = 
                    {
                        ["price"] = 5140,
                        ["guild"] = 1,
                        ["buyer"] = 9,
                        ["wasKiosk"] = false,
                        ["seller"] = 151,
                        ["timestamp"] = 1633155167,
                        ["quant"] = 1,
                        ["id"] = "1691432321",
                        ["itemLink"] = 263,
                    },
                    [11] = 
                    {
                        ["price"] = 5140,
                        ["guild"] = 1,
                        ["buyer"] = 9,
                        ["wasKiosk"] = false,
                        ["seller"] = 151,
                        ["timestamp"] = 1633155169,
                        ["quant"] = 1,
                        ["id"] = "1691432323",
                        ["itemLink"] = 263,
                    },
                    [12] = 
                    {
                        ["price"] = 5140,
                        ["guild"] = 1,
                        ["buyer"] = 9,
                        ["wasKiosk"] = false,
                        ["seller"] = 151,
                        ["timestamp"] = 1633155170,
                        ["quant"] = 1,
                        ["id"] = "1691432325",
                        ["itemLink"] = 263,
                    },
                    [13] = 
                    {
                        ["price"] = 5200,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632914234,
                        ["quant"] = 1,
                        ["id"] = "1689618667",
                        ["itemLink"] = 263,
                    },
                    [14] = 
                    {
                        ["price"] = 5200,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632914235,
                        ["quant"] = 1,
                        ["id"] = "1689618675",
                        ["itemLink"] = 263,
                    },
                },
                ["totalCount"] = 14,
                ["itemAdderText"] = "rr01 blue superior consumable container",
            },
        },
        [120836] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_col_lsb_dbhcandlelabra003.dds",
                ["itemDesc"] = "Brotherhood Candelabra, Floor",
                ["oldestTime"] = 1633228227,
                ["wasAltered"] = true,
                ["newestTime"] = 1633228227,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1665,
                        ["wasKiosk"] = false,
                        ["seller"] = 195,
                        ["timestamp"] = 1633228227,
                        ["quant"] = 1,
                        ["id"] = "1692099341",
                        ["itemLink"] = 2424,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [126471] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_vrd_lsb_telfloorlamp003.dds",
                ["itemDesc"] = "Telvanni Lantern, Organic Azure",
                ["oldestTime"] = 1632839339,
                ["wasAltered"] = true,
                ["newestTime"] = 1632839339,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22500,
                        ["guild"] = 1,
                        ["buyer"] = 2169,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632839339,
                        ["quant"] = 1,
                        ["id"] = "1689056439",
                        ["itemLink"] = 3130,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [57608] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 20: Yokudan Boots",
                ["oldestTime"] = 1632873493,
                ["wasAltered"] = true,
                ["newestTime"] = 1632873493,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 2312,
                        ["wasKiosk"] = true,
                        ["seller"] = 232,
                        ["timestamp"] = 1632873493,
                        ["quant"] = 1,
                        ["id"] = "1689326893",
                        ["itemLink"] = 3401,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [86025] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_medium_legs_a.dds",
                ["itemDesc"] = "Werewolf Hide Guards",
                ["oldestTime"] = 1632855628,
                ["wasAltered"] = true,
                ["newestTime"] = 1632855628,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 2235,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1632855628,
                        ["quant"] = 1,
                        ["id"] = "1689188447",
                        ["itemLink"] = 3265,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set hide of the werewolf legs infused",
            },
        },
        [176398] = 
        {
            ["1:0:2:46:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_helm_light.dds",
                ["itemDesc"] = "Companion's Hat",
                ["oldestTime"] = 1632991349,
                ["wasAltered"] = true,
                ["newestTime"] = 1632991349,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 357,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1632991349,
                        ["quant"] = 1,
                        ["id"] = "1690192835",
                        ["itemLink"] = 355,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine light apparel head shattering",
            },
        },
        [119055] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Orcish Nightstand, Open",
                ["oldestTime"] = 1633151526,
                ["wasAltered"] = true,
                ["newestTime"] = 1633151526,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1999,
                        ["guild"] = 1,
                        ["buyer"] = 1265,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633151526,
                        ["quant"] = 1,
                        ["id"] = "1691404665",
                        ["itemLink"] = 1728,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [133139] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nocturnal_medium_shoulder_a.dds",
                ["itemDesc"] = "Arm Cops of Unfathomable Darkness",
                ["oldestTime"] = 1633274107,
                ["wasAltered"] = true,
                ["newestTime"] = 1633274107,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1999,
                        ["guild"] = 1,
                        ["buyer"] = 1895,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633274107,
                        ["quant"] = 1,
                        ["id"] = "1692451593",
                        ["itemLink"] = 2690,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set unfathomable darkness shoulders impenetrable",
            },
        },
        [86295] = 
        {
            ["50:16:4:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_wormcult_1haxe_a.dds",
                ["itemDesc"] = "Axe of the Withered Hand",
                ["oldestTime"] = 1632935759,
                ["wasAltered"] = true,
                ["newestTime"] = 1632935759,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2253,
                        ["guild"] = 1,
                        ["buyer"] = 226,
                        ["wasKiosk"] = false,
                        ["seller"] = 528,
                        ["timestamp"] = 1632935759,
                        ["quant"] = 1,
                        ["id"] = "1689767415",
                        ["itemLink"] = 3735,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set robes of the withered hand axe one-handed charged",
            },
        },
        [129816] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_snowreach_medium_feet_a.dds",
                ["itemDesc"] = "Briarheart Boots",
                ["oldestTime"] = 1632972324,
                ["wasAltered"] = true,
                ["newestTime"] = 1632972324,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 187,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1632972324,
                        ["quant"] = 1,
                        ["id"] = "1690079137",
                        ["itemLink"] = 200,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set briarheart feet impenetrable",
            },
        },
        [153626] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/event_halloween_2016_spooky_recipe.dds",
                ["itemDesc"] = "Recipe: Pack Leader's Bone Broth",
                ["oldestTime"] = 1633261653,
                ["wasAltered"] = true,
                ["newestTime"] = 1633262686,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 33600,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 611,
                        ["timestamp"] = 1633261653,
                        ["quant"] = 1,
                        ["id"] = "1692334737",
                        ["itemLink"] = 2629,
                    },
                    [2] = 
                    {
                        ["price"] = 21999,
                        ["guild"] = 1,
                        ["buyer"] = 1843,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633262686,
                        ["quant"] = 1,
                        ["id"] = "1692340571",
                        ["itemLink"] = 2629,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary consumable recipe",
            },
        },
        [115739] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Argonian Basket, Serving",
                ["oldestTime"] = 1633047919,
                ["wasAltered"] = true,
                ["newestTime"] = 1633047919,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50,
                        ["guild"] = 1,
                        ["buyer"] = 271,
                        ["wasKiosk"] = false,
                        ["seller"] = 182,
                        ["timestamp"] = 1633047919,
                        ["quant"] = 1,
                        ["id"] = "1690584953",
                        ["itemLink"] = 873,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [135452] = 
        {
            ["50:16:4:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_dagger_b.dds",
                ["itemDesc"] = "Gryphon's Dagger",
                ["oldestTime"] = 1633307760,
                ["wasAltered"] = true,
                ["newestTime"] = 1633307760,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 2074,
                        ["wasKiosk"] = true,
                        ["seller"] = 474,
                        ["timestamp"] = 1633307760,
                        ["quant"] = 1,
                        ["id"] = "1692820843",
                        ["itemLink"] = 2950,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set gryphon's ferocity dagger one-handed charged",
            },
        },
        [45342] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_heavy_hands_a.dds",
                ["itemDesc"] = "Rubedite Gauntlets",
                ["oldestTime"] = 1632913789,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309493,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 262,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633028927,
                        ["quant"] = 1,
                        ["id"] = "1690436803",
                        ["itemLink"] = 706,
                    },
                    [2] = 
                    {
                        ["price"] = 262,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633028929,
                        ["quant"] = 1,
                        ["id"] = "1690436805",
                        ["itemLink"] = 707,
                    },
                    [3] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633146940,
                        ["quant"] = 1,
                        ["id"] = "1691365405",
                        ["itemLink"] = 1673,
                    },
                    [4] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633185990,
                        ["quant"] = 1,
                        ["id"] = "1691640609",
                        ["itemLink"] = 2048,
                    },
                    [5] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633186015,
                        ["quant"] = 1,
                        ["id"] = "1691640777",
                        ["itemLink"] = 2059,
                    },
                    [6] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633244678,
                        ["quant"] = 1,
                        ["id"] = "1692231327",
                        ["itemLink"] = 707,
                    },
                    [7] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633244680,
                        ["quant"] = 1,
                        ["id"] = "1692231353",
                        ["itemLink"] = 2059,
                    },
                    [8] = 
                    {
                        ["price"] = 384,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633309491,
                        ["quant"] = 1,
                        ["id"] = "1692843431",
                        ["itemLink"] = 1673,
                    },
                    [9] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633309493,
                        ["quant"] = 1,
                        ["id"] = "1692843453",
                        ["itemLink"] = 2971,
                    },
                    [10] = 
                    {
                        ["price"] = 160,
                        ["guild"] = 1,
                        ["buyer"] = 2202,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1632913789,
                        ["quant"] = 1,
                        ["id"] = "1689616111",
                        ["itemLink"] = 3631,
                    },
                    [11] = 
                    {
                        ["price"] = 199,
                        ["guild"] = 1,
                        ["buyer"] = 2202,
                        ["wasKiosk"] = true,
                        ["seller"] = 283,
                        ["timestamp"] = 1632913793,
                        ["quant"] = 1,
                        ["id"] = "1689616137",
                        ["itemLink"] = 2059,
                    },
                    [12] = 
                    {
                        ["price"] = 215,
                        ["guild"] = 1,
                        ["buyer"] = 2501,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632930578,
                        ["quant"] = 1,
                        ["id"] = "1689726301",
                        ["itemLink"] = 3702,
                    },
                    [13] = 
                    {
                        ["price"] = 275,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632956409,
                        ["quant"] = 1,
                        ["id"] = "1689931689",
                        ["itemLink"] = 3702,
                    },
                },
                ["totalCount"] = 13,
                ["itemAdderText"] = "cp160 white normal heavy apparel hands intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_heavy_hands_d.dds",
                ["itemDesc"] = "Rubedite Gauntlets",
                ["oldestTime"] = 1632838976,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309489,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633309489,
                        ["quant"] = 1,
                        ["id"] = "1692843385",
                        ["itemLink"] = 2968,
                    },
                    [2] = 
                    {
                        ["price"] = 381,
                        ["guild"] = 1,
                        ["buyer"] = 2167,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632838976,
                        ["quant"] = 1,
                        ["id"] = "1689054119",
                        ["itemLink"] = 3118,
                    },
                    [3] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2293,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632871322,
                        ["quant"] = 1,
                        ["id"] = "1689312095",
                        ["itemLink"] = 3390,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp150 white normal heavy apparel hands intricate",
            },
        },
        [45346] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_waist_d.dds",
                ["itemDesc"] = "Rubedite Girdle",
                ["oldestTime"] = 1632838702,
                ["wasAltered"] = true,
                ["newestTime"] = 1633249601,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 384,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633009360,
                        ["quant"] = 1,
                        ["id"] = "1690285363",
                        ["itemLink"] = 473,
                    },
                    [2] = 
                    {
                        ["price"] = 384,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633009361,
                        ["quant"] = 1,
                        ["id"] = "1690285385",
                        ["itemLink"] = 474,
                    },
                    [3] = 
                    {
                        ["price"] = 384,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633009362,
                        ["quant"] = 1,
                        ["id"] = "1690285393",
                        ["itemLink"] = 475,
                    },
                    [4] = 
                    {
                        ["price"] = 194,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1633028912,
                        ["quant"] = 1,
                        ["id"] = "1690436741",
                        ["itemLink"] = 701,
                    },
                    [5] = 
                    {
                        ["price"] = 194,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1633028916,
                        ["quant"] = 1,
                        ["id"] = "1690436747",
                        ["itemLink"] = 702,
                    },
                    [6] = 
                    {
                        ["price"] = 194,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1633028921,
                        ["quant"] = 1,
                        ["id"] = "1690436765",
                        ["itemLink"] = 701,
                    },
                    [7] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633084077,
                        ["quant"] = 1,
                        ["id"] = "1690854905",
                        ["itemLink"] = 475,
                    },
                    [8] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633129401,
                        ["quant"] = 1,
                        ["id"] = "1691180199",
                        ["itemLink"] = 1504,
                    },
                    [9] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633129402,
                        ["quant"] = 1,
                        ["id"] = "1691180209",
                        ["itemLink"] = 1504,
                    },
                    [10] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633186012,
                        ["quant"] = 1,
                        ["id"] = "1691640745",
                        ["itemLink"] = 475,
                    },
                    [11] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633186018,
                        ["quant"] = 1,
                        ["id"] = "1691640821",
                        ["itemLink"] = 474,
                    },
                    [12] = 
                    {
                        ["price"] = 160,
                        ["guild"] = 1,
                        ["buyer"] = 1734,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633236158,
                        ["quant"] = 1,
                        ["id"] = "1692168667",
                        ["itemLink"] = 2491,
                    },
                    [13] = 
                    {
                        ["price"] = 160,
                        ["guild"] = 1,
                        ["buyer"] = 1734,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633236160,
                        ["quant"] = 1,
                        ["id"] = "1692168699",
                        ["itemLink"] = 701,
                    },
                    [14] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1811,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633249601,
                        ["quant"] = 1,
                        ["id"] = "1692267629",
                        ["itemLink"] = 2590,
                    },
                    [15] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 527,
                        ["timestamp"] = 1632838702,
                        ["quant"] = 1,
                        ["id"] = "1689052593",
                        ["itemLink"] = 1504,
                    },
                    [16] = 
                    {
                        ["price"] = 864,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1632843203,
                        ["quant"] = 1,
                        ["id"] = "1689085405",
                        ["itemLink"] = 473,
                    },
                    [17] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2516,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632930836,
                        ["quant"] = 1,
                        ["id"] = "1689728273",
                        ["itemLink"] = 3708,
                    },
                },
                ["totalCount"] = 17,
                ["itemAdderText"] = "cp160 white normal heavy apparel waist intricate",
            },
            ["39:0:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_heavy_waist_d.dds",
                ["itemDesc"] = "Dwarven Girdle",
                ["oldestTime"] = 1633213532,
                ["wasAltered"] = true,
                ["newestTime"] = 1633213532,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1567,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633213532,
                        ["quant"] = 1,
                        ["id"] = "1691945369",
                        ["itemLink"] = 2291,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr39 white normal heavy apparel waist intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_heavy_waist_d.dds",
                ["itemDesc"] = "Rubedite Girdle",
                ["oldestTime"] = 1632865262,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309491,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084683,
                        ["quant"] = 1,
                        ["id"] = "1690857361",
                        ["itemLink"] = 1209,
                    },
                    [2] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633129407,
                        ["quant"] = 1,
                        ["id"] = "1691180267",
                        ["itemLink"] = 1505,
                    },
                    [3] = 
                    {
                        ["price"] = 310,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633129409,
                        ["quant"] = 1,
                        ["id"] = "1691180297",
                        ["itemLink"] = 1507,
                    },
                    [4] = 
                    {
                        ["price"] = 381,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633309491,
                        ["quant"] = 1,
                        ["id"] = "1692843417",
                        ["itemLink"] = 2969,
                    },
                    [5] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632865262,
                        ["quant"] = 1,
                        ["id"] = "1689266325",
                        ["itemLink"] = 3328,
                    },
                    [6] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2660,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632966352,
                        ["quant"] = 1,
                        ["id"] = "1690018417",
                        ["itemLink"] = 2969,
                    },
                    [7] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2660,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632966353,
                        ["quant"] = 1,
                        ["id"] = "1690018427",
                        ["itemLink"] = 3328,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "cp150 white normal heavy apparel waist intricate",
            },
        },
        [152099] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Elsweyr Carpet, Gold-Emerald",
                ["oldestTime"] = 1633158046,
                ["wasAltered"] = true,
                ["newestTime"] = 1633158046,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99,
                        ["guild"] = 1,
                        ["buyer"] = 1293,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633158046,
                        ["quant"] = 1,
                        ["id"] = "1691454577",
                        ["itemLink"] = 1778,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [45604] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Narsis Wickwheat Ale",
                ["oldestTime"] = 1633311197,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311197,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1899,
                        ["guild"] = 1,
                        ["buyer"] = 1,
                        ["wasKiosk"] = false,
                        ["seller"] = 2,
                        ["timestamp"] = 1633311197,
                        ["quant"] = 1,
                        ["id"] = "1692862437",
                        ["itemLink"] = 1,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45608] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Bitter Kaveh",
                ["oldestTime"] = 1632865559,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865559,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 2194,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632865559,
                        ["quant"] = 1,
                        ["id"] = "1689269081",
                        ["itemLink"] = 3354,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [16428] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_book_001.dds",
                ["itemDesc"] = "Crafting Motif 3: Wood Elf Style",
                ["oldestTime"] = 1632934323,
                ["wasAltered"] = true,
                ["newestTime"] = 1633040217,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 484,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633017937,
                        ["quant"] = 1,
                        ["id"] = "1690349041",
                        ["itemLink"] = 564,
                    },
                    [2] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 158,
                        ["wasKiosk"] = false,
                        ["seller"] = 533,
                        ["timestamp"] = 1633040217,
                        ["quant"] = 1,
                        ["id"] = "1690514961",
                        ["itemLink"] = 564,
                    },
                    [3] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 2524,
                        ["wasKiosk"] = true,
                        ["seller"] = 51,
                        ["timestamp"] = 1632934323,
                        ["quant"] = 1,
                        ["id"] = "1689754663",
                        ["itemLink"] = 564,
                    },
                    [4] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 2524,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632934325,
                        ["quant"] = 1,
                        ["id"] = "1689754683",
                        ["itemLink"] = 564,
                    },
                    [5] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 2524,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632934328,
                        ["quant"] = 1,
                        ["id"] = "1689754691",
                        ["itemLink"] = 564,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 blue superior consumable motif",
            },
        },
        [45870] = 
        {
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_reducespellcosts.dds",
                ["itemDesc"] = "Truly Superb Glyph of Reduce Spell Cost",
                ["oldestTime"] = 1632826377,
                ["wasAltered"] = true,
                ["newestTime"] = 1633032468,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 398,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633001133,
                        ["quant"] = 1,
                        ["id"] = "1690240029",
                        ["itemLink"] = 404,
                    },
                    [2] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633032465,
                        ["quant"] = 1,
                        ["id"] = "1690460913",
                        ["itemLink"] = 732,
                    },
                    [3] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633032466,
                        ["quant"] = 1,
                        ["id"] = "1690460919",
                        ["itemLink"] = 732,
                    },
                    [4] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633032468,
                        ["quant"] = 1,
                        ["id"] = "1690460933",
                        ["itemLink"] = 735,
                    },
                    [5] = 
                    {
                        ["price"] = 125,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1632826377,
                        ["quant"] = 1,
                        ["id"] = "1688971215",
                        ["itemLink"] = 3028,
                    },
                    [6] = 
                    {
                        ["price"] = 125,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1632826377,
                        ["quant"] = 1,
                        ["id"] = "1688971219",
                        ["itemLink"] = 3028,
                    },
                    [7] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 442,
                        ["timestamp"] = 1632826381,
                        ["quant"] = 1,
                        ["id"] = "1688971247",
                        ["itemLink"] = 3031,
                    },
                    [8] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632826387,
                        ["quant"] = 1,
                        ["id"] = "1688971323",
                        ["itemLink"] = 404,
                    },
                    [9] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632881736,
                        ["quant"] = 1,
                        ["id"] = "1689414585",
                        ["itemLink"] = 3470,
                    },
                    [10] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632885358,
                        ["quant"] = 1,
                        ["id"] = "1689456631",
                        ["itemLink"] = 3470,
                    },
                },
                ["totalCount"] = 10,
                ["itemAdderText"] = "cp160 white normal miscellaneous jewelry glyph",
            },
        },
        [45871] = 
        {
            ["50:16:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_reducefeatcosts.dds",
                ["itemDesc"] = "Truly Superb Glyph of Reduce Feat Cost",
                ["oldestTime"] = 1633148052,
                ["wasAltered"] = true,
                ["newestTime"] = 1633148052,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 360,
                        ["guild"] = 1,
                        ["buyer"] = 1244,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633148052,
                        ["quant"] = 1,
                        ["id"] = "1691374197",
                        ["itemLink"] = 1689,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior miscellaneous jewelry glyph",
            },
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_reducefeatcosts.dds",
                ["itemDesc"] = "Truly Superb Glyph of Reduce Feat Cost",
                ["oldestTime"] = 1632831093,
                ["wasAltered"] = true,
                ["newestTime"] = 1632937678,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6200,
                        ["guild"] = 1,
                        ["buyer"] = 340,
                        ["wasKiosk"] = false,
                        ["seller"] = 673,
                        ["timestamp"] = 1632831093,
                        ["quant"] = 1,
                        ["id"] = "1689005021",
                        ["itemLink"] = 3085,
                    },
                    [2] = 
                    {
                        ["price"] = 6200,
                        ["guild"] = 1,
                        ["buyer"] = 2532,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1632937678,
                        ["quant"] = 1,
                        ["id"] = "1689779441",
                        ["itemLink"] = 3085,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous jewelry glyph",
            },
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_reducefeatcosts.dds",
                ["itemDesc"] = "Truly Superb Glyph of Reduce Feat Cost",
                ["oldestTime"] = 1632826378,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297967,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 398,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633001130,
                        ["quant"] = 1,
                        ["id"] = "1690240005",
                        ["itemLink"] = 400,
                    },
                    [2] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633032462,
                        ["quant"] = 1,
                        ["id"] = "1690460879",
                        ["itemLink"] = 729,
                    },
                    [3] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633032464,
                        ["quant"] = 1,
                        ["id"] = "1690460897",
                        ["itemLink"] = 400,
                    },
                    [4] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1025,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633115971,
                        ["quant"] = 1,
                        ["id"] = "1691078547",
                        ["itemLink"] = 1403,
                    },
                    [5] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1639,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633224733,
                        ["quant"] = 1,
                        ["id"] = "1692061373",
                        ["itemLink"] = 400,
                    },
                    [6] = 
                    {
                        ["price"] = 185,
                        ["guild"] = 1,
                        ["buyer"] = 1639,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633225377,
                        ["quant"] = 1,
                        ["id"] = "1692068267",
                        ["itemLink"] = 400,
                    },
                    [7] = 
                    {
                        ["price"] = 126,
                        ["guild"] = 1,
                        ["buyer"] = 1866,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1633267872,
                        ["quant"] = 1,
                        ["id"] = "1692383631",
                        ["itemLink"] = 400,
                    },
                    [8] = 
                    {
                        ["price"] = 127,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633297960,
                        ["quant"] = 1,
                        ["id"] = "1692720433",
                        ["itemLink"] = 1403,
                    },
                    [9] = 
                    {
                        ["price"] = 127,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633297967,
                        ["quant"] = 1,
                        ["id"] = "1692720477",
                        ["itemLink"] = 400,
                    },
                    [10] = 
                    {
                        ["price"] = 125,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1632826378,
                        ["quant"] = 1,
                        ["id"] = "1688971221",
                        ["itemLink"] = 3029,
                    },
                    [11] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632826390,
                        ["quant"] = 1,
                        ["id"] = "1688971371",
                        ["itemLink"] = 3032,
                    },
                    [12] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2201,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632846657,
                        ["quant"] = 1,
                        ["id"] = "1689115631",
                        ["itemLink"] = 3201,
                    },
                },
                ["totalCount"] = 12,
                ["itemAdderText"] = "cp160 white normal miscellaneous jewelry glyph",
            },
        },
        [45361] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_medium_shoulders_d.dds",
                ["itemDesc"] = "Rubedo Leather Arm Cops",
                ["oldestTime"] = 1632839968,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186000,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 341,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633009351,
                        ["quant"] = 1,
                        ["id"] = "1690285261",
                        ["itemLink"] = 464,
                    },
                    [2] = 
                    {
                        ["price"] = 341,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633009352,
                        ["quant"] = 1,
                        ["id"] = "1690285267",
                        ["itemLink"] = 464,
                    },
                    [3] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633009354,
                        ["quant"] = 1,
                        ["id"] = "1690285293",
                        ["itemLink"] = 464,
                    },
                    [4] = 
                    {
                        ["price"] = 864,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633084117,
                        ["quant"] = 1,
                        ["id"] = "1690855125",
                        ["itemLink"] = 1195,
                    },
                    [5] = 
                    {
                        ["price"] = 151,
                        ["guild"] = 1,
                        ["buyer"] = 1150,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633136226,
                        ["quant"] = 1,
                        ["id"] = "1691255453",
                        ["itemLink"] = 464,
                    },
                    [6] = 
                    {
                        ["price"] = 160,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633146932,
                        ["quant"] = 1,
                        ["id"] = "1691365277",
                        ["itemLink"] = 1663,
                    },
                    [7] = 
                    {
                        ["price"] = 160,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633146934,
                        ["quant"] = 1,
                        ["id"] = "1691365305",
                        ["itemLink"] = 1665,
                    },
                    [8] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633186000,
                        ["quant"] = 1,
                        ["id"] = "1691640653",
                        ["itemLink"] = 2052,
                    },
                    [9] = 
                    {
                        ["price"] = 275,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1632839968,
                        ["quant"] = 1,
                        ["id"] = "1689060223",
                        ["itemLink"] = 3143,
                    },
                    [10] = 
                    {
                        ["price"] = 310,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632839970,
                        ["quant"] = 1,
                        ["id"] = "1689060237",
                        ["itemLink"] = 3146,
                    },
                    [11] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632956413,
                        ["quant"] = 1,
                        ["id"] = "1689931759",
                        ["itemLink"] = 3897,
                    },
                },
                ["totalCount"] = 11,
                ["itemAdderText"] = "cp160 white normal medium apparel shoulders intricate",
            },
            ["33:0:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_medium_shoulders_c.dds",
                ["itemDesc"] = "Leather Arm Cops",
                ["oldestTime"] = 1633136215,
                ["wasAltered"] = true,
                ["newestTime"] = 1633136215,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 81,
                        ["guild"] = 1,
                        ["buyer"] = 1150,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633136215,
                        ["quant"] = 1,
                        ["id"] = "1691255299",
                        ["itemLink"] = 1567,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr33 white normal medium apparel shoulders intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_medium_shoulders_d.dds",
                ["itemDesc"] = "Rubedo Leather Arm Cops",
                ["oldestTime"] = 1632839964,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185980,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 158,
                        ["guild"] = 1,
                        ["buyer"] = 780,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633059426,
                        ["quant"] = 1,
                        ["id"] = "1690704651",
                        ["itemLink"] = 999,
                    },
                    [2] = 
                    {
                        ["price"] = 243,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633185980,
                        ["quant"] = 1,
                        ["id"] = "1691640491",
                        ["itemLink"] = 2045,
                    },
                    [3] = 
                    {
                        ["price"] = 225,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 527,
                        ["timestamp"] = 1632839964,
                        ["quant"] = 1,
                        ["id"] = "1689060165",
                        ["itemLink"] = 3135,
                    },
                    [4] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632840313,
                        ["quant"] = 1,
                        ["id"] = "1689062303",
                        ["itemLink"] = 2045,
                    },
                    [5] = 
                    {
                        ["price"] = 185,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632956405,
                        ["quant"] = 1,
                        ["id"] = "1689931659",
                        ["itemLink"] = 2045,
                    },
                    [6] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632956415,
                        ["quant"] = 1,
                        ["id"] = "1689931791",
                        ["itemLink"] = 3898,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "cp150 white normal medium apparel shoulders intricate",
            },
        },
        [74547] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 32: Abah's Watch Helmets",
                ["oldestTime"] = 1632873241,
                ["wasAltered"] = true,
                ["newestTime"] = 1632873241,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 38389,
                        ["guild"] = 1,
                        ["buyer"] = 2308,
                        ["wasKiosk"] = true,
                        ["seller"] = 2123,
                        ["timestamp"] = 1632873241,
                        ["quant"] = 1,
                        ["id"] = "1689325345",
                        ["itemLink"] = 3399,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [160564] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 86: Sea Giant Chests",
                ["oldestTime"] = 1633118582,
                ["wasAltered"] = true,
                ["newestTime"] = 1633118582,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 73222,
                        ["guild"] = 1,
                        ["buyer"] = 1038,
                        ["wasKiosk"] = true,
                        ["seller"] = 765,
                        ["timestamp"] = 1633118582,
                        ["quant"] = 1,
                        ["id"] = "1691095881",
                        ["itemLink"] = 1425,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45110] = 
        {
            ["50:14:2:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_bow_d.dds",
                ["itemDesc"] = "Nightwood Bow",
                ["oldestTime"] = 1633018983,
                ["wasAltered"] = true,
                ["newestTime"] = 1633018983,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 500,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633018983,
                        ["quant"] = 1,
                        ["id"] = "1690358053",
                        ["itemLink"] = 574,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp140 green fine weapon bow two-handed precise",
            },
        },
        [145975] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Melon, Wax",
                ["oldestTime"] = 1633287003,
                ["wasAltered"] = true,
                ["newestTime"] = 1633287003,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 59027,
                        ["guild"] = 1,
                        ["buyer"] = 1960,
                        ["wasKiosk"] = false,
                        ["seller"] = 1756,
                        ["timestamp"] = 1633287003,
                        ["quant"] = 1,
                        ["id"] = "1692592163",
                        ["itemLink"] = 2761,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [117816] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_inc_varvase006.dds",
                ["itemDesc"] = "Redguard Decanter, Delicate",
                ["oldestTime"] = 1633165945,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165945,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 34768,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1633165945,
                        ["quant"] = 2,
                        ["id"] = "1691500187",
                        ["itemLink"] = 1853,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings hearth",
            },
        },
        [46137] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_hide_scaled.dds",
                ["itemDesc"] = "Superb Hide",
                ["oldestTime"] = 1632824708,
                ["wasAltered"] = true,
                ["newestTime"] = 1633304636,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1176,
                        ["wasKiosk"] = true,
                        ["seller"] = 803,
                        ["timestamp"] = 1633304636,
                        ["quant"] = 50,
                        ["id"] = "1692786487",
                        ["itemLink"] = 2927,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1365,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632824708,
                        ["quant"] = 10,
                        ["id"] = "1688962819",
                        ["itemLink"] = 2927,
                    },
                    [3] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 2374,
                        ["wasKiosk"] = true,
                        ["seller"] = 803,
                        ["timestamp"] = 1632883755,
                        ["quant"] = 50,
                        ["id"] = "1689436099",
                        ["itemLink"] = 2927,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [74556] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 33: Thieves Guild Axes",
                ["oldestTime"] = 1633083874,
                ["wasAltered"] = true,
                ["newestTime"] = 1633083874,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 893,
                        ["wasKiosk"] = true,
                        ["seller"] = 374,
                        ["timestamp"] = 1633083874,
                        ["quant"] = 1,
                        ["id"] = "1690853493",
                        ["itemLink"] = 1144,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45885] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_decreasephysicaldamage.dds",
                ["itemDesc"] = "Superb Glyph of Decrease Physical Harm",
                ["oldestTime"] = 1633297971,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297971,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 227,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633297971,
                        ["quant"] = 1,
                        ["id"] = "1692720495",
                        ["itemLink"] = 2900,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 green fine miscellaneous jewelry glyph",
            },
        },
        [181575] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Gate, Wooden Garden",
                ["oldestTime"] = 1633096489,
                ["wasAltered"] = true,
                ["newestTime"] = 1633216461,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 929,
                        ["wasKiosk"] = true,
                        ["seller"] = 802,
                        ["timestamp"] = 1633096489,
                        ["quant"] = 1,
                        ["id"] = "1690931959",
                        ["itemLink"] = 1265,
                    },
                    [2] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1589,
                        ["wasKiosk"] = true,
                        ["seller"] = 827,
                        ["timestamp"] = 1633216461,
                        ["quant"] = 1,
                        ["id"] = "1691972923",
                        ["itemLink"] = 1265,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45896] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Balmora Cabbage Biscuits",
                ["oldestTime"] = 1633157986,
                ["wasAltered"] = true,
                ["newestTime"] = 1633157986,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25,
                        ["guild"] = 1,
                        ["buyer"] = 1293,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633157986,
                        ["quant"] = 1,
                        ["id"] = "1691453929",
                        ["itemLink"] = 1773,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [166986] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 90: Thorn Legion Swords",
                ["oldestTime"] = 1633020136,
                ["wasAltered"] = true,
                ["newestTime"] = 1633020136,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 80000,
                        ["guild"] = 1,
                        ["buyer"] = 504,
                        ["wasKiosk"] = true,
                        ["seller"] = 506,
                        ["timestamp"] = 1633020136,
                        ["quant"] = 1,
                        ["id"] = "1690366599",
                        ["itemLink"] = 578,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [180812] = 
        {
            ["50:16:4:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_2hsword_a.dds",
                ["itemDesc"] = "Hrothgar's Greatsword",
                ["oldestTime"] = 1633112441,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112441,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 991,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633112441,
                        ["quant"] = 1,
                        ["id"] = "1691055269",
                        ["itemLink"] = 1348,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set hrothgar's chill sword two-handed precise",
            },
        },
        [176974] = 
        {
            ["1:0:2:50:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_helm_light.dds",
                ["itemDesc"] = "Companion's Hat",
                ["oldestTime"] = 1633189477,
                ["wasAltered"] = true,
                ["newestTime"] = 1633189477,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1608,
                        ["guild"] = 1,
                        ["buyer"] = 1413,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1633189477,
                        ["quant"] = 1,
                        ["id"] = "1691684153",
                        ["itemLink"] = 2095,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine light apparel head bolstered",
            },
        },
        [155215] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Dragonguard Elite's Ring",
                ["oldestTime"] = 1633163908,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163908,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 755,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633163908,
                        ["quant"] = 1,
                        ["id"] = "1691490295",
                        ["itemLink"] = 1799,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set dragonguard elite ring robust",
            },
        },
        [176722] = 
        {
            ["1:0:3:48:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_helm_light.dds",
                ["itemDesc"] = "Companion's Hat",
                ["oldestTime"] = 1632979708,
                ["wasAltered"] = true,
                ["newestTime"] = 1633295346,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 89999,
                        ["guild"] = 1,
                        ["buyer"] = 249,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1632979708,
                        ["quant"] = 1,
                        ["id"] = "1690129633",
                        ["itemLink"] = 261,
                    },
                    [2] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 807,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633064116,
                        ["quant"] = 1,
                        ["id"] = "1690740973",
                        ["itemLink"] = 261,
                    },
                    [3] = 
                    {
                        ["price"] = 79999,
                        ["guild"] = 1,
                        ["buyer"] = 1344,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633172255,
                        ["quant"] = 1,
                        ["id"] = "1691531561",
                        ["itemLink"] = 261,
                    },
                    [4] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 2017,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633295346,
                        ["quant"] = 1,
                        ["id"] = "1692693699",
                        ["itemLink"] = 261,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior light apparel head soothing",
            },
        },
        [115027] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/consumeable_experience_003.dds",
                ["itemDesc"] = "Mythic Aetherial Ambrosia",
                ["oldestTime"] = 1632971920,
                ["wasAltered"] = true,
                ["newestTime"] = 1633230917,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 149000,
                        ["guild"] = 1,
                        ["buyer"] = 184,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632971920,
                        ["quant"] = 1,
                        ["id"] = "1690075635",
                        ["itemLink"] = 197,
                    },
                    [2] = 
                    {
                        ["price"] = 149000,
                        ["guild"] = 1,
                        ["buyer"] = 184,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632971922,
                        ["quant"] = 1,
                        ["id"] = "1690075671",
                        ["itemLink"] = 197,
                    },
                    [3] = 
                    {
                        ["price"] = 150000,
                        ["guild"] = 1,
                        ["buyer"] = 184,
                        ["wasKiosk"] = true,
                        ["seller"] = 185,
                        ["timestamp"] = 1632971923,
                        ["quant"] = 1,
                        ["id"] = "1690075697",
                        ["itemLink"] = 197,
                    },
                    [4] = 
                    {
                        ["price"] = 150000,
                        ["guild"] = 1,
                        ["buyer"] = 184,
                        ["wasKiosk"] = true,
                        ["seller"] = 185,
                        ["timestamp"] = 1632971925,
                        ["quant"] = 1,
                        ["id"] = "1690075727",
                        ["itemLink"] = 197,
                    },
                    [5] = 
                    {
                        ["price"] = 151500,
                        ["guild"] = 1,
                        ["buyer"] = 184,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1632971926,
                        ["quant"] = 1,
                        ["id"] = "1690075755",
                        ["itemLink"] = 197,
                    },
                    [6] = 
                    {
                        ["price"] = 151500,
                        ["guild"] = 1,
                        ["buyer"] = 184,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1632971928,
                        ["quant"] = 1,
                        ["id"] = "1690075785",
                        ["itemLink"] = 197,
                    },
                    [7] = 
                    {
                        ["price"] = 140000,
                        ["guild"] = 1,
                        ["buyer"] = 614,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633038199,
                        ["quant"] = 1,
                        ["id"] = "1690499625",
                        ["itemLink"] = 197,
                    },
                    [8] = 
                    {
                        ["price"] = 140000,
                        ["guild"] = 1,
                        ["buyer"] = 614,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633040638,
                        ["quant"] = 1,
                        ["id"] = "1690517491",
                        ["itemLink"] = 197,
                    },
                    [9] = 
                    {
                        ["price"] = 146884,
                        ["guild"] = 1,
                        ["buyer"] = 1686,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633229914,
                        ["quant"] = 1,
                        ["id"] = "1692114519",
                        ["itemLink"] = 197,
                    },
                    [10] = 
                    {
                        ["price"] = 150500,
                        ["guild"] = 1,
                        ["buyer"] = 1671,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633230917,
                        ["quant"] = 1,
                        ["id"] = "1692123599",
                        ["itemLink"] = 197,
                    },
                },
                ["totalCount"] = 10,
                ["itemAdderText"] = "rr01 gold legendary consumable drink",
            },
        },
        [167002] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 91: Hazardous Alchemy Staves",
                ["oldestTime"] = 1633191255,
                ["wasAltered"] = true,
                ["newestTime"] = 1633191255,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 1423,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1633191255,
                        ["quant"] = 1,
                        ["id"] = "1691703925",
                        ["itemLink"] = 2110,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [76892] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 34: Assassins League Swords",
                ["oldestTime"] = 1632883759,
                ["wasAltered"] = true,
                ["newestTime"] = 1632883759,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10500,
                        ["guild"] = 1,
                        ["buyer"] = 719,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632883759,
                        ["quant"] = 1,
                        ["id"] = "1689436139",
                        ["itemLink"] = 3490,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [82016] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 41: Celestial Maces",
                ["oldestTime"] = 1632970178,
                ["wasAltered"] = true,
                ["newestTime"] = 1632970178,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 160,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1632970178,
                        ["quant"] = 1,
                        ["id"] = "1690058625",
                        ["itemLink"] = 170,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [98146] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of the Ranger",
                ["oldestTime"] = 1633042159,
                ["wasAltered"] = true,
                ["newestTime"] = 1633042159,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 646,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633042159,
                        ["quant"] = 1,
                        ["id"] = "1690529835",
                        ["itemLink"] = 814,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set ranger's gait neck robust",
            },
        },
        [151651] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_exc_housingmerchantspices003.dds",
                ["itemDesc"] = "Elsweyr Spice Display, Saffron Red",
                ["oldestTime"] = 1633165817,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165817,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 17,
                        ["timestamp"] = 1633165817,
                        ["quant"] = 1,
                        ["id"] = "1691499679",
                        ["itemLink"] = 1843,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings hearth",
            },
        },
        [68453] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_snowreach_medium_waist_a.dds",
                ["itemDesc"] = "Briarheart Belt",
                ["oldestTime"] = 1633023044,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023044,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 845,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633023044,
                        ["quant"] = 1,
                        ["id"] = "1690391015",
                        ["itemLink"] = 667,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set briarheart waist infused",
            },
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_snowreach_medium_waist_a.dds",
                ["itemDesc"] = "Briarheart Belt",
                ["oldestTime"] = 1632875015,
                ["wasAltered"] = true,
                ["newestTime"] = 1632875015,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 2321,
                        ["wasKiosk"] = true,
                        ["seller"] = 237,
                        ["timestamp"] = 1632875015,
                        ["quant"] = 1,
                        ["id"] = "1689341651",
                        ["itemLink"] = 3409,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set briarheart waist infused",
            },
        },
        [175977] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Leyawiin Firepit, Stone",
                ["oldestTime"] = 1633185691,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185691,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 709,
                        ["timestamp"] = 1633185691,
                        ["quant"] = 1,
                        ["id"] = "1691637135",
                        ["itemLink"] = 1990,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [166762] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Vampiric Drapes, Tall",
                ["oldestTime"] = 1633082241,
                ["wasAltered"] = true,
                ["newestTime"] = 1633082241,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 886,
                        ["wasKiosk"] = true,
                        ["seller"] = 514,
                        ["timestamp"] = 1633082241,
                        ["quant"] = 1,
                        ["id"] = "1690845177",
                        ["itemLink"] = 1131,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45931] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Cyrodilic Pumpkin Fritters",
                ["oldestTime"] = 1632965169,
                ["wasAltered"] = true,
                ["newestTime"] = 1632965169,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 2,
                        ["buyer"] = 134,
                        ["wasKiosk"] = false,
                        ["seller"] = 117,
                        ["timestamp"] = 1632965169,
                        ["quant"] = 1,
                        ["id"] = "1690008095",
                        ["itemLink"] = 145,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [82029] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 42: Hollowjack Gloves",
                ["oldestTime"] = 1633124328,
                ["wasAltered"] = true,
                ["newestTime"] = 1633124328,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1072,
                        ["wasKiosk"] = true,
                        ["seller"] = 533,
                        ["timestamp"] = 1633124328,
                        ["quant"] = 1,
                        ["id"] = "1691137193",
                        ["itemLink"] = 1462,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [4463] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_cloth_base_flax_r3.dds",
                ["itemDesc"] = "Flax",
                ["oldestTime"] = 1632637986,
                ["wasAltered"] = true,
                ["newestTime"] = 1632987728,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 2,
                        ["buyer"] = 124,
                        ["wasKiosk"] = false,
                        ["seller"] = 125,
                        ["timestamp"] = 1632637986,
                        ["quant"] = 200,
                        ["id"] = "1687416853",
                        ["itemLink"] = 102,
                    },
                    [2] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 2,
                        ["buyer"] = 124,
                        ["wasKiosk"] = false,
                        ["seller"] = 125,
                        ["timestamp"] = 1632769446,
                        ["quant"] = 200,
                        ["id"] = "1688524671",
                        ["itemLink"] = 102,
                    },
                    [3] = 
                    {
                        ["price"] = 2250,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 332,
                        ["timestamp"] = 1632987710,
                        ["quant"] = 200,
                        ["id"] = "1690172831",
                        ["itemLink"] = 102,
                    },
                    [4] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 46,
                        ["timestamp"] = 1632987728,
                        ["quant"] = 100,
                        ["id"] = "1690172915",
                        ["itemLink"] = 102,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [142192] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 68: Honor Guard Daggers",
                ["oldestTime"] = 1633005391,
                ["wasAltered"] = true,
                ["newestTime"] = 1633106698,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8999,
                        ["guild"] = 1,
                        ["buyer"] = 418,
                        ["wasKiosk"] = true,
                        ["seller"] = 417,
                        ["timestamp"] = 1633005391,
                        ["quant"] = 1,
                        ["id"] = "1690262009",
                        ["itemLink"] = 427,
                    },
                    [2] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 970,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633106698,
                        ["quant"] = 1,
                        ["id"] = "1691013337",
                        ["itemLink"] = 427,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [177010] = 
        {
            ["1:0:3:50:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_helm_light.dds",
                ["itemDesc"] = "Companion's Hat",
                ["oldestTime"] = 1632941963,
                ["wasAltered"] = true,
                ["newestTime"] = 1632941963,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1699,
                        ["guild"] = 1,
                        ["buyer"] = 2554,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1632941963,
                        ["quant"] = 1,
                        ["id"] = "1689808873",
                        ["itemLink"] = 3775,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior light apparel head bolstered",
            },
        },
        [45171] = 
        {
            ["50:16:1:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_heavy_waist_d.dds",
                ["itemDesc"] = "Rubedite Girdle",
                ["oldestTime"] = 1632856337,
                ["wasAltered"] = true,
                ["newestTime"] = 1632856337,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632856337,
                        ["quant"] = 1,
                        ["id"] = "1689200671",
                        ["itemLink"] = 3272,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal heavy apparel waist training",
            },
        },
        [42869] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_worms.dds",
                ["itemDesc"] = "Worms, Saltwater Bait",
                ["oldestTime"] = 1632833870,
                ["wasAltered"] = true,
                ["newestTime"] = 1633257660,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5678,
                        ["guild"] = 1,
                        ["buyer"] = 258,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1632980208,
                        ["quant"] = 155,
                        ["id"] = "1690131343",
                        ["itemLink"] = 265,
                    },
                    [2] = 
                    {
                        ["price"] = 19800,
                        ["guild"] = 1,
                        ["buyer"] = 446,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633009581,
                        ["quant"] = 200,
                        ["id"] = "1690287297",
                        ["itemLink"] = 265,
                    },
                    [3] = 
                    {
                        ["price"] = 19800,
                        ["guild"] = 1,
                        ["buyer"] = 446,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633009583,
                        ["quant"] = 200,
                        ["id"] = "1690287319",
                        ["itemLink"] = 265,
                    },
                    [4] = 
                    {
                        ["price"] = 6650,
                        ["guild"] = 1,
                        ["buyer"] = 751,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633055900,
                        ["quant"] = 95,
                        ["id"] = "1690663197",
                        ["itemLink"] = 265,
                    },
                    [5] = 
                    {
                        ["price"] = 8200,
                        ["guild"] = 1,
                        ["buyer"] = 1280,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633155559,
                        ["quant"] = 200,
                        ["id"] = "1691435905",
                        ["itemLink"] = 265,
                    },
                    [6] = 
                    {
                        ["price"] = 9235,
                        ["guild"] = 1,
                        ["buyer"] = 1280,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633155561,
                        ["quant"] = 200,
                        ["id"] = "1691435917",
                        ["itemLink"] = 265,
                    },
                    [7] = 
                    {
                        ["price"] = 11400,
                        ["guild"] = 1,
                        ["buyer"] = 1394,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633185720,
                        ["quant"] = 200,
                        ["id"] = "1691637389",
                        ["itemLink"] = 265,
                    },
                    [8] = 
                    {
                        ["price"] = 1512,
                        ["guild"] = 1,
                        ["buyer"] = 1757,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633239283,
                        ["quant"] = 42,
                        ["id"] = "1692193015",
                        ["itemLink"] = 265,
                    },
                    [9] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 900,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633257660,
                        ["quant"] = 32,
                        ["id"] = "1692315627",
                        ["itemLink"] = 265,
                    },
                    [10] = 
                    {
                        ["price"] = 8171,
                        ["guild"] = 1,
                        ["buyer"] = 2146,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1632833870,
                        ["quant"] = 200,
                        ["id"] = "1689021181",
                        ["itemLink"] = 265,
                    },
                    [11] = 
                    {
                        ["price"] = 8171,
                        ["guild"] = 1,
                        ["buyer"] = 2146,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1632833872,
                        ["quant"] = 200,
                        ["id"] = "1689021211",
                        ["itemLink"] = 265,
                    },
                    [12] = 
                    {
                        ["price"] = 7910,
                        ["guild"] = 1,
                        ["buyer"] = 2563,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632945500,
                        ["quant"] = 113,
                        ["id"] = "1689838663",
                        ["itemLink"] = 265,
                    },
                },
                ["totalCount"] = 12,
                ["itemAdderText"] = "rr01 white normal miscellaneous lure",
            },
        },
        [68470] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_snowreach_medium_feet_a.dds",
                ["itemDesc"] = "Briarheart Boots",
                ["oldestTime"] = 1633023038,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023038,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633023038,
                        ["quant"] = 1,
                        ["id"] = "1690390961",
                        ["itemLink"] = 662,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set briarheart feet well-fitted",
            },
        },
        [134775] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 59: Scalecaller Bows",
                ["oldestTime"] = 1633052109,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052109,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 242,
                        ["wasKiosk"] = false,
                        ["seller"] = 709,
                        ["timestamp"] = 1633052109,
                        ["quant"] = 1,
                        ["id"] = "1690627061",
                        ["itemLink"] = 896,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [175993] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting2.dds",
                ["itemDesc"] = "Praxis: Leyawiin Pitcher, Cracked",
                ["oldestTime"] = 1633091037,
                ["wasAltered"] = true,
                ["newestTime"] = 1633272474,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 655,
                        ["wasKiosk"] = false,
                        ["seller"] = 911,
                        ["timestamp"] = 1633091037,
                        ["quant"] = 1,
                        ["id"] = "1690894481",
                        ["itemLink"] = 1242,
                    },
                    [2] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1393,
                        ["wasKiosk"] = true,
                        ["seller"] = 911,
                        ["timestamp"] = 1633185719,
                        ["quant"] = 1,
                        ["id"] = "1691637387",
                        ["itemLink"] = 1242,
                    },
                    [3] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 31,
                        ["wasKiosk"] = false,
                        ["seller"] = 1108,
                        ["timestamp"] = 1633200578,
                        ["quant"] = 1,
                        ["id"] = "1691795583",
                        ["itemLink"] = 1242,
                    },
                    [4] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1643,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633272474,
                        ["quant"] = 1,
                        ["id"] = "1692431817",
                        ["itemLink"] = 1242,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [139642] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Alinor Carpet, Intricate",
                ["oldestTime"] = 1632958388,
                ["wasAltered"] = true,
                ["newestTime"] = 1632958388,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 1472,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632958388,
                        ["quant"] = 1,
                        ["id"] = "1689946699",
                        ["itemLink"] = 3913,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [171899] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 101: Ivory Brigade Bows",
                ["oldestTime"] = 1632897108,
                ["wasAltered"] = true,
                ["newestTime"] = 1633313767,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6750,
                        ["guild"] = 1,
                        ["buyer"] = 61,
                        ["wasKiosk"] = false,
                        ["seller"] = 63,
                        ["timestamp"] = 1633313767,
                        ["quant"] = 1,
                        ["id"] = "1692888459",
                        ["itemLink"] = 46,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 642,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1633041878,
                        ["quant"] = 1,
                        ["id"] = "1690527803",
                        ["itemLink"] = 46,
                    },
                    [3] = 
                    {
                        ["price"] = 7950,
                        ["guild"] = 1,
                        ["buyer"] = 1654,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633226591,
                        ["quant"] = 1,
                        ["id"] = "1692081013",
                        ["itemLink"] = 46,
                    },
                    [4] = 
                    {
                        ["price"] = 7950,
                        ["guild"] = 1,
                        ["buyer"] = 1654,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633226591,
                        ["quant"] = 1,
                        ["id"] = "1692081029",
                        ["itemLink"] = 46,
                    },
                    [5] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1654,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633226592,
                        ["quant"] = 1,
                        ["id"] = "1692081037",
                        ["itemLink"] = 46,
                    },
                    [6] = 
                    {
                        ["price"] = 10900,
                        ["guild"] = 1,
                        ["buyer"] = 1063,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632897108,
                        ["quant"] = 1,
                        ["id"] = "1689542569",
                        ["itemLink"] = 46,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [74108] = 
        {
            ["50:16:5:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Fury",
                ["oldestTime"] = 1633270871,
                ["wasAltered"] = true,
                ["newestTime"] = 1633270872,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 165000,
                        ["guild"] = 1,
                        ["buyer"] = 1420,
                        ["wasKiosk"] = true,
                        ["seller"] = 48,
                        ["timestamp"] = 1633270871,
                        ["quant"] = 1,
                        ["id"] = "1692414881",
                        ["itemLink"] = 2668,
                    },
                    [2] = 
                    {
                        ["price"] = 165000,
                        ["guild"] = 1,
                        ["buyer"] = 1420,
                        ["wasKiosk"] = true,
                        ["seller"] = 48,
                        ["timestamp"] = 1633270872,
                        ["quant"] = 1,
                        ["id"] = "1692414899",
                        ["itemLink"] = 2668,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 gold legendary jewelry apparel set warrior's fury ring healthy",
            },
        },
        [175998] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting2.dds",
                ["itemDesc"] = "Praxis: Leyawiin Pot, Wide",
                ["oldestTime"] = 1633091035,
                ["wasAltered"] = true,
                ["newestTime"] = 1633272487,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 375,
                        ["guild"] = 1,
                        ["buyer"] = 655,
                        ["wasKiosk"] = false,
                        ["seller"] = 911,
                        ["timestamp"] = 1633091035,
                        ["quant"] = 1,
                        ["id"] = "1690894477",
                        ["itemLink"] = 1241,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1643,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633272483,
                        ["quant"] = 1,
                        ["id"] = "1692431865",
                        ["itemLink"] = 1241,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1643,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633272487,
                        ["quant"] = 1,
                        ["id"] = "1692431889",
                        ["itemLink"] = 1241,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [171904] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 101: Ivory Brigade Legs",
                ["oldestTime"] = 1633057935,
                ["wasAltered"] = true,
                ["newestTime"] = 1633314442,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 68,
                        ["wasKiosk"] = true,
                        ["seller"] = 71,
                        ["timestamp"] = 1633314442,
                        ["quant"] = 1,
                        ["id"] = "1692895373",
                        ["itemLink"] = 54,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 79,
                        ["timestamp"] = 1633057935,
                        ["quant"] = 1,
                        ["id"] = "1690689831",
                        ["itemLink"] = 54,
                    },
                    [3] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1628,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1633224544,
                        ["quant"] = 1,
                        ["id"] = "1692059469",
                        ["itemLink"] = 54,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [180609] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_bow_a.dds",
                ["itemDesc"] = "Plaguebreak Bow",
                ["oldestTime"] = 1633195309,
                ["wasAltered"] = true,
                ["newestTime"] = 1633195309,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8240,
                        ["guild"] = 1,
                        ["buyer"] = 803,
                        ["wasKiosk"] = false,
                        ["seller"] = 54,
                        ["timestamp"] = 1633195309,
                        ["quant"] = 1,
                        ["id"] = "1691745081",
                        ["itemLink"] = 2134,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set plaguebreak bow two-handed infused",
            },
        },
        [4482] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_ore_calcinium.dds",
                ["itemDesc"] = "Calcinium Ore",
                ["oldestTime"] = 1632861109,
                ["wasAltered"] = true,
                ["newestTime"] = 1632861109,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 104,
                        ["timestamp"] = 1632861109,
                        ["quant"] = 3,
                        ["id"] = "1689239005",
                        ["itemLink"] = 3299,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [160899] = 
        {
            ["50:16:2:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_greyhostmed_helmet_a.dds",
                ["itemDesc"] = "Venomous Helmet",
                ["oldestTime"] = 1632819791,
                ["wasAltered"] = true,
                ["newestTime"] = 1632819791,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2100,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1632819791,
                        ["quant"] = 1,
                        ["id"] = "1688942729",
                        ["itemLink"] = 3010,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set venomous smite head reinforced",
            },
        },
        [177029] = 
        {
            ["1:0:3:50:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_pants_heavy.dds",
                ["itemDesc"] = "Companion's Greaves",
                ["oldestTime"] = 1632868416,
                ["wasAltered"] = true,
                ["newestTime"] = 1633307777,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 69999,
                        ["guild"] = 1,
                        ["buyer"] = 249,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1632978421,
                        ["quant"] = 1,
                        ["id"] = "1690121557",
                        ["itemLink"] = 249,
                    },
                    [2] = 
                    {
                        ["price"] = 69999,
                        ["guild"] = 1,
                        ["buyer"] = 1204,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633142456,
                        ["quant"] = 1,
                        ["id"] = "1691319457",
                        ["itemLink"] = 249,
                    },
                    [3] = 
                    {
                        ["price"] = 69999,
                        ["guild"] = 1,
                        ["buyer"] = 1665,
                        ["wasKiosk"] = false,
                        ["seller"] = 93,
                        ["timestamp"] = 1633307777,
                        ["quant"] = 1,
                        ["id"] = "1692821061",
                        ["itemLink"] = 249,
                    },
                    [4] = 
                    {
                        ["price"] = 49999,
                        ["guild"] = 1,
                        ["buyer"] = 2279,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1632868416,
                        ["quant"] = 1,
                        ["id"] = "1689290905",
                        ["itemLink"] = 249,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior heavy apparel legs bolstered",
            },
        },
        [176007] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Leyawiin Corncobs, Triple",
                ["oldestTime"] = 1633035654,
                ["wasAltered"] = true,
                ["newestTime"] = 1633167876,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1112,
                        ["guild"] = 1,
                        ["buyer"] = 333,
                        ["wasKiosk"] = false,
                        ["seller"] = 600,
                        ["timestamp"] = 1633035654,
                        ["quant"] = 1,
                        ["id"] = "1690480285",
                        ["itemLink"] = 766,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1331,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1633167876,
                        ["quant"] = 1,
                        ["id"] = "1691509701",
                        ["itemLink"] = 766,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [71560] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 22: Trinimac Maces",
                ["oldestTime"] = 1633195655,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310878,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 242,
                        ["wasKiosk"] = false,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633195655,
                        ["quant"] = 1,
                        ["id"] = "1691747799",
                        ["itemLink"] = 2141,
                    },
                    [2] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 2091,
                        ["wasKiosk"] = true,
                        ["seller"] = 981,
                        ["timestamp"] = 1633310878,
                        ["quant"] = 1,
                        ["id"] = "1692858581",
                        ["itemLink"] = 2141,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [99465] = 
        {
            ["22:0:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Order of Diagna",
                ["oldestTime"] = 1633082469,
                ["wasAltered"] = true,
                ["newestTime"] = 1633082469,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 770,
                        ["guild"] = 1,
                        ["buyer"] = 458,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633082469,
                        ["quant"] = 1,
                        ["id"] = "1690846511",
                        ["itemLink"] = 1133,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr22 blue superior jewelry apparel set order of diagna ring healthy",
            },
            ["20:0:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Order of Diagna",
                ["oldestTime"] = 1632935550,
                ["wasAltered"] = true,
                ["newestTime"] = 1632935550,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 975,
                        ["guild"] = 1,
                        ["buyer"] = 1003,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1632935550,
                        ["quant"] = 1,
                        ["id"] = "1689766075",
                        ["itemLink"] = 3733,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr20 blue superior jewelry apparel set order of diagna ring healthy",
            },
            ["22:0:2:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Order of Diagna",
                ["oldestTime"] = 1632875825,
                ["wasAltered"] = true,
                ["newestTime"] = 1632875825,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 735,
                        ["guild"] = 1,
                        ["buyer"] = 2325,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1632875825,
                        ["quant"] = 1,
                        ["id"] = "1689350317",
                        ["itemLink"] = 3421,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr22 green fine jewelry apparel set order of diagna ring healthy",
            },
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Order of Diagna",
                ["oldestTime"] = 1633163910,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163910,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1050,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633163910,
                        ["quant"] = 1,
                        ["id"] = "1691490309",
                        ["itemLink"] = 1801,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set order of diagna ring healthy",
            },
        },
        [71562] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 22: Trinimac Shoulders",
                ["oldestTime"] = 1633195676,
                ["wasAltered"] = true,
                ["newestTime"] = 1633195676,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1451,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633195676,
                        ["quant"] = 1,
                        ["id"] = "1691748125",
                        ["itemLink"] = 2145,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [176326] = 
        {
            ["1:0:4:45:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_helm_light.dds",
                ["itemDesc"] = "Companion's Hat",
                ["oldestTime"] = 1633282486,
                ["wasAltered"] = true,
                ["newestTime"] = 1633282486,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 1940,
                        ["wasKiosk"] = true,
                        ["seller"] = 1455,
                        ["timestamp"] = 1633282486,
                        ["quant"] = 1,
                        ["id"] = "1692541149",
                        ["itemLink"] = 2745,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic light apparel head focused",
            },
        },
        [139660] = 
        {
            ["1:0:4:33:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Exemplary Infused Necklace",
                ["oldestTime"] = 1632838350,
                ["wasAltered"] = true,
                ["newestTime"] = 1633316346,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 754,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633056165,
                        ["quant"] = 1,
                        ["id"] = "1690666401",
                        ["itemLink"] = 951,
                    },
                    [2] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 406,
                        ["wasKiosk"] = false,
                        ["seller"] = 142,
                        ["timestamp"] = 1633134723,
                        ["quant"] = 1,
                        ["id"] = "1691237907",
                        ["itemLink"] = 951,
                    },
                    [3] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633163928,
                        ["quant"] = 1,
                        ["id"] = "1691490435",
                        ["itemLink"] = 951,
                    },
                    [4] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1633163929,
                        ["quant"] = 1,
                        ["id"] = "1691490443",
                        ["itemLink"] = 951,
                    },
                    [5] = 
                    {
                        ["price"] = 1199,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633163929,
                        ["quant"] = 1,
                        ["id"] = "1691490449",
                        ["itemLink"] = 951,
                    },
                    [6] = 
                    {
                        ["price"] = 1199,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633163930,
                        ["quant"] = 1,
                        ["id"] = "1691490453",
                        ["itemLink"] = 951,
                    },
                    [7] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 1314,
                        ["timestamp"] = 1633163934,
                        ["quant"] = 1,
                        ["id"] = "1691490481",
                        ["itemLink"] = 951,
                    },
                    [8] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 1314,
                        ["timestamp"] = 1633163937,
                        ["quant"] = 1,
                        ["id"] = "1691490499",
                        ["itemLink"] = 951,
                    },
                    [9] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 1314,
                        ["timestamp"] = 1633163939,
                        ["quant"] = 1,
                        ["id"] = "1691490513",
                        ["itemLink"] = 951,
                    },
                    [10] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 1369,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633258454,
                        ["quant"] = 1,
                        ["id"] = "1692318891",
                        ["itemLink"] = 951,
                    },
                    [11] = 
                    {
                        ["price"] = 1036,
                        ["guild"] = 1,
                        ["buyer"] = 2096,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1633316346,
                        ["quant"] = 1,
                        ["id"] = "1692918775",
                        ["itemLink"] = 951,
                    },
                    [12] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2164,
                        ["wasKiosk"] = true,
                        ["seller"] = 1494,
                        ["timestamp"] = 1632838350,
                        ["quant"] = 1,
                        ["id"] = "1689050045",
                        ["itemLink"] = 951,
                    },
                    [13] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2051,
                        ["wasKiosk"] = true,
                        ["seller"] = 528,
                        ["timestamp"] = 1632934523,
                        ["quant"] = 1,
                        ["id"] = "1689755933",
                        ["itemLink"] = 951,
                    },
                    [14] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2665,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632966666,
                        ["quant"] = 1,
                        ["id"] = "1690020817",
                        ["itemLink"] = 951,
                    },
                },
                ["totalCount"] = 14,
                ["itemAdderText"] = "rr01 purple epic jewelry apparel neck infused",
            },
        },
        [144525] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_medium_shoulders_a.dds",
                ["itemDesc"] = "Soldier of Anguish Arm Cops",
                ["oldestTime"] = 1633200743,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200743,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1491,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633200743,
                        ["quant"] = 1,
                        ["id"] = "1691797205",
                        ["itemLink"] = 2195,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set soldier of anguish shoulders well-fitted",
            },
        },
        [34307] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_radish.dds",
                ["itemDesc"] = "Radish",
                ["oldestTime"] = 1633042316,
                ["wasAltered"] = true,
                ["newestTime"] = 1633042316,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2800,
                        ["guild"] = 1,
                        ["buyer"] = 648,
                        ["wasKiosk"] = true,
                        ["seller"] = 649,
                        ["timestamp"] = 1633042316,
                        ["quant"] = 200,
                        ["id"] = "1690531151",
                        ["itemLink"] = 825,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [180649] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_bow_a.dds",
                ["itemDesc"] = "Plaguebreak Bow",
                ["oldestTime"] = 1632958726,
                ["wasAltered"] = true,
                ["newestTime"] = 1632958847,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 334,
                        ["wasKiosk"] = false,
                        ["seller"] = 47,
                        ["timestamp"] = 1632958726,
                        ["quant"] = 1,
                        ["id"] = "1689950017",
                        ["itemLink"] = 3914,
                    },
                    [2] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 334,
                        ["wasKiosk"] = false,
                        ["seller"] = 510,
                        ["timestamp"] = 1632958847,
                        ["quant"] = 1,
                        ["id"] = "1689951297",
                        ["itemLink"] = 3915,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior weapon set plaguebreak bow two-handed precise",
            },
        },
        [119042] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Orcish Curtain, Curved",
                ["oldestTime"] = 1632958334,
                ["wasAltered"] = true,
                ["newestTime"] = 1632958334,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7700,
                        ["guild"] = 1,
                        ["buyer"] = 1472,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632958334,
                        ["quant"] = 1,
                        ["id"] = "1689946387",
                        ["itemLink"] = 3909,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [46140] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_wood_sanded_ash.dds",
                ["itemDesc"] = "Sanded Ash",
                ["oldestTime"] = 1632957856,
                ["wasAltered"] = true,
                ["newestTime"] = 1632957856,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 622,
                        ["wasKiosk"] = false,
                        ["seller"] = 803,
                        ["timestamp"] = 1632957856,
                        ["quant"] = 100,
                        ["id"] = "1689942055",
                        ["itemLink"] = 3906,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [115858] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Wood Elf Wall Hide, Fur",
                ["oldestTime"] = 1633179318,
                ["wasAltered"] = true,
                ["newestTime"] = 1633179318,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1361,
                        ["wasKiosk"] = true,
                        ["seller"] = 6,
                        ["timestamp"] = 1633179318,
                        ["quant"] = 1,
                        ["id"] = "1691581255",
                        ["itemLink"] = 1910,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [120555] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_flr_goldenrodcluster004.dds",
                ["itemDesc"] = "Flowers, Healthy Goldenrod",
                ["oldestTime"] = 1632950965,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950965,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 973,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1632950965,
                        ["quant"] = 3,
                        ["id"] = "1689881397",
                        ["itemLink"] = 3840,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings conservatory",
            },
        },
        [127054] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Redoran Table Runner, Gilded Ochre",
                ["oldestTime"] = 1632950218,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950218,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 420420,
                        ["guild"] = 1,
                        ["buyer"] = 193,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1632950218,
                        ["quant"] = 1,
                        ["id"] = "1689875927",
                        ["itemLink"] = 3834,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [45308] = 
        {
            ["29:0:1:19:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_heavy_head_c.dds",
                ["itemDesc"] = "Orichalc Helm",
                ["oldestTime"] = 1632950131,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950131,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 297,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 2205,
                        ["timestamp"] = 1632950131,
                        ["quant"] = 1,
                        ["id"] = "1689875247",
                        ["itemLink"] = 3823,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr29 white normal heavy apparel head ornate",
            },
        },
        [45100] = 
        {
            ["50:16:2:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_heavy_shoulders_d.dds",
                ["itemDesc"] = "Rubedite Pauldron of Stamina",
                ["oldestTime"] = 1632950135,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950135,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1632950135,
                        ["quant"] = 1,
                        ["id"] = "1689875283",
                        ["itemLink"] = 3829,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel shoulders reinforced",
            },
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_heavy_shoulders_d.dds",
                ["itemDesc"] = "Rubedite Pauldron of Magicka",
                ["oldestTime"] = 1632950130,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950130,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1632950130,
                        ["quant"] = 1,
                        ["id"] = "1689875235",
                        ["itemLink"] = 3821,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel shoulders reinforced",
            },
        },
        [82018] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 41: Celestial Shoulders",
                ["oldestTime"] = 1632948571,
                ["wasAltered"] = true,
                ["newestTime"] = 1632948571,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11111,
                        ["guild"] = 1,
                        ["buyer"] = 2577,
                        ["wasKiosk"] = true,
                        ["seller"] = 159,
                        ["timestamp"] = 1632948571,
                        ["quant"] = 1,
                        ["id"] = "1689862295",
                        ["itemLink"] = 3800,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [57029] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Sweet and Sour Port",
                ["oldestTime"] = 1632930437,
                ["wasAltered"] = true,
                ["newestTime"] = 1632930437,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1632930437,
                        ["quant"] = 1,
                        ["id"] = "1689725235",
                        ["itemLink"] = 3701,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [151705] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_fur_chest001.dds",
                ["itemDesc"] = "Elsweyr Trunk, Floral",
                ["oldestTime"] = 1632886293,
                ["wasAltered"] = true,
                ["newestTime"] = 1632886293,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 299,
                        ["wasKiosk"] = false,
                        ["seller"] = 73,
                        ["timestamp"] = 1632886293,
                        ["quant"] = 1,
                        ["id"] = "1689465143",
                        ["itemLink"] = 3520,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings suite",
            },
        },
        [166810] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Solitude Pew, Sturdy Long",
                ["oldestTime"] = 1633205024,
                ["wasAltered"] = true,
                ["newestTime"] = 1633205024,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 51000,
                        ["guild"] = 1,
                        ["buyer"] = 1520,
                        ["wasKiosk"] = true,
                        ["seller"] = 981,
                        ["timestamp"] = 1633205024,
                        ["quant"] = 1,
                        ["id"] = "1691842641",
                        ["itemLink"] = 2244,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [54171] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_forester_weapon_vendor_component_002.dds",
                ["itemDesc"] = "Dwarven Oil",
                ["oldestTime"] = 1632848314,
                ["wasAltered"] = true,
                ["newestTime"] = 1632848317,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 92,
                        ["timestamp"] = 1632848314,
                        ["quant"] = 50,
                        ["id"] = "1689130719",
                        ["itemLink"] = 3224,
                    },
                    [2] = 
                    {
                        ["price"] = 5995,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 322,
                        ["timestamp"] = 1632848315,
                        ["quant"] = 200,
                        ["id"] = "1689130729",
                        ["itemLink"] = 3224,
                    },
                    [3] = 
                    {
                        ["price"] = 5899,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 330,
                        ["timestamp"] = 1632848316,
                        ["quant"] = 200,
                        ["id"] = "1689130737",
                        ["itemLink"] = 3224,
                    },
                    [4] = 
                    {
                        ["price"] = 3999,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1632848317,
                        ["quant"] = 200,
                        ["id"] = "1689130743",
                        ["itemLink"] = 3224,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior materials temper",
            },
        },
        [45980] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Red Rye Beer",
                ["oldestTime"] = 1633197961,
                ["wasAltered"] = true,
                ["newestTime"] = 1633197961,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30,
                        ["guild"] = 1,
                        ["buyer"] = 1469,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633197961,
                        ["quant"] = 1,
                        ["id"] = "1691769133",
                        ["itemLink"] = 2157,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [98717] = 
        {
            ["50:16:3:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_2haxe_d.dds",
                ["itemDesc"] = "Battle Axe of Hist Sap",
                ["oldestTime"] = 1633052764,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052764,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 718,
                        ["wasKiosk"] = true,
                        ["seller"] = 281,
                        ["timestamp"] = 1633052764,
                        ["quant"] = 1,
                        ["id"] = "1690632823",
                        ["itemLink"] = 911,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set robes of the hist axe two-handed powered",
            },
        },
        [34308] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_melo.dds",
                ["itemDesc"] = "Melon",
                ["oldestTime"] = 1632928315,
                ["wasAltered"] = true,
                ["newestTime"] = 1632928315,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 775,
                        ["guild"] = 1,
                        ["buyer"] = 2068,
                        ["wasKiosk"] = true,
                        ["seller"] = 442,
                        ["timestamp"] = 1632928315,
                        ["quant"] = 50,
                        ["id"] = "1689708615",
                        ["itemLink"] = 3692,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [46024] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Tonsil Tingle Tonic",
                ["oldestTime"] = 1632913095,
                ["wasAltered"] = true,
                ["newestTime"] = 1632913095,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 850,
                        ["guild"] = 1,
                        ["buyer"] = 2471,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1632913095,
                        ["quant"] = 1,
                        ["id"] = "1689612645",
                        ["itemLink"] = 3628,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [176032] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Deadlands Table, Ashen Wide",
                ["oldestTime"] = 1633232853,
                ["wasAltered"] = true,
                ["newestTime"] = 1633232853,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1709,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633232853,
                        ["quant"] = 1,
                        ["id"] = "1692143275",
                        ["itemLink"] = 2451,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [156577] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 77: Stags of Z'en Bows",
                ["oldestTime"] = 1632902307,
                ["wasAltered"] = true,
                ["newestTime"] = 1632902307,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 420,
                        ["wasKiosk"] = true,
                        ["seller"] = 514,
                        ["timestamp"] = 1632902307,
                        ["quant"] = 1,
                        ["id"] = "1689570181",
                        ["itemLink"] = 3578,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [171591] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 99: Waking Flame Shields",
                ["oldestTime"] = 1632906223,
                ["wasAltered"] = true,
                ["newestTime"] = 1632906223,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 54999,
                        ["guild"] = 1,
                        ["buyer"] = 318,
                        ["wasKiosk"] = true,
                        ["seller"] = 283,
                        ["timestamp"] = 1632906223,
                        ["quant"] = 1,
                        ["id"] = "1689587811",
                        ["itemLink"] = 3589,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [28316] = 
        {
            ["15:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_vendor_fuel_stew_001.dds",
                ["itemDesc"] = "Shepherd's Pie",
                ["oldestTime"] = 1633304936,
                ["wasAltered"] = true,
                ["newestTime"] = 1633304936,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 836,
                        ["wasKiosk"] = true,
                        ["seller"] = 1004,
                        ["timestamp"] = 1633304936,
                        ["quant"] = 50,
                        ["id"] = "1692789329",
                        ["itemLink"] = 2928,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr15 blue superior consumable food",
            },
        },
        [142226] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 70: Elder Argonian Helmets",
                ["oldestTime"] = 1632900147,
                ["wasAltered"] = true,
                ["newestTime"] = 1632900147,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 29952,
                        ["guild"] = 1,
                        ["buyer"] = 328,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1632900147,
                        ["quant"] = 1,
                        ["id"] = "1689560145",
                        ["itemLink"] = 3573,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [54181] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_wood_rosin.dds",
                ["itemDesc"] = "Rosin",
                ["oldestTime"] = 1632838851,
                ["wasAltered"] = true,
                ["newestTime"] = 1633314636,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900000,
                        ["guild"] = 1,
                        ["buyer"] = 81,
                        ["wasKiosk"] = false,
                        ["seller"] = 82,
                        ["timestamp"] = 1633314636,
                        ["quant"] = 200,
                        ["id"] = "1692897885",
                        ["itemLink"] = 61,
                    },
                    [2] = 
                    {
                        ["price"] = 8400,
                        ["guild"] = 1,
                        ["buyer"] = 147,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1632969304,
                        ["quant"] = 2,
                        ["id"] = "1690049283",
                        ["itemLink"] = 61,
                    },
                    [3] = 
                    {
                        ["price"] = 8400,
                        ["guild"] = 1,
                        ["buyer"] = 147,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1632969693,
                        ["quant"] = 2,
                        ["id"] = "1690053707",
                        ["itemLink"] = 61,
                    },
                    [4] = 
                    {
                        ["price"] = 8400,
                        ["guild"] = 1,
                        ["buyer"] = 147,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1632969696,
                        ["quant"] = 2,
                        ["id"] = "1690053739",
                        ["itemLink"] = 61,
                    },
                    [5] = 
                    {
                        ["price"] = 8400,
                        ["guild"] = 1,
                        ["buyer"] = 147,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1632969698,
                        ["quant"] = 2,
                        ["id"] = "1690053761",
                        ["itemLink"] = 61,
                    },
                    [6] = 
                    {
                        ["price"] = 16800,
                        ["guild"] = 1,
                        ["buyer"] = 147,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632969705,
                        ["quant"] = 4,
                        ["id"] = "1690053851",
                        ["itemLink"] = 61,
                    },
                    [7] = 
                    {
                        ["price"] = 8400,
                        ["guild"] = 1,
                        ["buyer"] = 147,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632969707,
                        ["quant"] = 2,
                        ["id"] = "1690053893",
                        ["itemLink"] = 61,
                    },
                    [8] = 
                    {
                        ["price"] = 4393,
                        ["guild"] = 1,
                        ["buyer"] = 263,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632980904,
                        ["quant"] = 1,
                        ["id"] = "1690135575",
                        ["itemLink"] = 61,
                    },
                    [9] = 
                    {
                        ["price"] = 21500,
                        ["guild"] = 1,
                        ["buyer"] = 346,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1632990030,
                        ["quant"] = 5,
                        ["id"] = "1690187207",
                        ["itemLink"] = 61,
                    },
                    [10] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 346,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1632990031,
                        ["quant"] = 1,
                        ["id"] = "1690187211",
                        ["itemLink"] = 61,
                    },
                    [11] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 591,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633035089,
                        ["quant"] = 2,
                        ["id"] = "1690476455",
                        ["itemLink"] = 61,
                    },
                    [12] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 591,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633035090,
                        ["quant"] = 2,
                        ["id"] = "1690476473",
                        ["itemLink"] = 61,
                    },
                    [13] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 591,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633035092,
                        ["quant"] = 2,
                        ["id"] = "1690476491",
                        ["itemLink"] = 61,
                    },
                    [14] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 591,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633035094,
                        ["quant"] = 2,
                        ["id"] = "1690476519",
                        ["itemLink"] = 61,
                    },
                    [15] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 591,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633035096,
                        ["quant"] = 2,
                        ["id"] = "1690476541",
                        ["itemLink"] = 61,
                    },
                    [16] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 436,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633044290,
                        ["quant"] = 2,
                        ["id"] = "1690549903",
                        ["itemLink"] = 61,
                    },
                    [17] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 677,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633046027,
                        ["quant"] = 2,
                        ["id"] = "1690566767",
                        ["itemLink"] = 61,
                    },
                    [18] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 677,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633046028,
                        ["quant"] = 2,
                        ["id"] = "1690566795",
                        ["itemLink"] = 61,
                    },
                    [19] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 677,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633046030,
                        ["quant"] = 2,
                        ["id"] = "1690566821",
                        ["itemLink"] = 61,
                    },
                    [20] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 26,
                        ["wasKiosk"] = false,
                        ["seller"] = 63,
                        ["timestamp"] = 1633050432,
                        ["quant"] = 2,
                        ["id"] = "1690609389",
                        ["itemLink"] = 61,
                    },
                    [21] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 26,
                        ["wasKiosk"] = false,
                        ["seller"] = 63,
                        ["timestamp"] = 1633050433,
                        ["quant"] = 2,
                        ["id"] = "1690609397",
                        ["itemLink"] = 61,
                    },
                    [22] = 
                    {
                        ["price"] = 174000,
                        ["guild"] = 1,
                        ["buyer"] = 783,
                        ["wasKiosk"] = true,
                        ["seller"] = 626,
                        ["timestamp"] = 1633059540,
                        ["quant"] = 40,
                        ["id"] = "1690706057",
                        ["itemLink"] = 61,
                    },
                    [23] = 
                    {
                        ["price"] = 17298,
                        ["guild"] = 1,
                        ["buyer"] = 838,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633069738,
                        ["quant"] = 4,
                        ["id"] = "1690776787",
                        ["itemLink"] = 61,
                    },
                    [24] = 
                    {
                        ["price"] = 8400,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633124929,
                        ["quant"] = 2,
                        ["id"] = "1691142013",
                        ["itemLink"] = 61,
                    },
                    [25] = 
                    {
                        ["price"] = 8400,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633124929,
                        ["quant"] = 2,
                        ["id"] = "1691142021",
                        ["itemLink"] = 61,
                    },
                    [26] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633124930,
                        ["quant"] = 3,
                        ["id"] = "1691142029",
                        ["itemLink"] = 61,
                    },
                    [27] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1162,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633137220,
                        ["quant"] = 10,
                        ["id"] = "1691264143",
                        ["itemLink"] = 61,
                    },
                    [28] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1162,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633137220,
                        ["quant"] = 10,
                        ["id"] = "1691264147",
                        ["itemLink"] = 61,
                    },
                    [29] = 
                    {
                        ["price"] = 16800,
                        ["guild"] = 1,
                        ["buyer"] = 831,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633150914,
                        ["quant"] = 4,
                        ["id"] = "1691398715",
                        ["itemLink"] = 61,
                    },
                    [30] = 
                    {
                        ["price"] = 86400,
                        ["guild"] = 1,
                        ["buyer"] = 510,
                        ["wasKiosk"] = false,
                        ["seller"] = 76,
                        ["timestamp"] = 1633190099,
                        ["quant"] = 20,
                        ["id"] = "1691688619",
                        ["itemLink"] = 61,
                    },
                    [31] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1505,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633203025,
                        ["quant"] = 10,
                        ["id"] = "1691822907",
                        ["itemLink"] = 61,
                    },
                    [32] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1505,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633203027,
                        ["quant"] = 10,
                        ["id"] = "1691822951",
                        ["itemLink"] = 61,
                    },
                    [33] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1505,
                        ["wasKiosk"] = true,
                        ["seller"] = 1480,
                        ["timestamp"] = 1633203030,
                        ["quant"] = 2,
                        ["id"] = "1691823005",
                        ["itemLink"] = 61,
                    },
                    [34] = 
                    {
                        ["price"] = 17298,
                        ["guild"] = 1,
                        ["buyer"] = 511,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633203757,
                        ["quant"] = 4,
                        ["id"] = "1691830685",
                        ["itemLink"] = 61,
                    },
                    [35] = 
                    {
                        ["price"] = 34400,
                        ["guild"] = 1,
                        ["buyer"] = 658,
                        ["wasKiosk"] = true,
                        ["seller"] = 763,
                        ["timestamp"] = 1633218020,
                        ["quant"] = 8,
                        ["id"] = "1691990803",
                        ["itemLink"] = 61,
                    },
                    [36] = 
                    {
                        ["price"] = 34800,
                        ["guild"] = 1,
                        ["buyer"] = 658,
                        ["wasKiosk"] = true,
                        ["seller"] = 6,
                        ["timestamp"] = 1633218024,
                        ["quant"] = 8,
                        ["id"] = "1691990845",
                        ["itemLink"] = 61,
                    },
                    [37] = 
                    {
                        ["price"] = 60800,
                        ["guild"] = 1,
                        ["buyer"] = 1764,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633239904,
                        ["quant"] = 16,
                        ["id"] = "1692196437",
                        ["itemLink"] = 61,
                    },
                    [38] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 1890,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633272950,
                        ["quant"] = 4,
                        ["id"] = "1692436719",
                        ["itemLink"] = 61,
                    },
                    [39] = 
                    {
                        ["price"] = 17480,
                        ["guild"] = 1,
                        ["buyer"] = 22,
                        ["wasKiosk"] = false,
                        ["seller"] = 90,
                        ["timestamp"] = 1633302583,
                        ["quant"] = 4,
                        ["id"] = "1692767541",
                        ["itemLink"] = 61,
                    },
                    [40] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 2059,
                        ["wasKiosk"] = true,
                        ["seller"] = 1480,
                        ["timestamp"] = 1633304423,
                        ["quant"] = 1,
                        ["id"] = "1692784435",
                        ["itemLink"] = 61,
                    },
                    [41] = 
                    {
                        ["price"] = 15200,
                        ["guild"] = 1,
                        ["buyer"] = 358,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633306538,
                        ["quant"] = 4,
                        ["id"] = "1692805013",
                        ["itemLink"] = 61,
                    },
                    [42] = 
                    {
                        ["price"] = 17200,
                        ["guild"] = 1,
                        ["buyer"] = 358,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633306539,
                        ["quant"] = 4,
                        ["id"] = "1692805033",
                        ["itemLink"] = 61,
                    },
                    [43] = 
                    {
                        ["price"] = 4100,
                        ["guild"] = 1,
                        ["buyer"] = 2166,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1632838851,
                        ["quant"] = 1,
                        ["id"] = "1689053367",
                        ["itemLink"] = 61,
                    },
                    [44] = 
                    {
                        ["price"] = 73100,
                        ["guild"] = 1,
                        ["buyer"] = 2166,
                        ["wasKiosk"] = true,
                        ["seller"] = 31,
                        ["timestamp"] = 1632842705,
                        ["quant"] = 17,
                        ["id"] = "1689081399",
                        ["itemLink"] = 61,
                    },
                    [45] = 
                    {
                        ["price"] = 8800,
                        ["guild"] = 1,
                        ["buyer"] = 2166,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1632842708,
                        ["quant"] = 2,
                        ["id"] = "1689081423",
                        ["itemLink"] = 61,
                    },
                    [46] = 
                    {
                        ["price"] = 141000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 513,
                        ["timestamp"] = 1632848378,
                        ["quant"] = 30,
                        ["id"] = "1689131209",
                        ["itemLink"] = 61,
                    },
                    [47] = 
                    {
                        ["price"] = 76000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 351,
                        ["timestamp"] = 1632848379,
                        ["quant"] = 10,
                        ["id"] = "1689131237",
                        ["itemLink"] = 61,
                    },
                    [48] = 
                    {
                        ["price"] = 438750,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 1318,
                        ["timestamp"] = 1632848381,
                        ["quant"] = 75,
                        ["id"] = "1689131257",
                        ["itemLink"] = 61,
                    },
                    [49] = 
                    {
                        ["price"] = 87980,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1632848389,
                        ["quant"] = 20,
                        ["id"] = "1689131295",
                        ["itemLink"] = 61,
                    },
                    [50] = 
                    {
                        ["price"] = 68250,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1632848391,
                        ["quant"] = 15,
                        ["id"] = "1689131299",
                        ["itemLink"] = 61,
                    },
                    [51] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632848393,
                        ["quant"] = 10,
                        ["id"] = "1689131307",
                        ["itemLink"] = 61,
                    },
                    [52] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632848394,
                        ["quant"] = 10,
                        ["id"] = "1689131315",
                        ["itemLink"] = 61,
                    },
                    [53] = 
                    {
                        ["price"] = 23999,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 696,
                        ["timestamp"] = 1632848435,
                        ["quant"] = 5,
                        ["id"] = "1689131461",
                        ["itemLink"] = 61,
                    },
                    [54] = 
                    {
                        ["price"] = 23999,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 696,
                        ["timestamp"] = 1632848436,
                        ["quant"] = 5,
                        ["id"] = "1689131469",
                        ["itemLink"] = 61,
                    },
                    [55] = 
                    {
                        ["price"] = 23495,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632848437,
                        ["quant"] = 5,
                        ["id"] = "1689131477",
                        ["itemLink"] = 61,
                    },
                    [56] = 
                    {
                        ["price"] = 9306,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632848437,
                        ["quant"] = 2,
                        ["id"] = "1689131485",
                        ["itemLink"] = 61,
                    },
                    [57] = 
                    {
                        ["price"] = 4650,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 1786,
                        ["timestamp"] = 1632848438,
                        ["quant"] = 1,
                        ["id"] = "1689131489",
                        ["itemLink"] = 61,
                    },
                    [58] = 
                    {
                        ["price"] = 4650,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 1786,
                        ["timestamp"] = 1632848439,
                        ["quant"] = 1,
                        ["id"] = "1689131495",
                        ["itemLink"] = 61,
                    },
                    [59] = 
                    {
                        ["price"] = 4650,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 1786,
                        ["timestamp"] = 1632848440,
                        ["quant"] = 1,
                        ["id"] = "1689131501",
                        ["itemLink"] = 61,
                    },
                    [60] = 
                    {
                        ["price"] = 4650,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 1786,
                        ["timestamp"] = 1632848440,
                        ["quant"] = 1,
                        ["id"] = "1689131505",
                        ["itemLink"] = 61,
                    },
                    [61] = 
                    {
                        ["price"] = 4650,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 1786,
                        ["timestamp"] = 1632848441,
                        ["quant"] = 1,
                        ["id"] = "1689131509",
                        ["itemLink"] = 61,
                    },
                    [62] = 
                    {
                        ["price"] = 4650,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 1786,
                        ["timestamp"] = 1632848442,
                        ["quant"] = 1,
                        ["id"] = "1689131517",
                        ["itemLink"] = 61,
                    },
                    [63] = 
                    {
                        ["price"] = 4650,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 1786,
                        ["timestamp"] = 1632848442,
                        ["quant"] = 1,
                        ["id"] = "1689131523",
                        ["itemLink"] = 61,
                    },
                    [64] = 
                    {
                        ["price"] = 36800,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1632848445,
                        ["quant"] = 8,
                        ["id"] = "1689131533",
                        ["itemLink"] = 61,
                    },
                    [65] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1632848447,
                        ["quant"] = 1,
                        ["id"] = "1689131559",
                        ["itemLink"] = 61,
                    },
                    [66] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 2338,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632877756,
                        ["quant"] = 1,
                        ["id"] = "1689370533",
                        ["itemLink"] = 61,
                    },
                    [67] = 
                    {
                        ["price"] = 16340,
                        ["guild"] = 1,
                        ["buyer"] = 505,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1632892864,
                        ["quant"] = 4,
                        ["id"] = "1689515199",
                        ["itemLink"] = 61,
                    },
                    [68] = 
                    {
                        ["price"] = 16340,
                        ["guild"] = 1,
                        ["buyer"] = 505,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1632892865,
                        ["quant"] = 4,
                        ["id"] = "1689515209",
                        ["itemLink"] = 61,
                    },
                    [69] = 
                    {
                        ["price"] = 16340,
                        ["guild"] = 1,
                        ["buyer"] = 505,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1632892871,
                        ["quant"] = 4,
                        ["id"] = "1689515285",
                        ["itemLink"] = 61,
                    },
                    [70] = 
                    {
                        ["price"] = 16340,
                        ["guild"] = 1,
                        ["buyer"] = 505,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1632892871,
                        ["quant"] = 4,
                        ["id"] = "1689515293",
                        ["itemLink"] = 61,
                    },
                    [71] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632919253,
                        ["quant"] = 4,
                        ["id"] = "1689647797",
                        ["itemLink"] = 61,
                    },
                    [72] = 
                    {
                        ["price"] = 13179,
                        ["guild"] = 1,
                        ["buyer"] = 591,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632941480,
                        ["quant"] = 3,
                        ["id"] = "1689805593",
                        ["itemLink"] = 61,
                    },
                },
                ["totalCount"] = 72,
                ["itemAdderText"] = "rr01 gold legendary materials resin",
            },
        },
        [156582] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 77: Stags of Z'en Legs",
                ["oldestTime"] = 1633030767,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052105,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 561,
                        ["wasKiosk"] = true,
                        ["seller"] = 374,
                        ["timestamp"] = 1633030767,
                        ["quant"] = 1,
                        ["id"] = "1690449229",
                        ["itemLink"] = 712,
                    },
                    [2] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 710,
                        ["wasKiosk"] = false,
                        ["seller"] = 374,
                        ["timestamp"] = 1633052105,
                        ["quant"] = 1,
                        ["id"] = "1690627043",
                        ["itemLink"] = 712,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [176597] = 
        {
            ["1:0:3:47:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_pants_heavy.dds",
                ["itemDesc"] = "Companion's Greaves",
                ["oldestTime"] = 1633193595,
                ["wasAltered"] = true,
                ["newestTime"] = 1633193595,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5400,
                        ["guild"] = 1,
                        ["buyer"] = 32,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633193595,
                        ["quant"] = 1,
                        ["id"] = "1691730295",
                        ["itemLink"] = 2125,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior heavy apparel legs aggressive",
            },
        },
        [167982] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 97: Wayward Guardian Chests",
                ["oldestTime"] = 1632891741,
                ["wasAltered"] = true,
                ["newestTime"] = 1632891741,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 90000,
                        ["guild"] = 1,
                        ["buyer"] = 2416,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1632891741,
                        ["quant"] = 1,
                        ["id"] = "1689506053",
                        ["itemLink"] = 3542,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [27049] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_lemons.dds",
                ["itemDesc"] = "Lemon",
                ["oldestTime"] = 1633305855,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305855,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633305855,
                        ["quant"] = 200,
                        ["id"] = "1692798987",
                        ["itemLink"] = 2942,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [167338] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_inc_game001.dds",
                ["itemDesc"] = "Solitude Game, Blood-on-the-Snow",
                ["oldestTime"] = 1632878754,
                ["wasAltered"] = true,
                ["newestTime"] = 1633115123,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 1018,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633115123,
                        ["quant"] = 1,
                        ["id"] = "1691072927",
                        ["itemLink"] = 1392,
                    },
                    [2] = 
                    {
                        ["price"] = 24999,
                        ["guild"] = 1,
                        ["buyer"] = 2343,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632878754,
                        ["quant"] = 1,
                        ["id"] = "1689380557",
                        ["itemLink"] = 1392,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary furnishings parlor",
            },
        },
        [167595] = 
        {
            ["50:16:2:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Voidcaller",
                ["oldestTime"] = 1632875556,
                ["wasAltered"] = true,
                ["newestTime"] = 1632875811,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2325,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632875556,
                        ["quant"] = 1,
                        ["id"] = "1689347411",
                        ["itemLink"] = 3418,
                    },
                    [2] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2325,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632875811,
                        ["quant"] = 1,
                        ["id"] = "1689350215",
                        ["itemLink"] = 3418,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set voidcaller ring arcane",
            },
        },
        [180652] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_staff_a.dds",
                ["itemDesc"] = "Plaguebreak Lightning Staff",
                ["oldestTime"] = 1633235663,
                ["wasAltered"] = true,
                ["newestTime"] = 1633235663,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1731,
                        ["wasKiosk"] = true,
                        ["seller"] = 42,
                        ["timestamp"] = 1633235663,
                        ["quant"] = 1,
                        ["id"] = "1692165495",
                        ["itemLink"] = 2484,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set plaguebreak lightning staff two-handed precise",
            },
        },
        [159440] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_inc_gong001.dds",
                ["itemDesc"] = "Elsweyr Gong, Ornate",
                ["oldestTime"] = 1633165928,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165928,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633165928,
                        ["quant"] = 1,
                        ["id"] = "1691500089",
                        ["itemLink"] = 1850,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings parlor",
            },
        },
        [117811] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_inc_varhourglass001.dds",
                ["itemDesc"] = "Redguard Hourglass of Desert Sands",
                ["oldestTime"] = 1632883699,
                ["wasAltered"] = true,
                ["newestTime"] = 1632883699,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9164,
                        ["guild"] = 1,
                        ["buyer"] = 299,
                        ["wasKiosk"] = false,
                        ["seller"] = 236,
                        ["timestamp"] = 1632883699,
                        ["quant"] = 1,
                        ["id"] = "1689435601",
                        ["itemLink"] = 3488,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings parlor",
            },
        },
        [118191] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bre_con_cratetomatoes001.dds",
                ["itemDesc"] = "Basket of Tomatoes",
                ["oldestTime"] = 1633103457,
                ["wasAltered"] = true,
                ["newestTime"] = 1633103457,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 960,
                        ["wasKiosk"] = true,
                        ["seller"] = 17,
                        ["timestamp"] = 1633103457,
                        ["quant"] = 1,
                        ["id"] = "1690987373",
                        ["itemLink"] = 1292,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings hearth",
            },
        },
        [171922] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 102: Sul-Xan Maces",
                ["oldestTime"] = 1633292548,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292548,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 95000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633292548,
                        ["quant"] = 1,
                        ["id"] = "1692658159",
                        ["itemLink"] = 2840,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [69912] = 
        {
            ["50:15:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_light_legs_a.dds",
                ["itemDesc"] = "Breeches of Julianos",
                ["oldestTime"] = 1632877462,
                ["wasAltered"] = true,
                ["newestTime"] = 1632877462,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 2336,
                        ["wasKiosk"] = true,
                        ["seller"] = 2123,
                        ["timestamp"] = 1632877462,
                        ["quant"] = 1,
                        ["id"] = "1689366495",
                        ["itemLink"] = 3433,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 purple epic light apparel set law of julianos legs divines",
            },
        },
        [151991] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_jewelry_3.dds",
                ["itemDesc"] = "Sketch: Elsweyr Gravy Boat, Gilded",
                ["oldestTime"] = 1632869880,
                ["wasAltered"] = true,
                ["newestTime"] = 1632869880,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 2284,
                        ["wasKiosk"] = true,
                        ["seller"] = 729,
                        ["timestamp"] = 1632869880,
                        ["quant"] = 1,
                        ["id"] = "1689302443",
                        ["itemLink"] = 3381,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [160947] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_grayhost_2hhammer_a.dds",
                ["itemDesc"] = "Venomous Maul",
                ["oldestTime"] = 1632865600,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865600,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 2266,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1632865600,
                        ["quant"] = 1,
                        ["id"] = "1689269379",
                        ["itemLink"] = 3358,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set venomous smite mace two-handed decisive",
            },
        },
        [45196] = 
        {
            ["50:16:2:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_2haxe_d.dds",
                ["itemDesc"] = "Rubedite Battle Axe of Shock",
                ["oldestTime"] = 1632856319,
                ["wasAltered"] = true,
                ["newestTime"] = 1632856319,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632856319,
                        ["quant"] = 1,
                        ["id"] = "1689200595",
                        ["itemLink"] = 3271,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon axe two-handed training",
            },
        },
        [135144] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_electrum_refined.dds",
                ["itemDesc"] = "Electrum Ounce",
                ["oldestTime"] = 1632851934,
                ["wasAltered"] = true,
                ["newestTime"] = 1632851934,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 2220,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1632851934,
                        ["quant"] = 20,
                        ["id"] = "1689157945",
                        ["itemLink"] = 3245,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [43702] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Bal Foyen Treasure Map II",
                ["oldestTime"] = 1633182517,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182517,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 379,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182517,
                        ["quant"] = 1,
                        ["id"] = "1691608191",
                        ["itemLink"] = 1955,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [137655] = 
        {
            ["50:16:2:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Hunding's Rage",
                ["oldestTime"] = 1632962401,
                ["wasAltered"] = true,
                ["newestTime"] = 1633058608,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15999,
                        ["guild"] = 1,
                        ["buyer"] = 777,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633058608,
                        ["quant"] = 1,
                        ["id"] = "1690696119",
                        ["itemLink"] = 990,
                    },
                    [2] = 
                    {
                        ["price"] = 15999,
                        ["guild"] = 1,
                        ["buyer"] = 2372,
                        ["wasKiosk"] = false,
                        ["seller"] = 778,
                        ["timestamp"] = 1632962401,
                        ["quant"] = 1,
                        ["id"] = "1689978825",
                        ["itemLink"] = 990,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set hunding's rage ring robust",
            },
        },
        [180437] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_staff_a.dds",
                ["itemDesc"] = "Inferno Staff of Dark Convergence",
                ["oldestTime"] = 1632846460,
                ["wasAltered"] = true,
                ["newestTime"] = 1632846460,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 106000,
                        ["guild"] = 1,
                        ["buyer"] = 2200,
                        ["wasKiosk"] = true,
                        ["seller"] = 968,
                        ["timestamp"] = 1632846460,
                        ["quant"] = 1,
                        ["id"] = "1689114211",
                        ["itemLink"] = 3198,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set dark convergence flame staff two-handed infused",
            },
        },
        [57017] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Greef",
                ["oldestTime"] = 1633011826,
                ["wasAltered"] = true,
                ["newestTime"] = 1633011826,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633011826,
                        ["quant"] = 1,
                        ["id"] = "1690302887",
                        ["itemLink"] = 525,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [175996] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting2.dds",
                ["itemDesc"] = "Praxis: Leyawiin Pot, Domed",
                ["oldestTime"] = 1632843077,
                ["wasAltered"] = true,
                ["newestTime"] = 1632843077,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 1361,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1632843077,
                        ["quant"] = 1,
                        ["id"] = "1689084743",
                        ["itemLink"] = 3165,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [116155] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Nord Bed, Single",
                ["oldestTime"] = 1633158037,
                ["wasAltered"] = true,
                ["newestTime"] = 1633158037,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25,
                        ["guild"] = 1,
                        ["buyer"] = 1293,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633158037,
                        ["quant"] = 1,
                        ["id"] = "1691454449",
                        ["itemLink"] = 1776,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [71724] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 27: Ebonheart Pact Bows",
                ["oldestTime"] = 1632839222,
                ["wasAltered"] = true,
                ["newestTime"] = 1632839222,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4800,
                        ["guild"] = 1,
                        ["buyer"] = 2168,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1632839222,
                        ["quant"] = 1,
                        ["id"] = "1689055861",
                        ["itemLink"] = 3129,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [147596] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_vrd_lsb_hlaoillampalwayson001.dds",
                ["itemDesc"] = "Hlaalu Salt Lamp, Enchanted",
                ["oldestTime"] = 1633311151,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311151,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 2092,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633311151,
                        ["quant"] = 1,
                        ["id"] = "1692861897",
                        ["itemLink"] = 3001,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings lighting",
            },
        },
        [173246] = 
        {
            ["50:16:3:31:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Diamond's Victory",
                ["oldestTime"] = 1632984946,
                ["wasAltered"] = true,
                ["newestTime"] = 1633315721,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 51999,
                        ["guild"] = 1,
                        ["buyer"] = 102,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633315721,
                        ["quant"] = 1,
                        ["id"] = "1692912411",
                        ["itemLink"] = 74,
                    },
                    [2] = 
                    {
                        ["price"] = 54999,
                        ["guild"] = 1,
                        ["buyer"] = 313,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632984946,
                        ["quant"] = 1,
                        ["id"] = "1690159755",
                        ["itemLink"] = 74,
                    },
                    [3] = 
                    {
                        ["price"] = 54999,
                        ["guild"] = 1,
                        ["buyer"] = 313,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632985368,
                        ["quant"] = 1,
                        ["id"] = "1690161575",
                        ["itemLink"] = 74,
                    },
                    [4] = 
                    {
                        ["price"] = 54999,
                        ["guild"] = 1,
                        ["buyer"] = 459,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633013026,
                        ["quant"] = 1,
                        ["id"] = "1690309865",
                        ["itemLink"] = 74,
                    },
                    [5] = 
                    {
                        ["price"] = 54999,
                        ["guild"] = 1,
                        ["buyer"] = 459,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633013028,
                        ["quant"] = 1,
                        ["id"] = "1690309881",
                        ["itemLink"] = 74,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set diamond's victory ring bloodthirsty",
            },
        },
        [64703] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/notes_004.dds",
                ["itemDesc"] = "Recipe: Psijic Ambrosia, Fragment I",
                ["oldestTime"] = 1632714161,
                ["wasAltered"] = true,
                ["newestTime"] = 1633295803,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 2,
                        ["buyer"] = 129,
                        ["wasKiosk"] = false,
                        ["seller"] = 117,
                        ["timestamp"] = 1632714161,
                        ["quant"] = 1,
                        ["id"] = "1688086403",
                        ["itemLink"] = 111,
                    },
                    [2] = 
                    {
                        ["price"] = 280,
                        ["guild"] = 1,
                        ["buyer"] = 739,
                        ["wasKiosk"] = false,
                        ["seller"] = 149,
                        ["timestamp"] = 1633103127,
                        ["quant"] = 1,
                        ["id"] = "1690985125",
                        ["itemLink"] = 111,
                    },
                    [3] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 285,
                        ["wasKiosk"] = false,
                        ["seller"] = 737,
                        ["timestamp"] = 1633220844,
                        ["quant"] = 1,
                        ["id"] = "1692020473",
                        ["itemLink"] = 111,
                    },
                    [4] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2020,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1633295803,
                        ["quant"] = 1,
                        ["id"] = "1692698453",
                        ["itemLink"] = 111,
                    },
                    [5] = 
                    {
                        ["price"] = 410,
                        ["guild"] = 1,
                        ["buyer"] = 7,
                        ["wasKiosk"] = false,
                        ["seller"] = 649,
                        ["timestamp"] = 1632853410,
                        ["quant"] = 1,
                        ["id"] = "1689170553",
                        ["itemLink"] = 111,
                    },
                    [6] = 
                    {
                        ["price"] = 410,
                        ["guild"] = 1,
                        ["buyer"] = 2390,
                        ["wasKiosk"] = true,
                        ["seller"] = 649,
                        ["timestamp"] = 1632885346,
                        ["quant"] = 1,
                        ["id"] = "1689456541",
                        ["itemLink"] = 111,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [152138] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: The Maelstrom's Staff",
                ["oldestTime"] = 1633311062,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311062,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 1622,
                        ["timestamp"] = 1633311062,
                        ["quant"] = 1,
                        ["id"] = "1692860969",
                        ["itemLink"] = 3000,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [72897] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_light_shirt_a.dds",
                ["itemDesc"] = "Jerkin of Bahraha's Curse",
                ["oldestTime"] = 1632714218,
                ["wasAltered"] = true,
                ["newestTime"] = 1632714218,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 2,
                        ["buyer"] = 129,
                        ["wasKiosk"] = false,
                        ["seller"] = 111,
                        ["timestamp"] = 1632714218,
                        ["quant"] = 1,
                        ["id"] = "1688086727",
                        ["itemLink"] = 115,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set bahraha's curse chest divines",
            },
        },
        [55490] = 
        {
            ["50:14:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_staff_d.dds",
                ["itemDesc"] = "Nightwood Inferno Staff of Frost",
                ["oldestTime"] = 1633018983,
                ["wasAltered"] = true,
                ["newestTime"] = 1633018983,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 500,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633018983,
                        ["quant"] = 1,
                        ["id"] = "1690358043",
                        ["itemLink"] = 573,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp140 green fine weapon flame staff two-handed",
            },
        },
        [170209] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Doctrine Ordinator Jack",
                ["oldestTime"] = 1633309438,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309438,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 2083,
                        ["wasKiosk"] = true,
                        ["seller"] = 624,
                        ["timestamp"] = 1633309438,
                        ["quant"] = 1,
                        ["id"] = "1692842717",
                        ["itemLink"] = 2967,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [45680] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Pumpkin Corn Fritters",
                ["oldestTime"] = 1632875156,
                ["wasAltered"] = true,
                ["newestTime"] = 1633306733,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633306733,
                        ["quant"] = 1,
                        ["id"] = "1692806931",
                        ["itemLink"] = 2947,
                    },
                    [2] = 
                    {
                        ["price"] = 99,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1632875156,
                        ["quant"] = 1,
                        ["id"] = "1689342873",
                        ["itemLink"] = 2947,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [115397] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_nor_duc_chest006.dds",
                ["itemDesc"] = "Nord Chest, Latched",
                ["oldestTime"] = 1633165882,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165882,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633165882,
                        ["quant"] = 1,
                        ["id"] = "1691499835",
                        ["itemLink"] = 1847,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings suite",
            },
        },
        [132550] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_cwc_inc_scrollplate001.dds",
                ["itemDesc"] = "Crafting Motif 56: Apostle Axes",
                ["oldestTime"] = 1633051355,
                ["wasAltered"] = true,
                ["newestTime"] = 1633236797,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 703,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633051355,
                        ["quant"] = 1,
                        ["id"] = "1690619319",
                        ["itemLink"] = 893,
                    },
                    [2] = 
                    {
                        ["price"] = 6800,
                        ["guild"] = 1,
                        ["buyer"] = 1687,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633230263,
                        ["quant"] = 1,
                        ["id"] = "1692117429",
                        ["itemLink"] = 893,
                    },
                    [3] = 
                    {
                        ["price"] = 6800,
                        ["guild"] = 1,
                        ["buyer"] = 1739,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633236797,
                        ["quant"] = 1,
                        ["id"] = "1692174293",
                        ["itemLink"] = 893,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [126919] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Hlaalu Table, Formal Turtle",
                ["oldestTime"] = 1633020623,
                ["wasAltered"] = true,
                ["newestTime"] = 1633020623,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 64000,
                        ["guild"] = 1,
                        ["buyer"] = 507,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633020623,
                        ["quant"] = 1,
                        ["id"] = "1690369783",
                        ["itemLink"] = 579,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [96968] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/event_newlifefestival_2016_recipe.dds",
                ["itemDesc"] = "Recipe: Hissmir Fish-Eye Rye",
                ["oldestTime"] = 1633052934,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261649,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1633052934,
                        ["quant"] = 1,
                        ["id"] = "1690634937",
                        ["itemLink"] = 926,
                    },
                    [2] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 1585,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1633215434,
                        ["quant"] = 1,
                        ["id"] = "1691962089",
                        ["itemLink"] = 926,
                    },
                    [3] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1633261649,
                        ["quant"] = 1,
                        ["id"] = "1692334691",
                        ["itemLink"] = 926,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 gold legendary consumable recipe",
            },
        },
        [34334] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_veg_003.dds",
                ["itemDesc"] = "Bittergreen",
                ["oldestTime"] = 1633305851,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305852,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633305851,
                        ["quant"] = 200,
                        ["id"] = "1692798945",
                        ["itemLink"] = 2939,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633305852,
                        ["quant"] = 50,
                        ["id"] = "1692798951",
                        ["itemLink"] = 2939,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [118986] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: High Elf Bench, Curved",
                ["oldestTime"] = 1632905676,
                ["wasAltered"] = true,
                ["newestTime"] = 1632905676,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 105,
                        ["guild"] = 1,
                        ["buyer"] = 2452,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1632905676,
                        ["quant"] = 1,
                        ["id"] = "1689584611",
                        ["itemLink"] = 3584,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [116389] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_orc_fur_wtgbedsingle001.dds",
                ["itemDesc"] = "Orcish Bedding, Peaked",
                ["oldestTime"] = 1633295283,
                ["wasAltered"] = true,
                ["newestTime"] = 1633295283,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11500,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633295283,
                        ["quant"] = 1,
                        ["id"] = "1692693107",
                        ["itemLink"] = 2879,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings suite",
            },
        },
        [43603] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Stormhaven Treasure Map III",
                ["oldestTime"] = 1633294848,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294848,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 175,
                        ["wasKiosk"] = false,
                        ["seller"] = 202,
                        ["timestamp"] = 1633294848,
                        ["quant"] = 1,
                        ["id"] = "1692688941",
                        ["itemLink"] = 2876,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [140488] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 66: Silver Dawn Maces",
                ["oldestTime"] = 1633293509,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293509,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633293509,
                        ["quant"] = 1,
                        ["id"] = "1692669381",
                        ["itemLink"] = 2854,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [118222] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bre_inc_painting_elegant007.dds",
                ["itemDesc"] = "Painting of Jungle, Sturdy",
                ["oldestTime"] = 1632883011,
                ["wasAltered"] = true,
                ["newestTime"] = 1632883011,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 552,
                        ["guild"] = 1,
                        ["buyer"] = 2371,
                        ["wasKiosk"] = true,
                        ["seller"] = 492,
                        ["timestamp"] = 1632883011,
                        ["quant"] = 1,
                        ["id"] = "1689427875",
                        ["itemLink"] = 3483,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings gallery",
            },
        },
        [135297] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nocturnal_heavy_chest_a.dds",
                ["itemDesc"] = "Gloom-Graced Cuirass",
                ["oldestTime"] = 1633095082,
                ["wasAltered"] = true,
                ["newestTime"] = 1633095082,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 925,
                        ["wasKiosk"] = true,
                        ["seller"] = 51,
                        ["timestamp"] = 1633095082,
                        ["quant"] = 1,
                        ["id"] = "1690919571",
                        ["itemLink"] = 1260,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set grace of gloom chest sturdy",
            },
        },
        [77520] = 
        {
            ["50:16:2:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Sithis' Ring",
                ["oldestTime"] = 1633131777,
                ["wasAltered"] = true,
                ["newestTime"] = 1633131777,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1115,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633131777,
                        ["quant"] = 1,
                        ["id"] = "1691206689",
                        ["itemLink"] = 1535,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set sithis' touch ring healthy",
            },
        },
        [180689] = 
        {
            ["50:16:3:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_bow_a.dds",
                ["itemDesc"] = "Plaguebreak Bow",
                ["oldestTime"] = 1632962775,
                ["wasAltered"] = true,
                ["newestTime"] = 1632962775,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1067,
                        ["wasKiosk"] = true,
                        ["seller"] = 100,
                        ["timestamp"] = 1632962775,
                        ["quant"] = 1,
                        ["id"] = "1689983077",
                        ["itemLink"] = 3936,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set plaguebreak bow two-handed sharpened",
            },
        },
        [118994] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: High Elf Table, Sturdy Kitchen",
                ["oldestTime"] = 1633140919,
                ["wasAltered"] = true,
                ["newestTime"] = 1633140919,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633140919,
                        ["quant"] = 1,
                        ["id"] = "1691300579",
                        ["itemLink"] = 1602,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [180729] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_bow_a.dds",
                ["itemDesc"] = "Plaguebreak Bow",
                ["oldestTime"] = 1633290755,
                ["wasAltered"] = true,
                ["newestTime"] = 1633290755,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1983,
                        ["wasKiosk"] = true,
                        ["seller"] = 42,
                        ["timestamp"] = 1633290755,
                        ["quant"] = 1,
                        ["id"] = "1692636149",
                        ["itemLink"] = 2785,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set plaguebreak bow two-handed decisive",
            },
        },
        [77524] = 
        {
            ["50:16:2:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Sithis' Ring",
                ["oldestTime"] = 1633117496,
                ["wasAltered"] = true,
                ["newestTime"] = 1633117496,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 225,
                        ["guild"] = 1,
                        ["buyer"] = 451,
                        ["wasKiosk"] = false,
                        ["seller"] = 257,
                        ["timestamp"] = 1633117496,
                        ["quant"] = 1,
                        ["id"] = "1691088267",
                        ["itemLink"] = 1417,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set sithis' touch ring arcane",
            },
        },
        [30165] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_water_plant_nirnroot_r1.dds",
                ["itemDesc"] = "Nirnroot",
                ["oldestTime"] = 1632964560,
                ["wasAltered"] = true,
                ["newestTime"] = 1633252101,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3350,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 299,
                        ["timestamp"] = 1632987747,
                        ["quant"] = 30,
                        ["id"] = "1690172953",
                        ["itemLink"] = 339,
                    },
                    [2] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 1722,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633234505,
                        ["quant"] = 200,
                        ["id"] = "1692157725",
                        ["itemLink"] = 339,
                    },
                    [3] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633252101,
                        ["quant"] = 11,
                        ["id"] = "1692286485",
                        ["itemLink"] = 339,
                    },
                    [4] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 436,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632964560,
                        ["quant"] = 20,
                        ["id"] = "1690001017",
                        ["itemLink"] = 339,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [30166] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_water_plant_water_hyacinth_r1.dds",
                ["itemDesc"] = "Water Hyacinth",
                ["oldestTime"] = 1632825588,
                ["wasAltered"] = true,
                ["newestTime"] = 1633306376,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 23500,
                        ["guild"] = 1,
                        ["buyer"] = 549,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1633035193,
                        ["quant"] = 90,
                        ["id"] = "1690477423",
                        ["itemLink"] = 760,
                    },
                    [2] = 
                    {
                        ["price"] = 54200,
                        ["guild"] = 1,
                        ["buyer"] = 1048,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633120255,
                        ["quant"] = 200,
                        ["id"] = "1691106603",
                        ["itemLink"] = 760,
                    },
                    [3] = 
                    {
                        ["price"] = 54400,
                        ["guild"] = 1,
                        ["buyer"] = 1661,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633227467,
                        ["quant"] = 200,
                        ["id"] = "1692089867",
                        ["itemLink"] = 760,
                    },
                    [4] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1721,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633234259,
                        ["quant"] = 6,
                        ["id"] = "1692155733",
                        ["itemLink"] = 760,
                    },
                    [5] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 549,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633239323,
                        ["quant"] = 100,
                        ["id"] = "1692193349",
                        ["itemLink"] = 760,
                    },
                    [6] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1800,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633246129,
                        ["quant"] = 200,
                        ["id"] = "1692243793",
                        ["itemLink"] = 760,
                    },
                    [7] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 900,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633257676,
                        ["quant"] = 200,
                        ["id"] = "1692315681",
                        ["itemLink"] = 760,
                    },
                    [8] = 
                    {
                        ["price"] = 12528,
                        ["guild"] = 1,
                        ["buyer"] = 2070,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633306336,
                        ["quant"] = 50,
                        ["id"] = "1692802489",
                        ["itemLink"] = 760,
                    },
                    [9] = 
                    {
                        ["price"] = 26500,
                        ["guild"] = 1,
                        ["buyer"] = 2070,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633306376,
                        ["quant"] = 100,
                        ["id"] = "1692802751",
                        ["itemLink"] = 760,
                    },
                    [10] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 1252,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1632825588,
                        ["quant"] = 100,
                        ["id"] = "1688966841",
                        ["itemLink"] = 760,
                    },
                    [11] = 
                    {
                        ["price"] = 25999,
                        ["guild"] = 1,
                        ["buyer"] = 1252,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1632825589,
                        ["quant"] = 100,
                        ["id"] = "1688966849",
                        ["itemLink"] = 760,
                    },
                    [12] = 
                    {
                        ["price"] = 8126,
                        ["guild"] = 1,
                        ["buyer"] = 1252,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632825590,
                        ["quant"] = 34,
                        ["id"] = "1688966855",
                        ["itemLink"] = 760,
                    },
                    [13] = 
                    {
                        ["price"] = 47545,
                        ["guild"] = 1,
                        ["buyer"] = 436,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632880292,
                        ["quant"] = 200,
                        ["id"] = "1689400157",
                        ["itemLink"] = 760,
                    },
                },
                ["totalCount"] = 13,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [119693] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_provisioning.dds",
                ["itemDesc"] = "Sealed Provisioning Writ",
                ["oldestTime"] = 1632910816,
                ["wasAltered"] = true,
                ["newestTime"] = 1633296899,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633105324,
                        ["quant"] = 1,
                        ["id"] = "1691004409",
                        ["itemLink"] = 1295,
                    },
                    [2] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1065,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633122700,
                        ["quant"] = 1,
                        ["id"] = "1691125183",
                        ["itemLink"] = 1448,
                    },
                    [3] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 1257,
                        ["wasKiosk"] = true,
                        ["seller"] = 374,
                        ["timestamp"] = 1633150089,
                        ["quant"] = 1,
                        ["id"] = "1691391891",
                        ["itemLink"] = 1718,
                    },
                    [4] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 1257,
                        ["wasKiosk"] = true,
                        ["seller"] = 374,
                        ["timestamp"] = 1633150090,
                        ["quant"] = 1,
                        ["id"] = "1691391903",
                        ["itemLink"] = 1719,
                    },
                    [5] = 
                    {
                        ["price"] = 4084,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633198630,
                        ["quant"] = 1,
                        ["id"] = "1691775665",
                        ["itemLink"] = 1448,
                    },
                    [6] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633198642,
                        ["quant"] = 1,
                        ["id"] = "1691775745",
                        ["itemLink"] = 2169,
                    },
                    [7] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633198645,
                        ["quant"] = 1,
                        ["id"] = "1691775795",
                        ["itemLink"] = 1448,
                    },
                    [8] = 
                    {
                        ["price"] = 6130,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633198693,
                        ["quant"] = 1,
                        ["id"] = "1691776293",
                        ["itemLink"] = 2171,
                    },
                    [9] = 
                    {
                        ["price"] = 2300,
                        ["guild"] = 1,
                        ["buyer"] = 1065,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1633228933,
                        ["quant"] = 1,
                        ["id"] = "1692106325",
                        ["itemLink"] = 2427,
                    },
                    [10] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2024,
                        ["wasKiosk"] = true,
                        ["seller"] = 47,
                        ["timestamp"] = 1633296880,
                        ["quant"] = 1,
                        ["id"] = "1692709491",
                        ["itemLink"] = 1718,
                    },
                    [11] = 
                    {
                        ["price"] = 5702,
                        ["guild"] = 1,
                        ["buyer"] = 2024,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633296888,
                        ["quant"] = 1,
                        ["id"] = "1692709541",
                        ["itemLink"] = 1718,
                    },
                    [12] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2024,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633296898,
                        ["quant"] = 1,
                        ["id"] = "1692709649",
                        ["itemLink"] = 1719,
                    },
                    [13] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 2024,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633296899,
                        ["quant"] = 1,
                        ["id"] = "1692709665",
                        ["itemLink"] = 1719,
                    },
                    [14] = 
                    {
                        ["price"] = 4988,
                        ["guild"] = 1,
                        ["buyer"] = 2461,
                        ["wasKiosk"] = true,
                        ["seller"] = 600,
                        ["timestamp"] = 1632910816,
                        ["quant"] = 1,
                        ["id"] = "1689603769",
                        ["itemLink"] = 3605,
                    },
                },
                ["totalCount"] = 14,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [43736] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Gold Coast Treasure Map II",
                ["oldestTime"] = 1633149337,
                ["wasAltered"] = true,
                ["newestTime"] = 1633149337,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 485,
                        ["guild"] = 1,
                        ["buyer"] = 1250,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1633149337,
                        ["quant"] = 1,
                        ["id"] = "1691385149",
                        ["itemLink"] = 1701,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [43737] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Vvardenfell Treasure Map I",
                ["oldestTime"] = 1633169194,
                ["wasAltered"] = true,
                ["newestTime"] = 1633169194,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 359,
                        ["guild"] = 1,
                        ["buyer"] = 1333,
                        ["wasKiosk"] = true,
                        ["seller"] = 164,
                        ["timestamp"] = 1633169194,
                        ["quant"] = 1,
                        ["id"] = "1691515323",
                        ["itemLink"] = 1879,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [175630] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_fur_chest001.dds",
                ["itemDesc"] = "Leyawiin Trunk, Ornate",
                ["oldestTime"] = 1633040094,
                ["wasAltered"] = true,
                ["newestTime"] = 1633040094,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 621,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633040094,
                        ["quant"] = 1,
                        ["id"] = "1690513723",
                        ["itemLink"] = 789,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings suite",
            },
        },
        [46043] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Sweetberry Tonic",
                ["oldestTime"] = 1632966602,
                ["wasAltered"] = true,
                ["newestTime"] = 1632966602,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20,
                        ["guild"] = 1,
                        ["buyer"] = 2664,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1632966602,
                        ["quant"] = 1,
                        ["id"] = "1690020329",
                        ["itemLink"] = 3972,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [149468] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_medium_hands_a.dds",
                ["itemDesc"] = "Darloc Brae's Bracers",
                ["oldestTime"] = 1633061493,
                ["wasAltered"] = true,
                ["newestTime"] = 1633061493,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 49999,
                        ["guild"] = 1,
                        ["buyer"] = 794,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1633061493,
                        ["quant"] = 1,
                        ["id"] = "1690721485",
                        ["itemLink"] = 1027,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set vesture of darloc brae hands divines",
            },
        },
        [125474] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_researchscroll_clothier.dds",
                ["itemDesc"] = "Research Scroll, Clothing, 1 Day",
                ["oldestTime"] = 1632861970,
                ["wasAltered"] = true,
                ["newestTime"] = 1633304183,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 1891,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633273351,
                        ["quant"] = 2,
                        ["id"] = "1692441417",
                        ["itemLink"] = 2686,
                    },
                    [2] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 1121,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633275941,
                        ["quant"] = 2,
                        ["id"] = "1692475361",
                        ["itemLink"] = 2686,
                    },
                    [3] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 2054,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633304183,
                        ["quant"] = 2,
                        ["id"] = "1692781341",
                        ["itemLink"] = 2686,
                    },
                    [4] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 658,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632861970,
                        ["quant"] = 2,
                        ["id"] = "1689244201",
                        ["itemLink"] = 2686,
                    },
                    [5] = 
                    {
                        ["price"] = 36500,
                        ["guild"] = 1,
                        ["buyer"] = 2476,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1632915889,
                        ["quant"] = 10,
                        ["id"] = "1689629413",
                        ["itemLink"] = 2686,
                    },
                    [6] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 2054,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632921758,
                        ["quant"] = 2,
                        ["id"] = "1689663097",
                        ["itemLink"] = 2686,
                    },
                    [7] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 2529,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632936808,
                        ["quant"] = 2,
                        ["id"] = "1689773939",
                        ["itemLink"] = 2686,
                    },
                    [8] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 2529,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632936809,
                        ["quant"] = 2,
                        ["id"] = "1689773943",
                        ["itemLink"] = 2686,
                    },
                    [9] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 745,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632948868,
                        ["quant"] = 2,
                        ["id"] = "1689864483",
                        ["itemLink"] = 2686,
                    },
                    [10] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 2674,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632968747,
                        ["quant"] = 2,
                        ["id"] = "1690043759",
                        ["itemLink"] = 2686,
                    },
                    [11] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 2674,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632968749,
                        ["quant"] = 2,
                        ["id"] = "1690043793",
                        ["itemLink"] = 2686,
                    },
                },
                ["totalCount"] = 11,
                ["itemAdderText"] = "rr01 gold legendary consumable trophy",
            },
        },
        [137921] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 62: Sapiarch Axes",
                ["oldestTime"] = 1633246392,
                ["wasAltered"] = true,
                ["newestTime"] = 1633246392,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6999,
                        ["guild"] = 1,
                        ["buyer"] = 1463,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633246392,
                        ["quant"] = 1,
                        ["id"] = "1692244907",
                        ["itemLink"] = 2579,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [180563] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_staff_a.dds",
                ["itemDesc"] = "Inferno Staff of Dark Convergence",
                ["oldestTime"] = 1633067570,
                ["wasAltered"] = true,
                ["newestTime"] = 1633067570,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 831,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633067570,
                        ["quant"] = 1,
                        ["id"] = "1690764939",
                        ["itemLink"] = 1074,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set dark convergence flame staff two-handed decisive",
            },
        },
        [156609] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 81: New Moon Priest Axes",
                ["oldestTime"] = 1633240495,
                ["wasAltered"] = true,
                ["newestTime"] = 1633240495,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 355,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633240495,
                        ["quant"] = 1,
                        ["id"] = "1692201647",
                        ["itemLink"] = 2536,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [119265] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Redguard Mat, Desert",
                ["oldestTime"] = 1633227747,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227747,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 521,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633227747,
                        ["quant"] = 1,
                        ["id"] = "1692093331",
                        ["itemLink"] = 2412,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [130018] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 52: Redoran Helmets",
                ["oldestTime"] = 1633209867,
                ["wasAltered"] = true,
                ["newestTime"] = 1633209867,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14999,
                        ["guild"] = 1,
                        ["buyer"] = 421,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633209867,
                        ["quant"] = 1,
                        ["id"] = "1691903637",
                        ["itemLink"] = 2272,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [166042] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Western Skyrim Treasure Map III",
                ["oldestTime"] = 1633116009,
                ["wasAltered"] = true,
                ["newestTime"] = 1633173226,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 1024,
                        ["wasKiosk"] = true,
                        ["seller"] = 763,
                        ["timestamp"] = 1633116009,
                        ["quant"] = 1,
                        ["id"] = "1691078869",
                        ["itemLink"] = 1409,
                    },
                    [2] = 
                    {
                        ["price"] = 9999,
                        ["guild"] = 1,
                        ["buyer"] = 1347,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1633173226,
                        ["quant"] = 1,
                        ["id"] = "1691536629",
                        ["itemLink"] = 1409,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [180438] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_staff_a.dds",
                ["itemDesc"] = "Ice Staff of Dark Convergence",
                ["oldestTime"] = 1633236189,
                ["wasAltered"] = true,
                ["newestTime"] = 1633236189,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 74999,
                        ["guild"] = 1,
                        ["buyer"] = 1736,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633236189,
                        ["quant"] = 1,
                        ["id"] = "1692168983",
                        ["itemLink"] = 2496,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set dark convergence frost staff two-handed infused",
            },
        },
        [142309] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_elderarg_staff_a.dds",
                ["itemDesc"] = "Champion of the Hist Restoration Staff",
                ["oldestTime"] = 1633114491,
                ["wasAltered"] = true,
                ["newestTime"] = 1633114491,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 799,
                        ["guild"] = 1,
                        ["buyer"] = 1013,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633114491,
                        ["quant"] = 1,
                        ["id"] = "1691069361",
                        ["itemLink"] = 1377,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set champion of the hist healing staff two-handed defending",
            },
        },
        [57574] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 15: Dwemer Belts",
                ["oldestTime"] = 1632870377,
                ["wasAltered"] = true,
                ["newestTime"] = 1632870377,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 2,
                        ["buyer"] = 114,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1632870377,
                        ["quant"] = 1,
                        ["id"] = "1689305793",
                        ["itemLink"] = 141,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [97255] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_hands_d.dds",
                ["itemDesc"] = "Gloves of a Mother's Sorrow",
                ["oldestTime"] = 1633140466,
                ["wasAltered"] = true,
                ["newestTime"] = 1633290824,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22111,
                        ["guild"] = 1,
                        ["buyer"] = 1184,
                        ["wasKiosk"] = true,
                        ["seller"] = 48,
                        ["timestamp"] = 1633140466,
                        ["quant"] = 1,
                        ["id"] = "1691295551",
                        ["itemLink"] = 1599,
                    },
                    [2] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 1984,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633290824,
                        ["quant"] = 1,
                        ["id"] = "1692636673",
                        ["itemLink"] = 1599,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic light apparel set mother's sorrow hands divines",
            },
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_hands_d.dds",
                ["itemDesc"] = "Gloves of a Mother's Sorrow",
                ["oldestTime"] = 1632926714,
                ["wasAltered"] = true,
                ["newestTime"] = 1632926714,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10500,
                        ["guild"] = 1,
                        ["buyer"] = 2502,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1632926714,
                        ["quant"] = 1,
                        ["id"] = "1689698683",
                        ["itemLink"] = 3688,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set mother's sorrow hands divines",
            },
            ["50:16:5:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_hands_d.dds",
                ["itemDesc"] = "Gloves of a Mother's Sorrow",
                ["oldestTime"] = 1633084111,
                ["wasAltered"] = true,
                ["newestTime"] = 1633084111,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 220000,
                        ["guild"] = 1,
                        ["buyer"] = 883,
                        ["wasKiosk"] = true,
                        ["seller"] = 185,
                        ["timestamp"] = 1633084111,
                        ["quant"] = 1,
                        ["id"] = "1690855085",
                        ["itemLink"] = 1190,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary light apparel set mother's sorrow hands divines",
            },
        },
        [130024] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 52: Redoran Swords",
                ["oldestTime"] = 1633143403,
                ["wasAltered"] = true,
                ["newestTime"] = 1633143403,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11990,
                        ["guild"] = 1,
                        ["buyer"] = 1213,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633143403,
                        ["quant"] = 1,
                        ["id"] = "1691330475",
                        ["itemLink"] = 1634,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [69536] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 21: Ancient Orc Legs",
                ["oldestTime"] = 1632990348,
                ["wasAltered"] = true,
                ["newestTime"] = 1632990348,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 350,
                        ["wasKiosk"] = true,
                        ["seller"] = 351,
                        ["timestamp"] = 1632990348,
                        ["quant"] = 1,
                        ["id"] = "1690188901",
                        ["itemLink"] = 351,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [160561] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 86: Sea Giant Belts",
                ["oldestTime"] = 1633209877,
                ["wasAltered"] = true,
                ["newestTime"] = 1633209877,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 421,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633209877,
                        ["quant"] = 1,
                        ["id"] = "1691903719",
                        ["itemLink"] = 2273,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [115947] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Breton Desk, Knotwork",
                ["oldestTime"] = 1633109401,
                ["wasAltered"] = true,
                ["newestTime"] = 1633109401,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1992,
                        ["guild"] = 1,
                        ["buyer"] = 979,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633109401,
                        ["quant"] = 1,
                        ["id"] = "1691031739",
                        ["itemLink"] = 1315,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [100588] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Spriggan's Necklace",
                ["oldestTime"] = 1632899344,
                ["wasAltered"] = true,
                ["newestTime"] = 1632899344,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3313,
                        ["guild"] = 1,
                        ["buyer"] = 2441,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1632899344,
                        ["quant"] = 1,
                        ["id"] = "1689554151",
                        ["itemLink"] = 3571,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set spriggan's thorns neck robust",
            },
        },
        [149438] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_2hsword_a.dds",
                ["itemDesc"] = "Darloc Brae's Greatsword",
                ["oldestTime"] = 1633153100,
                ["wasAltered"] = true,
                ["newestTime"] = 1633153100,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8843,
                        ["guild"] = 1,
                        ["buyer"] = 1269,
                        ["wasKiosk"] = true,
                        ["seller"] = 547,
                        ["timestamp"] = 1633153100,
                        ["quant"] = 1,
                        ["id"] = "1691416743",
                        ["itemLink"] = 1738,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set vesture of darloc brae sword two-handed infused",
            },
        },
        [166773] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning3.dds",
                ["itemDesc"] = "Design: Vampiric Goblet, Full",
                ["oldestTime"] = 1633109408,
                ["wasAltered"] = true,
                ["newestTime"] = 1633109408,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 979,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1633109408,
                        ["quant"] = 1,
                        ["id"] = "1691031781",
                        ["itemLink"] = 1317,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45231] = 
        {
            ["50:16:2:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_2haxe_d.dds",
                ["itemDesc"] = "Rubedite Battle Axe of Shock",
                ["oldestTime"] = 1633185932,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185932,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633185932,
                        ["quant"] = 1,
                        ["id"] = "1691640001",
                        ["itemLink"] = 2021,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon axe two-handed sharpened",
            },
            ["50:16:1:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_2haxe_d.dds",
                ["itemDesc"] = "Rubedite Battle Axe",
                ["oldestTime"] = 1632950118,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950118,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1632950118,
                        ["quant"] = 1,
                        ["id"] = "1689875081",
                        ["itemLink"] = 3813,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal weapon axe two-handed sharpened",
            },
        },
        [97217] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of a Mother's Sorrow",
                ["oldestTime"] = 1632884559,
                ["wasAltered"] = true,
                ["newestTime"] = 1633017751,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1099,
                        ["guild"] = 1,
                        ["buyer"] = 489,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633017751,
                        ["quant"] = 1,
                        ["id"] = "1690346669",
                        ["itemLink"] = 555,
                    },
                    [2] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 2383,
                        ["wasKiosk"] = true,
                        ["seller"] = 691,
                        ["timestamp"] = 1632884559,
                        ["quant"] = 1,
                        ["id"] = "1689447001",
                        ["itemLink"] = 555,
                    },
                    [3] = 
                    {
                        ["price"] = 2944,
                        ["guild"] = 1,
                        ["buyer"] = 2449,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1632902378,
                        ["quant"] = 1,
                        ["id"] = "1689570721",
                        ["itemLink"] = 555,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set mother's sorrow ring arcane",
            },
            ["50:16:5:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of a Mother's Sorrow",
                ["oldestTime"] = 1633114185,
                ["wasAltered"] = true,
                ["newestTime"] = 1633160724,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 209899,
                        ["guild"] = 1,
                        ["buyer"] = 1009,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1633114185,
                        ["quant"] = 1,
                        ["id"] = "1691067085",
                        ["itemLink"] = 1375,
                    },
                    [2] = 
                    {
                        ["price"] = 155998,
                        ["guild"] = 1,
                        ["buyer"] = 1282,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633155896,
                        ["quant"] = 1,
                        ["id"] = "1691438599",
                        ["itemLink"] = 1375,
                    },
                    [3] = 
                    {
                        ["price"] = 155998,
                        ["guild"] = 1,
                        ["buyer"] = 1282,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633155898,
                        ["quant"] = 1,
                        ["id"] = "1691438607",
                        ["itemLink"] = 1375,
                    },
                    [4] = 
                    {
                        ["price"] = 155998,
                        ["guild"] = 1,
                        ["buyer"] = 1283,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633156206,
                        ["quant"] = 1,
                        ["id"] = "1691440251",
                        ["itemLink"] = 1375,
                    },
                    [5] = 
                    {
                        ["price"] = 155998,
                        ["guild"] = 1,
                        ["buyer"] = 1283,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633156208,
                        ["quant"] = 1,
                        ["id"] = "1691440263",
                        ["itemLink"] = 1375,
                    },
                    [6] = 
                    {
                        ["price"] = 155998,
                        ["guild"] = 1,
                        ["buyer"] = 1307,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633160723,
                        ["quant"] = 1,
                        ["id"] = "1691468899",
                        ["itemLink"] = 1375,
                    },
                    [7] = 
                    {
                        ["price"] = 155998,
                        ["guild"] = 1,
                        ["buyer"] = 1307,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633160724,
                        ["quant"] = 1,
                        ["id"] = "1691468919",
                        ["itemLink"] = 1375,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "cp160 gold legendary jewelry apparel set mother's sorrow ring arcane",
            },
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of a Mother's Sorrow",
                ["oldestTime"] = 1632909953,
                ["wasAltered"] = true,
                ["newestTime"] = 1633229344,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 725,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633053322,
                        ["quant"] = 1,
                        ["id"] = "1690639179",
                        ["itemLink"] = 930,
                    },
                    [2] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1434,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633193224,
                        ["quant"] = 1,
                        ["id"] = "1691726341",
                        ["itemLink"] = 930,
                    },
                    [3] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 1678,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1633229341,
                        ["quant"] = 1,
                        ["id"] = "1692109625",
                        ["itemLink"] = 930,
                    },
                    [4] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 1678,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1633229344,
                        ["quant"] = 1,
                        ["id"] = "1692109651",
                        ["itemLink"] = 930,
                    },
                    [5] = 
                    {
                        ["price"] = 13199,
                        ["guild"] = 1,
                        ["buyer"] = 2460,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632909953,
                        ["quant"] = 1,
                        ["id"] = "1689600867",
                        ["itemLink"] = 930,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set mother's sorrow ring arcane",
            },
            ["50:16:2:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of a Mother's Sorrow",
                ["oldestTime"] = 1633017757,
                ["wasAltered"] = true,
                ["newestTime"] = 1633211059,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 489,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633017757,
                        ["quant"] = 1,
                        ["id"] = "1690346737",
                        ["itemLink"] = 556,
                    },
                    [2] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 1553,
                        ["wasKiosk"] = true,
                        ["seller"] = 597,
                        ["timestamp"] = 1633211059,
                        ["quant"] = 1,
                        ["id"] = "1691916185",
                        ["itemLink"] = 556,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set mother's sorrow ring arcane",
            },
        },
        [180601] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Plaguebreak Amulet",
                ["oldestTime"] = 1633312685,
                ["wasAltered"] = true,
                ["newestTime"] = 1633315800,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13333,
                        ["guild"] = 1,
                        ["buyer"] = 39,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1633312685,
                        ["quant"] = 1,
                        ["id"] = "1692877509",
                        ["itemLink"] = 27,
                    },
                    [2] = 
                    {
                        ["price"] = 13333,
                        ["guild"] = 1,
                        ["buyer"] = 103,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1633315800,
                        ["quant"] = 1,
                        ["id"] = "1692912903",
                        ["itemLink"] = 27,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set plaguebreak neck robust",
            },
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Plaguebreak Amulet",
                ["oldestTime"] = 1633195282,
                ["wasAltered"] = true,
                ["newestTime"] = 1633314709,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 87,
                        ["wasKiosk"] = true,
                        ["seller"] = 47,
                        ["timestamp"] = 1633314709,
                        ["quant"] = 1,
                        ["id"] = "1692898877",
                        ["itemLink"] = 64,
                    },
                    [2] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 803,
                        ["wasKiosk"] = false,
                        ["seller"] = 583,
                        ["timestamp"] = 1633195282,
                        ["quant"] = 1,
                        ["id"] = "1691744843",
                        ["itemLink"] = 2133,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set plaguebreak neck robust",
            },
        },
        [180732] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_staff_a.dds",
                ["itemDesc"] = "Plaguebreak Lightning Staff",
                ["oldestTime"] = 1633181624,
                ["wasAltered"] = true,
                ["newestTime"] = 1633181624,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14444,
                        ["guild"] = 1,
                        ["buyer"] = 1360,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1633181624,
                        ["quant"] = 1,
                        ["id"] = "1691600527",
                        ["itemLink"] = 1931,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set plaguebreak lightning staff two-handed decisive",
            },
        },
        [95987] = 
        {
            ["50:16:4:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_heavy_legs_d.dds",
                ["itemDesc"] = "Greaves of the Trainee",
                ["oldestTime"] = 1632891175,
                ["wasAltered"] = true,
                ["newestTime"] = 1632891175,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2412,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632891175,
                        ["quant"] = 1,
                        ["id"] = "1689501019",
                        ["itemLink"] = 3539,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set armor of the trainee legs training",
            },
        },
        [92404] = 
        {
            ["50:16:4:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_medium_legs_d.dds",
                ["itemDesc"] = "Guards of the Twin Sisters",
                ["oldestTime"] = 1633244692,
                ["wasAltered"] = true,
                ["newestTime"] = 1633244692,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 1791,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633244692,
                        ["quant"] = 1,
                        ["id"] = "1692231461",
                        ["itemLink"] = 2576,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set twin sisters legs sturdy",
            },
        },
        [99705] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_light_feet_d.dds",
                ["itemDesc"] = "Spinner's Shoes",
                ["oldestTime"] = 1633162966,
                ["wasAltered"] = true,
                ["newestTime"] = 1633162966,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3420,
                        ["guild"] = 1,
                        ["buyer"] = 378,
                        ["wasKiosk"] = false,
                        ["seller"] = 1112,
                        ["timestamp"] = 1633162966,
                        ["quant"] = 1,
                        ["id"] = "1691485253",
                        ["itemLink"] = 1793,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set spinner's garments feet well-fitted",
            },
        },
        [68342] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_058.dds",
                ["itemDesc"] = "Hakeijo",
                ["oldestTime"] = 1632852493,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292583,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 39500,
                        ["guild"] = 1,
                        ["buyer"] = 231,
                        ["wasKiosk"] = true,
                        ["seller"] = 232,
                        ["timestamp"] = 1632976478,
                        ["quant"] = 1,
                        ["id"] = "1690106547",
                        ["itemLink"] = 239,
                    },
                    [2] = 
                    {
                        ["price"] = 39500,
                        ["guild"] = 1,
                        ["buyer"] = 241,
                        ["wasKiosk"] = true,
                        ["seller"] = 232,
                        ["timestamp"] = 1632977842,
                        ["quant"] = 1,
                        ["id"] = "1690117129",
                        ["itemLink"] = 239,
                    },
                    [3] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 430,
                        ["wasKiosk"] = true,
                        ["seller"] = 431,
                        ["timestamp"] = 1633007461,
                        ["quant"] = 1,
                        ["id"] = "1690274645",
                        ["itemLink"] = 239,
                    },
                    [4] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 554,
                        ["wasKiosk"] = true,
                        ["seller"] = 431,
                        ["timestamp"] = 1633028082,
                        ["quant"] = 1,
                        ["id"] = "1690429233",
                        ["itemLink"] = 239,
                    },
                    [5] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 847,
                        ["wasKiosk"] = true,
                        ["seller"] = 431,
                        ["timestamp"] = 1633071551,
                        ["quant"] = 1,
                        ["id"] = "1690787899",
                        ["itemLink"] = 239,
                    },
                    [6] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1493,
                        ["wasKiosk"] = true,
                        ["seller"] = 734,
                        ["timestamp"] = 1633201131,
                        ["quant"] = 1,
                        ["id"] = "1691801951",
                        ["itemLink"] = 239,
                    },
                    [7] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1488,
                        ["wasKiosk"] = true,
                        ["seller"] = 734,
                        ["timestamp"] = 1633201198,
                        ["quant"] = 1,
                        ["id"] = "1691802641",
                        ["itemLink"] = 239,
                    },
                    [8] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1529,
                        ["wasKiosk"] = true,
                        ["seller"] = 734,
                        ["timestamp"] = 1633206359,
                        ["quant"] = 1,
                        ["id"] = "1691859549",
                        ["itemLink"] = 239,
                    },
                    [9] = 
                    {
                        ["price"] = 156000,
                        ["guild"] = 1,
                        ["buyer"] = 1763,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633239876,
                        ["quant"] = 4,
                        ["id"] = "1692196343",
                        ["itemLink"] = 239,
                    },
                    [10] = 
                    {
                        ["price"] = 78850,
                        ["guild"] = 1,
                        ["buyer"] = 1769,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633240266,
                        ["quant"] = 2,
                        ["id"] = "1692199407",
                        ["itemLink"] = 239,
                    },
                    [11] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 1990,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633292583,
                        ["quant"] = 1,
                        ["id"] = "1692658625",
                        ["itemLink"] = 239,
                    },
                    [12] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1114,
                        ["wasKiosk"] = true,
                        ["seller"] = 431,
                        ["timestamp"] = 1632852493,
                        ["quant"] = 1,
                        ["id"] = "1689162759",
                        ["itemLink"] = 239,
                    },
                    [13] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 2385,
                        ["wasKiosk"] = true,
                        ["seller"] = 431,
                        ["timestamp"] = 1632884840,
                        ["quant"] = 1,
                        ["id"] = "1689450095",
                        ["itemLink"] = 239,
                    },
                    [14] = 
                    {
                        ["price"] = 39500,
                        ["guild"] = 1,
                        ["buyer"] = 2511,
                        ["wasKiosk"] = true,
                        ["seller"] = 232,
                        ["timestamp"] = 1632929597,
                        ["quant"] = 1,
                        ["id"] = "1689719749",
                        ["itemLink"] = 239,
                    },
                },
                ["totalCount"] = 14,
                ["itemAdderText"] = "rr01 white normal materials essence runestone",
            },
        },
        [140498] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 67: Welkynar Belts",
                ["oldestTime"] = 1633058058,
                ["wasAltered"] = true,
                ["newestTime"] = 1633058058,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 770,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633058058,
                        ["quant"] = 1,
                        ["id"] = "1690690823",
                        ["itemLink"] = 980,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [68475] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_snowreach_medium_waist_a.dds",
                ["itemDesc"] = "Briarheart Belt",
                ["oldestTime"] = 1633289876,
                ["wasAltered"] = true,
                ["newestTime"] = 1633289876,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2100,
                        ["guild"] = 1,
                        ["buyer"] = 1521,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1633289876,
                        ["quant"] = 1,
                        ["id"] = "1692625777",
                        ["itemLink"] = 2778,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set briarheart waist well-fitted",
            },
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_snowreach_medium_waist_a.dds",
                ["itemDesc"] = "Briarheart Belt",
                ["oldestTime"] = 1633159655,
                ["wasAltered"] = true,
                ["newestTime"] = 1633159655,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 1299,
                        ["wasKiosk"] = true,
                        ["seller"] = 360,
                        ["timestamp"] = 1633159655,
                        ["quant"] = 1,
                        ["id"] = "1691463077",
                        ["itemLink"] = 1785,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set briarheart waist well-fitted",
            },
        },
        [124665] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/fragment_pet_sentry_eye.dds",
                ["itemDesc"] = "Dwarven Theodolite Eye",
                ["oldestTime"] = 1632992992,
                ["wasAltered"] = true,
                ["newestTime"] = 1632992992,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4495,
                        ["guild"] = 1,
                        ["buyer"] = 366,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1632992992,
                        ["quant"] = 1,
                        ["id"] = "1690201127",
                        ["itemLink"] = 363,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [71674] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 28: Ra Gada Belts",
                ["oldestTime"] = 1633143179,
                ["wasAltered"] = true,
                ["newestTime"] = 1633143179,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2950,
                        ["guild"] = 1,
                        ["buyer"] = 1210,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633143179,
                        ["quant"] = 1,
                        ["id"] = "1691327365",
                        ["itemLink"] = 1628,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [56059] = 
        {
            ["1:0:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_medium_waist_a.dds",
                ["itemDesc"] = "Rawhide Belt",
                ["oldestTime"] = 1632984626,
                ["wasAltered"] = true,
                ["newestTime"] = 1632984626,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 309,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1632984626,
                        ["quant"] = 1,
                        ["id"] = "1690157899",
                        ["itemLink"] = 314,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal medium apparel waist nirnhoned",
            },
        },
        [97276] = 
        {
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_hands_d.dds",
                ["itemDesc"] = "Gloves of a Mother's Sorrow",
                ["oldestTime"] = 1633065634,
                ["wasAltered"] = true,
                ["newestTime"] = 1633065634,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 636,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633065634,
                        ["quant"] = 1,
                        ["id"] = "1690752611",
                        ["itemLink"] = 1064,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set mother's sorrow hands well-fitted",
            },
        },
        [71677] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 28: Ra Gada Chests",
                ["oldestTime"] = 1633063914,
                ["wasAltered"] = true,
                ["newestTime"] = 1633143167,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 806,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1633063914,
                        ["quant"] = 1,
                        ["id"] = "1690739861",
                        ["itemLink"] = 1046,
                    },
                    [2] = 
                    {
                        ["price"] = 8607,
                        ["guild"] = 1,
                        ["buyer"] = 1210,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633143167,
                        ["quant"] = 1,
                        ["id"] = "1691327195",
                        ["itemLink"] = 1046,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45326] = 
        {
            ["50:16:1:19:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_medium_shoulders_d.dds",
                ["itemDesc"] = "Rubedo Leather Arm Cops",
                ["oldestTime"] = 1633016246,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186028,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 403,
                        ["guild"] = 1,
                        ["buyer"] = 470,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633016246,
                        ["quant"] = 1,
                        ["id"] = "1690335485",
                        ["itemLink"] = 540,
                    },
                    [2] = 
                    {
                        ["price"] = 403,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633023016,
                        ["quant"] = 1,
                        ["id"] = "1690390757",
                        ["itemLink"] = 639,
                    },
                    [3] = 
                    {
                        ["price"] = 404,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633023016,
                        ["quant"] = 1,
                        ["id"] = "1690390773",
                        ["itemLink"] = 640,
                    },
                    [4] = 
                    {
                        ["price"] = 403,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633186028,
                        ["quant"] = 1,
                        ["id"] = "1691640987",
                        ["itemLink"] = 540,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp160 white normal medium apparel shoulders ornate",
            },
        },
        [86783] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_legs_d.dds",
                ["itemDesc"] = "Breeches of Necropotence",
                ["oldestTime"] = 1633183711,
                ["wasAltered"] = true,
                ["newestTime"] = 1633183711,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 145000,
                        ["guild"] = 1,
                        ["buyer"] = 1382,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1633183711,
                        ["quant"] = 1,
                        ["id"] = "1691619093",
                        ["itemLink"] = 1965,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set necropotence legs divines",
            },
        },
    },
}
