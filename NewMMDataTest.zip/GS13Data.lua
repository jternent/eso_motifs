GS13DataSavedVariables =
{
    ["listingseu"] = 
    {
    },
    ["listingsna"] = 
    {
    },
    ["dataeu"] = 
    {
    },
    ["datana"] = 
    {
        [71683] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 28: Ra Gada Shields",
                ["oldestTime"] = 1632886419,
                ["wasAltered"] = true,
                ["newestTime"] = 1633058014,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1679,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 765,
                        ["timestamp"] = 1633058014,
                        ["quant"] = 1,
                        ["id"] = "1690690251",
                        ["itemLink"] = 978,
                    },
                    [2] = 
                    {
                        ["price"] = 3340,
                        ["guild"] = 1,
                        ["buyer"] = 2393,
                        ["wasKiosk"] = true,
                        ["seller"] = 711,
                        ["timestamp"] = 1632886419,
                        ["quant"] = 1,
                        ["id"] = "1689466163",
                        ["itemLink"] = 978,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [51717] = 
        {
            ["50:16:5:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_2hsword_c.dds",
                ["itemDesc"] = "Greatsword of Hunding's Rage",
                ["oldestTime"] = 1633220128,
                ["wasAltered"] = true,
                ["newestTime"] = 1633220128,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 109000,
                        ["guild"] = 1,
                        ["buyer"] = 1610,
                        ["wasKiosk"] = true,
                        ["seller"] = 1318,
                        ["timestamp"] = 1633220128,
                        ["quant"] = 1,
                        ["id"] = "1692013457",
                        ["itemLink"] = 2342,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary weapon set hunding's rage sword two-handed precise",
            },
        },
        [173323] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_medium_hands_d.dds",
                ["itemDesc"] = "Bracers of Diamond's Victory",
                ["oldestTime"] = 1633145522,
                ["wasAltered"] = true,
                ["newestTime"] = 1633145522,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 1226,
                        ["wasKiosk"] = true,
                        ["seller"] = 261,
                        ["timestamp"] = 1633145522,
                        ["quant"] = 1,
                        ["id"] = "1691351811",
                        ["itemLink"] = 1649,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set diamond's victory hands divines",
            },
        },
        [120076] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/consumeable_experience_002.dds",
                ["itemDesc"] = "Aetherial Ambrosia",
                ["oldestTime"] = 1632961580,
                ["wasAltered"] = true,
                ["newestTime"] = 1633298950,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 86999,
                        ["guild"] = 1,
                        ["buyer"] = 1021,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633124683,
                        ["quant"] = 4,
                        ["id"] = "1691139963",
                        ["itemLink"] = 1466,
                    },
                    [2] = 
                    {
                        ["price"] = 171984,
                        ["guild"] = 1,
                        ["buyer"] = 2,
                        ["wasKiosk"] = false,
                        ["seller"] = 402,
                        ["timestamp"] = 1633298950,
                        ["quant"] = 8,
                        ["id"] = "1692730569",
                        ["itemLink"] = 1466,
                    },
                    [3] = 
                    {
                        ["price"] = 22484,
                        ["guild"] = 1,
                        ["buyer"] = 183,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1632961580,
                        ["quant"] = 1,
                        ["id"] = "1689971773",
                        ["itemLink"] = 1466,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 gold legendary consumable drink",
            },
        },
        [34573] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_shield_d.dds",
                ["itemDesc"] = "Plague Doctor Llarel's Sheltering Shield",
                ["oldestTime"] = 1633222837,
                ["wasAltered"] = true,
                ["newestTime"] = 1633222837,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 1624,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633222837,
                        ["quant"] = 1,
                        ["id"] = "1692040691",
                        ["itemLink"] = 2364,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior apparel weapon set plague doctor shield off hand impenetrable",
            },
        },
        [45838] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_018.dds",
                ["itemDesc"] = "Rakeipa",
                ["oldestTime"] = 1632871491,
                ["wasAltered"] = true,
                ["newestTime"] = 1633245141,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 140,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 502,
                        ["timestamp"] = 1633194027,
                        ["quant"] = 1,
                        ["id"] = "1691735293",
                        ["itemLink"] = 2127,
                    },
                    [2] = 
                    {
                        ["price"] = 79400,
                        ["guild"] = 1,
                        ["buyer"] = 1796,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1633245140,
                        ["quant"] = 200,
                        ["id"] = "1692234447",
                        ["itemLink"] = 2127,
                    },
                    [3] = 
                    {
                        ["price"] = 79400,
                        ["guild"] = 1,
                        ["buyer"] = 1796,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1633245141,
                        ["quant"] = 200,
                        ["id"] = "1692234453",
                        ["itemLink"] = 2127,
                    },
                    [4] = 
                    {
                        ["price"] = 2384,
                        ["guild"] = 1,
                        ["buyer"] = 2292,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632871491,
                        ["quant"] = 16,
                        ["id"] = "1689312811",
                        ["itemLink"] = 2127,
                    },
                    [5] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 2490,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1632921526,
                        ["quant"] = 200,
                        ["id"] = "1689661609",
                        ["itemLink"] = 2127,
                    },
                    [6] = 
                    {
                        ["price"] = 22823,
                        ["guild"] = 1,
                        ["buyer"] = 2490,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1632921531,
                        ["quant"] = 100,
                        ["id"] = "1689661627",
                        ["itemLink"] = 2127,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 white normal materials essence runestone",
            },
        },
        [45327] = 
        {
            ["50:16:1:19:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_medium_waist_a.dds",
                ["itemDesc"] = "Rubedo Leather Belt",
                ["oldestTime"] = 1633016244,
                ["wasAltered"] = true,
                ["newestTime"] = 1633016244,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 324,
                        ["guild"] = 1,
                        ["buyer"] = 470,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1633016244,
                        ["quant"] = 1,
                        ["id"] = "1690335475",
                        ["itemLink"] = 538,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal medium apparel waist ornate",
            },
        },
        [97296] = 
        {
            ["50:16:4:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_feet_d.dds",
                ["itemDesc"] = "Shoes of a Mother's Sorrow",
                ["oldestTime"] = 1633217315,
                ["wasAltered"] = true,
                ["newestTime"] = 1633217315,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11113,
                        ["guild"] = 1,
                        ["buyer"] = 1595,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633217315,
                        ["quant"] = 1,
                        ["id"] = "1691982703",
                        ["itemLink"] = 2324,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set mother's sorrow feet reinforced",
            },
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_feet_d.dds",
                ["itemDesc"] = "Shoes of a Mother's Sorrow",
                ["oldestTime"] = 1633065625,
                ["wasAltered"] = true,
                ["newestTime"] = 1633065625,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 636,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633065625,
                        ["quant"] = 1,
                        ["id"] = "1690752585",
                        ["itemLink"] = 1063,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set mother's sorrow feet reinforced",
            },
        },
        [57617] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 20: Yokudan Shoulders",
                ["oldestTime"] = 1632979070,
                ["wasAltered"] = true,
                ["newestTime"] = 1633062954,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19999,
                        ["guild"] = 1,
                        ["buyer"] = 253,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1632979070,
                        ["quant"] = 1,
                        ["id"] = "1690126165",
                        ["itemLink"] = 257,
                    },
                    [2] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 242,
                        ["wasKiosk"] = false,
                        ["seller"] = 786,
                        ["timestamp"] = 1633062954,
                        ["quant"] = 1,
                        ["id"] = "1690732109",
                        ["itemLink"] = 257,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [167955] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 95: Nighthollow Shoulders",
                ["oldestTime"] = 1633128038,
                ["wasAltered"] = true,
                ["newestTime"] = 1633128038,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 418,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1633128038,
                        ["quant"] = 1,
                        ["id"] = "1691167661",
                        ["itemLink"] = 1496,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [181524] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_waf_housingleycastleplatformint001.dds",
                ["itemDesc"] = "Leyawiin Platform, Huge Square",
                ["oldestTime"] = 1632969595,
                ["wasAltered"] = true,
                ["newestTime"] = 1632969595,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 49900,
                        ["guild"] = 1,
                        ["buyer"] = 154,
                        ["wasKiosk"] = true,
                        ["seller"] = 155,
                        ["timestamp"] = 1632969595,
                        ["quant"] = 2,
                        ["id"] = "1690052363",
                        ["itemLink"] = 164,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings structures",
            },
        },
        [77591] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_poisonmaking_reagent_mudcrab_chitin.dds",
                ["itemDesc"] = "Mudcrab Chitin",
                ["oldestTime"] = 1632844727,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297368,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 65800,
                        ["guild"] = 1,
                        ["buyer"] = 326,
                        ["wasKiosk"] = true,
                        ["seller"] = 327,
                        ["timestamp"] = 1632987534,
                        ["quant"] = 200,
                        ["id"] = "1690171949",
                        ["itemLink"] = 331,
                    },
                    [2] = 
                    {
                        ["price"] = 65800,
                        ["guild"] = 1,
                        ["buyer"] = 326,
                        ["wasKiosk"] = true,
                        ["seller"] = 327,
                        ["timestamp"] = 1632987535,
                        ["quant"] = 200,
                        ["id"] = "1690171957",
                        ["itemLink"] = 331,
                    },
                    [3] = 
                    {
                        ["price"] = 65800,
                        ["guild"] = 1,
                        ["buyer"] = 605,
                        ["wasKiosk"] = false,
                        ["seller"] = 327,
                        ["timestamp"] = 1633036659,
                        ["quant"] = 200,
                        ["id"] = "1690489893",
                        ["itemLink"] = 331,
                    },
                    [4] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 791,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633061298,
                        ["quant"] = 20,
                        ["id"] = "1690720517",
                        ["itemLink"] = 331,
                    },
                    [5] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 791,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633061299,
                        ["quant"] = 20,
                        ["id"] = "1690720521",
                        ["itemLink"] = 331,
                    },
                    [6] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 791,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633061299,
                        ["quant"] = 20,
                        ["id"] = "1690720523",
                        ["itemLink"] = 331,
                    },
                    [7] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 791,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633061300,
                        ["quant"] = 20,
                        ["id"] = "1690720527",
                        ["itemLink"] = 331,
                    },
                    [8] = 
                    {
                        ["price"] = 65800,
                        ["guild"] = 1,
                        ["buyer"] = 791,
                        ["wasKiosk"] = true,
                        ["seller"] = 327,
                        ["timestamp"] = 1633061301,
                        ["quant"] = 200,
                        ["id"] = "1690720533",
                        ["itemLink"] = 331,
                    },
                    [9] = 
                    {
                        ["price"] = 65800,
                        ["guild"] = 1,
                        ["buyer"] = 791,
                        ["wasKiosk"] = true,
                        ["seller"] = 327,
                        ["timestamp"] = 1633061302,
                        ["quant"] = 200,
                        ["id"] = "1690720537",
                        ["itemLink"] = 331,
                    },
                    [10] = 
                    {
                        ["price"] = 42560,
                        ["guild"] = 1,
                        ["buyer"] = 1378,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633182331,
                        ["quant"] = 133,
                        ["id"] = "1691606645",
                        ["itemLink"] = 331,
                    },
                    [11] = 
                    {
                        ["price"] = 65800,
                        ["guild"] = 1,
                        ["buyer"] = 1378,
                        ["wasKiosk"] = true,
                        ["seller"] = 327,
                        ["timestamp"] = 1633182334,
                        ["quant"] = 200,
                        ["id"] = "1691606661",
                        ["itemLink"] = 331,
                    },
                    [12] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 168,
                        ["wasKiosk"] = false,
                        ["seller"] = 222,
                        ["timestamp"] = 1633244460,
                        ["quant"] = 26,
                        ["id"] = "1692229271",
                        ["itemLink"] = 331,
                    },
                    [13] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633251949,
                        ["quant"] = 2,
                        ["id"] = "1692284869",
                        ["itemLink"] = 331,
                    },
                    [14] = 
                    {
                        ["price"] = 68200,
                        ["guild"] = 1,
                        ["buyer"] = 56,
                        ["wasKiosk"] = false,
                        ["seller"] = 327,
                        ["timestamp"] = 1633297365,
                        ["quant"] = 200,
                        ["id"] = "1692714127",
                        ["itemLink"] = 331,
                    },
                    [15] = 
                    {
                        ["price"] = 68200,
                        ["guild"] = 1,
                        ["buyer"] = 56,
                        ["wasKiosk"] = false,
                        ["seller"] = 327,
                        ["timestamp"] = 1633297368,
                        ["quant"] = 200,
                        ["id"] = "1692714171",
                        ["itemLink"] = 331,
                    },
                    [16] = 
                    {
                        ["price"] = 54000,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 294,
                        ["timestamp"] = 1632844727,
                        ["quant"] = 200,
                        ["id"] = "1689097431",
                        ["itemLink"] = 331,
                    },
                    [17] = 
                    {
                        ["price"] = 54000,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 294,
                        ["timestamp"] = 1632844727,
                        ["quant"] = 200,
                        ["id"] = "1689097437",
                        ["itemLink"] = 331,
                    },
                    [18] = 
                    {
                        ["price"] = 65800,
                        ["guild"] = 1,
                        ["buyer"] = 2295,
                        ["wasKiosk"] = true,
                        ["seller"] = 327,
                        ["timestamp"] = 1632871496,
                        ["quant"] = 200,
                        ["id"] = "1689312825",
                        ["itemLink"] = 331,
                    },
                    [19] = 
                    {
                        ["price"] = 12480,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1632954921,
                        ["quant"] = 39,
                        ["id"] = "1689917695",
                        ["itemLink"] = 331,
                    },
                },
                ["totalCount"] = 19,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [45851] = 
        {
            ["6:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_005.dds",
                ["itemDesc"] = "Jejota",
                ["oldestTime"] = 1633049643,
                ["wasAltered"] = true,
                ["newestTime"] = 1633164151,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 40,
                        ["wasKiosk"] = true,
                        ["seller"] = 267,
                        ["timestamp"] = 1633049643,
                        ["quant"] = 200,
                        ["id"] = "1690601285",
                        ["itemLink"] = 881,
                    },
                    [2] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1633164150,
                        ["quant"] = 200,
                        ["id"] = "1691491381",
                        ["itemLink"] = 881,
                    },
                    [3] = 
                    {
                        ["price"] = 1122,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633164151,
                        ["quant"] = 200,
                        ["id"] = "1691491389",
                        ["itemLink"] = 881,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr06 green fine materials aspect runestone",
            },
        },
        [45852] = 
        {
            ["11:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_004.dds",
                ["itemDesc"] = "Denata",
                ["oldestTime"] = 1633049671,
                ["wasAltered"] = true,
                ["newestTime"] = 1633049671,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 72,
                        ["guild"] = 1,
                        ["buyer"] = 40,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633049671,
                        ["quant"] = 9,
                        ["id"] = "1690601567",
                        ["itemLink"] = 882,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr11 blue superior materials aspect runestone",
            },
        },
        [43555] = 
        {
            ["50:14:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_medium_waist_d.dds",
                ["itemDesc"] = "Shadowhide Belt",
                ["oldestTime"] = 1632922802,
                ["wasAltered"] = true,
                ["newestTime"] = 1632922802,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 257,
                        ["timestamp"] = 1632922802,
                        ["quant"] = 1,
                        ["id"] = "1689672063",
                        ["itemLink"] = 3664,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp140 green fine medium apparel waist",
            },
            ["50:14:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_medium_waist_d.dds",
                ["itemDesc"] = "Shadowhide Belt",
                ["oldestTime"] = 1632922798,
                ["wasAltered"] = true,
                ["newestTime"] = 1632922798,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 111,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 67,
                        ["timestamp"] = 1632922798,
                        ["quant"] = 1,
                        ["id"] = "1689672037",
                        ["itemLink"] = 3660,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp140 white normal medium apparel waist",
            },
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_medium_waist_d.dds",
                ["itemDesc"] = "Rubedo Leather Belt",
                ["oldestTime"] = 1633023036,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023037,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1633023036,
                        ["quant"] = 1,
                        ["id"] = "1690390951",
                        ["itemLink"] = 660,
                    },
                    [2] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1633023037,
                        ["quant"] = 1,
                        ["id"] = "1690390955",
                        ["itemLink"] = 661,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 white normal medium apparel waist",
            },
        },
        [176423] = 
        {
            ["1:0:2:37:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_maul.dds",
                ["itemDesc"] = "Companion's Maul",
                ["oldestTime"] = 1633044252,
                ["wasAltered"] = true,
                ["newestTime"] = 1633044252,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 80,
                        ["guild"] = 1,
                        ["buyer"] = 661,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1633044252,
                        ["quant"] = 1,
                        ["id"] = "1690549503",
                        ["itemLink"] = 843,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine weapon mace two-handed shattering",
            },
        },
        [95528] = 
        {
            ["50:16:2:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_staff_a.dds",
                ["itemDesc"] = "Restoration Staff of Martial Knowledge",
                ["oldestTime"] = 1633225758,
                ["wasAltered"] = true,
                ["newestTime"] = 1633225758,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 1645,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1633225758,
                        ["quant"] = 1,
                        ["id"] = "1692071851",
                        ["itemLink"] = 2389,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set way of martial knowledge healing staff two-handed defending",
            },
        },
        [45097] = 
        {
            ["50:16:1:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_heavy_hands_d.dds",
                ["itemDesc"] = "Rubedite Gauntlets",
                ["oldestTime"] = 1632950137,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950137,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1632950137,
                        ["quant"] = 1,
                        ["id"] = "1689875297",
                        ["itemLink"] = 3832,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal heavy apparel hands reinforced",
            },
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_heavy_hands_d.dds",
                ["itemDesc"] = "Rubedite Gauntlets of Magicka",
                ["oldestTime"] = 1632976079,
                ["wasAltered"] = true,
                ["newestTime"] = 1632976079,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 90,
                        ["guild"] = 1,
                        ["buyer"] = 221,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632976079,
                        ["quant"] = 1,
                        ["id"] = "1690103367",
                        ["itemLink"] = 235,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel hands reinforced",
            },
        },
        [139307] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_sum_topiarypoodle001.dds",
                ["itemDesc"] = "Alinor Potted Plant, Triple Tiered",
                ["oldestTime"] = 1633060756,
                ["wasAltered"] = true,
                ["newestTime"] = 1633060756,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 788,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633060756,
                        ["quant"] = 2,
                        ["id"] = "1690716583",
                        ["itemLink"] = 1021,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings conservatory",
            },
        },
        [45357] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_medium_feet_d.dds",
                ["itemDesc"] = "Rubedo Leather Boots",
                ["oldestTime"] = 1632839964,
                ["wasAltered"] = true,
                ["newestTime"] = 1633146939,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1633009344,
                        ["quant"] = 1,
                        ["id"] = "1690285203",
                        ["itemLink"] = 457,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633009352,
                        ["quant"] = 1,
                        ["id"] = "1690285273",
                        ["itemLink"] = 465,
                    },
                    [3] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633009353,
                        ["quant"] = 1,
                        ["id"] = "1690285283",
                        ["itemLink"] = 466,
                    },
                    [4] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633009358,
                        ["quant"] = 1,
                        ["id"] = "1690285345",
                        ["itemLink"] = 466,
                    },
                    [5] = 
                    {
                        ["price"] = 140,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633023003,
                        ["quant"] = 1,
                        ["id"] = "1690390605",
                        ["itemLink"] = 627,
                    },
                    [6] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 780,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1633059427,
                        ["quant"] = 1,
                        ["id"] = "1690704657",
                        ["itemLink"] = 1000,
                    },
                    [7] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084092,
                        ["quant"] = 1,
                        ["id"] = "1690854989",
                        ["itemLink"] = 466,
                    },
                    [8] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084098,
                        ["quant"] = 1,
                        ["id"] = "1690855005",
                        ["itemLink"] = 1183,
                    },
                    [9] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633146935,
                        ["quant"] = 1,
                        ["id"] = "1691365317",
                        ["itemLink"] = 465,
                    },
                    [10] = 
                    {
                        ["price"] = 175,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633146939,
                        ["quant"] = 1,
                        ["id"] = "1691365389",
                        ["itemLink"] = 1671,
                    },
                    [11] = 
                    {
                        ["price"] = 231,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632839964,
                        ["quant"] = 1,
                        ["id"] = "1689060171",
                        ["itemLink"] = 466,
                    },
                    [12] = 
                    {
                        ["price"] = 323,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1632956412,
                        ["quant"] = 1,
                        ["id"] = "1689931739",
                        ["itemLink"] = 465,
                    },
                    [13] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632956420,
                        ["quant"] = 1,
                        ["id"] = "1689931851",
                        ["itemLink"] = 627,
                    },
                },
                ["totalCount"] = 13,
                ["itemAdderText"] = "cp160 white normal medium apparel feet intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ashlanderv_medium_feet_a.dds",
                ["itemDesc"] = "Rubedo Leather Boots",
                ["oldestTime"] = 1632839966,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185974,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 864,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633084689,
                        ["quant"] = 1,
                        ["id"] = "1690857427",
                        ["itemLink"] = 1214,
                    },
                    [2] = 
                    {
                        ["price"] = 202,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633185974,
                        ["quant"] = 1,
                        ["id"] = "1691640463",
                        ["itemLink"] = 2041,
                    },
                    [3] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632839966,
                        ["quant"] = 1,
                        ["id"] = "1689060193",
                        ["itemLink"] = 3139,
                    },
                    [4] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 77,
                        ["timestamp"] = 1632922800,
                        ["quant"] = 1,
                        ["id"] = "1689672055",
                        ["itemLink"] = 2041,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp150 white normal medium apparel feet intricate",
            },
        },
        [116017] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Dark Elf Table, Formal",
                ["oldestTime"] = 1632818901,
                ["wasAltered"] = true,
                ["newestTime"] = 1632818901,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 88,
                        ["guild"] = 1,
                        ["buyer"] = 1142,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1632818901,
                        ["quant"] = 1,
                        ["id"] = "1688938799",
                        ["itemLink"] = 3006,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [45362] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_medium_waist_d.dds",
                ["itemDesc"] = "Rubedo Leather Belt",
                ["oldestTime"] = 1632839967,
                ["wasAltered"] = true,
                ["newestTime"] = 1633236160,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 271,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633009347,
                        ["quant"] = 1,
                        ["id"] = "1690285221",
                        ["itemLink"] = 461,
                    },
                    [2] = 
                    {
                        ["price"] = 864,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633084115,
                        ["quant"] = 1,
                        ["id"] = "1690855111",
                        ["itemLink"] = 1193,
                    },
                    [3] = 
                    {
                        ["price"] = 864,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633084116,
                        ["quant"] = 1,
                        ["id"] = "1690855121",
                        ["itemLink"] = 1194,
                    },
                    [4] = 
                    {
                        ["price"] = 280,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633185998,
                        ["quant"] = 1,
                        ["id"] = "1691640647",
                        ["itemLink"] = 2051,
                    },
                    [5] = 
                    {
                        ["price"] = 160,
                        ["guild"] = 1,
                        ["buyer"] = 1734,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633236160,
                        ["quant"] = 1,
                        ["id"] = "1692168685",
                        ["itemLink"] = 2051,
                    },
                    [6] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1632839967,
                        ["quant"] = 1,
                        ["id"] = "1689060209",
                        ["itemLink"] = 3140,
                    },
                    [7] = 
                    {
                        ["price"] = 280,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632839969,
                        ["quant"] = 1,
                        ["id"] = "1689060227",
                        ["itemLink"] = 3144,
                    },
                    [8] = 
                    {
                        ["price"] = 180,
                        ["guild"] = 1,
                        ["buyer"] = 598,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632868128,
                        ["quant"] = 1,
                        ["id"] = "1689288719",
                        ["itemLink"] = 3366,
                    },
                    [9] = 
                    {
                        ["price"] = 180,
                        ["guild"] = 1,
                        ["buyer"] = 2319,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632874548,
                        ["quant"] = 1,
                        ["id"] = "1689336593",
                        ["itemLink"] = 3140,
                    },
                    [10] = 
                    {
                        ["price"] = 226,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 108,
                        ["timestamp"] = 1632922801,
                        ["quant"] = 1,
                        ["id"] = "1689672059",
                        ["itemLink"] = 3663,
                    },
                    [11] = 
                    {
                        ["price"] = 186,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1632956406,
                        ["quant"] = 1,
                        ["id"] = "1689931667",
                        ["itemLink"] = 461,
                    },
                    [12] = 
                    {
                        ["price"] = 265,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632956407,
                        ["quant"] = 1,
                        ["id"] = "1689931677",
                        ["itemLink"] = 3894,
                    },
                    [13] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632956419,
                        ["quant"] = 1,
                        ["id"] = "1689931827",
                        ["itemLink"] = 3894,
                    },
                    [14] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632956419,
                        ["quant"] = 1,
                        ["id"] = "1689931839",
                        ["itemLink"] = 3901,
                    },
                },
                ["totalCount"] = 14,
                ["itemAdderText"] = "cp160 white normal medium apparel waist intricate",
            },
            ["1:0:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ashlanderv_medium_waist_a.dds",
                ["itemDesc"] = "Rawhide Belt",
                ["oldestTime"] = 1632922797,
                ["wasAltered"] = true,
                ["newestTime"] = 1632922797,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 379,
                        ["timestamp"] = 1632922797,
                        ["quant"] = 1,
                        ["id"] = "1689672035",
                        ["itemLink"] = 3659,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal medium apparel waist intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_medium_waist_d.dds",
                ["itemDesc"] = "Rubedo Leather Belt",
                ["oldestTime"] = 1632839965,
                ["wasAltered"] = true,
                ["newestTime"] = 1633126100,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633009354,
                        ["quant"] = 1,
                        ["id"] = "1690285303",
                        ["itemLink"] = 468,
                    },
                    [2] = 
                    {
                        ["price"] = 140,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633023002,
                        ["quant"] = 1,
                        ["id"] = "1690390595",
                        ["itemLink"] = 626,
                    },
                    [3] = 
                    {
                        ["price"] = 140,
                        ["guild"] = 1,
                        ["buyer"] = 328,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633126100,
                        ["quant"] = 1,
                        ["id"] = "1691150103",
                        ["itemLink"] = 468,
                    },
                    [4] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632839965,
                        ["quant"] = 1,
                        ["id"] = "1689060185",
                        ["itemLink"] = 3137,
                    },
                    [5] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632839967,
                        ["quant"] = 1,
                        ["id"] = "1689060203",
                        ["itemLink"] = 626,
                    },
                    [6] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632840314,
                        ["quant"] = 1,
                        ["id"] = "1689062305",
                        ["itemLink"] = 468,
                    },
                    [7] = 
                    {
                        ["price"] = 844,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1632840315,
                        ["quant"] = 1,
                        ["id"] = "1689062313",
                        ["itemLink"] = 3149,
                    },
                    [8] = 
                    {
                        ["price"] = 844,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1632840315,
                        ["quant"] = 1,
                        ["id"] = "1689062317",
                        ["itemLink"] = 3137,
                    },
                    [9] = 
                    {
                        ["price"] = 265,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632885646,
                        ["quant"] = 1,
                        ["id"] = "1689459543",
                        ["itemLink"] = 3510,
                    },
                    [10] = 
                    {
                        ["price"] = 125,
                        ["guild"] = 1,
                        ["buyer"] = 2202,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1632913788,
                        ["quant"] = 1,
                        ["id"] = "1689616107",
                        ["itemLink"] = 3510,
                    },
                },
                ["totalCount"] = 10,
                ["itemAdderText"] = "cp150 white normal medium apparel waist intricate",
            },
        },
        [139059] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_inc_scrimshaw002.dds",
                ["itemDesc"] = "Ivory, Polished",
                ["oldestTime"] = 1632920853,
                ["wasAltered"] = true,
                ["newestTime"] = 1632920853,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 60,
                        ["guild"] = 1,
                        ["buyer"] = 2486,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632920853,
                        ["quant"] = 1,
                        ["id"] = "1689657085",
                        ["itemLink"] = 3652,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings parlor",
            },
        },
        [153652] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_fur_chaise001.dds",
                ["itemDesc"] = "Elsweyr Chaise Lounge, Upholstered",
                ["oldestTime"] = 1632886285,
                ["wasAltered"] = true,
                ["newestTime"] = 1633223755,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 42189,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1633165983,
                        ["quant"] = 1,
                        ["id"] = "1691500571",
                        ["itemLink"] = 1858,
                    },
                    [2] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 969,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633223755,
                        ["quant"] = 1,
                        ["id"] = "1692051527",
                        ["itemLink"] = 1858,
                    },
                    [3] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 299,
                        ["wasKiosk"] = false,
                        ["seller"] = 73,
                        ["timestamp"] = 1632886285,
                        ["quant"] = 1,
                        ["id"] = "1689465107",
                        ["itemLink"] = 1858,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 gold legendary furnishings parlor",
            },
        },
        [46133] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_cloth_silverweave.dds",
                ["itemDesc"] = "Silverweave",
                ["oldestTime"] = 1633134258,
                ["wasAltered"] = true,
                ["newestTime"] = 1633134258,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 31400,
                        ["guild"] = 1,
                        ["buyer"] = 1131,
                        ["wasKiosk"] = true,
                        ["seller"] = 327,
                        ["timestamp"] = 1633134258,
                        ["quant"] = 200,
                        ["id"] = "1691233231",
                        ["itemLink"] = 1550,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [175927] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Bookcase, Narrow",
                ["oldestTime"] = 1632843668,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186617,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1398,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633186617,
                        ["quant"] = 1,
                        ["id"] = "1691648197",
                        ["itemLink"] = 2075,
                    },
                    [2] = 
                    {
                        ["price"] = 23000,
                        ["guild"] = 1,
                        ["buyer"] = 2191,
                        ["wasKiosk"] = true,
                        ["seller"] = 100,
                        ["timestamp"] = 1632843668,
                        ["quant"] = 1,
                        ["id"] = "1689089027",
                        ["itemLink"] = 2075,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [175928] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Bookcase, Narrow Filled",
                ["oldestTime"] = 1632867468,
                ["wasAltered"] = true,
                ["newestTime"] = 1632867468,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 575000,
                        ["guild"] = 1,
                        ["buyer"] = 2275,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1632867468,
                        ["quant"] = 1,
                        ["id"] = "1689283977",
                        ["itemLink"] = 3364,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [176186] = 
        {
            ["1:0:4:44:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_belt_light.dds",
                ["itemDesc"] = "Companion's Sash",
                ["oldestTime"] = 1633243023,
                ["wasAltered"] = true,
                ["newestTime"] = 1633243023,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1787,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633243023,
                        ["quant"] = 1,
                        ["id"] = "1692219005",
                        ["itemLink"] = 2557,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic light apparel waist prolific",
            },
        },
        [97083] = 
        {
            ["50:16:2:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_dagger_d.dds",
                ["itemDesc"] = "Plague Doctor's Dagger",
                ["oldestTime"] = 1633204847,
                ["wasAltered"] = true,
                ["newestTime"] = 1633204847,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1518,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633204847,
                        ["quant"] = 1,
                        ["id"] = "1691840703",
                        ["itemLink"] = 2236,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set plague doctor dagger one-handed precise",
            },
        },
        [161084] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_greyhosthvy_helmet_a.dds",
                ["itemDesc"] = "Helm of Eternal Vigor",
                ["oldestTime"] = 1632948997,
                ["wasAltered"] = true,
                ["newestTime"] = 1632948997,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2333,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1632948997,
                        ["quant"] = 1,
                        ["id"] = "1689865759",
                        ["itemLink"] = 3803,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set eternal vigor head reinforced",
            },
        },
        [175677] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_inc_leykitchenservingpot001.dds",
                ["itemDesc"] = "Leyawiin Serving Pot, Lobster Stew",
                ["oldestTime"] = 1633140448,
                ["wasAltered"] = true,
                ["newestTime"] = 1633140448,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 48000,
                        ["guild"] = 1,
                        ["buyer"] = 1183,
                        ["wasKiosk"] = true,
                        ["seller"] = 513,
                        ["timestamp"] = 1633140448,
                        ["quant"] = 1,
                        ["id"] = "1691295291",
                        ["itemLink"] = 1598,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings hearth",
            },
        },
        [45630] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Ysgramor's Harbinger Lager",
                ["oldestTime"] = 1633091057,
                ["wasAltered"] = true,
                ["newestTime"] = 1633091057,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 655,
                        ["wasKiosk"] = false,
                        ["seller"] = 911,
                        ["timestamp"] = 1633091057,
                        ["quant"] = 1,
                        ["id"] = "1690894793",
                        ["itemLink"] = 1243,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [23104] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_runecrafter_potion_sp_names_001.dds",
                ["itemDesc"] = "Dwarven Ore",
                ["oldestTime"] = 1633247636,
                ["wasAltered"] = true,
                ["newestTime"] = 1633247636,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3400,
                        ["guild"] = 1,
                        ["buyer"] = 1805,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633247636,
                        ["quant"] = 155,
                        ["id"] = "1692255503",
                        ["itemLink"] = 2584,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [87874] = 
        {
            ["50:16:4:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_dagger_a.dds",
                ["itemDesc"] = "Deadly Dagger",
                ["oldestTime"] = 1633312634,
                ["wasAltered"] = true,
                ["newestTime"] = 1633312634,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250000,
                        ["guild"] = 1,
                        ["buyer"] = 37,
                        ["wasKiosk"] = true,
                        ["seller"] = 38,
                        ["timestamp"] = 1633312634,
                        ["quant"] = 1,
                        ["id"] = "1692876971",
                        ["itemLink"] = 26,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set deadly strike dagger one-handed infused",
            },
        },
        [160579] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 87: Ancestral Nord Boots",
                ["oldestTime"] = 1633083868,
                ["wasAltered"] = true,
                ["newestTime"] = 1633083868,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 893,
                        ["wasKiosk"] = true,
                        ["seller"] = 894,
                        ["timestamp"] = 1633083868,
                        ["quant"] = 1,
                        ["id"] = "1690853465",
                        ["itemLink"] = 1143,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [181572] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Stairway, Wooden",
                ["oldestTime"] = 1632985459,
                ["wasAltered"] = true,
                ["newestTime"] = 1633257548,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 80000,
                        ["guild"] = 1,
                        ["buyer"] = 316,
                        ["wasKiosk"] = true,
                        ["seller"] = 100,
                        ["timestamp"] = 1632985459,
                        ["quant"] = 1,
                        ["id"] = "1690161819",
                        ["itemLink"] = 323,
                    },
                    [2] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 964,
                        ["wasKiosk"] = true,
                        ["seller"] = 374,
                        ["timestamp"] = 1633104925,
                        ["quant"] = 1,
                        ["id"] = "1691000551",
                        ["itemLink"] = 323,
                    },
                    [3] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 1702,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633232043,
                        ["quant"] = 1,
                        ["id"] = "1692135397",
                        ["itemLink"] = 323,
                    },
                    [4] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 1832,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633257548,
                        ["quant"] = 1,
                        ["id"] = "1692315193",
                        ["itemLink"] = 323,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [181574] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Door, Wooden",
                ["oldestTime"] = 1633041638,
                ["wasAltered"] = true,
                ["newestTime"] = 1633314854,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 88,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1633314854,
                        ["quant"] = 1,
                        ["id"] = "1692901003",
                        ["itemLink"] = 65,
                    },
                    [2] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 638,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1633041638,
                        ["quant"] = 1,
                        ["id"] = "1690525487",
                        ["itemLink"] = 65,
                    },
                    [3] = 
                    {
                        ["price"] = 85000,
                        ["guild"] = 1,
                        ["buyer"] = 1707,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633232545,
                        ["quant"] = 1,
                        ["id"] = "1692140605",
                        ["itemLink"] = 65,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [119370] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Common Wheelbarrow, Flat",
                ["oldestTime"] = 1632905685,
                ["wasAltered"] = true,
                ["newestTime"] = 1632905685,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 2452,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632905685,
                        ["quant"] = 1,
                        ["id"] = "1689584639",
                        ["itemLink"] = 3588,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [96587] = 
        {
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Shalk's Ring",
                ["oldestTime"] = 1632854193,
                ["wasAltered"] = true,
                ["newestTime"] = 1632991876,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 358,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1632991876,
                        ["quant"] = 1,
                        ["id"] = "1690195271",
                        ["itemLink"] = 357,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2230,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1632854193,
                        ["quant"] = 1,
                        ["id"] = "1689177633",
                        ["itemLink"] = 357,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set shalk exoskeleton ring healthy",
            },
        },
        [87884] = 
        {
            ["50:16:4:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_2haxe_a.dds",
                ["itemDesc"] = "Deadly Battle Axe",
                ["oldestTime"] = 1633018745,
                ["wasAltered"] = true,
                ["newestTime"] = 1633018745,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 499,
                        ["wasKiosk"] = true,
                        ["seller"] = 356,
                        ["timestamp"] = 1633018745,
                        ["quant"] = 1,
                        ["id"] = "1690356141",
                        ["itemLink"] = 572,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set deadly strike axe two-handed powered",
            },
        },
        [166734] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Vampiric Sideboard, Shelves",
                ["oldestTime"] = 1633277621,
                ["wasAltered"] = true,
                ["newestTime"] = 1633277621,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1912,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1633277621,
                        ["quant"] = 1,
                        ["id"] = "1692491915",
                        ["itemLink"] = 2709,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45710] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Planked Abecean Longfin",
                ["oldestTime"] = 1632962379,
                ["wasAltered"] = true,
                ["newestTime"] = 1632962379,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 2641,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632962379,
                        ["quant"] = 1,
                        ["id"] = "1689978621",
                        ["itemLink"] = 3933,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [123298] = 
        {
            ["50:16:4:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_staff_a.dds",
                ["itemDesc"] = "Vanguard's Challenge Lightning Staff",
                ["oldestTime"] = 1632961819,
                ["wasAltered"] = true,
                ["newestTime"] = 1632961819,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2635,
                        ["wasKiosk"] = true,
                        ["seller"] = 785,
                        ["timestamp"] = 1632961819,
                        ["quant"] = 1,
                        ["id"] = "1689973933",
                        ["itemLink"] = 3928,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set vanguard's challenge lightning staff two-handed decisive",
            },
        },
        [127026] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Indoril Runner, Almalexia",
                ["oldestTime"] = 1632961648,
                ["wasAltered"] = true,
                ["newestTime"] = 1632961648,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 2631,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632961648,
                        ["quant"] = 1,
                        ["id"] = "1689972169",
                        ["itemLink"] = 3924,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [159477] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Style Page: Jephrine Paladin Girdle",
                ["oldestTime"] = 1632953413,
                ["wasAltered"] = true,
                ["newestTime"] = 1632953413,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2603,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632953413,
                        ["quant"] = 1,
                        ["id"] = "1689904921",
                        ["itemLink"] = 3857,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [86868] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_shirt_d.dds",
                ["itemDesc"] = "Jerkin of Necropotence",
                ["oldestTime"] = 1633131793,
                ["wasAltered"] = true,
                ["newestTime"] = 1633131793,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1116,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1633131793,
                        ["quant"] = 1,
                        ["id"] = "1691206787",
                        ["itemLink"] = 1537,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set necropotence chest invigorating",
            },
        },
        [56975] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Hag Fen Pumpkin Pie",
                ["oldestTime"] = 1632952000,
                ["wasAltered"] = true,
                ["newestTime"] = 1632952000,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 240,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632952000,
                        ["quant"] = 1,
                        ["id"] = "1689891853",
                        ["itemLink"] = 3845,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [75094] = 
        {
            ["50:16:2:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_staff_a.dds",
                ["itemDesc"] = "Restoration Staff of the Night Mother",
                ["oldestTime"] = 1632990854,
                ["wasAltered"] = true,
                ["newestTime"] = 1632990854,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1632990854,
                        ["quant"] = 1,
                        ["id"] = "1690191719",
                        ["itemLink"] = 353,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set night mother's embrace healing staff two-handed sharpened",
            },
        },
        [51543] = 
        {
            ["50:15:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_medium_hands_d.dds",
                ["itemDesc"] = "Bracers of Hunding's Rage",
                ["oldestTime"] = 1633157320,
                ["wasAltered"] = true,
                ["newestTime"] = 1633157320,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 1290,
                        ["wasKiosk"] = true,
                        ["seller"] = 8,
                        ["timestamp"] = 1633157320,
                        ["quant"] = 1,
                        ["id"] = "1691450585",
                        ["itemLink"] = 1770,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 purple epic medium apparel set hunding's rage hands divines",
            },
        },
        [15606] = 
        {
            ["35:0:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_chest_c.dds",
                ["itemDesc"] = "Cuirass of the Defender",
                ["oldestTime"] = 1632950128,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950128,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 2584,
                        ["timestamp"] = 1632950128,
                        ["quant"] = 1,
                        ["id"] = "1689875215",
                        ["itemLink"] = 3819,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr35 green fine heavy apparel set seventh legion brute chest impenetrable",
            },
        },
        [23101] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_leather_base_topgrain_r2.dds",
                ["itemDesc"] = "Fell Hide",
                ["oldestTime"] = 1633295284,
                ["wasAltered"] = true,
                ["newestTime"] = 1633295284,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 2016,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633295284,
                        ["quant"] = 200,
                        ["id"] = "1692693125",
                        ["itemLink"] = 2880,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [45658] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Shepherd's Pie",
                ["oldestTime"] = 1633140929,
                ["wasAltered"] = true,
                ["newestTime"] = 1633151644,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 76,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633140929,
                        ["quant"] = 1,
                        ["id"] = "1691300679",
                        ["itemLink"] = 1608,
                    },
                    [2] = 
                    {
                        ["price"] = 76,
                        ["guild"] = 1,
                        ["buyer"] = 839,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633151644,
                        ["quant"] = 1,
                        ["id"] = "1691405255",
                        ["itemLink"] = 1608,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45915] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Roast Venison",
                ["oldestTime"] = 1632874533,
                ["wasAltered"] = true,
                ["newestTime"] = 1633079628,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 879,
                        ["wasKiosk"] = true,
                        ["seller"] = 442,
                        ["timestamp"] = 1633079628,
                        ["quant"] = 1,
                        ["id"] = "1690835081",
                        ["itemLink"] = 1123,
                    },
                    [2] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1632874533,
                        ["quant"] = 1,
                        ["id"] = "1689336455",
                        ["itemLink"] = 1123,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [167959] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_nighthollow.dds",
                ["itemDesc"] = "Umbral Droplet",
                ["oldestTime"] = 1632839170,
                ["wasAltered"] = true,
                ["newestTime"] = 1632839170,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 199,
                        ["guild"] = 1,
                        ["buyer"] = 207,
                        ["wasKiosk"] = false,
                        ["seller"] = 331,
                        ["timestamp"] = 1632839170,
                        ["quant"] = 1,
                        ["id"] = "1689055695",
                        ["itemLink"] = 3128,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [68445] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_trinimac_light_shoulders_a.dds",
                ["itemDesc"] = "Epaulets of Trinimac's Valor",
                ["oldestTime"] = 1633022980,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022980,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 530,
                        ["timestamp"] = 1633022980,
                        ["quant"] = 1,
                        ["id"] = "1690390445",
                        ["itemLink"] = 620,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set trinimac's valor shoulders infused",
            },
        },
        [139614] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_jewelry_2.dds",
                ["itemDesc"] = "Sketch: Alinor Goblet, Silver Stamped",
                ["oldestTime"] = 1633199167,
                ["wasAltered"] = true,
                ["newestTime"] = 1633205889,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1474,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633199167,
                        ["quant"] = 1,
                        ["id"] = "1691781093",
                        ["itemLink"] = 2173,
                    },
                    [2] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1525,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633205889,
                        ["quant"] = 1,
                        ["id"] = "1691853231",
                        ["itemLink"] = 2173,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [45151] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_medium_shoulders_d.dds",
                ["itemDesc"] = "Rubedo Leather Arm Cops of Magicka",
                ["oldestTime"] = 1632847689,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023013,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633023013,
                        ["quant"] = 1,
                        ["id"] = "1690390721",
                        ["itemLink"] = 636,
                    },
                    [2] = 
                    {
                        ["price"] = 145,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1632847689,
                        ["quant"] = 1,
                        ["id"] = "1689125541",
                        ["itemLink"] = 3212,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior medium apparel shoulders well-fitted",
            },
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_medium_shoulders_d.dds",
                ["itemDesc"] = "Rubedo Leather Arm Cops of Magicka",
                ["oldestTime"] = 1632847695,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023030,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633023030,
                        ["quant"] = 1,
                        ["id"] = "1690390897",
                        ["itemLink"] = 654,
                    },
                    [2] = 
                    {
                        ["price"] = 230,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1632847695,
                        ["quant"] = 1,
                        ["id"] = "1689125601",
                        ["itemLink"] = 3220,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine medium apparel shoulders well-fitted",
            },
        },
        [45159] = 
        {
            ["50:16:2:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_1hhammer_d.dds",
                ["itemDesc"] = "Rubedite Mace of Frost",
                ["oldestTime"] = 1632936811,
                ["wasAltered"] = true,
                ["newestTime"] = 1632936811,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 226,
                        ["wasKiosk"] = false,
                        ["seller"] = 257,
                        ["timestamp"] = 1632936811,
                        ["quant"] = 1,
                        ["id"] = "1689773949",
                        ["itemLink"] = 3740,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon mace one-handed defending",
            },
        },
        [68193] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Thrice-Baked Gorapple Pie",
                ["oldestTime"] = 1633094971,
                ["wasAltered"] = true,
                ["newestTime"] = 1633094971,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20,
                        ["guild"] = 1,
                        ["buyer"] = 924,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633094971,
                        ["quant"] = 1,
                        ["id"] = "1690919051",
                        ["itemLink"] = 1257,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [45154] = 
        {
            ["50:16:2:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Inferno Staff of Flame",
                ["oldestTime"] = 1633281015,
                ["wasAltered"] = true,
                ["newestTime"] = 1633281015,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1389,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633281015,
                        ["quant"] = 1,
                        ["id"] = "1692524943",
                        ["itemLink"] = 2738,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon flame staff two-handed infused",
            },
        },
        [80739] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_light_head_d.dds",
                ["itemDesc"] = "Elegant Hat",
                ["oldestTime"] = 1633090190,
                ["wasAltered"] = true,
                ["newestTime"] = 1633090190,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 613,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1633090190,
                        ["quant"] = 1,
                        ["id"] = "1690889199",
                        ["itemLink"] = 1238,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set queen's elegance head divines",
            },
        },
        [97380] = 
        {
            ["50:16:4:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_feet_d.dds",
                ["itemDesc"] = "Shoes of a Mother's Sorrow",
                ["oldestTime"] = 1633224457,
                ["wasAltered"] = true,
                ["newestTime"] = 1633224457,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 1633,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633224457,
                        ["quant"] = 1,
                        ["id"] = "1692058585",
                        ["itemLink"] = 2371,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set mother's sorrow feet training",
            },
            ["50:16:2:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_feet_d.dds",
                ["itemDesc"] = "Shoes of a Mother's Sorrow",
                ["oldestTime"] = 1632991384,
                ["wasAltered"] = true,
                ["newestTime"] = 1632991384,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 358,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1632991384,
                        ["quant"] = 1,
                        ["id"] = "1690192901",
                        ["itemLink"] = 356,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set mother's sorrow feet training",
            },
        },
        [126565] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_dae_fur_sarcophagis001.dds",
                ["itemDesc"] = "Daedric Platform, Sarcophagus",
                ["oldestTime"] = 1632851127,
                ["wasAltered"] = true,
                ["newestTime"] = 1632851127,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 175,
                        ["wasKiosk"] = false,
                        ["seller"] = 669,
                        ["timestamp"] = 1632851127,
                        ["quant"] = 1,
                        ["id"] = "1689152785",
                        ["itemLink"] = 3238,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings undercroft",
            },
        },
        [71270] = 
        {
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_neck_a.dds",
                ["itemDesc"] = "Locket of the Pariah",
                ["oldestTime"] = 1633027465,
                ["wasAltered"] = true,
                ["newestTime"] = 1633211056,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 334,
                        ["wasKiosk"] = false,
                        ["seller"] = 547,
                        ["timestamp"] = 1633027465,
                        ["quant"] = 1,
                        ["id"] = "1690423497",
                        ["itemLink"] = 685,
                    },
                    [2] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 334,
                        ["wasKiosk"] = false,
                        ["seller"] = 360,
                        ["timestamp"] = 1633049749,
                        ["quant"] = 1,
                        ["id"] = "1690602239",
                        ["itemLink"] = 685,
                    },
                    [3] = 
                    {
                        ["price"] = 1700,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 474,
                        ["timestamp"] = 1633163920,
                        ["quant"] = 1,
                        ["id"] = "1691490377",
                        ["itemLink"] = 685,
                    },
                    [4] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633163921,
                        ["quant"] = 1,
                        ["id"] = "1691490389",
                        ["itemLink"] = 685,
                    },
                    [5] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 1553,
                        ["wasKiosk"] = true,
                        ["seller"] = 1128,
                        ["timestamp"] = 1633211056,
                        ["quant"] = 1,
                        ["id"] = "1691916159",
                        ["itemLink"] = 685,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set mark of the pariah neck healthy",
            },
        },
        [43623] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Bangkorai Treasure Map V",
                ["oldestTime"] = 1633054294,
                ["wasAltered"] = true,
                ["newestTime"] = 1633054294,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 733,
                        ["wasKiosk"] = true,
                        ["seller"] = 86,
                        ["timestamp"] = 1633054294,
                        ["quant"] = 1,
                        ["id"] = "1690648177",
                        ["itemLink"] = 937,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [171880] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 103: Black Fin Legion Belts",
                ["oldestTime"] = 1632885313,
                ["wasAltered"] = true,
                ["newestTime"] = 1633021597,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 55555,
                        ["guild"] = 1,
                        ["buyer"] = 281,
                        ["wasKiosk"] = false,
                        ["seller"] = 93,
                        ["timestamp"] = 1633021597,
                        ["quant"] = 1,
                        ["id"] = "1690379811",
                        ["itemLink"] = 581,
                    },
                    [2] = 
                    {
                        ["price"] = 64000,
                        ["guild"] = 1,
                        ["buyer"] = 2389,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1632885313,
                        ["quant"] = 1,
                        ["id"] = "1689456261",
                        ["itemLink"] = 581,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [126569] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_dae_inc_chest001.dds",
                ["itemDesc"] = "Daedric Chest, Sealed",
                ["oldestTime"] = 1632851153,
                ["wasAltered"] = true,
                ["newestTime"] = 1632895702,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 175,
                        ["wasKiosk"] = false,
                        ["seller"] = 669,
                        ["timestamp"] = 1632851153,
                        ["quant"] = 2,
                        ["id"] = "1689152979",
                        ["itemLink"] = 3240,
                    },
                    [2] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 2432,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1632895702,
                        ["quant"] = 1,
                        ["id"] = "1689533353",
                        ["itemLink"] = 3240,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings suite",
            },
        },
        [43626] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Auridon Treasure Map II",
                ["oldestTime"] = 1632842237,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310225,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633310225,
                        ["quant"] = 1,
                        ["id"] = "1692851243",
                        ["itemLink"] = 2986,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2188,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1632842237,
                        ["quant"] = 1,
                        ["id"] = "1689075257",
                        ["itemLink"] = 2986,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [171883] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 103: Black Fin Legion Chests",
                ["oldestTime"] = 1633021661,
                ["wasAltered"] = true,
                ["newestTime"] = 1633021661,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 179999,
                        ["guild"] = 1,
                        ["buyer"] = 281,
                        ["wasKiosk"] = false,
                        ["seller"] = 451,
                        ["timestamp"] = 1633021661,
                        ["quant"] = 1,
                        ["id"] = "1690380597",
                        ["itemLink"] = 587,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [171372] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_fur_markendtable002.dds",
                ["itemDesc"] = "Dwarven End Table, Columnar Granite",
                ["oldestTime"] = 1633201377,
                ["wasAltered"] = true,
                ["newestTime"] = 1633201377,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1496,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633201377,
                        ["quant"] = 1,
                        ["id"] = "1691804391",
                        ["itemLink"] = 2213,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings dining",
            },
        },
        [90989] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Almalexia's Mercy",
                ["oldestTime"] = 1632988862,
                ["wasAltered"] = true,
                ["newestTime"] = 1632988862,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 339,
                        ["wasKiosk"] = true,
                        ["seller"] = 340,
                        ["timestamp"] = 1632988862,
                        ["quant"] = 1,
                        ["id"] = "1690180261",
                        ["itemLink"] = 342,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set almalexia's mercy ring arcane",
            },
        },
        [82030] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 42: Hollowjack Helmets",
                ["oldestTime"] = 1633037563,
                ["wasAltered"] = true,
                ["newestTime"] = 1633088135,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 42500,
                        ["guild"] = 1,
                        ["buyer"] = 610,
                        ["wasKiosk"] = true,
                        ["seller"] = 611,
                        ["timestamp"] = 1633037563,
                        ["quant"] = 1,
                        ["id"] = "1690495619",
                        ["itemLink"] = 776,
                    },
                    [2] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 450,
                        ["wasKiosk"] = true,
                        ["seller"] = 802,
                        ["timestamp"] = 1633088135,
                        ["quant"] = 1,
                        ["id"] = "1690876835",
                        ["itemLink"] = 776,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [153739] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_jewelry.dds",
                ["itemDesc"] = "Sealed Jewelry Crafter Writ",
                ["oldestTime"] = 1632845844,
                ["wasAltered"] = true,
                ["newestTime"] = 1633239808,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 234,
                        ["timestamp"] = 1632998534,
                        ["quant"] = 1,
                        ["id"] = "1690225325",
                        ["itemLink"] = 389,
                    },
                    [2] = 
                    {
                        ["price"] = 45,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 700,
                        ["timestamp"] = 1633078840,
                        ["quant"] = 1,
                        ["id"] = "1690831193",
                        ["itemLink"] = 1120,
                    },
                    [3] = 
                    {
                        ["price"] = 45,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 700,
                        ["timestamp"] = 1633078860,
                        ["quant"] = 1,
                        ["id"] = "1690831331",
                        ["itemLink"] = 1121,
                    },
                    [4] = 
                    {
                        ["price"] = 99,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633121263,
                        ["quant"] = 1,
                        ["id"] = "1691113753",
                        ["itemLink"] = 1435,
                    },
                    [5] = 
                    {
                        ["price"] = 203,
                        ["guild"] = 1,
                        ["buyer"] = 1095,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633128360,
                        ["quant"] = 1,
                        ["id"] = "1691170183",
                        ["itemLink"] = 1498,
                    },
                    [6] = 
                    {
                        ["price"] = 45,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633156476,
                        ["quant"] = 1,
                        ["id"] = "1691441797",
                        ["itemLink"] = 1747,
                    },
                    [7] = 
                    {
                        ["price"] = 45,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633156661,
                        ["quant"] = 1,
                        ["id"] = "1691443441",
                        ["itemLink"] = 1749,
                    },
                    [8] = 
                    {
                        ["price"] = 45,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633156707,
                        ["quant"] = 1,
                        ["id"] = "1691443911",
                        ["itemLink"] = 1750,
                    },
                    [9] = 
                    {
                        ["price"] = 99,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633156707,
                        ["quant"] = 1,
                        ["id"] = "1691443921",
                        ["itemLink"] = 1751,
                    },
                    [10] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 1285,
                        ["timestamp"] = 1633156708,
                        ["quant"] = 1,
                        ["id"] = "1691443935",
                        ["itemLink"] = 1752,
                    },
                    [11] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 1285,
                        ["timestamp"] = 1633156709,
                        ["quant"] = 1,
                        ["id"] = "1691443945",
                        ["itemLink"] = 1753,
                    },
                    [12] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633156709,
                        ["quant"] = 1,
                        ["id"] = "1691443957",
                        ["itemLink"] = 1754,
                    },
                    [13] = 
                    {
                        ["price"] = 115,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 353,
                        ["timestamp"] = 1633156710,
                        ["quant"] = 1,
                        ["id"] = "1691443967",
                        ["itemLink"] = 1755,
                    },
                    [14] = 
                    {
                        ["price"] = 112,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633156711,
                        ["quant"] = 1,
                        ["id"] = "1691443979",
                        ["itemLink"] = 1756,
                    },
                    [15] = 
                    {
                        ["price"] = 116,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633156712,
                        ["quant"] = 1,
                        ["id"] = "1691443995",
                        ["itemLink"] = 1757,
                    },
                    [16] = 
                    {
                        ["price"] = 116,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633156716,
                        ["quant"] = 1,
                        ["id"] = "1691444057",
                        ["itemLink"] = 1758,
                    },
                    [17] = 
                    {
                        ["price"] = 112,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633156717,
                        ["quant"] = 1,
                        ["id"] = "1691444069",
                        ["itemLink"] = 1759,
                    },
                    [18] = 
                    {
                        ["price"] = 121,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 78,
                        ["timestamp"] = 1633156718,
                        ["quant"] = 1,
                        ["id"] = "1691444077",
                        ["itemLink"] = 1760,
                    },
                    [19] = 
                    {
                        ["price"] = 203,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633156720,
                        ["quant"] = 1,
                        ["id"] = "1691444093",
                        ["itemLink"] = 1761,
                    },
                    [20] = 
                    {
                        ["price"] = 196,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633156721,
                        ["quant"] = 1,
                        ["id"] = "1691444107",
                        ["itemLink"] = 1756,
                    },
                    [21] = 
                    {
                        ["price"] = 203,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633156722,
                        ["quant"] = 1,
                        ["id"] = "1691444121",
                        ["itemLink"] = 1762,
                    },
                    [22] = 
                    {
                        ["price"] = 203,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633156722,
                        ["quant"] = 1,
                        ["id"] = "1691444131",
                        ["itemLink"] = 1763,
                    },
                    [23] = 
                    {
                        ["price"] = 203,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633156723,
                        ["quant"] = 1,
                        ["id"] = "1691444147",
                        ["itemLink"] = 1764,
                    },
                    [24] = 
                    {
                        ["price"] = 196,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633156725,
                        ["quant"] = 1,
                        ["id"] = "1691444171",
                        ["itemLink"] = 1765,
                    },
                    [25] = 
                    {
                        ["price"] = 182,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633156726,
                        ["quant"] = 1,
                        ["id"] = "1691444185",
                        ["itemLink"] = 1766,
                    },
                    [26] = 
                    {
                        ["price"] = 203,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633156727,
                        ["quant"] = 1,
                        ["id"] = "1691444203",
                        ["itemLink"] = 1767,
                    },
                    [27] = 
                    {
                        ["price"] = 117,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 78,
                        ["timestamp"] = 1633239806,
                        ["quant"] = 1,
                        ["id"] = "1692195945",
                        ["itemLink"] = 2525,
                    },
                    [28] = 
                    {
                        ["price"] = 117,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 78,
                        ["timestamp"] = 1633239808,
                        ["quant"] = 1,
                        ["id"] = "1692195971",
                        ["itemLink"] = 2526,
                    },
                    [29] = 
                    {
                        ["price"] = 10,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 54,
                        ["timestamp"] = 1632845844,
                        ["quant"] = 1,
                        ["id"] = "1689108561",
                        ["itemLink"] = 3193,
                    },
                    [30] = 
                    {
                        ["price"] = 45,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1632845846,
                        ["quant"] = 1,
                        ["id"] = "1689108599",
                        ["itemLink"] = 3194,
                    },
                    [31] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 2281,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632869192,
                        ["quant"] = 1,
                        ["id"] = "1689297147",
                        ["itemLink"] = 3373,
                    },
                    [32] = 
                    {
                        ["price"] = 196,
                        ["guild"] = 1,
                        ["buyer"] = 2281,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1632869195,
                        ["quant"] = 1,
                        ["id"] = "1689297169",
                        ["itemLink"] = 3374,
                    },
                    [33] = 
                    {
                        ["price"] = 196,
                        ["guild"] = 1,
                        ["buyer"] = 2281,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1632869196,
                        ["quant"] = 1,
                        ["id"] = "1689297187",
                        ["itemLink"] = 3375,
                    },
                    [34] = 
                    {
                        ["price"] = 196,
                        ["guild"] = 1,
                        ["buyer"] = 2281,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1632869197,
                        ["quant"] = 1,
                        ["id"] = "1689297207",
                        ["itemLink"] = 3376,
                    },
                    [35] = 
                    {
                        ["price"] = 196,
                        ["guild"] = 1,
                        ["buyer"] = 2281,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1632869199,
                        ["quant"] = 1,
                        ["id"] = "1689297219",
                        ["itemLink"] = 3377,
                    },
                    [36] = 
                    {
                        ["price"] = 196,
                        ["guild"] = 1,
                        ["buyer"] = 838,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1632904526,
                        ["quant"] = 1,
                        ["id"] = "1689580497",
                        ["itemLink"] = 3580,
                    },
                    [37] = 
                    {
                        ["price"] = 196,
                        ["guild"] = 1,
                        ["buyer"] = 838,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1632904537,
                        ["quant"] = 1,
                        ["id"] = "1689580549",
                        ["itemLink"] = 3581,
                    },
                    [38] = 
                    {
                        ["price"] = 99,
                        ["guild"] = 1,
                        ["buyer"] = 8,
                        ["wasKiosk"] = false,
                        ["seller"] = 246,
                        ["timestamp"] = 1632961664,
                        ["quant"] = 1,
                        ["id"] = "1689972229",
                        ["itemLink"] = 3925,
                    },
                },
                ["totalCount"] = 38,
                ["itemAdderText"] = "rr01 blue superior consumable master writ",
            },
        },
        [147312] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Lyris Titanborn's Gauntlets",
                ["oldestTime"] = 1632981369,
                ["wasAltered"] = true,
                ["newestTime"] = 1632981369,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 268,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632981369,
                        ["quant"] = 1,
                        ["id"] = "1690138503",
                        ["itemLink"] = 278,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [133055] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nocturnal_medium_feet_a.dds",
                ["itemDesc"] = "Boots of Unfathomable Darkness",
                ["oldestTime"] = 1632922804,
                ["wasAltered"] = true,
                ["newestTime"] = 1632922804,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 105,
                        ["timestamp"] = 1632922804,
                        ["quant"] = 1,
                        ["id"] = "1689672069",
                        ["itemLink"] = 3666,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set unfathomable darkness feet infused",
            },
        },
        [92274] = 
        {
            ["50:16:4:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_bow_d.dds",
                ["itemDesc"] = "Bow of the Twin Sisters",
                ["oldestTime"] = 1632819347,
                ["wasAltered"] = true,
                ["newestTime"] = 1632819347,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 2098,
                        ["wasKiosk"] = true,
                        ["seller"] = 655,
                        ["timestamp"] = 1632819347,
                        ["quant"] = 1,
                        ["id"] = "1688940377",
                        ["itemLink"] = 3009,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set twin sisters bow two-handed infused",
            },
        },
        [43753] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Summerset Treasure Map VI",
                ["oldestTime"] = 1633182515,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182515,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 359,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182515,
                        ["quant"] = 1,
                        ["id"] = "1691608171",
                        ["itemLink"] = 1953,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [172035] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_1hhammer_a.dds",
                ["itemDesc"] = "Mace of Frostbite",
                ["oldestTime"] = 1632914758,
                ["wasAltered"] = true,
                ["newestTime"] = 1632914758,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9870,
                        ["guild"] = 1,
                        ["buyer"] = 2472,
                        ["wasKiosk"] = true,
                        ["seller"] = 626,
                        ["timestamp"] = 1632914758,
                        ["quant"] = 1,
                        ["id"] = "1689621689",
                        ["itemLink"] = 3637,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set frostbite mace one-handed sharpened",
            },
        },
        [58485] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_light_shoulders_a.dds",
                ["itemDesc"] = "Epaulets of the Twice-Born Star",
                ["oldestTime"] = 1633240545,
                ["wasAltered"] = true,
                ["newestTime"] = 1633240545,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1767,
                        ["wasKiosk"] = true,
                        ["seller"] = 832,
                        ["timestamp"] = 1633240545,
                        ["quant"] = 1,
                        ["id"] = "1692201987",
                        ["itemLink"] = 2537,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set twice-born star shoulders divines",
            },
        },
        [87926] = 
        {
            ["50:16:5:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_dagger_a.dds",
                ["itemDesc"] = "Deadly Dagger",
                ["oldestTime"] = 1633101750,
                ["wasAltered"] = true,
                ["newestTime"] = 1633101750,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 969420,
                        ["guild"] = 1,
                        ["buyer"] = 952,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1633101750,
                        ["quant"] = 1,
                        ["id"] = "1690971159",
                        ["itemLink"] = 1287,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary weapon set deadly strike dagger one-handed sharpened",
            },
        },
        [97143] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_dagger_d.dds",
                ["itemDesc"] = "Plague Doctor's Dagger",
                ["oldestTime"] = 1633048900,
                ["wasAltered"] = true,
                ["newestTime"] = 1633048900,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 690,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633048900,
                        ["quant"] = 1,
                        ["id"] = "1690594449",
                        ["itemLink"] = 879,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set plague doctor dagger one-handed charged",
            },
        },
        [71288] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_neck_a.dds",
                ["itemDesc"] = "Locket of the Pariah",
                ["oldestTime"] = 1633163914,
                ["wasAltered"] = true,
                ["newestTime"] = 1633211061,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 360,
                        ["timestamp"] = 1633163914,
                        ["quant"] = 1,
                        ["id"] = "1691490337",
                        ["itemLink"] = 1809,
                    },
                    [2] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633163915,
                        ["quant"] = 1,
                        ["id"] = "1691490341",
                        ["itemLink"] = 1809,
                    },
                    [3] = 
                    {
                        ["price"] = 1550,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 360,
                        ["timestamp"] = 1633163918,
                        ["quant"] = 1,
                        ["id"] = "1691490367",
                        ["itemLink"] = 1809,
                    },
                    [4] = 
                    {
                        ["price"] = 2100,
                        ["guild"] = 1,
                        ["buyer"] = 1553,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633211061,
                        ["quant"] = 1,
                        ["id"] = "1691916203",
                        ["itemLink"] = 1809,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set mark of the pariah neck arcane",
            },
            ["50:16:2:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_neck_a.dds",
                ["itemDesc"] = "Locket of the Pariah",
                ["oldestTime"] = 1633278427,
                ["wasAltered"] = true,
                ["newestTime"] = 1633278427,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 1902,
                        ["wasKiosk"] = true,
                        ["seller"] = 872,
                        ["timestamp"] = 1633278427,
                        ["quant"] = 1,
                        ["id"] = "1692499801",
                        ["itemLink"] = 2718,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set mark of the pariah neck arcane",
            },
        },
        [125694] = 
        {
            ["50:16:5:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Impregnable Armor Necklace",
                ["oldestTime"] = 1632900954,
                ["wasAltered"] = true,
                ["newestTime"] = 1632900954,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 125000,
                        ["guild"] = 1,
                        ["buyer"] = 2446,
                        ["wasKiosk"] = true,
                        ["seller"] = 510,
                        ["timestamp"] = 1632900954,
                        ["quant"] = 1,
                        ["id"] = "1689564541",
                        ["itemLink"] = 3576,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary jewelry apparel set impregnable armor neck arcane",
            },
        },
        [117684] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_fur_varrectangulartablelarge002.dds",
                ["itemDesc"] = "Redguard Table, Sturdy",
                ["oldestTime"] = 1633238252,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238252,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9980,
                        ["guild"] = 1,
                        ["buyer"] = 1745,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1633238252,
                        ["quant"] = 1,
                        ["id"] = "1692187309",
                        ["itemLink"] = 2511,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings dining",
            },
        },
        [76907] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 38: Draugr Staves",
                ["oldestTime"] = 1632883766,
                ["wasAltered"] = true,
                ["newestTime"] = 1632883766,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7019,
                        ["guild"] = 1,
                        ["buyer"] = 2375,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1632883766,
                        ["quant"] = 1,
                        ["id"] = "1689436227",
                        ["itemLink"] = 3491,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45948] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Redoran Peppered Melon",
                ["oldestTime"] = 1633301089,
                ["wasAltered"] = true,
                ["newestTime"] = 1633301089,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 2046,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633301089,
                        ["quant"] = 1,
                        ["id"] = "1692752341",
                        ["itemLink"] = 2915,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [171901] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 101: Ivory Brigade Daggers",
                ["oldestTime"] = 1633027652,
                ["wasAltered"] = true,
                ["newestTime"] = 1633314485,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 61,
                        ["wasKiosk"] = false,
                        ["seller"] = 65,
                        ["timestamp"] = 1633313777,
                        ["quant"] = 1,
                        ["id"] = "1692888515",
                        ["itemLink"] = 49,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 74,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1633314485,
                        ["quant"] = 1,
                        ["id"] = "1692896285",
                        ["itemLink"] = 49,
                    },
                    [3] = 
                    {
                        ["price"] = 8900,
                        ["guild"] = 1,
                        ["buyer"] = 551,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633027652,
                        ["quant"] = 1,
                        ["id"] = "1690425343",
                        ["itemLink"] = 49,
                    },
                    [4] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1127,
                        ["wasKiosk"] = true,
                        ["seller"] = 1128,
                        ["timestamp"] = 1633133959,
                        ["quant"] = 1,
                        ["id"] = "1691230575",
                        ["itemLink"] = 49,
                    },
                    [5] = 
                    {
                        ["price"] = 8900,
                        ["guild"] = 1,
                        ["buyer"] = 151,
                        ["wasKiosk"] = false,
                        ["seller"] = 35,
                        ["timestamp"] = 1633203424,
                        ["quant"] = 1,
                        ["id"] = "1691828067",
                        ["itemLink"] = 49,
                    },
                    [6] = 
                    {
                        ["price"] = 8900,
                        ["guild"] = 1,
                        ["buyer"] = 1570,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633213992,
                        ["quant"] = 1,
                        ["id"] = "1691949253",
                        ["itemLink"] = 49,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [96953] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/container_sealed_polymorph_001.dds",
                ["itemDesc"] = "Runebox: Colovian Filigreed Hood",
                ["oldestTime"] = 1632881882,
                ["wasAltered"] = true,
                ["newestTime"] = 1632881882,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 2364,
                        ["wasKiosk"] = true,
                        ["seller"] = 1510,
                        ["timestamp"] = 1632881882,
                        ["quant"] = 1,
                        ["id"] = "1689416747",
                        ["itemLink"] = 3472,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable container",
            },
        },
        [139020] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_cloth_sap.dds",
                ["itemDesc"] = "Clam Gall",
                ["oldestTime"] = 1632853420,
                ["wasAltered"] = true,
                ["newestTime"] = 1633276846,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5400,
                        ["guild"] = 1,
                        ["buyer"] = 538,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633024696,
                        ["quant"] = 2,
                        ["id"] = "1690404273",
                        ["itemLink"] = 677,
                    },
                    [2] = 
                    {
                        ["price"] = 54000,
                        ["guild"] = 1,
                        ["buyer"] = 857,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633074035,
                        ["quant"] = 20,
                        ["id"] = "1690804565",
                        ["itemLink"] = 677,
                    },
                    [3] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 857,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633074045,
                        ["quant"] = 10,
                        ["id"] = "1690804679",
                        ["itemLink"] = 677,
                    },
                    [4] = 
                    {
                        ["price"] = 2700,
                        ["guild"] = 1,
                        ["buyer"] = 7,
                        ["wasKiosk"] = false,
                        ["seller"] = 179,
                        ["timestamp"] = 1633276846,
                        ["quant"] = 1,
                        ["id"] = "1692484501",
                        ["itemLink"] = 677,
                    },
                    [5] = 
                    {
                        ["price"] = 58000,
                        ["guild"] = 1,
                        ["buyer"] = 7,
                        ["wasKiosk"] = false,
                        ["seller"] = 31,
                        ["timestamp"] = 1632853420,
                        ["quant"] = 20,
                        ["id"] = "1689170603",
                        ["itemLink"] = 677,
                    },
                    [6] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 538,
                        ["wasKiosk"] = true,
                        ["seller"] = 649,
                        ["timestamp"] = 1632867407,
                        ["quant"] = 5,
                        ["id"] = "1689283737",
                        ["itemLink"] = 677,
                    },
                    [7] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 538,
                        ["wasKiosk"] = true,
                        ["seller"] = 224,
                        ["timestamp"] = 1632867410,
                        ["quant"] = 5,
                        ["id"] = "1689283747",
                        ["itemLink"] = 677,
                    },
                    [8] = 
                    {
                        ["price"] = 150000,
                        ["guild"] = 1,
                        ["buyer"] = 2296,
                        ["wasKiosk"] = true,
                        ["seller"] = 513,
                        ["timestamp"] = 1632871646,
                        ["quant"] = 50,
                        ["id"] = "1689313909",
                        ["itemLink"] = 677,
                    },
                    [9] = 
                    {
                        ["price"] = 6004,
                        ["guild"] = 1,
                        ["buyer"] = 2368,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1632882604,
                        ["quant"] = 2,
                        ["id"] = "1689424409",
                        ["itemLink"] = 677,
                    },
                },
                ["totalCount"] = 9,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [119382] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing2.dds",
                ["itemDesc"] = "Diagram: Common Inkwell, Practical",
                ["oldestTime"] = 1633040321,
                ["wasAltered"] = true,
                ["newestTime"] = 1633040321,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 623,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633040321,
                        ["quant"] = 1,
                        ["id"] = "1690515703",
                        ["itemLink"] = 790,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [171795] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting2.dds",
                ["itemDesc"] = "Praxis: Markarth Stairway, Narrow Stone",
                ["oldestTime"] = 1632877839,
                ["wasAltered"] = true,
                ["newestTime"] = 1632930604,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2340,
                        ["wasKiosk"] = true,
                        ["seller"] = 271,
                        ["timestamp"] = 1632877839,
                        ["quant"] = 1,
                        ["id"] = "1689371071",
                        ["itemLink"] = 3435,
                    },
                    [2] = 
                    {
                        ["price"] = 2300,
                        ["guild"] = 1,
                        ["buyer"] = 2194,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632930604,
                        ["quant"] = 1,
                        ["id"] = "1689726565",
                        ["itemLink"] = 3435,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [71554] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 22: Trinimac Bows",
                ["oldestTime"] = 1632876042,
                ["wasAltered"] = true,
                ["newestTime"] = 1632906324,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14900,
                        ["guild"] = 1,
                        ["buyer"] = 2327,
                        ["wasKiosk"] = true,
                        ["seller"] = 633,
                        ["timestamp"] = 1632876042,
                        ["quant"] = 1,
                        ["id"] = "1689352309",
                        ["itemLink"] = 3423,
                    },
                    [2] = 
                    {
                        ["price"] = 7777,
                        ["guild"] = 1,
                        ["buyer"] = 2453,
                        ["wasKiosk"] = true,
                        ["seller"] = 315,
                        ["timestamp"] = 1632906324,
                        ["quant"] = 1,
                        ["id"] = "1689588273",
                        ["itemLink"] = 3423,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [56963] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Mistral Banana Bread",
                ["oldestTime"] = 1632881807,
                ["wasAltered"] = true,
                ["newestTime"] = 1633011817,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633011817,
                        ["quant"] = 1,
                        ["id"] = "1690302839",
                        ["itemLink"] = 522,
                    },
                    [2] = 
                    {
                        ["price"] = 253,
                        ["guild"] = 1,
                        ["buyer"] = 2362,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1632881807,
                        ["quant"] = 1,
                        ["id"] = "1689415529",
                        ["itemLink"] = 522,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [123012] = 
        {
            ["50:16:2:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_hlaalu_bow_a.dds",
                ["itemDesc"] = "Defiler's Bow",
                ["oldestTime"] = 1633053264,
                ["wasAltered"] = true,
                ["newestTime"] = 1633053264,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 724,
                        ["wasKiosk"] = true,
                        ["seller"] = 256,
                        ["timestamp"] = 1633053264,
                        ["quant"] = 1,
                        ["id"] = "1690638785",
                        ["itemLink"] = 929,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set defiler bow two-handed powered",
            },
        },
        [45701] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Twenty-Four-Raven Pie",
                ["oldestTime"] = 1633305811,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305811,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3999,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633305811,
                        ["quant"] = 1,
                        ["id"] = "1692798447",
                        ["itemLink"] = 2934,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [154956] = 
        {
            ["50:16:2:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_shieldssenchalhvy_shoulders_a.dds",
                ["itemDesc"] = "Senchal Defender's Pauldrons",
                ["oldestTime"] = 1632877219,
                ["wasAltered"] = true,
                ["newestTime"] = 1632877219,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 2333,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632877219,
                        ["quant"] = 1,
                        ["id"] = "1689363765",
                        ["itemLink"] = 3431,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set senchal defender shoulders invigorating",
            },
        },
        [43655] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Stonefalls Treasure Map I",
                ["oldestTime"] = 1633078812,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310220,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 409,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 647,
                        ["timestamp"] = 1633078812,
                        ["quant"] = 1,
                        ["id"] = "1690831003",
                        ["itemLink"] = 1119,
                    },
                    [2] = 
                    {
                        ["price"] = 433,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633310220,
                        ["quant"] = 1,
                        ["id"] = "1692851215",
                        ["itemLink"] = 1119,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [86680] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_legs_d.dds",
                ["itemDesc"] = "Greaves of the Storm Knight",
                ["oldestTime"] = 1632876073,
                ["wasAltered"] = true,
                ["newestTime"] = 1632876073,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 1600,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1632876073,
                        ["quant"] = 1,
                        ["id"] = "1689352517",
                        ["itemLink"] = 3424,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set storm knight's plate legs invigorating",
            },
        },
        [153737] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_jewelry.dds",
                ["itemDesc"] = "Sealed Jewelry Crafter Writ",
                ["oldestTime"] = 1632924290,
                ["wasAltered"] = true,
                ["newestTime"] = 1633285659,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 995,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1633105310,
                        ["quant"] = 1,
                        ["id"] = "1691004263",
                        ["itemLink"] = 1294,
                    },
                    [2] = 
                    {
                        ["price"] = 2150,
                        ["guild"] = 1,
                        ["buyer"] = 196,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1633120077,
                        ["quant"] = 1,
                        ["id"] = "1691105489",
                        ["itemLink"] = 1431,
                    },
                    [3] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633154277,
                        ["quant"] = 1,
                        ["id"] = "1691425957",
                        ["itemLink"] = 1740,
                    },
                    [4] = 
                    {
                        ["price"] = 3030,
                        ["guild"] = 1,
                        ["buyer"] = 1951,
                        ["wasKiosk"] = true,
                        ["seller"] = 327,
                        ["timestamp"] = 1633285652,
                        ["quant"] = 1,
                        ["id"] = "1692572901",
                        ["itemLink"] = 2754,
                    },
                    [5] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1951,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1633285659,
                        ["quant"] = 1,
                        ["id"] = "1692573003",
                        ["itemLink"] = 2755,
                    },
                    [6] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2495,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632924290,
                        ["quant"] = 1,
                        ["id"] = "1689681505",
                        ["itemLink"] = 3680,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [71306] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_neck_a.dds",
                ["itemDesc"] = "Locket of the Pariah",
                ["oldestTime"] = 1633163921,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163921,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1838,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633163921,
                        ["quant"] = 1,
                        ["id"] = "1691490383",
                        ["itemLink"] = 1819,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set mark of the pariah neck robust",
            },
            ["50:16:2:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_neck_a.dds",
                ["itemDesc"] = "Locket of the Pariah",
                ["oldestTime"] = 1633049742,
                ["wasAltered"] = true,
                ["newestTime"] = 1633049742,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 334,
                        ["wasKiosk"] = false,
                        ["seller"] = 243,
                        ["timestamp"] = 1633049742,
                        ["quant"] = 1,
                        ["id"] = "1690602163",
                        ["itemLink"] = 883,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set mark of the pariah neck robust",
            },
        },
        [68491] = 
        {
            ["50:16:5:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_snowreach_medium_chest_a.dds",
                ["itemDesc"] = "Briarheart Jack",
                ["oldestTime"] = 1633083261,
                ["wasAltered"] = true,
                ["newestTime"] = 1633153103,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150000,
                        ["guild"] = 1,
                        ["buyer"] = 891,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633083261,
                        ["quant"] = 1,
                        ["id"] = "1690851407",
                        ["itemLink"] = 1140,
                    },
                    [2] = 
                    {
                        ["price"] = 159000,
                        ["guild"] = 1,
                        ["buyer"] = 1270,
                        ["wasKiosk"] = true,
                        ["seller"] = 981,
                        ["timestamp"] = 1633153103,
                        ["quant"] = 1,
                        ["id"] = "1691416765",
                        ["itemLink"] = 1140,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 gold legendary medium apparel set briarheart chest divines",
            },
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_snowreach_medium_chest_a.dds",
                ["itemDesc"] = "Briarheart Jack",
                ["oldestTime"] = 1632877306,
                ["wasAltered"] = true,
                ["newestTime"] = 1632877306,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2334,
                        ["wasKiosk"] = true,
                        ["seller"] = 691,
                        ["timestamp"] = 1632877306,
                        ["quant"] = 1,
                        ["id"] = "1689364789",
                        ["itemLink"] = 3432,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set briarheart chest divines",
            },
        },
        [172940] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_light_feet_d.dds",
                ["itemDesc"] = "Heartland Conqueror's Shoes",
                ["oldestTime"] = 1633216229,
                ["wasAltered"] = true,
                ["newestTime"] = 1633216229,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 1588,
                        ["wasKiosk"] = true,
                        ["seller"] = 261,
                        ["timestamp"] = 1633216229,
                        ["quant"] = 1,
                        ["id"] = "1691970757",
                        ["itemLink"] = 2318,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set heartland conqueror feet divines",
            },
        },
        [100237] = 
        {
            ["50:16:3:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_2hhammer_d.dds",
                ["itemDesc"] = "Fiord's Maul",
                ["oldestTime"] = 1632930081,
                ["wasAltered"] = true,
                ["newestTime"] = 1632930081,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2250,
                        ["guild"] = 1,
                        ["buyer"] = 2512,
                        ["wasKiosk"] = true,
                        ["seller"] = 697,
                        ["timestamp"] = 1632930081,
                        ["quant"] = 1,
                        ["id"] = "1689722691",
                        ["itemLink"] = 3698,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set fiord's legacy mace two-handed powered",
            },
        },
        [118926] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: High Elf Counter, Block",
                ["oldestTime"] = 1633227067,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227067,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 1657,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633227067,
                        ["quant"] = 1,
                        ["id"] = "1692085885",
                        ["itemLink"] = 2400,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [176015] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning4.dds",
                ["itemDesc"] = "Design: Leyawiin Pie, Octopus",
                ["oldestTime"] = 1633060797,
                ["wasAltered"] = true,
                ["newestTime"] = 1633060797,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 375000,
                        ["guild"] = 1,
                        ["buyer"] = 379,
                        ["wasKiosk"] = false,
                        ["seller"] = 514,
                        ["timestamp"] = 1633060797,
                        ["quant"] = 1,
                        ["id"] = "1690716999",
                        ["itemLink"] = 1023,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [51600] = 
        {
            ["50:16:4:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_2hsword_c.dds",
                ["itemDesc"] = "Greatsword of Hunding's Rage",
                ["oldestTime"] = 1633137092,
                ["wasAltered"] = true,
                ["newestTime"] = 1633137092,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 1160,
                        ["wasKiosk"] = true,
                        ["seller"] = 1161,
                        ["timestamp"] = 1633137092,
                        ["quant"] = 1,
                        ["id"] = "1691263275",
                        ["itemLink"] = 1579,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set hunding's rage sword two-handed infused",
            },
        },
        [97425] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_medium_hands_d.dds",
                ["itemDesc"] = "Bracers of the Wilderqueen",
                ["oldestTime"] = 1633210500,
                ["wasAltered"] = true,
                ["newestTime"] = 1633210500,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1335,
                        ["guild"] = 1,
                        ["buyer"] = 1368,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1633210500,
                        ["quant"] = 1,
                        ["id"] = "1691910213",
                        ["itemLink"] = 2274,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set wilderqueen's arch hands infused",
            },
        },
        [159476] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Style Page: Jephrine Paladin Gauntlets",
                ["oldestTime"] = 1632861827,
                ["wasAltered"] = true,
                ["newestTime"] = 1632861827,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2249,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632861827,
                        ["quant"] = 1,
                        ["id"] = "1689243273",
                        ["itemLink"] = 3310,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [139411] = 
        {
            ["1:0:1:33:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_enchantment_base_jade_r1.dds",
                ["itemDesc"] = "Aurbic Amber",
                ["oldestTime"] = 1632848263,
                ["wasAltered"] = true,
                ["newestTime"] = 1633288216,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 29000,
                        ["guild"] = 1,
                        ["buyer"] = 1179,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633140011,
                        ["quant"] = 1,
                        ["id"] = "1691290357",
                        ["itemLink"] = 1594,
                    },
                    [2] = 
                    {
                        ["price"] = 28999,
                        ["guild"] = 1,
                        ["buyer"] = 1694,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633231212,
                        ["quant"] = 1,
                        ["id"] = "1692125859",
                        ["itemLink"] = 1594,
                    },
                    [3] = 
                    {
                        ["price"] = 28999,
                        ["guild"] = 1,
                        ["buyer"] = 1694,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633231214,
                        ["quant"] = 1,
                        ["id"] = "1692125897",
                        ["itemLink"] = 1594,
                    },
                    [4] = 
                    {
                        ["price"] = 26998,
                        ["guild"] = 1,
                        ["buyer"] = 1889,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633272858,
                        ["quant"] = 1,
                        ["id"] = "1692435841",
                        ["itemLink"] = 1594,
                    },
                    [5] = 
                    {
                        ["price"] = 26998,
                        ["guild"] = 1,
                        ["buyer"] = 1970,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633288216,
                        ["quant"] = 1,
                        ["id"] = "1692606849",
                        ["itemLink"] = 1594,
                    },
                    [6] = 
                    {
                        ["price"] = 30722,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1632848263,
                        ["quant"] = 1,
                        ["id"] = "1689130355",
                        ["itemLink"] = 1594,
                    },
                    [7] = 
                    {
                        ["price"] = 30381,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 2123,
                        ["timestamp"] = 1632848264,
                        ["quant"] = 1,
                        ["id"] = "1689130357",
                        ["itemLink"] = 1594,
                    },
                    [8] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632848265,
                        ["quant"] = 1,
                        ["id"] = "1689130365",
                        ["itemLink"] = 1594,
                    },
                    [9] = 
                    {
                        ["price"] = 32284,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1632848266,
                        ["quant"] = 1,
                        ["id"] = "1689130367",
                        ["itemLink"] = 1594,
                    },
                    [10] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632848266,
                        ["quant"] = 1,
                        ["id"] = "1689130369",
                        ["itemLink"] = 1594,
                    },
                    [11] = 
                    {
                        ["price"] = 29910,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1632848267,
                        ["quant"] = 1,
                        ["id"] = "1689130375",
                        ["itemLink"] = 1594,
                    },
                    [12] = 
                    {
                        ["price"] = 29910,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1632848268,
                        ["quant"] = 1,
                        ["id"] = "1689130379",
                        ["itemLink"] = 1594,
                    },
                },
                ["totalCount"] = 12,
                ["itemAdderText"] = "rr01 white normal materials jewelry trait infused",
            },
        },
        [100472] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_staff_d.dds",
                ["itemDesc"] = "Vampire Lord's Restoration Staff",
                ["oldestTime"] = 1632861593,
                ["wasAltered"] = true,
                ["newestTime"] = 1632861593,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2248,
                        ["wasKiosk"] = true,
                        ["seller"] = 474,
                        ["timestamp"] = 1632861593,
                        ["quant"] = 1,
                        ["id"] = "1689241737",
                        ["itemLink"] = 3307,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set vampire lord healing staff two-handed defending",
            },
        },
        [114984] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_mazzatun_r2.dds",
                ["itemDesc"] = "Leviathan Scrimshaw",
                ["oldestTime"] = 1632861557,
                ["wasAltered"] = true,
                ["newestTime"] = 1632861557,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632861557,
                        ["quant"] = 3,
                        ["id"] = "1689241495",
                        ["itemLink"] = 3303,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [117130] = 
        {
            ["50:16:4:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_1hhammer_a.dds",
                ["itemDesc"] = "Mace of the Powerful Assault",
                ["oldestTime"] = 1632855004,
                ["wasAltered"] = true,
                ["newestTime"] = 1632855004,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 2161,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1632855004,
                        ["quant"] = 1,
                        ["id"] = "1689183825",
                        ["itemLink"] = 3263,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set powerful assault mace one-handed precise",
            },
        },
        [153738] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_jewelry.dds",
                ["itemDesc"] = "Sealed Jewelry Crafter Writ",
                ["oldestTime"] = 1632844702,
                ["wasAltered"] = true,
                ["newestTime"] = 1632844702,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 2192,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1632844702,
                        ["quant"] = 1,
                        ["id"] = "1689097069",
                        ["itemLink"] = 3188,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable master writ",
            },
        },
        [171928] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/style_item_sul-xan.dds",
                ["itemDesc"] = "Death-Hopper Vocal Sac",
                ["oldestTime"] = 1633128689,
                ["wasAltered"] = true,
                ["newestTime"] = 1633252507,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1096,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633128689,
                        ["quant"] = 1,
                        ["id"] = "1691172663",
                        ["itemLink"] = 1499,
                    },
                    [2] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1096,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633128690,
                        ["quant"] = 1,
                        ["id"] = "1691172671",
                        ["itemLink"] = 1499,
                    },
                    [3] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1096,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633128691,
                        ["quant"] = 1,
                        ["id"] = "1691172693",
                        ["itemLink"] = 1499,
                    },
                    [4] = 
                    {
                        ["price"] = 1700,
                        ["guild"] = 1,
                        ["buyer"] = 1096,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633128694,
                        ["quant"] = 2,
                        ["id"] = "1691172717",
                        ["itemLink"] = 1499,
                    },
                    [5] = 
                    {
                        ["price"] = 2300,
                        ["guild"] = 1,
                        ["buyer"] = 387,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633179773,
                        ["quant"] = 3,
                        ["id"] = "1691583925",
                        ["itemLink"] = 1499,
                    },
                    [6] = 
                    {
                        ["price"] = 880,
                        ["guild"] = 1,
                        ["buyer"] = 1823,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633252507,
                        ["quant"] = 1,
                        ["id"] = "1692288795",
                        ["itemLink"] = 1499,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [68239] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_soup_002.dds",
                ["itemDesc"] = "Hearty Garlic Corn Chowder",
                ["oldestTime"] = 1632840193,
                ["wasAltered"] = true,
                ["newestTime"] = 1632840193,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45,
                        ["guild"] = 1,
                        ["buyer"] = 2175,
                        ["wasKiosk"] = true,
                        ["seller"] = 2176,
                        ["timestamp"] = 1632840193,
                        ["quant"] = 3,
                        ["id"] = "1689061457",
                        ["itemLink"] = 3147,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 green fine consumable food",
            },
        },
        [87962] = 
        {
            ["50:16:4:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_2haxe_a.dds",
                ["itemDesc"] = "Deadly Battle Axe",
                ["oldestTime"] = 1632996910,
                ["wasAltered"] = true,
                ["newestTime"] = 1632996910,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 384,
                        ["wasKiosk"] = true,
                        ["seller"] = 356,
                        ["timestamp"] = 1632996910,
                        ["quant"] = 1,
                        ["id"] = "1690217351",
                        ["itemLink"] = 383,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set deadly strike axe two-handed training",
            },
        },
        [27035] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_wood_gum.dds",
                ["itemDesc"] = "Isinglass",
                ["oldestTime"] = 1632861578,
                ["wasAltered"] = true,
                ["newestTime"] = 1633042295,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 648,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633042295,
                        ["quant"] = 200,
                        ["id"] = "1690531013",
                        ["itemLink"] = 818,
                    },
                    [2] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1632861578,
                        ["quant"] = 200,
                        ["id"] = "1689241599",
                        ["itemLink"] = 818,
                    },
                    [3] = 
                    {
                        ["price"] = 825,
                        ["guild"] = 1,
                        ["buyer"] = 2489,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1632921486,
                        ["quant"] = 100,
                        ["id"] = "1689661339",
                        ["itemLink"] = 818,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [155292] = 
        {
            ["50:16:4:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dragonguardmed_hands_a.dds",
                ["itemDesc"] = "Dragonguard Elite's Bracers",
                ["oldestTime"] = 1632936843,
                ["wasAltered"] = true,
                ["newestTime"] = 1632936843,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 226,
                        ["wasKiosk"] = false,
                        ["seller"] = 107,
                        ["timestamp"] = 1632936843,
                        ["quant"] = 1,
                        ["id"] = "1689774067",
                        ["itemLink"] = 3748,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set dragonguard elite hands reinforced",
            },
        },
        [175773] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_str_leydetachableplantershousing001.dds",
                ["itemDesc"] = "Leyawiin Windowbox, Yellow Daisies",
                ["oldestTime"] = 1633301035,
                ["wasAltered"] = true,
                ["newestTime"] = 1633301035,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 2045,
                        ["wasKiosk"] = true,
                        ["seller"] = 622,
                        ["timestamp"] = 1633301035,
                        ["quant"] = 1,
                        ["id"] = "1692751567",
                        ["itemLink"] = 2914,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings conservatory",
            },
        },
        [155022] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Amulet of Marauder's Haste",
                ["oldestTime"] = 1632839094,
                ["wasAltered"] = true,
                ["newestTime"] = 1632839094,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 499,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1632839094,
                        ["quant"] = 1,
                        ["id"] = "1689055139",
                        ["itemLink"] = 3127,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set marauder's haste neck arcane",
            },
        },
        [180725] = 
        {
            ["50:16:4:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_2haxe_a.dds",
                ["itemDesc"] = "Plaguebreak Battle Axe",
                ["oldestTime"] = 1633237402,
                ["wasAltered"] = true,
                ["newestTime"] = 1633237402,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 1569,
                        ["wasKiosk"] = true,
                        ["seller"] = 48,
                        ["timestamp"] = 1633237402,
                        ["quant"] = 1,
                        ["id"] = "1692179663",
                        ["itemLink"] = 2498,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set plaguebreak axe two-handed decisive",
            },
        },
        [118133] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_exc_varmarketproducepile001.dds",
                ["itemDesc"] = "Plums, Bunch",
                ["oldestTime"] = 1632824858,
                ["wasAltered"] = true,
                ["newestTime"] = 1632824858,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 2114,
                        ["wasKiosk"] = true,
                        ["seller"] = 17,
                        ["timestamp"] = 1632824858,
                        ["quant"] = 1,
                        ["id"] = "1688963469",
                        ["itemLink"] = 3019,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings hearth",
            },
        },
        [68513] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_snowreach_medium_chest_a.dds",
                ["itemDesc"] = "Briarheart Jack",
                ["oldestTime"] = 1633023046,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023046,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633023046,
                        ["quant"] = 1,
                        ["id"] = "1690391029",
                        ["itemLink"] = 669,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set briarheart chest reinforced",
            },
        },
        [172194] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_staff_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Restoration Staff",
                ["oldestTime"] = 1633180220,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261559,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1363,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633180220,
                        ["quant"] = 1,
                        ["id"] = "1691586797",
                        ["itemLink"] = 1924,
                    },
                    [2] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 1840,
                        ["wasKiosk"] = true,
                        ["seller"] = 50,
                        ["timestamp"] = 1633261559,
                        ["quant"] = 1,
                        ["id"] = "1692334221",
                        ["itemLink"] = 1924,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior weapon set deadlands assassin healing staff two-handed defending",
            },
        },
        [125475] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_researchscroll_woodworking.dds",
                ["itemDesc"] = "Research Scroll, Woodworking, 1 Day",
                ["oldestTime"] = 1632948865,
                ["wasAltered"] = true,
                ["newestTime"] = 1633304175,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9998,
                        ["guild"] = 1,
                        ["buyer"] = 2054,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633304175,
                        ["quant"] = 2,
                        ["id"] = "1692781303",
                        ["itemLink"] = 2923,
                    },
                    [2] = 
                    {
                        ["price"] = 9998,
                        ["guild"] = 1,
                        ["buyer"] = 745,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632948865,
                        ["quant"] = 2,
                        ["id"] = "1689864447",
                        ["itemLink"] = 2923,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary consumable trophy",
            },
        },
        [57603] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 18: Akaviri Staves",
                ["oldestTime"] = 1633299147,
                ["wasAltered"] = true,
                ["newestTime"] = 1633299147,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 2036,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633299147,
                        ["quant"] = 1,
                        ["id"] = "1692733365",
                        ["itemLink"] = 2908,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [170149] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Rkindaleft Dwarven Battle Axe",
                ["oldestTime"] = 1632948943,
                ["wasAltered"] = true,
                ["newestTime"] = 1632948943,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 2333,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1632948943,
                        ["quant"] = 1,
                        ["id"] = "1689865131",
                        ["itemLink"] = 3802,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [176294] = 
        {
            ["1:0:3:45:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_belt_light.dds",
                ["itemDesc"] = "Companion's Sash",
                ["oldestTime"] = 1633064909,
                ["wasAltered"] = true,
                ["newestTime"] = 1633064909,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 811,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1633064909,
                        ["quant"] = 1,
                        ["id"] = "1690746669",
                        ["itemLink"] = 1057,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior light apparel waist focused",
            },
        },
        [156483] = 
        {
            ["20:0:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_medium_head_b.dds",
                ["itemDesc"] = "New Moon Acolyte's Helmet",
                ["oldestTime"] = 1633293705,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293705,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 266,
                        ["timestamp"] = 1633293705,
                        ["quant"] = 1,
                        ["id"] = "1692672195",
                        ["itemLink"] = 2857,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr20 blue superior medium apparel set new moon acolyte head training",
            },
        },
        [142504] = 
        {
            ["50:16:5:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_deadwater_2hmace_a.dds",
                ["itemDesc"] = "Dead-Water's Guile Maul",
                ["oldestTime"] = 1633061583,
                ["wasAltered"] = true,
                ["newestTime"] = 1633061583,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 145000,
                        ["guild"] = 1,
                        ["buyer"] = 54,
                        ["wasKiosk"] = false,
                        ["seller"] = 211,
                        ["timestamp"] = 1633061583,
                        ["quant"] = 1,
                        ["id"] = "1690721899",
                        ["itemLink"] = 1029,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary weapon set dead-water's guile mace two-handed sharpened",
            },
        },
        [176783] = 
        {
            ["1:0:4:39:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_maul.dds",
                ["itemDesc"] = "Companion's Maul",
                ["oldestTime"] = 1633292833,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292833,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 1994,
                        ["wasKiosk"] = true,
                        ["seller"] = 232,
                        ["timestamp"] = 1633292833,
                        ["quant"] = 1,
                        ["id"] = "1692661475",
                        ["itemLink"] = 2847,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic weapon mace two-handed soothing",
            },
        },
        [69290] = 
        {
            ["50:16:4:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_staff_d.dds",
                ["itemDesc"] = "Ice Staff of Agility",
                ["oldestTime"] = 1632977842,
                ["wasAltered"] = true,
                ["newestTime"] = 1632977842,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 945,
                        ["guild"] = 1,
                        ["buyer"] = 245,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1632977842,
                        ["quant"] = 1,
                        ["id"] = "1690117133",
                        ["itemLink"] = 246,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set agility frost staff two-handed infused",
            },
        },
        [181566] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Leyawiin Wall, Castle Door Arch",
                ["oldestTime"] = 1633292262,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292262,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633292262,
                        ["quant"] = 1,
                        ["id"] = "1692654539",
                        ["itemLink"] = 2815,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [86188] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Withered Hand",
                ["oldestTime"] = 1633113811,
                ["wasAltered"] = true,
                ["newestTime"] = 1633113811,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 916,
                        ["guild"] = 1,
                        ["buyer"] = 1003,
                        ["wasKiosk"] = true,
                        ["seller"] = 1004,
                        ["timestamp"] = 1633113811,
                        ["quant"] = 1,
                        ["id"] = "1691064289",
                        ["itemLink"] = 1365,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set robes of the withered hand ring arcane",
            },
        },
        [64685] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_humanoid_daedra_void_salts.dds",
                ["itemDesc"] = "Ferrous Salts",
                ["oldestTime"] = 1632970329,
                ["wasAltered"] = true,
                ["newestTime"] = 1632970329,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 165,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632970329,
                        ["quant"] = 5,
                        ["id"] = "1690059825",
                        ["itemLink"] = 176,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [134318] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_cwc_con_cargobarrel003.dds",
                ["itemDesc"] = "Clockwork Keg, Sturdy",
                ["oldestTime"] = 1633124513,
                ["wasAltered"] = true,
                ["newestTime"] = 1633124513,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16223,
                        ["guild"] = 1,
                        ["buyer"] = 715,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1633124513,
                        ["quant"] = 1,
                        ["id"] = "1691138243",
                        ["itemLink"] = 1463,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings hearth",
            },
        },
        [154845] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_shieldsenchal_bow_a.dds",
                ["itemDesc"] = "Senchal Defender's Bow",
                ["oldestTime"] = 1633292052,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292052,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 107,
                        ["timestamp"] = 1633292052,
                        ["quant"] = 1,
                        ["id"] = "1692652237",
                        ["itemLink"] = 2805,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set senchal defender bow two-handed infused",
            },
        },
        [144526] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_medium_waist_a.dds",
                ["itemDesc"] = "Soldier of Anguish Belt",
                ["oldestTime"] = 1633291951,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291951,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 47,
                        ["timestamp"] = 1633291951,
                        ["quant"] = 1,
                        ["id"] = "1692651247",
                        ["itemLink"] = 2800,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set soldier of anguish waist well-fitted",
            },
        },
        [27057] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_trollfat_001.dds",
                ["itemDesc"] = "Cheese",
                ["oldestTime"] = 1632824160,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305828,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 648,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633042304,
                        ["quant"] = 200,
                        ["id"] = "1690531089",
                        ["itemLink"] = 822,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1633305827,
                        ["quant"] = 100,
                        ["id"] = "1692798663",
                        ["itemLink"] = 822,
                    },
                    [3] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633305828,
                        ["quant"] = 200,
                        ["id"] = "1692798677",
                        ["itemLink"] = 822,
                    },
                    [4] = 
                    {
                        ["price"] = 1700,
                        ["guild"] = 1,
                        ["buyer"] = 2113,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632824160,
                        ["quant"] = 200,
                        ["id"] = "1688960693",
                        ["itemLink"] = 822,
                    },
                    [5] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 649,
                        ["timestamp"] = 1632861578,
                        ["quant"] = 200,
                        ["id"] = "1689241595",
                        ["itemLink"] = 822,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [115864] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Wood Elf Table, Formal",
                ["oldestTime"] = 1633290968,
                ["wasAltered"] = true,
                ["newestTime"] = 1633290968,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 288,
                        ["timestamp"] = 1633290968,
                        ["quant"] = 1,
                        ["id"] = "1692637929",
                        ["itemLink"] = 2789,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [173573] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Style Page: Maarselok Shoulder",
                ["oldestTime"] = 1633276301,
                ["wasAltered"] = true,
                ["newestTime"] = 1633276301,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 225000,
                        ["guild"] = 1,
                        ["buyer"] = 1903,
                        ["wasKiosk"] = true,
                        ["seller"] = 732,
                        ["timestamp"] = 1633276301,
                        ["quant"] = 1,
                        ["id"] = "1692478379",
                        ["itemLink"] = 2702,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [133556] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_skillet_001.dds",
                ["itemDesc"] = "Clockwork Citrus Filet",
                ["oldestTime"] = 1632820997,
                ["wasAltered"] = true,
                ["newestTime"] = 1633129224,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15484,
                        ["guild"] = 1,
                        ["buyer"] = 183,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1632971462,
                        ["quant"] = 1,
                        ["id"] = "1690072009",
                        ["itemLink"] = 196,
                    },
                    [2] = 
                    {
                        ["price"] = 15484,
                        ["guild"] = 1,
                        ["buyer"] = 967,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633129224,
                        ["quant"] = 1,
                        ["id"] = "1691177669",
                        ["itemLink"] = 196,
                    },
                    [3] = 
                    {
                        ["price"] = 150000,
                        ["guild"] = 1,
                        ["buyer"] = 2104,
                        ["wasKiosk"] = true,
                        ["seller"] = 479,
                        ["timestamp"] = 1632820997,
                        ["quant"] = 10,
                        ["id"] = "1688948051",
                        ["itemLink"] = 196,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 gold legendary consumable food",
            },
        },
        [100295] = 
        {
            ["50:16:3:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_1hsword_d.dds",
                ["itemDesc"] = "Fiord's Sword",
                ["oldestTime"] = 1633273829,
                ["wasAltered"] = true,
                ["newestTime"] = 1633273829,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1894,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1633273829,
                        ["quant"] = 1,
                        ["id"] = "1692448051",
                        ["itemLink"] = 2689,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set fiord's legacy sword one-handed sharpened",
            },
        },
        [126839] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Daedric Platform, Ashen",
                ["oldestTime"] = 1633266483,
                ["wasAltered"] = true,
                ["newestTime"] = 1633266483,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1857,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633266483,
                        ["quant"] = 1,
                        ["id"] = "1692371323",
                        ["itemLink"] = 2639,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [130031] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 79: Refabricated Chests",
                ["oldestTime"] = 1633261785,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261785,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 1327,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1633261785,
                        ["quant"] = 1,
                        ["id"] = "1692336063",
                        ["itemLink"] = 2630,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [161149] = 
        {
            ["50:16:4:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_grayhost_hammer_a.dds",
                ["itemDesc"] = "Mace of Eternal Vigor",
                ["oldestTime"] = 1633243408,
                ["wasAltered"] = true,
                ["newestTime"] = 1633243408,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1368,
                        ["wasKiosk"] = true,
                        ["seller"] = 474,
                        ["timestamp"] = 1633243408,
                        ["quant"] = 1,
                        ["id"] = "1692221321",
                        ["itemLink"] = 2559,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set eternal vigor mace one-handed training",
            },
        },
        [126905] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Hlaalu Cannister, Sealed Azurite",
                ["oldestTime"] = 1633238679,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238679,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 1256,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633238679,
                        ["quant"] = 1,
                        ["id"] = "1692189433",
                        ["itemLink"] = 2517,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [120768] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Candied Jester's Coins",
                ["oldestTime"] = 1633242686,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242686,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 348,
                        ["wasKiosk"] = false,
                        ["seller"] = 222,
                        ["timestamp"] = 1633242686,
                        ["quant"] = 1,
                        ["id"] = "1692215203",
                        ["itemLink"] = 2546,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [139195] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_waf_altwallsmediumzoogate001.dds",
                ["itemDesc"] = "Alinor Archway, Tall",
                ["oldestTime"] = 1632900283,
                ["wasAltered"] = true,
                ["newestTime"] = 1632900283,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19950,
                        ["guild"] = 1,
                        ["buyer"] = 2445,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1632900283,
                        ["quant"] = 1,
                        ["id"] = "1689560709",
                        ["itemLink"] = 3575,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings structures",
            },
        },
        [101564] = 
        {
            ["50:16:2:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_bow_c.dds",
                ["itemDesc"] = "Witchman's Bow",
                ["oldestTime"] = 1632830331,
                ["wasAltered"] = true,
                ["newestTime"] = 1632830331,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2134,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632830331,
                        ["quant"] = 1,
                        ["id"] = "1689000439",
                        ["itemLink"] = 3078,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set witchman armor bow two-handed precise",
            },
        },
        [57021] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Sweet Slaughterfish Tea",
                ["oldestTime"] = 1632923727,
                ["wasAltered"] = true,
                ["newestTime"] = 1633060734,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633011822,
                        ["quant"] = 1,
                        ["id"] = "1690302845",
                        ["itemLink"] = 523,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633060734,
                        ["quant"] = 1,
                        ["id"] = "1690716461",
                        ["itemLink"] = 523,
                    },
                    [3] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632923727,
                        ["quant"] = 1,
                        ["id"] = "1689677437",
                        ["itemLink"] = 523,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [126573] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_vrd_lsb_hlacandlesolo001.dds",
                ["itemDesc"] = "Velothi Candle, Mourning",
                ["oldestTime"] = 1633228225,
                ["wasAltered"] = true,
                ["newestTime"] = 1633228225,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 1665,
                        ["wasKiosk"] = false,
                        ["seller"] = 151,
                        ["timestamp"] = 1633228225,
                        ["quant"] = 2,
                        ["id"] = "1692099319",
                        ["itemLink"] = 2423,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [172223] = 
        {
            ["50:16:2:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_1haxe_b.dds",
                ["itemDesc"] = "Deadlands Assassin's Axe",
                ["oldestTime"] = 1633231651,
                ["wasAltered"] = true,
                ["newestTime"] = 1633231651,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2998,
                        ["guild"] = 1,
                        ["buyer"] = 1695,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1633231651,
                        ["quant"] = 1,
                        ["id"] = "1692131915",
                        ["itemLink"] = 2440,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set deadlands assassin axe one-handed charged",
            },
        },
        [126912] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Hlaalu Armchair, Mossy Cushion",
                ["oldestTime"] = 1633227781,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227781,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 80000,
                        ["guild"] = 1,
                        ["buyer"] = 521,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633227781,
                        ["quant"] = 1,
                        ["id"] = "1692093633",
                        ["itemLink"] = 2417,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [64705] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/notes_004.dds",
                ["itemDesc"] = "Recipe: Psijic Ambrosia, Fragment III",
                ["oldestTime"] = 1633103128,
                ["wasAltered"] = true,
                ["newestTime"] = 1633128683,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 739,
                        ["wasKiosk"] = false,
                        ["seller"] = 351,
                        ["timestamp"] = 1633103128,
                        ["quant"] = 1,
                        ["id"] = "1690985137",
                        ["itemLink"] = 1291,
                    },
                    [2] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1096,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633128683,
                        ["quant"] = 1,
                        ["id"] = "1691172599",
                        ["itemLink"] = 1291,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [123602] = 
        {
            ["50:16:4:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_bow_a.dds",
                ["itemDesc"] = "Knight Slayer Bow",
                ["oldestTime"] = 1633200777,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200777,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1491,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633200777,
                        ["quant"] = 1,
                        ["id"] = "1691797491",
                        ["itemLink"] = 2204,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set knight slayer bow two-handed defending",
            },
        },
        [87747] = 
        {
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Potentates",
                ["oldestTime"] = 1633197596,
                ["wasAltered"] = true,
                ["newestTime"] = 1633218655,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1463,
                        ["wasKiosk"] = true,
                        ["seller"] = 340,
                        ["timestamp"] = 1633197596,
                        ["quant"] = 1,
                        ["id"] = "1691764431",
                        ["itemLink"] = 2152,
                    },
                    [2] = 
                    {
                        ["price"] = 4999,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633218655,
                        ["quant"] = 1,
                        ["id"] = "1691997233",
                        ["itemLink"] = 2329,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set blessing of the potentates ring healthy",
            },
        },
        [56053] = 
        {
            ["1:0:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_medium_chest_a.dds",
                ["itemDesc"] = "Rawhide Jack",
                ["oldestTime"] = 1633221211,
                ["wasAltered"] = true,
                ["newestTime"] = 1633221211,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1615,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633221211,
                        ["quant"] = 1,
                        ["id"] = "1692023661",
                        ["itemLink"] = 2352,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal medium apparel chest nirnhoned",
            },
        },
        [56054] = 
        {
            ["1:0:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_medium_feet_a.dds",
                ["itemDesc"] = "Rawhide Boots",
                ["oldestTime"] = 1632938604,
                ["wasAltered"] = true,
                ["newestTime"] = 1632938604,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 2534,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1632938604,
                        ["quant"] = 1,
                        ["id"] = "1689785171",
                        ["itemLink"] = 3753,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal medium apparel feet nirnhoned",
            },
            ["50:16:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_medium_feet_a.dds",
                ["itemDesc"] = "Rubedo Leather Boots",
                ["oldestTime"] = 1633084038,
                ["wasAltered"] = true,
                ["newestTime"] = 1633084038,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633084038,
                        ["quant"] = 1,
                        ["id"] = "1690854657",
                        ["itemLink"] = 1167,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal medium apparel feet nirnhoned",
            },
        },
        [23165] = 
        {
            ["1:0:1:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_runecrafter_armor_component_004.dds",
                ["itemDesc"] = "Carnelian",
                ["oldestTime"] = 1633125390,
                ["wasAltered"] = true,
                ["newestTime"] = 1633125390,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 166,
                        ["timestamp"] = 1633125390,
                        ["quant"] = 60,
                        ["id"] = "1691145611",
                        ["itemLink"] = 1472,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials weapon trait training",
            },
        },
        [140487] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 66: Silver Dawn Legs",
                ["oldestTime"] = 1633224713,
                ["wasAltered"] = true,
                ["newestTime"] = 1633224713,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1638,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633224713,
                        ["quant"] = 1,
                        ["id"] = "1692061239",
                        ["itemLink"] = 2374,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45256] = 
        {
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_medium_shoulders_d.dds",
                ["itemDesc"] = "Rubedo Leather Arm Cops of Stamina",
                ["oldestTime"] = 1633112320,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112320,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 992,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633112320,
                        ["quant"] = 1,
                        ["id"] = "1691054497",
                        ["itemLink"] = 1344,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel shoulders invigorating",
            },
        },
        [152084] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning3.dds",
                ["itemDesc"] = "Design: Elsweyr Sconce, Candle Elegant",
                ["oldestTime"] = 1633195660,
                ["wasAltered"] = true,
                ["newestTime"] = 1633195660,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1449,
                        ["wasKiosk"] = true,
                        ["seller"] = 1450,
                        ["timestamp"] = 1633195660,
                        ["quant"] = 1,
                        ["id"] = "1691747893",
                        ["itemLink"] = 2142,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [176586] = 
        {
            ["1:0:3:47:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_helm_medium.dds",
                ["itemDesc"] = "Companion's Helmet",
                ["oldestTime"] = 1633120469,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242332,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 69999,
                        ["guild"] = 1,
                        ["buyer"] = 1050,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633120469,
                        ["quant"] = 1,
                        ["id"] = "1691108063",
                        ["itemLink"] = 1433,
                    },
                    [2] = 
                    {
                        ["price"] = 69999,
                        ["guild"] = 1,
                        ["buyer"] = 1784,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633242332,
                        ["quant"] = 1,
                        ["id"] = "1692213173",
                        ["itemLink"] = 1433,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior medium apparel head aggressive",
            },
        },
        [27048] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_malt_004.dds",
                ["itemDesc"] = "Metheglin",
                ["oldestTime"] = 1632861579,
                ["wasAltered"] = true,
                ["newestTime"] = 1633193188,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 1433,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633193188,
                        ["quant"] = 200,
                        ["id"] = "1691725935",
                        ["itemLink"] = 2120,
                    },
                    [2] = 
                    {
                        ["price"] = 1999,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1632861579,
                        ["quant"] = 200,
                        ["id"] = "1689241609",
                        ["itemLink"] = 2120,
                    },
                    [3] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1632861580,
                        ["quant"] = 200,
                        ["id"] = "1689241615",
                        ["itemLink"] = 2120,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [171357] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_inc_markkitchenpitcher005.dds",
                ["itemDesc"] = "Dwarven Kettle, Ornate Polished",
                ["oldestTime"] = 1633165962,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165962,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1633165962,
                        ["quant"] = 1,
                        ["id"] = "1691500391",
                        ["itemLink"] = 1857,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings hearth",
            },
        },
        [126564] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_dwe_fur_clocka001.dds",
                ["itemDesc"] = "Dwarven Clock, Deactivated",
                ["oldestTime"] = 1633165868,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165868,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 669,
                        ["timestamp"] = 1633165868,
                        ["quant"] = 1,
                        ["id"] = "1691499801",
                        ["itemLink"] = 1846,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings workshop",
            },
        },
        [134531] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing2.dds",
                ["itemDesc"] = "Diagram: Clockwork Sequence Plaque, Single",
                ["oldestTime"] = 1633028552,
                ["wasAltered"] = true,
                ["newestTime"] = 1633109412,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 507,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633028552,
                        ["quant"] = 1,
                        ["id"] = "1690433621",
                        ["itemLink"] = 691,
                    },
                    [2] = 
                    {
                        ["price"] = 9995,
                        ["guild"] = 1,
                        ["buyer"] = 979,
                        ["wasKiosk"] = true,
                        ["seller"] = 322,
                        ["timestamp"] = 1633109406,
                        ["quant"] = 1,
                        ["id"] = "1691031769",
                        ["itemLink"] = 691,
                    },
                    [3] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 979,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633109412,
                        ["quant"] = 1,
                        ["id"] = "1691031803",
                        ["itemLink"] = 691,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [114895] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_furniture_base_heartwood.dds",
                ["itemDesc"] = "Heartwood",
                ["oldestTime"] = 1632861525,
                ["wasAltered"] = true,
                ["newestTime"] = 1633315319,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22500,
                        ["guild"] = 1,
                        ["buyer"] = 94,
                        ["wasKiosk"] = false,
                        ["seller"] = 95,
                        ["timestamp"] = 1633315319,
                        ["quant"] = 25,
                        ["id"] = "1692907443",
                        ["itemLink"] = 69,
                    },
                    [2] = 
                    {
                        ["price"] = 117000,
                        ["guild"] = 1,
                        ["buyer"] = 73,
                        ["wasKiosk"] = false,
                        ["seller"] = 344,
                        ["timestamp"] = 1632989395,
                        ["quant"] = 156,
                        ["id"] = "1690183159",
                        ["itemLink"] = 69,
                    },
                    [3] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 588,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633034578,
                        ["quant"] = 22,
                        ["id"] = "1690473603",
                        ["itemLink"] = 69,
                    },
                    [4] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 166,
                        ["timestamp"] = 1633041922,
                        ["quant"] = 10,
                        ["id"] = "1690528083",
                        ["itemLink"] = 69,
                    },
                    [5] = 
                    {
                        ["price"] = 48800,
                        ["guild"] = 1,
                        ["buyer"] = 651,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633042707,
                        ["quant"] = 61,
                        ["id"] = "1690535429",
                        ["itemLink"] = 69,
                    },
                    [6] = 
                    {
                        ["price"] = 12390,
                        ["guild"] = 1,
                        ["buyer"] = 856,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633073754,
                        ["quant"] = 15,
                        ["id"] = "1690803295",
                        ["itemLink"] = 69,
                    },
                    [7] = 
                    {
                        ["price"] = 275000,
                        ["guild"] = 1,
                        ["buyer"] = 1073,
                        ["wasKiosk"] = true,
                        ["seller"] = 1074,
                        ["timestamp"] = 1633124369,
                        ["quant"] = 200,
                        ["id"] = "1691137397",
                        ["itemLink"] = 69,
                    },
                    [8] = 
                    {
                        ["price"] = 125000,
                        ["guild"] = 1,
                        ["buyer"] = 1073,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1633124373,
                        ["quant"] = 100,
                        ["id"] = "1691137407",
                        ["itemLink"] = 69,
                    },
                    [9] = 
                    {
                        ["price"] = 27570,
                        ["guild"] = 1,
                        ["buyer"] = 6,
                        ["wasKiosk"] = false,
                        ["seller"] = 616,
                        ["timestamp"] = 1633136021,
                        ["quant"] = 30,
                        ["id"] = "1691253065",
                        ["itemLink"] = 69,
                    },
                    [10] = 
                    {
                        ["price"] = 5880,
                        ["guild"] = 1,
                        ["buyer"] = 6,
                        ["wasKiosk"] = false,
                        ["seller"] = 179,
                        ["timestamp"] = 1633136024,
                        ["quant"] = 6,
                        ["id"] = "1691253097",
                        ["itemLink"] = 69,
                    },
                    [11] = 
                    {
                        ["price"] = 31500,
                        ["guild"] = 1,
                        ["buyer"] = 1296,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633158869,
                        ["quant"] = 36,
                        ["id"] = "1691459417",
                        ["itemLink"] = 69,
                    },
                    [12] = 
                    {
                        ["price"] = 28875,
                        ["guild"] = 1,
                        ["buyer"] = 1296,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633158870,
                        ["quant"] = 33,
                        ["id"] = "1691459421",
                        ["itemLink"] = 69,
                    },
                    [13] = 
                    {
                        ["price"] = 14868,
                        ["guild"] = 1,
                        ["buyer"] = 1562,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633213145,
                        ["quant"] = 18,
                        ["id"] = "1691941865",
                        ["itemLink"] = 69,
                    },
                    [14] = 
                    {
                        ["price"] = 4200,
                        ["guild"] = 1,
                        ["buyer"] = 1670,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633228683,
                        ["quant"] = 6,
                        ["id"] = "1692104091",
                        ["itemLink"] = 69,
                    },
                    [15] = 
                    {
                        ["price"] = 2800,
                        ["guild"] = 1,
                        ["buyer"] = 1675,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633229108,
                        ["quant"] = 4,
                        ["id"] = "1692107941",
                        ["itemLink"] = 69,
                    },
                    [16] = 
                    {
                        ["price"] = 168522,
                        ["guild"] = 1,
                        ["buyer"] = 1040,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633232265,
                        ["quant"] = 200,
                        ["id"] = "1692138001",
                        ["itemLink"] = 69,
                    },
                    [17] = 
                    {
                        ["price"] = 7200,
                        ["guild"] = 1,
                        ["buyer"] = 1562,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633257373,
                        ["quant"] = 9,
                        ["id"] = "1692314375",
                        ["itemLink"] = 69,
                    },
                    [18] = 
                    {
                        ["price"] = 16800,
                        ["guild"] = 1,
                        ["buyer"] = 1562,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1633257374,
                        ["quant"] = 21,
                        ["id"] = "1692314385",
                        ["itemLink"] = 69,
                    },
                    [19] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1887,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633272641,
                        ["quant"] = 10,
                        ["id"] = "1692433631",
                        ["itemLink"] = 69,
                    },
                    [20] = 
                    {
                        ["price"] = 920,
                        ["guild"] = 1,
                        ["buyer"] = 1900,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633275680,
                        ["quant"] = 1,
                        ["id"] = "1692471899",
                        ["itemLink"] = 69,
                    },
                    [21] = 
                    {
                        ["price"] = 167038,
                        ["guild"] = 1,
                        ["buyer"] = 1901,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633275887,
                        ["quant"] = 200,
                        ["id"] = "1692474683",
                        ["itemLink"] = 69,
                    },
                    [22] = 
                    {
                        ["price"] = 29600,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632861525,
                        ["quant"] = 37,
                        ["id"] = "1689241331",
                        ["itemLink"] = 69,
                    },
                    [23] = 
                    {
                        ["price"] = 166501,
                        ["guild"] = 1,
                        ["buyer"] = 236,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1632869377,
                        ["quant"] = 200,
                        ["id"] = "1689298727",
                        ["itemLink"] = 69,
                    },
                    [24] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 1040,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632954051,
                        ["quant"] = 13,
                        ["id"] = "1689910467",
                        ["itemLink"] = 69,
                    },
                    [25] = 
                    {
                        ["price"] = 12740,
                        ["guild"] = 1,
                        ["buyer"] = 2471,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1632960939,
                        ["quant"] = 13,
                        ["id"] = "1689967801",
                        ["itemLink"] = 69,
                    },
                },
                ["totalCount"] = 25,
                ["itemAdderText"] = "rr01 white normal materials furnishing",
            },
        },
        [176784] = 
        {
            ["1:0:4:39:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_sword.dds",
                ["itemDesc"] = "Companion's Sword",
                ["oldestTime"] = 1633189371,
                ["wasAltered"] = true,
                ["newestTime"] = 1633189371,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1412,
                        ["wasKiosk"] = true,
                        ["seller"] = 43,
                        ["timestamp"] = 1633189371,
                        ["quant"] = 1,
                        ["id"] = "1691682165",
                        ["itemLink"] = 2092,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic weapon sword one-handed soothing",
            },
        },
        [45265] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_1hsword_d.dds",
                ["itemDesc"] = "Rubedite Sword of Flame",
                ["oldestTime"] = 1633185893,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185893,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633185893,
                        ["quant"] = 1,
                        ["id"] = "1691639401",
                        ["itemLink"] = 1995,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon sword one-handed decisive",
            },
        },
        [171474] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "The Reach Treasure Map",
                ["oldestTime"] = 1632590162,
                ["wasAltered"] = true,
                ["newestTime"] = 1633173238,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 2,
                        ["buyer"] = 117,
                        ["wasKiosk"] = false,
                        ["seller"] = 122,
                        ["timestamp"] = 1632590162,
                        ["quant"] = 1,
                        ["id"] = "1686937895",
                        ["itemLink"] = 99,
                    },
                    [2] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 809,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1633064278,
                        ["quant"] = 1,
                        ["id"] = "1690742591",
                        ["itemLink"] = 99,
                    },
                    [3] = 
                    {
                        ["price"] = 13358,
                        ["guild"] = 1,
                        ["buyer"] = 809,
                        ["wasKiosk"] = true,
                        ["seller"] = 765,
                        ["timestamp"] = 1633064279,
                        ["quant"] = 1,
                        ["id"] = "1690742609",
                        ["itemLink"] = 99,
                    },
                    [4] = 
                    {
                        ["price"] = 9999,
                        ["guild"] = 1,
                        ["buyer"] = 1347,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1633173224,
                        ["quant"] = 1,
                        ["id"] = "1691536625",
                        ["itemLink"] = 99,
                    },
                    [5] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1347,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633173230,
                        ["quant"] = 1,
                        ["id"] = "1691536645",
                        ["itemLink"] = 99,
                    },
                    [6] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1347,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633173233,
                        ["quant"] = 1,
                        ["id"] = "1691536653",
                        ["itemLink"] = 99,
                    },
                    [7] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1347,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633173238,
                        ["quant"] = 1,
                        ["id"] = "1691536661",
                        ["itemLink"] = 99,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [45101] = 
        {
            ["50:16:2:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_heavy_waist_d.dds",
                ["itemDesc"] = "Rubedite Girdle of Health",
                ["oldestTime"] = 1632847694,
                ["wasAltered"] = true,
                ["newestTime"] = 1632847694,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1632847694,
                        ["quant"] = 1,
                        ["id"] = "1689125587",
                        ["itemLink"] = 3218,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel waist reinforced",
            },
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_heavy_waist_d.dds",
                ["itemDesc"] = "Rubedite Girdle of Stamina",
                ["oldestTime"] = 1633185950,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185950,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 90,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633185950,
                        ["quant"] = 1,
                        ["id"] = "1691640235",
                        ["itemLink"] = 2026,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel waist reinforced",
            },
        },
        [147668] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 71: Coldsnap Belts",
                ["oldestTime"] = 1633312584,
                ["wasAltered"] = true,
                ["newestTime"] = 1633312584,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 36,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633312584,
                        ["quant"] = 1,
                        ["id"] = "1692876439",
                        ["itemLink"] = 25,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45962] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Solstheim Elk and Scuttle",
                ["oldestTime"] = 1633052740,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052740,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 199,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1633052740,
                        ["quant"] = 1,
                        ["id"] = "1690632513",
                        ["itemLink"] = 909,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [130006] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 51: Hlaalu Shoulders",
                ["oldestTime"] = 1633143429,
                ["wasAltered"] = true,
                ["newestTime"] = 1633143429,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1213,
                        ["wasKiosk"] = true,
                        ["seller"] = 1214,
                        ["timestamp"] = 1633143429,
                        ["quant"] = 1,
                        ["id"] = "1691330841",
                        ["itemLink"] = 1637,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [147671] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 71: Coldsnap Chests",
                ["oldestTime"] = 1632870592,
                ["wasAltered"] = true,
                ["newestTime"] = 1632870592,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 79500,
                        ["guild"] = 1,
                        ["buyer"] = 2290,
                        ["wasKiosk"] = true,
                        ["seller"] = 1438,
                        ["timestamp"] = 1632870592,
                        ["quant"] = 1,
                        ["id"] = "1689307719",
                        ["itemLink"] = 3387,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [134360] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_cwc_inc_scale001.dds",
                ["itemDesc"] = "Clockwork Scales, Precision Calibrated",
                ["oldestTime"] = 1632880500,
                ["wasAltered"] = true,
                ["newestTime"] = 1632880500,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 46697,
                        ["guild"] = 1,
                        ["buyer"] = 2354,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1632880500,
                        ["quant"] = 2,
                        ["id"] = "1689402109",
                        ["itemLink"] = 3463,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings workshop",
            },
        },
        [118489] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bre_inc_paperstack001.dds",
                ["itemDesc"] = "Papers, Stack",
                ["oldestTime"] = 1632949965,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165763,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 587,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633034578,
                        ["quant"] = 1,
                        ["id"] = "1690473601",
                        ["itemLink"] = 756,
                    },
                    [2] = 
                    {
                        ["price"] = 280,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633165763,
                        ["quant"] = 1,
                        ["id"] = "1691499485",
                        ["itemLink"] = 756,
                    },
                    [3] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 2583,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632949965,
                        ["quant"] = 1,
                        ["id"] = "1689874087",
                        ["itemLink"] = 756,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine furnishings library",
            },
        },
        [171796] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Markarth Stairway, Wide Stone",
                ["oldestTime"] = 1633115089,
                ["wasAltered"] = true,
                ["newestTime"] = 1633115089,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11467,
                        ["guild"] = 1,
                        ["buyer"] = 1016,
                        ["wasKiosk"] = true,
                        ["seller"] = 327,
                        ["timestamp"] = 1633115089,
                        ["quant"] = 1,
                        ["id"] = "1691072447",
                        ["itemLink"] = 1391,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [140507] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 67: Welkynar Shields",
                ["oldestTime"] = 1633144608,
                ["wasAltered"] = true,
                ["newestTime"] = 1633306658,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1223,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633144608,
                        ["quant"] = 1,
                        ["id"] = "1691343731",
                        ["itemLink"] = 1646,
                    },
                    [2] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1920,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633279209,
                        ["quant"] = 1,
                        ["id"] = "1692506883",
                        ["itemLink"] = 1646,
                    },
                    [3] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 2071,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1633306658,
                        ["quant"] = 1,
                        ["id"] = "1692806019",
                        ["itemLink"] = 1646,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [101983] = 
        {
            ["50:16:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_soulshriven_light_legs_a.dds",
                ["itemDesc"] = "Prisoner's Breeches",
                ["oldestTime"] = 1633114514,
                ["wasAltered"] = true,
                ["newestTime"] = 1633114514,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1013,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633114514,
                        ["quant"] = 1,
                        ["id"] = "1691069467",
                        ["itemLink"] = 1384,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set prisoner's rags legs impenetrable",
            },
        },
        [26845] = 
        {
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_reducearmor.dds",
                ["itemDesc"] = "Truly Superb Glyph of Crushing",
                ["oldestTime"] = 1633182053,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182053,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6700,
                        ["guild"] = 1,
                        ["buyer"] = 1375,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633182053,
                        ["quant"] = 1,
                        ["id"] = "1691604219",
                        ["itemLink"] = 1933,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous weapon glyph",
            },
        },
        [147731] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 75: Sunspire Axes",
                ["oldestTime"] = 1633004142,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052082,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2999,
                        ["guild"] = 1,
                        ["buyer"] = 416,
                        ["wasKiosk"] = true,
                        ["seller"] = 417,
                        ["timestamp"] = 1633004142,
                        ["quant"] = 1,
                        ["id"] = "1690254807",
                        ["itemLink"] = 423,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 242,
                        ["wasKiosk"] = false,
                        ["seller"] = 709,
                        ["timestamp"] = 1633052082,
                        ["quant"] = 1,
                        ["id"] = "1690626801",
                        ["itemLink"] = 423,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [69908] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_light_shirt_d.dds",
                ["itemDesc"] = "Jerkin of Julianos",
                ["oldestTime"] = 1632976059,
                ["wasAltered"] = true,
                ["newestTime"] = 1632976059,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9999,
                        ["guild"] = 1,
                        ["buyer"] = 219,
                        ["wasKiosk"] = true,
                        ["seller"] = 220,
                        ["timestamp"] = 1632976059,
                        ["quant"] = 1,
                        ["id"] = "1690103211",
                        ["itemLink"] = 234,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set law of julianos chest divines",
            },
        },
        [114400] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_alt_inc_tapestry004.dds",
                ["itemDesc"] = "High Elf Tapestry, Eagle",
                ["oldestTime"] = 1633060719,
                ["wasAltered"] = true,
                ["newestTime"] = 1633060719,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 788,
                        ["wasKiosk"] = true,
                        ["seller"] = 622,
                        ["timestamp"] = 1633060719,
                        ["quant"] = 1,
                        ["id"] = "1690716385",
                        ["itemLink"] = 1016,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings parlor",
            },
        },
        [156641] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 80: Shield of Senchal Swords",
                ["oldestTime"] = 1632920017,
                ["wasAltered"] = true,
                ["newestTime"] = 1632920017,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12750,
                        ["guild"] = 1,
                        ["buyer"] = 973,
                        ["wasKiosk"] = true,
                        ["seller"] = 269,
                        ["timestamp"] = 1632920017,
                        ["quant"] = 1,
                        ["id"] = "1689651449",
                        ["itemLink"] = 3650,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [153570] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Glenmoril Wyrd Mace",
                ["oldestTime"] = 1633148297,
                ["wasAltered"] = true,
                ["newestTime"] = 1633148297,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9500,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 218,
                        ["timestamp"] = 1633148297,
                        ["quant"] = 1,
                        ["id"] = "1691375993",
                        ["itemLink"] = 1698,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [43751] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Summerset Treasure Map IV",
                ["oldestTime"] = 1632858419,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182514,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 359,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182514,
                        ["quant"] = 1,
                        ["id"] = "1691608157",
                        ["itemLink"] = 1952,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 733,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632858419,
                        ["quant"] = 1,
                        ["id"] = "1689218603",
                        ["itemLink"] = 1952,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [119012] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Orcish Table, Braced Formal",
                ["oldestTime"] = 1633192350,
                ["wasAltered"] = true,
                ["newestTime"] = 1633192350,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1427,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633192350,
                        ["quant"] = 1,
                        ["id"] = "1691716531",
                        ["itemLink"] = 2113,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [56037] = 
        {
            ["1:0:1:26:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_staff_a.dds",
                ["itemDesc"] = "Maple Restoration Staff",
                ["oldestTime"] = 1633097071,
                ["wasAltered"] = true,
                ["newestTime"] = 1633284323,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 902,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633097071,
                        ["quant"] = 1,
                        ["id"] = "1690936587",
                        ["itemLink"] = 1268,
                    },
                    [2] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 1207,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633142746,
                        ["quant"] = 1,
                        ["id"] = "1691322571",
                        ["itemLink"] = 1268,
                    },
                    [3] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 510,
                        ["wasKiosk"] = false,
                        ["seller"] = 709,
                        ["timestamp"] = 1633277119,
                        ["quant"] = 1,
                        ["id"] = "1692487507",
                        ["itemLink"] = 1268,
                    },
                    [4] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 1947,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633284323,
                        ["quant"] = 1,
                        ["id"] = "1692558835",
                        ["itemLink"] = 1268,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 white normal weapon healing staff two-handed nirnhoned",
            },
        },
        [97254] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_feet_d.dds",
                ["itemDesc"] = "Shoes of a Mother's Sorrow",
                ["oldestTime"] = 1633191085,
                ["wasAltered"] = true,
                ["newestTime"] = 1633301606,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 90000,
                        ["guild"] = 1,
                        ["buyer"] = 1421,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1633191085,
                        ["quant"] = 1,
                        ["id"] = "1691700975",
                        ["itemLink"] = 2107,
                    },
                    [2] = 
                    {
                        ["price"] = 110000,
                        ["guild"] = 1,
                        ["buyer"] = 1431,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633193150,
                        ["quant"] = 1,
                        ["id"] = "1691725535",
                        ["itemLink"] = 2107,
                    },
                    [3] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 1612,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633220409,
                        ["quant"] = 1,
                        ["id"] = "1692016093",
                        ["itemLink"] = 2107,
                    },
                    [4] = 
                    {
                        ["price"] = 90000,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 2048,
                        ["timestamp"] = 1633301606,
                        ["quant"] = 1,
                        ["id"] = "1692756671",
                        ["itemLink"] = 2107,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp160 purple epic light apparel set mother's sorrow feet divines",
            },
        },
        [64487] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_daedricembers.dds",
                ["itemDesc"] = "Key Fragment",
                ["oldestTime"] = 1632844240,
                ["wasAltered"] = true,
                ["newestTime"] = 1633061293,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5355,
                        ["guild"] = 1,
                        ["buyer"] = 791,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633061286,
                        ["quant"] = 15,
                        ["id"] = "1690720435",
                        ["itemLink"] = 1024,
                    },
                    [2] = 
                    {
                        ["price"] = 7140,
                        ["guild"] = 1,
                        ["buyer"] = 791,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633061287,
                        ["quant"] = 20,
                        ["id"] = "1690720437",
                        ["itemLink"] = 1024,
                    },
                    [3] = 
                    {
                        ["price"] = 7140,
                        ["guild"] = 1,
                        ["buyer"] = 791,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633061287,
                        ["quant"] = 20,
                        ["id"] = "1690720445",
                        ["itemLink"] = 1024,
                    },
                    [4] = 
                    {
                        ["price"] = 37062,
                        ["guild"] = 1,
                        ["buyer"] = 791,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1633061288,
                        ["quant"] = 100,
                        ["id"] = "1690720447",
                        ["itemLink"] = 1024,
                    },
                    [5] = 
                    {
                        ["price"] = 37062,
                        ["guild"] = 1,
                        ["buyer"] = 791,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1633061289,
                        ["quant"] = 100,
                        ["id"] = "1690720451",
                        ["itemLink"] = 1024,
                    },
                    [6] = 
                    {
                        ["price"] = 37062,
                        ["guild"] = 1,
                        ["buyer"] = 791,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1633061289,
                        ["quant"] = 100,
                        ["id"] = "1690720457",
                        ["itemLink"] = 1024,
                    },
                    [7] = 
                    {
                        ["price"] = 37062,
                        ["guild"] = 1,
                        ["buyer"] = 791,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1633061290,
                        ["quant"] = 100,
                        ["id"] = "1690720465",
                        ["itemLink"] = 1024,
                    },
                    [8] = 
                    {
                        ["price"] = 37062,
                        ["guild"] = 1,
                        ["buyer"] = 791,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1633061291,
                        ["quant"] = 100,
                        ["id"] = "1690720469",
                        ["itemLink"] = 1024,
                    },
                    [9] = 
                    {
                        ["price"] = 37062,
                        ["guild"] = 1,
                        ["buyer"] = 791,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1633061292,
                        ["quant"] = 100,
                        ["id"] = "1690720475",
                        ["itemLink"] = 1024,
                    },
                    [10] = 
                    {
                        ["price"] = 14440,
                        ["guild"] = 1,
                        ["buyer"] = 791,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633061293,
                        ["quant"] = 38,
                        ["id"] = "1690720481",
                        ["itemLink"] = 1024,
                    },
                    [11] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1632844240,
                        ["quant"] = 20,
                        ["id"] = "1689093135",
                        ["itemLink"] = 1024,
                    },
                    [12] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1632844241,
                        ["quant"] = 20,
                        ["id"] = "1689093137",
                        ["itemLink"] = 1024,
                    },
                    [13] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1632844241,
                        ["quant"] = 20,
                        ["id"] = "1689093139",
                        ["itemLink"] = 1024,
                    },
                    [14] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1632844243,
                        ["quant"] = 20,
                        ["id"] = "1689093153",
                        ["itemLink"] = 1024,
                    },
                    [15] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1632844243,
                        ["quant"] = 20,
                        ["id"] = "1689093155",
                        ["itemLink"] = 1024,
                    },
                    [16] = 
                    {
                        ["price"] = 10836,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632844244,
                        ["quant"] = 28,
                        ["id"] = "1689093173",
                        ["itemLink"] = 1024,
                    },
                    [17] = 
                    {
                        ["price"] = 20500,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 269,
                        ["timestamp"] = 1632844245,
                        ["quant"] = 60,
                        ["id"] = "1689093191",
                        ["itemLink"] = 1024,
                    },
                    [18] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 763,
                        ["timestamp"] = 1632844249,
                        ["quant"] = 200,
                        ["id"] = "1689093249",
                        ["itemLink"] = 1024,
                    },
                    [19] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 232,
                        ["timestamp"] = 1632844252,
                        ["quant"] = 200,
                        ["id"] = "1689093271",
                        ["itemLink"] = 1024,
                    },
                    [20] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1384,
                        ["wasKiosk"] = true,
                        ["seller"] = 583,
                        ["timestamp"] = 1632851543,
                        ["quant"] = 200,
                        ["id"] = "1689155317",
                        ["itemLink"] = 1024,
                    },
                    [21] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1384,
                        ["wasKiosk"] = true,
                        ["seller"] = 583,
                        ["timestamp"] = 1632851544,
                        ["quant"] = 200,
                        ["id"] = "1689155327",
                        ["itemLink"] = 1024,
                    },
                    [22] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1384,
                        ["wasKiosk"] = true,
                        ["seller"] = 583,
                        ["timestamp"] = 1632851544,
                        ["quant"] = 200,
                        ["id"] = "1689155333",
                        ["itemLink"] = 1024,
                    },
                    [23] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1384,
                        ["wasKiosk"] = true,
                        ["seller"] = 583,
                        ["timestamp"] = 1632851545,
                        ["quant"] = 200,
                        ["id"] = "1689155337",
                        ["itemLink"] = 1024,
                    },
                    [24] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1384,
                        ["wasKiosk"] = true,
                        ["seller"] = 583,
                        ["timestamp"] = 1632851546,
                        ["quant"] = 200,
                        ["id"] = "1689155343",
                        ["itemLink"] = 1024,
                    },
                    [25] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1384,
                        ["wasKiosk"] = true,
                        ["seller"] = 583,
                        ["timestamp"] = 1632851546,
                        ["quant"] = 200,
                        ["id"] = "1689155351",
                        ["itemLink"] = 1024,
                    },
                    [26] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1384,
                        ["wasKiosk"] = true,
                        ["seller"] = 583,
                        ["timestamp"] = 1632851547,
                        ["quant"] = 200,
                        ["id"] = "1689155355",
                        ["itemLink"] = 1024,
                    },
                    [27] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 2292,
                        ["wasKiosk"] = true,
                        ["seller"] = 583,
                        ["timestamp"] = 1632871263,
                        ["quant"] = 200,
                        ["id"] = "1689311731",
                        ["itemLink"] = 1024,
                    },
                },
                ["totalCount"] = 27,
                ["itemAdderText"] = "rr01 purple epic miscellaneous trophy",
            },
        },
        [33256] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_metals_corundum.dds",
                ["itemDesc"] = "Corundum",
                ["oldestTime"] = 1633070509,
                ["wasAltered"] = true,
                ["newestTime"] = 1633116634,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3472,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 69,
                        ["timestamp"] = 1633070509,
                        ["quant"] = 100,
                        ["id"] = "1690780625",
                        ["itemLink"] = 1083,
                    },
                    [2] = 
                    {
                        ["price"] = 8700,
                        ["guild"] = 1,
                        ["buyer"] = 1028,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633116634,
                        ["quant"] = 200,
                        ["id"] = "1691082873",
                        ["itemLink"] = 1083,
                    },
                    [3] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1028,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633116634,
                        ["quant"] = 200,
                        ["id"] = "1691082877",
                        ["itemLink"] = 1083,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [95465] = 
        {
            ["50:16:2:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_staff_a.dds",
                ["itemDesc"] = "Restoration Staff of Martial Knowledge",
                ["oldestTime"] = 1633095256,
                ["wasAltered"] = true,
                ["newestTime"] = 1633095256,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 926,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1633095256,
                        ["quant"] = 1,
                        ["id"] = "1690921305",
                        ["itemLink"] = 1262,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set way of martial knowledge healing staff two-handed infused",
            },
        },
        [144561] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_medium_feet_a.dds",
                ["itemDesc"] = "Soldier of Anguish Boots",
                ["oldestTime"] = 1633153573,
                ["wasAltered"] = true,
                ["newestTime"] = 1633153573,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1272,
                        ["wasKiosk"] = true,
                        ["seller"] = 1273,
                        ["timestamp"] = 1633153573,
                        ["quant"] = 1,
                        ["id"] = "1691420011",
                        ["itemLink"] = 1739,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set soldier of anguish feet impenetrable",
            },
        },
        [135147] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/jewelrycrafting_booster_refined_terne.dds",
                ["itemDesc"] = "Terne Plating",
                ["oldestTime"] = 1632848404,
                ["wasAltered"] = true,
                ["newestTime"] = 1633282209,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1632983141,
                        ["quant"] = 4,
                        ["id"] = "1690148437",
                        ["itemLink"] = 301,
                    },
                    [2] = 
                    {
                        ["price"] = 34000,
                        ["guild"] = 1,
                        ["buyer"] = 302,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632983668,
                        ["quant"] = 20,
                        ["id"] = "1690151977",
                        ["itemLink"] = 301,
                    },
                    [3] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 541,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633025774,
                        ["quant"] = 1,
                        ["id"] = "1690413183",
                        ["itemLink"] = 301,
                    },
                    [4] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 541,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633025792,
                        ["quant"] = 5,
                        ["id"] = "1690413257",
                        ["itemLink"] = 301,
                    },
                    [5] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 1042,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633119026,
                        ["quant"] = 25,
                        ["id"] = "1691098305",
                        ["itemLink"] = 301,
                    },
                    [6] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1042,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633119029,
                        ["quant"] = 1,
                        ["id"] = "1691098327",
                        ["itemLink"] = 301,
                    },
                    [7] = 
                    {
                        ["price"] = 1700,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 1480,
                        ["timestamp"] = 1633199604,
                        ["quant"] = 1,
                        ["id"] = "1691785375",
                        ["itemLink"] = 301,
                    },
                    [8] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1937,
                        ["wasKiosk"] = true,
                        ["seller"] = 224,
                        ["timestamp"] = 1633282207,
                        ["quant"] = 4,
                        ["id"] = "1692538823",
                        ["itemLink"] = 301,
                    },
                    [9] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1937,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633282209,
                        ["quant"] = 2,
                        ["id"] = "1692538845",
                        ["itemLink"] = 301,
                    },
                    [10] = 
                    {
                        ["price"] = 100000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1632848404,
                        ["quant"] = 40,
                        ["id"] = "1689131361",
                        ["itemLink"] = 301,
                    },
                    [11] = 
                    {
                        ["price"] = 46000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1632848420,
                        ["quant"] = 20,
                        ["id"] = "1689131401",
                        ["itemLink"] = 301,
                    },
                    [12] = 
                    {
                        ["price"] = 8750,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 232,
                        ["timestamp"] = 1632926690,
                        ["quant"] = 7,
                        ["id"] = "1689698523",
                        ["itemLink"] = 301,
                    },
                    [13] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2207,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632928256,
                        ["quant"] = 1,
                        ["id"] = "1689708501",
                        ["itemLink"] = 301,
                    },
                },
                ["totalCount"] = 13,
                ["itemAdderText"] = "rr01 green fine materials plating",
            },
        },
        [132588] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 57: Ebonshadow Gloves",
                ["oldestTime"] = 1633175323,
                ["wasAltered"] = true,
                ["newestTime"] = 1633175323,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1351,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633175323,
                        ["quant"] = 1,
                        ["id"] = "1691549295",
                        ["itemLink"] = 1898,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [49133] = 
        {
            ["10:0:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_1haxe_a.dds",
                ["itemDesc"] = "Axe of the Night Mother",
                ["oldestTime"] = 1632857536,
                ["wasAltered"] = true,
                ["newestTime"] = 1633014454,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 330,
                        ["wasKiosk"] = false,
                        ["seller"] = 426,
                        ["timestamp"] = 1633014454,
                        ["quant"] = 1,
                        ["id"] = "1690319763",
                        ["itemLink"] = 531,
                    },
                    [2] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1300,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632857536,
                        ["quant"] = 1,
                        ["id"] = "1689209581",
                        ["itemLink"] = 3280,
                    },
                    [3] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2463,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632911208,
                        ["quant"] = 1,
                        ["id"] = "1689604929",
                        ["itemLink"] = 3280,
                    },
                    [4] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2463,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632911209,
                        ["quant"] = 1,
                        ["id"] = "1689604933",
                        ["itemLink"] = 531,
                    },
                    [5] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2481,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632919552,
                        ["quant"] = 1,
                        ["id"] = "1689649153",
                        ["itemLink"] = 531,
                    },
                    [6] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2610,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632955471,
                        ["quant"] = 1,
                        ["id"] = "1689922445",
                        ["itemLink"] = 531,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr10 blue superior weapon set night mother's gaze axe one-handed training",
            },
        },
        [141827] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_fur_wallbookcasecombined001.dds",
                ["itemDesc"] = "Alinor Bookshelf, Grand Full",
                ["oldestTime"] = 1632876512,
                ["wasAltered"] = true,
                ["newestTime"] = 1633149771,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 32999,
                        ["guild"] = 1,
                        ["buyer"] = 1251,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633149758,
                        ["quant"] = 1,
                        ["id"] = "1691388725",
                        ["itemLink"] = 1710,
                    },
                    [2] = 
                    {
                        ["price"] = 73999,
                        ["guild"] = 1,
                        ["buyer"] = 1251,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633149771,
                        ["quant"] = 2,
                        ["id"] = "1691388841",
                        ["itemLink"] = 1710,
                    },
                    [3] = 
                    {
                        ["price"] = 73999,
                        ["guild"] = 1,
                        ["buyer"] = 2331,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1632876512,
                        ["quant"] = 2,
                        ["id"] = "1689357365",
                        ["itemLink"] = 1710,
                    },
                    [4] = 
                    {
                        ["price"] = 38500,
                        ["guild"] = 1,
                        ["buyer"] = 2331,
                        ["wasKiosk"] = true,
                        ["seller"] = 569,
                        ["timestamp"] = 1632876512,
                        ["quant"] = 1,
                        ["id"] = "1689357369",
                        ["itemLink"] = 1710,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 gold legendary furnishings library",
            },
        },
        [57583] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 15: Dwemer Shields",
                ["oldestTime"] = 1633219211,
                ["wasAltered"] = true,
                ["newestTime"] = 1633219211,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1944,
                        ["guild"] = 1,
                        ["buyer"] = 160,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633219211,
                        ["quant"] = 1,
                        ["id"] = "1692004495",
                        ["itemLink"] = 2337,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [82010] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 41: Celestial Bows",
                ["oldestTime"] = 1633144510,
                ["wasAltered"] = true,
                ["newestTime"] = 1633144510,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10959,
                        ["guild"] = 1,
                        ["buyer"] = 1220,
                        ["wasKiosk"] = true,
                        ["seller"] = 765,
                        ["timestamp"] = 1633144510,
                        ["quant"] = 1,
                        ["id"] = "1691342819",
                        ["itemLink"] = 1643,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [165617] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_inc_vampiredrape004.dds",
                ["itemDesc"] = "Vampiric Drapes, Pulled Back",
                ["oldestTime"] = 1632879564,
                ["wasAltered"] = true,
                ["newestTime"] = 1632879564,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 2349,
                        ["wasKiosk"] = true,
                        ["seller"] = 6,
                        ["timestamp"] = 1632879564,
                        ["quant"] = 1,
                        ["id"] = "1689392173",
                        ["itemLink"] = 3445,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings parlor",
            },
        },
        [135527] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Vanus's Necklace",
                ["oldestTime"] = 1633082473,
                ["wasAltered"] = true,
                ["newestTime"] = 1633082473,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 787,
                        ["guild"] = 1,
                        ["buyer"] = 458,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633082473,
                        ["quant"] = 1,
                        ["id"] = "1690846541",
                        ["itemLink"] = 1134,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set wisdom of vanus neck arcane",
            },
        },
        [45549] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Fifth Legion Porter",
                ["oldestTime"] = 1633130352,
                ["wasAltered"] = true,
                ["newestTime"] = 1633130352,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1102,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633130352,
                        ["quant"] = 1,
                        ["id"] = "1691189583",
                        ["itemLink"] = 1510,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [147700] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 73: Anequina Belts",
                ["oldestTime"] = 1633214011,
                ["wasAltered"] = true,
                ["newestTime"] = 1633214011,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 1571,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633214011,
                        ["quant"] = 1,
                        ["id"] = "1691949603",
                        ["itemLink"] = 2293,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [160501] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 84: Blackreach Vanguard Helmets",
                ["oldestTime"] = 1633027073,
                ["wasAltered"] = true,
                ["newestTime"] = 1633027073,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 546,
                        ["timestamp"] = 1633027073,
                        ["quant"] = 1,
                        ["id"] = "1690421253",
                        ["itemLink"] = 683,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [64502] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_wood_ruddy_ash.dds",
                ["itemDesc"] = "Sanded Ruby Ash",
                ["oldestTime"] = 1632816839,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294032,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1824,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633038275,
                        ["quant"] = 200,
                        ["id"] = "1690500235",
                        ["itemLink"] = 779,
                    },
                    [2] = 
                    {
                        ["price"] = 1824,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633038276,
                        ["quant"] = 200,
                        ["id"] = "1690500239",
                        ["itemLink"] = 779,
                    },
                    [3] = 
                    {
                        ["price"] = 1824,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633038278,
                        ["quant"] = 200,
                        ["id"] = "1690500265",
                        ["itemLink"] = 779,
                    },
                    [4] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 742,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633054848,
                        ["quant"] = 200,
                        ["id"] = "1690653205",
                        ["itemLink"] = 779,
                    },
                    [5] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 1291,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633157432,
                        ["quant"] = 200,
                        ["id"] = "1691451141",
                        ["itemLink"] = 779,
                    },
                    [6] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1633200140,
                        ["quant"] = 200,
                        ["id"] = "1691791681",
                        ["itemLink"] = 779,
                    },
                    [7] = 
                    {
                        ["price"] = 1824,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633200141,
                        ["quant"] = 200,
                        ["id"] = "1691791685",
                        ["itemLink"] = 779,
                    },
                    [8] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1633200142,
                        ["quant"] = 200,
                        ["id"] = "1691791695",
                        ["itemLink"] = 779,
                    },
                    [9] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1633200142,
                        ["quant"] = 200,
                        ["id"] = "1691791707",
                        ["itemLink"] = 779,
                    },
                    [10] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1633200143,
                        ["quant"] = 200,
                        ["id"] = "1691791711",
                        ["itemLink"] = 779,
                    },
                    [11] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1633200143,
                        ["quant"] = 200,
                        ["id"] = "1691791721",
                        ["itemLink"] = 779,
                    },
                    [12] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633200144,
                        ["quant"] = 200,
                        ["id"] = "1691791729",
                        ["itemLink"] = 779,
                    },
                    [13] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1633200144,
                        ["quant"] = 200,
                        ["id"] = "1691791735",
                        ["itemLink"] = 779,
                    },
                    [14] = 
                    {
                        ["price"] = 1824,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633200145,
                        ["quant"] = 200,
                        ["id"] = "1691791741",
                        ["itemLink"] = 779,
                    },
                    [15] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1633200146,
                        ["quant"] = 200,
                        ["id"] = "1691791745",
                        ["itemLink"] = 779,
                    },
                    [16] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633200149,
                        ["quant"] = 200,
                        ["id"] = "1691791807",
                        ["itemLink"] = 779,
                    },
                    [17] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633200150,
                        ["quant"] = 200,
                        ["id"] = "1691791813",
                        ["itemLink"] = 779,
                    },
                    [18] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633200150,
                        ["quant"] = 200,
                        ["id"] = "1691791819",
                        ["itemLink"] = 779,
                    },
                    [19] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633200151,
                        ["quant"] = 200,
                        ["id"] = "1691791825",
                        ["itemLink"] = 779,
                    },
                    [20] = 
                    {
                        ["price"] = 2100,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1633200151,
                        ["quant"] = 200,
                        ["id"] = "1691791837",
                        ["itemLink"] = 779,
                    },
                    [21] = 
                    {
                        ["price"] = 2100,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1633200152,
                        ["quant"] = 200,
                        ["id"] = "1691791845",
                        ["itemLink"] = 779,
                    },
                    [22] = 
                    {
                        ["price"] = 2100,
                        ["guild"] = 1,
                        ["buyer"] = 825,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1633237801,
                        ["quant"] = 200,
                        ["id"] = "1692183861",
                        ["itemLink"] = 779,
                    },
                    [23] = 
                    {
                        ["price"] = 2100,
                        ["guild"] = 1,
                        ["buyer"] = 825,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1633237803,
                        ["quant"] = 200,
                        ["id"] = "1692183891",
                        ["itemLink"] = 779,
                    },
                    [24] = 
                    {
                        ["price"] = 2100,
                        ["guild"] = 1,
                        ["buyer"] = 825,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1633237803,
                        ["quant"] = 200,
                        ["id"] = "1692183893",
                        ["itemLink"] = 779,
                    },
                    [25] = 
                    {
                        ["price"] = 2174,
                        ["guild"] = 1,
                        ["buyer"] = 825,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633237804,
                        ["quant"] = 200,
                        ["id"] = "1692183903",
                        ["itemLink"] = 779,
                    },
                    [26] = 
                    {
                        ["price"] = 2174,
                        ["guild"] = 1,
                        ["buyer"] = 825,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633237805,
                        ["quant"] = 200,
                        ["id"] = "1692183917",
                        ["itemLink"] = 779,
                    },
                    [27] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1775,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1633241006,
                        ["quant"] = 200,
                        ["id"] = "1692204483",
                        ["itemLink"] = 779,
                    },
                    [28] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1775,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633241007,
                        ["quant"] = 200,
                        ["id"] = "1692204491",
                        ["itemLink"] = 779,
                    },
                    [29] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1775,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633241008,
                        ["quant"] = 200,
                        ["id"] = "1692204493",
                        ["itemLink"] = 779,
                    },
                    [30] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1775,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633241008,
                        ["quant"] = 200,
                        ["id"] = "1692204497",
                        ["itemLink"] = 779,
                    },
                    [31] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1775,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633241009,
                        ["quant"] = 200,
                        ["id"] = "1692204499",
                        ["itemLink"] = 779,
                    },
                    [32] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633242130,
                        ["quant"] = 200,
                        ["id"] = "1692212325",
                        ["itemLink"] = 779,
                    },
                    [33] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2004,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633294029,
                        ["quant"] = 200,
                        ["id"] = "1692676219",
                        ["itemLink"] = 779,
                    },
                    [34] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2004,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633294030,
                        ["quant"] = 200,
                        ["id"] = "1692676229",
                        ["itemLink"] = 779,
                    },
                    [35] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2004,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633294030,
                        ["quant"] = 200,
                        ["id"] = "1692676237",
                        ["itemLink"] = 779,
                    },
                    [36] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2004,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633294031,
                        ["quant"] = 200,
                        ["id"] = "1692676243",
                        ["itemLink"] = 779,
                    },
                    [37] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2004,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633294032,
                        ["quant"] = 200,
                        ["id"] = "1692676251",
                        ["itemLink"] = 779,
                    },
                    [38] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632816839,
                        ["quant"] = 200,
                        ["id"] = "1688929437",
                        ["itemLink"] = 779,
                    },
                    [39] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632816840,
                        ["quant"] = 200,
                        ["id"] = "1688929447",
                        ["itemLink"] = 779,
                    },
                    [40] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632816841,
                        ["quant"] = 200,
                        ["id"] = "1688929453",
                        ["itemLink"] = 779,
                    },
                    [41] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632816841,
                        ["quant"] = 200,
                        ["id"] = "1688929463",
                        ["itemLink"] = 779,
                    },
                    [42] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632816842,
                        ["quant"] = 200,
                        ["id"] = "1688929471",
                        ["itemLink"] = 779,
                    },
                    [43] = 
                    {
                        ["price"] = 1756,
                        ["guild"] = 1,
                        ["buyer"] = 2130,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1632829967,
                        ["quant"] = 200,
                        ["id"] = "1688998339",
                        ["itemLink"] = 779,
                    },
                    [44] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2216,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632850831,
                        ["quant"] = 200,
                        ["id"] = "1689151425",
                        ["itemLink"] = 779,
                    },
                    [45] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2216,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632850832,
                        ["quant"] = 200,
                        ["id"] = "1689151429",
                        ["itemLink"] = 779,
                    },
                    [46] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2216,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632850834,
                        ["quant"] = 200,
                        ["id"] = "1689151439",
                        ["itemLink"] = 779,
                    },
                    [47] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2216,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632850834,
                        ["quant"] = 200,
                        ["id"] = "1689151441",
                        ["itemLink"] = 779,
                    },
                    [48] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2216,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632850836,
                        ["quant"] = 200,
                        ["id"] = "1689151447",
                        ["itemLink"] = 779,
                    },
                    [49] = 
                    {
                        ["price"] = 2173,
                        ["guild"] = 1,
                        ["buyer"] = 2243,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632859347,
                        ["quant"] = 200,
                        ["id"] = "1689225615",
                        ["itemLink"] = 779,
                    },
                    [50] = 
                    {
                        ["price"] = 2173,
                        ["guild"] = 1,
                        ["buyer"] = 2243,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632859348,
                        ["quant"] = 200,
                        ["id"] = "1689225621",
                        ["itemLink"] = 779,
                    },
                    [51] = 
                    {
                        ["price"] = 2173,
                        ["guild"] = 1,
                        ["buyer"] = 2345,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632879072,
                        ["quant"] = 200,
                        ["id"] = "1689385097",
                        ["itemLink"] = 779,
                    },
                    [52] = 
                    {
                        ["price"] = 2173,
                        ["guild"] = 1,
                        ["buyer"] = 2402,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632887769,
                        ["quant"] = 200,
                        ["id"] = "1689477387",
                        ["itemLink"] = 779,
                    },
                    [53] = 
                    {
                        ["price"] = 2173,
                        ["guild"] = 1,
                        ["buyer"] = 2402,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632887769,
                        ["quant"] = 200,
                        ["id"] = "1689477397",
                        ["itemLink"] = 779,
                    },
                    [54] = 
                    {
                        ["price"] = 2100,
                        ["guild"] = 1,
                        ["buyer"] = 2183,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1632913185,
                        ["quant"] = 200,
                        ["id"] = "1689613113",
                        ["itemLink"] = 779,
                    },
                },
                ["totalCount"] = 54,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [147703] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 73: Anequina Chests",
                ["oldestTime"] = 1632939822,
                ["wasAltered"] = true,
                ["newestTime"] = 1633230236,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1379,
                        ["wasKiosk"] = true,
                        ["seller"] = 31,
                        ["timestamp"] = 1633183002,
                        ["quant"] = 1,
                        ["id"] = "1691611941",
                        ["itemLink"] = 1963,
                    },
                    [2] = 
                    {
                        ["price"] = 6300,
                        ["guild"] = 1,
                        ["buyer"] = 1687,
                        ["wasKiosk"] = true,
                        ["seller"] = 1108,
                        ["timestamp"] = 1633230236,
                        ["quant"] = 1,
                        ["id"] = "1692117283",
                        ["itemLink"] = 1963,
                    },
                    [3] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 1872,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1632939822,
                        ["quant"] = 1,
                        ["id"] = "1689793883",
                        ["itemLink"] = 1963,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [69368] = 
        {
            ["50:16:4:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_staff_d.dds",
                ["itemDesc"] = "Ice Staff of Agility",
                ["oldestTime"] = 1633114494,
                ["wasAltered"] = true,
                ["newestTime"] = 1633114494,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 936,
                        ["guild"] = 1,
                        ["buyer"] = 1013,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633114494,
                        ["quant"] = 1,
                        ["id"] = "1691069373",
                        ["itemLink"] = 1378,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set agility frost staff two-handed defending",
            },
        },
        [176726] = 
        {
            ["1:0:3:48:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_belt_light.dds",
                ["itemDesc"] = "Companion's Sash",
                ["oldestTime"] = 1632979705,
                ["wasAltered"] = true,
                ["newestTime"] = 1633192004,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 89999,
                        ["guild"] = 1,
                        ["buyer"] = 249,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1632979705,
                        ["quant"] = 1,
                        ["id"] = "1690129621",
                        ["itemLink"] = 260,
                    },
                    [2] = 
                    {
                        ["price"] = 89999,
                        ["guild"] = 1,
                        ["buyer"] = 807,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633064153,
                        ["quant"] = 1,
                        ["id"] = "1690741415",
                        ["itemLink"] = 260,
                    },
                    [3] = 
                    {
                        ["price"] = 89999,
                        ["guild"] = 1,
                        ["buyer"] = 1418,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633192004,
                        ["quant"] = 1,
                        ["id"] = "1691713449",
                        ["itemLink"] = 260,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior light apparel waist soothing",
            },
        },
        [126458] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_vrd_inc_hlatablerunner006.dds",
                ["itemDesc"] = "Telvanni Table Runner, Bordered Azure",
                ["oldestTime"] = 1633142132,
                ["wasAltered"] = true,
                ["newestTime"] = 1633142132,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1198,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633142132,
                        ["quant"] = 1,
                        ["id"] = "1691314329",
                        ["itemLink"] = 1619,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings parlor",
            },
        },
        [121339] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 50: Telvanni Gloves",
                ["oldestTime"] = 1633177639,
                ["wasAltered"] = true,
                ["newestTime"] = 1633283013,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 202,
                        ["wasKiosk"] = false,
                        ["seller"] = 1214,
                        ["timestamp"] = 1633177639,
                        ["quant"] = 1,
                        ["id"] = "1691567897",
                        ["itemLink"] = 1905,
                    },
                    [2] = 
                    {
                        ["price"] = 15900,
                        ["guild"] = 1,
                        ["buyer"] = 1943,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633283013,
                        ["quant"] = 1,
                        ["id"] = "1692547015",
                        ["itemLink"] = 1905,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [125692] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Impregnable Armor Necklace",
                ["oldestTime"] = 1633063298,
                ["wasAltered"] = true,
                ["newestTime"] = 1633063298,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 801,
                        ["wasKiosk"] = true,
                        ["seller"] = 802,
                        ["timestamp"] = 1633063298,
                        ["quant"] = 1,
                        ["id"] = "1690734447",
                        ["itemLink"] = 1039,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set impregnable armor neck robust",
            },
        },
        [129679] = 
        {
            ["50:16:4:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_2hsword_a.dds",
                ["itemDesc"] = "Greatsword of the Pariah",
                ["oldestTime"] = 1633100826,
                ["wasAltered"] = true,
                ["newestTime"] = 1633100826,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 947,
                        ["wasKiosk"] = true,
                        ["seller"] = 695,
                        ["timestamp"] = 1633100826,
                        ["quant"] = 1,
                        ["id"] = "1690962575",
                        ["itemLink"] = 1284,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set mark of the pariah sword two-handed training",
            },
        },
        [45054] = 
        {
            ["50:16:2:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_1hhammer_d.dds",
                ["itemDesc"] = "Rubedite Mace of Frost",
                ["oldestTime"] = 1633185894,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185894,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 245,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633185894,
                        ["quant"] = 1,
                        ["id"] = "1691639445",
                        ["itemLink"] = 1997,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon mace one-handed charged",
            },
        },
        [172163] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_1haxe_b.dds",
                ["itemDesc"] = "Deadlands Assassin's Axe",
                ["oldestTime"] = 1633074429,
                ["wasAltered"] = true,
                ["newestTime"] = 1633074429,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 860,
                        ["wasKiosk"] = true,
                        ["seller"] = 691,
                        ["timestamp"] = 1633074429,
                        ["quant"] = 1,
                        ["id"] = "1690807295",
                        ["itemLink"] = 1103,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set deadlands assassin axe one-handed precise",
            },
        },
    },
}
