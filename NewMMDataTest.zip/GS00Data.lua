GS00DataSavedVariables =
{
    ["listingseu"] = 
    {
    },
    ["listingsna"] = 
    {
    },
    ["dataeu"] = 
    {
    },
    ["datana"] = 
    {
        [129794] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_heavy_shoulders_a.dds",
                ["itemDesc"] = "Pauldron of the Pariah",
                ["oldestTime"] = 1633186496,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186496,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 464,
                        ["wasKiosk"] = true,
                        ["seller"] = 872,
                        ["timestamp"] = 1633186496,
                        ["quant"] = 1,
                        ["id"] = "1691646885",
                        ["itemLink"] = 2074,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set mark of the pariah shoulders sturdy",
            },
        },
        [141829] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_inc_artistpigments001.dds",
                ["itemDesc"] = "Artist's Palette, Pigment",
                ["oldestTime"] = 1633042586,
                ["wasAltered"] = true,
                ["newestTime"] = 1633166008,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 52532,
                        ["guild"] = 1,
                        ["buyer"] = 645,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1633042586,
                        ["quant"] = 1,
                        ["id"] = "1690534489",
                        ["itemLink"] = 829,
                    },
                    [2] = 
                    {
                        ["price"] = 52532,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1633166008,
                        ["quant"] = 1,
                        ["id"] = "1691500747",
                        ["itemLink"] = 829,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary furnishings parlor",
            },
        },
        [141830] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_exc_winestompbarrel001.dds",
                ["itemDesc"] = "Alinor Grape Stomping Tub",
                ["oldestTime"] = 1633146111,
                ["wasAltered"] = true,
                ["newestTime"] = 1633146111,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 65000,
                        ["guild"] = 1,
                        ["buyer"] = 1183,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633146111,
                        ["quant"] = 1,
                        ["id"] = "1691357625",
                        ["itemLink"] = 1652,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings hearth",
            },
        },
        [181511] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_waf_housingleycastleturret001.dds",
                ["itemDesc"] = "Leyawiin Turret, Castle",
                ["oldestTime"] = 1633165953,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165979,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 38000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633165953,
                        ["quant"] = 1,
                        ["id"] = "1691500277",
                        ["itemLink"] = 1854,
                    },
                    [2] = 
                    {
                        ["price"] = 42000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633165979,
                        ["quant"] = 1,
                        ["id"] = "1691500537",
                        ["itemLink"] = 1854,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings structures",
            },
        },
        [45833] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_016.dds",
                ["itemDesc"] = "Deni",
                ["oldestTime"] = 1632714129,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305413,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 58,
                        ["guild"] = 2,
                        ["buyer"] = 129,
                        ["wasKiosk"] = false,
                        ["seller"] = 115,
                        ["timestamp"] = 1632714129,
                        ["quant"] = 2,
                        ["id"] = "1688086075",
                        ["itemLink"] = 110,
                    },
                    [2] = 
                    {
                        ["price"] = 136,
                        ["guild"] = 1,
                        ["buyer"] = 238,
                        ["wasKiosk"] = false,
                        ["seller"] = 502,
                        ["timestamp"] = 1633061675,
                        ["quant"] = 4,
                        ["id"] = "1690722819",
                        ["itemLink"] = 110,
                    },
                    [3] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 238,
                        ["wasKiosk"] = false,
                        ["seller"] = 230,
                        ["timestamp"] = 1633061741,
                        ["quant"] = 200,
                        ["id"] = "1690723339",
                        ["itemLink"] = 110,
                    },
                    [4] = 
                    {
                        ["price"] = 19800,
                        ["guild"] = 1,
                        ["buyer"] = 1905,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1633276564,
                        ["quant"] = 200,
                        ["id"] = "1692481127",
                        ["itemLink"] = 110,
                    },
                    [5] = 
                    {
                        ["price"] = 19800,
                        ["guild"] = 1,
                        ["buyer"] = 1905,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1633276567,
                        ["quant"] = 200,
                        ["id"] = "1692481169",
                        ["itemLink"] = 110,
                    },
                    [6] = 
                    {
                        ["price"] = 19800,
                        ["guild"] = 1,
                        ["buyer"] = 40,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1633305413,
                        ["quant"] = 200,
                        ["id"] = "1692794215",
                        ["itemLink"] = 110,
                    },
                    [7] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2409,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632889573,
                        ["quant"] = 50,
                        ["id"] = "1689489829",
                        ["itemLink"] = 110,
                    },
                    [8] = 
                    {
                        ["price"] = 4346,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 158,
                        ["timestamp"] = 1632938424,
                        ["quant"] = 82,
                        ["id"] = "1689784281",
                        ["itemLink"] = 110,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "rr01 white normal materials essence runestone",
            },
        },
        [167178] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 92: Ancestral Akaviri Chests",
                ["oldestTime"] = 1633142983,
                ["wasAltered"] = true,
                ["newestTime"] = 1633198081,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750000,
                        ["guild"] = 1,
                        ["buyer"] = 149,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633142983,
                        ["quant"] = 1,
                        ["id"] = "1691324677",
                        ["itemLink"] = 1626,
                    },
                    [2] = 
                    {
                        ["price"] = 999999,
                        ["guild"] = 1,
                        ["buyer"] = 1471,
                        ["wasKiosk"] = true,
                        ["seller"] = 951,
                        ["timestamp"] = 1633198081,
                        ["quant"] = 1,
                        ["id"] = "1691769973",
                        ["itemLink"] = 1626,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [43531] = 
        {
            ["50:16:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_1hsword_d.dds",
                ["itemDesc"] = "Rubedite Sword of Shock",
                ["oldestTime"] = 1633185903,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185903,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 439,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633185903,
                        ["quant"] = 1,
                        ["id"] = "1691639651",
                        ["itemLink"] = 2004,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon sword one-handed",
            },
        },
        [178445] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_inc_leywoodframepainting008.dds",
                ["itemDesc"] = "Leyawiin at Night Painting, Wood",
                ["oldestTime"] = 1633057994,
                ["wasAltered"] = true,
                ["newestTime"] = 1633057994,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 61466,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 765,
                        ["timestamp"] = 1633057994,
                        ["quant"] = 1,
                        ["id"] = "1690690121",
                        ["itemLink"] = 977,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings gallery",
            },
        },
        [177168] = 
        {
            ["1:0:3:51:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_gloves_medium.dds",
                ["itemDesc"] = "Companion's Bracers",
                ["oldestTime"] = 1632966461,
                ["wasAltered"] = true,
                ["newestTime"] = 1632966461,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3965,
                        ["guild"] = 1,
                        ["buyer"] = 2661,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1632966461,
                        ["quant"] = 1,
                        ["id"] = "1690019181",
                        ["itemLink"] = 3967,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior medium apparel hands vigorous",
            },
        },
        [45073] = 
        {
            ["50:16:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_light_shoulders_a.dds",
                ["itemDesc"] = "Ancestor Silk Epaulets of Health",
                ["oldestTime"] = 1633186029,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186029,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 420,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1633186029,
                        ["quant"] = 1,
                        ["id"] = "1691640997",
                        ["itemLink"] = 2064,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel shoulders impenetrable",
            },
        },
        [167954] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 95: Nighthollow Shields",
                ["oldestTime"] = 1632891892,
                ["wasAltered"] = true,
                ["newestTime"] = 1632986357,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12900,
                        ["guild"] = 1,
                        ["buyer"] = 318,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632986357,
                        ["quant"] = 1,
                        ["id"] = "1690166499",
                        ["itemLink"] = 324,
                    },
                    [2] = 
                    {
                        ["price"] = 12500,
                        ["guild"] = 1,
                        ["buyer"] = 973,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632891892,
                        ["quant"] = 1,
                        ["id"] = "1689507431",
                        ["itemLink"] = 324,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45075] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_bow_d.dds",
                ["itemDesc"] = "Ruby Ash Bow of Flame",
                ["oldestTime"] = 1633180212,
                ["wasAltered"] = true,
                ["newestTime"] = 1633180212,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 1363,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633180212,
                        ["quant"] = 1,
                        ["id"] = "1691586765",
                        ["itemLink"] = 1922,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon bow two-handed charged",
            },
        },
        [171797] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting2.dds",
                ["itemDesc"] = "Praxis: Markarth Walkway, Stone",
                ["oldestTime"] = 1632971124,
                ["wasAltered"] = true,
                ["newestTime"] = 1632971124,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 172,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632971124,
                        ["quant"] = 1,
                        ["id"] = "1690067063",
                        ["itemLink"] = 192,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [173336] = 
        {
            ["50:16:5:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_staff_d.dds",
                ["itemDesc"] = "Inferno Staff of Diamond's Victory",
                ["oldestTime"] = 1633286679,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294474,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 64999,
                        ["guild"] = 1,
                        ["buyer"] = 1956,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633286679,
                        ["quant"] = 1,
                        ["id"] = "1692586641",
                        ["itemLink"] = 2758,
                    },
                    [2] = 
                    {
                        ["price"] = 64999,
                        ["guild"] = 1,
                        ["buyer"] = 1997,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633294474,
                        ["quant"] = 1,
                        ["id"] = "1692683399",
                        ["itemLink"] = 2865,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 gold legendary weapon set diamond's victory flame staff two-handed precise",
            },
        },
        [793] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_medium_armor_component_004.dds",
                ["itemDesc"] = "Rawhide Scraps",
                ["oldestTime"] = 1632852946,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185020,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983089,
                        ["quant"] = 200,
                        ["id"] = "1690148177",
                        ["itemLink"] = 297,
                    },
                    [2] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983089,
                        ["quant"] = 200,
                        ["id"] = "1690148185",
                        ["itemLink"] = 297,
                    },
                    [3] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983090,
                        ["quant"] = 200,
                        ["id"] = "1690148187",
                        ["itemLink"] = 297,
                    },
                    [4] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983090,
                        ["quant"] = 200,
                        ["id"] = "1690148193",
                        ["itemLink"] = 297,
                    },
                    [5] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983090,
                        ["quant"] = 200,
                        ["id"] = "1690148197",
                        ["itemLink"] = 297,
                    },
                    [6] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983091,
                        ["quant"] = 200,
                        ["id"] = "1690148199",
                        ["itemLink"] = 297,
                    },
                    [7] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983091,
                        ["quant"] = 200,
                        ["id"] = "1690148205",
                        ["itemLink"] = 297,
                    },
                    [8] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983092,
                        ["quant"] = 200,
                        ["id"] = "1690148211",
                        ["itemLink"] = 297,
                    },
                    [9] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983094,
                        ["quant"] = 200,
                        ["id"] = "1690148225",
                        ["itemLink"] = 297,
                    },
                    [10] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983095,
                        ["quant"] = 200,
                        ["id"] = "1690148239",
                        ["itemLink"] = 297,
                    },
                    [11] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983095,
                        ["quant"] = 200,
                        ["id"] = "1690148243",
                        ["itemLink"] = 297,
                    },
                    [12] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983096,
                        ["quant"] = 200,
                        ["id"] = "1690148247",
                        ["itemLink"] = 297,
                    },
                    [13] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983096,
                        ["quant"] = 200,
                        ["id"] = "1690148253",
                        ["itemLink"] = 297,
                    },
                    [14] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983097,
                        ["quant"] = 200,
                        ["id"] = "1690148261",
                        ["itemLink"] = 297,
                    },
                    [15] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983099,
                        ["quant"] = 200,
                        ["id"] = "1690148263",
                        ["itemLink"] = 297,
                    },
                    [16] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983101,
                        ["quant"] = 200,
                        ["id"] = "1690148271",
                        ["itemLink"] = 297,
                    },
                    [17] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983104,
                        ["quant"] = 200,
                        ["id"] = "1690148283",
                        ["itemLink"] = 297,
                    },
                    [18] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983105,
                        ["quant"] = 200,
                        ["id"] = "1690148285",
                        ["itemLink"] = 297,
                    },
                    [19] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983108,
                        ["quant"] = 200,
                        ["id"] = "1690148303",
                        ["itemLink"] = 297,
                    },
                    [20] = 
                    {
                        ["price"] = 3740,
                        ["guild"] = 1,
                        ["buyer"] = 1389,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633185020,
                        ["quant"] = 44,
                        ["id"] = "1691629327",
                        ["itemLink"] = 297,
                    },
                    [21] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852946,
                        ["quant"] = 200,
                        ["id"] = "1689166663",
                        ["itemLink"] = 297,
                    },
                    [22] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852946,
                        ["quant"] = 200,
                        ["id"] = "1689166671",
                        ["itemLink"] = 297,
                    },
                    [23] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852947,
                        ["quant"] = 200,
                        ["id"] = "1689166675",
                        ["itemLink"] = 297,
                    },
                    [24] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852948,
                        ["quant"] = 200,
                        ["id"] = "1689166681",
                        ["itemLink"] = 297,
                    },
                    [25] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852949,
                        ["quant"] = 200,
                        ["id"] = "1689166691",
                        ["itemLink"] = 297,
                    },
                    [26] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852950,
                        ["quant"] = 200,
                        ["id"] = "1689166697",
                        ["itemLink"] = 297,
                    },
                    [27] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852951,
                        ["quant"] = 200,
                        ["id"] = "1689166711",
                        ["itemLink"] = 297,
                    },
                    [28] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852954,
                        ["quant"] = 200,
                        ["id"] = "1689166737",
                        ["itemLink"] = 297,
                    },
                    [29] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852955,
                        ["quant"] = 200,
                        ["id"] = "1689166741",
                        ["itemLink"] = 297,
                    },
                    [30] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852957,
                        ["quant"] = 200,
                        ["id"] = "1689166749",
                        ["itemLink"] = 297,
                    },
                    [31] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852960,
                        ["quant"] = 200,
                        ["id"] = "1689166775",
                        ["itemLink"] = 297,
                    },
                    [32] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852962,
                        ["quant"] = 200,
                        ["id"] = "1689166799",
                        ["itemLink"] = 297,
                    },
                    [33] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852962,
                        ["quant"] = 200,
                        ["id"] = "1689166809",
                        ["itemLink"] = 297,
                    },
                    [34] = 
                    {
                        ["price"] = 2295,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632961236,
                        ["quant"] = 27,
                        ["id"] = "1689969769",
                        ["itemLink"] = 297,
                    },
                },
                ["totalCount"] = 34,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [122910] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_telvanni_staff_a.dds",
                ["itemDesc"] = "War Maiden's Restoration Staff",
                ["oldestTime"] = 1633056322,
                ["wasAltered"] = true,
                ["newestTime"] = 1633056322,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1700,
                        ["guild"] = 1,
                        ["buyer"] = 755,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633056322,
                        ["quant"] = 1,
                        ["id"] = "1690668469",
                        ["itemLink"] = 953,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set war maiden healing staff two-handed charged",
            },
        },
        [176160] = 
        {
            ["1:0:3:44:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_gloves_medium.dds",
                ["itemDesc"] = "Companion's Bracers",
                ["oldestTime"] = 1633064485,
                ["wasAltered"] = true,
                ["newestTime"] = 1633064485,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 812,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633064485,
                        ["quant"] = 1,
                        ["id"] = "1690744393",
                        ["itemLink"] = 1051,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior medium apparel hands prolific",
            },
        },
        [167970] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 96: Arkthzand Armory Maces",
                ["oldestTime"] = 1633246389,
                ["wasAltered"] = true,
                ["newestTime"] = 1633246389,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6800,
                        ["guild"] = 1,
                        ["buyer"] = 1463,
                        ["wasKiosk"] = true,
                        ["seller"] = 1720,
                        ["timestamp"] = 1633246389,
                        ["quant"] = 1,
                        ["id"] = "1692244901",
                        ["itemLink"] = 2578,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [43559] = 
        {
            ["50:16:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Lightning Staff of Flame",
                ["oldestTime"] = 1632826472,
                ["wasAltered"] = true,
                ["newestTime"] = 1632826472,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 225,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 527,
                        ["timestamp"] = 1632826472,
                        ["quant"] = 1,
                        ["id"] = "1688971699",
                        ["itemLink"] = 3043,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon lightning staff two-handed",
            },
        },
        [16424] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_book_001.dds",
                ["itemDesc"] = "Crafting Motif 1: High Elf Style",
                ["oldestTime"] = 1633017920,
                ["wasAltered"] = true,
                ["newestTime"] = 1633288175,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 484,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1633017920,
                        ["quant"] = 1,
                        ["id"] = "1690348859",
                        ["itemLink"] = 559,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 654,
                        ["wasKiosk"] = true,
                        ["seller"] = 655,
                        ["timestamp"] = 1633042960,
                        ["quant"] = 1,
                        ["id"] = "1690537529",
                        ["itemLink"] = 559,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 940,
                        ["wasKiosk"] = true,
                        ["seller"] = 493,
                        ["timestamp"] = 1633196366,
                        ["quant"] = 1,
                        ["id"] = "1691753067",
                        ["itemLink"] = 559,
                    },
                    [4] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1967,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633288175,
                        ["quant"] = 1,
                        ["id"] = "1692606539",
                        ["itemLink"] = 559,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior consumable motif",
            },
        },
        [45867] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_staminaabsorption.dds",
                ["itemDesc"] = "Superb Glyph of Absorb Stamina",
                ["oldestTime"] = 1632826380,
                ["wasAltered"] = true,
                ["newestTime"] = 1633032460,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633032460,
                        ["quant"] = 1,
                        ["id"] = "1690460841",
                        ["itemLink"] = 726,
                    },
                    [2] = 
                    {
                        ["price"] = 140,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1632826380,
                        ["quant"] = 1,
                        ["id"] = "1688971233",
                        ["itemLink"] = 726,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp150 green fine miscellaneous weapon glyph",
            },
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_staminaabsorption.dds",
                ["itemDesc"] = "Truly Superb Glyph of Absorb Stamina",
                ["oldestTime"] = 1633241269,
                ["wasAltered"] = true,
                ["newestTime"] = 1633241269,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 1779,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633241269,
                        ["quant"] = 1,
                        ["id"] = "1692206529",
                        ["itemLink"] = 2538,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous weapon glyph",
            },
            ["50:15:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_staminaabsorption.dds",
                ["itemDesc"] = "Superb Glyph of Absorb Stamina",
                ["oldestTime"] = 1633186126,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297989,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186126,
                        ["quant"] = 1,
                        ["id"] = "1691642053",
                        ["itemLink"] = 2070,
                    },
                    [2] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633297980,
                        ["quant"] = 1,
                        ["id"] = "1692720581",
                        ["itemLink"] = 2070,
                    },
                    [3] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633297981,
                        ["quant"] = 1,
                        ["id"] = "1692720609",
                        ["itemLink"] = 2070,
                    },
                    [4] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633297982,
                        ["quant"] = 1,
                        ["id"] = "1692720633",
                        ["itemLink"] = 2070,
                    },
                    [5] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633297983,
                        ["quant"] = 1,
                        ["id"] = "1692720657",
                        ["itemLink"] = 2070,
                    },
                    [6] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633297985,
                        ["quant"] = 1,
                        ["id"] = "1692720679",
                        ["itemLink"] = 2070,
                    },
                    [7] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633297986,
                        ["quant"] = 1,
                        ["id"] = "1692720705",
                        ["itemLink"] = 2070,
                    },
                    [8] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633297987,
                        ["quant"] = 1,
                        ["id"] = "1692720723",
                        ["itemLink"] = 2070,
                    },
                    [9] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633297988,
                        ["quant"] = 1,
                        ["id"] = "1692720739",
                        ["itemLink"] = 2070,
                    },
                    [10] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633297989,
                        ["quant"] = 1,
                        ["id"] = "1692720751",
                        ["itemLink"] = 2070,
                    },
                },
                ["totalCount"] = 10,
                ["itemAdderText"] = "cp150 purple epic miscellaneous weapon glyph",
            },
        },
        [45868] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_magickaabsorbtion.dds",
                ["itemDesc"] = "Superb Glyph of Absorb Magicka",
                ["oldestTime"] = 1632826376,
                ["wasAltered"] = true,
                ["newestTime"] = 1632826383,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 115,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1632826376,
                        ["quant"] = 1,
                        ["id"] = "1688971211",
                        ["itemLink"] = 3027,
                    },
                    [2] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632826383,
                        ["quant"] = 1,
                        ["id"] = "1688971269",
                        ["itemLink"] = 3027,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp150 green fine miscellaneous weapon glyph",
            },
            ["50:15:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_magickaabsorbtion.dds",
                ["itemDesc"] = "Superb Glyph of Absorb Magicka",
                ["oldestTime"] = 1632826533,
                ["wasAltered"] = true,
                ["newestTime"] = 1632826540,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 620,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632826533,
                        ["quant"] = 1,
                        ["id"] = "1688972397",
                        ["itemLink"] = 3058,
                    },
                    [2] = 
                    {
                        ["price"] = 620,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632826534,
                        ["quant"] = 1,
                        ["id"] = "1688972399",
                        ["itemLink"] = 3058,
                    },
                    [3] = 
                    {
                        ["price"] = 620,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632826535,
                        ["quant"] = 1,
                        ["id"] = "1688972403",
                        ["itemLink"] = 3058,
                    },
                    [4] = 
                    {
                        ["price"] = 620,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632826536,
                        ["quant"] = 1,
                        ["id"] = "1688972405",
                        ["itemLink"] = 3058,
                    },
                    [5] = 
                    {
                        ["price"] = 620,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632826536,
                        ["quant"] = 1,
                        ["id"] = "1688972411",
                        ["itemLink"] = 3058,
                    },
                    [6] = 
                    {
                        ["price"] = 620,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632826537,
                        ["quant"] = 1,
                        ["id"] = "1688972415",
                        ["itemLink"] = 3058,
                    },
                    [7] = 
                    {
                        ["price"] = 620,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632826537,
                        ["quant"] = 1,
                        ["id"] = "1688972417",
                        ["itemLink"] = 3058,
                    },
                    [8] = 
                    {
                        ["price"] = 620,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632826539,
                        ["quant"] = 1,
                        ["id"] = "1688972421",
                        ["itemLink"] = 3058,
                    },
                    [9] = 
                    {
                        ["price"] = 620,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632826540,
                        ["quant"] = 1,
                        ["id"] = "1688972427",
                        ["itemLink"] = 3058,
                    },
                    [10] = 
                    {
                        ["price"] = 620,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632826540,
                        ["quant"] = 1,
                        ["id"] = "1688972431",
                        ["itemLink"] = 3058,
                    },
                    [11] = 
                    {
                        ["price"] = 620,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632826540,
                        ["quant"] = 1,
                        ["id"] = "1688972435",
                        ["itemLink"] = 3058,
                    },
                },
                ["totalCount"] = 11,
                ["itemAdderText"] = "cp150 purple epic miscellaneous weapon glyph",
            },
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_magickaabsorbtion.dds",
                ["itemDesc"] = "Truly Superb Glyph of Absorb Magicka",
                ["oldestTime"] = 1633259232,
                ["wasAltered"] = true,
                ["newestTime"] = 1633259232,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1834,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1633259232,
                        ["quant"] = 1,
                        ["id"] = "1692321639",
                        ["itemLink"] = 2617,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous weapon glyph",
            },
        },
        [138797] = 
        {
            ["50:15:1:27:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Platinum Necklace",
                ["oldestTime"] = 1632842118,
                ["wasAltered"] = true,
                ["newestTime"] = 1633316377,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1632994929,
                        ["quant"] = 1,
                        ["id"] = "1690210009",
                        ["itemLink"] = 370,
                    },
                    [2] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633009404,
                        ["quant"] = 1,
                        ["id"] = "1690285865",
                        ["itemLink"] = 370,
                    },
                    [3] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633009405,
                        ["quant"] = 1,
                        ["id"] = "1690285871",
                        ["itemLink"] = 370,
                    },
                    [4] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633009406,
                        ["quant"] = 1,
                        ["id"] = "1690285883",
                        ["itemLink"] = 370,
                    },
                    [5] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633009407,
                        ["quant"] = 1,
                        ["id"] = "1690285899",
                        ["itemLink"] = 370,
                    },
                    [6] = 
                    {
                        ["price"] = 1138,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633009409,
                        ["quant"] = 1,
                        ["id"] = "1690285919",
                        ["itemLink"] = 370,
                    },
                    [7] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009412,
                        ["quant"] = 1,
                        ["id"] = "1690285959",
                        ["itemLink"] = 370,
                    },
                    [8] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 445,
                        ["timestamp"] = 1633009419,
                        ["quant"] = 1,
                        ["id"] = "1690286033",
                        ["itemLink"] = 370,
                    },
                    [9] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 445,
                        ["timestamp"] = 1633009424,
                        ["quant"] = 1,
                        ["id"] = "1690286085",
                        ["itemLink"] = 370,
                    },
                    [10] = 
                    {
                        ["price"] = 120000,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 82,
                        ["timestamp"] = 1633009427,
                        ["quant"] = 1,
                        ["id"] = "1690286129",
                        ["itemLink"] = 370,
                    },
                    [11] = 
                    {
                        ["price"] = 910,
                        ["guild"] = 1,
                        ["buyer"] = 609,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633037552,
                        ["quant"] = 1,
                        ["id"] = "1690495589",
                        ["itemLink"] = 370,
                    },
                    [12] = 
                    {
                        ["price"] = 638,
                        ["guild"] = 1,
                        ["buyer"] = 707,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633052036,
                        ["quant"] = 1,
                        ["id"] = "1690626411",
                        ["itemLink"] = 370,
                    },
                    [13] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 707,
                        ["wasKiosk"] = true,
                        ["seller"] = 552,
                        ["timestamp"] = 1633052044,
                        ["quant"] = 1,
                        ["id"] = "1690626475",
                        ["itemLink"] = 370,
                    },
                    [14] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 707,
                        ["wasKiosk"] = true,
                        ["seller"] = 552,
                        ["timestamp"] = 1633052044,
                        ["quant"] = 1,
                        ["id"] = "1690626489",
                        ["itemLink"] = 370,
                    },
                    [15] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1051,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633121078,
                        ["quant"] = 1,
                        ["id"] = "1691111569",
                        ["itemLink"] = 370,
                    },
                    [16] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633132606,
                        ["quant"] = 1,
                        ["id"] = "1691214633",
                        ["itemLink"] = 370,
                    },
                    [17] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633132624,
                        ["quant"] = 1,
                        ["id"] = "1691214789",
                        ["itemLink"] = 370,
                    },
                    [18] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633132625,
                        ["quant"] = 1,
                        ["id"] = "1691214797",
                        ["itemLink"] = 370,
                    },
                    [19] = 
                    {
                        ["price"] = 538,
                        ["guild"] = 1,
                        ["buyer"] = 881,
                        ["wasKiosk"] = true,
                        ["seller"] = 528,
                        ["timestamp"] = 1633163299,
                        ["quant"] = 1,
                        ["id"] = "1691487293",
                        ["itemLink"] = 370,
                    },
                    [20] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633186079,
                        ["quant"] = 1,
                        ["id"] = "1691641593",
                        ["itemLink"] = 370,
                    },
                    [21] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633186081,
                        ["quant"] = 1,
                        ["id"] = "1691641609",
                        ["itemLink"] = 370,
                    },
                    [22] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1440,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633194324,
                        ["quant"] = 1,
                        ["id"] = "1691737157",
                        ["itemLink"] = 370,
                    },
                    [23] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1440,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633194330,
                        ["quant"] = 1,
                        ["id"] = "1691737191",
                        ["itemLink"] = 370,
                    },
                    [24] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 1440,
                        ["wasKiosk"] = true,
                        ["seller"] = 377,
                        ["timestamp"] = 1633194342,
                        ["quant"] = 1,
                        ["id"] = "1691737231",
                        ["itemLink"] = 370,
                    },
                    [25] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 1041,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1633204194,
                        ["quant"] = 1,
                        ["id"] = "1691835251",
                        ["itemLink"] = 370,
                    },
                    [26] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 1041,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1633204196,
                        ["quant"] = 1,
                        ["id"] = "1691835297",
                        ["itemLink"] = 370,
                    },
                    [27] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 1041,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1633204197,
                        ["quant"] = 1,
                        ["id"] = "1691835305",
                        ["itemLink"] = 370,
                    },
                    [28] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 1041,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1633204197,
                        ["quant"] = 1,
                        ["id"] = "1691835315",
                        ["itemLink"] = 370,
                    },
                    [29] = 
                    {
                        ["price"] = 420,
                        ["guild"] = 1,
                        ["buyer"] = 1785,
                        ["wasKiosk"] = true,
                        ["seller"] = 1786,
                        ["timestamp"] = 1633242724,
                        ["quant"] = 1,
                        ["id"] = "1692215861",
                        ["itemLink"] = 370,
                    },
                    [30] = 
                    {
                        ["price"] = 799,
                        ["guild"] = 1,
                        ["buyer"] = 1785,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633242730,
                        ["quant"] = 1,
                        ["id"] = "1692215959",
                        ["itemLink"] = 370,
                    },
                    [31] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1845,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633263531,
                        ["quant"] = 1,
                        ["id"] = "1692347051",
                        ["itemLink"] = 370,
                    },
                    [32] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1898,
                        ["wasKiosk"] = true,
                        ["seller"] = 474,
                        ["timestamp"] = 1633274744,
                        ["quant"] = 1,
                        ["id"] = "1692460471",
                        ["itemLink"] = 370,
                    },
                    [33] = 
                    {
                        ["price"] = 1302,
                        ["guild"] = 1,
                        ["buyer"] = 1898,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633274745,
                        ["quant"] = 1,
                        ["id"] = "1692460473",
                        ["itemLink"] = 370,
                    },
                    [34] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1898,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633274746,
                        ["quant"] = 1,
                        ["id"] = "1692460487",
                        ["itemLink"] = 370,
                    },
                    [35] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 184,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633283666,
                        ["quant"] = 1,
                        ["id"] = "1692552797",
                        ["itemLink"] = 370,
                    },
                    [36] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 184,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633283667,
                        ["quant"] = 1,
                        ["id"] = "1692552805",
                        ["itemLink"] = 370,
                    },
                    [37] = 
                    {
                        ["price"] = 658,
                        ["guild"] = 1,
                        ["buyer"] = 2076,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633307944,
                        ["quant"] = 1,
                        ["id"] = "1692822295",
                        ["itemLink"] = 370,
                    },
                    [38] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633308948,
                        ["quant"] = 1,
                        ["id"] = "1692835141",
                        ["itemLink"] = 370,
                    },
                    [39] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633308965,
                        ["quant"] = 1,
                        ["id"] = "1692835481",
                        ["itemLink"] = 370,
                    },
                    [40] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633308966,
                        ["quant"] = 1,
                        ["id"] = "1692835513",
                        ["itemLink"] = 370,
                    },
                    [41] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1433,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1632842118,
                        ["quant"] = 1,
                        ["id"] = "1689074487",
                        ["itemLink"] = 370,
                    },
                    [42] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 2213,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632850219,
                        ["quant"] = 1,
                        ["id"] = "1689146267",
                        ["itemLink"] = 370,
                    },
                    [43] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865290,
                        ["quant"] = 1,
                        ["id"] = "1689266605",
                        ["itemLink"] = 370,
                    },
                    [44] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865291,
                        ["quant"] = 1,
                        ["id"] = "1689266641",
                        ["itemLink"] = 370,
                    },
                    [45] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865292,
                        ["quant"] = 1,
                        ["id"] = "1689266671",
                        ["itemLink"] = 370,
                    },
                    [46] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865293,
                        ["quant"] = 1,
                        ["id"] = "1689266687",
                        ["itemLink"] = 370,
                    },
                    [47] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865294,
                        ["quant"] = 1,
                        ["id"] = "1689266699",
                        ["itemLink"] = 370,
                    },
                    [48] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865295,
                        ["quant"] = 1,
                        ["id"] = "1689266715",
                        ["itemLink"] = 370,
                    },
                    [49] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865303,
                        ["quant"] = 1,
                        ["id"] = "1689266787",
                        ["itemLink"] = 370,
                    },
                    [50] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865304,
                        ["quant"] = 1,
                        ["id"] = "1689266825",
                        ["itemLink"] = 370,
                    },
                    [51] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865306,
                        ["quant"] = 1,
                        ["id"] = "1689266843",
                        ["itemLink"] = 370,
                    },
                    [52] = 
                    {
                        ["price"] = 1075,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632865312,
                        ["quant"] = 1,
                        ["id"] = "1689266879",
                        ["itemLink"] = 370,
                    },
                    [53] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1632865313,
                        ["quant"] = 1,
                        ["id"] = "1689266883",
                        ["itemLink"] = 370,
                    },
                    [54] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1632865313,
                        ["quant"] = 1,
                        ["id"] = "1689266889",
                        ["itemLink"] = 370,
                    },
                    [55] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632865316,
                        ["quant"] = 1,
                        ["id"] = "1689266905",
                        ["itemLink"] = 370,
                    },
                    [56] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632865316,
                        ["quant"] = 1,
                        ["id"] = "1689266911",
                        ["itemLink"] = 370,
                    },
                    [57] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632865319,
                        ["quant"] = 1,
                        ["id"] = "1689266941",
                        ["itemLink"] = 370,
                    },
                    [58] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632865321,
                        ["quant"] = 1,
                        ["id"] = "1689266959",
                        ["itemLink"] = 370,
                    },
                    [59] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 445,
                        ["timestamp"] = 1632865324,
                        ["quant"] = 1,
                        ["id"] = "1689266975",
                        ["itemLink"] = 370,
                    },
                    [60] = 
                    {
                        ["price"] = 420,
                        ["guild"] = 1,
                        ["buyer"] = 2333,
                        ["wasKiosk"] = true,
                        ["seller"] = 1786,
                        ["timestamp"] = 1632877166,
                        ["quant"] = 1,
                        ["id"] = "1689363145",
                        ["itemLink"] = 370,
                    },
                    [61] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2421,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632892359,
                        ["quant"] = 1,
                        ["id"] = "1689511603",
                        ["itemLink"] = 370,
                    },
                    [62] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2421,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632892364,
                        ["quant"] = 1,
                        ["id"] = "1689511635",
                        ["itemLink"] = 370,
                    },
                    [63] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 2458,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1632908152,
                        ["quant"] = 1,
                        ["id"] = "1689595847",
                        ["itemLink"] = 370,
                    },
                    [64] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2503,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632926863,
                        ["quant"] = 1,
                        ["id"] = "1689699801",
                        ["itemLink"] = 370,
                    },
                    [65] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 2503,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632926864,
                        ["quant"] = 1,
                        ["id"] = "1689699805",
                        ["itemLink"] = 370,
                    },
                    [66] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 2543,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1632940529,
                        ["quant"] = 1,
                        ["id"] = "1689798085",
                        ["itemLink"] = 370,
                    },
                    [67] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 2543,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1632940530,
                        ["quant"] = 1,
                        ["id"] = "1689798089",
                        ["itemLink"] = 370,
                    },
                    [68] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 2543,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1632940531,
                        ["quant"] = 1,
                        ["id"] = "1689798095",
                        ["itemLink"] = 370,
                    },
                    [69] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 2564,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1632945822,
                        ["quant"] = 1,
                        ["id"] = "1689840673",
                        ["itemLink"] = 370,
                    },
                    [70] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 2096,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633316376,
                        ["quant"] = 1,
                        ["id"] = "1692919131",
                        ["itemLink"] = 370,
                    },
                    [71] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 2096,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633316377,
                        ["quant"] = 1,
                        ["id"] = "1692919137",
                        ["itemLink"] = 370,
                    },
                },
                ["totalCount"] = 71,
                ["itemAdderText"] = "cp150 white normal jewelry apparel neck intricate",
            },
            ["1:0:1:27:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Pewter Necklace",
                ["oldestTime"] = 1633031703,
                ["wasAltered"] = true,
                ["newestTime"] = 1633248630,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 566,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633031703,
                        ["quant"] = 1,
                        ["id"] = "1690455177",
                        ["itemLink"] = 721,
                    },
                    [2] = 
                    {
                        ["price"] = 985,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633248630,
                        ["quant"] = 1,
                        ["id"] = "1692261703",
                        ["itemLink"] = 721,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal jewelry apparel neck intricate",
            },
            ["48:0:1:27:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Copper Necklace",
                ["oldestTime"] = 1632865323,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865323,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 445,
                        ["timestamp"] = 1632865323,
                        ["quant"] = 1,
                        ["id"] = "1689266973",
                        ["itemLink"] = 3334,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr48 white normal jewelry apparel neck intricate",
            },
            ["33:0:1:27:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Copper Necklace",
                ["oldestTime"] = 1633119132,
                ["wasAltered"] = true,
                ["newestTime"] = 1633119132,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 260,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633119132,
                        ["quant"] = 1,
                        ["id"] = "1691098795",
                        ["itemLink"] = 1430,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr33 white normal jewelry apparel neck intricate",
            },
            ["50:16:1:27:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Platinum Necklace",
                ["oldestTime"] = 1632850214,
                ["wasAltered"] = true,
                ["newestTime"] = 1633316375,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 913,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1632976876,
                        ["quant"] = 1,
                        ["id"] = "1690109583",
                        ["itemLink"] = 240,
                    },
                    [2] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632976876,
                        ["quant"] = 1,
                        ["id"] = "1690109585",
                        ["itemLink"] = 240,
                    },
                    [3] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632976876,
                        ["quant"] = 1,
                        ["id"] = "1690109589",
                        ["itemLink"] = 240,
                    },
                    [4] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632976877,
                        ["quant"] = 1,
                        ["id"] = "1690109597",
                        ["itemLink"] = 240,
                    },
                    [5] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632976878,
                        ["quant"] = 1,
                        ["id"] = "1690109607",
                        ["itemLink"] = 240,
                    },
                    [6] = 
                    {
                        ["price"] = 1141,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632976878,
                        ["quant"] = 1,
                        ["id"] = "1690109615",
                        ["itemLink"] = 240,
                    },
                    [7] = 
                    {
                        ["price"] = 1141,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632976879,
                        ["quant"] = 1,
                        ["id"] = "1690109625",
                        ["itemLink"] = 240,
                    },
                    [8] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1632994928,
                        ["quant"] = 1,
                        ["id"] = "1690210007",
                        ["itemLink"] = 240,
                    },
                    [9] = 
                    {
                        ["price"] = 1015,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633009402,
                        ["quant"] = 1,
                        ["id"] = "1690285847",
                        ["itemLink"] = 240,
                    },
                    [10] = 
                    {
                        ["price"] = 1015,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633009403,
                        ["quant"] = 1,
                        ["id"] = "1690285853",
                        ["itemLink"] = 240,
                    },
                    [11] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633009405,
                        ["quant"] = 1,
                        ["id"] = "1690285875",
                        ["itemLink"] = 240,
                    },
                    [12] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633009406,
                        ["quant"] = 1,
                        ["id"] = "1690285889",
                        ["itemLink"] = 240,
                    },
                    [13] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633009411,
                        ["quant"] = 1,
                        ["id"] = "1690285935",
                        ["itemLink"] = 240,
                    },
                    [14] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633009411,
                        ["quant"] = 1,
                        ["id"] = "1690285945",
                        ["itemLink"] = 240,
                    },
                    [15] = 
                    {
                        ["price"] = 1450,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 445,
                        ["timestamp"] = 1633009412,
                        ["quant"] = 1,
                        ["id"] = "1690285949",
                        ["itemLink"] = 240,
                    },
                    [16] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009415,
                        ["quant"] = 1,
                        ["id"] = "1690285989",
                        ["itemLink"] = 240,
                    },
                    [17] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009417,
                        ["quant"] = 1,
                        ["id"] = "1690286005",
                        ["itemLink"] = 240,
                    },
                    [18] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009417,
                        ["quant"] = 1,
                        ["id"] = "1690286015",
                        ["itemLink"] = 240,
                    },
                    [19] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 445,
                        ["timestamp"] = 1633009422,
                        ["quant"] = 1,
                        ["id"] = "1690286075",
                        ["itemLink"] = 240,
                    },
                    [20] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 445,
                        ["timestamp"] = 1633009427,
                        ["quant"] = 1,
                        ["id"] = "1690286123",
                        ["itemLink"] = 240,
                    },
                    [21] = 
                    {
                        ["price"] = 820,
                        ["guild"] = 1,
                        ["buyer"] = 346,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633019445,
                        ["quant"] = 1,
                        ["id"] = "1690362121",
                        ["itemLink"] = 240,
                    },
                    [22] = 
                    {
                        ["price"] = 1057,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633025270,
                        ["quant"] = 1,
                        ["id"] = "1690410447",
                        ["itemLink"] = 240,
                    },
                    [23] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633025271,
                        ["quant"] = 1,
                        ["id"] = "1690410449",
                        ["itemLink"] = 240,
                    },
                    [24] = 
                    {
                        ["price"] = 910,
                        ["guild"] = 1,
                        ["buyer"] = 584,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633033873,
                        ["quant"] = 1,
                        ["id"] = "1690468829",
                        ["itemLink"] = 240,
                    },
                    [25] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 584,
                        ["wasKiosk"] = true,
                        ["seller"] = 552,
                        ["timestamp"] = 1633033874,
                        ["quant"] = 1,
                        ["id"] = "1690468841",
                        ["itemLink"] = 240,
                    },
                    [26] = 
                    {
                        ["price"] = 910,
                        ["guild"] = 1,
                        ["buyer"] = 609,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633037553,
                        ["quant"] = 1,
                        ["id"] = "1690495595",
                        ["itemLink"] = 240,
                    },
                    [27] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 636,
                        ["wasKiosk"] = true,
                        ["seller"] = 552,
                        ["timestamp"] = 1633041447,
                        ["quant"] = 1,
                        ["id"] = "1690523977",
                        ["itemLink"] = 240,
                    },
                    [28] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 636,
                        ["wasKiosk"] = true,
                        ["seller"] = 552,
                        ["timestamp"] = 1633041447,
                        ["quant"] = 1,
                        ["id"] = "1690523985",
                        ["itemLink"] = 240,
                    },
                    [29] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 584,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633054465,
                        ["quant"] = 1,
                        ["id"] = "1690649863",
                        ["itemLink"] = 240,
                    },
                    [30] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 328,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633126108,
                        ["quant"] = 1,
                        ["id"] = "1691150187",
                        ["itemLink"] = 240,
                    },
                    [31] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633132610,
                        ["quant"] = 1,
                        ["id"] = "1691214665",
                        ["itemLink"] = 240,
                    },
                    [32] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633132620,
                        ["quant"] = 1,
                        ["id"] = "1691214741",
                        ["itemLink"] = 240,
                    },
                    [33] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633132622,
                        ["quant"] = 1,
                        ["id"] = "1691214775",
                        ["itemLink"] = 240,
                    },
                    [34] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633132623,
                        ["quant"] = 1,
                        ["id"] = "1691214781",
                        ["itemLink"] = 240,
                    },
                    [35] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633132626,
                        ["quant"] = 1,
                        ["id"] = "1691214801",
                        ["itemLink"] = 240,
                    },
                    [36] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633132630,
                        ["quant"] = 1,
                        ["id"] = "1691214843",
                        ["itemLink"] = 240,
                    },
                    [37] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633132634,
                        ["quant"] = 1,
                        ["id"] = "1691214861",
                        ["itemLink"] = 240,
                    },
                    [38] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633132637,
                        ["quant"] = 1,
                        ["id"] = "1691214889",
                        ["itemLink"] = 240,
                    },
                    [39] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1147,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633135988,
                        ["quant"] = 1,
                        ["id"] = "1691252655",
                        ["itemLink"] = 240,
                    },
                    [40] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1230,
                        ["wasKiosk"] = true,
                        ["seller"] = 61,
                        ["timestamp"] = 1633146157,
                        ["quant"] = 1,
                        ["id"] = "1691358097",
                        ["itemLink"] = 240,
                    },
                    [41] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1230,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1633147028,
                        ["quant"] = 1,
                        ["id"] = "1691366487",
                        ["itemLink"] = 240,
                    },
                    [42] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1230,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1633147030,
                        ["quant"] = 1,
                        ["id"] = "1691366505",
                        ["itemLink"] = 240,
                    },
                    [43] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1230,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633147031,
                        ["quant"] = 1,
                        ["id"] = "1691366513",
                        ["itemLink"] = 240,
                    },
                    [44] = 
                    {
                        ["price"] = 976,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633186069,
                        ["quant"] = 1,
                        ["id"] = "1691641489",
                        ["itemLink"] = 240,
                    },
                    [45] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633186076,
                        ["quant"] = 1,
                        ["id"] = "1691641563",
                        ["itemLink"] = 240,
                    },
                    [46] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633186077,
                        ["quant"] = 1,
                        ["id"] = "1691641579",
                        ["itemLink"] = 240,
                    },
                    [47] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633186082,
                        ["quant"] = 1,
                        ["id"] = "1691641615",
                        ["itemLink"] = 240,
                    },
                    [48] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1440,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633194330,
                        ["quant"] = 1,
                        ["id"] = "1691737193",
                        ["itemLink"] = 240,
                    },
                    [49] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1440,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633194339,
                        ["quant"] = 1,
                        ["id"] = "1691737219",
                        ["itemLink"] = 240,
                    },
                    [50] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1440,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633194341,
                        ["quant"] = 1,
                        ["id"] = "1691737227",
                        ["itemLink"] = 240,
                    },
                    [51] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1633238329,
                        ["quant"] = 1,
                        ["id"] = "1692187817",
                        ["itemLink"] = 240,
                    },
                    [52] = 
                    {
                        ["price"] = 1020,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633238330,
                        ["quant"] = 1,
                        ["id"] = "1692187823",
                        ["itemLink"] = 240,
                    },
                    [53] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633238332,
                        ["quant"] = 1,
                        ["id"] = "1692187829",
                        ["itemLink"] = 240,
                    },
                    [54] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633238333,
                        ["quant"] = 1,
                        ["id"] = "1692187833",
                        ["itemLink"] = 240,
                    },
                    [55] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633238333,
                        ["quant"] = 1,
                        ["id"] = "1692187837",
                        ["itemLink"] = 240,
                    },
                    [56] = 
                    {
                        ["price"] = 1223,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1633238334,
                        ["quant"] = 1,
                        ["id"] = "1692187839",
                        ["itemLink"] = 240,
                    },
                    [57] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633238335,
                        ["quant"] = 1,
                        ["id"] = "1692187841",
                        ["itemLink"] = 240,
                    },
                    [58] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633238337,
                        ["quant"] = 1,
                        ["id"] = "1692187849",
                        ["itemLink"] = 240,
                    },
                    [59] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633238337,
                        ["quant"] = 1,
                        ["id"] = "1692187851",
                        ["itemLink"] = 240,
                    },
                    [60] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633238338,
                        ["quant"] = 1,
                        ["id"] = "1692187855",
                        ["itemLink"] = 240,
                    },
                    [61] = 
                    {
                        ["price"] = 990,
                        ["guild"] = 1,
                        ["buyer"] = 1785,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633242733,
                        ["quant"] = 1,
                        ["id"] = "1692216017",
                        ["itemLink"] = 240,
                    },
                    [62] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1898,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633274748,
                        ["quant"] = 1,
                        ["id"] = "1692460515",
                        ["itemLink"] = 240,
                    },
                    [63] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633294756,
                        ["quant"] = 1,
                        ["id"] = "1692687215",
                        ["itemLink"] = 240,
                    },
                    [64] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633294756,
                        ["quant"] = 1,
                        ["id"] = "1692687231",
                        ["itemLink"] = 240,
                    },
                    [65] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633294757,
                        ["quant"] = 1,
                        ["id"] = "1692687247",
                        ["itemLink"] = 240,
                    },
                    [66] = 
                    {
                        ["price"] = 1141,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633294758,
                        ["quant"] = 1,
                        ["id"] = "1692687253",
                        ["itemLink"] = 240,
                    },
                    [67] = 
                    {
                        ["price"] = 1141,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633294759,
                        ["quant"] = 1,
                        ["id"] = "1692687269",
                        ["itemLink"] = 240,
                    },
                    [68] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 2051,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633302481,
                        ["quant"] = 1,
                        ["id"] = "1692766353",
                        ["itemLink"] = 240,
                    },
                    [69] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633308949,
                        ["quant"] = 1,
                        ["id"] = "1692835169",
                        ["itemLink"] = 240,
                    },
                    [70] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633308954,
                        ["quant"] = 1,
                        ["id"] = "1692835241",
                        ["itemLink"] = 240,
                    },
                    [71] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633308962,
                        ["quant"] = 1,
                        ["id"] = "1692835439",
                        ["itemLink"] = 240,
                    },
                    [72] = 
                    {
                        ["price"] = 980,
                        ["guild"] = 1,
                        ["buyer"] = 2213,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632850214,
                        ["quant"] = 1,
                        ["id"] = "1689146237",
                        ["itemLink"] = 240,
                    },
                    [73] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865290,
                        ["quant"] = 1,
                        ["id"] = "1689266623",
                        ["itemLink"] = 240,
                    },
                    [74] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865292,
                        ["quant"] = 1,
                        ["id"] = "1689266653",
                        ["itemLink"] = 240,
                    },
                    [75] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865297,
                        ["quant"] = 1,
                        ["id"] = "1689266743",
                        ["itemLink"] = 240,
                    },
                    [76] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865300,
                        ["quant"] = 1,
                        ["id"] = "1689266761",
                        ["itemLink"] = 240,
                    },
                    [77] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865301,
                        ["quant"] = 1,
                        ["id"] = "1689266765",
                        ["itemLink"] = 240,
                    },
                    [78] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865302,
                        ["quant"] = 1,
                        ["id"] = "1689266781",
                        ["itemLink"] = 240,
                    },
                    [79] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 377,
                        ["timestamp"] = 1632865309,
                        ["quant"] = 1,
                        ["id"] = "1689266859",
                        ["itemLink"] = 240,
                    },
                    [80] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1632865310,
                        ["quant"] = 1,
                        ["id"] = "1689266873",
                        ["itemLink"] = 240,
                    },
                    [81] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1632865314,
                        ["quant"] = 1,
                        ["id"] = "1689266893",
                        ["itemLink"] = 240,
                    },
                    [82] = 
                    {
                        ["price"] = 1017,
                        ["guild"] = 1,
                        ["buyer"] = 1942,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632890255,
                        ["quant"] = 1,
                        ["id"] = "1689494297",
                        ["itemLink"] = 240,
                    },
                    [83] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2421,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632892362,
                        ["quant"] = 1,
                        ["id"] = "1689511619",
                        ["itemLink"] = 240,
                    },
                    [84] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 2501,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1632926021,
                        ["quant"] = 1,
                        ["id"] = "1689694137",
                        ["itemLink"] = 240,
                    },
                    [85] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 2564,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1632945818,
                        ["quant"] = 1,
                        ["id"] = "1689840643",
                        ["itemLink"] = 240,
                    },
                    [86] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 2564,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1632945820,
                        ["quant"] = 1,
                        ["id"] = "1689840657",
                        ["itemLink"] = 240,
                    },
                    [87] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 2564,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1632945823,
                        ["quant"] = 1,
                        ["id"] = "1689840679",
                        ["itemLink"] = 240,
                    },
                    [88] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 881,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632952199,
                        ["quant"] = 1,
                        ["id"] = "1689893743",
                        ["itemLink"] = 240,
                    },
                    [89] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 2096,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633316375,
                        ["quant"] = 1,
                        ["id"] = "1692919123",
                        ["itemLink"] = 240,
                    },
                },
                ["totalCount"] = 89,
                ["itemAdderText"] = "cp160 white normal jewelry apparel neck intricate",
            },
            ["26:0:1:27:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Copper Necklace",
                ["oldestTime"] = 1633057611,
                ["wasAltered"] = true,
                ["newestTime"] = 1633057611,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 842,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633057611,
                        ["quant"] = 1,
                        ["id"] = "1690686805",
                        ["itemLink"] = 968,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr26 white normal jewelry apparel neck intricate",
            },
        },
        [69166] = 
        {
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of Endurance",
                ["oldestTime"] = 1633163935,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163935,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4995,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1633163935,
                        ["quant"] = 1,
                        ["id"] = "1691490493",
                        ["itemLink"] = 1827,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set endurance neck healthy",
            },
        },
        [71727] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 27: Ebonheart Pact Gloves",
                ["oldestTime"] = 1632834714,
                ["wasAltered"] = true,
                ["newestTime"] = 1632834714,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1448,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1632834714,
                        ["quant"] = 1,
                        ["id"] = "1689025287",
                        ["itemLink"] = 3097,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [69168] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of Endurance",
                ["oldestTime"] = 1632839086,
                ["wasAltered"] = true,
                ["newestTime"] = 1633115678,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3300,
                        ["guild"] = 1,
                        ["buyer"] = 646,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633042174,
                        ["quant"] = 1,
                        ["id"] = "1690530001",
                        ["itemLink"] = 817,
                    },
                    [2] = 
                    {
                        ["price"] = 2999,
                        ["guild"] = 1,
                        ["buyer"] = 196,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633115678,
                        ["quant"] = 1,
                        ["id"] = "1691076349",
                        ["itemLink"] = 1394,
                    },
                    [3] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 51,
                        ["timestamp"] = 1632839086,
                        ["quant"] = 1,
                        ["id"] = "1689055085",
                        ["itemLink"] = 1394,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set endurance neck arcane",
            },
        },
        [45873] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_decreasebashblockcost.dds",
                ["itemDesc"] = "Superb Glyph of Bracing",
                ["oldestTime"] = 1632826379,
                ["wasAltered"] = true,
                ["newestTime"] = 1633251479,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 227,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633032469,
                        ["quant"] = 1,
                        ["id"] = "1690460935",
                        ["itemLink"] = 736,
                    },
                    [2] = 
                    {
                        ["price"] = 85,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 78,
                        ["timestamp"] = 1633251479,
                        ["quant"] = 1,
                        ["id"] = "1692280587",
                        ["itemLink"] = 736,
                    },
                    [3] = 
                    {
                        ["price"] = 140,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 527,
                        ["timestamp"] = 1632826379,
                        ["quant"] = 1,
                        ["id"] = "1688971231",
                        ["itemLink"] = 736,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp150 green fine miscellaneous jewelry glyph",
            },
        },
        [46132] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_cloth_ironthread.dds",
                ["itemDesc"] = "Ironthread",
                ["oldestTime"] = 1633176547,
                ["wasAltered"] = true,
                ["newestTime"] = 1633176547,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1356,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633176547,
                        ["quant"] = 200,
                        ["id"] = "1691559183",
                        ["itemLink"] = 1903,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [145973] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Murkmire Berry Strand",
                ["oldestTime"] = 1632852116,
                ["wasAltered"] = true,
                ["newestTime"] = 1632852116,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 29027,
                        ["guild"] = 1,
                        ["buyer"] = 2221,
                        ["wasKiosk"] = true,
                        ["seller"] = 1756,
                        ["timestamp"] = 1632852116,
                        ["quant"] = 1,
                        ["id"] = "1689160087",
                        ["itemLink"] = 3249,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [46138] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_leather_base_leather_r2.dds",
                ["itemDesc"] = "Shadowhide",
                ["oldestTime"] = 1632900178,
                ["wasAltered"] = true,
                ["newestTime"] = 1632900178,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3260,
                        ["guild"] = 1,
                        ["buyer"] = 2444,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1632900178,
                        ["quant"] = 163,
                        ["id"] = "1689560243",
                        ["itemLink"] = 3574,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [175934] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Leyawiin Banner, Abstract",
                ["oldestTime"] = 1633091039,
                ["wasAltered"] = true,
                ["newestTime"] = 1633315571,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 76,
                        ["wasKiosk"] = false,
                        ["seller"] = 100,
                        ["timestamp"] = 1633315571,
                        ["quant"] = 1,
                        ["id"] = "1692911227",
                        ["itemLink"] = 72,
                    },
                    [2] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 655,
                        ["wasKiosk"] = false,
                        ["seller"] = 911,
                        ["timestamp"] = 1633091039,
                        ["quant"] = 1,
                        ["id"] = "1690894511",
                        ["itemLink"] = 72,
                    },
                    [3] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 958,
                        ["wasKiosk"] = true,
                        ["seller"] = 911,
                        ["timestamp"] = 1633103084,
                        ["quant"] = 1,
                        ["id"] = "1690984827",
                        ["itemLink"] = 72,
                    },
                    [4] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 1091,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1633127220,
                        ["quant"] = 1,
                        ["id"] = "1691160277",
                        ["itemLink"] = 72,
                    },
                    [5] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1523,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633205601,
                        ["quant"] = 1,
                        ["id"] = "1691849549",
                        ["itemLink"] = 72,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [119360] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Common Basket, Lid",
                ["oldestTime"] = 1632452998,
                ["wasAltered"] = true,
                ["newestTime"] = 1632452998,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 34,
                        ["guild"] = 2,
                        ["buyer"] = 110,
                        ["wasKiosk"] = false,
                        ["seller"] = 111,
                        ["timestamp"] = 1632452998,
                        ["quant"] = 1,
                        ["id"] = "1685858753",
                        ["itemLink"] = 81,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [160578] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 87: Ancestral Nord Belts",
                ["oldestTime"] = 1632970182,
                ["wasAltered"] = true,
                ["newestTime"] = 1632970182,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5999,
                        ["guild"] = 1,
                        ["buyer"] = 160,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632970182,
                        ["quant"] = 1,
                        ["id"] = "1690058673",
                        ["itemLink"] = 171,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [118339] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_gen_exc_fishbundle001.dds",
                ["itemDesc"] = "Fish, Salmon",
                ["oldestTime"] = 1633064679,
                ["wasAltered"] = true,
                ["newestTime"] = 1633064679,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 814,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633064679,
                        ["quant"] = 2,
                        ["id"] = "1690745913",
                        ["itemLink"] = 1054,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings hearth",
            },
        },
        [160581] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 87: Ancestral Nord Chests",
                ["oldestTime"] = 1632927930,
                ["wasAltered"] = true,
                ["newestTime"] = 1632927930,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9877,
                        ["guild"] = 1,
                        ["buyer"] = 53,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1632927930,
                        ["quant"] = 1,
                        ["id"] = "1689706363",
                        ["itemLink"] = 3691,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [97354] = 
        {
            ["50:16:4:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_d.dds",
                ["itemDesc"] = "Ice Staff of a Mother's Sorrow",
                ["oldestTime"] = 1632882087,
                ["wasAltered"] = true,
                ["newestTime"] = 1632882087,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11999,
                        ["guild"] = 1,
                        ["buyer"] = 2202,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632882087,
                        ["quant"] = 1,
                        ["id"] = "1689419257",
                        ["itemLink"] = 3474,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set mother's sorrow frost staff two-handed decisive",
            },
        },
        [115533] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_arg_lsb_mudlamp003.dds",
                ["itemDesc"] = "Argonian Brazier, Mud",
                ["oldestTime"] = 1633239334,
                ["wasAltered"] = true,
                ["newestTime"] = 1633239334,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1760,
                        ["wasKiosk"] = true,
                        ["seller"] = 99,
                        ["timestamp"] = 1633239334,
                        ["quant"] = 1,
                        ["id"] = "1692193411",
                        ["itemLink"] = 2521,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [181584] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Leyawiin Platform, Large Square",
                ["oldestTime"] = 1633115072,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292257,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1016,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1633115072,
                        ["quant"] = 1,
                        ["id"] = "1691072345",
                        ["itemLink"] = 1389,
                    },
                    [2] = 
                    {
                        ["price"] = 48900,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 48,
                        ["timestamp"] = 1633185682,
                        ["quant"] = 1,
                        ["id"] = "1691637029",
                        ["itemLink"] = 1389,
                    },
                    [3] = 
                    {
                        ["price"] = 67500,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 479,
                        ["timestamp"] = 1633292257,
                        ["quant"] = 1,
                        ["id"] = "1692654465",
                        ["itemLink"] = 1389,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [125777] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_shield_a.dds",
                ["itemDesc"] = "Impregnable Armor Shield",
                ["oldestTime"] = 1632908930,
                ["wasAltered"] = true,
                ["newestTime"] = 1632908930,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 2459,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1632908930,
                        ["quant"] = 1,
                        ["id"] = "1689598641",
                        ["itemLink"] = 3599,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic apparel weapon set impregnable armor shield off hand well-fitted",
            },
        },
        [61011] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Artifact-Hunter's Band",
                ["oldestTime"] = 1633163914,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163914,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 51,
                        ["timestamp"] = 1633163914,
                        ["quant"] = 1,
                        ["id"] = "1691490339",
                        ["itemLink"] = 1810,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel ring arcane",
            },
        },
        [86356] = 
        {
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_wormcult_light_shoulders_a.dds",
                ["itemDesc"] = "Epaulets of the Withered Hand",
                ["oldestTime"] = 1632826000,
                ["wasAltered"] = true,
                ["newestTime"] = 1632826000,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2118,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632826000,
                        ["quant"] = 1,
                        ["id"] = "1688969015",
                        ["itemLink"] = 3026,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set robes of the withered hand shoulders training",
            },
        },
        [134486] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing2.dds",
                ["itemDesc"] = "Diagram: Clockwork Barrel, Sealed",
                ["oldestTime"] = 1633109411,
                ["wasAltered"] = true,
                ["newestTime"] = 1633109411,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 979,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633109411,
                        ["quant"] = 1,
                        ["id"] = "1691031793",
                        ["itemLink"] = 1318,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [45912] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Baked Potato",
                ["oldestTime"] = 1633068122,
                ["wasAltered"] = true,
                ["newestTime"] = 1633068122,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30,
                        ["guild"] = 2,
                        ["buyer"] = 135,
                        ["wasKiosk"] = false,
                        ["seller"] = 128,
                        ["timestamp"] = 1633068122,
                        ["quant"] = 1,
                        ["id"] = "1690768129",
                        ["itemLink"] = 146,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [45913] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Banana Surprise",
                ["oldestTime"] = 1632897193,
                ["wasAltered"] = true,
                ["newestTime"] = 1632897193,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 27,
                        ["guild"] = 1,
                        ["buyer"] = 1304,
                        ["wasKiosk"] = true,
                        ["seller"] = 531,
                        ["timestamp"] = 1632897193,
                        ["quant"] = 1,
                        ["id"] = "1689543255",
                        ["itemLink"] = 3566,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [45149] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_medium_head_d.dds",
                ["itemDesc"] = "Rubedo Leather Helmet of Health",
                ["oldestTime"] = 1633023027,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023027,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 510,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1633023027,
                        ["quant"] = 1,
                        ["id"] = "1690390881",
                        ["itemLink"] = 651,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel head well-fitted",
            },
        },
        [146014] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Murkmire Rug, Lurking Lizard",
                ["oldestTime"] = 1633216471,
                ["wasAltered"] = true,
                ["newestTime"] = 1633216471,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16850,
                        ["guild"] = 1,
                        ["buyer"] = 1589,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1633216471,
                        ["quant"] = 1,
                        ["id"] = "1691973081",
                        ["itemLink"] = 2319,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [75360] = 
        {
            ["30:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_potion_base_oil_3_r1.dds",
                ["itemDesc"] = "Gall",
                ["oldestTime"] = 1633100135,
                ["wasAltered"] = true,
                ["newestTime"] = 1633100135,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 941,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633100135,
                        ["quant"] = 200,
                        ["id"] = "1690958079",
                        ["itemLink"] = 1278,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr30 white normal materials poison solvent",
            },
        },
        [43619] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Bangkorai Treasure Map I",
                ["oldestTime"] = 1633054295,
                ["wasAltered"] = true,
                ["newestTime"] = 1633054295,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 733,
                        ["wasKiosk"] = true,
                        ["seller"] = 734,
                        ["timestamp"] = 1633054295,
                        ["quant"] = 1,
                        ["id"] = "1690648187",
                        ["itemLink"] = 938,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [176997] = 
        {
            ["1:0:2:41:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_greatsword.dds",
                ["itemDesc"] = "Companion's Greatsword",
                ["oldestTime"] = 1633222938,
                ["wasAltered"] = true,
                ["newestTime"] = 1633222938,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 67,
                        ["guild"] = 1,
                        ["buyer"] = 1625,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1633222938,
                        ["quant"] = 1,
                        ["id"] = "1692042471",
                        ["itemLink"] = 2365,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine weapon sword two-handed bolstered",
            },
        },
        [167527] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_arkthzand_heavy_hands_a.dds",
                ["itemDesc"] = "Gauntlets of the Radiant Bastion",
                ["oldestTime"] = 1633180600,
                ["wasAltered"] = true,
                ["newestTime"] = 1633180600,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1367,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633180600,
                        ["quant"] = 1,
                        ["id"] = "1691589213",
                        ["itemLink"] = 1926,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set radiant bastion hands impenetrable",
            },
        },
        [68200] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Solitude Salmon-Millet Soup",
                ["oldestTime"] = 1633076496,
                ["wasAltered"] = true,
                ["newestTime"] = 1633084348,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 125,
                        ["guild"] = 1,
                        ["buyer"] = 870,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1633076496,
                        ["quant"] = 1,
                        ["id"] = "1690819373",
                        ["itemLink"] = 1115,
                    },
                    [2] = 
                    {
                        ["price"] = 699,
                        ["guild"] = 1,
                        ["buyer"] = 897,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633084348,
                        ["quant"] = 1,
                        ["id"] = "1690856001",
                        ["itemLink"] = 1115,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45673] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Parrot-and-Pumpkin Salad",
                ["oldestTime"] = 1632865315,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865315,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2261,
                        ["wasKiosk"] = true,
                        ["seller"] = 1145,
                        ["timestamp"] = 1632865315,
                        ["quant"] = 1,
                        ["id"] = "1689266903",
                        ["itemLink"] = 3332,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [116074] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing4.dds",
                ["itemDesc"] = "Diagram: Dark Elf Censer, Hanging",
                ["oldestTime"] = 1632865542,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865542,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 23750,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1632865542,
                        ["quant"] = 1,
                        ["id"] = "1689268949",
                        ["itemLink"] = 3347,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [75371] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_thieves_guild_r1.dds",
                ["itemDesc"] = "Coarse Chalk",
                ["oldestTime"] = 1633048118,
                ["wasAltered"] = true,
                ["newestTime"] = 1633048118,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45,
                        ["guild"] = 1,
                        ["buyer"] = 151,
                        ["wasKiosk"] = false,
                        ["seller"] = 333,
                        ["timestamp"] = 1633048118,
                        ["quant"] = 1,
                        ["id"] = "1690587205",
                        ["itemLink"] = 874,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [171884] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 103: Black Fin Legion Daggers",
                ["oldestTime"] = 1632983205,
                ["wasAltered"] = true,
                ["newestTime"] = 1633058272,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 64000,
                        ["guild"] = 1,
                        ["buyer"] = 296,
                        ["wasKiosk"] = true,
                        ["seller"] = 71,
                        ["timestamp"] = 1632983205,
                        ["quant"] = 1,
                        ["id"] = "1690149005",
                        ["itemLink"] = 302,
                    },
                    [2] = 
                    {
                        ["price"] = 72000,
                        ["guild"] = 1,
                        ["buyer"] = 281,
                        ["wasKiosk"] = false,
                        ["seller"] = 515,
                        ["timestamp"] = 1633021630,
                        ["quant"] = 1,
                        ["id"] = "1690380351",
                        ["itemLink"] = 302,
                    },
                    [3] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 311,
                        ["timestamp"] = 1633058272,
                        ["quant"] = 1,
                        ["id"] = "1690692965",
                        ["itemLink"] = 302,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [27246] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_book_001.dds",
                ["itemDesc"] = "Crafting Motif 9: Argonian Style",
                ["oldestTime"] = 1632820750,
                ["wasAltered"] = true,
                ["newestTime"] = 1633243377,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 484,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633017346,
                        ["quant"] = 1,
                        ["id"] = "1690343803",
                        ["itemLink"] = 551,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 484,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633017932,
                        ["quant"] = 1,
                        ["id"] = "1690348985",
                        ["itemLink"] = 551,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 944,
                        ["wasKiosk"] = false,
                        ["seller"] = 227,
                        ["timestamp"] = 1633243377,
                        ["quant"] = 1,
                        ["id"] = "1692221219",
                        ["itemLink"] = 551,
                    },
                    [4] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2103,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632820750,
                        ["quant"] = 1,
                        ["id"] = "1688947469",
                        ["itemLink"] = 551,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior consumable motif",
            },
        },
        [58480] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_medium_legs_a.dds",
                ["itemDesc"] = "Guards of the Twice-Born Star",
                ["oldestTime"] = 1633292246,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292246,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1990,
                        ["wasKiosk"] = true,
                        ["seller"] = 832,
                        ["timestamp"] = 1633292246,
                        ["quant"] = 1,
                        ["id"] = "1692654301",
                        ["itemLink"] = 2814,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set twice-born star legs divines",
            },
        },
        [45941] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Hunter's Pie",
                ["oldestTime"] = 1632839854,
                ["wasAltered"] = true,
                ["newestTime"] = 1632839854,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 27,
                        ["guild"] = 1,
                        ["buyer"] = 2173,
                        ["wasKiosk"] = true,
                        ["seller"] = 531,
                        ["timestamp"] = 1632839854,
                        ["quant"] = 1,
                        ["id"] = "1689059339",
                        ["itemLink"] = 3133,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [167798] = 
        {
            ["50:16:4:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_waywardguardian_staff_a.dds",
                ["itemDesc"] = "Witch-Knight's Inferno Staff",
                ["oldestTime"] = 1633017016,
                ["wasAltered"] = true,
                ["newestTime"] = 1633017016,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9500,
                        ["guild"] = 1,
                        ["buyer"] = 481,
                        ["wasKiosk"] = true,
                        ["seller"] = 474,
                        ["timestamp"] = 1633017016,
                        ["quant"] = 1,
                        ["id"] = "1690341885",
                        ["itemLink"] = 547,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set witch-knight's defiance flame staff two-handed powered",
            },
        },
        [172407] = 
        {
            ["50:16:2:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_hvy_waist_a.dds",
                ["itemDesc"] = "Bog Raider's Girdle",
                ["oldestTime"] = 1633141163,
                ["wasAltered"] = true,
                ["newestTime"] = 1633141163,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 1188,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633141163,
                        ["quant"] = 1,
                        ["id"] = "1691302991",
                        ["itemLink"] = 1612,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set bog raider waist invigorating",
            },
        },
        [142200] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 68: Honor Guard Swords",
                ["oldestTime"] = 1633000592,
                ["wasAltered"] = true,
                ["newestTime"] = 1633169251,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 395,
                        ["wasKiosk"] = true,
                        ["seller"] = 386,
                        ["timestamp"] = 1633000592,
                        ["quant"] = 1,
                        ["id"] = "1690237263",
                        ["itemLink"] = 398,
                    },
                    [2] = 
                    {
                        ["price"] = 13667,
                        ["guild"] = 1,
                        ["buyer"] = 1334,
                        ["wasKiosk"] = true,
                        ["seller"] = 1215,
                        ["timestamp"] = 1633169251,
                        ["quant"] = 1,
                        ["id"] = "1691515509",
                        ["itemLink"] = 398,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [171902] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 101: Ivory Brigade Gloves",
                ["oldestTime"] = 1633029773,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291293,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7950,
                        ["guild"] = 1,
                        ["buyer"] = 558,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633029773,
                        ["quant"] = 1,
                        ["id"] = "1690442683",
                        ["itemLink"] = 709,
                    },
                    [2] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 242,
                        ["wasKiosk"] = false,
                        ["seller"] = 604,
                        ["timestamp"] = 1633052089,
                        ["quant"] = 1,
                        ["id"] = "1690626899",
                        ["itemLink"] = 709,
                    },
                    [3] = 
                    {
                        ["price"] = 9500,
                        ["guild"] = 1,
                        ["buyer"] = 1628,
                        ["wasKiosk"] = true,
                        ["seller"] = 911,
                        ["timestamp"] = 1633223311,
                        ["quant"] = 1,
                        ["id"] = "1692046765",
                        ["itemLink"] = 709,
                    },
                    [4] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1171,
                        ["wasKiosk"] = true,
                        ["seller"] = 22,
                        ["timestamp"] = 1633291293,
                        ["quant"] = 1,
                        ["id"] = "1692641949",
                        ["itemLink"] = 709,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [68224] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Camlorn Sweet Brown Ale",
                ["oldestTime"] = 1632913043,
                ["wasAltered"] = true,
                ["newestTime"] = 1633222206,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50,
                        ["guild"] = 1,
                        ["buyer"] = 76,
                        ["wasKiosk"] = false,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633222206,
                        ["quant"] = 1,
                        ["id"] = "1692034691",
                        ["itemLink"] = 2355,
                    },
                    [2] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2471,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632913043,
                        ["quant"] = 1,
                        ["id"] = "1689612443",
                        ["itemLink"] = 2355,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45189] = 
        {
            ["50:16:2:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Inferno Staff of Shock",
                ["oldestTime"] = 1633200111,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200111,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1485,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633200111,
                        ["quant"] = 1,
                        ["id"] = "1691791347",
                        ["itemLink"] = 2184,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon flame staff two-handed defending",
            },
        },
        [176006] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Leyawiin Tomatoes, Vine",
                ["oldestTime"] = 1633091029,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242868,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 655,
                        ["wasKiosk"] = false,
                        ["seller"] = 911,
                        ["timestamp"] = 1633091029,
                        ["quant"] = 1,
                        ["id"] = "1690894423",
                        ["itemLink"] = 1240,
                    },
                    [2] = 
                    {
                        ["price"] = 299,
                        ["guild"] = 1,
                        ["buyer"] = 997,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633112657,
                        ["quant"] = 1,
                        ["id"] = "1691056615",
                        ["itemLink"] = 1240,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 31,
                        ["wasKiosk"] = false,
                        ["seller"] = 930,
                        ["timestamp"] = 1633200568,
                        ["quant"] = 1,
                        ["id"] = "1691795505",
                        ["itemLink"] = 1240,
                    },
                    [4] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1331,
                        ["wasKiosk"] = true,
                        ["seller"] = 911,
                        ["timestamp"] = 1633242868,
                        ["quant"] = 1,
                        ["id"] = "1692217525",
                        ["itemLink"] = 1240,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [172423] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_hvy_hands_a.dds",
                ["itemDesc"] = "Bog Raider's Gauntlets",
                ["oldestTime"] = 1633200591,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200591,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 180,
                        ["guild"] = 1,
                        ["buyer"] = 1490,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1633200591,
                        ["quant"] = 1,
                        ["id"] = "1691795781",
                        ["itemLink"] = 2190,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set bog raider hands sturdy",
            },
        },
        [176008] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Leyawiin Lettuce, Leaf",
                ["oldestTime"] = 1633127241,
                ["wasAltered"] = true,
                ["newestTime"] = 1633272464,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1091,
                        ["wasKiosk"] = true,
                        ["seller"] = 353,
                        ["timestamp"] = 1633127241,
                        ["quant"] = 1,
                        ["id"] = "1691160499",
                        ["itemLink"] = 1492,
                    },
                    [2] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1643,
                        ["wasKiosk"] = true,
                        ["seller"] = 911,
                        ["timestamp"] = 1633272464,
                        ["quant"] = 1,
                        ["id"] = "1692431761",
                        ["itemLink"] = 1492,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [116178] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Nord Stool, Braced",
                ["oldestTime"] = 1632877842,
                ["wasAltered"] = true,
                ["newestTime"] = 1632877842,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2340,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632877842,
                        ["quant"] = 1,
                        ["id"] = "1689371093",
                        ["itemLink"] = 3436,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [28639] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_bread_005.dds",
                ["itemDesc"] = "Rye",
                ["oldestTime"] = 1633236170,
                ["wasAltered"] = true,
                ["newestTime"] = 1633236170,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1735,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633236170,
                        ["quant"] = 200,
                        ["id"] = "1692168805",
                        ["itemLink"] = 2494,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [139407] = 
        {
            ["50:15:1:31:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Platinum Necklace",
                ["oldestTime"] = 1633124382,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311281,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 8,
                        ["wasKiosk"] = false,
                        ["seller"] = 9,
                        ["timestamp"] = 1633311281,
                        ["quant"] = 1,
                        ["id"] = "1692863457",
                        ["itemLink"] = 7,
                    },
                    [2] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1075,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633124382,
                        ["quant"] = 1,
                        ["id"] = "1691137431",
                        ["itemLink"] = 7,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp150 white normal jewelry apparel neck bloodthirsty",
            },
        },
        [45712] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Savory Mid Year Preserves",
                ["oldestTime"] = 1632870700,
                ["wasAltered"] = true,
                ["newestTime"] = 1632870700,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 2290,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632870700,
                        ["quant"] = 1,
                        ["id"] = "1689308343",
                        ["itemLink"] = 3388,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [68204] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Chevre-Radish Salad with Pumpkin Seeds",
                ["oldestTime"] = 1632839878,
                ["wasAltered"] = true,
                ["newestTime"] = 1633222234,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 839,
                        ["wasKiosk"] = true,
                        ["seller"] = 697,
                        ["timestamp"] = 1633151662,
                        ["quant"] = 1,
                        ["id"] = "1691405397",
                        ["itemLink"] = 1731,
                    },
                    [2] = 
                    {
                        ["price"] = 186,
                        ["guild"] = 1,
                        ["buyer"] = 76,
                        ["wasKiosk"] = false,
                        ["seller"] = 399,
                        ["timestamp"] = 1633222234,
                        ["quant"] = 1,
                        ["id"] = "1692034989",
                        ["itemLink"] = 1731,
                    },
                    [3] = 
                    {
                        ["price"] = 75,
                        ["guild"] = 1,
                        ["buyer"] = 2174,
                        ["wasKiosk"] = true,
                        ["seller"] = 353,
                        ["timestamp"] = 1632839878,
                        ["quant"] = 1,
                        ["id"] = "1689059553",
                        ["itemLink"] = 1731,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [56976] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Ordinator's Beetle-Cheese Soup",
                ["oldestTime"] = 1632956048,
                ["wasAltered"] = true,
                ["newestTime"] = 1632956048,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2046,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632956048,
                        ["quant"] = 1,
                        ["id"] = "1689927919",
                        ["itemLink"] = 3868,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [171740] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Imperial Champion Mace",
                ["oldestTime"] = 1632953420,
                ["wasAltered"] = true,
                ["newestTime"] = 1632953420,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 333,
                        ["guild"] = 1,
                        ["buyer"] = 2603,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1632953420,
                        ["quant"] = 1,
                        ["id"] = "1689905101",
                        ["itemLink"] = 3859,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [134314] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_bsh_clkleafy003.dds",
                ["itemDesc"] = "Fabricant Shrub, Gold",
                ["oldestTime"] = 1632952194,
                ["wasAltered"] = true,
                ["newestTime"] = 1632952195,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6200,
                        ["guild"] = 1,
                        ["buyer"] = 2594,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1632952194,
                        ["quant"] = 1,
                        ["id"] = "1689893657",
                        ["itemLink"] = 3846,
                    },
                    [2] = 
                    {
                        ["price"] = 7200,
                        ["guild"] = 1,
                        ["buyer"] = 2594,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632952195,
                        ["quant"] = 1,
                        ["id"] = "1689893675",
                        ["itemLink"] = 3846,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine furnishings conservatory",
            },
        },
        [30357] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/lockpick.dds",
                ["itemDesc"] = "Lockpick",
                ["oldestTime"] = 1632849649,
                ["wasAltered"] = true,
                ["newestTime"] = 1633135758,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 162,
                        ["wasKiosk"] = false,
                        ["seller"] = 9,
                        ["timestamp"] = 1633134110,
                        ["quant"] = 200,
                        ["id"] = "1691232141",
                        ["itemLink"] = 1549,
                    },
                    [2] = 
                    {
                        ["price"] = 9,
                        ["guild"] = 1,
                        ["buyer"] = 1143,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633135758,
                        ["quant"] = 9,
                        ["id"] = "1691251215",
                        ["itemLink"] = 1549,
                    },
                    [3] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1033,
                        ["wasKiosk"] = false,
                        ["seller"] = 9,
                        ["timestamp"] = 1632849649,
                        ["quant"] = 200,
                        ["id"] = "1689140919",
                        ["itemLink"] = 1549,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal miscellaneous tool",
            },
        },
        [176880] = 
        {
            ["1:0:3:49:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_gloves_medium.dds",
                ["itemDesc"] = "Companion's Bracers",
                ["oldestTime"] = 1632950541,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950541,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 2587,
                        ["wasKiosk"] = true,
                        ["seller"] = 8,
                        ["timestamp"] = 1632950541,
                        ["quant"] = 1,
                        ["id"] = "1689878197",
                        ["itemLink"] = 3839,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior medium apparel hands augmented",
            },
        },
        [115863] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Wood Elf Bookcase, Leather",
                ["oldestTime"] = 1633200301,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200301,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1487,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633200301,
                        ["quant"] = 1,
                        ["id"] = "1691793227",
                        ["itemLink"] = 2186,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [71576] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 23: Malacath Maces",
                ["oldestTime"] = 1632852235,
                ["wasAltered"] = true,
                ["newestTime"] = 1632852235,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 1497,
                        ["timestamp"] = 1632852235,
                        ["quant"] = 1,
                        ["id"] = "1689160743",
                        ["itemLink"] = 3250,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [127043] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Indoril Rug, Vivec",
                ["oldestTime"] = 1633227662,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227662,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 38000,
                        ["guild"] = 1,
                        ["buyer"] = 521,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633227662,
                        ["quant"] = 1,
                        ["id"] = "1692092555",
                        ["itemLink"] = 2409,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [71578] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 23: Malacath Shoulders",
                ["oldestTime"] = 1632941314,
                ["wasAltered"] = true,
                ["newestTime"] = 1632941314,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10200,
                        ["guild"] = 1,
                        ["buyer"] = 1872,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632941314,
                        ["quant"] = 1,
                        ["id"] = "1689804499",
                        ["itemLink"] = 3772,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [116123] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning4.dds",
                ["itemDesc"] = "Design: Khajiit Skooma Bubbler",
                ["oldestTime"] = 1633043583,
                ["wasAltered"] = true,
                ["newestTime"] = 1633043583,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 599999,
                        ["guild"] = 1,
                        ["buyer"] = 657,
                        ["wasKiosk"] = true,
                        ["seller"] = 625,
                        ["timestamp"] = 1633043583,
                        ["quant"] = 1,
                        ["id"] = "1690542329",
                        ["itemLink"] = 838,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [69276] = 
        {
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of Willpower",
                ["oldestTime"] = 1633024648,
                ["wasAltered"] = true,
                ["newestTime"] = 1633024648,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 538,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633024648,
                        ["quant"] = 1,
                        ["id"] = "1690403565",
                        ["itemLink"] = 675,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set willpower neck healthy",
            },
        },
        [147704] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 73: Anequina Daggers",
                ["oldestTime"] = 1632939819,
                ["wasAltered"] = true,
                ["newestTime"] = 1632939819,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1872,
                        ["wasKiosk"] = true,
                        ["seller"] = 1548,
                        ["timestamp"] = 1632939819,
                        ["quant"] = 1,
                        ["id"] = "1689793867",
                        ["itemLink"] = 3765,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [69278] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of Willpower",
                ["oldestTime"] = 1632984311,
                ["wasAltered"] = true,
                ["newestTime"] = 1632984311,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4400,
                        ["guild"] = 1,
                        ["buyer"] = 306,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1632984311,
                        ["quant"] = 1,
                        ["id"] = "1690155647",
                        ["itemLink"] = 309,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set willpower neck arcane",
            },
        },
        [172447] = 
        {
            ["50:16:4:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_hvy_waist_a.dds",
                ["itemDesc"] = "Bog Raider's Girdle",
                ["oldestTime"] = 1633244661,
                ["wasAltered"] = true,
                ["newestTime"] = 1633244661,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1791,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633244661,
                        ["quant"] = 1,
                        ["id"] = "1692231179",
                        ["itemLink"] = 2565,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set bog raider waist training",
            },
            ["50:16:2:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_hvy_waist_a.dds",
                ["itemDesc"] = "Bog Raider's Girdle",
                ["oldestTime"] = 1633136579,
                ["wasAltered"] = true,
                ["newestTime"] = 1633136579,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 287,
                        ["guild"] = 1,
                        ["buyer"] = 716,
                        ["wasKiosk"] = true,
                        ["seller"] = 896,
                        ["timestamp"] = 1633136579,
                        ["quant"] = 1,
                        ["id"] = "1691258237",
                        ["itemLink"] = 1571,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set bog raider waist training",
            },
        },
        [180842] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_heavy_hands_a.dds",
                ["itemDesc"] = "Hrothgar's Gauntlets",
                ["oldestTime"] = 1632935271,
                ["wasAltered"] = true,
                ["newestTime"] = 1632935271,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 626,
                        ["wasKiosk"] = false,
                        ["seller"] = 408,
                        ["timestamp"] = 1632935271,
                        ["quant"] = 1,
                        ["id"] = "1689763789",
                        ["itemLink"] = 3730,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set hrothgar's chill hands reinforced",
            },
        },
        [45654] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Red Deer Stew",
                ["oldestTime"] = 1633306730,
                ["wasAltered"] = true,
                ["newestTime"] = 1633306730,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633306730,
                        ["quant"] = 1,
                        ["id"] = "1692806903",
                        ["itemLink"] = 2946,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [71525] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 24: Outlaw Boots",
                ["oldestTime"] = 1632891910,
                ["wasAltered"] = true,
                ["newestTime"] = 1632891910,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 48506,
                        ["guild"] = 1,
                        ["buyer"] = 2417,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1632891910,
                        ["quant"] = 1,
                        ["id"] = "1689507599",
                        ["itemLink"] = 3544,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [167347] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_orc_inc_wtgceramicanimal001.dds",
                ["itemDesc"] = "Orcish Figurine, Mammoth",
                ["oldestTime"] = 1632890276,
                ["wasAltered"] = true,
                ["newestTime"] = 1632890276,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 34000,
                        ["guild"] = 1,
                        ["buyer"] = 299,
                        ["wasKiosk"] = false,
                        ["seller"] = 108,
                        ["timestamp"] = 1632890276,
                        ["quant"] = 2,
                        ["id"] = "1689494385",
                        ["itemLink"] = 3536,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings gallery",
            },
        },
        [156580] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 77: Stags of Z'en Gloves",
                ["oldestTime"] = 1633148213,
                ["wasAltered"] = true,
                ["newestTime"] = 1633148213,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 397,
                        ["timestamp"] = 1633148213,
                        ["quant"] = 1,
                        ["id"] = "1691375593",
                        ["itemLink"] = 1697,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [100248] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_medium_hands_d.dds",
                ["itemDesc"] = "Fiord's Bracers",
                ["oldestTime"] = 1632882513,
                ["wasAltered"] = true,
                ["newestTime"] = 1632882513,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5555,
                        ["guild"] = 1,
                        ["buyer"] = 2367,
                        ["wasKiosk"] = true,
                        ["seller"] = 697,
                        ["timestamp"] = 1632882513,
                        ["quant"] = 1,
                        ["id"] = "1689423695",
                        ["itemLink"] = 3478,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set fiord's legacy hands divines",
            },
        },
        [72870] = 
        {
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_light_robe_a.dds",
                ["itemDesc"] = "Robe of Bahraha's Curse",
                ["oldestTime"] = 1633017982,
                ["wasAltered"] = true,
                ["newestTime"] = 1633017982,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 489,
                        ["wasKiosk"] = true,
                        ["seller"] = 374,
                        ["timestamp"] = 1633017982,
                        ["quant"] = 1,
                        ["id"] = "1690349305",
                        ["itemLink"] = 566,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set bahraha's curse chest infused",
            },
        },
        [68229] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Senche-Tiger Single Malt",
                ["oldestTime"] = 1632881475,
                ["wasAltered"] = true,
                ["newestTime"] = 1632881475,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2359,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1632881475,
                        ["quant"] = 1,
                        ["id"] = "1689411349",
                        ["itemLink"] = 3466,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [45224] = 
        {
            ["16:0:1:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_staff_b.dds",
                ["itemDesc"] = "Oak Inferno Staff",
                ["oldestTime"] = 1632966265,
                ["wasAltered"] = true,
                ["newestTime"] = 1632966265,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2659,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1632966265,
                        ["quant"] = 1,
                        ["id"] = "1690017423",
                        ["itemLink"] = 3962,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr16 white normal weapon flame staff two-handed training",
            },
        },
        [46050] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Grandpa's Bedtime Tonic",
                ["oldestTime"] = 1632877192,
                ["wasAltered"] = true,
                ["newestTime"] = 1632877192,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 2333,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1632877192,
                        ["quant"] = 1,
                        ["id"] = "1689363389",
                        ["itemLink"] = 3430,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [97194] = 
        {
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_legs_d.dds",
                ["itemDesc"] = "Plague Doctor's Greaves",
                ["oldestTime"] = 1633228042,
                ["wasAltered"] = true,
                ["newestTime"] = 1633228042,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1026,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1633228042,
                        ["quant"] = 1,
                        ["id"] = "1692097475",
                        ["itemLink"] = 2418,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set plague doctor legs training",
            },
        },
        [56950] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Summer Sundas Soup",
                ["oldestTime"] = 1632875164,
                ["wasAltered"] = true,
                ["newestTime"] = 1632875164,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 144,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1632875164,
                        ["quant"] = 1,
                        ["id"] = "1689342961",
                        ["itemLink"] = 3411,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [167808] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_waywardguardianmed_shoulders_a.dds",
                ["itemDesc"] = "Witch-Knight's Arm Cops",
                ["oldestTime"] = 1632864716,
                ["wasAltered"] = true,
                ["newestTime"] = 1632864716,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2257,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1632864716,
                        ["quant"] = 1,
                        ["id"] = "1689263795",
                        ["itemLink"] = 3326,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set witch-knight's defiance shoulders divines",
            },
        },
        [149467] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_medium_feet_a.dds",
                ["itemDesc"] = "Darloc Brae's Boots",
                ["oldestTime"] = 1632863668,
                ["wasAltered"] = true,
                ["newestTime"] = 1632863668,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2254,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1632863668,
                        ["quant"] = 1,
                        ["id"] = "1689256483",
                        ["itemLink"] = 3322,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set vesture of darloc brae feet divines",
            },
        },
        [43694] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Betnikh Treasure Map II",
                ["oldestTime"] = 1633182518,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182518,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 379,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182518,
                        ["quant"] = 1,
                        ["id"] = "1691608199",
                        ["itemLink"] = 1956,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [167175] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 92: Ancestral Akaviri Belts",
                ["oldestTime"] = 1633125548,
                ["wasAltered"] = true,
                ["newestTime"] = 1633125548,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 80000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 1082,
                        ["timestamp"] = 1633125548,
                        ["quant"] = 1,
                        ["id"] = "1691147121",
                        ["itemLink"] = 1475,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [139184] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_duc_sarcophagusbase001.dds",
                ["itemDesc"] = "Alinor Plinth, Sarcophagus",
                ["oldestTime"] = 1633082136,
                ["wasAltered"] = true,
                ["newestTime"] = 1633082136,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 397,
                        ["wasKiosk"] = false,
                        ["seller"] = 323,
                        ["timestamp"] = 1633082136,
                        ["quant"] = 1,
                        ["id"] = "1690844617",
                        ["itemLink"] = 1130,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings undercroft",
            },
        },
        [43686] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Coldharbour Treasure Map II",
                ["oldestTime"] = 1632858417,
                ["wasAltered"] = true,
                ["newestTime"] = 1632879880,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 733,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632858417,
                        ["quant"] = 1,
                        ["id"] = "1689218581",
                        ["itemLink"] = 3293,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2350,
                        ["wasKiosk"] = true,
                        ["seller"] = 737,
                        ["timestamp"] = 1632879880,
                        ["quant"] = 1,
                        ["id"] = "1689395121",
                        ["itemLink"] = 3293,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [97332] = 
        {
            ["50:16:4:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_d.dds",
                ["itemDesc"] = "Inferno Staff of a Mother's Sorrow",
                ["oldestTime"] = 1633229583,
                ["wasAltered"] = true,
                ["newestTime"] = 1633229583,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 59000,
                        ["guild"] = 1,
                        ["buyer"] = 1678,
                        ["wasKiosk"] = true,
                        ["seller"] = 479,
                        ["timestamp"] = 1633229583,
                        ["quant"] = 1,
                        ["id"] = "1692111411",
                        ["itemLink"] = 2434,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set mother's sorrow flame staff two-handed charged",
            },
        },
        [43699] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Bleakrock Treasure Map I",
                ["oldestTime"] = 1632858418,
                ["wasAltered"] = true,
                ["newestTime"] = 1633187108,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1401,
                        ["wasKiosk"] = true,
                        ["seller"] = 86,
                        ["timestamp"] = 1633187099,
                        ["quant"] = 1,
                        ["id"] = "1691653145",
                        ["itemLink"] = 2077,
                    },
                    [2] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1401,
                        ["wasKiosk"] = true,
                        ["seller"] = 492,
                        ["timestamp"] = 1633187108,
                        ["quant"] = 1,
                        ["id"] = "1691653199",
                        ["itemLink"] = 2077,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 733,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632858418,
                        ["quant"] = 1,
                        ["id"] = "1689218589",
                        ["itemLink"] = 2077,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [175637] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_lsb_leylantern001.dds",
                ["itemDesc"] = "Leyawiin Lantern, Stationary",
                ["oldestTime"] = 1632839462,
                ["wasAltered"] = true,
                ["newestTime"] = 1632839462,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4533,
                        ["guild"] = 1,
                        ["buyer"] = 2170,
                        ["wasKiosk"] = true,
                        ["seller"] = 312,
                        ["timestamp"] = 1632839462,
                        ["quant"] = 1,
                        ["id"] = "1689056871",
                        ["itemLink"] = 3131,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings lighting",
            },
        },
        [139744] = 
        {
            ["50:16:3:31:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of Julianos",
                ["oldestTime"] = 1632836225,
                ["wasAltered"] = true,
                ["newestTime"] = 1632886330,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 59999,
                        ["guild"] = 1,
                        ["buyer"] = 2159,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632836225,
                        ["quant"] = 1,
                        ["id"] = "1689035485",
                        ["itemLink"] = 3107,
                    },
                    [2] = 
                    {
                        ["price"] = 59999,
                        ["guild"] = 1,
                        ["buyer"] = 2392,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632886330,
                        ["quant"] = 1,
                        ["id"] = "1689465395",
                        ["itemLink"] = 3107,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set law of julianos neck bloodthirsty",
            },
        },
        [180782] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_heavy_hands_a.dds",
                ["itemDesc"] = "Hrothgar's Gauntlets",
                ["oldestTime"] = 1632830309,
                ["wasAltered"] = true,
                ["newestTime"] = 1632830309,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1870,
                        ["guild"] = 1,
                        ["buyer"] = 2134,
                        ["wasKiosk"] = true,
                        ["seller"] = 1112,
                        ["timestamp"] = 1632830309,
                        ["quant"] = 1,
                        ["id"] = "1689000351",
                        ["itemLink"] = 3072,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set hrothgar's chill hands infused",
            },
        },
        [139455] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/justice_stolen_feather_001.dds",
                ["itemDesc"] = "Big-Eared Ginger Kitten's Feather Toy",
                ["oldestTime"] = 1633007062,
                ["wasAltered"] = true,
                ["newestTime"] = 1633007062,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 427,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633007062,
                        ["quant"] = 1,
                        ["id"] = "1690271289",
                        ["itemLink"] = 437,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [45579] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Kaveh Stout",
                ["oldestTime"] = 1633151684,
                ["wasAltered"] = true,
                ["newestTime"] = 1633151684,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30,
                        ["guild"] = 1,
                        ["buyer"] = 839,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633151684,
                        ["quant"] = 1,
                        ["id"] = "1691405521",
                        ["itemLink"] = 1732,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [117712] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_fur_cupboard001.dds",
                ["itemDesc"] = "Redguard Cupboard, Lattice",
                ["oldestTime"] = 1633160573,
                ["wasAltered"] = true,
                ["newestTime"] = 1633160573,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 1306,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633160573,
                        ["quant"] = 2,
                        ["id"] = "1691467349",
                        ["itemLink"] = 1790,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings hearth",
            },
        },
        [45155] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_staff_c.dds",
                ["itemDesc"] = "Ruby Ash Ice Staff of Shock",
                ["oldestTime"] = 1632826456,
                ["wasAltered"] = true,
                ["newestTime"] = 1632826456,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 180,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632826456,
                        ["quant"] = 1,
                        ["id"] = "1688971641",
                        ["itemLink"] = 3035,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon frost staff two-handed infused",
            },
        },
        [99003] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_medium_waist_d.dds",
                ["itemDesc"] = "Swamp Raider's Belt",
                ["oldestTime"] = 1632950174,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950174,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3100,
                        ["guild"] = 1,
                        ["buyer"] = 2585,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1632950174,
                        ["quant"] = 1,
                        ["id"] = "1689875485",
                        ["itemLink"] = 3833,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set swamp raider waist invigorating",
            },
        },
        [156604] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 78: Moongrave Fane Swords",
                ["oldestTime"] = 1633076991,
                ["wasAltered"] = true,
                ["newestTime"] = 1633076991,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 873,
                        ["wasKiosk"] = true,
                        ["seller"] = 386,
                        ["timestamp"] = 1633076991,
                        ["quant"] = 1,
                        ["id"] = "1690821471",
                        ["itemLink"] = 1117,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [43709] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Cyrodiil Treasure Map VII",
                ["oldestTime"] = 1633148096,
                ["wasAltered"] = true,
                ["newestTime"] = 1633148096,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 682,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633148096,
                        ["quant"] = 1,
                        ["id"] = "1691374565",
                        ["itemLink"] = 1692,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [180926] = 
        {
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_heavy_waist_a.dds",
                ["itemDesc"] = "Hrothgar's Girdle",
                ["oldestTime"] = 1632935257,
                ["wasAltered"] = true,
                ["newestTime"] = 1632935257,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 626,
                        ["wasKiosk"] = false,
                        ["seller"] = 476,
                        ["timestamp"] = 1632935257,
                        ["quant"] = 1,
                        ["id"] = "1689763531",
                        ["itemLink"] = 3729,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set hrothgar's chill waist training",
            },
        },
        [116159] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Nord Shelf, Wall",
                ["oldestTime"] = 1633140920,
                ["wasAltered"] = true,
                ["newestTime"] = 1633140920,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 53,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1633140920,
                        ["quant"] = 1,
                        ["id"] = "1691300589",
                        ["itemLink"] = 1603,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [172443] = 
        {
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_hvy_hands_a.dds",
                ["itemDesc"] = "Bog Raider's Gauntlets",
                ["oldestTime"] = 1633301128,
                ["wasAltered"] = true,
                ["newestTime"] = 1633301128,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 340,
                        ["guild"] = 1,
                        ["buyer"] = 716,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633301128,
                        ["quant"] = 1,
                        ["id"] = "1692752679",
                        ["itemLink"] = 2916,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set bog raider hands training",
            },
        },
        [57602] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 18: Akaviri Shoulders",
                ["oldestTime"] = 1633299151,
                ["wasAltered"] = true,
                ["newestTime"] = 1633299151,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 151999,
                        ["guild"] = 1,
                        ["buyer"] = 2036,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633299151,
                        ["quant"] = 1,
                        ["id"] = "1692733401",
                        ["itemLink"] = 2909,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [123806] = 
        {
            ["50:16:4:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_light_waist_a.dds",
                ["itemDesc"] = "Wizard's Riposte Sash",
                ["oldestTime"] = 1633291931,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291931,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 555,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633291931,
                        ["quant"] = 1,
                        ["id"] = "1692651119",
                        ["itemLink"] = 2795,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set wizard's riposte waist reinforced",
            },
        },
        [45086] = 
        {
            ["50:16:4:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Lightning Staff of Flame",
                ["oldestTime"] = 1633293870,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293870,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1480,
                        ["wasKiosk"] = false,
                        ["seller"] = 501,
                        ["timestamp"] = 1633293870,
                        ["quant"] = 1,
                        ["id"] = "1692674415",
                        ["itemLink"] = 2861,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon lightning staff two-handed charged",
            },
        },
        [126959] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Dres Divider, Screen",
                ["oldestTime"] = 1633292336,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292336,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 31,
                        ["timestamp"] = 1633292336,
                        ["quant"] = 1,
                        ["id"] = "1692655449",
                        ["itemLink"] = 2822,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [30149] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_mushroom_stinkhorn_cap_r1.dds",
                ["itemDesc"] = "Stinkhorn",
                ["oldestTime"] = 1632941730,
                ["wasAltered"] = true,
                ["newestTime"] = 1633203736,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3250,
                        ["guild"] = 1,
                        ["buyer"] = 511,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1633203731,
                        ["quant"] = 25,
                        ["id"] = "1691830449",
                        ["itemLink"] = 2232,
                    },
                    [2] = 
                    {
                        ["price"] = 26500,
                        ["guild"] = 1,
                        ["buyer"] = 511,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633203733,
                        ["quant"] = 200,
                        ["id"] = "1691830463",
                        ["itemLink"] = 2232,
                    },
                    [3] = 
                    {
                        ["price"] = 13400,
                        ["guild"] = 1,
                        ["buyer"] = 511,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633203736,
                        ["quant"] = 100,
                        ["id"] = "1691830481",
                        ["itemLink"] = 2232,
                    },
                    [4] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 2552,
                        ["wasKiosk"] = true,
                        ["seller"] = 1535,
                        ["timestamp"] = 1632941730,
                        ["quant"] = 40,
                        ["id"] = "1689807289",
                        ["itemLink"] = 2232,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [177024] = 
        {
            ["1:0:3:50:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_gloves_medium.dds",
                ["itemDesc"] = "Companion's Bracers",
                ["oldestTime"] = 1633178816,
                ["wasAltered"] = true,
                ["newestTime"] = 1633178816,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 658,
                        ["wasKiosk"] = true,
                        ["seller"] = 50,
                        ["timestamp"] = 1633178816,
                        ["quant"] = 1,
                        ["id"] = "1691576677",
                        ["itemLink"] = 1909,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior medium apparel hands bolstered",
            },
        },
        [149447] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_medium_feet_a.dds",
                ["itemDesc"] = "Darloc Brae's Boots",
                ["oldestTime"] = 1633296773,
                ["wasAltered"] = true,
                ["newestTime"] = 1633296773,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 2022,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1633296773,
                        ["quant"] = 1,
                        ["id"] = "1692708487",
                        ["itemLink"] = 2884,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set vesture of darloc brae feet infused",
            },
        },
        [98818] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_waist_d.dds",
                ["itemDesc"] = "Sash of Hist Sap",
                ["oldestTime"] = 1633094749,
                ["wasAltered"] = true,
                ["newestTime"] = 1633094749,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 63,
                        ["wasKiosk"] = false,
                        ["seller"] = 535,
                        ["timestamp"] = 1633094749,
                        ["quant"] = 1,
                        ["id"] = "1690917463",
                        ["itemLink"] = 1252,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set robes of the hist waist invigorating",
            },
        },
        [123869] = 
        {
            ["50:16:4:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_light_waist_a.dds",
                ["itemDesc"] = "Wizard's Riposte Sash",
                ["oldestTime"] = 1633244672,
                ["wasAltered"] = true,
                ["newestTime"] = 1633244672,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 1791,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633244672,
                        ["quant"] = 1,
                        ["id"] = "1692231267",
                        ["itemLink"] = 2567,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set wizard's riposte waist sturdy",
            },
        },
        [118218] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bre_inc_painting_elegant003.dds",
                ["itemDesc"] = "Painting of Creek, Sturdy",
                ["oldestTime"] = 1633201410,
                ["wasAltered"] = true,
                ["newestTime"] = 1633201410,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1496,
                        ["wasKiosk"] = true,
                        ["seller"] = 1497,
                        ["timestamp"] = 1633201410,
                        ["quant"] = 1,
                        ["id"] = "1691804775",
                        ["itemLink"] = 2214,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings gallery",
            },
        },
        [177060] = 
        {
            ["1:0:4:50:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_gloves_medium.dds",
                ["itemDesc"] = "Companion's Bracers",
                ["oldestTime"] = 1633282481,
                ["wasAltered"] = true,
                ["newestTime"] = 1633282481,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 69696,
                        ["guild"] = 1,
                        ["buyer"] = 1940,
                        ["wasKiosk"] = true,
                        ["seller"] = 43,
                        ["timestamp"] = 1633282481,
                        ["quant"] = 1,
                        ["id"] = "1692541043",
                        ["itemLink"] = 2744,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic medium apparel hands bolstered",
            },
        },
        [43724] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Craglorn Treasure Map IV",
                ["oldestTime"] = 1633202872,
                ["wasAltered"] = true,
                ["newestTime"] = 1633202872,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 479,
                        ["guild"] = 1,
                        ["buyer"] = 1504,
                        ["wasKiosk"] = true,
                        ["seller"] = 164,
                        ["timestamp"] = 1633202872,
                        ["quant"] = 1,
                        ["id"] = "1691820773",
                        ["itemLink"] = 2221,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [137933] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 62: Sapiarch Staves",
                ["oldestTime"] = 1633124517,
                ["wasAltered"] = true,
                ["newestTime"] = 1633280774,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9999,
                        ["guild"] = 1,
                        ["buyer"] = 1076,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633124517,
                        ["quant"] = 1,
                        ["id"] = "1691138265",
                        ["itemLink"] = 1464,
                    },
                    [2] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 511,
                        ["wasKiosk"] = true,
                        ["seller"] = 351,
                        ["timestamp"] = 1633280774,
                        ["quant"] = 1,
                        ["id"] = "1692522837",
                        ["itemLink"] = 1464,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [166862] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Solitude Jewelry Box, Wolf's-Head",
                ["oldestTime"] = 1633315803,
                ["wasAltered"] = true,
                ["newestTime"] = 1633315803,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 31000,
                        ["guild"] = 1,
                        ["buyer"] = 76,
                        ["wasKiosk"] = false,
                        ["seller"] = 105,
                        ["timestamp"] = 1633315803,
                        ["quant"] = 1,
                        ["id"] = "1692912941",
                        ["itemLink"] = 76,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [68613] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_heavy_shoulders_a.dds",
                ["itemDesc"] = "Pauldron of the Pariah",
                ["oldestTime"] = 1633122461,
                ["wasAltered"] = true,
                ["newestTime"] = 1633122461,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1064,
                        ["wasKiosk"] = true,
                        ["seller"] = 256,
                        ["timestamp"] = 1633122461,
                        ["quant"] = 1,
                        ["id"] = "1691122595",
                        ["itemLink"] = 1447,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set mark of the pariah shoulders infused",
            },
        },
        [176592] = 
        {
            ["1:0:3:47:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_gloves_medium.dds",
                ["itemDesc"] = "Companion's Bracers",
                ["oldestTime"] = 1632908465,
                ["wasAltered"] = true,
                ["newestTime"] = 1633167366,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 203,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1632974294,
                        ["quant"] = 1,
                        ["id"] = "1690091733",
                        ["itemLink"] = 214,
                    },
                    [2] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 434,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633137510,
                        ["quant"] = 1,
                        ["id"] = "1691266403",
                        ["itemLink"] = 214,
                    },
                    [3] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 1329,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633167366,
                        ["quant"] = 1,
                        ["id"] = "1691506573",
                        ["itemLink"] = 214,
                    },
                    [4] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 1082,
                        ["wasKiosk"] = false,
                        ["seller"] = 93,
                        ["timestamp"] = 1632908465,
                        ["quant"] = 1,
                        ["id"] = "1689596733",
                        ["itemLink"] = 214,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior medium apparel hands aggressive",
            },
        },
        [57041] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Sylph Gin",
                ["oldestTime"] = 1632975967,
                ["wasAltered"] = true,
                ["newestTime"] = 1633130339,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1333,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1632975967,
                        ["quant"] = 1,
                        ["id"] = "1690102395",
                        ["itemLink"] = 232,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1102,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633130339,
                        ["quant"] = 1,
                        ["id"] = "1691189509",
                        ["itemLink"] = 232,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [132562] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_cwc_inc_scrollplate001.dds",
                ["itemDesc"] = "Crafting Motif 56: Apostle Staves",
                ["oldestTime"] = 1632863287,
                ["wasAltered"] = true,
                ["newestTime"] = 1632863287,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 2226,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632863287,
                        ["quant"] = 1,
                        ["id"] = "1689253217",
                        ["itemLink"] = 3319,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45267] = 
        {
            ["50:16:2:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_2hhammer_d.dds",
                ["itemDesc"] = "Rubedite Maul of Shock",
                ["oldestTime"] = 1632826480,
                ["wasAltered"] = true,
                ["newestTime"] = 1632826480,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 234,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 527,
                        ["timestamp"] = 1632826480,
                        ["quant"] = 1,
                        ["id"] = "1688971807",
                        ["itemLink"] = 3046,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon mace two-handed decisive",
            },
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_2hhammer_d.dds",
                ["itemDesc"] = "Rubedite Maul of Frost",
                ["oldestTime"] = 1632860937,
                ["wasAltered"] = true,
                ["newestTime"] = 1632860937,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 463,
                        ["guild"] = 1,
                        ["buyer"] = 2244,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1632860937,
                        ["quant"] = 1,
                        ["id"] = "1689237821",
                        ["itemLink"] = 3297,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon mace two-handed decisive",
            },
        },
        [26580] = 
        {
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_armor_healthboost.dds",
                ["itemDesc"] = "Truly Superb Glyph of Health",
                ["oldestTime"] = 1633044832,
                ["wasAltered"] = true,
                ["newestTime"] = 1633301756,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 666,
                        ["wasKiosk"] = true,
                        ["seller"] = 356,
                        ["timestamp"] = 1633044832,
                        ["quant"] = 1,
                        ["id"] = "1690554739",
                        ["itemLink"] = 846,
                    },
                    [2] = 
                    {
                        ["price"] = 6150,
                        ["guild"] = 1,
                        ["buyer"] = 858,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633074118,
                        ["quant"] = 1,
                        ["id"] = "1690805671",
                        ["itemLink"] = 846,
                    },
                    [3] = 
                    {
                        ["price"] = 6150,
                        ["guild"] = 1,
                        ["buyer"] = 367,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633087931,
                        ["quant"] = 1,
                        ["id"] = "1690875849",
                        ["itemLink"] = 846,
                    },
                    [4] = 
                    {
                        ["price"] = 6300,
                        ["guild"] = 1,
                        ["buyer"] = 885,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1633095737,
                        ["quant"] = 1,
                        ["id"] = "1690924851",
                        ["itemLink"] = 846,
                    },
                    [5] = 
                    {
                        ["price"] = 6150,
                        ["guild"] = 1,
                        ["buyer"] = 885,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633095758,
                        ["quant"] = 1,
                        ["id"] = "1690924949",
                        ["itemLink"] = 846,
                    },
                    [6] = 
                    {
                        ["price"] = 6150,
                        ["guild"] = 1,
                        ["buyer"] = 945,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633100489,
                        ["quant"] = 1,
                        ["id"] = "1690960947",
                        ["itemLink"] = 846,
                    },
                    [7] = 
                    {
                        ["price"] = 6150,
                        ["guild"] = 1,
                        ["buyer"] = 1026,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633116045,
                        ["quant"] = 1,
                        ["id"] = "1691079301",
                        ["itemLink"] = 846,
                    },
                    [8] = 
                    {
                        ["price"] = 6150,
                        ["guild"] = 1,
                        ["buyer"] = 1026,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633116052,
                        ["quant"] = 1,
                        ["id"] = "1691079341",
                        ["itemLink"] = 846,
                    },
                    [9] = 
                    {
                        ["price"] = 6150,
                        ["guild"] = 1,
                        ["buyer"] = 1026,
                        ["wasKiosk"] = true,
                        ["seller"] = 696,
                        ["timestamp"] = 1633116060,
                        ["quant"] = 1,
                        ["id"] = "1691079403",
                        ["itemLink"] = 846,
                    },
                    [10] = 
                    {
                        ["price"] = 6300,
                        ["guild"] = 1,
                        ["buyer"] = 13,
                        ["wasKiosk"] = false,
                        ["seller"] = 673,
                        ["timestamp"] = 1633205281,
                        ["quant"] = 1,
                        ["id"] = "1691845579",
                        ["itemLink"] = 846,
                    },
                    [11] = 
                    {
                        ["price"] = 6300,
                        ["guild"] = 1,
                        ["buyer"] = 1458,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1633226048,
                        ["quant"] = 1,
                        ["id"] = "1692074625",
                        ["itemLink"] = 846,
                    },
                    [12] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 881,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633301756,
                        ["quant"] = 1,
                        ["id"] = "1692758695",
                        ["itemLink"] = 846,
                    },
                },
                ["totalCount"] = 12,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous armor glyph",
            },
            ["50:16:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_armor_healthboost.dds",
                ["itemDesc"] = "Truly Superb Glyph of Health",
                ["oldestTime"] = 1633112390,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112392,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 993,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633112390,
                        ["quant"] = 1,
                        ["id"] = "1691054953",
                        ["itemLink"] = 1345,
                    },
                    [2] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 993,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633112392,
                        ["quant"] = 1,
                        ["id"] = "1691054957",
                        ["itemLink"] = 1345,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic miscellaneous armor glyph",
            },
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_armor_healthboost.dds",
                ["itemDesc"] = "Truly Superb Glyph of Health",
                ["oldestTime"] = 1632826385,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297966,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 398,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633001132,
                        ["quant"] = 1,
                        ["id"] = "1690240013",
                        ["itemLink"] = 402,
                    },
                    [2] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 1244,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633148041,
                        ["quant"] = 1,
                        ["id"] = "1691374123",
                        ["itemLink"] = 1686,
                    },
                    [3] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 1244,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633148044,
                        ["quant"] = 1,
                        ["id"] = "1691374139",
                        ["itemLink"] = 1687,
                    },
                    [4] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1639,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633224720,
                        ["quant"] = 1,
                        ["id"] = "1692061305",
                        ["itemLink"] = 2376,
                    },
                    [5] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1639,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633225364,
                        ["quant"] = 1,
                        ["id"] = "1692068113",
                        ["itemLink"] = 2385,
                    },
                    [6] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1639,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633225368,
                        ["quant"] = 1,
                        ["id"] = "1692068155",
                        ["itemLink"] = 2385,
                    },
                    [7] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1639,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633225370,
                        ["quant"] = 1,
                        ["id"] = "1692068185",
                        ["itemLink"] = 1686,
                    },
                    [8] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633251480,
                        ["quant"] = 1,
                        ["id"] = "1692280591",
                        ["itemLink"] = 402,
                    },
                    [9] = 
                    {
                        ["price"] = 122,
                        ["guild"] = 1,
                        ["buyer"] = 1866,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1633267871,
                        ["quant"] = 1,
                        ["id"] = "1692383603",
                        ["itemLink"] = 402,
                    },
                    [10] = 
                    {
                        ["price"] = 127,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633297956,
                        ["quant"] = 1,
                        ["id"] = "1692720405",
                        ["itemLink"] = 2894,
                    },
                    [11] = 
                    {
                        ["price"] = 127,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633297962,
                        ["quant"] = 1,
                        ["id"] = "1692720443",
                        ["itemLink"] = 2896,
                    },
                    [12] = 
                    {
                        ["price"] = 127,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633297966,
                        ["quant"] = 1,
                        ["id"] = "1692720471",
                        ["itemLink"] = 2897,
                    },
                    [13] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632826385,
                        ["quant"] = 1,
                        ["id"] = "1688971293",
                        ["itemLink"] = 1687,
                    },
                    [14] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2201,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632846656,
                        ["quant"] = 1,
                        ["id"] = "1689115627",
                        ["itemLink"] = 3200,
                    },
                    [15] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632885359,
                        ["quant"] = 1,
                        ["id"] = "1689456641",
                        ["itemLink"] = 3504,
                    },
                },
                ["totalCount"] = 15,
                ["itemAdderText"] = "cp160 white normal miscellaneous armor glyph",
            },
        },
        [120764] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/event_jester_rockcandy.dds",
                ["itemDesc"] = "Jewels of Misrule",
                ["oldestTime"] = 1633281002,
                ["wasAltered"] = true,
                ["newestTime"] = 1633281002,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2650,
                        ["guild"] = 1,
                        ["buyer"] = 1933,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633281002,
                        ["quant"] = 10,
                        ["id"] = "1692524829",
                        ["itemLink"] = 2737,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable food",
            },
        },
        [71267] = 
        {
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Proof of Trinimac's Valor",
                ["oldestTime"] = 1633163911,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163911,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1150,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633163911,
                        ["quant"] = 1,
                        ["id"] = "1691490315",
                        ["itemLink"] = 1804,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set trinimac's valor neck healthy",
            },
        },
        [118487] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bre_inc_paper001.dds",
                ["itemDesc"] = "Letter, Personal",
                ["oldestTime"] = 1632980997,
                ["wasAltered"] = true,
                ["newestTime"] = 1632980997,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 264,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1632980997,
                        ["quant"] = 1,
                        ["id"] = "1690136553",
                        ["itemLink"] = 268,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings library",
            },
        },
        [86744] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of Necropotence",
                ["oldestTime"] = 1632960137,
                ["wasAltered"] = true,
                ["newestTime"] = 1632960137,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 970,
                        ["guild"] = 1,
                        ["buyer"] = 2625,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1632960137,
                        ["quant"] = 1,
                        ["id"] = "1689961147",
                        ["itemLink"] = 3919,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set necropotence neck arcane",
            },
        },
        [176124] = 
        {
            ["1:0:2:44:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_gloves_medium.dds",
                ["itemDesc"] = "Companion's Bracers",
                ["oldestTime"] = 1633226013,
                ["wasAltered"] = true,
                ["newestTime"] = 1633226013,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2630,
                        ["guild"] = 1,
                        ["buyer"] = 1648,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1633226013,
                        ["quant"] = 1,
                        ["id"] = "1692074285",
                        ["itemLink"] = 2392,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine medium apparel hands prolific",
            },
        },
        [118234] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_gen_crf_tablepropsalchemy005.dds",
                ["itemDesc"] = "Case of Vials",
                ["oldestTime"] = 1633165957,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165957,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 39772,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1633165957,
                        ["quant"] = 1,
                        ["id"] = "1691500313",
                        ["itemLink"] = 1855,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings workshop",
            },
        },
        [152027] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Hakoshae Banner, Triple Insignia",
                ["oldestTime"] = 1633205597,
                ["wasAltered"] = true,
                ["newestTime"] = 1633205597,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1523,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633205597,
                        ["quant"] = 1,
                        ["id"] = "1691849381",
                        ["itemLink"] = 2249,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [115932] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing2.dds",
                ["itemDesc"] = "Diagram: Breton Sconce, Torch",
                ["oldestTime"] = 1633117333,
                ["wasAltered"] = true,
                ["newestTime"] = 1633117333,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 224,
                        ["guild"] = 1,
                        ["buyer"] = 1030,
                        ["wasKiosk"] = true,
                        ["seller"] = 600,
                        ["timestamp"] = 1633117333,
                        ["quant"] = 1,
                        ["id"] = "1691087083",
                        ["itemLink"] = 1413,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [64221] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_potion_001.dds",
                ["itemDesc"] = "Psijic Ambrosia",
                ["oldestTime"] = 1632959697,
                ["wasAltered"] = true,
                ["newestTime"] = 1633211975,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 57000,
                        ["guild"] = 1,
                        ["buyer"] = 738,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633054576,
                        ["quant"] = 4,
                        ["id"] = "1690650775",
                        ["itemLink"] = 942,
                    },
                    [2] = 
                    {
                        ["price"] = 35996,
                        ["guild"] = 1,
                        ["buyer"] = 1012,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633114450,
                        ["quant"] = 4,
                        ["id"] = "1691069127",
                        ["itemLink"] = 942,
                    },
                    [3] = 
                    {
                        ["price"] = 43800,
                        ["guild"] = 1,
                        ["buyer"] = 1058,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633121710,
                        ["quant"] = 3,
                        ["id"] = "1691117599",
                        ["itemLink"] = 942,
                    },
                    [4] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 1021,
                        ["wasKiosk"] = true,
                        ["seller"] = 1077,
                        ["timestamp"] = 1633124650,
                        ["quant"] = 1,
                        ["id"] = "1691139627",
                        ["itemLink"] = 942,
                    },
                    [5] = 
                    {
                        ["price"] = 58000,
                        ["guild"] = 1,
                        ["buyer"] = 1557,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633211975,
                        ["quant"] = 4,
                        ["id"] = "1691928607",
                        ["itemLink"] = 942,
                    },
                    [6] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 340,
                        ["wasKiosk"] = false,
                        ["seller"] = 461,
                        ["timestamp"] = 1632959697,
                        ["quant"] = 2,
                        ["id"] = "1689957913",
                        ["itemLink"] = 942,
                    },
                    [7] = 
                    {
                        ["price"] = 65000,
                        ["guild"] = 1,
                        ["buyer"] = 340,
                        ["wasKiosk"] = false,
                        ["seller"] = 227,
                        ["timestamp"] = 1632959708,
                        ["quant"] = 5,
                        ["id"] = "1689957959",
                        ["itemLink"] = 942,
                    },
                    [8] = 
                    {
                        ["price"] = 65000,
                        ["guild"] = 1,
                        ["buyer"] = 340,
                        ["wasKiosk"] = false,
                        ["seller"] = 227,
                        ["timestamp"] = 1632959711,
                        ["quant"] = 5,
                        ["id"] = "1689957975",
                        ["itemLink"] = 942,
                    },
                    [9] = 
                    {
                        ["price"] = 42000,
                        ["guild"] = 1,
                        ["buyer"] = 340,
                        ["wasKiosk"] = false,
                        ["seller"] = 739,
                        ["timestamp"] = 1632959713,
                        ["quant"] = 3,
                        ["id"] = "1689957989",
                        ["itemLink"] = 942,
                    },
                },
                ["totalCount"] = 9,
                ["itemAdderText"] = "rr01 gold legendary consumable drink",
            },
        },
        [127019] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Indoril Incense Cup, Silver",
                ["oldestTime"] = 1633234225,
                ["wasAltered"] = true,
                ["newestTime"] = 1633234225,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 31499,
                        ["guild"] = 1,
                        ["buyer"] = 1720,
                        ["wasKiosk"] = false,
                        ["seller"] = 451,
                        ["timestamp"] = 1633234225,
                        ["quant"] = 1,
                        ["id"] = "1692155547",
                        ["itemLink"] = 2465,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45791] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Direnni Hundred-Year Rabbit Bisque",
                ["oldestTime"] = 1633203137,
                ["wasAltered"] = true,
                ["newestTime"] = 1633203137,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3666,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633203137,
                        ["quant"] = 1,
                        ["id"] = "1691824323",
                        ["itemLink"] = 2224,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [69088] = 
        {
            ["50:16:4:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_1hhammer_d.dds",
                ["itemDesc"] = "Mace of Endurance",
                ["oldestTime"] = 1633271039,
                ["wasAltered"] = true,
                ["newestTime"] = 1633271039,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1299,
                        ["guild"] = 1,
                        ["buyer"] = 55,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633271039,
                        ["quant"] = 1,
                        ["id"] = "1692417095",
                        ["itemLink"] = 2670,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set endurance mace one-handed precise",
            },
        },
        [116138] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning4.dds",
                ["itemDesc"] = "Design: Khajiit Urn, Amber",
                ["oldestTime"] = 1633234988,
                ["wasAltered"] = true,
                ["newestTime"] = 1633234988,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633234988,
                        ["quant"] = 1,
                        ["id"] = "1692160649",
                        ["itemLink"] = 2477,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [45282] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_light_shirt_d.dds",
                ["itemDesc"] = "Ancestor Silk Jerkin of Health",
                ["oldestTime"] = 1632847696,
                ["wasAltered"] = true,
                ["newestTime"] = 1632847696,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 275,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632847696,
                        ["quant"] = 1,
                        ["id"] = "1689125613",
                        ["itemLink"] = 3222,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel chest divines",
            },
        },
        [120797] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_bsh_abatrellisfence001.dds",
                ["itemDesc"] = "Wedding Flower Trellis",
                ["oldestTime"] = 1633228387,
                ["wasAltered"] = true,
                ["newestTime"] = 1633228387,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 36000,
                        ["guild"] = 1,
                        ["buyer"] = 1667,
                        ["wasKiosk"] = true,
                        ["seller"] = 1668,
                        ["timestamp"] = 1633228387,
                        ["quant"] = 2,
                        ["id"] = "1692101041",
                        ["itemLink"] = 2426,
                    },
                    [2] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 1667,
                        ["wasKiosk"] = true,
                        ["seller"] = 1668,
                        ["timestamp"] = 1633228387,
                        ["quant"] = 1,
                        ["id"] = "1692101045",
                        ["itemLink"] = 2426,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings conservatory",
            },
        },
        [172004] = 
        {
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_shield_a.dds",
                ["itemDesc"] = "Shield of Frostbite",
                ["oldestTime"] = 1633182282,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182282,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1377,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633182282,
                        ["quant"] = 1,
                        ["id"] = "1691606391",
                        ["itemLink"] = 1936,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine apparel weapon set frostbite shield off hand well-fitted",
            },
        },
        [43749] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Summerset Treasure Map II",
                ["oldestTime"] = 1633310227,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310227,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633310227,
                        ["quant"] = 1,
                        ["id"] = "1692851255",
                        ["itemLink"] = 2987,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [126922] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Hlaalu Bed, Canopy",
                ["oldestTime"] = 1633227759,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227759,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 521,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633227759,
                        ["quant"] = 1,
                        ["id"] = "1692093407",
                        ["itemLink"] = 2414,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [74542] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 32: Abah's Watch Boots",
                ["oldestTime"] = 1633088144,
                ["wasAltered"] = true,
                ["newestTime"] = 1633088144,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12999,
                        ["guild"] = 1,
                        ["buyer"] = 450,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633088144,
                        ["quant"] = 1,
                        ["id"] = "1690876865",
                        ["itemLink"] = 1233,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [130295] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_tre_ded_vrdlimberpine_branch001.dds",
                ["itemDesc"] = "Branch, Sturdy Burnt",
                ["oldestTime"] = 1633214888,
                ["wasAltered"] = true,
                ["newestTime"] = 1633214888,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 56,
                        ["guild"] = 1,
                        ["buyer"] = 1581,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1633214888,
                        ["quant"] = 1,
                        ["id"] = "1691958153",
                        ["itemLink"] = 2306,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings conservatory",
            },
        },
        [176692] = 
        {
            ["1:0:2:48:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_boots_light.dds",
                ["itemDesc"] = "Companion's Shoes",
                ["oldestTime"] = 1633158456,
                ["wasAltered"] = true,
                ["newestTime"] = 1633158456,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1295,
                        ["wasKiosk"] = true,
                        ["seller"] = 1108,
                        ["timestamp"] = 1633158456,
                        ["quant"] = 1,
                        ["id"] = "1691457015",
                        ["itemLink"] = 1783,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine light apparel feet soothing",
            },
        },
        [124683] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 48: Ashlander Bows",
                ["oldestTime"] = 1633219226,
                ["wasAltered"] = true,
                ["newestTime"] = 1633219226,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5300,
                        ["guild"] = 1,
                        ["buyer"] = 160,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633219226,
                        ["quant"] = 1,
                        ["id"] = "1692004753",
                        ["itemLink"] = 2338,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45230] = 
        {
            ["50:16:2:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ashlanderv_1hsword_a.dds",
                ["itemDesc"] = "Rubedite Sword of Shock",
                ["oldestTime"] = 1633185890,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185890,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 144,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633185890,
                        ["quant"] = 1,
                        ["id"] = "1691639331",
                        ["itemLink"] = 1993,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon sword one-handed sharpened",
            },
            ["50:16:3:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_1hsword_c.dds",
                ["itemDesc"] = "Rubedite Sword of Flame",
                ["oldestTime"] = 1633211139,
                ["wasAltered"] = true,
                ["newestTime"] = 1633211139,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 797,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633211139,
                        ["quant"] = 1,
                        ["id"] = "1691916881",
                        ["itemLink"] = 2278,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon sword one-handed sharpened",
            },
        },
        [54508] = 
        {
            ["50:16:2:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Platinum Ring of Reduce Spell Cost",
                ["oldestTime"] = 1632875534,
                ["wasAltered"] = true,
                ["newestTime"] = 1632875534,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2325,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632875534,
                        ["quant"] = 1,
                        ["id"] = "1689347047",
                        ["itemLink"] = 3415,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel ring healthy",
            },
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Platinum Ring of Reduce Spell Cost",
                ["oldestTime"] = 1633163907,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163911,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 660,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1633163907,
                        ["quant"] = 1,
                        ["id"] = "1691490289",
                        ["itemLink"] = 1797,
                    },
                    [2] = 
                    {
                        ["price"] = 1150,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633163911,
                        ["quant"] = 1,
                        ["id"] = "1691490317",
                        ["itemLink"] = 1805,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel ring healthy",
            },
        },
        [119150] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Redguard Kabobs, Wax",
                ["oldestTime"] = 1632960673,
                ["wasAltered"] = true,
                ["newestTime"] = 1633307965,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1524,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633205814,
                        ["quant"] = 1,
                        ["id"] = "1691852353",
                        ["itemLink"] = 2250,
                    },
                    [2] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 2076,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633307965,
                        ["quant"] = 1,
                        ["id"] = "1692822475",
                        ["itemLink"] = 2250,
                    },
                    [3] = 
                    {
                        ["price"] = 177,
                        ["guild"] = 1,
                        ["buyer"] = 2471,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1632960673,
                        ["quant"] = 1,
                        ["id"] = "1689965245",
                        ["itemLink"] = 2250,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [176728] = 
        {
            ["1:0:3:48:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_boots_light.dds",
                ["itemDesc"] = "Companion's Shoes",
                ["oldestTime"] = 1632874446,
                ["wasAltered"] = true,
                ["newestTime"] = 1633295341,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 807,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633064112,
                        ["quant"] = 1,
                        ["id"] = "1690740951",
                        ["itemLink"] = 1047,
                    },
                    [2] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 2017,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633295341,
                        ["quant"] = 1,
                        ["id"] = "1692693677",
                        ["itemLink"] = 1047,
                    },
                    [3] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 2316,
                        ["wasKiosk"] = true,
                        ["seller"] = 8,
                        ["timestamp"] = 1632874446,
                        ["quant"] = 1,
                        ["id"] = "1689335343",
                        ["itemLink"] = 1047,
                    },
                    [4] = 
                    {
                        ["price"] = 89999,
                        ["guild"] = 1,
                        ["buyer"] = 2250,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1632956964,
                        ["quant"] = 1,
                        ["id"] = "1689935621",
                        ["itemLink"] = 1047,
                    },
                    [5] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 2637,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1632961840,
                        ["quant"] = 1,
                        ["id"] = "1689974075",
                        ["itemLink"] = 1047,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 blue superior light apparel feet soothing",
            },
        },
        [86767] = 
        {
            ["50:16:5:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_1hhammer_d.dds",
                ["itemDesc"] = "Mace of Necropotence",
                ["oldestTime"] = 1632970973,
                ["wasAltered"] = true,
                ["newestTime"] = 1632970973,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 176,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632970973,
                        ["quant"] = 1,
                        ["id"] = "1690065531",
                        ["itemLink"] = 188,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary weapon set necropotence mace one-handed powered",
            },
        },
        [130032] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 79: Refabricated Daggers",
                ["oldestTime"] = 1633201437,
                ["wasAltered"] = true,
                ["newestTime"] = 1633201437,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14400,
                        ["guild"] = 1,
                        ["buyer"] = 1495,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1633201437,
                        ["quant"] = 1,
                        ["id"] = "1691805009",
                        ["itemLink"] = 2215,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [56049] = 
        {
            ["1:0:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_light_legs_a.dds",
                ["itemDesc"] = "Homespun Breeches",
                ["oldestTime"] = 1632874761,
                ["wasAltered"] = true,
                ["newestTime"] = 1633296084,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 902,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633086652,
                        ["quant"] = 1,
                        ["id"] = "1690867463",
                        ["itemLink"] = 1225,
                    },
                    [2] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1360,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633178532,
                        ["quant"] = 1,
                        ["id"] = "1691574039",
                        ["itemLink"] = 1225,
                    },
                    [3] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 1390,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633185097,
                        ["quant"] = 1,
                        ["id"] = "1691629893",
                        ["itemLink"] = 1225,
                    },
                    [4] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1079,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633296084,
                        ["quant"] = 1,
                        ["id"] = "1692701555",
                        ["itemLink"] = 1225,
                    },
                    [5] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 2320,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1632874761,
                        ["quant"] = 1,
                        ["id"] = "1689339125",
                        ["itemLink"] = 1225,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 white normal light apparel legs nirnhoned",
            },
        },
        [135666] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_psijicorder_shield_a.dds",
                ["itemDesc"] = "Vanus's Shield",
                ["oldestTime"] = 1632830306,
                ["wasAltered"] = true,
                ["newestTime"] = 1632830306,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2134,
                        ["wasKiosk"] = true,
                        ["seller"] = 51,
                        ["timestamp"] = 1632830306,
                        ["quant"] = 1,
                        ["id"] = "1689000335",
                        ["itemLink"] = 3070,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior apparel weapon set wisdom of vanus shield off hand sturdy",
            },
        },
        [54515] = 
        {
            ["50:16:1:24:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Platinum Necklace",
                ["oldestTime"] = 1632829377,
                ["wasAltered"] = true,
                ["newestTime"] = 1633301484,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632994935,
                        ["quant"] = 1,
                        ["id"] = "1690210021",
                        ["itemLink"] = 372,
                    },
                    [2] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632994935,
                        ["quant"] = 1,
                        ["id"] = "1690210023",
                        ["itemLink"] = 372,
                    },
                    [3] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632994937,
                        ["quant"] = 1,
                        ["id"] = "1690210029",
                        ["itemLink"] = 372,
                    },
                    [4] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632994937,
                        ["quant"] = 1,
                        ["id"] = "1690210031",
                        ["itemLink"] = 372,
                    },
                    [5] = 
                    {
                        ["price"] = 435,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1632994939,
                        ["quant"] = 1,
                        ["id"] = "1690210045",
                        ["itemLink"] = 372,
                    },
                    [6] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633127148,
                        ["quant"] = 1,
                        ["id"] = "1691159785",
                        ["itemLink"] = 372,
                    },
                    [7] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633127150,
                        ["quant"] = 1,
                        ["id"] = "1691159811",
                        ["itemLink"] = 372,
                    },
                    [8] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633127153,
                        ["quant"] = 1,
                        ["id"] = "1691159851",
                        ["itemLink"] = 372,
                    },
                    [9] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633127158,
                        ["quant"] = 1,
                        ["id"] = "1691159889",
                        ["itemLink"] = 372,
                    },
                    [10] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633127159,
                        ["quant"] = 1,
                        ["id"] = "1691159893",
                        ["itemLink"] = 372,
                    },
                    [11] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633127162,
                        ["quant"] = 1,
                        ["id"] = "1691159909",
                        ["itemLink"] = 372,
                    },
                    [12] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633186052,
                        ["quant"] = 1,
                        ["id"] = "1691641217",
                        ["itemLink"] = 372,
                    },
                    [13] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633186053,
                        ["quant"] = 1,
                        ["id"] = "1691641241",
                        ["itemLink"] = 372,
                    },
                    [14] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633186054,
                        ["quant"] = 1,
                        ["id"] = "1691641253",
                        ["itemLink"] = 372,
                    },
                    [15] = 
                    {
                        ["price"] = 578,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186061,
                        ["quant"] = 1,
                        ["id"] = "1691641367",
                        ["itemLink"] = 372,
                    },
                    [16] = 
                    {
                        ["price"] = 578,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186062,
                        ["quant"] = 1,
                        ["id"] = "1691641375",
                        ["itemLink"] = 372,
                    },
                    [17] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231704,
                        ["quant"] = 1,
                        ["id"] = "1692132477",
                        ["itemLink"] = 372,
                    },
                    [18] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231705,
                        ["quant"] = 1,
                        ["id"] = "1692132483",
                        ["itemLink"] = 372,
                    },
                    [19] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231705,
                        ["quant"] = 1,
                        ["id"] = "1692132491",
                        ["itemLink"] = 372,
                    },
                    [20] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231706,
                        ["quant"] = 1,
                        ["id"] = "1692132495",
                        ["itemLink"] = 372,
                    },
                    [21] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231707,
                        ["quant"] = 1,
                        ["id"] = "1692132509",
                        ["itemLink"] = 372,
                    },
                    [22] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231708,
                        ["quant"] = 1,
                        ["id"] = "1692132513",
                        ["itemLink"] = 372,
                    },
                    [23] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231709,
                        ["quant"] = 1,
                        ["id"] = "1692132521",
                        ["itemLink"] = 372,
                    },
                    [24] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231710,
                        ["quant"] = 1,
                        ["id"] = "1692132535",
                        ["itemLink"] = 372,
                    },
                    [25] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231711,
                        ["quant"] = 1,
                        ["id"] = "1692132537",
                        ["itemLink"] = 372,
                    },
                    [26] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231712,
                        ["quant"] = 1,
                        ["id"] = "1692132545",
                        ["itemLink"] = 372,
                    },
                    [27] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231714,
                        ["quant"] = 1,
                        ["id"] = "1692132551",
                        ["itemLink"] = 372,
                    },
                    [28] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231716,
                        ["quant"] = 1,
                        ["id"] = "1692132557",
                        ["itemLink"] = 372,
                    },
                    [29] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231716,
                        ["quant"] = 1,
                        ["id"] = "1692132567",
                        ["itemLink"] = 372,
                    },
                    [30] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231718,
                        ["quant"] = 1,
                        ["id"] = "1692132581",
                        ["itemLink"] = 372,
                    },
                    [31] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231720,
                        ["quant"] = 1,
                        ["id"] = "1692132597",
                        ["itemLink"] = 372,
                    },
                    [32] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275197,
                        ["quant"] = 1,
                        ["id"] = "1692465633",
                        ["itemLink"] = 372,
                    },
                    [33] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275198,
                        ["quant"] = 1,
                        ["id"] = "1692465639",
                        ["itemLink"] = 372,
                    },
                    [34] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275199,
                        ["quant"] = 1,
                        ["id"] = "1692465649",
                        ["itemLink"] = 372,
                    },
                    [35] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275199,
                        ["quant"] = 1,
                        ["id"] = "1692465653",
                        ["itemLink"] = 372,
                    },
                    [36] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275200,
                        ["quant"] = 1,
                        ["id"] = "1692465661",
                        ["itemLink"] = 372,
                    },
                    [37] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275202,
                        ["quant"] = 1,
                        ["id"] = "1692465677",
                        ["itemLink"] = 372,
                    },
                    [38] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275203,
                        ["quant"] = 1,
                        ["id"] = "1692465683",
                        ["itemLink"] = 372,
                    },
                    [39] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275203,
                        ["quant"] = 1,
                        ["id"] = "1692465687",
                        ["itemLink"] = 372,
                    },
                    [40] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275205,
                        ["quant"] = 1,
                        ["id"] = "1692465701",
                        ["itemLink"] = 372,
                    },
                    [41] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275205,
                        ["quant"] = 1,
                        ["id"] = "1692465709",
                        ["itemLink"] = 372,
                    },
                    [42] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275207,
                        ["quant"] = 1,
                        ["id"] = "1692465731",
                        ["itemLink"] = 372,
                    },
                    [43] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275208,
                        ["quant"] = 1,
                        ["id"] = "1692465743",
                        ["itemLink"] = 372,
                    },
                    [44] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275210,
                        ["quant"] = 1,
                        ["id"] = "1692465775",
                        ["itemLink"] = 372,
                    },
                    [45] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275212,
                        ["quant"] = 1,
                        ["id"] = "1692465797",
                        ["itemLink"] = 372,
                    },
                    [46] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275213,
                        ["quant"] = 1,
                        ["id"] = "1692465803",
                        ["itemLink"] = 372,
                    },
                    [47] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275214,
                        ["quant"] = 1,
                        ["id"] = "1692465813",
                        ["itemLink"] = 372,
                    },
                    [48] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275215,
                        ["quant"] = 1,
                        ["id"] = "1692465825",
                        ["itemLink"] = 372,
                    },
                    [49] = 
                    {
                        ["price"] = 375,
                        ["guild"] = 1,
                        ["buyer"] = 184,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633282980,
                        ["quant"] = 1,
                        ["id"] = "1692546823",
                        ["itemLink"] = 372,
                    },
                    [50] = 
                    {
                        ["price"] = 475,
                        ["guild"] = 1,
                        ["buyer"] = 184,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633282982,
                        ["quant"] = 1,
                        ["id"] = "1692546837",
                        ["itemLink"] = 372,
                    },
                    [51] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294059,
                        ["quant"] = 1,
                        ["id"] = "1692676465",
                        ["itemLink"] = 372,
                    },
                    [52] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294060,
                        ["quant"] = 1,
                        ["id"] = "1692676479",
                        ["itemLink"] = 372,
                    },
                    [53] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294069,
                        ["quant"] = 1,
                        ["id"] = "1692676545",
                        ["itemLink"] = 372,
                    },
                    [54] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294071,
                        ["quant"] = 1,
                        ["id"] = "1692676575",
                        ["itemLink"] = 372,
                    },
                    [55] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294080,
                        ["quant"] = 1,
                        ["id"] = "1692676653",
                        ["itemLink"] = 372,
                    },
                    [56] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301456,
                        ["quant"] = 1,
                        ["id"] = "1692755749",
                        ["itemLink"] = 372,
                    },
                    [57] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301462,
                        ["quant"] = 1,
                        ["id"] = "1692755819",
                        ["itemLink"] = 372,
                    },
                    [58] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301464,
                        ["quant"] = 1,
                        ["id"] = "1692755843",
                        ["itemLink"] = 372,
                    },
                    [59] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301466,
                        ["quant"] = 1,
                        ["id"] = "1692755855",
                        ["itemLink"] = 372,
                    },
                    [60] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301467,
                        ["quant"] = 1,
                        ["id"] = "1692755861",
                        ["itemLink"] = 372,
                    },
                    [61] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301469,
                        ["quant"] = 1,
                        ["id"] = "1692755873",
                        ["itemLink"] = 372,
                    },
                    [62] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301469,
                        ["quant"] = 1,
                        ["id"] = "1692755877",
                        ["itemLink"] = 372,
                    },
                    [63] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301470,
                        ["quant"] = 1,
                        ["id"] = "1692755885",
                        ["itemLink"] = 372,
                    },
                    [64] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301472,
                        ["quant"] = 1,
                        ["id"] = "1692755901",
                        ["itemLink"] = 372,
                    },
                    [65] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301476,
                        ["quant"] = 1,
                        ["id"] = "1692755931",
                        ["itemLink"] = 372,
                    },
                    [66] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301484,
                        ["quant"] = 1,
                        ["id"] = "1692755987",
                        ["itemLink"] = 372,
                    },
                    [67] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632829377,
                        ["quant"] = 1,
                        ["id"] = "1688994979",
                        ["itemLink"] = 372,
                    },
                    [68] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632829377,
                        ["quant"] = 1,
                        ["id"] = "1688994981",
                        ["itemLink"] = 372,
                    },
                    [69] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632829378,
                        ["quant"] = 1,
                        ["id"] = "1688994987",
                        ["itemLink"] = 372,
                    },
                    [70] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632829380,
                        ["quant"] = 1,
                        ["id"] = "1688995005",
                        ["itemLink"] = 372,
                    },
                    [71] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632829381,
                        ["quant"] = 1,
                        ["id"] = "1688995009",
                        ["itemLink"] = 372,
                    },
                    [72] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632829381,
                        ["quant"] = 1,
                        ["id"] = "1688995015",
                        ["itemLink"] = 372,
                    },
                    [73] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632829382,
                        ["quant"] = 1,
                        ["id"] = "1688995025",
                        ["itemLink"] = 372,
                    },
                    [74] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632829384,
                        ["quant"] = 1,
                        ["id"] = "1688995029",
                        ["itemLink"] = 372,
                    },
                    [75] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2672,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632968102,
                        ["quant"] = 1,
                        ["id"] = "1690036491",
                        ["itemLink"] = 372,
                    },
                    [76] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2672,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632968103,
                        ["quant"] = 1,
                        ["id"] = "1690036503",
                        ["itemLink"] = 372,
                    },
                    [77] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2672,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632968104,
                        ["quant"] = 1,
                        ["id"] = "1690036509",
                        ["itemLink"] = 372,
                    },
                    [78] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2672,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632968106,
                        ["quant"] = 1,
                        ["id"] = "1690036551",
                        ["itemLink"] = 372,
                    },
                    [79] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2672,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632968108,
                        ["quant"] = 1,
                        ["id"] = "1690036569",
                        ["itemLink"] = 372,
                    },
                    [80] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2672,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632968108,
                        ["quant"] = 1,
                        ["id"] = "1690036577",
                        ["itemLink"] = 372,
                    },
                },
                ["totalCount"] = 80,
                ["itemAdderText"] = "cp160 white normal jewelry apparel neck ornate",
            },
            ["50:15:1:24:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Platinum Necklace",
                ["oldestTime"] = 1632829376,
                ["wasAltered"] = true,
                ["newestTime"] = 1633301474,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632994934,
                        ["quant"] = 1,
                        ["id"] = "1690210017",
                        ["itemLink"] = 371,
                    },
                    [2] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632994936,
                        ["quant"] = 1,
                        ["id"] = "1690210025",
                        ["itemLink"] = 371,
                    },
                    [3] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632994936,
                        ["quant"] = 1,
                        ["id"] = "1690210027",
                        ["itemLink"] = 371,
                    },
                    [4] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632994938,
                        ["quant"] = 1,
                        ["id"] = "1690210035",
                        ["itemLink"] = 371,
                    },
                    [5] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633127149,
                        ["quant"] = 1,
                        ["id"] = "1691159797",
                        ["itemLink"] = 371,
                    },
                    [6] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633127151,
                        ["quant"] = 1,
                        ["id"] = "1691159823",
                        ["itemLink"] = 371,
                    },
                    [7] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633127152,
                        ["quant"] = 1,
                        ["id"] = "1691159837",
                        ["itemLink"] = 371,
                    },
                    [8] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633127154,
                        ["quant"] = 1,
                        ["id"] = "1691159861",
                        ["itemLink"] = 371,
                    },
                    [9] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633127155,
                        ["quant"] = 1,
                        ["id"] = "1691159865",
                        ["itemLink"] = 371,
                    },
                    [10] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633127156,
                        ["quant"] = 1,
                        ["id"] = "1691159873",
                        ["itemLink"] = 371,
                    },
                    [11] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633127157,
                        ["quant"] = 1,
                        ["id"] = "1691159883",
                        ["itemLink"] = 371,
                    },
                    [12] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633127161,
                        ["quant"] = 1,
                        ["id"] = "1691159901",
                        ["itemLink"] = 371,
                    },
                    [13] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633127163,
                        ["quant"] = 1,
                        ["id"] = "1691159913",
                        ["itemLink"] = 371,
                    },
                    [14] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633127165,
                        ["quant"] = 1,
                        ["id"] = "1691159923",
                        ["itemLink"] = 371,
                    },
                    [15] = 
                    {
                        ["price"] = 425,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 528,
                        ["timestamp"] = 1633186049,
                        ["quant"] = 1,
                        ["id"] = "1691641165",
                        ["itemLink"] = 371,
                    },
                    [16] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 445,
                        ["timestamp"] = 1633186072,
                        ["quant"] = 1,
                        ["id"] = "1691641521",
                        ["itemLink"] = 371,
                    },
                    [17] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231704,
                        ["quant"] = 1,
                        ["id"] = "1692132467",
                        ["itemLink"] = 371,
                    },
                    [18] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231707,
                        ["quant"] = 1,
                        ["id"] = "1692132503",
                        ["itemLink"] = 371,
                    },
                    [19] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231708,
                        ["quant"] = 1,
                        ["id"] = "1692132517",
                        ["itemLink"] = 371,
                    },
                    [20] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231709,
                        ["quant"] = 1,
                        ["id"] = "1692132525",
                        ["itemLink"] = 371,
                    },
                    [21] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231710,
                        ["quant"] = 1,
                        ["id"] = "1692132531",
                        ["itemLink"] = 371,
                    },
                    [22] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231712,
                        ["quant"] = 1,
                        ["id"] = "1692132543",
                        ["itemLink"] = 371,
                    },
                    [23] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231713,
                        ["quant"] = 1,
                        ["id"] = "1692132549",
                        ["itemLink"] = 371,
                    },
                    [24] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231716,
                        ["quant"] = 1,
                        ["id"] = "1692132561",
                        ["itemLink"] = 371,
                    },
                    [25] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231716,
                        ["quant"] = 1,
                        ["id"] = "1692132563",
                        ["itemLink"] = 371,
                    },
                    [26] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231717,
                        ["quant"] = 1,
                        ["id"] = "1692132573",
                        ["itemLink"] = 371,
                    },
                    [27] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231720,
                        ["quant"] = 1,
                        ["id"] = "1692132603",
                        ["itemLink"] = 371,
                    },
                    [28] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633231721,
                        ["quant"] = 1,
                        ["id"] = "1692132609",
                        ["itemLink"] = 371,
                    },
                    [29] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275197,
                        ["quant"] = 1,
                        ["id"] = "1692465627",
                        ["itemLink"] = 371,
                    },
                    [30] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275201,
                        ["quant"] = 1,
                        ["id"] = "1692465663",
                        ["itemLink"] = 371,
                    },
                    [31] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275204,
                        ["quant"] = 1,
                        ["id"] = "1692465695",
                        ["itemLink"] = 371,
                    },
                    [32] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275206,
                        ["quant"] = 1,
                        ["id"] = "1692465715",
                        ["itemLink"] = 371,
                    },
                    [33] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275211,
                        ["quant"] = 1,
                        ["id"] = "1692465785",
                        ["itemLink"] = 371,
                    },
                    [34] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275216,
                        ["quant"] = 1,
                        ["id"] = "1692465837",
                        ["itemLink"] = 371,
                    },
                    [35] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275217,
                        ["quant"] = 1,
                        ["id"] = "1692465845",
                        ["itemLink"] = 371,
                    },
                    [36] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275217,
                        ["quant"] = 1,
                        ["id"] = "1692465851",
                        ["itemLink"] = 371,
                    },
                    [37] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275218,
                        ["quant"] = 1,
                        ["id"] = "1692465861",
                        ["itemLink"] = 371,
                    },
                    [38] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275219,
                        ["quant"] = 1,
                        ["id"] = "1692465871",
                        ["itemLink"] = 371,
                    },
                    [39] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275220,
                        ["quant"] = 1,
                        ["id"] = "1692465879",
                        ["itemLink"] = 371,
                    },
                    [40] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633275221,
                        ["quant"] = 1,
                        ["id"] = "1692465889",
                        ["itemLink"] = 371,
                    },
                    [41] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294059,
                        ["quant"] = 1,
                        ["id"] = "1692676467",
                        ["itemLink"] = 371,
                    },
                    [42] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294066,
                        ["quant"] = 1,
                        ["id"] = "1692676515",
                        ["itemLink"] = 371,
                    },
                    [43] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294070,
                        ["quant"] = 1,
                        ["id"] = "1692676561",
                        ["itemLink"] = 371,
                    },
                    [44] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301457,
                        ["quant"] = 1,
                        ["id"] = "1692755765",
                        ["itemLink"] = 371,
                    },
                    [45] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301459,
                        ["quant"] = 1,
                        ["id"] = "1692755797",
                        ["itemLink"] = 371,
                    },
                    [46] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301460,
                        ["quant"] = 1,
                        ["id"] = "1692755811",
                        ["itemLink"] = 371,
                    },
                    [47] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301463,
                        ["quant"] = 1,
                        ["id"] = "1692755831",
                        ["itemLink"] = 371,
                    },
                    [48] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301465,
                        ["quant"] = 1,
                        ["id"] = "1692755849",
                        ["itemLink"] = 371,
                    },
                    [49] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301468,
                        ["quant"] = 1,
                        ["id"] = "1692755867",
                        ["itemLink"] = 371,
                    },
                    [50] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301471,
                        ["quant"] = 1,
                        ["id"] = "1692755895",
                        ["itemLink"] = 371,
                    },
                    [51] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301474,
                        ["quant"] = 1,
                        ["id"] = "1692755923",
                        ["itemLink"] = 371,
                    },
                    [52] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632829376,
                        ["quant"] = 1,
                        ["id"] = "1688994971",
                        ["itemLink"] = 371,
                    },
                    [53] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632829376,
                        ["quant"] = 1,
                        ["id"] = "1688994975",
                        ["itemLink"] = 371,
                    },
                    [54] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632829378,
                        ["quant"] = 1,
                        ["id"] = "1688994983",
                        ["itemLink"] = 371,
                    },
                    [55] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632829379,
                        ["quant"] = 1,
                        ["id"] = "1688994993",
                        ["itemLink"] = 371,
                    },
                    [56] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632829379,
                        ["quant"] = 1,
                        ["id"] = "1688994997",
                        ["itemLink"] = 371,
                    },
                    [57] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632829380,
                        ["quant"] = 1,
                        ["id"] = "1688995001",
                        ["itemLink"] = 371,
                    },
                    [58] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632829382,
                        ["quant"] = 1,
                        ["id"] = "1688995019",
                        ["itemLink"] = 371,
                    },
                    [59] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632829383,
                        ["quant"] = 1,
                        ["id"] = "1688995027",
                        ["itemLink"] = 371,
                    },
                    [60] = 
                    {
                        ["price"] = 465,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 332,
                        ["timestamp"] = 1632911741,
                        ["quant"] = 1,
                        ["id"] = "1689607431",
                        ["itemLink"] = 371,
                    },
                    [61] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2672,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632968104,
                        ["quant"] = 1,
                        ["id"] = "1690036517",
                        ["itemLink"] = 371,
                    },
                    [62] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2672,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632968105,
                        ["quant"] = 1,
                        ["id"] = "1690036529",
                        ["itemLink"] = 371,
                    },
                    [63] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2672,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632968105,
                        ["quant"] = 1,
                        ["id"] = "1690036535",
                        ["itemLink"] = 371,
                    },
                },
                ["totalCount"] = 63,
                ["itemAdderText"] = "cp150 white normal jewelry apparel neck ornate",
            },
            ["1:0:1:24:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Pewter Necklace",
                ["oldestTime"] = 1633065217,
                ["wasAltered"] = true,
                ["newestTime"] = 1633065217,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99,
                        ["guild"] = 1,
                        ["buyer"] = 817,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633065217,
                        ["quant"] = 1,
                        ["id"] = "1690749019",
                        ["itemLink"] = 1058,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal jewelry apparel neck ornate",
            },
        },
        [130013] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 52: Redoran Boots",
                ["oldestTime"] = 1633101100,
                ["wasAltered"] = true,
                ["newestTime"] = 1633184109,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19722,
                        ["guild"] = 1,
                        ["buyer"] = 948,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1633101100,
                        ["quant"] = 1,
                        ["id"] = "1690964841",
                        ["itemLink"] = 1285,
                    },
                    [2] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 1386,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633184109,
                        ["quant"] = 1,
                        ["id"] = "1691622297",
                        ["itemLink"] = 1285,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [123222] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_heavy_feet_a.dds",
                ["itemDesc"] = "Vanguard's Challenge Sabatons",
                ["oldestTime"] = 1633200739,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200739,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1491,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633200739,
                        ["quant"] = 1,
                        ["id"] = "1691797181",
                        ["itemLink"] = 2194,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set vanguard's challenge feet well-fitted",
            },
        },
        [130294] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_tre_ded_vrdlimberpine_branch002.dds",
                ["itemDesc"] = "Branch, Forked Burnt",
                ["oldestTime"] = 1633214889,
                ["wasAltered"] = true,
                ["newestTime"] = 1633214889,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 60,
                        ["guild"] = 1,
                        ["buyer"] = 1581,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1633214889,
                        ["quant"] = 1,
                        ["id"] = "1691958159",
                        ["itemLink"] = 2307,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings conservatory",
            },
        },
        [68343] = 
        {
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_enchantment_036.dds",
                ["itemDesc"] = "Truly Superb Glyph of Prismatic Defense",
                ["oldestTime"] = 1632863789,
                ["wasAltered"] = true,
                ["newestTime"] = 1633307481,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 47895,
                        ["guild"] = 1,
                        ["buyer"] = 1221,
                        ["wasKiosk"] = true,
                        ["seller"] = 1222,
                        ["timestamp"] = 1633144602,
                        ["quant"] = 1,
                        ["id"] = "1691343699",
                        ["itemLink"] = 1645,
                    },
                    [2] = 
                    {
                        ["price"] = 47895,
                        ["guild"] = 1,
                        ["buyer"] = 1458,
                        ["wasKiosk"] = true,
                        ["seller"] = 1222,
                        ["timestamp"] = 1633196770,
                        ["quant"] = 1,
                        ["id"] = "1691756109",
                        ["itemLink"] = 1645,
                    },
                    [3] = 
                    {
                        ["price"] = 47895,
                        ["guild"] = 1,
                        ["buyer"] = 1458,
                        ["wasKiosk"] = true,
                        ["seller"] = 1222,
                        ["timestamp"] = 1633196773,
                        ["quant"] = 1,
                        ["id"] = "1691756173",
                        ["itemLink"] = 1645,
                    },
                    [4] = 
                    {
                        ["price"] = 47895,
                        ["guild"] = 1,
                        ["buyer"] = 1458,
                        ["wasKiosk"] = true,
                        ["seller"] = 1222,
                        ["timestamp"] = 1633196775,
                        ["quant"] = 1,
                        ["id"] = "1691756213",
                        ["itemLink"] = 1645,
                    },
                    [5] = 
                    {
                        ["price"] = 47895,
                        ["guild"] = 1,
                        ["buyer"] = 1458,
                        ["wasKiosk"] = true,
                        ["seller"] = 1222,
                        ["timestamp"] = 1633196776,
                        ["quant"] = 1,
                        ["id"] = "1691756253",
                        ["itemLink"] = 1645,
                    },
                    [6] = 
                    {
                        ["price"] = 49000,
                        ["guild"] = 1,
                        ["buyer"] = 1682,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633229598,
                        ["quant"] = 1,
                        ["id"] = "1692111673",
                        ["itemLink"] = 1645,
                    },
                    [7] = 
                    {
                        ["price"] = 49000,
                        ["guild"] = 1,
                        ["buyer"] = 1682,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633229599,
                        ["quant"] = 1,
                        ["id"] = "1692111687",
                        ["itemLink"] = 1645,
                    },
                    [8] = 
                    {
                        ["price"] = 49000,
                        ["guild"] = 1,
                        ["buyer"] = 1682,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633229610,
                        ["quant"] = 1,
                        ["id"] = "1692111821",
                        ["itemLink"] = 1645,
                    },
                    [9] = 
                    {
                        ["price"] = 49000,
                        ["guild"] = 1,
                        ["buyer"] = 1682,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633229612,
                        ["quant"] = 1,
                        ["id"] = "1692111841",
                        ["itemLink"] = 1645,
                    },
                    [10] = 
                    {
                        ["price"] = 49188,
                        ["guild"] = 1,
                        ["buyer"] = 1682,
                        ["wasKiosk"] = true,
                        ["seller"] = 600,
                        ["timestamp"] = 1633229612,
                        ["quant"] = 1,
                        ["id"] = "1692111849",
                        ["itemLink"] = 1645,
                    },
                    [11] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 2037,
                        ["wasKiosk"] = true,
                        ["seller"] = 2038,
                        ["timestamp"] = 1633299235,
                        ["quant"] = 1,
                        ["id"] = "1692734321",
                        ["itemLink"] = 1645,
                    },
                    [12] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 2037,
                        ["wasKiosk"] = true,
                        ["seller"] = 2038,
                        ["timestamp"] = 1633299239,
                        ["quant"] = 1,
                        ["id"] = "1692734383",
                        ["itemLink"] = 1645,
                    },
                    [13] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 2038,
                        ["timestamp"] = 1633307469,
                        ["quant"] = 1,
                        ["id"] = "1692817213",
                        ["itemLink"] = 1645,
                    },
                    [14] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 2038,
                        ["timestamp"] = 1633307469,
                        ["quant"] = 1,
                        ["id"] = "1692817223",
                        ["itemLink"] = 1645,
                    },
                    [15] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 2038,
                        ["timestamp"] = 1633307473,
                        ["quant"] = 1,
                        ["id"] = "1692817259",
                        ["itemLink"] = 1645,
                    },
                    [16] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 2038,
                        ["timestamp"] = 1633307475,
                        ["quant"] = 1,
                        ["id"] = "1692817277",
                        ["itemLink"] = 1645,
                    },
                    [17] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 2038,
                        ["timestamp"] = 1633307476,
                        ["quant"] = 1,
                        ["id"] = "1692817287",
                        ["itemLink"] = 1645,
                    },
                    [18] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 2038,
                        ["timestamp"] = 1633307477,
                        ["quant"] = 1,
                        ["id"] = "1692817303",
                        ["itemLink"] = 1645,
                    },
                    [19] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 2038,
                        ["timestamp"] = 1633307478,
                        ["quant"] = 1,
                        ["id"] = "1692817319",
                        ["itemLink"] = 1645,
                    },
                    [20] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 2038,
                        ["timestamp"] = 1633307479,
                        ["quant"] = 1,
                        ["id"] = "1692817321",
                        ["itemLink"] = 1645,
                    },
                    [21] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 2038,
                        ["timestamp"] = 1633307479,
                        ["quant"] = 1,
                        ["id"] = "1692817329",
                        ["itemLink"] = 1645,
                    },
                    [22] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 2038,
                        ["timestamp"] = 1633307480,
                        ["quant"] = 1,
                        ["id"] = "1692817335",
                        ["itemLink"] = 1645,
                    },
                    [23] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 2038,
                        ["timestamp"] = 1633307480,
                        ["quant"] = 1,
                        ["id"] = "1692817345",
                        ["itemLink"] = 1645,
                    },
                    [24] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 2038,
                        ["timestamp"] = 1633307481,
                        ["quant"] = 1,
                        ["id"] = "1692817347",
                        ["itemLink"] = 1645,
                    },
                    [25] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 2038,
                        ["timestamp"] = 1633307481,
                        ["quant"] = 1,
                        ["id"] = "1692817351",
                        ["itemLink"] = 1645,
                    },
                    [26] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 2254,
                        ["wasKiosk"] = true,
                        ["seller"] = 593,
                        ["timestamp"] = 1632863789,
                        ["quant"] = 1,
                        ["id"] = "1689257033",
                        ["itemLink"] = 1645,
                    },
                },
                ["totalCount"] = 26,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous armor glyph",
            },
        },
        [149240] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Crafty Alfiq's Ring",
                ["oldestTime"] = 1633279255,
                ["wasAltered"] = true,
                ["newestTime"] = 1633279255,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5999,
                        ["guild"] = 1,
                        ["buyer"] = 1922,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633279255,
                        ["quant"] = 1,
                        ["id"] = "1692507123",
                        ["itemLink"] = 2728,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set crafty alfiq ring arcane",
            },
        },
        [117241] = 
        {
            ["50:16:4:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_shield_a.dds",
                ["itemDesc"] = "Shield of the Powerful Assault",
                ["oldestTime"] = 1632958926,
                ["wasAltered"] = true,
                ["newestTime"] = 1632958926,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22222,
                        ["guild"] = 1,
                        ["buyer"] = 2622,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1632958926,
                        ["quant"] = 1,
                        ["id"] = "1689951905",
                        ["itemLink"] = 3916,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic apparel weapon set powerful assault shield off hand training",
            },
        },
        [45050] = 
        {
            ["50:16:2:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Ice Staff of Shock",
                ["oldestTime"] = 1632826475,
                ["wasAltered"] = true,
                ["newestTime"] = 1632826475,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 234,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632826475,
                        ["quant"] = 1,
                        ["id"] = "1688971747",
                        ["itemLink"] = 3045,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon frost staff two-handed powered",
            },
        },
        [45051] = 
        {
            ["50:16:3:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Lightning Staff of Flame",
                ["oldestTime"] = 1633179499,
                ["wasAltered"] = true,
                ["newestTime"] = 1633179499,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 240,
                        ["guild"] = 1,
                        ["buyer"] = 1363,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633179499,
                        ["quant"] = 1,
                        ["id"] = "1691583003",
                        ["itemLink"] = 1913,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon lightning staff two-handed powered",
            },
            ["50:16:2:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Lightning Staff of Shock",
                ["oldestTime"] = 1632826482,
                ["wasAltered"] = true,
                ["newestTime"] = 1632826482,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 245,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1632826482,
                        ["quant"] = 1,
                        ["id"] = "1688971827",
                        ["itemLink"] = 3047,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon lightning staff two-handed powered",
            },
        },
        [139516] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Alinor Fence, Tall",
                ["oldestTime"] = 1633198331,
                ["wasAltered"] = true,
                ["newestTime"] = 1633198331,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1472,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633198331,
                        ["quant"] = 1,
                        ["id"] = "1691772087",
                        ["itemLink"] = 2161,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [74223] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_abahswatch_light_feet_a.dds",
                ["itemDesc"] = "Shoes of Transmutation",
                ["oldestTime"] = 1633145862,
                ["wasAltered"] = true,
                ["newestTime"] = 1633145862,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 384,
                        ["wasKiosk"] = true,
                        ["seller"] = 145,
                        ["timestamp"] = 1633145862,
                        ["quant"] = 1,
                        ["id"] = "1691355389",
                        ["itemLink"] = 1651,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set robes of transmutation feet divines",
            },
        },
        [95471] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_light_legs_a.dds",
                ["itemDesc"] = "Breeches of Martial Knowledge",
                ["oldestTime"] = 1633022978,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022978,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1633022978,
                        ["quant"] = 1,
                        ["id"] = "1690390435",
                        ["itemLink"] = 618,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set way of martial knowledge legs infused",
            },
        },
        [139263] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_inc_fireplacestandgroup001.dds",
                ["itemDesc"] = "Fireplace Tools, Wrought Iron",
                ["oldestTime"] = 1633165862,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165862,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 17,
                        ["timestamp"] = 1633165862,
                        ["quant"] = 1,
                        ["id"] = "1691499787",
                        ["itemLink"] = 1845,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings workshop",
            },
        },
    },
}
