GS08DataSavedVariables =
{
    ["listingseu"] = 
    {
    },
    ["listingsna"] = 
    {
    },
    ["dataeu"] = 
    {
    },
    ["datana"] = 
    {
        [181505] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_str_leyfireplace002.dds",
                ["itemDesc"] = "Leyawiin Hearth, Carved Wood",
                ["oldestTime"] = 1633033973,
                ["wasAltered"] = true,
                ["newestTime"] = 1633271768,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 585,
                        ["wasKiosk"] = true,
                        ["seller"] = 586,
                        ["timestamp"] = 1633033973,
                        ["quant"] = 1,
                        ["id"] = "1690469869",
                        ["itemLink"] = 754,
                    },
                    [2] = 
                    {
                        ["price"] = 80000,
                        ["guild"] = 1,
                        ["buyer"] = 1883,
                        ["wasKiosk"] = true,
                        ["seller"] = 586,
                        ["timestamp"] = 1633271768,
                        ["quant"] = 1,
                        ["id"] = "1692423477",
                        ["itemLink"] = 754,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary furnishings structures",
            },
        },
        [68612] = 
        {
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_heavy_legs_a.dds",
                ["itemDesc"] = "Greaves of the Pariah",
                ["oldestTime"] = 1633049801,
                ["wasAltered"] = true,
                ["newestTime"] = 1633049801,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2750,
                        ["guild"] = 1,
                        ["buyer"] = 334,
                        ["wasKiosk"] = false,
                        ["seller"] = 697,
                        ["timestamp"] = 1633049801,
                        ["quant"] = 1,
                        ["id"] = "1690602885",
                        ["itemLink"] = 885,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set mark of the pariah legs infused",
            },
        },
        [142601] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Bright-Throat's Boast Necklace",
                ["oldestTime"] = 1633238673,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238673,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12222,
                        ["guild"] = 1,
                        ["buyer"] = 1752,
                        ["wasKiosk"] = true,
                        ["seller"] = 315,
                        ["timestamp"] = 1633238673,
                        ["quant"] = 1,
                        ["id"] = "1692189387",
                        ["itemLink"] = 2516,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set bright-throat's boast neck arcane",
            },
            ["50:16:5:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Bright-Throat's Boast Necklace",
                ["oldestTime"] = 1633285692,
                ["wasAltered"] = true,
                ["newestTime"] = 1633285692,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250000,
                        ["guild"] = 1,
                        ["buyer"] = 1953,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633285692,
                        ["quant"] = 1,
                        ["id"] = "1692573373",
                        ["itemLink"] = 2757,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary jewelry apparel set bright-throat's boast neck arcane",
            },
        },
        [175627] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_fur_leybenchlarge002a.dds",
                ["itemDesc"] = "Leyawiin Bench, Formal Wide",
                ["oldestTime"] = 1633226115,
                ["wasAltered"] = true,
                ["newestTime"] = 1633226115,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1650,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633226115,
                        ["quant"] = 1,
                        ["id"] = "1692075555",
                        ["itemLink"] = 2394,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings dining",
            },
        },
        [30221] = 
        {
            ["1:0:1:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_enchantment_base_sardonyx_r2.dds",
                ["itemDesc"] = "Sardonyx",
                ["oldestTime"] = 1632987719,
                ["wasAltered"] = true,
                ["newestTime"] = 1632987719,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 142,
                        ["timestamp"] = 1632987719,
                        ["quant"] = 200,
                        ["id"] = "1690172875",
                        ["itemLink"] = 337,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials armor trait reinforced",
            },
        },
        [86798] = 
        {
            ["50:16:4:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_d.dds",
                ["itemDesc"] = "Restoration Staff of Necropotence",
                ["oldestTime"] = 1633263560,
                ["wasAltered"] = true,
                ["newestTime"] = 1633263560,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1840,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1633263560,
                        ["quant"] = 1,
                        ["id"] = "1692347407",
                        ["itemLink"] = 2633,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set necropotence healing staff two-handed precise",
            },
        },
        [135440] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_medium_feet_a.dds",
                ["itemDesc"] = "Gryphon's Boots",
                ["oldestTime"] = 1633094747,
                ["wasAltered"] = true,
                ["newestTime"] = 1633094747,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 299,
                        ["guild"] = 1,
                        ["buyer"] = 63,
                        ["wasKiosk"] = false,
                        ["seller"] = 2,
                        ["timestamp"] = 1633094747,
                        ["quant"] = 1,
                        ["id"] = "1690917455",
                        ["itemLink"] = 1251,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set gryphon's ferocity feet impenetrable",
            },
        },
        [97298] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_head_d.dds",
                ["itemDesc"] = "Hat of a Mother's Sorrow",
                ["oldestTime"] = 1632884570,
                ["wasAltered"] = true,
                ["newestTime"] = 1632884570,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 2383,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1632884570,
                        ["quant"] = 1,
                        ["id"] = "1689447125",
                        ["itemLink"] = 3498,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set mother's sorrow head reinforced",
            },
        },
        [172051] = 
        {
            ["50:16:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_legs_a.dds",
                ["itemDesc"] = "Breeches of Frostbite",
                ["oldestTime"] = 1633215990,
                ["wasAltered"] = true,
                ["newestTime"] = 1633215990,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 327,
                        ["wasKiosk"] = false,
                        ["seller"] = 512,
                        ["timestamp"] = 1633215990,
                        ["quant"] = 1,
                        ["id"] = "1691968345",
                        ["itemLink"] = 2315,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite legs impenetrable",
            },
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_legs_a.dds",
                ["itemDesc"] = "Breeches of Frostbite",
                ["oldestTime"] = 1633215992,
                ["wasAltered"] = true,
                ["newestTime"] = 1633215992,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 327,
                        ["wasKiosk"] = false,
                        ["seller"] = 512,
                        ["timestamp"] = 1633215992,
                        ["quant"] = 1,
                        ["id"] = "1691968361",
                        ["itemLink"] = 2316,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set frostbite legs impenetrable",
            },
        },
        [102165] = 
        {
            ["50:16:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_draugr_shield_a.dds",
                ["itemDesc"] = "Stygian Shield",
                ["oldestTime"] = 1633214722,
                ["wasAltered"] = true,
                ["newestTime"] = 1633214722,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 1577,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633214722,
                        ["quant"] = 1,
                        ["id"] = "1691956199",
                        ["itemLink"] = 2302,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine apparel weapon set stygian shield off hand impenetrable",
            },
        },
        [172312] = 
        {
            ["50:16:2:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_2hhammer_a.dds",
                ["itemDesc"] = "Bog Raider's Maul",
                ["oldestTime"] = 1633289452,
                ["wasAltered"] = true,
                ["newestTime"] = 1633289452,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 202,
                        ["wasKiosk"] = false,
                        ["seller"] = 22,
                        ["timestamp"] = 1633289452,
                        ["quant"] = 1,
                        ["id"] = "1692620607",
                        ["itemLink"] = 2773,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set bog raider mace two-handed powered",
            },
        },
        [167961] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 96: Arkthzand Armory Axes",
                ["oldestTime"] = 1632891891,
                ["wasAltered"] = true,
                ["newestTime"] = 1632891891,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 973,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632891891,
                        ["quant"] = 1,
                        ["id"] = "1689507411",
                        ["itemLink"] = 3543,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45595] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Tsaesci Tea",
                ["oldestTime"] = 1632913046,
                ["wasAltered"] = true,
                ["newestTime"] = 1632913046,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 380,
                        ["guild"] = 1,
                        ["buyer"] = 2471,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1632913046,
                        ["quant"] = 1,
                        ["id"] = "1689612449",
                        ["itemLink"] = 3624,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [147741] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 75: Sunspire Shields",
                ["oldestTime"] = 1632897558,
                ["wasAltered"] = true,
                ["newestTime"] = 1633008238,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3999,
                        ["guild"] = 1,
                        ["buyer"] = 25,
                        ["wasKiosk"] = true,
                        ["seller"] = 417,
                        ["timestamp"] = 1633008238,
                        ["quant"] = 4,
                        ["id"] = "1690277803",
                        ["itemLink"] = 443,
                    },
                    [2] = 
                    {
                        ["price"] = 20039,
                        ["guild"] = 1,
                        ["buyer"] = 2438,
                        ["wasKiosk"] = true,
                        ["seller"] = 54,
                        ["timestamp"] = 1632897558,
                        ["quant"] = 1,
                        ["id"] = "1689546529",
                        ["itemLink"] = 443,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [77089] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ooth_medium_chest_a.dds",
                ["itemDesc"] = "Jack of Flanking",
                ["oldestTime"] = 1633141167,
                ["wasAltered"] = true,
                ["newestTime"] = 1633141167,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 1188,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1633141167,
                        ["quant"] = 1,
                        ["id"] = "1691303071",
                        ["itemLink"] = 1613,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set flanking strategist chest infused",
            },
        },
        [127012] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing4.dds",
                ["itemDesc"] = "Diagram: Indoril Platter, Floral",
                ["oldestTime"] = 1633234232,
                ["wasAltered"] = true,
                ["newestTime"] = 1633234232,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 1720,
                        ["wasKiosk"] = false,
                        ["seller"] = 508,
                        ["timestamp"] = 1633234232,
                        ["quant"] = 1,
                        ["id"] = "1692155625",
                        ["itemLink"] = 2466,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [43558] = 
        {
            ["50:14:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_staff_d.dds",
                ["itemDesc"] = "Nightwood Ice Staff",
                ["oldestTime"] = 1633018984,
                ["wasAltered"] = true,
                ["newestTime"] = 1633018984,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 520,
                        ["guild"] = 1,
                        ["buyer"] = 500,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1633018984,
                        ["quant"] = 1,
                        ["id"] = "1690358069",
                        ["itemLink"] = 575,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp140 green fine weapon frost staff two-handed",
            },
        },
        [97319] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_head_d.dds",
                ["itemDesc"] = "Hat of a Mother's Sorrow",
                ["oldestTime"] = 1633315657,
                ["wasAltered"] = true,
                ["newestTime"] = 1633315657,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 101,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633315657,
                        ["quant"] = 1,
                        ["id"] = "1692912021",
                        ["itemLink"] = 73,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set mother's sorrow head impenetrable",
            },
        },
        [172072] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_legs_a.dds",
                ["itemDesc"] = "Breeches of Frostbite",
                ["oldestTime"] = 1633168228,
                ["wasAltered"] = true,
                ["newestTime"] = 1633168228,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 180,
                        ["guild"] = 1,
                        ["buyer"] = 1332,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633168228,
                        ["quant"] = 1,
                        ["id"] = "1691511591",
                        ["itemLink"] = 1873,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set frostbite legs invigorating",
            },
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_legs_a.dds",
                ["itemDesc"] = "Breeches of Frostbite",
                ["oldestTime"] = 1633168230,
                ["wasAltered"] = true,
                ["newestTime"] = 1633168230,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1332,
                        ["wasKiosk"] = true,
                        ["seller"] = 61,
                        ["timestamp"] = 1633168230,
                        ["quant"] = 1,
                        ["id"] = "1691511601",
                        ["itemLink"] = 1874,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set frostbite legs invigorating",
            },
        },
        [811] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_light_armor_standard_r_001.dds",
                ["itemDesc"] = "Jute",
                ["oldestTime"] = 1633056653,
                ["wasAltered"] = true,
                ["newestTime"] = 1633313038,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 45,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1633313038,
                        ["quant"] = 100,
                        ["id"] = "1692880595",
                        ["itemLink"] = 33,
                    },
                    [2] = 
                    {
                        ["price"] = 3881,
                        ["guild"] = 1,
                        ["buyer"] = 756,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633056653,
                        ["quant"] = 200,
                        ["id"] = "1690673917",
                        ["itemLink"] = 33,
                    },
                    [3] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 2055,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633304260,
                        ["quant"] = 200,
                        ["id"] = "1692782489",
                        ["itemLink"] = 33,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [166700] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_cartographers_mask.dds",
                ["itemDesc"] = "Cartographer's Mask",
                ["oldestTime"] = 1633135274,
                ["wasAltered"] = true,
                ["newestTime"] = 1633135274,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7420,
                        ["guild"] = 1,
                        ["buyer"] = 1138,
                        ["wasKiosk"] = true,
                        ["seller"] = 1112,
                        ["timestamp"] = 1633135274,
                        ["quant"] = 1,
                        ["id"] = "1691245287",
                        ["itemLink"] = 1558,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [45358] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_medium_hands_d.dds",
                ["itemDesc"] = "Rubedo Leather Bracers",
                ["oldestTime"] = 1632831878,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185983,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 225,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 442,
                        ["timestamp"] = 1633009342,
                        ["quant"] = 1,
                        ["id"] = "1690285185",
                        ["itemLink"] = 453,
                    },
                    [2] = 
                    {
                        ["price"] = 194,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1633023005,
                        ["quant"] = 1,
                        ["id"] = "1690390633",
                        ["itemLink"] = 628,
                    },
                    [3] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084082,
                        ["quant"] = 1,
                        ["id"] = "1690854941",
                        ["itemLink"] = 1177,
                    },
                    [4] = 
                    {
                        ["price"] = 84,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633146927,
                        ["quant"] = 1,
                        ["id"] = "1691365207",
                        ["itemLink"] = 1658,
                    },
                    [5] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633146937,
                        ["quant"] = 1,
                        ["id"] = "1691365351",
                        ["itemLink"] = 1669,
                    },
                    [6] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633146938,
                        ["quant"] = 1,
                        ["id"] = "1691365361",
                        ["itemLink"] = 453,
                    },
                    [7] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633185968,
                        ["quant"] = 1,
                        ["id"] = "1691640427",
                        ["itemLink"] = 2038,
                    },
                    [8] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1633185982,
                        ["quant"] = 1,
                        ["id"] = "1691640503",
                        ["itemLink"] = 1658,
                    },
                    [9] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1633185983,
                        ["quant"] = 1,
                        ["id"] = "1691640509",
                        ["itemLink"] = 453,
                    },
                    [10] = 
                    {
                        ["price"] = 194,
                        ["guild"] = 1,
                        ["buyer"] = 2141,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632831878,
                        ["quant"] = 1,
                        ["id"] = "1689009967",
                        ["itemLink"] = 3091,
                    },
                    [11] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1632839965,
                        ["quant"] = 1,
                        ["id"] = "1689060175",
                        ["itemLink"] = 2038,
                    },
                    [12] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1632839965,
                        ["quant"] = 1,
                        ["id"] = "1689060181",
                        ["itemLink"] = 3136,
                    },
                    [13] = 
                    {
                        ["price"] = 310,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632839970,
                        ["quant"] = 1,
                        ["id"] = "1689060243",
                        ["itemLink"] = 628,
                    },
                },
                ["totalCount"] = 13,
                ["itemAdderText"] = "cp160 white normal medium apparel hands intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_medium_hands_d.dds",
                ["itemDesc"] = "Rubedo Leather Bracers",
                ["oldestTime"] = 1632885645,
                ["wasAltered"] = true,
                ["newestTime"] = 1632956421,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632885645,
                        ["quant"] = 1,
                        ["id"] = "1689459533",
                        ["itemLink"] = 3509,
                    },
                    [2] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632885648,
                        ["quant"] = 1,
                        ["id"] = "1689459551",
                        ["itemLink"] = 3509,
                    },
                    [3] = 
                    {
                        ["price"] = 194,
                        ["guild"] = 1,
                        ["buyer"] = 2202,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632913790,
                        ["quant"] = 1,
                        ["id"] = "1689616119",
                        ["itemLink"] = 3509,
                    },
                    [4] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632956421,
                        ["quant"] = 1,
                        ["id"] = "1689931863",
                        ["itemLink"] = 3509,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp150 white normal medium apparel hands intricate",
            },
            ["50:14:2:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_medium_hands_d.dds",
                ["itemDesc"] = "Shadowhide Bracers",
                ["oldestTime"] = 1632839969,
                ["wasAltered"] = true,
                ["newestTime"] = 1632839969,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 1004,
                        ["timestamp"] = 1632839969,
                        ["quant"] = 1,
                        ["id"] = "1689060233",
                        ["itemLink"] = 3145,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp140 green fine medium apparel hands intricate",
            },
        },
        [176176] = 
        {
            ["1:0:3:35:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_dagger.dds",
                ["itemDesc"] = "Companion's Dagger",
                ["oldestTime"] = 1633292719,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292719,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1994,
                        ["wasKiosk"] = true,
                        ["seller"] = 8,
                        ["timestamp"] = 1633292719,
                        ["quant"] = 1,
                        ["id"] = "1692660665",
                        ["itemLink"] = 2845,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior weapon dagger one-handed prolific",
            },
        },
        [45363] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_shield_d.dds",
                ["itemDesc"] = "Ruby Ash Shield",
                ["oldestTime"] = 1632826518,
                ["wasAltered"] = true,
                ["newestTime"] = 1633146938,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009363,
                        ["quant"] = 1,
                        ["id"] = "1690285411",
                        ["itemLink"] = 477,
                    },
                    [2] = 
                    {
                        ["price"] = 168,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633028910,
                        ["quant"] = 1,
                        ["id"] = "1690436737",
                        ["itemLink"] = 700,
                    },
                    [3] = 
                    {
                        ["price"] = 199,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1633028925,
                        ["quant"] = 1,
                        ["id"] = "1690436797",
                        ["itemLink"] = 705,
                    },
                    [4] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633084073,
                        ["quant"] = 1,
                        ["id"] = "1690854853",
                        ["itemLink"] = 1172,
                    },
                    [5] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633084107,
                        ["quant"] = 1,
                        ["id"] = "1690855055",
                        ["itemLink"] = 477,
                    },
                    [6] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633084108,
                        ["quant"] = 1,
                        ["id"] = "1690855059",
                        ["itemLink"] = 477,
                    },
                    [7] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633135865,
                        ["quant"] = 1,
                        ["id"] = "1691251987",
                        ["itemLink"] = 1566,
                    },
                    [8] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633146938,
                        ["quant"] = 1,
                        ["id"] = "1691365369",
                        ["itemLink"] = 1670,
                    },
                    [9] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632826518,
                        ["quant"] = 1,
                        ["id"] = "1688972311",
                        ["itemLink"] = 3057,
                    },
                    [10] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1632826519,
                        ["quant"] = 1,
                        ["id"] = "1688972321",
                        ["itemLink"] = 477,
                    },
                    [11] = 
                    {
                        ["price"] = 160,
                        ["guild"] = 1,
                        ["buyer"] = 2141,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1632831877,
                        ["quant"] = 1,
                        ["id"] = "1689009963",
                        ["itemLink"] = 3090,
                    },
                    [12] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632843170,
                        ["quant"] = 1,
                        ["id"] = "1689085133",
                        ["itemLink"] = 477,
                    },
                    [13] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632843171,
                        ["quant"] = 1,
                        ["id"] = "1689085143",
                        ["itemLink"] = 1670,
                    },
                    [14] = 
                    {
                        ["price"] = 275,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632843176,
                        ["quant"] = 1,
                        ["id"] = "1689085193",
                        ["itemLink"] = 3090,
                    },
                    [15] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1632843181,
                        ["quant"] = 1,
                        ["id"] = "1689085249",
                        ["itemLink"] = 700,
                    },
                    [16] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632843192,
                        ["quant"] = 1,
                        ["id"] = "1689085331",
                        ["itemLink"] = 700,
                    },
                    [17] = 
                    {
                        ["price"] = 237,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1632885660,
                        ["quant"] = 1,
                        ["id"] = "1689459633",
                        ["itemLink"] = 1172,
                    },
                    [18] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1632885660,
                        ["quant"] = 1,
                        ["id"] = "1689459639",
                        ["itemLink"] = 705,
                    },
                    [19] = 
                    {
                        ["price"] = 268,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 240,
                        ["timestamp"] = 1632885662,
                        ["quant"] = 1,
                        ["id"] = "1689459651",
                        ["itemLink"] = 477,
                    },
                    [20] = 
                    {
                        ["price"] = 265,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632956406,
                        ["quant"] = 1,
                        ["id"] = "1689931671",
                        ["itemLink"] = 3893,
                    },
                    [21] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632956417,
                        ["quant"] = 1,
                        ["id"] = "1689931805",
                        ["itemLink"] = 3899,
                    },
                },
                ["totalCount"] = 21,
                ["itemAdderText"] = "cp160 white normal apparel weapon shield off hand intricate",
            },
            ["1:0:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_shield_a.dds",
                ["itemDesc"] = "Maple Shield",
                ["oldestTime"] = 1632843168,
                ["wasAltered"] = true,
                ["newestTime"] = 1633268078,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 256,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1633009345,
                        ["quant"] = 1,
                        ["id"] = "1690285209",
                        ["itemLink"] = 458,
                    },
                    [2] = 
                    {
                        ["price"] = 120,
                        ["guild"] = 1,
                        ["buyer"] = 850,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633072300,
                        ["quant"] = 1,
                        ["id"] = "1690793375",
                        ["itemLink"] = 458,
                    },
                    [3] = 
                    {
                        ["price"] = 120,
                        ["guild"] = 1,
                        ["buyer"] = 1001,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633268078,
                        ["quant"] = 1,
                        ["id"] = "1692385967",
                        ["itemLink"] = 458,
                    },
                    [4] = 
                    {
                        ["price"] = 120,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632843168,
                        ["quant"] = 1,
                        ["id"] = "1689085121",
                        ["itemLink"] = 458,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 white normal apparel weapon shield off hand intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_shield_d.dds",
                ["itemDesc"] = "Ruby Ash Shield",
                ["oldestTime"] = 1632826513,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185965,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009364,
                        ["quant"] = 1,
                        ["id"] = "1690285427",
                        ["itemLink"] = 478,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084681,
                        ["quant"] = 1,
                        ["id"] = "1690857345",
                        ["itemLink"] = 1207,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633135866,
                        ["quant"] = 1,
                        ["id"] = "1691251993",
                        ["itemLink"] = 478,
                    },
                    [4] = 
                    {
                        ["price"] = 199,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1633185965,
                        ["quant"] = 1,
                        ["id"] = "1691640383",
                        ["itemLink"] = 1207,
                    },
                    [5] = 
                    {
                        ["price"] = 199,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632826513,
                        ["quant"] = 1,
                        ["id"] = "1688972271",
                        ["itemLink"] = 1207,
                    },
                    [6] = 
                    {
                        ["price"] = 235,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632843172,
                        ["quant"] = 1,
                        ["id"] = "1689085151",
                        ["itemLink"] = 3174,
                    },
                    [7] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632843174,
                        ["quant"] = 1,
                        ["id"] = "1689085175",
                        ["itemLink"] = 3175,
                    },
                    [8] = 
                    {
                        ["price"] = 338,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632843178,
                        ["quant"] = 1,
                        ["id"] = "1689085219",
                        ["itemLink"] = 3176,
                    },
                    [9] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632843195,
                        ["quant"] = 1,
                        ["id"] = "1689085351",
                        ["itemLink"] = 3174,
                    },
                    [10] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632843199,
                        ["quant"] = 1,
                        ["id"] = "1689085359",
                        ["itemLink"] = 1207,
                    },
                    [11] = 
                    {
                        ["price"] = 265,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632885661,
                        ["quant"] = 1,
                        ["id"] = "1689459643",
                        ["itemLink"] = 3514,
                    },
                    [12] = 
                    {
                        ["price"] = 265,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632956408,
                        ["quant"] = 1,
                        ["id"] = "1689931683",
                        ["itemLink"] = 3514,
                    },
                    [13] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632956410,
                        ["quant"] = 1,
                        ["id"] = "1689931707",
                        ["itemLink"] = 478,
                    },
                    [14] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632956417,
                        ["quant"] = 1,
                        ["id"] = "1689931809",
                        ["itemLink"] = 3900,
                    },
                    [15] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632956418,
                        ["quant"] = 1,
                        ["id"] = "1689931817",
                        ["itemLink"] = 478,
                    },
                },
                ["totalCount"] = 15,
                ["itemAdderText"] = "cp150 white normal apparel weapon shield off hand intricate",
            },
        },
        [117813] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_inc_varvase002.dds",
                ["itemDesc"] = "Redguard Vase, Baroque",
                ["oldestTime"] = 1633239679,
                ["wasAltered"] = true,
                ["newestTime"] = 1633239679,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13200,
                        ["guild"] = 1,
                        ["buyer"] = 1762,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633239679,
                        ["quant"] = 1,
                        ["id"] = "1692194953",
                        ["itemLink"] = 2523,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings parlor",
            },
        },
        [86840] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_d.dds",
                ["itemDesc"] = "Restoration Staff of Necropotence",
                ["oldestTime"] = 1633212189,
                ["wasAltered"] = true,
                ["newestTime"] = 1633212189,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1558,
                        ["wasKiosk"] = true,
                        ["seller"] = 377,
                        ["timestamp"] = 1633212189,
                        ["quant"] = 1,
                        ["id"] = "1691931373",
                        ["itemLink"] = 2285,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set necropotence healing staff two-handed sharpened",
            },
        },
        [23100] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_leather_base_topgrain_r3.dds",
                ["itemDesc"] = "Thick Leather",
                ["oldestTime"] = 1632769477,
                ["wasAltered"] = true,
                ["newestTime"] = 1633240450,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 975,
                        ["guild"] = 2,
                        ["buyer"] = 124,
                        ["wasKiosk"] = false,
                        ["seller"] = 125,
                        ["timestamp"] = 1632769477,
                        ["quant"] = 100,
                        ["id"] = "1688524905",
                        ["itemLink"] = 120,
                    },
                    [2] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1711,
                        ["wasKiosk"] = true,
                        ["seller"] = 803,
                        ["timestamp"] = 1633232958,
                        ["quant"] = 100,
                        ["id"] = "1692144515",
                        ["itemLink"] = 120,
                    },
                    [3] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1772,
                        ["wasKiosk"] = true,
                        ["seller"] = 1773,
                        ["timestamp"] = 1633240450,
                        ["quant"] = 200,
                        ["id"] = "1692201251",
                        ["itemLink"] = 120,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [172093] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_legs_a.dds",
                ["itemDesc"] = "Breeches of Frostbite",
                ["oldestTime"] = 1633190645,
                ["wasAltered"] = true,
                ["newestTime"] = 1633190645,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 1417,
                        ["timestamp"] = 1633190645,
                        ["quant"] = 1,
                        ["id"] = "1691695215",
                        ["itemLink"] = 2105,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set frostbite legs sturdy",
            },
        },
        [172350] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_1hsword_a.dds",
                ["itemDesc"] = "Bog Raider's Sword",
                ["oldestTime"] = 1633076447,
                ["wasAltered"] = true,
                ["newestTime"] = 1633076447,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2190,
                        ["guild"] = 1,
                        ["buyer"] = 869,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633076447,
                        ["quant"] = 1,
                        ["id"] = "1690819253",
                        ["itemLink"] = 1114,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set bog raider sword one-handed defending",
            },
        },
        [45890] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Steamed Radishes",
                ["oldestTime"] = 1633214824,
                ["wasAltered"] = true,
                ["newestTime"] = 1633214824,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45,
                        ["guild"] = 1,
                        ["buyer"] = 1578,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1633214824,
                        ["quant"] = 1,
                        ["id"] = "1691957373",
                        ["itemLink"] = 2304,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [23107] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_ore_base_iron_r3.dds",
                ["itemDesc"] = "Orichalcum Ingot",
                ["oldestTime"] = 1632714076,
                ["wasAltered"] = true,
                ["newestTime"] = 1632714076,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 2,
                        ["buyer"] = 129,
                        ["wasKiosk"] = false,
                        ["seller"] = 125,
                        ["timestamp"] = 1632714076,
                        ["quant"] = 200,
                        ["id"] = "1688085761",
                        ["itemLink"] = 106,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [180548] = 
        {
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_light_feet_a.dds",
                ["itemDesc"] = "Shoes of Dark Convergence",
                ["oldestTime"] = 1633100501,
                ["wasAltered"] = true,
                ["newestTime"] = 1633100501,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4444,
                        ["guild"] = 1,
                        ["buyer"] = 946,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633100501,
                        ["quant"] = 1,
                        ["id"] = "1690960993",
                        ["itemLink"] = 1283,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set dark convergence feet invigorating",
            },
        },
        [68678] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_heavy_legs_a.dds",
                ["itemDesc"] = "Greaves of the Pariah",
                ["oldestTime"] = 1633027474,
                ["wasAltered"] = true,
                ["newestTime"] = 1633027474,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 334,
                        ["wasKiosk"] = false,
                        ["seller"] = 274,
                        ["timestamp"] = 1633027474,
                        ["quant"] = 1,
                        ["id"] = "1690423543",
                        ["itemLink"] = 686,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set mark of the pariah legs reinforced",
            },
        },
        [171592] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 99: Waking Flame Shoulders",
                ["oldestTime"] = 1633292536,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292536,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 69000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 505,
                        ["timestamp"] = 1633292536,
                        ["quant"] = 1,
                        ["id"] = "1692657981",
                        ["itemLink"] = 2838,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [134985] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting5.dds",
                ["itemDesc"] = "Praxis: Hlaalu Trinket Box, Curious Turtle",
                ["oldestTime"] = 1633292271,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292271,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 85000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 528,
                        ["timestamp"] = 1633292271,
                        ["quant"] = 1,
                        ["id"] = "1692654689",
                        ["itemLink"] = 2816,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable recipe",
            },
        },
        [175946] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Table, Sturdy Round",
                ["oldestTime"] = 1633185717,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185717,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1393,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633185717,
                        ["quant"] = 1,
                        ["id"] = "1691637373",
                        ["itemLink"] = 1991,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [139595] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Alinor Amphora, Delicate",
                ["oldestTime"] = 1633250014,
                ["wasAltered"] = true,
                ["newestTime"] = 1633250014,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1817,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633250014,
                        ["quant"] = 1,
                        ["id"] = "1692270441",
                        ["itemLink"] = 2596,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [121165] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing5.dds",
                ["itemDesc"] = "Diagram: Apparatus, Gem Calipers",
                ["oldestTime"] = 1632995522,
                ["wasAltered"] = true,
                ["newestTime"] = 1632995522,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 63100,
                        ["guild"] = 1,
                        ["buyer"] = 380,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1632995522,
                        ["quant"] = 1,
                        ["id"] = "1690211759",
                        ["itemLink"] = 378,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable recipe",
            },
        },
        [45647] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Hearthfire Vegetable Salad",
                ["oldestTime"] = 1633060727,
                ["wasAltered"] = true,
                ["newestTime"] = 1633060727,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633060727,
                        ["quant"] = 1,
                        ["id"] = "1690716429",
                        ["itemLink"] = 1018,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [149072] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_shield_a.dds",
                ["itemDesc"] = "Undertaker's Shield",
                ["oldestTime"] = 1633072388,
                ["wasAltered"] = true,
                ["newestTime"] = 1633072388,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 144,
                        ["guild"] = 1,
                        ["buyer"] = 851,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633072388,
                        ["quant"] = 1,
                        ["id"] = "1690793903",
                        ["itemLink"] = 1100,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine apparel weapon set call of the undertaker shield off hand infused",
            },
        },
        [87889] = 
        {
            ["50:16:4:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_staff_a.dds",
                ["itemDesc"] = "Deadly Inferno Staff",
                ["oldestTime"] = 1633228069,
                ["wasAltered"] = true,
                ["newestTime"] = 1633228069,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100000,
                        ["guild"] = 1,
                        ["buyer"] = 1656,
                        ["wasKiosk"] = true,
                        ["seller"] = 38,
                        ["timestamp"] = 1633228069,
                        ["quant"] = 1,
                        ["id"] = "1692097811",
                        ["itemLink"] = 2419,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set deadly strike flame staff two-handed powered",
            },
        },
        [172114] = 
        {
            ["50:16:2:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_legs_a.dds",
                ["itemDesc"] = "Breeches of Frostbite",
                ["oldestTime"] = 1633055531,
                ["wasAltered"] = true,
                ["newestTime"] = 1633055531,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 345,
                        ["guild"] = 1,
                        ["buyer"] = 749,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633055531,
                        ["quant"] = 1,
                        ["id"] = "1690660011",
                        ["itemLink"] = 947,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite legs training",
            },
        },
        [172372] = 
        {
            ["50:16:3:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_2hhammer_a.dds",
                ["itemDesc"] = "Bog Raider's Maul",
                ["oldestTime"] = 1633273200,
                ["wasAltered"] = true,
                ["newestTime"] = 1633273200,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 484,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633273200,
                        ["quant"] = 1,
                        ["id"] = "1692439563",
                        ["itemLink"] = 2682,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set bog raider mace two-handed sharpened",
            },
        },
        [175957] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Bench, Sturdy",
                ["oldestTime"] = 1632520231,
                ["wasAltered"] = true,
                ["newestTime"] = 1633290962,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 850,
                        ["guild"] = 2,
                        ["buyer"] = 114,
                        ["wasKiosk"] = false,
                        ["seller"] = 117,
                        ["timestamp"] = 1632520231,
                        ["quant"] = 1,
                        ["id"] = "1686355353",
                        ["itemLink"] = 94,
                    },
                    [2] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1393,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633185725,
                        ["quant"] = 1,
                        ["id"] = "1691637425",
                        ["itemLink"] = 94,
                    },
                    [3] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 31,
                        ["wasKiosk"] = false,
                        ["seller"] = 182,
                        ["timestamp"] = 1633200586,
                        ["quant"] = 1,
                        ["id"] = "1691795725",
                        ["itemLink"] = 94,
                    },
                    [4] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 353,
                        ["timestamp"] = 1633290962,
                        ["quant"] = 1,
                        ["id"] = "1692637867",
                        ["itemLink"] = 94,
                    },
                    [5] = 
                    {
                        ["price"] = 1009,
                        ["guild"] = 1,
                        ["buyer"] = 2618,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632957874,
                        ["quant"] = 1,
                        ["id"] = "1689942211",
                        ["itemLink"] = 94,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [117853] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_inc_glassbottle003.dds",
                ["itemDesc"] = "Redguard Vial, Stained Glass",
                ["oldestTime"] = 1633294737,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294737,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9098,
                        ["guild"] = 1,
                        ["buyer"] = 2011,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1633294737,
                        ["quant"] = 1,
                        ["id"] = "1692686977",
                        ["itemLink"] = 2871,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings hearth",
            },
        },
        [180831] = 
        {
            ["50:16:4:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_2hhammer_a.dds",
                ["itemDesc"] = "Hrothgar's Maul",
                ["oldestTime"] = 1633112527,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112527,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 89000,
                        ["guild"] = 1,
                        ["buyer"] = 991,
                        ["wasKiosk"] = true,
                        ["seller"] = 438,
                        ["timestamp"] = 1633112527,
                        ["quant"] = 1,
                        ["id"] = "1691055691",
                        ["itemLink"] = 1356,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set hrothgar's chill mace two-handed defending",
            },
        },
        [151649] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_exc_housingmerchantspices001.dds",
                ["itemDesc"] = "Elsweyr Spice Display, Turmeric Yellow",
                ["oldestTime"] = 1633165818,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165818,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 17,
                        ["timestamp"] = 1633165818,
                        ["quant"] = 1,
                        ["id"] = "1691499685",
                        ["itemLink"] = 1844,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings hearth",
            },
        },
        [68194] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Tomato Garlic Chutney",
                ["oldestTime"] = 1633070282,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261582,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20,
                        ["guild"] = 1,
                        ["buyer"] = 839,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633070282,
                        ["quant"] = 1,
                        ["id"] = "1690779037",
                        ["itemLink"] = 1082,
                    },
                    [2] = 
                    {
                        ["price"] = 27,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 442,
                        ["timestamp"] = 1633261582,
                        ["quant"] = 1,
                        ["id"] = "1692334299",
                        ["itemLink"] = 1082,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [151908] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_auroran_dust.dds",
                ["itemDesc"] = "Auroran Dust",
                ["oldestTime"] = 1633211174,
                ["wasAltered"] = true,
                ["newestTime"] = 1633211174,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 23600,
                        ["guild"] = 1,
                        ["buyer"] = 508,
                        ["wasKiosk"] = false,
                        ["seller"] = 957,
                        ["timestamp"] = 1633211174,
                        ["quant"] = 59,
                        ["id"] = "1691917219",
                        ["itemLink"] = 2281,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [172135] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_shield_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Shield",
                ["oldestTime"] = 1633305696,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305696,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633305696,
                        ["quant"] = 1,
                        ["id"] = "1692797521",
                        ["itemLink"] = 2933,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior apparel weapon set deadlands assassin shield off hand infused",
            },
        },
        [172392] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_2hhammer_a.dds",
                ["itemDesc"] = "Bog Raider's Maul",
                ["oldestTime"] = 1633042325,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200616,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2700,
                        ["guild"] = 1,
                        ["buyer"] = 650,
                        ["wasKiosk"] = true,
                        ["seller"] = 281,
                        ["timestamp"] = 1633042325,
                        ["quant"] = 1,
                        ["id"] = "1690531219",
                        ["itemLink"] = 827,
                    },
                    [2] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1490,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633200616,
                        ["quant"] = 1,
                        ["id"] = "1691796099",
                        ["itemLink"] = 827,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior weapon set bog raider mace two-handed charged",
            },
            ["50:16:4:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_2hhammer_a.dds",
                ["itemDesc"] = "Bog Raider's Maul",
                ["oldestTime"] = 1632884781,
                ["wasAltered"] = true,
                ["newestTime"] = 1632884781,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 2384,
                        ["wasKiosk"] = true,
                        ["seller"] = 1201,
                        ["timestamp"] = 1632884781,
                        ["quant"] = 1,
                        ["id"] = "1689449317",
                        ["itemLink"] = 3500,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set bog raider mace two-handed charged",
            },
        },
        [134762] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 58: Fang Lair Gloves",
                ["oldestTime"] = 1633005391,
                ["wasAltered"] = true,
                ["newestTime"] = 1633005391,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9457,
                        ["guild"] = 1,
                        ["buyer"] = 418,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633005391,
                        ["quant"] = 1,
                        ["id"] = "1690262015",
                        ["itemLink"] = 428,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [82028] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 42: Hollowjack Daggers",
                ["oldestTime"] = 1633207978,
                ["wasAltered"] = true,
                ["newestTime"] = 1633314378,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 68,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1633314378,
                        ["quant"] = 1,
                        ["id"] = "1692894239",
                        ["itemLink"] = 52,
                    },
                    [2] = 
                    {
                        ["price"] = 13900,
                        ["guild"] = 1,
                        ["buyer"] = 1539,
                        ["wasKiosk"] = true,
                        ["seller"] = 611,
                        ["timestamp"] = 1633207978,
                        ["quant"] = 1,
                        ["id"] = "1691881873",
                        ["itemLink"] = 52,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [97135] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_shoulders_d.dds",
                ["itemDesc"] = "Plague Doctor's Pauldron",
                ["oldestTime"] = 1632942616,
                ["wasAltered"] = true,
                ["newestTime"] = 1632942616,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 2556,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1632942616,
                        ["quant"] = 1,
                        ["id"] = "1689814671",
                        ["itemLink"] = 3778,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set plague doctor shoulders impenetrable",
            },
        },
        [6000] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_smith_plug_standard_r_001.dds",
                ["itemDesc"] = "Dwarven Ingot",
                ["oldestTime"] = 1632865505,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865509,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 756,
                        ["guild"] = 1,
                        ["buyer"] = 2265,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632865505,
                        ["quant"] = 126,
                        ["id"] = "1689268739",
                        ["itemLink"] = 3336,
                    },
                    [2] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 2265,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632865509,
                        ["quant"] = 200,
                        ["id"] = "1689268753",
                        ["itemLink"] = 3336,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [45937] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Green Salad",
                ["oldestTime"] = 1633052866,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052866,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633052866,
                        ["quant"] = 1,
                        ["id"] = "1690633917",
                        ["itemLink"] = 922,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [119155] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Redguard Curtain, Desert Rose",
                ["oldestTime"] = 1633242861,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242861,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1331,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633242861,
                        ["quant"] = 1,
                        ["id"] = "1692217451",
                        ["itemLink"] = 2554,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [176500] = 
        {
            ["1:0:4:37:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_dagger.dds",
                ["itemDesc"] = "Companion's Dagger",
                ["oldestTime"] = 1633291029,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291029,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633291029,
                        ["quant"] = 1,
                        ["id"] = "1692638373",
                        ["itemLink"] = 2790,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic weapon dagger one-handed shattering",
            },
        },
        [43637] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Greenshade Treasure Map I",
                ["oldestTime"] = 1633131965,
                ["wasAltered"] = true,
                ["newestTime"] = 1633131965,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1117,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633131965,
                        ["quant"] = 1,
                        ["id"] = "1691207753",
                        ["itemLink"] = 1540,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [172156] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_chest_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Jack",
                ["oldestTime"] = 1633041779,
                ["wasAltered"] = true,
                ["newestTime"] = 1633041779,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 641,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633041779,
                        ["quant"] = 1,
                        ["id"] = "1690527099",
                        ["itemLink"] = 807,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set deadlands assassin chest divines",
            },
        },
        [147326] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Abnur Tharn's Breeches",
                ["oldestTime"] = 1633274180,
                ["wasAltered"] = true,
                ["newestTime"] = 1633274180,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1334,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633274180,
                        ["quant"] = 1,
                        ["id"] = "1692453091",
                        ["itemLink"] = 2692,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [180610] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_staff_a.dds",
                ["itemDesc"] = "Plaguebreak Inferno Staff",
                ["oldestTime"] = 1633235705,
                ["wasAltered"] = true,
                ["newestTime"] = 1633235705,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3434,
                        ["guild"] = 1,
                        ["buyer"] = 1731,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633235705,
                        ["quant"] = 1,
                        ["id"] = "1692165951",
                        ["itemLink"] = 2485,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set plaguebreak flame staff two-handed infused",
            },
        },
        [43651] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Reaper's March Treasure Map III",
                ["oldestTime"] = 1633083003,
                ["wasAltered"] = true,
                ["newestTime"] = 1633083003,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 464,
                        ["guild"] = 1,
                        ["buyer"] = 888,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633083003,
                        ["quant"] = 1,
                        ["id"] = "1690850307",
                        ["itemLink"] = 1138,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [87688] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/event_halloween_2016_spooky_recipe.dds",
                ["itemDesc"] = "Recipe: Witchmother's Party Punch",
                ["oldestTime"] = 1632961364,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297009,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 348,
                        ["wasKiosk"] = false,
                        ["seller"] = 201,
                        ["timestamp"] = 1633297009,
                        ["quant"] = 1,
                        ["id"] = "1692711009",
                        ["itemLink"] = 2886,
                    },
                    [2] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2629,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632961364,
                        ["quant"] = 1,
                        ["id"] = "1689970471",
                        ["itemLink"] = 2886,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [71563] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 22: Trinimac Staves",
                ["oldestTime"] = 1632934358,
                ["wasAltered"] = true,
                ["newestTime"] = 1633199476,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1477,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633199476,
                        ["quant"] = 1,
                        ["id"] = "1691783779",
                        ["itemLink"] = 2177,
                    },
                    [2] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 2524,
                        ["wasKiosk"] = true,
                        ["seller"] = 170,
                        ["timestamp"] = 1632934358,
                        ["quant"] = 1,
                        ["id"] = "1689754817",
                        ["itemLink"] = 2177,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [140430] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 64: Pyandonean Belts",
                ["oldestTime"] = 1633140367,
                ["wasAltered"] = true,
                ["newestTime"] = 1633140367,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 36,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633140367,
                        ["quant"] = 1,
                        ["id"] = "1691294617",
                        ["itemLink"] = 1597,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [172175] = 
        {
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_shield_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Shield",
                ["oldestTime"] = 1633166691,
                ["wasAltered"] = true,
                ["newestTime"] = 1633166691,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 599,
                        ["guild"] = 1,
                        ["buyer"] = 889,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633166691,
                        ["quant"] = 1,
                        ["id"] = "1691503537",
                        ["itemLink"] = 1865,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine apparel weapon set deadlands assassin shield off hand well-fitted",
            },
        },
        [116113] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Khajiit Banner, Hooked",
                ["oldestTime"] = 1633040325,
                ["wasAltered"] = true,
                ["newestTime"] = 1633040325,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 623,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633040325,
                        ["quant"] = 1,
                        ["id"] = "1690515717",
                        ["itemLink"] = 793,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [171925] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 102: Sul-Xan Staves",
                ["oldestTime"] = 1633101581,
                ["wasAltered"] = true,
                ["newestTime"] = 1633276052,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 239999,
                        ["guild"] = 1,
                        ["buyer"] = 950,
                        ["wasKiosk"] = true,
                        ["seller"] = 951,
                        ["timestamp"] = 1633101581,
                        ["quant"] = 1,
                        ["id"] = "1690969351",
                        ["itemLink"] = 1286,
                    },
                    [2] = 
                    {
                        ["price"] = 140000,
                        ["guild"] = 1,
                        ["buyer"] = 550,
                        ["wasKiosk"] = false,
                        ["seller"] = 1450,
                        ["timestamp"] = 1633276052,
                        ["quant"] = 1,
                        ["id"] = "1692476375",
                        ["itemLink"] = 1286,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [139414] = 
        {
            ["1:0:1:31:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_enchantment_baxe_bloodstone_r1.dds",
                ["itemDesc"] = "Slaughterstone",
                ["oldestTime"] = 1632912740,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311113,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 23034,
                        ["guild"] = 1,
                        ["buyer"] = 308,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1632984360,
                        ["quant"] = 3,
                        ["id"] = "1690155889",
                        ["itemLink"] = 311,
                    },
                    [2] = 
                    {
                        ["price"] = 7399,
                        ["guild"] = 1,
                        ["buyer"] = 401,
                        ["wasKiosk"] = true,
                        ["seller"] = 402,
                        ["timestamp"] = 1633001192,
                        ["quant"] = 1,
                        ["id"] = "1690240263",
                        ["itemLink"] = 311,
                    },
                    [3] = 
                    {
                        ["price"] = 7399,
                        ["guild"] = 1,
                        ["buyer"] = 401,
                        ["wasKiosk"] = true,
                        ["seller"] = 402,
                        ["timestamp"] = 1633001215,
                        ["quant"] = 1,
                        ["id"] = "1690240345",
                        ["itemLink"] = 311,
                    },
                    [4] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 665,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633044810,
                        ["quant"] = 1,
                        ["id"] = "1690554555",
                        ["itemLink"] = 311,
                    },
                    [5] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 665,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633044811,
                        ["quant"] = 1,
                        ["id"] = "1690554565",
                        ["itemLink"] = 311,
                    },
                    [6] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 665,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633044812,
                        ["quant"] = 1,
                        ["id"] = "1690554571",
                        ["itemLink"] = 311,
                    },
                    [7] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 988,
                        ["wasKiosk"] = true,
                        ["seller"] = 732,
                        ["timestamp"] = 1633111927,
                        ["quant"] = 2,
                        ["id"] = "1691051491",
                        ["itemLink"] = 311,
                    },
                    [8] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 988,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633112020,
                        ["quant"] = 1,
                        ["id"] = "1691052373",
                        ["itemLink"] = 311,
                    },
                    [9] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1160,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633138393,
                        ["quant"] = 1,
                        ["id"] = "1691276357",
                        ["itemLink"] = 311,
                    },
                    [10] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1168,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633138494,
                        ["quant"] = 1,
                        ["id"] = "1691277467",
                        ["itemLink"] = 311,
                    },
                    [11] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 689,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633142806,
                        ["quant"] = 1,
                        ["id"] = "1691322989",
                        ["itemLink"] = 311,
                    },
                    [12] = 
                    {
                        ["price"] = 7200,
                        ["guild"] = 1,
                        ["buyer"] = 689,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633142808,
                        ["quant"] = 1,
                        ["id"] = "1691323011",
                        ["itemLink"] = 311,
                    },
                    [13] = 
                    {
                        ["price"] = 7300,
                        ["guild"] = 1,
                        ["buyer"] = 1830,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633259692,
                        ["quant"] = 1,
                        ["id"] = "1692323579",
                        ["itemLink"] = 311,
                    },
                    [14] = 
                    {
                        ["price"] = 7300,
                        ["guild"] = 1,
                        ["buyer"] = 1,
                        ["wasKiosk"] = false,
                        ["seller"] = 647,
                        ["timestamp"] = 1633311110,
                        ["quant"] = 1,
                        ["id"] = "1692861401",
                        ["itemLink"] = 311,
                    },
                    [15] = 
                    {
                        ["price"] = 7399,
                        ["guild"] = 1,
                        ["buyer"] = 1,
                        ["wasKiosk"] = false,
                        ["seller"] = 402,
                        ["timestamp"] = 1633311111,
                        ["quant"] = 1,
                        ["id"] = "1692861411",
                        ["itemLink"] = 311,
                    },
                    [16] = 
                    {
                        ["price"] = 22854,
                        ["guild"] = 1,
                        ["buyer"] = 1,
                        ["wasKiosk"] = false,
                        ["seller"] = 9,
                        ["timestamp"] = 1633311112,
                        ["quant"] = 3,
                        ["id"] = "1692861427",
                        ["itemLink"] = 311,
                    },
                    [17] = 
                    {
                        ["price"] = 15990,
                        ["guild"] = 1,
                        ["buyer"] = 1,
                        ["wasKiosk"] = false,
                        ["seller"] = 9,
                        ["timestamp"] = 1633311113,
                        ["quant"] = 2,
                        ["id"] = "1692861437",
                        ["itemLink"] = 311,
                    },
                    [18] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 171,
                        ["timestamp"] = 1632912740,
                        ["quant"] = 10,
                        ["id"] = "1689611211",
                        ["itemLink"] = 311,
                    },
                    [19] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 171,
                        ["timestamp"] = 1632912741,
                        ["quant"] = 10,
                        ["id"] = "1689611213",
                        ["itemLink"] = 311,
                    },
                },
                ["totalCount"] = 19,
                ["itemAdderText"] = "rr01 white normal materials jewelry trait bloodthirsty",
            },
        },
        [99735] = 
        {
            ["50:16:2:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_1hsword_d.dds",
                ["itemDesc"] = "Spinner's Sword",
                ["oldestTime"] = 1633033230,
                ["wasAltered"] = true,
                ["newestTime"] = 1633033230,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 225000,
                        ["guild"] = 1,
                        ["buyer"] = 576,
                        ["wasKiosk"] = true,
                        ["seller"] = 577,
                        ["timestamp"] = 1633033230,
                        ["quant"] = 1,
                        ["id"] = "1690465311",
                        ["itemLink"] = 749,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set spinner's garments sword one-handed sharpened",
            },
        },
        [167576] = 
        {
            ["50:16:4:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_arkthzand_2hhammer_a.dds",
                ["itemDesc"] = "Maul of the Radiant Bastion",
                ["oldestTime"] = 1632857756,
                ["wasAltered"] = true,
                ["newestTime"] = 1632857756,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1632857756,
                        ["quant"] = 1,
                        ["id"] = "1689211875",
                        ["itemLink"] = 3284,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set radiant bastion mace two-handed training",
            },
        },
        [27037] = 
        {
            ["50:15:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/consumable_potion_002_type_005.dds",
                ["itemDesc"] = "Essence of Magicka",
                ["oldestTime"] = 1632877348,
                ["wasAltered"] = true,
                ["newestTime"] = 1633231689,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 256,
                        ["wasKiosk"] = false,
                        ["seller"] = 257,
                        ["timestamp"] = 1632979988,
                        ["quant"] = 46,
                        ["id"] = "1690130817",
                        ["itemLink"] = 264,
                    },
                    [2] = 
                    {
                        ["price"] = 1399,
                        ["guild"] = 1,
                        ["buyer"] = 877,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633078537,
                        ["quant"] = 100,
                        ["id"] = "1690829017",
                        ["itemLink"] = 264,
                    },
                    [3] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1696,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633231687,
                        ["quant"] = 20,
                        ["id"] = "1692132315",
                        ["itemLink"] = 264,
                    },
                    [4] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1696,
                        ["wasKiosk"] = true,
                        ["seller"] = 256,
                        ["timestamp"] = 1633231689,
                        ["quant"] = 100,
                        ["id"] = "1692132337",
                        ["itemLink"] = 264,
                    },
                    [5] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 2335,
                        ["wasKiosk"] = true,
                        ["seller"] = 474,
                        ["timestamp"] = 1632877348,
                        ["quant"] = 100,
                        ["id"] = "1689365213",
                        ["itemLink"] = 264,
                    },
                    [6] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 505,
                        ["wasKiosk"] = false,
                        ["seller"] = 2372,
                        ["timestamp"] = 1632883229,
                        ["quant"] = 100,
                        ["id"] = "1689429729",
                        ["itemLink"] = 264,
                    },
                    [7] = 
                    {
                        ["price"] = 1245,
                        ["guild"] = 1,
                        ["buyer"] = 1789,
                        ["wasKiosk"] = true,
                        ["seller"] = 2372,
                        ["timestamp"] = 1632925945,
                        ["quant"] = 83,
                        ["id"] = "1689693535",
                        ["itemLink"] = 264,
                    },
                    [8] = 
                    {
                        ["price"] = 1080,
                        ["guild"] = 1,
                        ["buyer"] = 1789,
                        ["wasKiosk"] = true,
                        ["seller"] = 2372,
                        ["timestamp"] = 1632925946,
                        ["quant"] = 72,
                        ["id"] = "1689693545",
                        ["itemLink"] = 264,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "cp150 white normal consumable potion",
            },
        },
        [27038] = 
        {
            ["50:15:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/consumable_potion_003_type_005.dds",
                ["itemDesc"] = "Essence of Stamina",
                ["oldestTime"] = 1632965904,
                ["wasAltered"] = true,
                ["newestTime"] = 1632965904,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 698,
                        ["guild"] = 1,
                        ["buyer"] = 2657,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1632965904,
                        ["quant"] = 100,
                        ["id"] = "1690014415",
                        ["itemLink"] = 3958,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 white normal consumable potion",
            },
        },
        [71072] = 
        {
            ["50:15:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/consumable_potion_009_type_003.dds",
                ["itemDesc"] = "Alliance Spell Draught",
                ["oldestTime"] = 1632870915,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311697,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 18,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1633311668,
                        ["quant"] = 200,
                        ["id"] = "1692866705",
                        ["itemLink"] = 12,
                    },
                    [2] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 18,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1633311671,
                        ["quant"] = 200,
                        ["id"] = "1692866727",
                        ["itemLink"] = 12,
                    },
                    [3] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 18,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1633311674,
                        ["quant"] = 200,
                        ["id"] = "1692866737",
                        ["itemLink"] = 12,
                    },
                    [4] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 18,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1633311675,
                        ["quant"] = 200,
                        ["id"] = "1692866741",
                        ["itemLink"] = 12,
                    },
                    [5] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 18,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1633311695,
                        ["quant"] = 200,
                        ["id"] = "1692866905",
                        ["itemLink"] = 12,
                    },
                    [6] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 18,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1633311696,
                        ["quant"] = 200,
                        ["id"] = "1692866911",
                        ["itemLink"] = 12,
                    },
                    [7] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 18,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1633311697,
                        ["quant"] = 200,
                        ["id"] = "1692866919",
                        ["itemLink"] = 12,
                    },
                    [8] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2064,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1633305573,
                        ["quant"] = 200,
                        ["id"] = "1692796177",
                        ["itemLink"] = 12,
                    },
                    [9] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2291,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632870915,
                        ["quant"] = 200,
                        ["id"] = "1689309869",
                        ["itemLink"] = 12,
                    },
                    [10] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2291,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632870917,
                        ["quant"] = 200,
                        ["id"] = "1689309903",
                        ["itemLink"] = 12,
                    },
                    [11] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2291,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632870918,
                        ["quant"] = 200,
                        ["id"] = "1689309913",
                        ["itemLink"] = 12,
                    },
                    [12] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2291,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632870919,
                        ["quant"] = 200,
                        ["id"] = "1689309933",
                        ["itemLink"] = 12,
                    },
                    [13] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2291,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632870922,
                        ["quant"] = 200,
                        ["id"] = "1689309953",
                        ["itemLink"] = 12,
                    },
                    [14] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2291,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632870923,
                        ["quant"] = 200,
                        ["id"] = "1689309961",
                        ["itemLink"] = 12,
                    },
                    [15] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2291,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632870924,
                        ["quant"] = 200,
                        ["id"] = "1689309969",
                        ["itemLink"] = 12,
                    },
                    [16] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2291,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632870925,
                        ["quant"] = 200,
                        ["id"] = "1689309977",
                        ["itemLink"] = 12,
                    },
                    [17] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2291,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632870975,
                        ["quant"] = 200,
                        ["id"] = "1689310323",
                        ["itemLink"] = 12,
                    },
                    [18] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2291,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632870976,
                        ["quant"] = 200,
                        ["id"] = "1689310329",
                        ["itemLink"] = 12,
                    },
                    [19] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2291,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632870977,
                        ["quant"] = 200,
                        ["id"] = "1689310335",
                        ["itemLink"] = 12,
                    },
                    [20] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2291,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632870978,
                        ["quant"] = 200,
                        ["id"] = "1689310339",
                        ["itemLink"] = 12,
                    },
                    [21] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2291,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632870979,
                        ["quant"] = 200,
                        ["id"] = "1689310345",
                        ["itemLink"] = 12,
                    },
                    [22] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2291,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632870981,
                        ["quant"] = 200,
                        ["id"] = "1689310359",
                        ["itemLink"] = 12,
                    },
                    [23] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2291,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632870982,
                        ["quant"] = 200,
                        ["id"] = "1689310365",
                        ["itemLink"] = 12,
                    },
                    [24] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2291,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632871003,
                        ["quant"] = 200,
                        ["id"] = "1689310485",
                        ["itemLink"] = 12,
                    },
                    [25] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2291,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632871004,
                        ["quant"] = 200,
                        ["id"] = "1689310495",
                        ["itemLink"] = 12,
                    },
                    [26] = 
                    {
                        ["price"] = 42545,
                        ["guild"] = 1,
                        ["buyer"] = 967,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1632871135,
                        ["quant"] = 127,
                        ["id"] = "1689311221",
                        ["itemLink"] = 12,
                    },
                },
                ["totalCount"] = 26,
                ["itemAdderText"] = "cp150 white normal consumable potion",
            },
            ["10:0:1:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/consumable_potion_009_type_003.dds",
                ["itemDesc"] = "Alliance Spell Draught",
                ["oldestTime"] = 1632871138,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311902,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 27,
                        ["wasKiosk"] = true,
                        ["seller"] = 28,
                        ["timestamp"] = 1633311902,
                        ["quant"] = 200,
                        ["id"] = "1692868549",
                        ["itemLink"] = 18,
                    },
                    [2] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 967,
                        ["wasKiosk"] = true,
                        ["seller"] = 968,
                        ["timestamp"] = 1633105927,
                        ["quant"] = 200,
                        ["id"] = "1691008369",
                        ["itemLink"] = 18,
                    },
                    [3] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 967,
                        ["wasKiosk"] = true,
                        ["seller"] = 968,
                        ["timestamp"] = 1633105928,
                        ["quant"] = 200,
                        ["id"] = "1691008377",
                        ["itemLink"] = 18,
                    },
                    [4] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 967,
                        ["wasKiosk"] = true,
                        ["seller"] = 968,
                        ["timestamp"] = 1633105929,
                        ["quant"] = 200,
                        ["id"] = "1691008385",
                        ["itemLink"] = 18,
                    },
                    [5] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 967,
                        ["wasKiosk"] = true,
                        ["seller"] = 28,
                        ["timestamp"] = 1633105931,
                        ["quant"] = 200,
                        ["id"] = "1691008407",
                        ["itemLink"] = 18,
                    },
                    [6] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1063,
                        ["wasKiosk"] = true,
                        ["seller"] = 28,
                        ["timestamp"] = 1633122255,
                        ["quant"] = 200,
                        ["id"] = "1691121155",
                        ["itemLink"] = 18,
                    },
                    [7] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1063,
                        ["wasKiosk"] = true,
                        ["seller"] = 28,
                        ["timestamp"] = 1633122255,
                        ["quant"] = 200,
                        ["id"] = "1691121167",
                        ["itemLink"] = 18,
                    },
                    [8] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1063,
                        ["wasKiosk"] = true,
                        ["seller"] = 28,
                        ["timestamp"] = 1633122256,
                        ["quant"] = 200,
                        ["id"] = "1691121175",
                        ["itemLink"] = 18,
                    },
                    [9] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 967,
                        ["wasKiosk"] = true,
                        ["seller"] = 28,
                        ["timestamp"] = 1633198950,
                        ["quant"] = 200,
                        ["id"] = "1691778577",
                        ["itemLink"] = 18,
                    },
                    [10] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 967,
                        ["wasKiosk"] = true,
                        ["seller"] = 28,
                        ["timestamp"] = 1633198951,
                        ["quant"] = 200,
                        ["id"] = "1691778589",
                        ["itemLink"] = 18,
                    },
                    [11] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 967,
                        ["wasKiosk"] = true,
                        ["seller"] = 968,
                        ["timestamp"] = 1632871138,
                        ["quant"] = 200,
                        ["id"] = "1689311245",
                        ["itemLink"] = 18,
                    },
                    [12] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 967,
                        ["wasKiosk"] = true,
                        ["seller"] = 968,
                        ["timestamp"] = 1632871139,
                        ["quant"] = 200,
                        ["id"] = "1689311251",
                        ["itemLink"] = 18,
                    },
                    [13] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 967,
                        ["wasKiosk"] = true,
                        ["seller"] = 968,
                        ["timestamp"] = 1632871140,
                        ["quant"] = 200,
                        ["id"] = "1689311259",
                        ["itemLink"] = 18,
                    },
                    [14] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 505,
                        ["wasKiosk"] = false,
                        ["seller"] = 968,
                        ["timestamp"] = 1632883240,
                        ["quant"] = 200,
                        ["id"] = "1689429853",
                        ["itemLink"] = 18,
                    },
                    [15] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 505,
                        ["wasKiosk"] = false,
                        ["seller"] = 968,
                        ["timestamp"] = 1632883241,
                        ["quant"] = 200,
                        ["id"] = "1689429867",
                        ["itemLink"] = 18,
                    },
                },
                ["totalCount"] = 15,
                ["itemAdderText"] = "rr10 white normal consumable potion",
            },
        },
        [54178] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_forester_weapon_vendor_component_002.dds",
                ["itemDesc"] = "Pitch",
                ["oldestTime"] = 1633229205,
                ["wasAltered"] = true,
                ["newestTime"] = 1633229205,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14400,
                        ["guild"] = 1,
                        ["buyer"] = 1676,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633229205,
                        ["quant"] = 200,
                        ["id"] = "1692108513",
                        ["itemLink"] = 2430,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine materials resin",
            },
        },
        [172195] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_shield_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Shield",
                ["oldestTime"] = 1633043223,
                ["wasAltered"] = true,
                ["newestTime"] = 1633043223,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633043223,
                        ["quant"] = 1,
                        ["id"] = "1690539889",
                        ["itemLink"] = 834,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior apparel weapon set deadlands assassin shield off hand reinforced",
            },
        },
        [95742] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_medium_legs_a.dds",
                ["itemDesc"] = "Guards of the Air",
                ["oldestTime"] = 1632965880,
                ["wasAltered"] = true,
                ["newestTime"] = 1632965880,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1632965880,
                        ["quant"] = 1,
                        ["id"] = "1690014181",
                        ["itemLink"] = 3957,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set way of air legs impenetrable",
            },
        },
        [23122] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_wood_base_hickory_r3.dds",
                ["itemDesc"] = "Sanded Hickory",
                ["oldestTime"] = 1632769468,
                ["wasAltered"] = true,
                ["newestTime"] = 1633222988,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 2,
                        ["buyer"] = 124,
                        ["wasKiosk"] = false,
                        ["seller"] = 125,
                        ["timestamp"] = 1632769468,
                        ["quant"] = 100,
                        ["id"] = "1688524843",
                        ["itemLink"] = 116,
                    },
                    [2] = 
                    {
                        ["price"] = 80,
                        ["guild"] = 1,
                        ["buyer"] = 1626,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633222966,
                        ["quant"] = 10,
                        ["id"] = "1692042773",
                        ["itemLink"] = 116,
                    },
                    [3] = 
                    {
                        ["price"] = 1979,
                        ["guild"] = 1,
                        ["buyer"] = 1626,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633222988,
                        ["quant"] = 200,
                        ["id"] = "1692043157",
                        ["itemLink"] = 116,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [141736] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_motif_binding_welkynar.dds",
                ["itemDesc"] = "Welkynar Binding",
                ["oldestTime"] = 1632874330,
                ["wasAltered"] = true,
                ["newestTime"] = 1633136818,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 863,
                        ["guild"] = 1,
                        ["buyer"] = 773,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633058216,
                        ["quant"] = 1,
                        ["id"] = "1690692249",
                        ["itemLink"] = 986,
                    },
                    [2] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 1157,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633136818,
                        ["quant"] = 3,
                        ["id"] = "1691260705",
                        ["itemLink"] = 986,
                    },
                    [3] = 
                    {
                        ["price"] = 2414,
                        ["guild"] = 1,
                        ["buyer"] = 2315,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632874330,
                        ["quant"] = 2,
                        ["id"] = "1689334245",
                        ["itemLink"] = 986,
                    },
                    [4] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2315,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632874330,
                        ["quant"] = 1,
                        ["id"] = "1689334251",
                        ["itemLink"] = 986,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [115986] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Breton Stool, Padded",
                ["oldestTime"] = 1632964856,
                ["wasAltered"] = true,
                ["newestTime"] = 1632964856,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 2046,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632964856,
                        ["quant"] = 1,
                        ["id"] = "1690005247",
                        ["itemLink"] = 3949,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [99544] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_heavy_legs_d.dds",
                ["itemDesc"] = "Greaves of the Order of Diagna",
                ["oldestTime"] = 1632964340,
                ["wasAltered"] = true,
                ["newestTime"] = 1632964340,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 2650,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1632964340,
                        ["quant"] = 1,
                        ["id"] = "1689998707",
                        ["itemLink"] = 3943,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set order of diagna legs reinforced",
            },
        },
        [90283] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_light_feet_a.dds",
                ["itemDesc"] = "Shoes of the Desert Rose",
                ["oldestTime"] = 1633133276,
                ["wasAltered"] = true,
                ["newestTime"] = 1633133276,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15555,
                        ["guild"] = 1,
                        ["buyer"] = 738,
                        ["wasKiosk"] = true,
                        ["seller"] = 492,
                        ["timestamp"] = 1633133276,
                        ["quant"] = 1,
                        ["id"] = "1691222683",
                        ["itemLink"] = 1546,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set desert rose feet well-fitted",
            },
        },
        [97175] = 
        {
            ["50:16:2:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_shoulders_d.dds",
                ["itemDesc"] = "Plague Doctor's Pauldron",
                ["oldestTime"] = 1632950136,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950136,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1632950136,
                        ["quant"] = 1,
                        ["id"] = "1689875287",
                        ["itemLink"] = 3830,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set plague doctor shoulders sturdy",
            },
        },
        [84660] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_heavy_hands_d.dds",
                ["itemDesc"] = "Gauntlets of the Dragon",
                ["oldestTime"] = 1632948036,
                ["wasAltered"] = true,
                ["newestTime"] = 1632948036,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2574,
                        ["wasKiosk"] = true,
                        ["seller"] = 177,
                        ["timestamp"] = 1632948036,
                        ["quant"] = 1,
                        ["id"] = "1689858703",
                        ["itemLink"] = 3797,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set akaviri dragonguard hands sturdy",
            },
        },
        [116142] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Khajiit Pillow, Roll",
                ["oldestTime"] = 1632928473,
                ["wasAltered"] = true,
                ["newestTime"] = 1632977884,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 38000,
                        ["guild"] = 1,
                        ["buyer"] = 247,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632977884,
                        ["quant"] = 1,
                        ["id"] = "1690117405",
                        ["itemLink"] = 247,
                    },
                    [2] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 2508,
                        ["wasKiosk"] = true,
                        ["seller"] = 1450,
                        ["timestamp"] = 1632928473,
                        ["quant"] = 1,
                        ["id"] = "1689709907",
                        ["itemLink"] = 247,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [69389] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Agility",
                ["oldestTime"] = 1632793710,
                ["wasAltered"] = true,
                ["newestTime"] = 1633064734,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 2,
                        ["buyer"] = 131,
                        ["wasKiosk"] = false,
                        ["seller"] = 111,
                        ["timestamp"] = 1632793710,
                        ["quant"] = 1,
                        ["id"] = "1688754635",
                        ["itemLink"] = 137,
                    },
                    [2] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 815,
                        ["wasKiosk"] = true,
                        ["seller"] = 171,
                        ["timestamp"] = 1633064734,
                        ["quant"] = 1,
                        ["id"] = "1690746045",
                        ["itemLink"] = 1055,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set agility ring robust",
            },
        },
        [69385] = 
        {
            ["18:0:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Agility",
                ["oldestTime"] = 1632932632,
                ["wasAltered"] = true,
                ["newestTime"] = 1632932632,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 196,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1632932632,
                        ["quant"] = 1,
                        ["id"] = "1689741459",
                        ["itemLink"] = 3717,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr18 purple epic jewelry apparel set agility ring healthy",
            },
        },
        [64689] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_ore_base_malachite_r2.dds",
                ["itemDesc"] = "Malachite",
                ["oldestTime"] = 1633139475,
                ["wasAltered"] = true,
                ["newestTime"] = 1633207018,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 1175,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633139475,
                        ["quant"] = 1,
                        ["id"] = "1691285591",
                        ["itemLink"] = 1592,
                    },
                    [2] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1533,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633207018,
                        ["quant"] = 1,
                        ["id"] = "1691867747",
                        ["itemLink"] = 1592,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [97155] = 
        {
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_shoulders_d.dds",
                ["itemDesc"] = "Plague Doctor's Pauldron",
                ["oldestTime"] = 1632964775,
                ["wasAltered"] = true,
                ["newestTime"] = 1632964775,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1655,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1632964775,
                        ["quant"] = 1,
                        ["id"] = "1690003855",
                        ["itemLink"] = 3946,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set plague doctor shoulders invigorating",
            },
            ["50:16:2:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_shoulders_d.dds",
                ["itemDesc"] = "Plague Doctor's Pauldron",
                ["oldestTime"] = 1632925679,
                ["wasAltered"] = true,
                ["newestTime"] = 1632925679,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 175,
                        ["guild"] = 1,
                        ["buyer"] = 2500,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1632925679,
                        ["quant"] = 1,
                        ["id"] = "1689691883",
                        ["itemLink"] = 3686,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set plague doctor shoulders invigorating",
            },
        },
        [134835] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_orc_duc_wtgembeddedskeleton007.dds",
                ["itemDesc"] = "Orcish Burial Urn, Exhumed",
                ["oldestTime"] = 1632883664,
                ["wasAltered"] = true,
                ["newestTime"] = 1632883664,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 35600,
                        ["guild"] = 1,
                        ["buyer"] = 2373,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1632883664,
                        ["quant"] = 1,
                        ["id"] = "1689435157",
                        ["itemLink"] = 3486,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings undercroft",
            },
        },
        [100020] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Stendarr",
                ["oldestTime"] = 1632973856,
                ["wasAltered"] = true,
                ["newestTime"] = 1632973856,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 196,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1632973856,
                        ["quant"] = 1,
                        ["id"] = "1690088811",
                        ["itemLink"] = 207,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set stendarr's embrace ring arcane",
            },
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Stendarr",
                ["oldestTime"] = 1633163921,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163921,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1700,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633163921,
                        ["quant"] = 1,
                        ["id"] = "1691490381",
                        ["itemLink"] = 1818,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set stendarr's embrace ring arcane",
            },
        },
        [96349] = 
        {
            ["50:16:4:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_dagger_d.dds",
                ["itemDesc"] = "Dagger of the Trainee",
                ["oldestTime"] = 1632924408,
                ["wasAltered"] = true,
                ["newestTime"] = 1632924408,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10153,
                        ["guild"] = 1,
                        ["buyer"] = 2208,
                        ["wasKiosk"] = true,
                        ["seller"] = 1494,
                        ["timestamp"] = 1632924408,
                        ["quant"] = 1,
                        ["id"] = "1689682379",
                        ["itemLink"] = 3682,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set armor of the trainee dagger one-handed training",
            },
        },
        [5365] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_frostessence.dds",
                ["itemDesc"] = "Superb Glyph of Frost",
                ["oldestTime"] = 1633251478,
                ["wasAltered"] = true,
                ["newestTime"] = 1633251478,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 80,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 78,
                        ["timestamp"] = 1633251478,
                        ["quant"] = 1,
                        ["id"] = "1692280583",
                        ["itemLink"] = 2598,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 green fine miscellaneous weapon glyph",
            },
            ["50:15:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_frostessence.dds",
                ["itemDesc"] = "Superb Glyph of Frost",
                ["oldestTime"] = 1633251483,
                ["wasAltered"] = true,
                ["newestTime"] = 1633251487,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633251483,
                        ["quant"] = 1,
                        ["id"] = "1692280605",
                        ["itemLink"] = 2600,
                    },
                    [2] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633251483,
                        ["quant"] = 1,
                        ["id"] = "1692280609",
                        ["itemLink"] = 2600,
                    },
                    [3] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633251484,
                        ["quant"] = 1,
                        ["id"] = "1692280611",
                        ["itemLink"] = 2600,
                    },
                    [4] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633251484,
                        ["quant"] = 1,
                        ["id"] = "1692280613",
                        ["itemLink"] = 2600,
                    },
                    [5] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633251485,
                        ["quant"] = 1,
                        ["id"] = "1692280615",
                        ["itemLink"] = 2600,
                    },
                    [6] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633251485,
                        ["quant"] = 1,
                        ["id"] = "1692280617",
                        ["itemLink"] = 2600,
                    },
                    [7] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633251486,
                        ["quant"] = 1,
                        ["id"] = "1692280621",
                        ["itemLink"] = 2600,
                    },
                    [8] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633251487,
                        ["quant"] = 1,
                        ["id"] = "1692280627",
                        ["itemLink"] = 2600,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "cp150 purple epic miscellaneous weapon glyph",
            },
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_frostessence.dds",
                ["itemDesc"] = "Truly Superb Glyph of Frost",
                ["oldestTime"] = 1632846651,
                ["wasAltered"] = true,
                ["newestTime"] = 1633267873,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1025,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633115973,
                        ["quant"] = 1,
                        ["id"] = "1691078593",
                        ["itemLink"] = 1404,
                    },
                    [2] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1639,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633224729,
                        ["quant"] = 1,
                        ["id"] = "1692061355",
                        ["itemLink"] = 2378,
                    },
                    [3] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1639,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633224736,
                        ["quant"] = 1,
                        ["id"] = "1692061387",
                        ["itemLink"] = 2379,
                    },
                    [4] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1639,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633225362,
                        ["quant"] = 1,
                        ["id"] = "1692068069",
                        ["itemLink"] = 2384,
                    },
                    [5] = 
                    {
                        ["price"] = 123,
                        ["guild"] = 1,
                        ["buyer"] = 1866,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1633267872,
                        ["quant"] = 1,
                        ["id"] = "1692383615",
                        ["itemLink"] = 2379,
                    },
                    [6] = 
                    {
                        ["price"] = 123,
                        ["guild"] = 1,
                        ["buyer"] = 1866,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1633267872,
                        ["quant"] = 1,
                        ["id"] = "1692383619",
                        ["itemLink"] = 2645,
                    },
                    [7] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1866,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1633267873,
                        ["quant"] = 1,
                        ["id"] = "1692383643",
                        ["itemLink"] = 1404,
                    },
                    [8] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2201,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632846651,
                        ["quant"] = 1,
                        ["id"] = "1689115603",
                        ["itemLink"] = 2378,
                    },
                    [9] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2201,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632846653,
                        ["quant"] = 1,
                        ["id"] = "1689115611",
                        ["itemLink"] = 1404,
                    },
                    [10] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2201,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632846658,
                        ["quant"] = 1,
                        ["id"] = "1689115641",
                        ["itemLink"] = 2384,
                    },
                },
                ["totalCount"] = 10,
                ["itemAdderText"] = "cp160 white normal miscellaneous weapon glyph",
            },
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_frostessence.dds",
                ["itemDesc"] = "Truly Superb Glyph of Frost",
                ["oldestTime"] = 1633026716,
                ["wasAltered"] = true,
                ["newestTime"] = 1633026716,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6300,
                        ["guild"] = 1,
                        ["buyer"] = 544,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633026716,
                        ["quant"] = 1,
                        ["id"] = "1690419565",
                        ["itemLink"] = 681,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous weapon glyph",
            },
        },
        [124668] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/fragment_costume_sixthhouse_thread.dds",
                ["itemDesc"] = "Sixth House Writhing Thread",
                ["oldestTime"] = 1632919059,
                ["wasAltered"] = true,
                ["newestTime"] = 1632919059,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3309,
                        ["guild"] = 1,
                        ["buyer"] = 366,
                        ["wasKiosk"] = true,
                        ["seller"] = 493,
                        ["timestamp"] = 1632919059,
                        ["quant"] = 1,
                        ["id"] = "1689646643",
                        ["itemLink"] = 3645,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [172216] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_chest_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Jack",
                ["oldestTime"] = 1633310170,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310170,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 393,
                        ["guild"] = 1,
                        ["buyer"] = 63,
                        ["wasKiosk"] = false,
                        ["seller"] = 662,
                        ["timestamp"] = 1633310170,
                        ["quant"] = 1,
                        ["id"] = "1692850929",
                        ["itemLink"] = 2984,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set deadlands assassin chest impenetrable",
            },
        },
        [99020] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_medium_head_d.dds",
                ["itemDesc"] = "Swamp Raider's Helmet",
                ["oldestTime"] = 1632912364,
                ["wasAltered"] = true,
                ["newestTime"] = 1632912364,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2467,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1632912364,
                        ["quant"] = 1,
                        ["id"] = "1689609929",
                        ["itemLink"] = 3618,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set swamp raider head sturdy",
            },
        },
        [49125] = 
        {
            ["10:0:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_medium_chest_a.dds",
                ["itemDesc"] = "Jack of the Night Mother",
                ["oldestTime"] = 1632911079,
                ["wasAltered"] = true,
                ["newestTime"] = 1632911079,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2463,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632911079,
                        ["quant"] = 1,
                        ["id"] = "1689604505",
                        ["itemLink"] = 3609,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr10 blue superior medium apparel set night mother's gaze chest training",
            },
        },
        [175547] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Blackwood Treasure Map I",
                ["oldestTime"] = 1633057626,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293476,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 49995,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 211,
                        ["timestamp"] = 1633057626,
                        ["quant"] = 1,
                        ["id"] = "1690686931",
                        ["itemLink"] = 970,
                    },
                    [2] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 513,
                        ["timestamp"] = 1633057628,
                        ["quant"] = 1,
                        ["id"] = "1690686941",
                        ["itemLink"] = 970,
                    },
                    [3] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 586,
                        ["timestamp"] = 1633057673,
                        ["quant"] = 1,
                        ["id"] = "1690687301",
                        ["itemLink"] = 970,
                    },
                    [4] = 
                    {
                        ["price"] = 48000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 845,
                        ["timestamp"] = 1633075827,
                        ["quant"] = 1,
                        ["id"] = "1690815851",
                        ["itemLink"] = 970,
                    },
                    [5] = 
                    {
                        ["price"] = 44000,
                        ["guild"] = 1,
                        ["buyer"] = 15,
                        ["wasKiosk"] = false,
                        ["seller"] = 1128,
                        ["timestamp"] = 1633142803,
                        ["quant"] = 1,
                        ["id"] = "1691322951",
                        ["itemLink"] = 970,
                    },
                    [6] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633146749,
                        ["quant"] = 1,
                        ["id"] = "1691363315",
                        ["itemLink"] = 970,
                    },
                    [7] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 521,
                        ["timestamp"] = 1633156800,
                        ["quant"] = 1,
                        ["id"] = "1691444681",
                        ["itemLink"] = 970,
                    },
                    [8] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633227286,
                        ["quant"] = 1,
                        ["id"] = "1692088061",
                        ["itemLink"] = 970,
                    },
                    [9] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 615,
                        ["timestamp"] = 1633227287,
                        ["quant"] = 1,
                        ["id"] = "1692088077",
                        ["itemLink"] = 970,
                    },
                    [10] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 75,
                        ["timestamp"] = 1633234411,
                        ["quant"] = 1,
                        ["id"] = "1692156985",
                        ["itemLink"] = 970,
                    },
                    [11] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633234413,
                        ["quant"] = 1,
                        ["id"] = "1692156997",
                        ["itemLink"] = 970,
                    },
                    [12] = 
                    {
                        ["price"] = 49000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 763,
                        ["timestamp"] = 1633234416,
                        ["quant"] = 1,
                        ["id"] = "1692157029",
                        ["itemLink"] = 970,
                    },
                    [13] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 2000,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633293476,
                        ["quant"] = 1,
                        ["id"] = "1692668947",
                        ["itemLink"] = 970,
                    },
                },
                ["totalCount"] = 13,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [57020] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Cheydinhal Sherry",
                ["oldestTime"] = 1633052845,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052846,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633052845,
                        ["quant"] = 1,
                        ["id"] = "1690633725",
                        ["itemLink"] = 918,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633052846,
                        ["quant"] = 1,
                        ["id"] = "1690633739",
                        ["itemLink"] = 918,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [151944] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_coh_inc_sconce001.dds",
                ["itemDesc"] = "Daedric Sconce, Coldharbour",
                ["oldestTime"] = 1632895697,
                ["wasAltered"] = true,
                ["newestTime"] = 1632895699,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 2432,
                        ["wasKiosk"] = true,
                        ["seller"] = 669,
                        ["timestamp"] = 1632895697,
                        ["quant"] = 1,
                        ["id"] = "1689533335",
                        ["itemLink"] = 3562,
                    },
                    [2] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 2432,
                        ["wasKiosk"] = true,
                        ["seller"] = 669,
                        ["timestamp"] = 1632895699,
                        ["quant"] = 1,
                        ["id"] = "1689533341",
                        ["itemLink"] = 3562,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [100100] = 
        {
            ["50:16:4:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_light_hands_d.dds",
                ["itemDesc"] = "Gloves of Stendarr",
                ["oldestTime"] = 1632880323,
                ["wasAltered"] = true,
                ["newestTime"] = 1632880323,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2353,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1632880323,
                        ["quant"] = 1,
                        ["id"] = "1689400463",
                        ["itemLink"] = 3457,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set stendarr's embrace hands reinforced",
            },
        },
        [171967] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_legs_a.dds",
                ["itemDesc"] = "Breeches of Frostbite",
                ["oldestTime"] = 1633191579,
                ["wasAltered"] = true,
                ["newestTime"] = 1633191579,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 850,
                        ["guild"] = 1,
                        ["buyer"] = 1159,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633191579,
                        ["quant"] = 1,
                        ["id"] = "1691708363",
                        ["itemLink"] = 2112,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set frostbite legs infused",
            },
        },
        [135360] = 
        {
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_medium_feet_a.dds",
                ["itemDesc"] = "Gryphon's Boots",
                ["oldestTime"] = 1633074456,
                ["wasAltered"] = true,
                ["newestTime"] = 1633074456,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 861,
                        ["wasKiosk"] = true,
                        ["seller"] = 51,
                        ["timestamp"] = 1633074456,
                        ["quant"] = 1,
                        ["id"] = "1690807449",
                        ["itemLink"] = 1105,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set gryphon's ferocity feet infused",
            },
        },
        [30145] = 
        {
            ["50:15:1:9:724744"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/consumable_potion_006_type_005.dds",
                ["itemDesc"] = "Essence of Spell Power",
                ["oldestTime"] = 1633058076,
                ["wasAltered"] = true,
                ["newestTime"] = 1633058076,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12912,
                        ["guild"] = 1,
                        ["buyer"] = 772,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633058076,
                        ["quant"] = 48,
                        ["id"] = "1690691037",
                        ["itemLink"] = 983,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 white normal consumable potion",
            },
            ["50:15:1:9:724739"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/consumable_potion_006_type_005.dds",
                ["itemDesc"] = "Essence of Spell Power",
                ["oldestTime"] = 1632849554,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311980,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 78999,
                        ["guild"] = 1,
                        ["buyer"] = 27,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633311980,
                        ["quant"] = 200,
                        ["id"] = "1692869733",
                        ["itemLink"] = 23,
                    },
                    [2] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 452,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633011301,
                        ["quant"] = 200,
                        ["id"] = "1690299659",
                        ["itemLink"] = 23,
                    },
                    [3] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 455,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633011709,
                        ["quant"] = 200,
                        ["id"] = "1690302257",
                        ["itemLink"] = 23,
                    },
                    [4] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 455,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633011710,
                        ["quant"] = 200,
                        ["id"] = "1690302263",
                        ["itemLink"] = 23,
                    },
                    [5] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 536,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633023827,
                        ["quant"] = 200,
                        ["id"] = "1690396005",
                        ["itemLink"] = 23,
                    },
                    [6] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 536,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633023831,
                        ["quant"] = 200,
                        ["id"] = "1690396027",
                        ["itemLink"] = 23,
                    },
                    [7] = 
                    {
                        ["price"] = 67506,
                        ["guild"] = 1,
                        ["buyer"] = 658,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633043513,
                        ["quant"] = 200,
                        ["id"] = "1690541669",
                        ["itemLink"] = 23,
                    },
                    [8] = 
                    {
                        ["price"] = 67506,
                        ["guild"] = 1,
                        ["buyer"] = 679,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633046371,
                        ["quant"] = 200,
                        ["id"] = "1690569755",
                        ["itemLink"] = 23,
                    },
                    [9] = 
                    {
                        ["price"] = 67506,
                        ["guild"] = 1,
                        ["buyer"] = 750,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633055537,
                        ["quant"] = 200,
                        ["id"] = "1690660041",
                        ["itemLink"] = 23,
                    },
                    [10] = 
                    {
                        ["price"] = 67506,
                        ["guild"] = 1,
                        ["buyer"] = 750,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633055542,
                        ["quant"] = 200,
                        ["id"] = "1690660067",
                        ["itemLink"] = 23,
                    },
                    [11] = 
                    {
                        ["price"] = 22500,
                        ["guild"] = 1,
                        ["buyer"] = 949,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633101484,
                        ["quant"] = 50,
                        ["id"] = "1690968373",
                        ["itemLink"] = 23,
                    },
                    [12] = 
                    {
                        ["price"] = 76000,
                        ["guild"] = 1,
                        ["buyer"] = 982,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633110321,
                        ["quant"] = 200,
                        ["id"] = "1691039279",
                        ["itemLink"] = 23,
                    },
                    [13] = 
                    {
                        ["price"] = 76000,
                        ["guild"] = 1,
                        ["buyer"] = 982,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633110322,
                        ["quant"] = 200,
                        ["id"] = "1691039299",
                        ["itemLink"] = 23,
                    },
                    [14] = 
                    {
                        ["price"] = 76000,
                        ["guild"] = 1,
                        ["buyer"] = 982,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633110323,
                        ["quant"] = 200,
                        ["id"] = "1691039307",
                        ["itemLink"] = 23,
                    },
                    [15] = 
                    {
                        ["price"] = 76000,
                        ["guild"] = 1,
                        ["buyer"] = 982,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633110325,
                        ["quant"] = 200,
                        ["id"] = "1691039335",
                        ["itemLink"] = 23,
                    },
                    [16] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 1092,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633127290,
                        ["quant"] = 200,
                        ["id"] = "1691161435",
                        ["itemLink"] = 23,
                    },
                    [17] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 1092,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633127291,
                        ["quant"] = 200,
                        ["id"] = "1691161443",
                        ["itemLink"] = 23,
                    },
                    [18] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 1092,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633127291,
                        ["quant"] = 200,
                        ["id"] = "1691161449",
                        ["itemLink"] = 23,
                    },
                    [19] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 1092,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633127292,
                        ["quant"] = 200,
                        ["id"] = "1691161451",
                        ["itemLink"] = 23,
                    },
                    [20] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 1092,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633127292,
                        ["quant"] = 200,
                        ["id"] = "1691161457",
                        ["itemLink"] = 23,
                    },
                    [21] = 
                    {
                        ["price"] = 1520,
                        ["guild"] = 1,
                        ["buyer"] = 1097,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633129171,
                        ["quant"] = 4,
                        ["id"] = "1691177073",
                        ["itemLink"] = 23,
                    },
                    [22] = 
                    {
                        ["price"] = 79999,
                        ["guild"] = 1,
                        ["buyer"] = 1100,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633129986,
                        ["quant"] = 200,
                        ["id"] = "1691185601",
                        ["itemLink"] = 23,
                    },
                    [23] = 
                    {
                        ["price"] = 79999,
                        ["guild"] = 1,
                        ["buyer"] = 1100,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633129988,
                        ["quant"] = 200,
                        ["id"] = "1691185643",
                        ["itemLink"] = 23,
                    },
                    [24] = 
                    {
                        ["price"] = 79999,
                        ["guild"] = 1,
                        ["buyer"] = 1178,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633139791,
                        ["quant"] = 200,
                        ["id"] = "1691289001",
                        ["itemLink"] = 23,
                    },
                    [25] = 
                    {
                        ["price"] = 79999,
                        ["guild"] = 1,
                        ["buyer"] = 1178,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633139794,
                        ["quant"] = 200,
                        ["id"] = "1691289023",
                        ["itemLink"] = 23,
                    },
                    [26] = 
                    {
                        ["price"] = 22500,
                        ["guild"] = 1,
                        ["buyer"] = 1191,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633141741,
                        ["quant"] = 50,
                        ["id"] = "1691310173",
                        ["itemLink"] = 23,
                    },
                    [27] = 
                    {
                        ["price"] = 79999,
                        ["guild"] = 1,
                        ["buyer"] = 1193,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633141857,
                        ["quant"] = 200,
                        ["id"] = "1691311461",
                        ["itemLink"] = 23,
                    },
                    [28] = 
                    {
                        ["price"] = 79999,
                        ["guild"] = 1,
                        ["buyer"] = 1193,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633141857,
                        ["quant"] = 200,
                        ["id"] = "1691311463",
                        ["itemLink"] = 23,
                    },
                    [29] = 
                    {
                        ["price"] = 79999,
                        ["guild"] = 1,
                        ["buyer"] = 1193,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633141858,
                        ["quant"] = 200,
                        ["id"] = "1691311467",
                        ["itemLink"] = 23,
                    },
                    [30] = 
                    {
                        ["price"] = 79999,
                        ["guild"] = 1,
                        ["buyer"] = 1193,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633141858,
                        ["quant"] = 200,
                        ["id"] = "1691311471",
                        ["itemLink"] = 23,
                    },
                    [31] = 
                    {
                        ["price"] = 81000,
                        ["guild"] = 1,
                        ["buyer"] = 1193,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633141861,
                        ["quant"] = 200,
                        ["id"] = "1691311479",
                        ["itemLink"] = 23,
                    },
                    [32] = 
                    {
                        ["price"] = 79999,
                        ["guild"] = 1,
                        ["buyer"] = 1298,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633159576,
                        ["quant"] = 200,
                        ["id"] = "1691462623",
                        ["itemLink"] = 23,
                    },
                    [33] = 
                    {
                        ["price"] = 79999,
                        ["guild"] = 1,
                        ["buyer"] = 1298,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633159592,
                        ["quant"] = 200,
                        ["id"] = "1691462707",
                        ["itemLink"] = 23,
                    },
                    [34] = 
                    {
                        ["price"] = 79000,
                        ["guild"] = 1,
                        ["buyer"] = 1652,
                        ["wasKiosk"] = true,
                        ["seller"] = 1318,
                        ["timestamp"] = 1633226318,
                        ["quant"] = 200,
                        ["id"] = "1692077795",
                        ["itemLink"] = 23,
                    },
                    [35] = 
                    {
                        ["price"] = 79000,
                        ["guild"] = 1,
                        ["buyer"] = 1714,
                        ["wasKiosk"] = true,
                        ["seller"] = 1318,
                        ["timestamp"] = 1633233328,
                        ["quant"] = 200,
                        ["id"] = "1692147937",
                        ["itemLink"] = 23,
                    },
                    [36] = 
                    {
                        ["price"] = 78999,
                        ["guild"] = 1,
                        ["buyer"] = 1723,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633234714,
                        ["quant"] = 200,
                        ["id"] = "1692159005",
                        ["itemLink"] = 23,
                    },
                    [37] = 
                    {
                        ["price"] = 78999,
                        ["guild"] = 1,
                        ["buyer"] = 1723,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633234717,
                        ["quant"] = 200,
                        ["id"] = "1692159051",
                        ["itemLink"] = 23,
                    },
                    [38] = 
                    {
                        ["price"] = 78999,
                        ["guild"] = 1,
                        ["buyer"] = 1854,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633265529,
                        ["quant"] = 200,
                        ["id"] = "1692364733",
                        ["itemLink"] = 23,
                    },
                    [39] = 
                    {
                        ["price"] = 78999,
                        ["guild"] = 1,
                        ["buyer"] = 1863,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633267653,
                        ["quant"] = 200,
                        ["id"] = "1692381243",
                        ["itemLink"] = 23,
                    },
                    [40] = 
                    {
                        ["price"] = 78999,
                        ["guild"] = 1,
                        ["buyer"] = 2013,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633294731,
                        ["quant"] = 200,
                        ["id"] = "1692686871",
                        ["itemLink"] = 23,
                    },
                    [41] = 
                    {
                        ["price"] = 78999,
                        ["guild"] = 1,
                        ["buyer"] = 1723,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633302139,
                        ["quant"] = 200,
                        ["id"] = "1692763419",
                        ["itemLink"] = 23,
                    },
                    [42] = 
                    {
                        ["price"] = 78999,
                        ["guild"] = 1,
                        ["buyer"] = 1723,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633302141,
                        ["quant"] = 200,
                        ["id"] = "1692763431",
                        ["itemLink"] = 23,
                    },
                    [43] = 
                    {
                        ["price"] = 78999,
                        ["guild"] = 1,
                        ["buyer"] = 2060,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633304482,
                        ["quant"] = 200,
                        ["id"] = "1692785187",
                        ["itemLink"] = 23,
                    },
                    [44] = 
                    {
                        ["price"] = 78999,
                        ["guild"] = 1,
                        ["buyer"] = 2060,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633304484,
                        ["quant"] = 200,
                        ["id"] = "1692785203",
                        ["itemLink"] = 23,
                    },
                    [45] = 
                    {
                        ["price"] = 19450,
                        ["guild"] = 1,
                        ["buyer"] = 2211,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1632849554,
                        ["quant"] = 50,
                        ["id"] = "1689140003",
                        ["itemLink"] = 23,
                    },
                    [46] = 
                    {
                        ["price"] = 19450,
                        ["guild"] = 1,
                        ["buyer"] = 2211,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1632849555,
                        ["quant"] = 50,
                        ["id"] = "1689140019",
                        ["itemLink"] = 23,
                    },
                    [47] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 2311,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632873474,
                        ["quant"] = 200,
                        ["id"] = "1689326725",
                        ["itemLink"] = 23,
                    },
                    [48] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 2311,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632873475,
                        ["quant"] = 200,
                        ["id"] = "1689326731",
                        ["itemLink"] = 23,
                    },
                    [49] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 2311,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632873476,
                        ["quant"] = 200,
                        ["id"] = "1689326735",
                        ["itemLink"] = 23,
                    },
                    [50] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 16,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632875699,
                        ["quant"] = 200,
                        ["id"] = "1689349035",
                        ["itemLink"] = 23,
                    },
                    [51] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 2330,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632876237,
                        ["quant"] = 200,
                        ["id"] = "1689354153",
                        ["itemLink"] = 23,
                    },
                    [52] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 2355,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632880821,
                        ["quant"] = 200,
                        ["id"] = "1689404677",
                        ["itemLink"] = 23,
                    },
                    [53] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 2399,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632887434,
                        ["quant"] = 200,
                        ["id"] = "1689474091",
                        ["itemLink"] = 23,
                    },
                    [54] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 2447,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632901284,
                        ["quant"] = 200,
                        ["id"] = "1689565775",
                        ["itemLink"] = 23,
                    },
                    [55] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 29,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632910326,
                        ["quant"] = 200,
                        ["id"] = "1689602367",
                        ["itemLink"] = 23,
                    },
                    [56] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 2621,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632958438,
                        ["quant"] = 200,
                        ["id"] = "1689947105",
                        ["itemLink"] = 23,
                    },
                    [57] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 2621,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632958440,
                        ["quant"] = 200,
                        ["id"] = "1689947127",
                        ["itemLink"] = 23,
                    },
                    [58] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 2621,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632958441,
                        ["quant"] = 200,
                        ["id"] = "1689947145",
                        ["itemLink"] = 23,
                    },
                    [59] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 2621,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632958442,
                        ["quant"] = 200,
                        ["id"] = "1689947185",
                        ["itemLink"] = 23,
                    },
                    [60] = 
                    {
                        ["price"] = 80999,
                        ["guild"] = 1,
                        ["buyer"] = 2623,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632959205,
                        ["quant"] = 200,
                        ["id"] = "1689954015",
                        ["itemLink"] = 23,
                    },
                },
                ["totalCount"] = 60,
                ["itemAdderText"] = "cp150 white normal consumable potion",
            },
        },
        [171590] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 99: Waking Flame Maces",
                ["oldestTime"] = 1632874426,
                ["wasAltered"] = true,
                ["newestTime"] = 1632874426,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 46500,
                        ["guild"] = 1,
                        ["buyer"] = 2318,
                        ["wasKiosk"] = true,
                        ["seller"] = 712,
                        ["timestamp"] = 1632874426,
                        ["quant"] = 1,
                        ["id"] = "1689335143",
                        ["itemLink"] = 3402,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [64707] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/notes_004.dds",
                ["itemDesc"] = "Recipe: Psijic Ambrosia, Fragment V",
                ["oldestTime"] = 1633220831,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310219,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 285,
                        ["wasKiosk"] = false,
                        ["seller"] = 802,
                        ["timestamp"] = 1633220831,
                        ["quant"] = 1,
                        ["id"] = "1692020345",
                        ["itemLink"] = 2347,
                    },
                    [2] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1982,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633290441,
                        ["quant"] = 1,
                        ["id"] = "1692632533",
                        ["itemLink"] = 2347,
                    },
                    [3] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2020,
                        ["wasKiosk"] = true,
                        ["seller"] = 155,
                        ["timestamp"] = 1633295804,
                        ["quant"] = 1,
                        ["id"] = "1692698469",
                        ["itemLink"] = 2347,
                    },
                    [4] = 
                    {
                        ["price"] = 422,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633310219,
                        ["quant"] = 1,
                        ["id"] = "1692851199",
                        ["itemLink"] = 2347,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [99690] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_light_waist_d.dds",
                ["itemDesc"] = "Spinner's Sash",
                ["oldestTime"] = 1633142439,
                ["wasAltered"] = true,
                ["newestTime"] = 1633142439,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1206,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1633142439,
                        ["quant"] = 1,
                        ["id"] = "1691319177",
                        ["itemLink"] = 1623,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set spinner's garments waist divines",
            },
        },
        [171553] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 100: True-Sworn Belts",
                ["oldestTime"] = 1632863596,
                ["wasAltered"] = true,
                ["newestTime"] = 1632863596,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 2253,
                        ["wasKiosk"] = true,
                        ["seller"] = 451,
                        ["timestamp"] = 1632863596,
                        ["quant"] = 1,
                        ["id"] = "1689255577",
                        ["itemLink"] = 3320,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [175915] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Cupboard, Sturdy",
                ["oldestTime"] = 1632862555,
                ["wasAltered"] = true,
                ["newestTime"] = 1632862555,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2251,
                        ["wasKiosk"] = true,
                        ["seller"] = 100,
                        ["timestamp"] = 1632862555,
                        ["quant"] = 1,
                        ["id"] = "1689248513",
                        ["itemLink"] = 3316,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [97075] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_shoulders_d.dds",
                ["itemDesc"] = "Plague Doctor's Pauldron",
                ["oldestTime"] = 1632857742,
                ["wasAltered"] = true,
                ["newestTime"] = 1632857742,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 522,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1632857742,
                        ["quant"] = 1,
                        ["id"] = "1689211641",
                        ["itemLink"] = 3283,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set plague doctor shoulders divines",
            },
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_shoulders_d.dds",
                ["itemDesc"] = "Plague Doctor's Pauldron",
                ["oldestTime"] = 1632856303,
                ["wasAltered"] = true,
                ["newestTime"] = 1632856303,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1632856303,
                        ["quant"] = 1,
                        ["id"] = "1689200555",
                        ["itemLink"] = 3269,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set plague doctor shoulders divines",
            },
        },
        [33772] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_coffee_beans.dds",
                ["itemDesc"] = "Coffee",
                ["oldestTime"] = 1632831314,
                ["wasAltered"] = true,
                ["newestTime"] = 1632831314,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2275,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1632831314,
                        ["quant"] = 200,
                        ["id"] = "1689006951",
                        ["itemLink"] = 3087,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [102126] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_draugr_medium_chest_a.dds",
                ["itemDesc"] = "Stygian Jack",
                ["oldestTime"] = 1633299780,
                ["wasAltered"] = true,
                ["newestTime"] = 1633299780,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 2040,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633299780,
                        ["quant"] = 1,
                        ["id"] = "1692738661",
                        ["itemLink"] = 2911,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set stygian chest well-fitted",
            },
        },
        [160584] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 87: Ancestral Nord Helmets",
                ["oldestTime"] = 1632846172,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294748,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12500,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 611,
                        ["timestamp"] = 1633294748,
                        ["quant"] = 1,
                        ["id"] = "1692687133",
                        ["itemLink"] = 2875,
                    },
                    [2] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 2197,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1632846172,
                        ["quant"] = 1,
                        ["id"] = "1689112139",
                        ["itemLink"] = 2875,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [114891] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_furniture_base_clean_pelt.dds",
                ["itemDesc"] = "Clean Pelt",
                ["oldestTime"] = 1632987682,
                ["wasAltered"] = true,
                ["newestTime"] = 1632999415,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 294,
                        ["timestamp"] = 1632987682,
                        ["quant"] = 200,
                        ["id"] = "1690172703",
                        ["itemLink"] = 334,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 294,
                        ["timestamp"] = 1632987683,
                        ["quant"] = 200,
                        ["id"] = "1690172709",
                        ["itemLink"] = 334,
                    },
                    [3] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 294,
                        ["timestamp"] = 1632987684,
                        ["quant"] = 200,
                        ["id"] = "1690172717",
                        ["itemLink"] = 334,
                    },
                    [4] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 294,
                        ["timestamp"] = 1632987685,
                        ["quant"] = 200,
                        ["id"] = "1690172727",
                        ["itemLink"] = 334,
                    },
                    [5] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 334,
                        ["timestamp"] = 1632987741,
                        ["quant"] = 200,
                        ["id"] = "1690172947",
                        ["itemLink"] = 334,
                    },
                    [6] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 391,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632999415,
                        ["quant"] = 200,
                        ["id"] = "1690229483",
                        ["itemLink"] = 334,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 white normal materials furnishing",
            },
        },
        [175564] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Ja'zennji Siir Jack",
                ["oldestTime"] = 1633298425,
                ["wasAltered"] = true,
                ["newestTime"] = 1633298425,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1586,
                        ["guild"] = 1,
                        ["buyer"] = 48,
                        ["wasKiosk"] = false,
                        ["seller"] = 1161,
                        ["timestamp"] = 1633298425,
                        ["quant"] = 1,
                        ["id"] = "1692725447",
                        ["itemLink"] = 2903,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [72909] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Bahraha's Curse",
                ["oldestTime"] = 1633249733,
                ["wasAltered"] = true,
                ["newestTime"] = 1633249733,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1813,
                        ["wasKiosk"] = true,
                        ["seller"] = 655,
                        ["timestamp"] = 1633249733,
                        ["quant"] = 1,
                        ["id"] = "1692268951",
                        ["itemLink"] = 2594,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set bahraha's curse ring arcane",
            },
        },
        [171556] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 100: True-Sworn Chests",
                ["oldestTime"] = 1633293263,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293263,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325000,
                        ["guild"] = 1,
                        ["buyer"] = 1999,
                        ["wasKiosk"] = true,
                        ["seller"] = 712,
                        ["timestamp"] = 1633293263,
                        ["quant"] = 1,
                        ["id"] = "1692666473",
                        ["itemLink"] = 2853,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [115198] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bre_inc_rug001.dds",
                ["itemDesc"] = "Breton Carpet, Full",
                ["oldestTime"] = 1633292815,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292815,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 1995,
                        ["wasKiosk"] = true,
                        ["seller"] = 600,
                        ["timestamp"] = 1633292815,
                        ["quant"] = 1,
                        ["id"] = "1692661331",
                        ["itemLink"] = 2846,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings parlor",
            },
        },
        [130281] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_fug_chlightstalk001.dds",
                ["itemDesc"] = "Coldharbour Glowstalk, Towering",
                ["oldestTime"] = 1633235077,
                ["wasAltered"] = true,
                ["newestTime"] = 1633235077,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633235077,
                        ["quant"] = 1,
                        ["id"] = "1692161097",
                        ["itemLink"] = 2480,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [120529] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_bsh_malabaltorfernclusterred001.dds",
                ["itemDesc"] = "Fern Cluster, Healthy",
                ["oldestTime"] = 1633238153,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238153,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1745,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633238153,
                        ["quant"] = 2,
                        ["id"] = "1692186553",
                        ["itemLink"] = 2504,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal furnishings conservatory",
            },
        },
        [180434] = 
        {
            ["50:16:4:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_2hsword_a.dds",
                ["itemDesc"] = "Greatsword of Dark Convergence",
                ["oldestTime"] = 1633313598,
                ["wasAltered"] = true,
                ["newestTime"] = 1633313598,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 59,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633313598,
                        ["quant"] = 1,
                        ["id"] = "1692886777",
                        ["itemLink"] = 41,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set dark convergence sword two-handed infused",
            },
        },
        [140499] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 67: Welkynar Boots",
                ["oldestTime"] = 1633107982,
                ["wasAltered"] = true,
                ["newestTime"] = 1633107982,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 973,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633107982,
                        ["quant"] = 1,
                        ["id"] = "1691021953",
                        ["itemLink"] = 1305,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [171988] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_legs_a.dds",
                ["itemDesc"] = "Breeches of Frostbite",
                ["oldestTime"] = 1633164303,
                ["wasAltered"] = true,
                ["newestTime"] = 1633164303,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1690,
                        ["guild"] = 1,
                        ["buyer"] = 1316,
                        ["wasKiosk"] = true,
                        ["seller"] = 1112,
                        ["timestamp"] = 1633164303,
                        ["quant"] = 1,
                        ["id"] = "1691492307",
                        ["itemLink"] = 1831,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set frostbite legs divines",
            },
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_legs_a.dds",
                ["itemDesc"] = "Breeches of Frostbite",
                ["oldestTime"] = 1633182294,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182294,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1377,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633182294,
                        ["quant"] = 1,
                        ["id"] = "1691606439",
                        ["itemLink"] = 1941,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite legs divines",
            },
        },
        [45269] = 
        {
            ["50:16:2:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_dagger_d.dds",
                ["itemDesc"] = "Rubedite Dagger of Flame",
                ["oldestTime"] = 1633094742,
                ["wasAltered"] = true,
                ["newestTime"] = 1633094742,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 63,
                        ["wasKiosk"] = false,
                        ["seller"] = 501,
                        ["timestamp"] = 1633094742,
                        ["quant"] = 1,
                        ["id"] = "1690917425",
                        ["itemLink"] = 1250,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon dagger one-handed decisive",
            },
        },
        [118998] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing2.dds",
                ["itemDesc"] = "Diagram: High Elf Basin, Gilded",
                ["oldestTime"] = 1633292409,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292409,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 1992,
                        ["wasKiosk"] = true,
                        ["seller"] = 533,
                        ["timestamp"] = 1633292409,
                        ["quant"] = 1,
                        ["id"] = "1692656435",
                        ["itemLink"] = 2832,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [177026] = 
        {
            ["1:0:3:50:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_chest_heavy.dds",
                ["itemDesc"] = "Companion's Cuirass",
                ["oldestTime"] = 1633031190,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293811,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19999,
                        ["guild"] = 1,
                        ["buyer"] = 564,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633031190,
                        ["quant"] = 1,
                        ["id"] = "1690452381",
                        ["itemLink"] = 714,
                    },
                    [2] = 
                    {
                        ["price"] = 19999,
                        ["guild"] = 1,
                        ["buyer"] = 1441,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633194348,
                        ["quant"] = 1,
                        ["id"] = "1691737283",
                        ["itemLink"] = 714,
                    },
                    [3] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 1680,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633229504,
                        ["quant"] = 1,
                        ["id"] = "1692110887",
                        ["itemLink"] = 714,
                    },
                    [4] = 
                    {
                        ["price"] = 49999,
                        ["guild"] = 1,
                        ["buyer"] = 2001,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633293811,
                        ["quant"] = 1,
                        ["id"] = "1692673703",
                        ["itemLink"] = 714,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior heavy apparel chest bolstered",
            },
        },
        [139224] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_fur_chair001.dds",
                ["itemDesc"] = "Alinor Armchair, Noble",
                ["oldestTime"] = 1633103790,
                ["wasAltered"] = true,
                ["newestTime"] = 1633103817,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 962,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633103790,
                        ["quant"] = 1,
                        ["id"] = "1690989667",
                        ["itemLink"] = 1293,
                    },
                    [2] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 962,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633103817,
                        ["quant"] = 1,
                        ["id"] = "1690990125",
                        ["itemLink"] = 1293,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [45266] = 
        {
            ["50:16:2:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_2haxe_d.dds",
                ["itemDesc"] = "Rubedite Battle Axe of Flame",
                ["oldestTime"] = 1632950120,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185938,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633185938,
                        ["quant"] = 1,
                        ["id"] = "1691640101",
                        ["itemLink"] = 2024,
                    },
                    [2] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632950120,
                        ["quant"] = 1,
                        ["id"] = "1689875123",
                        ["itemLink"] = 3817,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine weapon axe two-handed decisive",
            },
        },
        [33754] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_critter_dom_animal_fat.dds",
                ["itemDesc"] = "White Meat",
                ["oldestTime"] = 1632830662,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305857,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 753,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1633055954,
                        ["quant"] = 100,
                        ["id"] = "1690663711",
                        ["itemLink"] = 950,
                    },
                    [2] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633305857,
                        ["quant"] = 200,
                        ["id"] = "1692799025",
                        ["itemLink"] = 950,
                    },
                    [3] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 2136,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1632830662,
                        ["quant"] = 200,
                        ["id"] = "1689002001",
                        ["itemLink"] = 950,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [166466] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_stonehuskfragment.dds",
                ["itemDesc"] = "Stone Husk Fragment",
                ["oldestTime"] = 1633292071,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292073,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 1988,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633292071,
                        ["quant"] = 1,
                        ["id"] = "1692652477",
                        ["itemLink"] = 2809,
                    },
                    [2] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 1988,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633292073,
                        ["quant"] = 1,
                        ["id"] = "1692652495",
                        ["itemLink"] = 2809,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [27100] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_dust_001.dds",
                ["itemDesc"] = "Flour",
                ["oldestTime"] = 1632957618,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305857,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6660,
                        ["guild"] = 1,
                        ["buyer"] = 702,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633051018,
                        ["quant"] = 148,
                        ["id"] = "1690614545",
                        ["itemLink"] = 892,
                    },
                    [2] = 
                    {
                        ["price"] = 99,
                        ["guild"] = 1,
                        ["buyer"] = 702,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633051020,
                        ["quant"] = 2,
                        ["id"] = "1690614573",
                        ["itemLink"] = 892,
                    },
                    [3] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 6,
                        ["wasKiosk"] = false,
                        ["seller"] = 508,
                        ["timestamp"] = 1633137444,
                        ["quant"] = 200,
                        ["id"] = "1691265827",
                        ["itemLink"] = 892,
                    },
                    [4] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633251995,
                        ["quant"] = 10,
                        ["id"] = "1692285383",
                        ["itemLink"] = 892,
                    },
                    [5] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 508,
                        ["timestamp"] = 1633291546,
                        ["quant"] = 200,
                        ["id"] = "1692645891",
                        ["itemLink"] = 892,
                    },
                    [6] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633305838,
                        ["quant"] = 200,
                        ["id"] = "1692798779",
                        ["itemLink"] = 892,
                    },
                    [7] = 
                    {
                        ["price"] = 4728,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633305857,
                        ["quant"] = 75,
                        ["id"] = "1692799027",
                        ["itemLink"] = 892,
                    },
                    [8] = 
                    {
                        ["price"] = 1440,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 333,
                        ["timestamp"] = 1632957618,
                        ["quant"] = 25,
                        ["id"] = "1689940673",
                        ["itemLink"] = 892,
                    },
                    [9] = 
                    {
                        ["price"] = 3400,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 442,
                        ["timestamp"] = 1632957621,
                        ["quant"] = 50,
                        ["id"] = "1689940687",
                        ["itemLink"] = 892,
                    },
                    [10] = 
                    {
                        ["price"] = 3750,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 46,
                        ["timestamp"] = 1632961190,
                        ["quant"] = 50,
                        ["id"] = "1689969453",
                        ["itemLink"] = 892,
                    },
                },
                ["totalCount"] = 10,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [43741] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Vvardenfell Treasure Map V",
                ["oldestTime"] = 1633169180,
                ["wasAltered"] = true,
                ["newestTime"] = 1633169180,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 259,
                        ["guild"] = 1,
                        ["buyer"] = 1333,
                        ["wasKiosk"] = true,
                        ["seller"] = 164,
                        ["timestamp"] = 1633169180,
                        ["quant"] = 1,
                        ["id"] = "1691515273",
                        ["itemLink"] = 1877,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [120798] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_fan_grahtwoodflower002.dds",
                ["itemDesc"] = "Wedding Blossoms, Blue",
                ["oldestTime"] = 1633238206,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238206,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1745,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633238206,
                        ["quant"] = 2,
                        ["id"] = "1692186885",
                        ["itemLink"] = 2508,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings lighting",
            },
        },
        [126431] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_vrd_fur_hlabed004.dds",
                ["itemDesc"] = "Hlaalu Bed, Canopy",
                ["oldestTime"] = 1632872755,
                ["wasAltered"] = true,
                ["newestTime"] = 1632872755,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12888,
                        ["guild"] = 1,
                        ["buyer"] = 2305,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1632872755,
                        ["quant"] = 1,
                        ["id"] = "1689321019",
                        ["itemLink"] = 3396,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings suite",
            },
        },
        [45024] = 
        {
            ["50:16:2:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_dagger_d.dds",
                ["itemDesc"] = "Rubedite Dagger of Flame",
                ["oldestTime"] = 1632936803,
                ["wasAltered"] = true,
                ["newestTime"] = 1632936803,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 226,
                        ["wasKiosk"] = false,
                        ["seller"] = 501,
                        ["timestamp"] = 1632936803,
                        ["quant"] = 1,
                        ["id"] = "1689773901",
                        ["itemLink"] = 3737,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon dagger one-handed powered",
            },
        },
        [77070] = 
        {
            ["50:16:2:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_minotaur_heavy_feet_a.dds",
                ["itemDesc"] = "Sabatons of Morihaus",
                ["oldestTime"] = 1632870279,
                ["wasAltered"] = true,
                ["newestTime"] = 1632870279,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 87,
                        ["guild"] = 2,
                        ["buyer"] = 114,
                        ["wasKiosk"] = false,
                        ["seller"] = 116,
                        ["timestamp"] = 1632870279,
                        ["quant"] = 1,
                        ["id"] = "1689305207",
                        ["itemLink"] = 138,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set hide of morihaus feet training",
            },
        },
        [71567] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 23: Malacath Axes",
                ["oldestTime"] = 1632853483,
                ["wasAltered"] = true,
                ["newestTime"] = 1633133945,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6550,
                        ["guild"] = 1,
                        ["buyer"] = 1127,
                        ["wasKiosk"] = true,
                        ["seller"] = 911,
                        ["timestamp"] = 1633133945,
                        ["quant"] = 1,
                        ["id"] = "1691230325",
                        ["itemLink"] = 1548,
                    },
                    [2] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 2226,
                        ["wasKiosk"] = true,
                        ["seller"] = 261,
                        ["timestamp"] = 1632853483,
                        ["quant"] = 1,
                        ["id"] = "1689171039",
                        ["itemLink"] = 1548,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45287] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_medium_feet_d.dds",
                ["itemDesc"] = "Rubedo Leather Boots of Health",
                ["oldestTime"] = 1633286968,
                ["wasAltered"] = true,
                ["newestTime"] = 1633286968,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 90,
                        ["guild"] = 1,
                        ["buyer"] = 1958,
                        ["wasKiosk"] = true,
                        ["seller"] = 99,
                        ["timestamp"] = 1633286968,
                        ["quant"] = 1,
                        ["id"] = "1692591859",
                        ["itemLink"] = 2759,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel feet divines",
            },
        },
        [33252] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/grafting_gems_adamantine.dds",
                ["itemDesc"] = "Adamantite",
                ["oldestTime"] = 1633067252,
                ["wasAltered"] = true,
                ["newestTime"] = 1633067252,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2800,
                        ["guild"] = 1,
                        ["buyer"] = 829,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633067252,
                        ["quant"] = 100,
                        ["id"] = "1690762661",
                        ["itemLink"] = 1071,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [4325] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_d.dds",
                ["itemDesc"] = "Argonian Muck Minder of Mother's Sorrow",
                ["oldestTime"] = 1633017818,
                ["wasAltered"] = true,
                ["newestTime"] = 1633017818,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 489,
                        ["wasKiosk"] = true,
                        ["seller"] = 252,
                        ["timestamp"] = 1633017818,
                        ["quant"] = 1,
                        ["id"] = "1690347387",
                        ["itemLink"] = 558,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set mother's sorrow lightning staff two-handed infused",
            },
        },
        [180710] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_staff_a.dds",
                ["itemDesc"] = "Plaguebreak Inferno Staff",
                ["oldestTime"] = 1633117898,
                ["wasAltered"] = true,
                ["newestTime"] = 1633117898,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5555,
                        ["guild"] = 1,
                        ["buyer"] = 1036,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633117898,
                        ["quant"] = 1,
                        ["id"] = "1691090729",
                        ["itemLink"] = 1420,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set plaguebreak flame staff two-handed charged",
            },
        },
        [180711] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_staff_a.dds",
                ["itemDesc"] = "Plaguebreak Ice Staff",
                ["oldestTime"] = 1633312845,
                ["wasAltered"] = true,
                ["newestTime"] = 1633312845,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3333,
                        ["guild"] = 1,
                        ["buyer"] = 39,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633312845,
                        ["quant"] = 1,
                        ["id"] = "1692878931",
                        ["itemLink"] = 32,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set plaguebreak frost staff two-handed charged",
            },
        },
        [177214] = 
        {
            ["1:0:4:42:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_battleaxe.dds",
                ["itemDesc"] = "Companion's Battle Axe",
                ["oldestTime"] = 1633282461,
                ["wasAltered"] = true,
                ["newestTime"] = 1633282461,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1940,
                        ["wasKiosk"] = true,
                        ["seller"] = 329,
                        ["timestamp"] = 1633282461,
                        ["quant"] = 1,
                        ["id"] = "1692540761",
                        ["itemLink"] = 2742,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic weapon axe two-handed vigorous",
            },
        },
        [172009] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_legs_a.dds",
                ["itemDesc"] = "Breeches of Frostbite",
                ["oldestTime"] = 1633189011,
                ["wasAltered"] = true,
                ["newestTime"] = 1633215996,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 180,
                        ["guild"] = 1,
                        ["buyer"] = 1409,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1633189011,
                        ["quant"] = 1,
                        ["id"] = "1691678201",
                        ["itemLink"] = 2090,
                    },
                    [2] = 
                    {
                        ["price"] = 1001,
                        ["guild"] = 1,
                        ["buyer"] = 327,
                        ["wasKiosk"] = false,
                        ["seller"] = 50,
                        ["timestamp"] = 1633215996,
                        ["quant"] = 1,
                        ["id"] = "1691968437",
                        ["itemLink"] = 2090,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior light apparel set frostbite legs well-fitted",
            },
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_legs_a.dds",
                ["itemDesc"] = "Breeches of Frostbite",
                ["oldestTime"] = 1633045839,
                ["wasAltered"] = true,
                ["newestTime"] = 1633045839,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 674,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633045839,
                        ["quant"] = 1,
                        ["id"] = "1690564963",
                        ["itemLink"] = 861,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set frostbite legs well-fitted",
            },
        },
        [95722] = 
        {
            ["24:0:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_medium_legs_a.dds",
                ["itemDesc"] = "Guards of the Air",
                ["oldestTime"] = 1632831792,
                ["wasAltered"] = true,
                ["newestTime"] = 1632831792,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1499,
                        ["guild"] = 1,
                        ["buyer"] = 412,
                        ["wasKiosk"] = true,
                        ["seller"] = 2140,
                        ["timestamp"] = 1632831792,
                        ["quant"] = 1,
                        ["id"] = "1689009757",
                        ["itemLink"] = 3089,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr24 blue superior medium apparel set way of air legs reinforced",
            },
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_medium_legs_a.dds",
                ["itemDesc"] = "Guards of the Air",
                ["oldestTime"] = 1633023031,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023031,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1633023031,
                        ["quant"] = 1,
                        ["id"] = "1690390903",
                        ["itemLink"] = 655,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set way of air legs reinforced",
            },
        },
        [97045] = 
        {
            ["50:16:2:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_staff_d.dds",
                ["itemDesc"] = "Plague Doctor's Inferno Staff",
                ["oldestTime"] = 1633038084,
                ["wasAltered"] = true,
                ["newestTime"] = 1633038084,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 613,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633038084,
                        ["quant"] = 1,
                        ["id"] = "1690499091",
                        ["itemLink"] = 778,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set plague doctor flame staff two-handed infused",
            },
        },
        [57068] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Hasphat's Sticky Guar Tonic",
                ["oldestTime"] = 1633052733,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242695,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 125,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633052733,
                        ["quant"] = 1,
                        ["id"] = "1690632383",
                        ["itemLink"] = 907,
                    },
                    [2] = 
                    {
                        ["price"] = 15,
                        ["guild"] = 1,
                        ["buyer"] = 348,
                        ["wasKiosk"] = false,
                        ["seller"] = 389,
                        ["timestamp"] = 1633242695,
                        ["quant"] = 1,
                        ["id"] = "1692215313",
                        ["itemLink"] = 907,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [135405] = 
        {
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_medium_waist_a.dds",
                ["itemDesc"] = "Gryphon's Belt",
                ["oldestTime"] = 1632922805,
                ["wasAltered"] = true,
                ["newestTime"] = 1632922805,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 535,
                        ["timestamp"] = 1632922805,
                        ["quant"] = 1,
                        ["id"] = "1689672079",
                        ["itemLink"] = 3669,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set gryphon's ferocity waist well-fitted",
            },
        },
        [166894] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing2.dds",
                ["itemDesc"] = "Diagram: Solitude Hammer, Simple",
                ["oldestTime"] = 1632538955,
                ["wasAltered"] = true,
                ["newestTime"] = 1632538955,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 2,
                        ["buyer"] = 119,
                        ["wasKiosk"] = false,
                        ["seller"] = 117,
                        ["timestamp"] = 1632538955,
                        ["quant"] = 1,
                        ["id"] = "1686536225",
                        ["itemLink"] = 96,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [95983] = 
        {
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_heavy_chest_d.dds",
                ["itemDesc"] = "Cuirass of the Trainee",
                ["oldestTime"] = 1633268841,
                ["wasAltered"] = true,
                ["newestTime"] = 1633268841,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2040,
                        ["guild"] = 1,
                        ["buyer"] = 483,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1633268841,
                        ["quant"] = 1,
                        ["id"] = "1692393333",
                        ["itemLink"] = 2660,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set armor of the trainee chest training",
            },
        },
        [45552] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Creme de Menthe",
                ["oldestTime"] = 1633140931,
                ["wasAltered"] = true,
                ["newestTime"] = 1633226239,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 88,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633140931,
                        ["quant"] = 1,
                        ["id"] = "1691300693",
                        ["itemLink"] = 1609,
                    },
                    [2] = 
                    {
                        ["price"] = 95,
                        ["guild"] = 1,
                        ["buyer"] = 839,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1633151692,
                        ["quant"] = 1,
                        ["id"] = "1691405561",
                        ["itemLink"] = 1609,
                    },
                    [3] = 
                    {
                        ["price"] = 88,
                        ["guild"] = 1,
                        ["buyer"] = 1651,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633226239,
                        ["quant"] = 1,
                        ["id"] = "1692076977",
                        ["itemLink"] = 1609,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [172136] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_chest_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Jack",
                ["oldestTime"] = 1633080966,
                ["wasAltered"] = true,
                ["newestTime"] = 1633080966,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 575,
                        ["guild"] = 1,
                        ["buyer"] = 884,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633080966,
                        ["quant"] = 1,
                        ["id"] = "1690839181",
                        ["itemLink"] = 1127,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set deadlands assassin chest infused",
            },
        },
        [135154] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/jewelrycrafting_booster_raw_chromium.dds",
                ["itemDesc"] = "Chromium Grains",
                ["oldestTime"] = 1632951161,
                ["wasAltered"] = true,
                ["newestTime"] = 1633280960,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40547,
                        ["guild"] = 1,
                        ["buyer"] = 555,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633028682,
                        ["quant"] = 2,
                        ["id"] = "1690435333",
                        ["itemLink"] = 692,
                    },
                    [2] = 
                    {
                        ["price"] = 19999,
                        ["guild"] = 1,
                        ["buyer"] = 769,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633057795,
                        ["quant"] = 1,
                        ["id"] = "1690688239",
                        ["itemLink"] = 692,
                    },
                    [3] = 
                    {
                        ["price"] = 19998,
                        ["guild"] = 1,
                        ["buyer"] = 1253,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633149806,
                        ["quant"] = 1,
                        ["id"] = "1691389081",
                        ["itemLink"] = 692,
                    },
                    [4] = 
                    {
                        ["price"] = 19998,
                        ["guild"] = 1,
                        ["buyer"] = 1253,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633149806,
                        ["quant"] = 1,
                        ["id"] = "1691389091",
                        ["itemLink"] = 692,
                    },
                    [5] = 
                    {
                        ["price"] = 19998,
                        ["guild"] = 1,
                        ["buyer"] = 1253,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633149807,
                        ["quant"] = 1,
                        ["id"] = "1691389095",
                        ["itemLink"] = 692,
                    },
                    [6] = 
                    {
                        ["price"] = 84000,
                        ["guild"] = 1,
                        ["buyer"] = 1253,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633149808,
                        ["quant"] = 4,
                        ["id"] = "1691389107",
                        ["itemLink"] = 692,
                    },
                    [7] = 
                    {
                        ["price"] = 19998,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633280960,
                        ["quant"] = 1,
                        ["id"] = "1692524457",
                        ["itemLink"] = 692,
                    },
                    [8] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 644,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1632951161,
                        ["quant"] = 1,
                        ["id"] = "1689883565",
                        ["itemLink"] = 692,
                    },
                    [9] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 644,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1632951162,
                        ["quant"] = 1,
                        ["id"] = "1689883569",
                        ["itemLink"] = 692,
                    },
                    [10] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 644,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1632951163,
                        ["quant"] = 1,
                        ["id"] = "1689883575",
                        ["itemLink"] = 692,
                    },
                },
                ["totalCount"] = 10,
                ["itemAdderText"] = "rr01 gold legendary materials raw plating",
            },
        },
        [125476] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_ashlander_r2.dds",
                ["itemDesc"] = "Ash Canvas",
                ["oldestTime"] = 1633135013,
                ["wasAltered"] = true,
                ["newestTime"] = 1633135013,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1136,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633135013,
                        ["quant"] = 13,
                        ["id"] = "1691241565",
                        ["itemLink"] = 1556,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [68209] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Longfin Pasty with Melon Sauce",
                ["oldestTime"] = 1632865322,
                ["wasAltered"] = true,
                ["newestTime"] = 1633070813,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 840,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633070813,
                        ["quant"] = 1,
                        ["id"] = "1690782475",
                        ["itemLink"] = 1084,
                    },
                    [2] = 
                    {
                        ["price"] = 9999,
                        ["guild"] = 1,
                        ["buyer"] = 2261,
                        ["wasKiosk"] = true,
                        ["seller"] = 2262,
                        ["timestamp"] = 1632865322,
                        ["quant"] = 1,
                        ["id"] = "1689266965",
                        ["itemLink"] = 1084,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [64501] = 
        {
            ["50:15:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_lorkhanstears.dds",
                ["itemDesc"] = "Lorkhan's Tears",
                ["oldestTime"] = 1632874013,
                ["wasAltered"] = true,
                ["newestTime"] = 1633215603,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1632981467,
                        ["quant"] = 200,
                        ["id"] = "1690139071",
                        ["itemLink"] = 285,
                    },
                    [2] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1632981467,
                        ["quant"] = 200,
                        ["id"] = "1690139079",
                        ["itemLink"] = 285,
                    },
                    [3] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1632981469,
                        ["quant"] = 200,
                        ["id"] = "1690139095",
                        ["itemLink"] = 285,
                    },
                    [4] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 786,
                        ["timestamp"] = 1633060245,
                        ["quant"] = 200,
                        ["id"] = "1690711901",
                        ["itemLink"] = 285,
                    },
                    [5] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 786,
                        ["timestamp"] = 1633060246,
                        ["quant"] = 200,
                        ["id"] = "1690711907",
                        ["itemLink"] = 285,
                    },
                    [6] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 786,
                        ["timestamp"] = 1633060247,
                        ["quant"] = 200,
                        ["id"] = "1690711913",
                        ["itemLink"] = 285,
                    },
                    [7] = 
                    {
                        ["price"] = 4200,
                        ["guild"] = 1,
                        ["buyer"] = 1093,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633215603,
                        ["quant"] = 200,
                        ["id"] = "1691963863",
                        ["itemLink"] = 285,
                    },
                    [8] = 
                    {
                        ["price"] = 5995,
                        ["guild"] = 1,
                        ["buyer"] = 151,
                        ["wasKiosk"] = false,
                        ["seller"] = 322,
                        ["timestamp"] = 1632874013,
                        ["quant"] = 200,
                        ["id"] = "1689331341",
                        ["itemLink"] = 285,
                    },
                    [9] = 
                    {
                        ["price"] = 2240,
                        ["guild"] = 1,
                        ["buyer"] = 436,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632964564,
                        ["quant"] = 112,
                        ["id"] = "1690001057",
                        ["itemLink"] = 285,
                    },
                },
                ["totalCount"] = 9,
                ["itemAdderText"] = "cp150 white normal materials potion solvent",
            },
        },
        [167980] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 97: Wayward Guardian Boots",
                ["oldestTime"] = 1633097780,
                ["wasAltered"] = true,
                ["newestTime"] = 1633097780,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19000,
                        ["guild"] = 1,
                        ["buyer"] = 933,
                        ["wasKiosk"] = true,
                        ["seller"] = 894,
                        ["timestamp"] = 1633097780,
                        ["quant"] = 1,
                        ["id"] = "1690942235",
                        ["itemLink"] = 1270,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [153698] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_cwc_str_wayshrinedungeon001.dds",
                ["itemDesc"] = "Clockwork Orrery, Simple",
                ["oldestTime"] = 1633220801,
                ["wasAltered"] = true,
                ["newestTime"] = 1633220801,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 38998,
                        ["guild"] = 1,
                        ["buyer"] = 668,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633220801,
                        ["quant"] = 1,
                        ["id"] = "1692020125",
                        ["itemLink"] = 2346,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings workshop",
            },
        },
        [132585] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 57: Ebonshadow Bows",
                ["oldestTime"] = 1633214030,
                ["wasAltered"] = true,
                ["newestTime"] = 1633214030,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3800,
                        ["guild"] = 1,
                        ["buyer"] = 1571,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633214030,
                        ["quant"] = 1,
                        ["id"] = "1691949945",
                        ["itemLink"] = 2294,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [149241] = 
        {
            ["45:0:2:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Crafty Alfiq's Amulet",
                ["oldestTime"] = 1632793705,
                ["wasAltered"] = true,
                ["newestTime"] = 1632793705,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 2,
                        ["buyer"] = 131,
                        ["wasKiosk"] = false,
                        ["seller"] = 125,
                        ["timestamp"] = 1632793705,
                        ["quant"] = 1,
                        ["id"] = "1688754549",
                        ["itemLink"] = 130,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr45 green fine jewelry apparel set crafty alfiq neck arcane",
            },
        },
        [77050] = 
        {
            ["50:16:2:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_minotaur_heavy_feet_a.dds",
                ["itemDesc"] = "Sabatons of Morihaus",
                ["oldestTime"] = 1632965052,
                ["wasAltered"] = true,
                ["newestTime"] = 1632965052,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 646,
                        ["guild"] = 1,
                        ["buyer"] = 2654,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1632965052,
                        ["quant"] = 1,
                        ["id"] = "1690007061",
                        ["itemLink"] = 3952,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set hide of morihaus feet sturdy",
            },
        },
        [71675] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 28: Ra Gada Boots",
                ["oldestTime"] = 1633027569,
                ["wasAltered"] = true,
                ["newestTime"] = 1633290244,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2198,
                        ["guild"] = 1,
                        ["buyer"] = 548,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633027569,
                        ["quant"] = 1,
                        ["id"] = "1690424477",
                        ["itemLink"] = 688,
                    },
                    [2] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 1586,
                        ["wasKiosk"] = true,
                        ["seller"] = 711,
                        ["timestamp"] = 1633215807,
                        ["quant"] = 1,
                        ["id"] = "1691966131",
                        ["itemLink"] = 688,
                    },
                    [3] = 
                    {
                        ["price"] = 1229,
                        ["guild"] = 1,
                        ["buyer"] = 74,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1633290244,
                        ["quant"] = 1,
                        ["id"] = "1692630235",
                        ["itemLink"] = 688,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [56060] = 
        {
            ["1:0:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_shield_a.dds",
                ["itemDesc"] = "Maple Shield",
                ["oldestTime"] = 1632952987,
                ["wasAltered"] = true,
                ["newestTime"] = 1633277795,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 902,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633087006,
                        ["quant"] = 1,
                        ["id"] = "1690869225",
                        ["itemLink"] = 1226,
                    },
                    [2] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 1456,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633196587,
                        ["quant"] = 1,
                        ["id"] = "1691754725",
                        ["itemLink"] = 1226,
                    },
                    [3] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1459,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633196776,
                        ["quant"] = 1,
                        ["id"] = "1691756249",
                        ["itemLink"] = 1226,
                    },
                    [4] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1897,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633277795,
                        ["quant"] = 1,
                        ["id"] = "1692493447",
                        ["itemLink"] = 1226,
                    },
                    [5] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 819,
                        ["wasKiosk"] = false,
                        ["seller"] = 207,
                        ["timestamp"] = 1632952987,
                        ["quant"] = 1,
                        ["id"] = "1689901469",
                        ["itemLink"] = 1226,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 white normal apparel weapon shield off hand nirnhoned",
            },
        },
        [121341] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 50: Telvanni Legs",
                ["oldestTime"] = 1633229683,
                ["wasAltered"] = true,
                ["newestTime"] = 1633229683,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1684,
                        ["wasKiosk"] = true,
                        ["seller"] = 1214,
                        ["timestamp"] = 1633229683,
                        ["quant"] = 1,
                        ["id"] = "1692112603",
                        ["itemLink"] = 2436,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [172030] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_legs_a.dds",
                ["itemDesc"] = "Breeches of Frostbite",
                ["oldestTime"] = 1633278916,
                ["wasAltered"] = true,
                ["newestTime"] = 1633278916,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 655,
                        ["guild"] = 1,
                        ["buyer"] = 1159,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1633278916,
                        ["quant"] = 1,
                        ["id"] = "1692504341",
                        ["itemLink"] = 2725,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set frostbite legs reinforced",
            },
        },
        [76895] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 38: Draugr Axes",
                ["oldestTime"] = 1633058146,
                ["wasAltered"] = true,
                ["newestTime"] = 1633058146,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 709,
                        ["timestamp"] = 1633058146,
                        ["quant"] = 1,
                        ["id"] = "1690691601",
                        ["itemLink"] = 985,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
    },
}
