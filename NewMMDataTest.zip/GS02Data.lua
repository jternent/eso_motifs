GS02DataSavedVariables =
{
    ["listingseu"] = 
    {
    },
    ["listingsna"] = 
    {
    },
    ["dataeu"] = 
    {
    },
    ["datana"] = 
    {
        [132864] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_apostle_light_feet_a.dds",
                ["itemDesc"] = "Mad Tinkerer's Shoes",
                ["oldestTime"] = 1632902634,
                ["wasAltered"] = true,
                ["newestTime"] = 1632902634,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2450,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632902634,
                        ["quant"] = 1,
                        ["id"] = "1689572339",
                        ["itemLink"] = 3579,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set mad tinkerer feet infused",
            },
        },
        [147716] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 74: Pellitine Belts",
                ["oldestTime"] = 1632821684,
                ["wasAltered"] = true,
                ["newestTime"] = 1632821684,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 633,
                        ["timestamp"] = 1632821684,
                        ["quant"] = 1,
                        ["id"] = "1688950419",
                        ["itemLink"] = 3015,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [121350] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 49: Militant Ordinator Belts",
                ["oldestTime"] = 1633005809,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292552,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 419,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633005809,
                        ["quant"] = 1,
                        ["id"] = "1690264067",
                        ["itemLink"] = 429,
                    },
                    [2] = 
                    {
                        ["price"] = 99000,
                        ["guild"] = 1,
                        ["buyer"] = 874,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633076994,
                        ["quant"] = 1,
                        ["id"] = "1690821487",
                        ["itemLink"] = 429,
                    },
                    [3] = 
                    {
                        ["price"] = 99000,
                        ["guild"] = 1,
                        ["buyer"] = 1265,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633151585,
                        ["quant"] = 1,
                        ["id"] = "1691405001",
                        ["itemLink"] = 429,
                    },
                    [4] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 550,
                        ["wasKiosk"] = false,
                        ["seller"] = 26,
                        ["timestamp"] = 1633275383,
                        ["quant"] = 1,
                        ["id"] = "1692468141",
                        ["itemLink"] = 429,
                    },
                    [5] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633292552,
                        ["quant"] = 1,
                        ["id"] = "1692658205",
                        ["itemLink"] = 429,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [142600] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Bright-Throat's Boast Ring",
                ["oldestTime"] = 1633276410,
                ["wasAltered"] = true,
                ["newestTime"] = 1633276410,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19999,
                        ["guild"] = 1,
                        ["buyer"] = 1904,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1633276410,
                        ["quant"] = 1,
                        ["id"] = "1692479679",
                        ["itemLink"] = 2703,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set bright-throat's boast ring arcane",
            },
            ["50:16:5:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Bright-Throat's Boast Ring",
                ["oldestTime"] = 1633285688,
                ["wasAltered"] = true,
                ["newestTime"] = 1633285688,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 175000,
                        ["guild"] = 1,
                        ["buyer"] = 1953,
                        ["wasKiosk"] = true,
                        ["seller"] = 431,
                        ["timestamp"] = 1633285688,
                        ["quant"] = 1,
                        ["id"] = "1692573335",
                        ["itemLink"] = 2756,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary jewelry apparel set bright-throat's boast ring arcane",
            },
        },
        [171273] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Style Page: Opal Iceheart Shield",
                ["oldestTime"] = 1633310242,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310242,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 44999,
                        ["guild"] = 1,
                        ["buyer"] = 2088,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633310242,
                        ["quant"] = 1,
                        ["id"] = "1692851421",
                        ["itemLink"] = 2992,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [139019] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_celestial_r1.dds",
                ["itemDesc"] = "Powdered Mother of Pearl",
                ["oldestTime"] = 1632827412,
                ["wasAltered"] = true,
                ["newestTime"] = 1633127397,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 178,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1632971188,
                        ["quant"] = 1,
                        ["id"] = "1690067721",
                        ["itemLink"] = 193,
                    },
                    [2] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632981490,
                        ["quant"] = 5,
                        ["id"] = "1690139165",
                        ["itemLink"] = 193,
                    },
                    [3] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 692,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1633049229,
                        ["quant"] = 5,
                        ["id"] = "1690597197",
                        ["itemLink"] = 193,
                    },
                    [4] = 
                    {
                        ["price"] = 80000,
                        ["guild"] = 1,
                        ["buyer"] = 616,
                        ["wasKiosk"] = false,
                        ["seller"] = 700,
                        ["timestamp"] = 1633061767,
                        ["quant"] = 20,
                        ["id"] = "1690723697",
                        ["itemLink"] = 193,
                    },
                    [5] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 585,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633089767,
                        ["quant"] = 10,
                        ["id"] = "1690887257",
                        ["itemLink"] = 193,
                    },
                    [6] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 585,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633089769,
                        ["quant"] = 10,
                        ["id"] = "1690887259",
                        ["itemLink"] = 193,
                    },
                    [7] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 585,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633089770,
                        ["quant"] = 10,
                        ["id"] = "1690887263",
                        ["itemLink"] = 193,
                    },
                    [8] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1093,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633127397,
                        ["quant"] = 10,
                        ["id"] = "1691162385",
                        ["itemLink"] = 193,
                    },
                    [9] = 
                    {
                        ["price"] = 29600,
                        ["guild"] = 1,
                        ["buyer"] = 2126,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1632827412,
                        ["quant"] = 8,
                        ["id"] = "1688978091",
                        ["itemLink"] = 193,
                    },
                    [10] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 2465,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632912112,
                        ["quant"] = 5,
                        ["id"] = "1689608493",
                        ["itemLink"] = 193,
                    },
                    [11] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1632963929,
                        ["quant"] = 5,
                        ["id"] = "1689994909",
                        ["itemLink"] = 193,
                    },
                },
                ["totalCount"] = 11,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [175628] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_inc_leybox001.dds",
                ["itemDesc"] = "Leyawiin Jewelry Box, Gilded",
                ["oldestTime"] = 1633165933,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165933,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 1128,
                        ["timestamp"] = 1633165933,
                        ["quant"] = 1,
                        ["id"] = "1691500101",
                        ["itemLink"] = 1851,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings parlor",
            },
        },
        [97549] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_medium_waist_d.dds",
                ["itemDesc"] = "Belt of the Wilderqueen",
                ["oldestTime"] = 1632868623,
                ["wasAltered"] = true,
                ["newestTime"] = 1632868623,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 507,
                        ["guild"] = 1,
                        ["buyer"] = 2280,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1632868623,
                        ["quant"] = 1,
                        ["id"] = "1689291959",
                        ["itemLink"] = 3372,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set wilderqueen's arch waist sturdy",
            },
        },
        [167184] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 92: Ancestral Akaviri Shields",
                ["oldestTime"] = 1633292578,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292578,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633292578,
                        ["quant"] = 1,
                        ["id"] = "1692658491",
                        ["itemLink"] = 2844,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45841] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_013.dds",
                ["itemDesc"] = "Haoko",
                ["oldestTime"] = 1632844972,
                ["wasAltered"] = true,
                ["newestTime"] = 1633281979,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 245,
                        ["guild"] = 1,
                        ["buyer"] = 250,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632978534,
                        ["quant"] = 4,
                        ["id"] = "1690122451",
                        ["itemLink"] = 254,
                    },
                    [2] = 
                    {
                        ["price"] = 248,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1633194025,
                        ["quant"] = 4,
                        ["id"] = "1691735279",
                        ["itemLink"] = 254,
                    },
                    [3] = 
                    {
                        ["price"] = 544,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1633281979,
                        ["quant"] = 9,
                        ["id"] = "1692536829",
                        ["itemLink"] = 254,
                    },
                    [4] = 
                    {
                        ["price"] = 870,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1632844972,
                        ["quant"] = 14,
                        ["id"] = "1689099651",
                        ["itemLink"] = 254,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 white normal materials essence runestone",
            },
        },
        [34323] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_corn.dds",
                ["itemDesc"] = "Corn",
                ["oldestTime"] = 1633035782,
                ["wasAltered"] = true,
                ["newestTime"] = 1633042318,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2399,
                        ["guild"] = 1,
                        ["buyer"] = 601,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633035782,
                        ["quant"] = 200,
                        ["id"] = "1690481197",
                        ["itemLink"] = 771,
                    },
                    [2] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 601,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633035784,
                        ["quant"] = 200,
                        ["id"] = "1690481201",
                        ["itemLink"] = 771,
                    },
                    [3] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 648,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1633042318,
                        ["quant"] = 100,
                        ["id"] = "1690531167",
                        ["itemLink"] = 771,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [134420] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_cwc_str_planetariumsealthief001.dds",
                ["itemDesc"] = "Clockwork Calibration Guide, The Thief",
                ["oldestTime"] = 1632879966,
                ["wasAltered"] = true,
                ["newestTime"] = 1632879966,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 87000,
                        ["guild"] = 1,
                        ["buyer"] = 2331,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632879966,
                        ["quant"] = 1,
                        ["id"] = "1689396419",
                        ["itemLink"] = 3454,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings structures",
            },
        },
        [149525] = 
        {
            ["50:16:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_shield_a.dds",
                ["itemDesc"] = "Darloc Brae's Shield",
                ["oldestTime"] = 1633045864,
                ["wasAltered"] = true,
                ["newestTime"] = 1633045864,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 674,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1633045864,
                        ["quant"] = 1,
                        ["id"] = "1690565157",
                        ["itemLink"] = 863,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine apparel weapon set vesture of darloc brae shield off hand impenetrable",
            },
        },
        [98327] = 
        {
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Beekeeper's Ring",
                ["oldestTime"] = 1633087784,
                ["wasAltered"] = true,
                ["newestTime"] = 1633087784,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 909,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1633087784,
                        ["quant"] = 1,
                        ["id"] = "1690875067",
                        ["itemLink"] = 1230,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set beekeeper's gear ring healthy",
            },
        },
        [68632] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_heavy_hands_a.dds",
                ["itemDesc"] = "Gauntlets of the Pariah",
                ["oldestTime"] = 1633151826,
                ["wasAltered"] = true,
                ["newestTime"] = 1633151826,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9500,
                        ["guild"] = 1,
                        ["buyer"] = 1267,
                        ["wasKiosk"] = true,
                        ["seller"] = 696,
                        ["timestamp"] = 1633151826,
                        ["quant"] = 1,
                        ["id"] = "1691406533",
                        ["itemLink"] = 1736,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set mark of the pariah hands well-fitted",
            },
        },
        [45083] = 
        {
            ["50:16:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_shield_d.dds",
                ["itemDesc"] = "Ruby Ash Shield of Health",
                ["oldestTime"] = 1633186007,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186007,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633186007,
                        ["quant"] = 1,
                        ["id"] = "1691640681",
                        ["itemLink"] = 2056,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine apparel weapon shield off hand impenetrable",
            },
        },
        [68636] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_heavy_waist_a.dds",
                ["itemDesc"] = "Girdle of the Pariah",
                ["oldestTime"] = 1633151788,
                ["wasAltered"] = true,
                ["newestTime"] = 1633151788,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3200,
                        ["guild"] = 1,
                        ["buyer"] = 1267,
                        ["wasKiosk"] = true,
                        ["seller"] = 377,
                        ["timestamp"] = 1633151788,
                        ["quant"] = 1,
                        ["id"] = "1691406217",
                        ["itemLink"] = 1735,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set mark of the pariah waist well-fitted",
            },
        },
        [119070] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing3.dds",
                ["itemDesc"] = "Diagram: Orcish Sconce, Caged",
                ["oldestTime"] = 1632867311,
                ["wasAltered"] = true,
                ["newestTime"] = 1632867311,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2274,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1632867311,
                        ["quant"] = 1,
                        ["id"] = "1689283325",
                        ["itemLink"] = 3363,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [123423] = 
        {
            ["50:16:4:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_medium_chest_a.dds",
                ["itemDesc"] = "Coward's Gear Jack",
                ["oldestTime"] = 1633139655,
                ["wasAltered"] = true,
                ["newestTime"] = 1633139655,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 1177,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1633139655,
                        ["quant"] = 1,
                        ["id"] = "1691287019",
                        ["itemLink"] = 1593,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set coward's gear chest reinforced",
            },
        },
        [172320] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_shield_a.dds",
                ["itemDesc"] = "Bog Raider's Shield",
                ["oldestTime"] = 1633200610,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200610,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 619,
                        ["guild"] = 1,
                        ["buyer"] = 1490,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1633200610,
                        ["quant"] = 1,
                        ["id"] = "1691796037",
                        ["itemLink"] = 2192,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior apparel weapon set bog raider shield off hand divines",
            },
        },
        [167969] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 96: Arkthzand Armory Legs",
                ["oldestTime"] = 1633200283,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200283,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1487,
                        ["wasKiosk"] = true,
                        ["seller"] = 1455,
                        ["timestamp"] = 1633200283,
                        ["quant"] = 1,
                        ["id"] = "1691792979",
                        ["itemLink"] = 2185,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [160547] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 85: Greymoor Chests",
                ["oldestTime"] = 1633001280,
                ["wasAltered"] = true,
                ["newestTime"] = 1633036113,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 404,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633001280,
                        ["quant"] = 1,
                        ["id"] = "1690240683",
                        ["itemLink"] = 411,
                    },
                    [2] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 602,
                        ["wasKiosk"] = true,
                        ["seller"] = 603,
                        ["timestamp"] = 1633036113,
                        ["quant"] = 1,
                        ["id"] = "1690484769",
                        ["itemLink"] = 411,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45349] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_light_hands_d.dds",
                ["itemDesc"] = "Ancestor Silk Gloves",
                ["oldestTime"] = 1632841094,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185995,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 864,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633009368,
                        ["quant"] = 1,
                        ["id"] = "1690285473",
                        ["itemLink"] = 483,
                    },
                    [2] = 
                    {
                        ["price"] = 864,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633009371,
                        ["quant"] = 1,
                        ["id"] = "1690285493",
                        ["itemLink"] = 486,
                    },
                    [3] = 
                    {
                        ["price"] = 310,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633084077,
                        ["quant"] = 1,
                        ["id"] = "1690854893",
                        ["itemLink"] = 486,
                    },
                    [4] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084083,
                        ["quant"] = 1,
                        ["id"] = "1690854957",
                        ["itemLink"] = 1178,
                    },
                    [5] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084099,
                        ["quant"] = 1,
                        ["id"] = "1690855011",
                        ["itemLink"] = 1178,
                    },
                    [6] = 
                    {
                        ["price"] = 185,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633146936,
                        ["quant"] = 1,
                        ["id"] = "1691365329",
                        ["itemLink"] = 1667,
                    },
                    [7] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633185987,
                        ["quant"] = 1,
                        ["id"] = "1691640585",
                        ["itemLink"] = 2047,
                    },
                    [8] = 
                    {
                        ["price"] = 271,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633185995,
                        ["quant"] = 1,
                        ["id"] = "1691640625",
                        ["itemLink"] = 2049,
                    },
                    [9] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632841094,
                        ["quant"] = 1,
                        ["id"] = "1689067915",
                        ["itemLink"] = 2047,
                    },
                    [10] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632841096,
                        ["quant"] = 1,
                        ["id"] = "1689067945",
                        ["itemLink"] = 3152,
                    },
                    [11] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632843186,
                        ["quant"] = 1,
                        ["id"] = "1689085291",
                        ["itemLink"] = 483,
                    },
                    [12] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2501,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1632930587,
                        ["quant"] = 1,
                        ["id"] = "1689726385",
                        ["itemLink"] = 483,
                    },
                },
                ["totalCount"] = 12,
                ["itemAdderText"] = "cp160 white normal light apparel hands intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_light_hands_d.dds",
                ["itemDesc"] = "Ancestor Silk Gloves",
                ["oldestTime"] = 1632843183,
                ["wasAltered"] = true,
                ["newestTime"] = 1633268079,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 780,
                        ["wasKiosk"] = true,
                        ["seller"] = 42,
                        ["timestamp"] = 1633059420,
                        ["quant"] = 1,
                        ["id"] = "1690704567",
                        ["itemLink"] = 992,
                    },
                    [2] = 
                    {
                        ["price"] = 125,
                        ["guild"] = 1,
                        ["buyer"] = 1001,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633268079,
                        ["quant"] = 1,
                        ["id"] = "1692385979",
                        ["itemLink"] = 2654,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632843183,
                        ["quant"] = 1,
                        ["id"] = "1689085271",
                        ["itemLink"] = 3177,
                    },
                    [4] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1632843202,
                        ["quant"] = 1,
                        ["id"] = "1689085383",
                        ["itemLink"] = 3182,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp150 white normal light apparel hands intricate",
            },
        },
        [95271] = 
        {
            ["50:16:2:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of the Fire",
                ["oldestTime"] = 1633200727,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200727,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1491,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633200727,
                        ["quant"] = 1,
                        ["id"] = "1691797119",
                        ["itemLink"] = 2193,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set way of fire neck healthy",
            },
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of the Fire",
                ["oldestTime"] = 1633163912,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163922,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633163912,
                        ["quant"] = 1,
                        ["id"] = "1691490321",
                        ["itemLink"] = 1807,
                    },
                    [2] = 
                    {
                        ["price"] = 1997,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 600,
                        ["timestamp"] = 1633163922,
                        ["quant"] = 1,
                        ["id"] = "1691490395",
                        ["itemLink"] = 1807,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set way of fire neck healthy",
            },
        },
        [167976] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_arkthzand_armory.dds",
                ["itemDesc"] = "Arkthzand Sprocket",
                ["oldestTime"] = 1632938583,
                ["wasAltered"] = true,
                ["newestTime"] = 1633218208,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 480,
                        ["wasKiosk"] = true,
                        ["seller"] = 163,
                        ["timestamp"] = 1633016876,
                        ["quant"] = 2,
                        ["id"] = "1690340217",
                        ["itemLink"] = 546,
                    },
                    [2] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 741,
                        ["wasKiosk"] = true,
                        ["seller"] = 732,
                        ["timestamp"] = 1633054698,
                        ["quant"] = 2,
                        ["id"] = "1690651757",
                        ["itemLink"] = 546,
                    },
                    [3] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 741,
                        ["wasKiosk"] = true,
                        ["seller"] = 732,
                        ["timestamp"] = 1633054698,
                        ["quant"] = 2,
                        ["id"] = "1690651767",
                        ["itemLink"] = 546,
                    },
                    [4] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 741,
                        ["wasKiosk"] = true,
                        ["seller"] = 732,
                        ["timestamp"] = 1633054699,
                        ["quant"] = 2,
                        ["id"] = "1690651779",
                        ["itemLink"] = 546,
                    },
                    [5] = 
                    {
                        ["price"] = 89970,
                        ["guild"] = 1,
                        ["buyer"] = 1415,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633190177,
                        ["quant"] = 30,
                        ["id"] = "1691689729",
                        ["itemLink"] = 546,
                    },
                    [6] = 
                    {
                        ["price"] = 32800,
                        ["guild"] = 1,
                        ["buyer"] = 1415,
                        ["wasKiosk"] = true,
                        ["seller"] = 271,
                        ["timestamp"] = 1633190179,
                        ["quant"] = 10,
                        ["id"] = "1691689769",
                        ["itemLink"] = 546,
                    },
                    [7] = 
                    {
                        ["price"] = 36000,
                        ["guild"] = 1,
                        ["buyer"] = 508,
                        ["wasKiosk"] = false,
                        ["seller"] = 957,
                        ["timestamp"] = 1633211182,
                        ["quant"] = 12,
                        ["id"] = "1691917265",
                        ["itemLink"] = 546,
                    },
                    [8] = 
                    {
                        ["price"] = 38000,
                        ["guild"] = 1,
                        ["buyer"] = 1597,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633218208,
                        ["quant"] = 10,
                        ["id"] = "1691992681",
                        ["itemLink"] = 546,
                    },
                    [9] = 
                    {
                        ["price"] = 95000,
                        ["guild"] = 1,
                        ["buyer"] = 1142,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632938583,
                        ["quant"] = 25,
                        ["id"] = "1689785057",
                        ["itemLink"] = 546,
                    },
                },
                ["totalCount"] = 9,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [149546] = 
        {
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_medium_chest_a.dds",
                ["itemDesc"] = "Darloc Brae's Jack",
                ["oldestTime"] = 1632869441,
                ["wasAltered"] = true,
                ["newestTime"] = 1632869441,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1441,
                        ["wasKiosk"] = true,
                        ["seller"] = 697,
                        ["timestamp"] = 1632869441,
                        ["quant"] = 1,
                        ["id"] = "1689299367",
                        ["itemLink"] = 3379,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set vesture of darloc brae chest invigorating",
            },
        },
        [166443] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_inc_vampirepainting007.dds",
                ["itemDesc"] = "Contrasts Painting, Brass",
                ["oldestTime"] = 1633148141,
                ["wasAltered"] = true,
                ["newestTime"] = 1633148141,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 332,
                        ["timestamp"] = 1633148141,
                        ["quant"] = 1,
                        ["id"] = "1691375235",
                        ["itemLink"] = 1695,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings gallery",
            },
        },
        [812] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_cloth_base_jute_r1.dds",
                ["itemDesc"] = "Raw Jute",
                ["oldestTime"] = 1632983110,
                ["wasAltered"] = true,
                ["newestTime"] = 1633247640,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632983110,
                        ["quant"] = 200,
                        ["id"] = "1690148317",
                        ["itemLink"] = 299,
                    },
                    [2] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632983110,
                        ["quant"] = 200,
                        ["id"] = "1690148321",
                        ["itemLink"] = 299,
                    },
                    [3] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632983113,
                        ["quant"] = 180,
                        ["id"] = "1690148337",
                        ["itemLink"] = 299,
                    },
                    [4] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1389,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633185023,
                        ["quant"] = 200,
                        ["id"] = "1691629349",
                        ["itemLink"] = 299,
                    },
                    [5] = 
                    {
                        ["price"] = 13400,
                        ["guild"] = 1,
                        ["buyer"] = 1389,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633185027,
                        ["quant"] = 134,
                        ["id"] = "1691629385",
                        ["itemLink"] = 299,
                    },
                    [6] = 
                    {
                        ["price"] = 3100,
                        ["guild"] = 1,
                        ["buyer"] = 1805,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633247640,
                        ["quant"] = 62,
                        ["id"] = "1692255529",
                        ["itemLink"] = 299,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [34349] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_acai_berry.dds",
                ["itemDesc"] = "Acai Berry",
                ["oldestTime"] = 1633197910,
                ["wasAltered"] = true,
                ["newestTime"] = 1633197910,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 704,
                        ["guild"] = 1,
                        ["buyer"] = 1467,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633197910,
                        ["quant"] = 100,
                        ["id"] = "1691768437",
                        ["itemLink"] = 2156,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [139311] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_exc_housingplanter001.dds",
                ["itemDesc"] = "Alinor Windowbox, Blue Wisteria",
                ["oldestTime"] = 1633050431,
                ["wasAltered"] = true,
                ["newestTime"] = 1633050433,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 699,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633050431,
                        ["quant"] = 2,
                        ["id"] = "1690609385",
                        ["itemLink"] = 890,
                    },
                    [2] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 699,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633050433,
                        ["quant"] = 2,
                        ["id"] = "1690609395",
                        ["itemLink"] = 890,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings conservatory",
            },
        },
        [160560] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 86: Sea Giant Axes",
                ["oldestTime"] = 1633255097,
                ["wasAltered"] = true,
                ["newestTime"] = 1633255097,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15777,
                        ["guild"] = 1,
                        ["buyer"] = 973,
                        ["wasKiosk"] = true,
                        ["seller"] = 765,
                        ["timestamp"] = 1633255097,
                        ["quant"] = 1,
                        ["id"] = "1692301669",
                        ["itemLink"] = 2614,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [152113] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Elsweyr Platform, Stepped",
                ["oldestTime"] = 1633071527,
                ["wasAltered"] = true,
                ["newestTime"] = 1633071527,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 846,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1633071527,
                        ["quant"] = 2,
                        ["id"] = "1690787797",
                        ["itemLink"] = 1089,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [175668] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_inc_housingleyplantpotaspentree001.dds",
                ["itemDesc"] = "Leyawiin Potted Plant, Aspen Sapling",
                ["oldestTime"] = 1633113859,
                ["wasAltered"] = true,
                ["newestTime"] = 1633116297,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1005,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633113859,
                        ["quant"] = 1,
                        ["id"] = "1691064521",
                        ["itemLink"] = 1371,
                    },
                    [2] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1005,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633113860,
                        ["quant"] = 1,
                        ["id"] = "1691064535",
                        ["itemLink"] = 1371,
                    },
                    [3] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1005,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633113861,
                        ["quant"] = 1,
                        ["id"] = "1691064549",
                        ["itemLink"] = 1371,
                    },
                    [4] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1005,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633113862,
                        ["quant"] = 1,
                        ["id"] = "1691064571",
                        ["itemLink"] = 1371,
                    },
                    [5] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1027,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633116297,
                        ["quant"] = 1,
                        ["id"] = "1691080553",
                        ["itemLink"] = 1371,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 blue superior furnishings conservatory",
            },
        },
        [74551] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 32: Abah's Watch Shoulders",
                ["oldestTime"] = 1633143437,
                ["wasAltered"] = true,
                ["newestTime"] = 1633143437,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 21999,
                        ["guild"] = 1,
                        ["buyer"] = 1213,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633143437,
                        ["quant"] = 1,
                        ["id"] = "1691330993",
                        ["itemLink"] = 1639,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [127033] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Hlaalu Mat, Welcoming",
                ["oldestTime"] = 1633289471,
                ["wasAltered"] = true,
                ["newestTime"] = 1633289471,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 202,
                        ["wasKiosk"] = false,
                        ["seller"] = 288,
                        ["timestamp"] = 1633289471,
                        ["quant"] = 1,
                        ["id"] = "1692621097",
                        ["itemLink"] = 2776,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [116029] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Dark Elf Wagon, Merchant",
                ["oldestTime"] = 1632930606,
                ["wasAltered"] = true,
                ["newestTime"] = 1632930606,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2194,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632930606,
                        ["quant"] = 1,
                        ["id"] = "1689726595",
                        ["itemLink"] = 3705,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [46142] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_wood_sanded_nightwood.dds",
                ["itemDesc"] = "Sanded Nightwood",
                ["oldestTime"] = 1632648262,
                ["wasAltered"] = true,
                ["newestTime"] = 1632648262,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 2,
                        ["buyer"] = 126,
                        ["wasKiosk"] = false,
                        ["seller"] = 115,
                        ["timestamp"] = 1632648262,
                        ["quant"] = 70,
                        ["id"] = "1687483665",
                        ["itemLink"] = 103,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [134465] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_ayl_duc_varlastone01.dds",
                ["itemDesc"] = "Varla Stone, Glowing",
                ["oldestTime"] = 1633247136,
                ["wasAltered"] = true,
                ["newestTime"] = 1633247136,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 41250,
                        ["guild"] = 1,
                        ["buyer"] = 1804,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633247136,
                        ["quant"] = 5,
                        ["id"] = "1692250435",
                        ["itemLink"] = 2583,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [45636] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Melon Carpaccio",
                ["oldestTime"] = 1633094986,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294708,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 924,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633094986,
                        ["quant"] = 1,
                        ["id"] = "1690919151",
                        ["itemLink"] = 1259,
                    },
                    [2] = 
                    {
                        ["price"] = 70,
                        ["guild"] = 1,
                        ["buyer"] = 1427,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633294708,
                        ["quant"] = 1,
                        ["id"] = "1692686577",
                        ["itemLink"] = 1259,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [123463] = 
        {
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_medium_chest_a.dds",
                ["itemDesc"] = "Coward's Gear Jack",
                ["oldestTime"] = 1632830308,
                ["wasAltered"] = true,
                ["newestTime"] = 1632830308,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2134,
                        ["wasKiosk"] = true,
                        ["seller"] = 531,
                        ["timestamp"] = 1632830308,
                        ["quant"] = 1,
                        ["id"] = "1689000343",
                        ["itemLink"] = 3071,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set coward's gear chest invigorating",
            },
        },
        [26954] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_spice_003.dds",
                ["itemDesc"] = "Garlic",
                ["oldestTime"] = 1632861577,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305853,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 648,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633042307,
                        ["quant"] = 200,
                        ["id"] = "1690531099",
                        ["itemLink"] = 823,
                    },
                    [2] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633305853,
                        ["quant"] = 200,
                        ["id"] = "1692798975",
                        ["itemLink"] = 823,
                    },
                    [3] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632861577,
                        ["quant"] = 200,
                        ["id"] = "1689241583",
                        ["itemLink"] = 823,
                    },
                    [4] = 
                    {
                        ["price"] = 2113,
                        ["guild"] = 1,
                        ["buyer"] = 2666,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1632967636,
                        ["quant"] = 200,
                        ["id"] = "1690030211",
                        ["itemLink"] = 823,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [116046] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_alchemy3.dds",
                ["itemDesc"] = "Formula: Dark Elf Cruet, Glass",
                ["oldestTime"] = 1633040323,
                ["wasAltered"] = true,
                ["newestTime"] = 1633040323,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 623,
                        ["wasKiosk"] = true,
                        ["seller"] = 624,
                        ["timestamp"] = 1633040323,
                        ["quant"] = 1,
                        ["id"] = "1690515707",
                        ["itemLink"] = 791,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [175951] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Nightstand, Formal",
                ["oldestTime"] = 1633060363,
                ["wasAltered"] = true,
                ["newestTime"] = 1633060363,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 709,
                        ["timestamp"] = 1633060363,
                        ["quant"] = 1,
                        ["id"] = "1690713379",
                        ["itemLink"] = 1008,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [180819] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_shield_a.dds",
                ["itemDesc"] = "Hrothgar's Shield",
                ["oldestTime"] = 1632937192,
                ["wasAltered"] = true,
                ["newestTime"] = 1632937192,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4321,
                        ["guild"] = 1,
                        ["buyer"] = 2531,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1632937192,
                        ["quant"] = 1,
                        ["id"] = "1689775711",
                        ["itemLink"] = 3751,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior apparel weapon set hrothgar's chill shield off hand well-fitted",
            },
        },
        [51542] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_medium_feet_d.dds",
                ["itemDesc"] = "Boots of Hunding's Rage",
                ["oldestTime"] = 1632879518,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310422,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 1290,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633157922,
                        ["quant"] = 1,
                        ["id"] = "1691453549",
                        ["itemLink"] = 1772,
                    },
                    [2] = 
                    {
                        ["price"] = 8420,
                        ["guild"] = 1,
                        ["buyer"] = 1613,
                        ["wasKiosk"] = true,
                        ["seller"] = 1161,
                        ["timestamp"] = 1633221009,
                        ["quant"] = 1,
                        ["id"] = "1692021557",
                        ["itemLink"] = 2349,
                    },
                    [3] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2090,
                        ["wasKiosk"] = true,
                        ["seller"] = 65,
                        ["timestamp"] = 1633310422,
                        ["quant"] = 1,
                        ["id"] = "1692853947",
                        ["itemLink"] = 2994,
                    },
                    [4] = 
                    {
                        ["price"] = 8999,
                        ["guild"] = 1,
                        ["buyer"] = 2348,
                        ["wasKiosk"] = true,
                        ["seller"] = 220,
                        ["timestamp"] = 1632879518,
                        ["quant"] = 1,
                        ["id"] = "1689391595",
                        ["itemLink"] = 3444,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp160 purple epic medium apparel set hunding's rage feet divines",
            },
        },
        [45655] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Beet-Glazed Pork",
                ["oldestTime"] = 1633242683,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242683,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 88,
                        ["guild"] = 1,
                        ["buyer"] = 348,
                        ["wasKiosk"] = false,
                        ["seller"] = 149,
                        ["timestamp"] = 1633242683,
                        ["quant"] = 1,
                        ["id"] = "1692215183",
                        ["itemLink"] = 2543,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [142680] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_elderarg_light_hand_a.dds",
                ["itemDesc"] = "Bright-Throat's Boast Gloves",
                ["oldestTime"] = 1632886467,
                ["wasAltered"] = true,
                ["newestTime"] = 1632886467,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2394,
                        ["wasKiosk"] = true,
                        ["seller"] = 655,
                        ["timestamp"] = 1632886467,
                        ["quant"] = 1,
                        ["id"] = "1689466473",
                        ["itemLink"] = 3521,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set bright-throat's boast hands reinforced",
            },
        },
        [151642] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_inc_noodlebowl001.dds",
                ["itemDesc"] = "Elsweyr Pot, Stoneware",
                ["oldestTime"] = 1633165788,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165788,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8574,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 312,
                        ["timestamp"] = 1633165788,
                        ["quant"] = 1,
                        ["id"] = "1691499613",
                        ["itemLink"] = 1840,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings hearth",
            },
        },
        [123483] = 
        {
            ["50:16:4:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_medium_chest_a.dds",
                ["itemDesc"] = "Coward's Gear Jack",
                ["oldestTime"] = 1633200762,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200762,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1491,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633200762,
                        ["quant"] = 1,
                        ["id"] = "1691797337",
                        ["itemLink"] = 2200,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set coward's gear chest sturdy",
            },
        },
        [126044] = 
        {
            ["50:16:3:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ashlanderv_2haxe_a.dds",
                ["itemDesc"] = "Great Axe of the Defiler",
                ["oldestTime"] = 1633053210,
                ["wasAltered"] = true,
                ["newestTime"] = 1633053210,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4800,
                        ["guild"] = 1,
                        ["buyer"] = 724,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1633053210,
                        ["quant"] = 1,
                        ["id"] = "1690638293",
                        ["itemLink"] = 928,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set defiler axe two-handed powered",
            },
        },
        [126559] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_dwe_inc_schematica001.dds",
                ["itemDesc"] = "Dwarven Schematics, Technical",
                ["oldestTime"] = 1633045208,
                ["wasAltered"] = true,
                ["newestTime"] = 1633045208,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18500,
                        ["guild"] = 1,
                        ["buyer"] = 668,
                        ["wasKiosk"] = true,
                        ["seller"] = 232,
                        ["timestamp"] = 1633045208,
                        ["quant"] = 1,
                        ["id"] = "1690558197",
                        ["itemLink"] = 848,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings gallery",
            },
        },
        [43616] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Alik'r Treasure Map IV",
                ["oldestTime"] = 1632842239,
                ["wasAltered"] = true,
                ["newestTime"] = 1633131953,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1117,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633131953,
                        ["quant"] = 1,
                        ["id"] = "1691207663",
                        ["itemLink"] = 1539,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2188,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1632842239,
                        ["quant"] = 1,
                        ["id"] = "1689075291",
                        ["itemLink"] = 1539,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [76898] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 38: Draugr Bows",
                ["oldestTime"] = 1632519491,
                ["wasAltered"] = true,
                ["newestTime"] = 1632519491,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 2,
                        ["buyer"] = 114,
                        ["wasKiosk"] = false,
                        ["seller"] = 111,
                        ["timestamp"] = 1632519491,
                        ["quant"] = 1,
                        ["id"] = "1686349131",
                        ["itemLink"] = 87,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [86884] = 
        {
            ["50:16:4:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_robe_d.dds",
                ["itemDesc"] = "Robe of Necropotence",
                ["oldestTime"] = 1632931038,
                ["wasAltered"] = true,
                ["newestTime"] = 1632931038,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 2518,
                        ["wasKiosk"] = true,
                        ["seller"] = 660,
                        ["timestamp"] = 1632931038,
                        ["quant"] = 1,
                        ["id"] = "1689729379",
                        ["itemLink"] = 3715,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set necropotence chest sturdy",
            },
        },
        [134757] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 58: Fang Lair Belts",
                ["oldestTime"] = 1633315426,
                ["wasAltered"] = true,
                ["newestTime"] = 1633315426,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 96,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633315426,
                        ["quant"] = 1,
                        ["id"] = "1692909021",
                        ["itemLink"] = 70,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [76903] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 38: Draugr Legs",
                ["oldestTime"] = 1633223942,
                ["wasAltered"] = true,
                ["newestTime"] = 1633223942,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1632,
                        ["wasKiosk"] = true,
                        ["seller"] = 660,
                        ["timestamp"] = 1633223942,
                        ["quant"] = 1,
                        ["id"] = "1692053559",
                        ["itemLink"] = 2369,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [134760] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 58: Fang Lair Chests",
                ["oldestTime"] = 1633064621,
                ["wasAltered"] = true,
                ["newestTime"] = 1633064621,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 195000,
                        ["guild"] = 1,
                        ["buyer"] = 813,
                        ["wasKiosk"] = true,
                        ["seller"] = 514,
                        ["timestamp"] = 1633064621,
                        ["quant"] = 1,
                        ["id"] = "1690745273",
                        ["itemLink"] = 1053,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [171369] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_fur_marktabletall001.dds",
                ["itemDesc"] = "Dwarven Sideboard, Granite Polished",
                ["oldestTime"] = 1633045220,
                ["wasAltered"] = true,
                ["newestTime"] = 1633045220,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 668,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633045220,
                        ["quant"] = 1,
                        ["id"] = "1690558345",
                        ["itemLink"] = 849,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [167789] = 
        {
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_waywardguardianmed_waist_a.dds",
                ["itemDesc"] = "Witch-Knight's Belt",
                ["oldestTime"] = 1633001305,
                ["wasAltered"] = true,
                ["newestTime"] = 1633001305,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 404,
                        ["wasKiosk"] = true,
                        ["seller"] = 43,
                        ["timestamp"] = 1633001305,
                        ["quant"] = 1,
                        ["id"] = "1690240875",
                        ["itemLink"] = 413,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set witch-knight's defiance waist infused",
            },
        },
        [71534] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 24: Outlaw Shoulders",
                ["oldestTime"] = 1633137620,
                ["wasAltered"] = true,
                ["newestTime"] = 1633137620,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 1165,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633137620,
                        ["quant"] = 1,
                        ["id"] = "1691267889",
                        ["itemLink"] = 1582,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45679] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Rabbit Loin with Bitter Greens",
                ["oldestTime"] = 1632520168,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261591,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 2,
                        ["buyer"] = 114,
                        ["wasKiosk"] = false,
                        ["seller"] = 117,
                        ["timestamp"] = 1632520168,
                        ["quant"] = 1,
                        ["id"] = "1686354817",
                        ["itemLink"] = 90,
                    },
                    [2] = 
                    {
                        ["price"] = 434,
                        ["guild"] = 1,
                        ["buyer"] = 924,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633094984,
                        ["quant"] = 1,
                        ["id"] = "1690919143",
                        ["itemLink"] = 90,
                    },
                    [3] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1345,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633172347,
                        ["quant"] = 1,
                        ["id"] = "1691532105",
                        ["itemLink"] = 90,
                    },
                    [4] = 
                    {
                        ["price"] = 71,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633261591,
                        ["quant"] = 1,
                        ["id"] = "1692334367",
                        ["itemLink"] = 90,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [68208] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Jugged Rabbit in Preserves",
                ["oldestTime"] = 1633266268,
                ["wasAltered"] = true,
                ["newestTime"] = 1633266268,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3700,
                        ["guild"] = 1,
                        ["buyer"] = 1856,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633266268,
                        ["quant"] = 1,
                        ["id"] = "1692370153",
                        ["itemLink"] = 2638,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [117875] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_exc_varpergola001.dds",
                ["itemDesc"] = "Wedding Pergola, Bare",
                ["oldestTime"] = 1633166006,
                ["wasAltered"] = true,
                ["newestTime"] = 1633166006,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 52000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633166006,
                        ["quant"] = 1,
                        ["id"] = "1691500725",
                        ["itemLink"] = 1859,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings structures",
            },
        },
        [87924] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_2hhammer_a.dds",
                ["itemDesc"] = "Deadly Maul",
                ["oldestTime"] = 1633233941,
                ["wasAltered"] = true,
                ["newestTime"] = 1633233941,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200000,
                        ["guild"] = 1,
                        ["buyer"] = 1718,
                        ["wasKiosk"] = true,
                        ["seller"] = 38,
                        ["timestamp"] = 1633233941,
                        ["quant"] = 1,
                        ["id"] = "1692153605",
                        ["itemLink"] = 2461,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set deadly strike mace two-handed sharpened",
            },
        },
        [165750] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_inc_toolspreader001.dds",
                ["itemDesc"] = "Solitude Wedge Pick, Simple",
                ["oldestTime"] = 1633042859,
                ["wasAltered"] = true,
                ["newestTime"] = 1633042859,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 653,
                        ["wasKiosk"] = true,
                        ["seller"] = 17,
                        ["timestamp"] = 1633042859,
                        ["quant"] = 1,
                        ["id"] = "1690536723",
                        ["itemLink"] = 831,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings workshop",
            },
        },
        [68216] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Muthsera's Remorse",
                ["oldestTime"] = 1633167665,
                ["wasAltered"] = true,
                ["newestTime"] = 1633223526,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 27,
                        ["guild"] = 1,
                        ["buyer"] = 1330,
                        ["wasKiosk"] = true,
                        ["seller"] = 78,
                        ["timestamp"] = 1633167665,
                        ["quant"] = 1,
                        ["id"] = "1691508613",
                        ["itemLink"] = 1870,
                    },
                    [2] = 
                    {
                        ["price"] = 15,
                        ["guild"] = 1,
                        ["buyer"] = 1593,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633217139,
                        ["quant"] = 1,
                        ["id"] = "1691981709",
                        ["itemLink"] = 1870,
                    },
                    [3] = 
                    {
                        ["price"] = 20,
                        ["guild"] = 1,
                        ["buyer"] = 1262,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633223526,
                        ["quant"] = 1,
                        ["id"] = "1692049265",
                        ["itemLink"] = 1870,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [56953] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Toasted Millet Salad",
                ["oldestTime"] = 1633011815,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185113,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 368,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1633011815,
                        ["quant"] = 1,
                        ["id"] = "1690302833",
                        ["itemLink"] = 521,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633185113,
                        ["quant"] = 1,
                        ["id"] = "1691630139",
                        ["itemLink"] = 521,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [56955] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Chicken-and-Banana Fried Rice",
                ["oldestTime"] = 1633184431,
                ["wasAltered"] = true,
                ["newestTime"] = 1633184431,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3200,
                        ["guild"] = 1,
                        ["buyer"] = 1387,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633184431,
                        ["quant"] = 1,
                        ["id"] = "1691624299",
                        ["itemLink"] = 1976,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [171903] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 101: Ivory Brigade Helmets",
                ["oldestTime"] = 1632882109,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242092,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14200,
                        ["guild"] = 1,
                        ["buyer"] = 329,
                        ["wasKiosk"] = false,
                        ["seller"] = 70,
                        ["timestamp"] = 1633006742,
                        ["quant"] = 1,
                        ["id"] = "1690269539",
                        ["itemLink"] = 433,
                    },
                    [2] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 978,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633109329,
                        ["quant"] = 1,
                        ["id"] = "1691031105",
                        ["itemLink"] = 433,
                    },
                    [3] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 238,
                        ["wasKiosk"] = false,
                        ["seller"] = 51,
                        ["timestamp"] = 1633181464,
                        ["quant"] = 1,
                        ["id"] = "1691599051",
                        ["itemLink"] = 433,
                    },
                    [4] = 
                    {
                        ["price"] = 9500,
                        ["guild"] = 1,
                        ["buyer"] = 1570,
                        ["wasKiosk"] = true,
                        ["seller"] = 1128,
                        ["timestamp"] = 1633214004,
                        ["quant"] = 1,
                        ["id"] = "1691949479",
                        ["itemLink"] = 433,
                    },
                    [5] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1628,
                        ["wasKiosk"] = true,
                        ["seller"] = 1546,
                        ["timestamp"] = 1633223308,
                        ["quant"] = 1,
                        ["id"] = "1692046721",
                        ["itemLink"] = 433,
                    },
                    [6] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1654,
                        ["wasKiosk"] = true,
                        ["seller"] = 514,
                        ["timestamp"] = 1633226633,
                        ["quant"] = 1,
                        ["id"] = "1692081493",
                        ["itemLink"] = 433,
                    },
                    [7] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 1782,
                        ["wasKiosk"] = true,
                        ["seller"] = 1450,
                        ["timestamp"] = 1633242092,
                        ["quant"] = 1,
                        ["id"] = "1692212189",
                        ["itemLink"] = 433,
                    },
                    [8] = 
                    {
                        ["price"] = 12450,
                        ["guild"] = 1,
                        ["buyer"] = 2365,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1632882109,
                        ["quant"] = 1,
                        ["id"] = "1689419565",
                        ["itemLink"] = 433,
                    },
                    [9] = 
                    {
                        ["price"] = 12500,
                        ["guild"] = 1,
                        ["buyer"] = 1063,
                        ["wasKiosk"] = true,
                        ["seller"] = 1899,
                        ["timestamp"] = 1632897124,
                        ["quant"] = 1,
                        ["id"] = "1689542701",
                        ["itemLink"] = 433,
                    },
                },
                ["totalCount"] = 9,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [77440] = 
        {
            ["50:16:2:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_darkbrotherhoodv2_medium_feet_a.dds",
                ["itemDesc"] = "Sithis' Boots",
                ["oldestTime"] = 1632825539,
                ["wasAltered"] = true,
                ["newestTime"] = 1632825539,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1084,
                        ["wasKiosk"] = true,
                        ["seller"] = 533,
                        ["timestamp"] = 1632825539,
                        ["quant"] = 1,
                        ["id"] = "1688966369",
                        ["itemLink"] = 3022,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set sithis' touch feet invigorating",
            },
        },
        [68225] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Flowing Bowl Green Port",
                ["oldestTime"] = 1633130297,
                ["wasAltered"] = true,
                ["newestTime"] = 1633314480,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 103,
                        ["guild"] = 1,
                        ["buyer"] = 76,
                        ["wasKiosk"] = false,
                        ["seller"] = 78,
                        ["timestamp"] = 1633314480,
                        ["quant"] = 1,
                        ["id"] = "1692896241",
                        ["itemLink"] = 58,
                    },
                    [2] = 
                    {
                        ["price"] = 80,
                        ["guild"] = 1,
                        ["buyer"] = 1102,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1633130297,
                        ["quant"] = 1,
                        ["id"] = "1691189227",
                        ["itemLink"] = 58,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [56964] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Akaviri Pork Fried Rice",
                ["oldestTime"] = 1633208640,
                ["wasAltered"] = true,
                ["newestTime"] = 1633208640,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1542,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1633208640,
                        ["quant"] = 1,
                        ["id"] = "1691890037",
                        ["itemLink"] = 2265,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [171909] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 101: Ivory Brigade Swords",
                ["oldestTime"] = 1633088127,
                ["wasAltered"] = true,
                ["newestTime"] = 1633313772,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 61,
                        ["wasKiosk"] = false,
                        ["seller"] = 22,
                        ["timestamp"] = 1633313772,
                        ["quant"] = 1,
                        ["id"] = "1692888477",
                        ["itemLink"] = 47,
                    },
                    [2] = 
                    {
                        ["price"] = 8600,
                        ["guild"] = 1,
                        ["buyer"] = 450,
                        ["wasKiosk"] = true,
                        ["seller"] = 911,
                        ["timestamp"] = 1633088127,
                        ["quant"] = 1,
                        ["id"] = "1690876825",
                        ["itemLink"] = 47,
                    },
                    [3] = 
                    {
                        ["price"] = 8799,
                        ["guild"] = 1,
                        ["buyer"] = 1570,
                        ["wasKiosk"] = true,
                        ["seller"] = 451,
                        ["timestamp"] = 1633213980,
                        ["quant"] = 1,
                        ["id"] = "1691949079",
                        ["itemLink"] = 47,
                    },
                    [4] = 
                    {
                        ["price"] = 9500,
                        ["guild"] = 1,
                        ["buyer"] = 1770,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1633240325,
                        ["quant"] = 1,
                        ["id"] = "1692200069",
                        ["itemLink"] = 47,
                    },
                    [5] = 
                    {
                        ["price"] = 9999,
                        ["guild"] = 1,
                        ["buyer"] = 1849,
                        ["wasKiosk"] = true,
                        ["seller"] = 1850,
                        ["timestamp"] = 1633264588,
                        ["quant"] = 1,
                        ["id"] = "1692355579",
                        ["itemLink"] = 47,
                    },
                    [6] = 
                    {
                        ["price"] = 7300,
                        ["guild"] = 1,
                        ["buyer"] = 550,
                        ["wasKiosk"] = false,
                        ["seller"] = 1128,
                        ["timestamp"] = 1633275989,
                        ["quant"] = 1,
                        ["id"] = "1692475875",
                        ["itemLink"] = 47,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [4486] = 
        {
            ["1:0:1:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_jewelry_base_ruby_r3.dds",
                ["itemDesc"] = "Ruby",
                ["oldestTime"] = 1633125401,
                ["wasAltered"] = true,
                ["newestTime"] = 1633125401,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 166,
                        ["timestamp"] = 1633125401,
                        ["quant"] = 50,
                        ["id"] = "1691145685",
                        ["itemLink"] = 1473,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials weapon trait precise",
            },
        },
        [72327] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_medium_waist_a.dds",
                ["itemDesc"] = "Clever Alchemist Belt",
                ["oldestTime"] = 1632892264,
                ["wasAltered"] = true,
                ["newestTime"] = 1632892264,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 2420,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1632892264,
                        ["quant"] = 1,
                        ["id"] = "1689510707",
                        ["itemLink"] = 3546,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set clever alchemist waist well-fitted",
            },
        },
        [139659] = 
        {
            ["1:0:4:32:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Exemplary Protective Necklace",
                ["oldestTime"] = 1632844977,
                ["wasAltered"] = true,
                ["newestTime"] = 1633063244,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2769,
                        ["guild"] = 1,
                        ["buyer"] = 800,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633063244,
                        ["quant"] = 1,
                        ["id"] = "1690733943",
                        ["itemLink"] = 1037,
                    },
                    [2] = 
                    {
                        ["price"] = 2345,
                        ["guild"] = 1,
                        ["buyer"] = 2193,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1632844977,
                        ["quant"] = 1,
                        ["id"] = "1689099673",
                        ["itemLink"] = 1037,
                    },
                    [3] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 2237,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632856569,
                        ["quant"] = 1,
                        ["id"] = "1689202397",
                        ["itemLink"] = 1037,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic jewelry apparel neck protective",
            },
        },
        [167824] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_waywardguardianmed_feet_a.dds",
                ["itemDesc"] = "Witch-Knight's Boots",
                ["oldestTime"] = 1633126177,
                ["wasAltered"] = true,
                ["newestTime"] = 1633126177,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 17995,
                        ["guild"] = 1,
                        ["buyer"] = 369,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1633126177,
                        ["quant"] = 1,
                        ["id"] = "1691150877",
                        ["itemLink"] = 1487,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set witch-knight's defiance feet well-fitted",
            },
        },
        [139409] = 
        {
            ["1:0:1:30:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/jewelrycrafting_trait_refined_dawnprism.dds",
                ["itemDesc"] = "Dawn-Prism",
                ["oldestTime"] = 1633263800,
                ["wasAltered"] = true,
                ["newestTime"] = 1633275562,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 43999,
                        ["guild"] = 1,
                        ["buyer"] = 1846,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633263800,
                        ["quant"] = 1,
                        ["id"] = "1692349419",
                        ["itemLink"] = 2634,
                    },
                    [2] = 
                    {
                        ["price"] = 43999,
                        ["guild"] = 1,
                        ["buyer"] = 1877,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633270752,
                        ["quant"] = 1,
                        ["id"] = "1692413369",
                        ["itemLink"] = 2634,
                    },
                    [3] = 
                    {
                        ["price"] = 43999,
                        ["guild"] = 1,
                        ["buyer"] = 1877,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633270753,
                        ["quant"] = 1,
                        ["id"] = "1692413381",
                        ["itemLink"] = 2634,
                    },
                    [4] = 
                    {
                        ["price"] = 43999,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633275561,
                        ["quant"] = 1,
                        ["id"] = "1692470377",
                        ["itemLink"] = 2634,
                    },
                    [5] = 
                    {
                        ["price"] = 43999,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633275562,
                        ["quant"] = 1,
                        ["id"] = "1692470399",
                        ["itemLink"] = 2634,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 white normal materials jewelry trait triune",
            },
        },
        [71570] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 23: Malacath Bows",
                ["oldestTime"] = 1633205002,
                ["wasAltered"] = true,
                ["newestTime"] = 1633205002,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3400,
                        ["guild"] = 1,
                        ["buyer"] = 698,
                        ["wasKiosk"] = true,
                        ["seller"] = 33,
                        ["timestamp"] = 1633205002,
                        ["quant"] = 1,
                        ["id"] = "1691842373",
                        ["itemLink"] = 2239,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [71059] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_meat_001.dds",
                ["itemDesc"] = "Orzorga's Smoked Bear Haunch",
                ["oldestTime"] = 1632834264,
                ["wasAltered"] = true,
                ["newestTime"] = 1632834264,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13984,
                        ["guild"] = 1,
                        ["buyer"] = 2148,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1632834264,
                        ["quant"] = 1,
                        ["id"] = "1689022807",
                        ["itemLink"] = 3096,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable food",
            },
        },
        [100501] = 
        {
            ["50:16:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_light_shoulders_d.dds",
                ["itemDesc"] = "Vampire Lord's Epaulets",
                ["oldestTime"] = 1632939502,
                ["wasAltered"] = true,
                ["newestTime"] = 1632939502,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 2539,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1632939502,
                        ["quant"] = 1,
                        ["id"] = "1689791359",
                        ["itemLink"] = 3760,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set vampire lord shoulders impenetrable",
            },
        },
        [166038] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Blackreach: Greymoor Caverns Treasure Map I",
                ["oldestTime"] = 1633173236,
                ["wasAltered"] = true,
                ["newestTime"] = 1633229055,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1347,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633173236,
                        ["quant"] = 1,
                        ["id"] = "1691536657",
                        ["itemLink"] = 1892,
                    },
                    [2] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1347,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633173236,
                        ["quant"] = 1,
                        ["id"] = "1691536659",
                        ["itemLink"] = 1892,
                    },
                    [3] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1674,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633229055,
                        ["quant"] = 1,
                        ["id"] = "1692107423",
                        ["itemLink"] = 1892,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [176023] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Leyawiin Canopy, Merchant",
                ["oldestTime"] = 1632520216,
                ["wasAltered"] = true,
                ["newestTime"] = 1633272477,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 2,
                        ["buyer"] = 114,
                        ["wasKiosk"] = false,
                        ["seller"] = 117,
                        ["timestamp"] = 1632520216,
                        ["quant"] = 1,
                        ["id"] = "1686355245",
                        ["itemLink"] = 93,
                    },
                    [2] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 31,
                        ["wasKiosk"] = false,
                        ["seller"] = 930,
                        ["timestamp"] = 1633200549,
                        ["quant"] = 1,
                        ["id"] = "1691795303",
                        ["itemLink"] = 93,
                    },
                    [3] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1643,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633272477,
                        ["quant"] = 1,
                        ["id"] = "1692431837",
                        ["itemLink"] = 93,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [68505] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_trinimac_light_robe_a.dds",
                ["itemDesc"] = "Robe of Trinimac's Valor",
                ["oldestTime"] = 1633215017,
                ["wasAltered"] = true,
                ["newestTime"] = 1633215017,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 1582,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1633215017,
                        ["quant"] = 1,
                        ["id"] = "1691958761",
                        ["itemLink"] = 2308,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set trinimac's valor chest reinforced",
            },
        },
        [95643] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Air",
                ["oldestTime"] = 1633082474,
                ["wasAltered"] = true,
                ["newestTime"] = 1633113810,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 458,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1633082474,
                        ["quant"] = 1,
                        ["id"] = "1690846557",
                        ["itemLink"] = 1135,
                    },
                    [2] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1003,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1633113810,
                        ["quant"] = 1,
                        ["id"] = "1691064283",
                        ["itemLink"] = 1135,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set way of air ring robust",
            },
        },
        [151708] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_fur_chest004.dds",
                ["itemDesc"] = "Elsweyr Chest, Red Gilded",
                ["oldestTime"] = 1633040029,
                ["wasAltered"] = true,
                ["newestTime"] = 1633040029,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 29409,
                        ["guild"] = 1,
                        ["buyer"] = 621,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1633040029,
                        ["quant"] = 1,
                        ["id"] = "1690513335",
                        ["itemLink"] = 787,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings suite",
            },
        },
        [144797] = 
        {
            ["50:16:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_staff_a.dds",
                ["itemDesc"] = "Steadfast Hero Inferno Staff",
                ["oldestTime"] = 1633200774,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200774,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 1491,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633200774,
                        ["quant"] = 1,
                        ["id"] = "1691797483",
                        ["itemLink"] = 2203,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set steadfast hero flame staff two-handed training",
            },
        },
        [115614] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bos_inc_plate004.dds",
                ["itemDesc"] = "Wood Elf Fish Dish",
                ["oldestTime"] = 1632905520,
                ["wasAltered"] = true,
                ["newestTime"] = 1632905520,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 2451,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1632905520,
                        ["quant"] = 1,
                        ["id"] = "1689584021",
                        ["itemLink"] = 3583,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings hearth",
            },
        },
        [54175] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_light_armor_vendor_component_002.dds",
                ["itemDesc"] = "Embroidery",
                ["oldestTime"] = 1632848331,
                ["wasAltered"] = true,
                ["newestTime"] = 1632987732,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 75,
                        ["timestamp"] = 1632987732,
                        ["quant"] = 200,
                        ["id"] = "1690172927",
                        ["itemLink"] = 338,
                    },
                    [2] = 
                    {
                        ["price"] = 3600,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632848331,
                        ["quant"] = 200,
                        ["id"] = "1689130849",
                        ["itemLink"] = 338,
                    },
                    [3] = 
                    {
                        ["price"] = 3400,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1632848332,
                        ["quant"] = 200,
                        ["id"] = "1689130861",
                        ["itemLink"] = 338,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior materials tannin",
            },
        },
        [151712] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_fur_merchantcenterlongcounter001.dds",
                ["itemDesc"] = "Elsweyr Cabinet, Wide Elegant Wooden",
                ["oldestTime"] = 1633174122,
                ["wasAltered"] = true,
                ["newestTime"] = 1633174122,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633174122,
                        ["quant"] = 1,
                        ["id"] = "1691542103",
                        ["itemLink"] = 1897,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [135151] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/jewelrycrafting_booster_raw_terne.dds",
                ["itemDesc"] = "Terne Grains",
                ["oldestTime"] = 1633235040,
                ["wasAltered"] = true,
                ["newestTime"] = 1633235040,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1727,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633235040,
                        ["quant"] = 2,
                        ["id"] = "1692160941",
                        ["itemLink"] = 2479,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine materials raw plating",
            },
        },
        [115987] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Breton Desk, Scholar's",
                ["oldestTime"] = 1632964859,
                ["wasAltered"] = true,
                ["newestTime"] = 1632964859,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 2046,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632964859,
                        ["quant"] = 1,
                        ["id"] = "1690005293",
                        ["itemLink"] = 3950,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [178455] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Nibenese Court Wizard Epaulets",
                ["oldestTime"] = 1632952520,
                ["wasAltered"] = true,
                ["newestTime"] = 1632952520,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22054,
                        ["guild"] = 1,
                        ["buyer"] = 2597,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1632952520,
                        ["quant"] = 1,
                        ["id"] = "1689897023",
                        ["itemLink"] = 3851,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [57836] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 17: Xivkyn Belts",
                ["oldestTime"] = 1632875230,
                ["wasAltered"] = true,
                ["newestTime"] = 1633280108,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15655,
                        ["guild"] = 1,
                        ["buyer"] = 1926,
                        ["wasKiosk"] = true,
                        ["seller"] = 765,
                        ["timestamp"] = 1633280108,
                        ["quant"] = 1,
                        ["id"] = "1692516571",
                        ["itemLink"] = 2731,
                    },
                    [2] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 2323,
                        ["wasKiosk"] = true,
                        ["seller"] = 660,
                        ["timestamp"] = 1632875230,
                        ["quant"] = 1,
                        ["id"] = "1689343559",
                        ["itemLink"] = 2731,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [122792] = 
        {
            ["50:16:2:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "War Maiden's Ring",
                ["oldestTime"] = 1633057313,
                ["wasAltered"] = true,
                ["newestTime"] = 1633057313,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 755,
                        ["wasKiosk"] = true,
                        ["seller"] = 327,
                        ["timestamp"] = 1633057313,
                        ["quant"] = 1,
                        ["id"] = "1690682799",
                        ["itemLink"] = 964,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set war maiden ring arcane",
            },
        },
        [160900] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_greyhostmed_legs_a.dds",
                ["itemDesc"] = "Venomous Guards",
                ["oldestTime"] = 1632932999,
                ["wasAltered"] = true,
                ["newestTime"] = 1632932999,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2521,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632932999,
                        ["quant"] = 1,
                        ["id"] = "1689743977",
                        ["itemLink"] = 3719,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set venomous smite legs reinforced",
            },
        },
        [44714] = 
        {
            ["50:15:1:9:856325"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/consumable_potion_005_type_005.dds",
                ["itemDesc"] = "Essence of Weapon Power",
                ["oldestTime"] = 1633045852,
                ["wasAltered"] = true,
                ["newestTime"] = 1633288067,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 675,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633045852,
                        ["quant"] = 12,
                        ["id"] = "1690565085",
                        ["itemLink"] = 862,
                    },
                    [2] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1439,
                        ["wasKiosk"] = true,
                        ["seller"] = 1417,
                        ["timestamp"] = 1633194212,
                        ["quant"] = 100,
                        ["id"] = "1691736403",
                        ["itemLink"] = 862,
                    },
                    [3] = 
                    {
                        ["price"] = 30083,
                        ["guild"] = 1,
                        ["buyer"] = 827,
                        ["wasKiosk"] = false,
                        ["seller"] = 266,
                        ["timestamp"] = 1633233194,
                        ["quant"] = 200,
                        ["id"] = "1692146421",
                        ["itemLink"] = 862,
                    },
                    [4] = 
                    {
                        ["price"] = 30083,
                        ["guild"] = 1,
                        ["buyer"] = 879,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633243278,
                        ["quant"] = 200,
                        ["id"] = "1692220717",
                        ["itemLink"] = 862,
                    },
                    [5] = 
                    {
                        ["price"] = 31000,
                        ["guild"] = 1,
                        ["buyer"] = 1966,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1633288066,
                        ["quant"] = 200,
                        ["id"] = "1692605647",
                        ["itemLink"] = 862,
                    },
                    [6] = 
                    {
                        ["price"] = 31000,
                        ["guild"] = 1,
                        ["buyer"] = 1966,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1633288067,
                        ["quant"] = 200,
                        ["id"] = "1692605665",
                        ["itemLink"] = 862,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "cp150 white normal consumable potion",
            },
            ["50:15:1:9:856330"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/consumable_potion_005_type_005.dds",
                ["itemDesc"] = "Essence of Weapon Power",
                ["oldestTime"] = 1633194217,
                ["wasAltered"] = true,
                ["newestTime"] = 1633194217,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1439,
                        ["wasKiosk"] = true,
                        ["seller"] = 1417,
                        ["timestamp"] = 1633194217,
                        ["quant"] = 100,
                        ["id"] = "1691736421",
                        ["itemLink"] = 2128,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 white normal consumable potion",
            },
        },
        [119211] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing3.dds",
                ["itemDesc"] = "Diagram: Redguard Streetlamps, Paired",
                ["oldestTime"] = 1632836164,
                ["wasAltered"] = true,
                ["newestTime"] = 1632836164,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 2158,
                        ["wasKiosk"] = true,
                        ["seller"] = 177,
                        ["timestamp"] = 1632836164,
                        ["quant"] = 1,
                        ["id"] = "1689035111",
                        ["itemLink"] = 3104,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [43552] = 
        {
            ["50:14:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_medium_hands_d.dds",
                ["itemDesc"] = "Shadowhide Bracers",
                ["oldestTime"] = 1632922799,
                ["wasAltered"] = true,
                ["newestTime"] = 1632922799,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 127,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 67,
                        ["timestamp"] = 1632922799,
                        ["quant"] = 1,
                        ["id"] = "1689672039",
                        ["itemLink"] = 3661,
                    },
                    [2] = 
                    {
                        ["price"] = 127,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 67,
                        ["timestamp"] = 1632922799,
                        ["quant"] = 1,
                        ["id"] = "1689672043",
                        ["itemLink"] = 3662,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp140 white normal medium apparel hands",
            },
        },
        [57036] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Lemonic Invigoration",
                ["oldestTime"] = 1632975961,
                ["wasAltered"] = true,
                ["newestTime"] = 1632975961,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 123,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1632975961,
                        ["quant"] = 1,
                        ["id"] = "1690102361",
                        ["itemLink"] = 229,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [160496] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 84: Blackreach Vanguard Boots",
                ["oldestTime"] = 1632917799,
                ["wasAltered"] = true,
                ["newestTime"] = 1632917799,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14500,
                        ["guild"] = 1,
                        ["buyer"] = 2478,
                        ["wasKiosk"] = true,
                        ["seller"] = 611,
                        ["timestamp"] = 1632917799,
                        ["quant"] = 1,
                        ["id"] = "1689639421",
                        ["itemLink"] = 3642,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [68228] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Cloudrest Clarified Coffee",
                ["oldestTime"] = 1632913040,
                ["wasAltered"] = true,
                ["newestTime"] = 1632913040,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 160,
                        ["guild"] = 1,
                        ["buyer"] = 2471,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632913040,
                        ["quant"] = 1,
                        ["id"] = "1689612435",
                        ["itemLink"] = 3623,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [121520] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_militant_ordinator_r2.dds",
                ["itemDesc"] = "Lustrous Sphalerite",
                ["oldestTime"] = 1632970331,
                ["wasAltered"] = true,
                ["newestTime"] = 1632970331,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 165,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1632970331,
                        ["quant"] = 1,
                        ["id"] = "1690059833",
                        ["itemLink"] = 178,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [175937] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Leyawiin Tapestry, Fleet",
                ["oldestTime"] = 1632883885,
                ["wasAltered"] = true,
                ["newestTime"] = 1632883885,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 590000,
                        ["guild"] = 1,
                        ["buyer"] = 2377,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1632883885,
                        ["quant"] = 1,
                        ["id"] = "1689437233",
                        ["itemLink"] = 3494,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [51547] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_medium_waist_d.dds",
                ["itemDesc"] = "Belt of Hunding's Rage",
                ["oldestTime"] = 1633201648,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310472,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 1500,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633201648,
                        ["quant"] = 1,
                        ["id"] = "1691807361",
                        ["itemLink"] = 2217,
                    },
                    [2] = 
                    {
                        ["price"] = 8576,
                        ["guild"] = 1,
                        ["buyer"] = 2090,
                        ["wasKiosk"] = true,
                        ["seller"] = 1161,
                        ["timestamp"] = 1633310472,
                        ["quant"] = 1,
                        ["id"] = "1692854577",
                        ["itemLink"] = 2995,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic medium apparel set hunding's rage waist divines",
            },
        },
        [68676] = 
        {
            ["50:16:4:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_heavy_hands_a.dds",
                ["itemDesc"] = "Gauntlets of the Pariah",
                ["oldestTime"] = 1633213317,
                ["wasAltered"] = true,
                ["newestTime"] = 1633213317,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1090,
                        ["guild"] = 1,
                        ["buyer"] = 1564,
                        ["wasKiosk"] = true,
                        ["seller"] = 6,
                        ["timestamp"] = 1633213317,
                        ["quant"] = 1,
                        ["id"] = "1691943433",
                        ["itemLink"] = 2288,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set mark of the pariah hands reinforced",
            },
        },
        [69300] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_dagger_c.dds",
                ["itemDesc"] = "Dagger of Agility",
                ["oldestTime"] = 1633086249,
                ["wasAltered"] = true,
                ["newestTime"] = 1633086249,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 137,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633086249,
                        ["quant"] = 1,
                        ["id"] = "1690864895",
                        ["itemLink"] = 1217,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set agility dagger one-handed sharpened",
            },
        },
        [43701] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Bal Foyen Treasure Map I",
                ["oldestTime"] = 1632769509,
                ["wasAltered"] = true,
                ["newestTime"] = 1632769509,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 2,
                        ["buyer"] = 124,
                        ["wasKiosk"] = false,
                        ["seller"] = 111,
                        ["timestamp"] = 1632769509,
                        ["quant"] = 1,
                        ["id"] = "1688525033",
                        ["itemLink"] = 123,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [87697] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/event_halloween_2016_iron_cup_bones.dds",
                ["itemDesc"] = "Witchmother's Potent Brew",
                ["oldestTime"] = 1632861637,
                ["wasAltered"] = true,
                ["newestTime"] = 1632925291,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19000,
                        ["guild"] = 1,
                        ["buyer"] = 1908,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1632861637,
                        ["quant"] = 100,
                        ["id"] = "1689241985",
                        ["itemLink"] = 3309,
                    },
                    [2] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 2497,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1632925291,
                        ["quant"] = 10,
                        ["id"] = "1689688737",
                        ["itemLink"] = 3309,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable drink",
            },
        },
        [167189] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_burnishedgoldscale.dds",
                ["itemDesc"] = "Burnished Goldscale",
                ["oldestTime"] = 1632861564,
                ["wasAltered"] = true,
                ["newestTime"] = 1632861564,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1770,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1632861564,
                        ["quant"] = 1,
                        ["id"] = "1689241525",
                        ["itemLink"] = 3304,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [116152] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing2.dds",
                ["itemDesc"] = "Diagram: Nord Lantern, Cage",
                ["oldestTime"] = 1632981401,
                ["wasAltered"] = true,
                ["newestTime"] = 1633158054,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50,
                        ["guild"] = 1,
                        ["buyer"] = 265,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632981401,
                        ["quant"] = 1,
                        ["id"] = "1690138619",
                        ["itemLink"] = 280,
                    },
                    [2] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1293,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633158054,
                        ["quant"] = 1,
                        ["id"] = "1691454671",
                        ["itemLink"] = 280,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [151737] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_lsb_lantern001.dds",
                ["itemDesc"] = "Elsweyr Lantern, Hanging Twist",
                ["oldestTime"] = 1632879631,
                ["wasAltered"] = true,
                ["newestTime"] = 1633201478,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 44000,
                        ["guild"] = 1,
                        ["buyer"] = 1496,
                        ["wasKiosk"] = true,
                        ["seller"] = 323,
                        ["timestamp"] = 1633201478,
                        ["quant"] = 4,
                        ["id"] = "1691805427",
                        ["itemLink"] = 2216,
                    },
                    [2] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 2349,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1632879631,
                        ["quant"] = 1,
                        ["id"] = "1689392805",
                        ["itemLink"] = 2216,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior furnishings lighting",
            },
        },
        [84706] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of the Sun",
                ["oldestTime"] = 1632854194,
                ["wasAltered"] = true,
                ["newestTime"] = 1632854194,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2230,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1632854194,
                        ["quant"] = 1,
                        ["id"] = "1689177635",
                        ["itemLink"] = 3260,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set silks of the sun neck arcane",
            },
        },
        [180704] = 
        {
            ["50:16:4:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_1hsword_a.dds",
                ["itemDesc"] = "Plaguebreak Sword",
                ["oldestTime"] = 1632852543,
                ["wasAltered"] = true,
                ["newestTime"] = 1632852543,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 2224,
                        ["wasKiosk"] = true,
                        ["seller"] = 13,
                        ["timestamp"] = 1632852543,
                        ["quant"] = 1,
                        ["id"] = "1689163227",
                        ["itemLink"] = 3255,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set plaguebreak sword one-handed charged",
            },
        },
        [166041] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Western Skyrim Treasure Map II",
                ["oldestTime"] = 1632999579,
                ["wasAltered"] = true,
                ["newestTime"] = 1632999579,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 392,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1632999579,
                        ["quant"] = 1,
                        ["id"] = "1690231299",
                        ["itemLink"] = 395,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [126610] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_fan_forestcoralplant001.dds",
                ["itemDesc"] = "Vvardenfell Coral Plant, Strong",
                ["oldestTime"] = 1632851136,
                ["wasAltered"] = true,
                ["newestTime"] = 1632851140,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 175,
                        ["wasKiosk"] = false,
                        ["seller"] = 669,
                        ["timestamp"] = 1632851136,
                        ["quant"] = 2,
                        ["id"] = "1689152841",
                        ["itemLink"] = 3239,
                    },
                    [2] = 
                    {
                        ["price"] = 13990,
                        ["guild"] = 1,
                        ["buyer"] = 175,
                        ["wasKiosk"] = false,
                        ["seller"] = 333,
                        ["timestamp"] = 1632851140,
                        ["quant"] = 1,
                        ["id"] = "1689152869",
                        ["itemLink"] = 3239,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings conservatory",
            },
        },
        [82025] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 42: Hollowjack Boots",
                ["oldestTime"] = 1633207978,
                ["wasAltered"] = true,
                ["newestTime"] = 1633207978,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16500,
                        ["guild"] = 1,
                        ["buyer"] = 1539,
                        ["wasKiosk"] = true,
                        ["seller"] = 611,
                        ["timestamp"] = 1633207978,
                        ["quant"] = 1,
                        ["id"] = "1691881871",
                        ["itemLink"] = 2260,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45942] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Bravil Melon Salad",
                ["oldestTime"] = 1632839856,
                ["wasAltered"] = true,
                ["newestTime"] = 1632839856,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 27,
                        ["guild"] = 1,
                        ["buyer"] = 2173,
                        ["wasKiosk"] = true,
                        ["seller"] = 531,
                        ["timestamp"] = 1632839856,
                        ["quant"] = 1,
                        ["id"] = "1689059369",
                        ["itemLink"] = 3134,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [102253] = 
        {
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Blessed Ring",
                ["oldestTime"] = 1632839088,
                ["wasAltered"] = true,
                ["newestTime"] = 1632839088,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1632839088,
                        ["quant"] = 1,
                        ["id"] = "1689055099",
                        ["itemLink"] = 3126,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set meridia's blessed armor ring healthy",
            },
        },
        [175990] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Leyawiin Basket, Open",
                ["oldestTime"] = 1633091032,
                ["wasAltered"] = true,
                ["newestTime"] = 1633206127,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1150,
                        ["guild"] = 2,
                        ["buyer"] = 139,
                        ["wasKiosk"] = false,
                        ["seller"] = 117,
                        ["timestamp"] = 1633206127,
                        ["quant"] = 1,
                        ["id"] = "1691856949",
                        ["itemLink"] = 157,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 655,
                        ["wasKiosk"] = false,
                        ["seller"] = 911,
                        ["timestamp"] = 1633091032,
                        ["quant"] = 1,
                        ["id"] = "1690894455",
                        ["itemLink"] = 157,
                    },
                    [3] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1091,
                        ["wasKiosk"] = true,
                        ["seller"] = 911,
                        ["timestamp"] = 1633127211,
                        ["quant"] = 1,
                        ["id"] = "1691160185",
                        ["itemLink"] = 157,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [129798] = 
        {
            ["50:16:2:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_heavy_hands_a.dds",
                ["itemDesc"] = "Gauntlets of the Pariah",
                ["oldestTime"] = 1632833529,
                ["wasAltered"] = true,
                ["newestTime"] = 1632833529,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2145,
                        ["wasKiosk"] = true,
                        ["seller"] = 534,
                        ["timestamp"] = 1632833529,
                        ["quant"] = 1,
                        ["id"] = "1689019113",
                        ["itemLink"] = 3094,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set mark of the pariah hands training",
            },
        },
        [23266] = 
        {
            ["40:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_potion_base_water_3_r2.dds",
                ["itemDesc"] = "Filtered Water",
                ["oldestTime"] = 1632832696,
                ["wasAltered"] = true,
                ["newestTime"] = 1632832696,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 23000,
                        ["guild"] = 1,
                        ["buyer"] = 2144,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1632832696,
                        ["quant"] = 200,
                        ["id"] = "1689014223",
                        ["itemLink"] = 3093,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr40 white normal materials potion solvent",
            },
        },
        [123782] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_light_legs_a.dds",
                ["itemDesc"] = "Wizard's Riposte Breeches",
                ["oldestTime"] = 1633200753,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200753,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1491,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633200753,
                        ["quant"] = 1,
                        ["id"] = "1691797265",
                        ["itemLink"] = 2198,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set wizard's riposte legs well-fitted",
            },
        },
        [123403] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_medium_chest_a.dds",
                ["itemDesc"] = "Coward's Gear Jack",
                ["oldestTime"] = 1632827283,
                ["wasAltered"] = true,
                ["newestTime"] = 1632827283,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 2124,
                        ["wasKiosk"] = true,
                        ["seller"] = 529,
                        ["timestamp"] = 1632827283,
                        ["quant"] = 1,
                        ["id"] = "1688977535",
                        ["itemLink"] = 3060,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set coward's gear chest well-fitted",
            },
        },
        [180678] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_medium_head_a.dds",
                ["itemDesc"] = "Plaguebreak Helmet",
                ["oldestTime"] = 1633274175,
                ["wasAltered"] = true,
                ["newestTime"] = 1633274175,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5150,
                        ["guild"] = 1,
                        ["buyer"] = 330,
                        ["wasKiosk"] = false,
                        ["seller"] = 54,
                        ["timestamp"] = 1633274175,
                        ["quant"] = 1,
                        ["id"] = "1692453033",
                        ["itemLink"] = 2691,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set plaguebreak head reinforced",
            },
        },
        [132567] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 55: Dreadhorn Belts",
                ["oldestTime"] = 1633310873,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310873,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2091,
                        ["wasKiosk"] = true,
                        ["seller"] = 1161,
                        ["timestamp"] = 1633310873,
                        ["quant"] = 1,
                        ["id"] = "1692858525",
                        ["itemLink"] = 2997,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [160615] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 88: Ancestral Orc Chests",
                ["oldestTime"] = 1632870616,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294732,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 711,
                        ["timestamp"] = 1633294732,
                        ["quant"] = 1,
                        ["id"] = "1692686895",
                        ["itemLink"] = 2869,
                    },
                    [2] = 
                    {
                        ["price"] = 15500,
                        ["guild"] = 1,
                        ["buyer"] = 2290,
                        ["wasKiosk"] = true,
                        ["seller"] = 577,
                        ["timestamp"] = 1632870616,
                        ["quant"] = 1,
                        ["id"] = "1689307875",
                        ["itemLink"] = 2869,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [167369] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Solitude Well, Covered",
                ["oldestTime"] = 1633198249,
                ["wasAltered"] = true,
                ["newestTime"] = 1633198249,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1472,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633198249,
                        ["quant"] = 1,
                        ["id"] = "1691771377",
                        ["itemLink"] = 2159,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [123503] = 
        {
            ["50:16:4:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_medium_chest_a.dds",
                ["itemDesc"] = "Coward's Gear Jack",
                ["oldestTime"] = 1633291940,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291940,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633291940,
                        ["quant"] = 1,
                        ["id"] = "1692651183",
                        ["itemLink"] = 2797,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set coward's gear chest training",
            },
        },
        [147743] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 75: Sunspire Staves",
                ["oldestTime"] = 1633006360,
                ["wasAltered"] = true,
                ["newestTime"] = 1633006360,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3999,
                        ["guild"] = 1,
                        ["buyer"] = 421,
                        ["wasKiosk"] = true,
                        ["seller"] = 417,
                        ["timestamp"] = 1633006360,
                        ["quant"] = 1,
                        ["id"] = "1690267123",
                        ["itemLink"] = 430,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [114892] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_furniture_base_mundante_rune.dds",
                ["itemDesc"] = "Mundane Rune",
                ["oldestTime"] = 1632828098,
                ["wasAltered"] = true,
                ["newestTime"] = 1633315831,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 164966,
                        ["guild"] = 1,
                        ["buyer"] = 76,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1633315831,
                        ["quant"] = 200,
                        ["id"] = "1692913109",
                        ["itemLink"] = 77,
                    },
                    [2] = 
                    {
                        ["price"] = 21600,
                        ["guild"] = 1,
                        ["buyer"] = 73,
                        ["wasKiosk"] = false,
                        ["seller"] = 179,
                        ["timestamp"] = 1632989399,
                        ["quant"] = 24,
                        ["id"] = "1690183173",
                        ["itemLink"] = 77,
                    },
                    [3] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 460,
                        ["wasKiosk"] = true,
                        ["seller"] = 461,
                        ["timestamp"] = 1633013703,
                        ["quant"] = 28,
                        ["id"] = "1690314871",
                        ["itemLink"] = 77,
                    },
                    [4] = 
                    {
                        ["price"] = 31320,
                        ["guild"] = 1,
                        ["buyer"] = 644,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633044466,
                        ["quant"] = 36,
                        ["id"] = "1690551599",
                        ["itemLink"] = 77,
                    },
                    [5] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 70,
                        ["timestamp"] = 1633071399,
                        ["quant"] = 20,
                        ["id"] = "1690787113",
                        ["itemLink"] = 77,
                    },
                    [6] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 70,
                        ["timestamp"] = 1633071401,
                        ["quant"] = 20,
                        ["id"] = "1690787121",
                        ["itemLink"] = 77,
                    },
                    [7] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 70,
                        ["timestamp"] = 1633071402,
                        ["quant"] = 20,
                        ["id"] = "1690787127",
                        ["itemLink"] = 77,
                    },
                    [8] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 70,
                        ["timestamp"] = 1633071404,
                        ["quant"] = 20,
                        ["id"] = "1690787135",
                        ["itemLink"] = 77,
                    },
                    [9] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 70,
                        ["timestamp"] = 1633071405,
                        ["quant"] = 20,
                        ["id"] = "1690787143",
                        ["itemLink"] = 77,
                    },
                    [10] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 70,
                        ["timestamp"] = 1633071406,
                        ["quant"] = 20,
                        ["id"] = "1690787157",
                        ["itemLink"] = 77,
                    },
                    [11] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 70,
                        ["timestamp"] = 1633071408,
                        ["quant"] = 20,
                        ["id"] = "1690787177",
                        ["itemLink"] = 77,
                    },
                    [12] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 70,
                        ["timestamp"] = 1633071409,
                        ["quant"] = 20,
                        ["id"] = "1690787187",
                        ["itemLink"] = 77,
                    },
                    [13] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 70,
                        ["timestamp"] = 1633071410,
                        ["quant"] = 20,
                        ["id"] = "1690787201",
                        ["itemLink"] = 77,
                    },
                    [14] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 70,
                        ["timestamp"] = 1633071411,
                        ["quant"] = 20,
                        ["id"] = "1690787213",
                        ["itemLink"] = 77,
                    },
                    [15] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 70,
                        ["timestamp"] = 1633071412,
                        ["quant"] = 20,
                        ["id"] = "1690787229",
                        ["itemLink"] = 77,
                    },
                    [16] = 
                    {
                        ["price"] = 27200,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 158,
                        ["timestamp"] = 1633071416,
                        ["quant"] = 32,
                        ["id"] = "1690787241",
                        ["itemLink"] = 77,
                    },
                    [17] = 
                    {
                        ["price"] = 190000,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 593,
                        ["timestamp"] = 1633071434,
                        ["quant"] = 200,
                        ["id"] = "1690787339",
                        ["itemLink"] = 77,
                    },
                    [18] = 
                    {
                        ["price"] = 26670,
                        ["guild"] = 1,
                        ["buyer"] = 1113,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633131620,
                        ["quant"] = 30,
                        ["id"] = "1691204375",
                        ["itemLink"] = 77,
                    },
                    [19] = 
                    {
                        ["price"] = 26670,
                        ["guild"] = 1,
                        ["buyer"] = 1113,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633131623,
                        ["quant"] = 30,
                        ["id"] = "1691204411",
                        ["itemLink"] = 77,
                    },
                    [20] = 
                    {
                        ["price"] = 28800,
                        ["guild"] = 1,
                        ["buyer"] = 1202,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633142349,
                        ["quant"] = 32,
                        ["id"] = "1691317635",
                        ["itemLink"] = 77,
                    },
                    [21] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1348,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633173803,
                        ["quant"] = 20,
                        ["id"] = "1691540081",
                        ["itemLink"] = 77,
                    },
                    [22] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1348,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633173804,
                        ["quant"] = 20,
                        ["id"] = "1691540101",
                        ["itemLink"] = 77,
                    },
                    [23] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1040,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633203151,
                        ["quant"] = 20,
                        ["id"] = "1691824435",
                        ["itemLink"] = 77,
                    },
                    [24] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1040,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633203152,
                        ["quant"] = 20,
                        ["id"] = "1691824441",
                        ["itemLink"] = 77,
                    },
                    [25] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1040,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633203153,
                        ["quant"] = 20,
                        ["id"] = "1691824449",
                        ["itemLink"] = 77,
                    },
                    [26] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1040,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633203154,
                        ["quant"] = 20,
                        ["id"] = "1691824465",
                        ["itemLink"] = 77,
                    },
                    [27] = 
                    {
                        ["price"] = 149966,
                        ["guild"] = 1,
                        ["buyer"] = 1573,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633214310,
                        ["quant"] = 167,
                        ["id"] = "1691952511",
                        ["itemLink"] = 77,
                    },
                    [28] = 
                    {
                        ["price"] = 93599,
                        ["guild"] = 1,
                        ["buyer"] = 1573,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633214313,
                        ["quant"] = 100,
                        ["id"] = "1691952533",
                        ["itemLink"] = 77,
                    },
                    [29] = 
                    {
                        ["price"] = 93599,
                        ["guild"] = 1,
                        ["buyer"] = 1573,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633214314,
                        ["quant"] = 100,
                        ["id"] = "1691952541",
                        ["itemLink"] = 77,
                    },
                    [30] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1597,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633218196,
                        ["quant"] = 20,
                        ["id"] = "1691992469",
                        ["itemLink"] = 77,
                    },
                    [31] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1597,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633218200,
                        ["quant"] = 20,
                        ["id"] = "1691992551",
                        ["itemLink"] = 77,
                    },
                    [32] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 73,
                        ["wasKiosk"] = false,
                        ["seller"] = 95,
                        ["timestamp"] = 1633219295,
                        ["quant"] = 20,
                        ["id"] = "1692005417",
                        ["itemLink"] = 77,
                    },
                    [33] = 
                    {
                        ["price"] = 2700,
                        ["guild"] = 1,
                        ["buyer"] = 521,
                        ["wasKiosk"] = false,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633227650,
                        ["quant"] = 4,
                        ["id"] = "1692092387",
                        ["itemLink"] = 77,
                    },
                    [34] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1688,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633230111,
                        ["quant"] = 4,
                        ["id"] = "1692116357",
                        ["itemLink"] = 77,
                    },
                    [35] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1688,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633230113,
                        ["quant"] = 20,
                        ["id"] = "1692116361",
                        ["itemLink"] = 77,
                    },
                    [36] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1688,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633230114,
                        ["quant"] = 20,
                        ["id"] = "1692116365",
                        ["itemLink"] = 77,
                    },
                    [37] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1688,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633230115,
                        ["quant"] = 20,
                        ["id"] = "1692116371",
                        ["itemLink"] = 77,
                    },
                    [38] = 
                    {
                        ["price"] = 21250,
                        ["guild"] = 1,
                        ["buyer"] = 1688,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633230120,
                        ["quant"] = 25,
                        ["id"] = "1692116397",
                        ["itemLink"] = 77,
                    },
                    [39] = 
                    {
                        ["price"] = 21250,
                        ["guild"] = 1,
                        ["buyer"] = 1688,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633230121,
                        ["quant"] = 25,
                        ["id"] = "1692116403",
                        ["itemLink"] = 77,
                    },
                    [40] = 
                    {
                        ["price"] = 35465,
                        ["guild"] = 1,
                        ["buyer"] = 1688,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633230123,
                        ["quant"] = 41,
                        ["id"] = "1692116411",
                        ["itemLink"] = 77,
                    },
                    [41] = 
                    {
                        ["price"] = 21250,
                        ["guild"] = 1,
                        ["buyer"] = 1777,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633241106,
                        ["quant"] = 25,
                        ["id"] = "1692205387",
                        ["itemLink"] = 77,
                    },
                    [42] = 
                    {
                        ["price"] = 4200,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633252094,
                        ["quant"] = 6,
                        ["id"] = "1692286429",
                        ["itemLink"] = 77,
                    },
                    [43] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 1860,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633267181,
                        ["quant"] = 1,
                        ["id"] = "1692376443",
                        ["itemLink"] = 77,
                    },
                    [44] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1860,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633267183,
                        ["quant"] = 1,
                        ["id"] = "1692376459",
                        ["itemLink"] = 77,
                    },
                    [45] = 
                    {
                        ["price"] = 12750,
                        ["guild"] = 1,
                        ["buyer"] = 1088,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633295049,
                        ["quant"] = 15,
                        ["id"] = "1692690927",
                        ["itemLink"] = 77,
                    },
                    [46] = 
                    {
                        ["price"] = 8998,
                        ["guild"] = 1,
                        ["buyer"] = 1088,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633295056,
                        ["quant"] = 10,
                        ["id"] = "1692690991",
                        ["itemLink"] = 77,
                    },
                    [47] = 
                    {
                        ["price"] = 181800,
                        ["guild"] = 1,
                        ["buyer"] = 2015,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633295278,
                        ["quant"] = 200,
                        ["id"] = "1692693019",
                        ["itemLink"] = 77,
                    },
                    [48] = 
                    {
                        ["price"] = 63750,
                        ["guild"] = 1,
                        ["buyer"] = 900,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633297876,
                        ["quant"] = 75,
                        ["id"] = "1692719543",
                        ["itemLink"] = 77,
                    },
                    [49] = 
                    {
                        ["price"] = 45500,
                        ["guild"] = 1,
                        ["buyer"] = 428,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632828098,
                        ["quant"] = 50,
                        ["id"] = "1688983803",
                        ["itemLink"] = 77,
                    },
                    [50] = 
                    {
                        ["price"] = 45500,
                        ["guild"] = 1,
                        ["buyer"] = 2129,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632829756,
                        ["quant"] = 50,
                        ["id"] = "1688997169",
                        ["itemLink"] = 77,
                    },
                    [51] = 
                    {
                        ["price"] = 11050,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632861527,
                        ["quant"] = 13,
                        ["id"] = "1689241347",
                        ["itemLink"] = 77,
                    },
                    [52] = 
                    {
                        ["price"] = 46920,
                        ["guild"] = 1,
                        ["buyer"] = 262,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1632861998,
                        ["quant"] = 51,
                        ["id"] = "1689244393",
                        ["itemLink"] = 77,
                    },
                    [53] = 
                    {
                        ["price"] = 23500,
                        ["guild"] = 1,
                        ["buyer"] = 262,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1632862005,
                        ["quant"] = 25,
                        ["id"] = "1689244449",
                        ["itemLink"] = 77,
                    },
                    [54] = 
                    {
                        ["price"] = 23500,
                        ["guild"] = 1,
                        ["buyer"] = 262,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1632862006,
                        ["quant"] = 25,
                        ["id"] = "1689244463",
                        ["itemLink"] = 77,
                    },
                    [55] = 
                    {
                        ["price"] = 23500,
                        ["guild"] = 1,
                        ["buyer"] = 262,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1632862007,
                        ["quant"] = 25,
                        ["id"] = "1689244473",
                        ["itemLink"] = 77,
                    },
                    [56] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 262,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1632862012,
                        ["quant"] = 20,
                        ["id"] = "1689244499",
                        ["itemLink"] = 77,
                    },
                    [57] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 262,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1632862012,
                        ["quant"] = 20,
                        ["id"] = "1689244509",
                        ["itemLink"] = 77,
                    },
                    [58] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 262,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1632862013,
                        ["quant"] = 20,
                        ["id"] = "1689244519",
                        ["itemLink"] = 77,
                    },
                    [59] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 262,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1632862014,
                        ["quant"] = 20,
                        ["id"] = "1689244533",
                        ["itemLink"] = 77,
                    },
                    [60] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 262,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1632862015,
                        ["quant"] = 20,
                        ["id"] = "1689244541",
                        ["itemLink"] = 77,
                    },
                    [61] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 262,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1632862015,
                        ["quant"] = 20,
                        ["id"] = "1689244545",
                        ["itemLink"] = 77,
                    },
                    [62] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 262,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1632862016,
                        ["quant"] = 20,
                        ["id"] = "1689244549",
                        ["itemLink"] = 77,
                    },
                    [63] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 262,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1632862018,
                        ["quant"] = 20,
                        ["id"] = "1689244567",
                        ["itemLink"] = 77,
                    },
                    [64] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 262,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1632862018,
                        ["quant"] = 20,
                        ["id"] = "1689244575",
                        ["itemLink"] = 77,
                    },
                    [65] = 
                    {
                        ["price"] = 47000,
                        ["guild"] = 1,
                        ["buyer"] = 2268,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632865983,
                        ["quant"] = 50,
                        ["id"] = "1689272453",
                        ["itemLink"] = 77,
                    },
                    [66] = 
                    {
                        ["price"] = 22500,
                        ["guild"] = 1,
                        ["buyer"] = 1142,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632939051,
                        ["quant"] = 25,
                        ["id"] = "1689787765",
                        ["itemLink"] = 77,
                    },
                    [67] = 
                    {
                        ["price"] = 180000,
                        ["guild"] = 1,
                        ["buyer"] = 1142,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1632939055,
                        ["quant"] = 200,
                        ["id"] = "1689787779",
                        ["itemLink"] = 77,
                    },
                    [68] = 
                    {
                        ["price"] = 130200,
                        ["guild"] = 1,
                        ["buyer"] = 1142,
                        ["wasKiosk"] = true,
                        ["seller"] = 763,
                        ["timestamp"] = 1632939063,
                        ["quant"] = 140,
                        ["id"] = "1689787811",
                        ["itemLink"] = 77,
                    },
                    [69] = 
                    {
                        ["price"] = 93599,
                        ["guild"] = 1,
                        ["buyer"] = 1142,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1632939064,
                        ["quant"] = 100,
                        ["id"] = "1689787819",
                        ["itemLink"] = 77,
                    },
                    [70] = 
                    {
                        ["price"] = 47000,
                        ["guild"] = 1,
                        ["buyer"] = 1142,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632939075,
                        ["quant"] = 50,
                        ["id"] = "1689787835",
                        ["itemLink"] = 77,
                    },
                    [71] = 
                    {
                        ["price"] = 35670,
                        ["guild"] = 1,
                        ["buyer"] = 193,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632949650,
                        ["quant"] = 41,
                        ["id"] = "1689871627",
                        ["itemLink"] = 77,
                    },
                    [72] = 
                    {
                        ["price"] = 23800,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 158,
                        ["timestamp"] = 1632954448,
                        ["quant"] = 28,
                        ["id"] = "1689913809",
                        ["itemLink"] = 77,
                    },
                    [73] = 
                    {
                        ["price"] = 6800,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 179,
                        ["timestamp"] = 1632954451,
                        ["quant"] = 8,
                        ["id"] = "1689913833",
                        ["itemLink"] = 77,
                    },
                },
                ["totalCount"] = 73,
                ["itemAdderText"] = "rr01 white normal materials furnishing",
            },
        },
        [167809] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_waywardguardianmed_waist_a.dds",
                ["itemDesc"] = "Witch-Knight's Belt",
                ["oldestTime"] = 1633288216,
                ["wasAltered"] = true,
                ["newestTime"] = 1633288216,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2555,
                        ["guild"] = 1,
                        ["buyer"] = 1969,
                        ["wasKiosk"] = true,
                        ["seller"] = 494,
                        ["timestamp"] = 1633288216,
                        ["quant"] = 1,
                        ["id"] = "1692606847",
                        ["itemLink"] = 2768,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set witch-knight's defiance waist divines",
            },
        },
        [122830] = 
        {
            ["50:16:5:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_telvanni_light_hands_a.dds",
                ["itemDesc"] = "War Maiden's Gloves",
                ["oldestTime"] = 1632992866,
                ["wasAltered"] = true,
                ["newestTime"] = 1632992866,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 225000,
                        ["guild"] = 1,
                        ["buyer"] = 364,
                        ["wasKiosk"] = true,
                        ["seller"] = 185,
                        ["timestamp"] = 1632992866,
                        ["quant"] = 1,
                        ["id"] = "1690200043",
                        ["itemLink"] = 361,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary light apparel set war maiden hands divines",
            },
        },
        [69071] = 
        {
            ["50:16:4:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_staff_d.dds",
                ["itemDesc"] = "Lightning Staff of Endurance",
                ["oldestTime"] = 1632938262,
                ["wasAltered"] = true,
                ["newestTime"] = 1632938262,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1137,
                        ["guild"] = 1,
                        ["buyer"] = 2533,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1632938262,
                        ["quant"] = 1,
                        ["id"] = "1689783057",
                        ["itemLink"] = 3752,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set endurance lightning staff two-handed infused",
            },
        },
        [71557] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 22: Trinimac Gloves",
                ["oldestTime"] = 1633041176,
                ["wasAltered"] = true,
                ["newestTime"] = 1633301405,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15400,
                        ["guild"] = 1,
                        ["buyer"] = 632,
                        ["wasKiosk"] = true,
                        ["seller"] = 633,
                        ["timestamp"] = 1633041176,
                        ["quant"] = 1,
                        ["id"] = "1690521871",
                        ["itemLink"] = 803,
                    },
                    [2] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 242,
                        ["wasKiosk"] = false,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633195662,
                        ["quant"] = 1,
                        ["id"] = "1691747935",
                        ["itemLink"] = 803,
                    },
                    [3] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 1477,
                        ["wasKiosk"] = true,
                        ["seller"] = 981,
                        ["timestamp"] = 1633199485,
                        ["quant"] = 1,
                        ["id"] = "1691783957",
                        ["itemLink"] = 803,
                    },
                    [4] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 352,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633301405,
                        ["quant"] = 1,
                        ["id"] = "1692755463",
                        ["itemLink"] = 803,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [95494] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_light_shoulders_a.dds",
                ["itemDesc"] = "Epaulets of Martial Knowledge",
                ["oldestTime"] = 1633016665,
                ["wasAltered"] = true,
                ["newestTime"] = 1633016665,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 477,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1633016665,
                        ["quant"] = 1,
                        ["id"] = "1690338907",
                        ["itemLink"] = 545,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set way of martial knowledge shoulders divines",
            },
        },
        [7386] = 
        {
            ["50:16:2:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_1hhammer_d.dds",
                ["itemDesc"] = "Rebellion Mace",
                ["oldestTime"] = 1633254249,
                ["wasAltered"] = true,
                ["newestTime"] = 1633254249,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1827,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1633254249,
                        ["quant"] = 1,
                        ["id"] = "1692297705",
                        ["itemLink"] = 2612,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon mace one-handed sharpened",
            },
        },
        [45333] = 
        {
            ["50:16:1:10:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_1haxe_d.dds",
                ["itemDesc"] = "Rubedite Axe",
                ["oldestTime"] = 1633185904,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185904,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 475,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633185904,
                        ["quant"] = 1,
                        ["id"] = "1691639671",
                        ["itemLink"] = 2005,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal weapon axe one-handed ornate",
            },
        },
        [64724] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 19: Mercenary Legs",
                ["oldestTime"] = 1633055558,
                ["wasAltered"] = true,
                ["newestTime"] = 1633055558,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 749,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633055558,
                        ["quant"] = 1,
                        ["id"] = "1690660151",
                        ["itemLink"] = 948,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [58483] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_light_robe_a.dds",
                ["itemDesc"] = "Robe of the Twice-Born Star",
                ["oldestTime"] = 1633240249,
                ["wasAltered"] = true,
                ["newestTime"] = 1633240249,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1767,
                        ["wasKiosk"] = true,
                        ["seller"] = 832,
                        ["timestamp"] = 1633240249,
                        ["quant"] = 1,
                        ["id"] = "1692199163",
                        ["itemLink"] = 2527,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set twice-born star chest divines",
            },
        },
        [156630] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 80: Shield of Senchal Boots",
                ["oldestTime"] = 1633143619,
                ["wasAltered"] = true,
                ["newestTime"] = 1633143619,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1218,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633143619,
                        ["quant"] = 1,
                        ["id"] = "1691332415",
                        ["itemLink"] = 1641,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [171479] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_cwc_lsb_lightcapsulenoglow001.dds",
                ["itemDesc"] = "Sealed Fabrication Materials",
                ["oldestTime"] = 1632919054,
                ["wasAltered"] = true,
                ["newestTime"] = 1633143793,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15992,
                        ["guild"] = 1,
                        ["buyer"] = 1219,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633143793,
                        ["quant"] = 8,
                        ["id"] = "1691334831",
                        ["itemLink"] = 1642,
                    },
                    [2] = 
                    {
                        ["price"] = 21000,
                        ["guild"] = 1,
                        ["buyer"] = 366,
                        ["wasKiosk"] = true,
                        ["seller"] = 461,
                        ["timestamp"] = 1632919054,
                        ["quant"] = 7,
                        ["id"] = "1689646619",
                        ["itemLink"] = 1642,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [33752] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_food_003.dds",
                ["itemDesc"] = "Red Meat",
                ["oldestTime"] = 1633219262,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305856,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2800,
                        ["guild"] = 1,
                        ["buyer"] = 73,
                        ["wasKiosk"] = false,
                        ["seller"] = 649,
                        ["timestamp"] = 1633219262,
                        ["quant"] = 200,
                        ["id"] = "1692005171",
                        ["itemLink"] = 2340,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633305856,
                        ["quant"] = 200,
                        ["id"] = "1692799007",
                        ["itemLink"] = 2340,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [149465] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_shield_a.dds",
                ["itemDesc"] = "Darloc Brae's Shield",
                ["oldestTime"] = 1632967698,
                ["wasAltered"] = true,
                ["newestTime"] = 1632967698,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2669,
                        ["wasKiosk"] = true,
                        ["seller"] = 171,
                        ["timestamp"] = 1632967698,
                        ["quant"] = 1,
                        ["id"] = "1690030821",
                        ["itemLink"] = 3975,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior apparel weapon set vesture of darloc brae shield off hand divines",
            },
        },
        [56026] = 
        {
            ["50:16:1:26:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_1haxe_b.dds",
                ["itemDesc"] = "Rubedite Axe",
                ["oldestTime"] = 1633181865,
                ["wasAltered"] = true,
                ["newestTime"] = 1633181865,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 1374,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633181865,
                        ["quant"] = 1,
                        ["id"] = "1691602379",
                        ["itemLink"] = 1932,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal weapon axe one-handed nirnhoned",
            },
        },
        [137947] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_gen_crf_portabletablejewelry001.dds",
                ["itemDesc"] = "Attunable Jewelry Crafting Station",
                ["oldestTime"] = 1633022594,
                ["wasAltered"] = true,
                ["newestTime"] = 1633148426,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 275000,
                        ["guild"] = 1,
                        ["buyer"] = 520,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1633022594,
                        ["quant"] = 1,
                        ["id"] = "1690387189",
                        ["itemLink"] = 594,
                    },
                    [2] = 
                    {
                        ["price"] = 275000,
                        ["guild"] = 1,
                        ["buyer"] = 1247,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1633148425,
                        ["quant"] = 1,
                        ["id"] = "1691377231",
                        ["itemLink"] = 594,
                    },
                    [3] = 
                    {
                        ["price"] = 275000,
                        ["guild"] = 1,
                        ["buyer"] = 1247,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1633148426,
                        ["quant"] = 1,
                        ["id"] = "1691377245",
                        ["itemLink"] = 594,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 gold legendary consumable trophy",
            },
        },
        [26844] = 
        {
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_shockessence.dds",
                ["itemDesc"] = "Truly Superb Glyph of Shock",
                ["oldestTime"] = 1632853897,
                ["wasAltered"] = true,
                ["newestTime"] = 1632853897,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 797,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632853897,
                        ["quant"] = 1,
                        ["id"] = "1689174439",
                        ["itemLink"] = 3259,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous weapon glyph",
            },
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_shockessence.dds",
                ["itemDesc"] = "Truly Superb Glyph of Shock",
                ["oldestTime"] = 1632826386,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297965,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 398,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633001132,
                        ["quant"] = 1,
                        ["id"] = "1690240019",
                        ["itemLink"] = 403,
                    },
                    [2] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633032461,
                        ["quant"] = 1,
                        ["id"] = "1690460857",
                        ["itemLink"] = 728,
                    },
                    [3] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633032462,
                        ["quant"] = 1,
                        ["id"] = "1690460865",
                        ["itemLink"] = 403,
                    },
                    [4] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633032464,
                        ["quant"] = 1,
                        ["id"] = "1690460905",
                        ["itemLink"] = 731,
                    },
                    [5] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1025,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633115974,
                        ["quant"] = 1,
                        ["id"] = "1691078605",
                        ["itemLink"] = 1405,
                    },
                    [6] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 1244,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633148040,
                        ["quant"] = 1,
                        ["id"] = "1691374119",
                        ["itemLink"] = 728,
                    },
                    [7] = 
                    {
                        ["price"] = 127,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633297957,
                        ["quant"] = 1,
                        ["id"] = "1692720415",
                        ["itemLink"] = 2895,
                    },
                    [8] = 
                    {
                        ["price"] = 127,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633297965,
                        ["quant"] = 1,
                        ["id"] = "1692720463",
                        ["itemLink"] = 403,
                    },
                    [9] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632826386,
                        ["quant"] = 1,
                        ["id"] = "1688971311",
                        ["itemLink"] = 403,
                    },
                    [10] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2201,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632846650,
                        ["quant"] = 1,
                        ["id"] = "1689115597",
                        ["itemLink"] = 1405,
                    },
                    [11] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632885361,
                        ["quant"] = 1,
                        ["id"] = "1689456655",
                        ["itemLink"] = 731,
                    },
                    [12] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 2425,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632893293,
                        ["quant"] = 1,
                        ["id"] = "1689518731",
                        ["itemLink"] = 1405,
                    },
                },
                ["totalCount"] = 12,
                ["itemAdderText"] = "cp160 white normal miscellaneous weapon glyph",
            },
        },
        [69785] = 
        {
            ["50:16:5:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_staff_d.dds",
                ["itemDesc"] = "Lightning Staff of Julianos",
                ["oldestTime"] = 1633234951,
                ["wasAltered"] = true,
                ["newestTime"] = 1633234951,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1726,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633234951,
                        ["quant"] = 1,
                        ["id"] = "1692160493",
                        ["itemLink"] = 2474,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary weapon set law of julianos lightning staff two-handed infused",
            },
        },
        [127096] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Telvanni Lamp, Organic Azure",
                ["oldestTime"] = 1633234315,
                ["wasAltered"] = true,
                ["newestTime"] = 1633234315,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 135000,
                        ["guild"] = 1,
                        ["buyer"] = 1720,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633234315,
                        ["quant"] = 1,
                        ["id"] = "1692156153",
                        ["itemLink"] = 2467,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [26847] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_diseaseresist.dds",
                ["itemDesc"] = "Superb Glyph of Disease Resist",
                ["oldestTime"] = 1633087413,
                ["wasAltered"] = true,
                ["newestTime"] = 1633087413,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 130,
                        ["guild"] = 1,
                        ["buyer"] = 398,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633087413,
                        ["quant"] = 1,
                        ["id"] = "1690872653",
                        ["itemLink"] = 1228,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 green fine miscellaneous jewelry glyph",
            },
        },
        [56032] = 
        {
            ["1:0:1:26:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_dagger_a.dds",
                ["itemDesc"] = "Iron Dagger",
                ["oldestTime"] = 1633031913,
                ["wasAltered"] = true,
                ["newestTime"] = 1633316291,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 34500,
                        ["guild"] = 1,
                        ["buyer"] = 568,
                        ["wasKiosk"] = true,
                        ["seller"] = 569,
                        ["timestamp"] = 1633031913,
                        ["quant"] = 1,
                        ["id"] = "1690456427",
                        ["itemLink"] = 723,
                    },
                    [2] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 2094,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633316291,
                        ["quant"] = 1,
                        ["id"] = "1692918115",
                        ["itemLink"] = 3003,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal weapon dagger one-handed nirnhoned",
            },
        },
        [23265] = 
        {
            ["30:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_potion_base_water_3_r1.dds",
                ["itemDesc"] = "Cleansed Water",
                ["oldestTime"] = 1632851205,
                ["wasAltered"] = true,
                ["newestTime"] = 1632851205,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 36000,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632851205,
                        ["quant"] = 200,
                        ["id"] = "1689153147",
                        ["itemLink"] = 3243,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr30 white normal materials potion solvent",
            },
        },
        [180706] = 
        {
            ["50:16:4:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_2hhammer_a.dds",
                ["itemDesc"] = "Plaguebreak Maul",
                ["oldestTime"] = 1633112062,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112062,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9876,
                        ["guild"] = 1,
                        ["buyer"] = 989,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633112062,
                        ["quant"] = 1,
                        ["id"] = "1691052705",
                        ["itemLink"] = 1340,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set plaguebreak mace two-handed charged",
            },
        },
        [45539] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Cloudrest Golden Ale",
                ["oldestTime"] = 1633242699,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242699,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 716,
                        ["guild"] = 1,
                        ["buyer"] = 348,
                        ["wasKiosk"] = false,
                        ["seller"] = 152,
                        ["timestamp"] = 1633242699,
                        ["quant"] = 1,
                        ["id"] = "1692215369",
                        ["itemLink"] = 2551,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [127072] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Indoril Banner, Sotha Sil",
                ["oldestTime"] = 1633234210,
                ["wasAltered"] = true,
                ["newestTime"] = 1633234210,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1720,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633234210,
                        ["quant"] = 1,
                        ["id"] = "1692155427",
                        ["itemLink"] = 2464,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [57573] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 15: Dwemer Axes",
                ["oldestTime"] = 1633179688,
                ["wasAltered"] = true,
                ["newestTime"] = 1633179688,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1296,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633179688,
                        ["quant"] = 1,
                        ["id"] = "1691583739",
                        ["itemLink"] = 1918,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [130022] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 52: Redoran Shoulders",
                ["oldestTime"] = 1633143427,
                ["wasAltered"] = true,
                ["newestTime"] = 1633143427,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12999,
                        ["guild"] = 1,
                        ["buyer"] = 1213,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633143427,
                        ["quant"] = 1,
                        ["id"] = "1691330813",
                        ["itemLink"] = 1636,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [33255] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_smith_plug_sp_names_001.dds",
                ["itemDesc"] = "Moonstone",
                ["oldestTime"] = 1632921302,
                ["wasAltered"] = true,
                ["newestTime"] = 1632921302,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1403,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1632921302,
                        ["quant"] = 200,
                        ["id"] = "1689659935",
                        ["itemLink"] = 3656,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [120808] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_alt_exc_altmerbase001.dds",
                ["itemDesc"] = "Statue Base, Circular",
                ["oldestTime"] = 1633289470,
                ["wasAltered"] = true,
                ["newestTime"] = 1633289470,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 1975,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633289470,
                        ["quant"] = 5,
                        ["id"] = "1692621081",
                        ["itemLink"] = 2775,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings structures",
            },
        },
        [160544] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 85: Greymoor Belts",
                ["oldestTime"] = 1633145163,
                ["wasAltered"] = true,
                ["newestTime"] = 1633145163,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15500,
                        ["guild"] = 1,
                        ["buyer"] = 828,
                        ["wasKiosk"] = true,
                        ["seller"] = 611,
                        ["timestamp"] = 1633145163,
                        ["quant"] = 1,
                        ["id"] = "1691348319",
                        ["itemLink"] = 1648,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45615] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Comberry Tonic",
                ["oldestTime"] = 1633140935,
                ["wasAltered"] = true,
                ["newestTime"] = 1633140935,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 78,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633140935,
                        ["quant"] = 1,
                        ["id"] = "1691300711",
                        ["itemLink"] = 1610,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [26587] = 
        {
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_poisonessence.dds",
                ["itemDesc"] = "Truly Superb Glyph of Poison",
                ["oldestTime"] = 1633241277,
                ["wasAltered"] = true,
                ["newestTime"] = 1633295169,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6200,
                        ["guild"] = 1,
                        ["buyer"] = 1779,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1633241277,
                        ["quant"] = 1,
                        ["id"] = "1692206607",
                        ["itemLink"] = 2539,
                    },
                    [2] = 
                    {
                        ["price"] = 6200,
                        ["guild"] = 1,
                        ["buyer"] = 2014,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1633295169,
                        ["quant"] = 1,
                        ["id"] = "1692691941",
                        ["itemLink"] = 2539,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous weapon glyph",
            },
            ["50:15:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_poisonessence.dds",
                ["itemDesc"] = "Superb Glyph of Poison",
                ["oldestTime"] = 1633218687,
                ["wasAltered"] = true,
                ["newestTime"] = 1633251481,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 355,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633218687,
                        ["quant"] = 1,
                        ["id"] = "1691997609",
                        ["itemLink"] = 2332,
                    },
                    [2] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633251481,
                        ["quant"] = 1,
                        ["id"] = "1692280593",
                        ["itemLink"] = 2332,
                    },
                    [3] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633251481,
                        ["quant"] = 1,
                        ["id"] = "1692280597",
                        ["itemLink"] = 2332,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp150 purple epic miscellaneous weapon glyph",
            },
        },
        [135148] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/jewelrycrafting_booster_refined_iridium.dds",
                ["itemDesc"] = "Iridium Plating",
                ["oldestTime"] = 1632851532,
                ["wasAltered"] = true,
                ["newestTime"] = 1633282417,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 149,
                        ["wasKiosk"] = false,
                        ["seller"] = 150,
                        ["timestamp"] = 1632969459,
                        ["quant"] = 2,
                        ["id"] = "1690050797",
                        ["itemLink"] = 163,
                    },
                    [2] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 149,
                        ["wasKiosk"] = false,
                        ["seller"] = 151,
                        ["timestamp"] = 1632969460,
                        ["quant"] = 2,
                        ["id"] = "1690050805",
                        ["itemLink"] = 163,
                    },
                    [3] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 149,
                        ["wasKiosk"] = false,
                        ["seller"] = 151,
                        ["timestamp"] = 1632969461,
                        ["quant"] = 2,
                        ["id"] = "1690050819",
                        ["itemLink"] = 163,
                    },
                    [4] = 
                    {
                        ["price"] = 52000,
                        ["guild"] = 1,
                        ["buyer"] = 149,
                        ["wasKiosk"] = false,
                        ["seller"] = 8,
                        ["timestamp"] = 1632969462,
                        ["quant"] = 4,
                        ["id"] = "1690050831",
                        ["itemLink"] = 163,
                    },
                    [5] = 
                    {
                        ["price"] = 66015,
                        ["guild"] = 1,
                        ["buyer"] = 149,
                        ["wasKiosk"] = false,
                        ["seller"] = 152,
                        ["timestamp"] = 1632969464,
                        ["quant"] = 5,
                        ["id"] = "1690050843",
                        ["itemLink"] = 163,
                    },
                    [6] = 
                    {
                        ["price"] = 13500,
                        ["guild"] = 1,
                        ["buyer"] = 149,
                        ["wasKiosk"] = false,
                        ["seller"] = 35,
                        ["timestamp"] = 1632969465,
                        ["quant"] = 1,
                        ["id"] = "1690050849",
                        ["itemLink"] = 163,
                    },
                    [7] = 
                    {
                        ["price"] = 13500,
                        ["guild"] = 1,
                        ["buyer"] = 149,
                        ["wasKiosk"] = false,
                        ["seller"] = 153,
                        ["timestamp"] = 1632969466,
                        ["quant"] = 1,
                        ["id"] = "1690050859",
                        ["itemLink"] = 163,
                    },
                    [8] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 286,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1632982160,
                        ["quant"] = 1,
                        ["id"] = "1690143253",
                        ["itemLink"] = 163,
                    },
                    [9] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 362,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1632992503,
                        ["quant"] = 2,
                        ["id"] = "1690198651",
                        ["itemLink"] = 163,
                    },
                    [10] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 362,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1632992505,
                        ["quant"] = 1,
                        ["id"] = "1690198665",
                        ["itemLink"] = 163,
                    },
                    [11] = 
                    {
                        ["price"] = 26621,
                        ["guild"] = 1,
                        ["buyer"] = 635,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633041388,
                        ["quant"] = 2,
                        ["id"] = "1690523629",
                        ["itemLink"] = 163,
                    },
                    [12] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 343,
                        ["timestamp"] = 1633078800,
                        ["quant"] = 2,
                        ["id"] = "1690830923",
                        ["itemLink"] = 163,
                    },
                    [13] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633105264,
                        ["quant"] = 2,
                        ["id"] = "1691003969",
                        ["itemLink"] = 163,
                    },
                    [14] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633105265,
                        ["quant"] = 2,
                        ["id"] = "1691003973",
                        ["itemLink"] = 163,
                    },
                    [15] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633105265,
                        ["quant"] = 2,
                        ["id"] = "1691003981",
                        ["itemLink"] = 163,
                    },
                    [16] = 
                    {
                        ["price"] = 23912,
                        ["guild"] = 1,
                        ["buyer"] = 1042,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633119015,
                        ["quant"] = 2,
                        ["id"] = "1691098207",
                        ["itemLink"] = 163,
                    },
                    [17] = 
                    {
                        ["price"] = 23912,
                        ["guild"] = 1,
                        ["buyer"] = 1042,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633119015,
                        ["quant"] = 2,
                        ["id"] = "1691098213",
                        ["itemLink"] = 163,
                    },
                    [18] = 
                    {
                        ["price"] = 23912,
                        ["guild"] = 1,
                        ["buyer"] = 1042,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633119016,
                        ["quant"] = 2,
                        ["id"] = "1691098223",
                        ["itemLink"] = 163,
                    },
                    [19] = 
                    {
                        ["price"] = 23912,
                        ["guild"] = 1,
                        ["buyer"] = 1042,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633119017,
                        ["quant"] = 2,
                        ["id"] = "1691098231",
                        ["itemLink"] = 163,
                    },
                    [20] = 
                    {
                        ["price"] = 175500,
                        ["guild"] = 1,
                        ["buyer"] = 1160,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1633138414,
                        ["quant"] = 13,
                        ["id"] = "1691276519",
                        ["itemLink"] = 163,
                    },
                    [21] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 1425,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633191790,
                        ["quant"] = 1,
                        ["id"] = "1691710907",
                        ["itemLink"] = 163,
                    },
                    [22] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 1425,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633191792,
                        ["quant"] = 1,
                        ["id"] = "1691710935",
                        ["itemLink"] = 163,
                    },
                    [23] = 
                    {
                        ["price"] = 52496,
                        ["guild"] = 1,
                        ["buyer"] = 1425,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633191798,
                        ["quant"] = 4,
                        ["id"] = "1691711027",
                        ["itemLink"] = 163,
                    },
                    [24] = 
                    {
                        ["price"] = 88000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 95,
                        ["timestamp"] = 1633234960,
                        ["quant"] = 8,
                        ["id"] = "1692160511",
                        ["itemLink"] = 163,
                    },
                    [25] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633252079,
                        ["quant"] = 2,
                        ["id"] = "1692286267",
                        ["itemLink"] = 163,
                    },
                    [26] = 
                    {
                        ["price"] = 53999,
                        ["guild"] = 1,
                        ["buyer"] = 1937,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633282235,
                        ["quant"] = 4,
                        ["id"] = "1692539003",
                        ["itemLink"] = 163,
                    },
                    [27] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 1937,
                        ["wasKiosk"] = true,
                        ["seller"] = 732,
                        ["timestamp"] = 1633282237,
                        ["quant"] = 2,
                        ["id"] = "1692539013",
                        ["itemLink"] = 163,
                    },
                    [28] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 1937,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633282238,
                        ["quant"] = 2,
                        ["id"] = "1692539029",
                        ["itemLink"] = 163,
                    },
                    [29] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 1937,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633282239,
                        ["quant"] = 2,
                        ["id"] = "1692539033",
                        ["itemLink"] = 163,
                    },
                    [30] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 1939,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633282416,
                        ["quant"] = 1,
                        ["id"] = "1692540095",
                        ["itemLink"] = 163,
                    },
                    [31] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 1939,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633282417,
                        ["quant"] = 1,
                        ["id"] = "1692540097",
                        ["itemLink"] = 163,
                    },
                    [32] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1384,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1632851532,
                        ["quant"] = 1,
                        ["id"] = "1689155245",
                        ["itemLink"] = 163,
                    },
                    [33] = 
                    {
                        ["price"] = 46000,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 232,
                        ["timestamp"] = 1632939961,
                        ["quant"] = 4,
                        ["id"] = "1689794479",
                        ["itemLink"] = 163,
                    },
                },
                ["totalCount"] = 33,
                ["itemAdderText"] = "rr01 blue superior materials plating",
            },
        },
        [69326] = 
        {
            ["50:16:4:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_dagger_a.dds",
                ["itemDesc"] = "Dagger of Agility",
                ["oldestTime"] = 1633086575,
                ["wasAltered"] = true,
                ["newestTime"] = 1633086575,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4300,
                        ["guild"] = 1,
                        ["buyer"] = 137,
                        ["wasKiosk"] = true,
                        ["seller"] = 92,
                        ["timestamp"] = 1633086575,
                        ["quant"] = 1,
                        ["id"] = "1690867135",
                        ["itemLink"] = 1223,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set agility dagger one-handed decisive",
            },
        },
        [139502] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Alinor Column, Slender Timeworn",
                ["oldestTime"] = 1632865551,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865551,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 177,
                        ["timestamp"] = 1632865551,
                        ["quant"] = 1,
                        ["id"] = "1689269007",
                        ["itemLink"] = 3352,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [57839] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 17: Xivkyn Chests",
                ["oldestTime"] = 1632834525,
                ["wasAltered"] = true,
                ["newestTime"] = 1633280134,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1060,
                        ["wasKiosk"] = true,
                        ["seller"] = 1061,
                        ["timestamp"] = 1633121920,
                        ["quant"] = 1,
                        ["id"] = "1691118781",
                        ["itemLink"] = 1444,
                    },
                    [2] = 
                    {
                        ["price"] = 17232,
                        ["guild"] = 1,
                        ["buyer"] = 1926,
                        ["wasKiosk"] = true,
                        ["seller"] = 1622,
                        ["timestamp"] = 1633280121,
                        ["quant"] = 1,
                        ["id"] = "1692516709",
                        ["itemLink"] = 1444,
                    },
                    [3] = 
                    {
                        ["price"] = 120000,
                        ["guild"] = 1,
                        ["buyer"] = 1926,
                        ["wasKiosk"] = true,
                        ["seller"] = 729,
                        ["timestamp"] = 1633280134,
                        ["quant"] = 1,
                        ["id"] = "1692516899",
                        ["itemLink"] = 1444,
                    },
                    [4] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 2149,
                        ["wasKiosk"] = true,
                        ["seller"] = 1061,
                        ["timestamp"] = 1632834525,
                        ["quant"] = 1,
                        ["id"] = "1689024727",
                        ["itemLink"] = 1444,
                    },
                    [5] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 1061,
                        ["timestamp"] = 1632852254,
                        ["quant"] = 1,
                        ["id"] = "1689160843",
                        ["itemLink"] = 1444,
                    },
                    [6] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 2323,
                        ["wasKiosk"] = true,
                        ["seller"] = 1061,
                        ["timestamp"] = 1632875185,
                        ["quant"] = 1,
                        ["id"] = "1689343127",
                        ["itemLink"] = 1444,
                    },
                    [7] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 665,
                        ["wasKiosk"] = true,
                        ["seller"] = 1061,
                        ["timestamp"] = 1632968123,
                        ["quant"] = 1,
                        ["id"] = "1690036725",
                        ["itemLink"] = 1444,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [181488] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_exc_leystatuestkaladas001.dds",
                ["itemDesc"] = "Statue, Saint Kaladas",
                ["oldestTime"] = 1633216619,
                ["wasAltered"] = true,
                ["newestTime"] = 1633216619,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1590,
                        ["wasKiosk"] = true,
                        ["seller"] = 48,
                        ["timestamp"] = 1633216619,
                        ["quant"] = 1,
                        ["id"] = "1691975203",
                        ["itemLink"] = 2321,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings courtyard",
            },
        },
        [64223] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Psijic Ambrosia",
                ["oldestTime"] = 1632961437,
                ["wasAltered"] = true,
                ["newestTime"] = 1633295843,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3535,
                        ["guild"] = 1,
                        ["buyer"] = 1543,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633208820,
                        ["quant"] = 1,
                        ["id"] = "1691892583",
                        ["itemLink"] = 2267,
                    },
                    [2] = 
                    {
                        ["price"] = 3535,
                        ["guild"] = 1,
                        ["buyer"] = 495,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633226995,
                        ["quant"] = 1,
                        ["id"] = "1692085117",
                        ["itemLink"] = 2267,
                    },
                    [3] = 
                    {
                        ["price"] = 3535,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633244016,
                        ["quant"] = 1,
                        ["id"] = "1692225995",
                        ["itemLink"] = 2267,
                    },
                    [4] = 
                    {
                        ["price"] = 3535,
                        ["guild"] = 1,
                        ["buyer"] = 2020,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633295843,
                        ["quant"] = 1,
                        ["id"] = "1692698853",
                        ["itemLink"] = 2267,
                    },
                    [5] = 
                    {
                        ["price"] = 3535,
                        ["guild"] = 1,
                        ["buyer"] = 2629,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1632961437,
                        ["quant"] = 1,
                        ["id"] = "1689970785",
                        ["itemLink"] = 2267,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 gold legendary consumable recipe",
            },
        },
        [45298] = 
        {
            ["1:0:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ashlanderv_1haxe_a.dds",
                ["itemDesc"] = "Iron Axe",
                ["oldestTime"] = 1633309696,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309696,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633309696,
                        ["quant"] = 1,
                        ["id"] = "1692845859",
                        ["itemLink"] = 2978,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal weapon axe one-handed intricate",
            },
            ["50:16:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_1haxe_d.dds",
                ["itemDesc"] = "Rubedite Axe",
                ["oldestTime"] = 1632838996,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309700,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1633083997,
                        ["quant"] = 1,
                        ["id"] = "1690854395",
                        ["itemLink"] = 1148,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633185909,
                        ["quant"] = 1,
                        ["id"] = "1691639727",
                        ["itemLink"] = 2008,
                    },
                    [3] = 
                    {
                        ["price"] = 541,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 528,
                        ["timestamp"] = 1633185913,
                        ["quant"] = 1,
                        ["id"] = "1691639767",
                        ["itemLink"] = 2008,
                    },
                    [4] = 
                    {
                        ["price"] = 217,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633309692,
                        ["quant"] = 1,
                        ["id"] = "1692845811",
                        ["itemLink"] = 2975,
                    },
                    [5] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633309693,
                        ["quant"] = 1,
                        ["id"] = "1692845817",
                        ["itemLink"] = 2976,
                    },
                    [6] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633309694,
                        ["quant"] = 1,
                        ["id"] = "1692845821",
                        ["itemLink"] = 2008,
                    },
                    [7] = 
                    {
                        ["price"] = 984,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633309699,
                        ["quant"] = 1,
                        ["id"] = "1692845893",
                        ["itemLink"] = 2980,
                    },
                    [8] = 
                    {
                        ["price"] = 984,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633309699,
                        ["quant"] = 1,
                        ["id"] = "1692845897",
                        ["itemLink"] = 2976,
                    },
                    [9] = 
                    {
                        ["price"] = 984,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633309700,
                        ["quant"] = 1,
                        ["id"] = "1692845903",
                        ["itemLink"] = 2981,
                    },
                    [10] = 
                    {
                        ["price"] = 380,
                        ["guild"] = 1,
                        ["buyer"] = 2167,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632838996,
                        ["quant"] = 1,
                        ["id"] = "1689054257",
                        ["itemLink"] = 2008,
                    },
                    [11] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1632885680,
                        ["quant"] = 1,
                        ["id"] = "1689459763",
                        ["itemLink"] = 3516,
                    },
                    [12] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2424,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632892806,
                        ["quant"] = 1,
                        ["id"] = "1689514715",
                        ["itemLink"] = 2008,
                    },
                    [13] = 
                    {
                        ["price"] = 199,
                        ["guild"] = 1,
                        ["buyer"] = 2424,
                        ["wasKiosk"] = true,
                        ["seller"] = 283,
                        ["timestamp"] = 1632897933,
                        ["quant"] = 1,
                        ["id"] = "1689547889",
                        ["itemLink"] = 3568,
                    },
                    [14] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2516,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632930823,
                        ["quant"] = 1,
                        ["id"] = "1689728243",
                        ["itemLink"] = 3568,
                    },
                    [15] = 
                    {
                        ["price"] = 285,
                        ["guild"] = 1,
                        ["buyer"] = 2591,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632951464,
                        ["quant"] = 1,
                        ["id"] = "1689886977",
                        ["itemLink"] = 2976,
                    },
                    [16] = 
                    {
                        ["price"] = 190,
                        ["guild"] = 1,
                        ["buyer"] = 2501,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632954391,
                        ["quant"] = 1,
                        ["id"] = "1689913293",
                        ["itemLink"] = 1148,
                    },
                },
                ["totalCount"] = 16,
                ["itemAdderText"] = "cp160 white normal weapon axe one-handed intricate",
            },
            ["50:15:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_1haxe_d.dds",
                ["itemDesc"] = "Rubedite Axe",
                ["oldestTime"] = 1632838990,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185905,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 154,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633028884,
                        ["quant"] = 1,
                        ["id"] = "1690436655",
                        ["itemLink"] = 693,
                    },
                    [2] = 
                    {
                        ["price"] = 195,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1633028892,
                        ["quant"] = 1,
                        ["id"] = "1690436689",
                        ["itemLink"] = 696,
                    },
                    [3] = 
                    {
                        ["price"] = 228,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633084673,
                        ["quant"] = 1,
                        ["id"] = "1690857219",
                        ["itemLink"] = 696,
                    },
                    [4] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633084673,
                        ["quant"] = 1,
                        ["id"] = "1690857231",
                        ["itemLink"] = 1201,
                    },
                    [5] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633185905,
                        ["quant"] = 1,
                        ["id"] = "1691639689",
                        ["itemLink"] = 693,
                    },
                    [6] = 
                    {
                        ["price"] = 315,
                        ["guild"] = 1,
                        ["buyer"] = 2167,
                        ["wasKiosk"] = true,
                        ["seller"] = 533,
                        ["timestamp"] = 1632838990,
                        ["quant"] = 1,
                        ["id"] = "1689054187",
                        ["itemLink"] = 3119,
                    },
                    [7] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2424,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632892808,
                        ["quant"] = 1,
                        ["id"] = "1689514725",
                        ["itemLink"] = 693,
                    },
                    [8] = 
                    {
                        ["price"] = 253,
                        ["guild"] = 1,
                        ["buyer"] = 2591,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632951462,
                        ["quant"] = 1,
                        ["id"] = "1689886941",
                        ["itemLink"] = 693,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "cp150 white normal weapon axe one-handed intricate",
            },
        },
        [155123] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_pellitine_light_helmet_a.dds",
                ["itemDesc"] = "Hat of Marauder's Haste",
                ["oldestTime"] = 1633316129,
                ["wasAltered"] = true,
                ["newestTime"] = 1633316129,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 141,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633316129,
                        ["quant"] = 1,
                        ["id"] = "1692916467",
                        ["itemLink"] = 161,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set marauder's haste head impenetrable",
            },
        },
        [5364] = 
        {
            ["50:15:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_frostresist.dds",
                ["itemDesc"] = "Superb Glyph of Frost Resist",
                ["oldestTime"] = 1632846663,
                ["wasAltered"] = true,
                ["newestTime"] = 1632846663,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 2201,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632846663,
                        ["quant"] = 1,
                        ["id"] = "1689115653",
                        ["itemLink"] = 3202,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 purple epic miscellaneous jewelry glyph",
            },
        },
        [129781] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_heavy_waist_a.dds",
                ["itemDesc"] = "Girdle of the Pariah",
                ["oldestTime"] = 1633112804,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112804,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 998,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633112804,
                        ["quant"] = 1,
                        ["id"] = "1691057255",
                        ["itemLink"] = 1359,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set mark of the pariah waist impenetrable",
            },
        },
        [180726] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_2hhammer_a.dds",
                ["itemDesc"] = "Plaguebreak Maul",
                ["oldestTime"] = 1632869917,
                ["wasAltered"] = true,
                ["newestTime"] = 1632869917,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2285,
                        ["wasKiosk"] = true,
                        ["seller"] = 514,
                        ["timestamp"] = 1632869917,
                        ["quant"] = 1,
                        ["id"] = "1689302603",
                        ["itemLink"] = 3382,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set plaguebreak mace two-handed decisive",
            },
        },
        [132855] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_apostle_2hsword_a.dds",
                ["itemDesc"] = "Mad Tinkerer's Greatsword",
                ["oldestTime"] = 1632830329,
                ["wasAltered"] = true,
                ["newestTime"] = 1632830329,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 2134,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632830329,
                        ["quant"] = 1,
                        ["id"] = "1689000423",
                        ["itemLink"] = 3077,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set mad tinkerer sword two-handed infused",
            },
        },
        [64504] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_cloth_base_harvestersilk.dds",
                ["itemDesc"] = "Ancestor Silk",
                ["oldestTime"] = 1632828844,
                ["wasAltered"] = true,
                ["newestTime"] = 1633316195,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 214,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632975714,
                        ["quant"] = 200,
                        ["id"] = "1690100355",
                        ["itemLink"] = 224,
                    },
                    [2] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 214,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632975714,
                        ["quant"] = 200,
                        ["id"] = "1690100365",
                        ["itemLink"] = 224,
                    },
                    [3] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 214,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632975715,
                        ["quant"] = 200,
                        ["id"] = "1690100379",
                        ["itemLink"] = 224,
                    },
                    [4] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 214,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632975716,
                        ["quant"] = 200,
                        ["id"] = "1690100381",
                        ["itemLink"] = 224,
                    },
                    [5] = 
                    {
                        ["price"] = 7900,
                        ["guild"] = 1,
                        ["buyer"] = 214,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632975717,
                        ["quant"] = 200,
                        ["id"] = "1690100399",
                        ["itemLink"] = 224,
                    },
                    [6] = 
                    {
                        ["price"] = 7900,
                        ["guild"] = 1,
                        ["buyer"] = 214,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632975720,
                        ["quant"] = 200,
                        ["id"] = "1690100435",
                        ["itemLink"] = 224,
                    },
                    [7] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 224,
                        ["timestamp"] = 1632976253,
                        ["quant"] = 200,
                        ["id"] = "1690104097",
                        ["itemLink"] = 224,
                    },
                    [8] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1632976254,
                        ["quant"] = 200,
                        ["id"] = "1690104101",
                        ["itemLink"] = 224,
                    },
                    [9] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1632976254,
                        ["quant"] = 200,
                        ["id"] = "1690104109",
                        ["itemLink"] = 224,
                    },
                    [10] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1632976255,
                        ["quant"] = 200,
                        ["id"] = "1690104117",
                        ["itemLink"] = 224,
                    },
                    [11] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1632976255,
                        ["quant"] = 200,
                        ["id"] = "1690104119",
                        ["itemLink"] = 224,
                    },
                    [12] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1632976256,
                        ["quant"] = 200,
                        ["id"] = "1690104123",
                        ["itemLink"] = 224,
                    },
                    [13] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1632976257,
                        ["quant"] = 200,
                        ["id"] = "1690104127",
                        ["itemLink"] = 224,
                    },
                    [14] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632976257,
                        ["quant"] = 200,
                        ["id"] = "1690104129",
                        ["itemLink"] = 224,
                    },
                    [15] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632976258,
                        ["quant"] = 200,
                        ["id"] = "1690104133",
                        ["itemLink"] = 224,
                    },
                    [16] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632976258,
                        ["quant"] = 200,
                        ["id"] = "1690104135",
                        ["itemLink"] = 224,
                    },
                    [17] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632976259,
                        ["quant"] = 200,
                        ["id"] = "1690104145",
                        ["itemLink"] = 224,
                    },
                    [18] = 
                    {
                        ["price"] = 8235,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1632976259,
                        ["quant"] = 200,
                        ["id"] = "1690104153",
                        ["itemLink"] = 224,
                    },
                    [19] = 
                    {
                        ["price"] = 8235,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1632976260,
                        ["quant"] = 200,
                        ["id"] = "1690104155",
                        ["itemLink"] = 224,
                    },
                    [20] = 
                    {
                        ["price"] = 8235,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1632976260,
                        ["quant"] = 200,
                        ["id"] = "1690104157",
                        ["itemLink"] = 224,
                    },
                    [21] = 
                    {
                        ["price"] = 8235,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1632976261,
                        ["quant"] = 200,
                        ["id"] = "1690104169",
                        ["itemLink"] = 224,
                    },
                    [22] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1632976265,
                        ["quant"] = 200,
                        ["id"] = "1690104251",
                        ["itemLink"] = 224,
                    },
                    [23] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1632976265,
                        ["quant"] = 200,
                        ["id"] = "1690104263",
                        ["itemLink"] = 224,
                    },
                    [24] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1632976266,
                        ["quant"] = 200,
                        ["id"] = "1690104275",
                        ["itemLink"] = 224,
                    },
                    [25] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1632976266,
                        ["quant"] = 200,
                        ["id"] = "1690104289",
                        ["itemLink"] = 224,
                    },
                    [26] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1632976267,
                        ["quant"] = 200,
                        ["id"] = "1690104301",
                        ["itemLink"] = 224,
                    },
                    [27] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1632976268,
                        ["quant"] = 200,
                        ["id"] = "1690104309",
                        ["itemLink"] = 224,
                    },
                    [28] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1632976268,
                        ["quant"] = 200,
                        ["id"] = "1690104321",
                        ["itemLink"] = 224,
                    },
                    [29] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1632976269,
                        ["quant"] = 200,
                        ["id"] = "1690104329",
                        ["itemLink"] = 224,
                    },
                    [30] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1632976269,
                        ["quant"] = 200,
                        ["id"] = "1690104335",
                        ["itemLink"] = 224,
                    },
                    [31] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1632976270,
                        ["quant"] = 200,
                        ["id"] = "1690104351",
                        ["itemLink"] = 224,
                    },
                    [32] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1632976270,
                        ["quant"] = 200,
                        ["id"] = "1690104357",
                        ["itemLink"] = 224,
                    },
                    [33] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1632976271,
                        ["quant"] = 200,
                        ["id"] = "1690104369",
                        ["itemLink"] = 224,
                    },
                    [34] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1632976272,
                        ["quant"] = 200,
                        ["id"] = "1690104381",
                        ["itemLink"] = 224,
                    },
                    [35] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 223,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1632976272,
                        ["quant"] = 200,
                        ["id"] = "1690104389",
                        ["itemLink"] = 224,
                    },
                    [36] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 367,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1632993172,
                        ["quant"] = 200,
                        ["id"] = "1690201965",
                        ["itemLink"] = 224,
                    },
                    [37] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 350,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1632993543,
                        ["quant"] = 200,
                        ["id"] = "1690203359",
                        ["itemLink"] = 224,
                    },
                    [38] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 350,
                        ["wasKiosk"] = true,
                        ["seller"] = 344,
                        ["timestamp"] = 1632993553,
                        ["quant"] = 200,
                        ["id"] = "1690203407",
                        ["itemLink"] = 224,
                    },
                    [39] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 350,
                        ["wasKiosk"] = true,
                        ["seller"] = 344,
                        ["timestamp"] = 1632993556,
                        ["quant"] = 200,
                        ["id"] = "1690203429",
                        ["itemLink"] = 224,
                    },
                    [40] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 350,
                        ["wasKiosk"] = true,
                        ["seller"] = 344,
                        ["timestamp"] = 1632993558,
                        ["quant"] = 200,
                        ["id"] = "1690203445",
                        ["itemLink"] = 224,
                    },
                    [41] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 350,
                        ["wasKiosk"] = true,
                        ["seller"] = 344,
                        ["timestamp"] = 1632993559,
                        ["quant"] = 200,
                        ["id"] = "1690203455",
                        ["itemLink"] = 224,
                    },
                    [42] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 350,
                        ["wasKiosk"] = true,
                        ["seller"] = 344,
                        ["timestamp"] = 1632993561,
                        ["quant"] = 200,
                        ["id"] = "1690203465",
                        ["itemLink"] = 224,
                    },
                    [43] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 350,
                        ["wasKiosk"] = true,
                        ["seller"] = 344,
                        ["timestamp"] = 1632993562,
                        ["quant"] = 200,
                        ["id"] = "1690203477",
                        ["itemLink"] = 224,
                    },
                    [44] = 
                    {
                        ["price"] = 9033,
                        ["guild"] = 1,
                        ["buyer"] = 429,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633007307,
                        ["quant"] = 200,
                        ["id"] = "1690273187",
                        ["itemLink"] = 224,
                    },
                    [45] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 522,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633022607,
                        ["quant"] = 200,
                        ["id"] = "1690387305",
                        ["itemLink"] = 224,
                    },
                    [46] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 683,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633047208,
                        ["quant"] = 200,
                        ["id"] = "1690577525",
                        ["itemLink"] = 224,
                    },
                    [47] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 849,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633071811,
                        ["quant"] = 200,
                        ["id"] = "1690789351",
                        ["itemLink"] = 224,
                    },
                    [48] = 
                    {
                        ["price"] = 7533,
                        ["guild"] = 1,
                        ["buyer"] = 849,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633071812,
                        ["quant"] = 200,
                        ["id"] = "1690789359",
                        ["itemLink"] = 224,
                    },
                    [49] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 849,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633071813,
                        ["quant"] = 200,
                        ["id"] = "1690789367",
                        ["itemLink"] = 224,
                    },
                    [50] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 849,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633071814,
                        ["quant"] = 200,
                        ["id"] = "1690789371",
                        ["itemLink"] = 224,
                    },
                    [51] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 849,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633071814,
                        ["quant"] = 200,
                        ["id"] = "1690789383",
                        ["itemLink"] = 224,
                    },
                    [52] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 849,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633071815,
                        ["quant"] = 200,
                        ["id"] = "1690789393",
                        ["itemLink"] = 224,
                    },
                    [53] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 849,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633071817,
                        ["quant"] = 200,
                        ["id"] = "1690789407",
                        ["itemLink"] = 224,
                    },
                    [54] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 882,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633080707,
                        ["quant"] = 200,
                        ["id"] = "1690838363",
                        ["itemLink"] = 224,
                    },
                    [55] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 882,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1633080710,
                        ["quant"] = 200,
                        ["id"] = "1690838373",
                        ["itemLink"] = 224,
                    },
                    [56] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 882,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1633080715,
                        ["quant"] = 200,
                        ["id"] = "1690838389",
                        ["itemLink"] = 224,
                    },
                    [57] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 918,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633090315,
                        ["quant"] = 200,
                        ["id"] = "1690890303",
                        ["itemLink"] = 224,
                    },
                    [58] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633129788,
                        ["quant"] = 200,
                        ["id"] = "1691183487",
                        ["itemLink"] = 224,
                    },
                    [59] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633129789,
                        ["quant"] = 200,
                        ["id"] = "1691183497",
                        ["itemLink"] = 224,
                    },
                    [60] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633129793,
                        ["quant"] = 200,
                        ["id"] = "1691183533",
                        ["itemLink"] = 224,
                    },
                    [61] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633129794,
                        ["quant"] = 200,
                        ["id"] = "1691183539",
                        ["itemLink"] = 224,
                    },
                    [62] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 1192,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633141786,
                        ["quant"] = 200,
                        ["id"] = "1691310739",
                        ["itemLink"] = 224,
                    },
                    [63] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 1192,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633141787,
                        ["quant"] = 200,
                        ["id"] = "1691310757",
                        ["itemLink"] = 224,
                    },
                    [64] = 
                    {
                        ["price"] = 7900,
                        ["guild"] = 1,
                        ["buyer"] = 1192,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633141788,
                        ["quant"] = 200,
                        ["id"] = "1691310767",
                        ["itemLink"] = 224,
                    },
                    [65] = 
                    {
                        ["price"] = 7900,
                        ["guild"] = 1,
                        ["buyer"] = 1192,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633141788,
                        ["quant"] = 200,
                        ["id"] = "1691310777",
                        ["itemLink"] = 224,
                    },
                    [66] = 
                    {
                        ["price"] = 7900,
                        ["guild"] = 1,
                        ["buyer"] = 1192,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633141789,
                        ["quant"] = 200,
                        ["id"] = "1691310795",
                        ["itemLink"] = 224,
                    },
                    [67] = 
                    {
                        ["price"] = 7900,
                        ["guild"] = 1,
                        ["buyer"] = 1192,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633141790,
                        ["quant"] = 200,
                        ["id"] = "1691310803",
                        ["itemLink"] = 224,
                    },
                    [68] = 
                    {
                        ["price"] = 7900,
                        ["guild"] = 1,
                        ["buyer"] = 1192,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633141791,
                        ["quant"] = 200,
                        ["id"] = "1691310809",
                        ["itemLink"] = 224,
                    },
                    [69] = 
                    {
                        ["price"] = 7900,
                        ["guild"] = 1,
                        ["buyer"] = 1192,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633141791,
                        ["quant"] = 200,
                        ["id"] = "1691310823",
                        ["itemLink"] = 224,
                    },
                    [70] = 
                    {
                        ["price"] = 7900,
                        ["guild"] = 1,
                        ["buyer"] = 1192,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633141798,
                        ["quant"] = 200,
                        ["id"] = "1691310963",
                        ["itemLink"] = 224,
                    },
                    [71] = 
                    {
                        ["price"] = 7981,
                        ["guild"] = 1,
                        ["buyer"] = 1211,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1633143231,
                        ["quant"] = 200,
                        ["id"] = "1691327933",
                        ["itemLink"] = 224,
                    },
                    [72] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 1305,
                        ["wasKiosk"] = true,
                        ["seller"] = 344,
                        ["timestamp"] = 1633160572,
                        ["quant"] = 200,
                        ["id"] = "1691467337",
                        ["itemLink"] = 224,
                    },
                    [73] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 1305,
                        ["wasKiosk"] = true,
                        ["seller"] = 344,
                        ["timestamp"] = 1633160573,
                        ["quant"] = 200,
                        ["id"] = "1691467347",
                        ["itemLink"] = 224,
                    },
                    [74] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 1305,
                        ["wasKiosk"] = true,
                        ["seller"] = 344,
                        ["timestamp"] = 1633160574,
                        ["quant"] = 200,
                        ["id"] = "1691467351",
                        ["itemLink"] = 224,
                    },
                    [75] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 1305,
                        ["wasKiosk"] = true,
                        ["seller"] = 344,
                        ["timestamp"] = 1633160576,
                        ["quant"] = 200,
                        ["id"] = "1691467359",
                        ["itemLink"] = 224,
                    },
                    [76] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 1305,
                        ["wasKiosk"] = true,
                        ["seller"] = 344,
                        ["timestamp"] = 1633160577,
                        ["quant"] = 200,
                        ["id"] = "1691467369",
                        ["itemLink"] = 224,
                    },
                    [77] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 1373,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633181306,
                        ["quant"] = 200,
                        ["id"] = "1691596543",
                        ["itemLink"] = 224,
                    },
                    [78] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 1373,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633181307,
                        ["quant"] = 200,
                        ["id"] = "1691596553",
                        ["itemLink"] = 224,
                    },
                    [79] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 1373,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633181309,
                        ["quant"] = 200,
                        ["id"] = "1691596569",
                        ["itemLink"] = 224,
                    },
                    [80] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 1373,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633181311,
                        ["quant"] = 200,
                        ["id"] = "1691596579",
                        ["itemLink"] = 224,
                    },
                    [81] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 1373,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633181313,
                        ["quant"] = 200,
                        ["id"] = "1691596591",
                        ["itemLink"] = 224,
                    },
                    [82] = 
                    {
                        ["price"] = 7912,
                        ["guild"] = 1,
                        ["buyer"] = 1406,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1633188348,
                        ["quant"] = 200,
                        ["id"] = "1691670189",
                        ["itemLink"] = 224,
                    },
                    [83] = 
                    {
                        ["price"] = 7981,
                        ["guild"] = 1,
                        ["buyer"] = 1406,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1633188349,
                        ["quant"] = 200,
                        ["id"] = "1691670205",
                        ["itemLink"] = 224,
                    },
                    [84] = 
                    {
                        ["price"] = 7981,
                        ["guild"] = 1,
                        ["buyer"] = 1662,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1633227477,
                        ["quant"] = 200,
                        ["id"] = "1692089923",
                        ["itemLink"] = 224,
                    },
                    [85] = 
                    {
                        ["price"] = 7981,
                        ["guild"] = 1,
                        ["buyer"] = 1662,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1633227478,
                        ["quant"] = 200,
                        ["id"] = "1692089937",
                        ["itemLink"] = 224,
                    },
                    [86] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633288054,
                        ["quant"] = 200,
                        ["id"] = "1692605473",
                        ["itemLink"] = 224,
                    },
                    [87] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633288055,
                        ["quant"] = 200,
                        ["id"] = "1692605499",
                        ["itemLink"] = 224,
                    },
                    [88] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633288056,
                        ["quant"] = 200,
                        ["id"] = "1692605513",
                        ["itemLink"] = 224,
                    },
                    [89] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633288057,
                        ["quant"] = 200,
                        ["id"] = "1692605543",
                        ["itemLink"] = 224,
                    },
                    [90] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633288057,
                        ["quant"] = 200,
                        ["id"] = "1692605547",
                        ["itemLink"] = 224,
                    },
                    [91] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633288058,
                        ["quant"] = 200,
                        ["id"] = "1692605551",
                        ["itemLink"] = 224,
                    },
                    [92] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633288059,
                        ["quant"] = 200,
                        ["id"] = "1692605571",
                        ["itemLink"] = 224,
                    },
                    [93] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633288060,
                        ["quant"] = 200,
                        ["id"] = "1692605583",
                        ["itemLink"] = 224,
                    },
                    [94] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633288064,
                        ["quant"] = 200,
                        ["id"] = "1692605625",
                        ["itemLink"] = 224,
                    },
                    [95] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633288064,
                        ["quant"] = 200,
                        ["id"] = "1692605631",
                        ["itemLink"] = 224,
                    },
                    [96] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633288065,
                        ["quant"] = 200,
                        ["id"] = "1692605637",
                        ["itemLink"] = 224,
                    },
                    [97] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633288066,
                        ["quant"] = 200,
                        ["id"] = "1692605651",
                        ["itemLink"] = 224,
                    },
                    [98] = 
                    {
                        ["price"] = 7943,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1633288067,
                        ["quant"] = 200,
                        ["id"] = "1692605661",
                        ["itemLink"] = 224,
                    },
                    [99] = 
                    {
                        ["price"] = 7943,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1633288067,
                        ["quant"] = 200,
                        ["id"] = "1692605669",
                        ["itemLink"] = 224,
                    },
                    [100] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633316195,
                        ["quant"] = 200,
                        ["id"] = "1692917283",
                        ["itemLink"] = 224,
                    },
                    [101] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 2127,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1632828844,
                        ["quant"] = 200,
                        ["id"] = "1688991753",
                        ["itemLink"] = 224,
                    },
                    [102] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 626,
                        ["wasKiosk"] = false,
                        ["seller"] = 266,
                        ["timestamp"] = 1632935549,
                        ["quant"] = 200,
                        ["id"] = "1689766073",
                        ["itemLink"] = 224,
                    },
                    [103] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 626,
                        ["wasKiosk"] = false,
                        ["seller"] = 266,
                        ["timestamp"] = 1632935550,
                        ["quant"] = 200,
                        ["id"] = "1689766077",
                        ["itemLink"] = 224,
                    },
                    [104] = 
                    {
                        ["price"] = 7700,
                        ["guild"] = 1,
                        ["buyer"] = 2538,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632938989,
                        ["quant"] = 200,
                        ["id"] = "1689787507",
                        ["itemLink"] = 224,
                    },
                    [105] = 
                    {
                        ["price"] = 7700,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632942563,
                        ["quant"] = 200,
                        ["id"] = "1689814357",
                        ["itemLink"] = 224,
                    },
                },
                ["totalCount"] = 105,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [71673] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 28: Ra Gada Axes",
                ["oldestTime"] = 1633184421,
                ["wasAltered"] = true,
                ["newestTime"] = 1633219932,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 388,
                        ["timestamp"] = 1633184421,
                        ["quant"] = 1,
                        ["id"] = "1691624191",
                        ["itemLink"] = 1975,
                    },
                    [2] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1607,
                        ["wasKiosk"] = true,
                        ["seller"] = 711,
                        ["timestamp"] = 1633219932,
                        ["quant"] = 1,
                        ["id"] = "1692011461",
                        ["itemLink"] = 1975,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [151903] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_run_sarcophaguslid001.dds",
                ["itemDesc"] = "Elsweyr Sarcophagus Lid, Ancient",
                ["oldestTime"] = 1633052248,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052248,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10698,
                        ["guild"] = 1,
                        ["buyer"] = 715,
                        ["wasKiosk"] = true,
                        ["seller"] = 312,
                        ["timestamp"] = 1633052248,
                        ["quant"] = 1,
                        ["id"] = "1690628789",
                        ["itemLink"] = 903,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings undercroft",
            },
        },
        [43735] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Gold Coast Treasure Map I",
                ["oldestTime"] = 1633182525,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182525,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 379,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182525,
                        ["quant"] = 1,
                        ["id"] = "1691608257",
                        ["itemLink"] = 1958,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [43621] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Bangkorai Treasure Map III",
                ["oldestTime"] = 1633182504,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182504,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 259,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182504,
                        ["quant"] = 1,
                        ["id"] = "1691608037",
                        ["itemLink"] = 1944,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [45945] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Stuffed Grape Leaves",
                ["oldestTime"] = 1632839850,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242688,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1345,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633172335,
                        ["quant"] = 1,
                        ["id"] = "1691532039",
                        ["itemLink"] = 1887,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 348,
                        ["wasKiosk"] = false,
                        ["seller"] = 723,
                        ["timestamp"] = 1633242688,
                        ["quant"] = 1,
                        ["id"] = "1692215211",
                        ["itemLink"] = 1887,
                    },
                    [3] = 
                    {
                        ["price"] = 20,
                        ["guild"] = 1,
                        ["buyer"] = 2173,
                        ["wasKiosk"] = true,
                        ["seller"] = 170,
                        ["timestamp"] = 1632839850,
                        ["quant"] = 1,
                        ["id"] = "1689059307",
                        ["itemLink"] = 1887,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [56051] = 
        {
            ["1:0:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_light_shoulders_a.dds",
                ["itemDesc"] = "Homespun Epaulets",
                ["oldestTime"] = 1632868043,
                ["wasAltered"] = true,
                ["newestTime"] = 1633224112,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 423,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633006660,
                        ["quant"] = 1,
                        ["id"] = "1690268917",
                        ["itemLink"] = 432,
                    },
                    [2] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1153,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633136371,
                        ["quant"] = 1,
                        ["id"] = "1691256815",
                        ["itemLink"] = 432,
                    },
                    [3] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1360,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633178528,
                        ["quant"] = 1,
                        ["id"] = "1691574033",
                        ["itemLink"] = 432,
                    },
                    [4] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 1634,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633224112,
                        ["quant"] = 1,
                        ["id"] = "1692054869",
                        ["itemLink"] = 432,
                    },
                    [5] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1093,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1632868043,
                        ["quant"] = 1,
                        ["id"] = "1689288023",
                        ["itemLink"] = 432,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 white normal light apparel shoulders nirnhoned",
            },
            ["50:15:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_light_shoulders_d.dds",
                ["itemDesc"] = "Ancestor Silk Epaulets",
                ["oldestTime"] = 1632827380,
                ["wasAltered"] = true,
                ["newestTime"] = 1632827380,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4999,
                        ["guild"] = 1,
                        ["buyer"] = 2125,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632827380,
                        ["quant"] = 1,
                        ["id"] = "1688978025",
                        ["itemLink"] = 3061,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 white normal light apparel shoulders nirnhoned",
            },
        },
        [57599] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 18: Akaviri Legs",
                ["oldestTime"] = 1632836167,
                ["wasAltered"] = true,
                ["newestTime"] = 1632836167,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 27500,
                        ["guild"] = 1,
                        ["buyer"] = 2158,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632836167,
                        ["quant"] = 1,
                        ["id"] = "1689035121",
                        ["itemLink"] = 3105,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
    },
}
