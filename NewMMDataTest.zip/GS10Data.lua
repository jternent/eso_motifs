GS10DataSavedVariables =
{
    ["listingseu"] = 
    {
    },
    ["listingsna"] = 
    {
    },
    ["dataeu"] = 
    {
    },
    ["datana"] = 
    {
        [180736] = 
        {
            ["50:16:4:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_medium_feet_a.dds",
                ["itemDesc"] = "Plaguebreak Boots",
                ["oldestTime"] = 1633312841,
                ["wasAltered"] = true,
                ["newestTime"] = 1633312841,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 39,
                        ["wasKiosk"] = true,
                        ["seller"] = 43,
                        ["timestamp"] = 1633312841,
                        ["quant"] = 1,
                        ["id"] = "1692878885",
                        ["itemLink"] = 31,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set plaguebreak feet sturdy",
            },
        },
        [139266] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_duc_fountainwall001.dds",
                ["itemDesc"] = "Alinor Fountain, Timeworn",
                ["oldestTime"] = 1632865642,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865642,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 2267,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1632865642,
                        ["quant"] = 2,
                        ["id"] = "1689269721",
                        ["itemLink"] = 3359,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings courtyard",
            },
        },
        [45571] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Fulmination Ale",
                ["oldestTime"] = 1633164804,
                ["wasAltered"] = true,
                ["newestTime"] = 1633164804,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633164804,
                        ["quant"] = 1,
                        ["id"] = "1691495061",
                        ["itemLink"] = 1833,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [120837] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_col_str_dbstainedglasswinsanctuary001.dds",
                ["itemDesc"] = "Brotherhood Stained Glass Window",
                ["oldestTime"] = 1633234729,
                ["wasAltered"] = true,
                ["newestTime"] = 1633234729,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 109000,
                        ["guild"] = 1,
                        ["buyer"] = 1724,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633234729,
                        ["quant"] = 1,
                        ["id"] = "1692159127",
                        ["itemLink"] = 2471,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings undercroft",
            },
        },
        [171782] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Markarth Floor, Square",
                ["oldestTime"] = 1632882212,
                ["wasAltered"] = true,
                ["newestTime"] = 1632882212,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2365,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632882212,
                        ["quant"] = 1,
                        ["id"] = "1689420763",
                        ["itemLink"] = 3475,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45576] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Centurion's Friend Kaveh",
                ["oldestTime"] = 1633122932,
                ["wasAltered"] = true,
                ["newestTime"] = 1633122932,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 799,
                        ["guild"] = 1,
                        ["buyer"] = 1066,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633122932,
                        ["quant"] = 1,
                        ["id"] = "1691126849",
                        ["itemLink"] = 1452,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45577] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Berveza Vitae",
                ["oldestTime"] = 1632880402,
                ["wasAltered"] = true,
                ["newestTime"] = 1632880402,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3799,
                        ["guild"] = 1,
                        ["buyer"] = 1217,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1632880402,
                        ["quant"] = 1,
                        ["id"] = "1689401205",
                        ["itemLink"] = 3459,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [43530] = 
        {
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_1hhammer_d.dds",
                ["itemDesc"] = "Rubedite Mace",
                ["oldestTime"] = 1633309690,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309690,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 105,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633309690,
                        ["quant"] = 1,
                        ["id"] = "1692845781",
                        ["itemLink"] = 2973,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal weapon mace one-handed",
            },
        },
        [122891] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_telvanni_light_robe_a.dds",
                ["itemDesc"] = "War Maiden's Robe",
                ["oldestTime"] = 1632879053,
                ["wasAltered"] = true,
                ["newestTime"] = 1632879053,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 2344,
                        ["wasKiosk"] = true,
                        ["seller"] = 327,
                        ["timestamp"] = 1632879053,
                        ["quant"] = 1,
                        ["id"] = "1689384869",
                        ["itemLink"] = 3440,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set war maiden chest impenetrable",
            },
        },
        [114958] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 45: Mazzatun Gloves",
                ["oldestTime"] = 1633052082,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052082,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 710,
                        ["wasKiosk"] = false,
                        ["seller"] = 505,
                        ["timestamp"] = 1633052082,
                        ["quant"] = 1,
                        ["id"] = "1690626803",
                        ["itemLink"] = 894,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [77584] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_poisonmaking_reagent_spider_egg.dds",
                ["itemDesc"] = "Spider Egg",
                ["oldestTime"] = 1632981473,
                ["wasAltered"] = true,
                ["newestTime"] = 1633159817,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1632981473,
                        ["quant"] = 80,
                        ["id"] = "1690139105",
                        ["itemLink"] = 286,
                    },
                    [2] = 
                    {
                        ["price"] = 285,
                        ["guild"] = 1,
                        ["buyer"] = 905,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633087141,
                        ["quant"] = 3,
                        ["id"] = "1690870219",
                        ["itemLink"] = 286,
                    },
                    [3] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 1301,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1633159817,
                        ["quant"] = 200,
                        ["id"] = "1691463963",
                        ["itemLink"] = 286,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [57618] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 20: Yokudan Staves",
                ["oldestTime"] = 1632970662,
                ["wasAltered"] = true,
                ["newestTime"] = 1633064302,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 149,
                        ["wasKiosk"] = false,
                        ["seller"] = 171,
                        ["timestamp"] = 1632970662,
                        ["quant"] = 1,
                        ["id"] = "1690062941",
                        ["itemLink"] = 182,
                    },
                    [2] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 810,
                        ["wasKiosk"] = true,
                        ["seller"] = 729,
                        ["timestamp"] = 1633064302,
                        ["quant"] = 1,
                        ["id"] = "1690742825",
                        ["itemLink"] = 182,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [167956] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 95: Nighthollow Staves",
                ["oldestTime"] = 1633058069,
                ["wasAltered"] = true,
                ["newestTime"] = 1633280776,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 770,
                        ["wasKiosk"] = true,
                        ["seller"] = 505,
                        ["timestamp"] = 1633058069,
                        ["quant"] = 1,
                        ["id"] = "1690690965",
                        ["itemLink"] = 981,
                    },
                    [2] = 
                    {
                        ["price"] = 39600,
                        ["guild"] = 1,
                        ["buyer"] = 511,
                        ["wasKiosk"] = true,
                        ["seller"] = 611,
                        ["timestamp"] = 1633280776,
                        ["quant"] = 1,
                        ["id"] = "1692522863",
                        ["itemLink"] = 981,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [533] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_wood_base_oak_r3.dds",
                ["itemDesc"] = "Sanded Oak",
                ["oldestTime"] = 1632987678,
                ["wasAltered"] = true,
                ["newestTime"] = 1633134362,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 46,
                        ["timestamp"] = 1632987678,
                        ["quant"] = 100,
                        ["id"] = "1690172693",
                        ["itemLink"] = 333,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 329,
                        ["timestamp"] = 1632987679,
                        ["quant"] = 200,
                        ["id"] = "1690172697",
                        ["itemLink"] = 333,
                    },
                    [3] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 330,
                        ["timestamp"] = 1632987680,
                        ["quant"] = 200,
                        ["id"] = "1690172699",
                        ["itemLink"] = 333,
                    },
                    [4] = 
                    {
                        ["price"] = 60,
                        ["guild"] = 1,
                        ["buyer"] = 1132,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633134362,
                        ["quant"] = 10,
                        ["id"] = "1691234203",
                        ["itemLink"] = 333,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [45334] = 
        {
            ["50:15:1:10:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ashlanderv_1hhammer_a.dds",
                ["itemDesc"] = "Rubedite Mace",
                ["oldestTime"] = 1633185909,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185909,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 525,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 527,
                        ["timestamp"] = 1633185909,
                        ["quant"] = 1,
                        ["id"] = "1691639733",
                        ["itemLink"] = 2009,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 white normal weapon mace one-handed ornate",
            },
            ["50:16:1:10:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_1hhammer_c.dds",
                ["itemDesc"] = "Rubedite Mace",
                ["oldestTime"] = 1633185912,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185912,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 540,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 527,
                        ["timestamp"] = 1633185912,
                        ["quant"] = 1,
                        ["id"] = "1691639757",
                        ["itemLink"] = 2012,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal weapon mace one-handed ornate",
            },
        },
        [43543] = 
        {
            ["50:16:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_light_robe_d.dds",
                ["itemDesc"] = "Ancestor Silk Robe of Stamina",
                ["oldestTime"] = 1633185957,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185957,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 174,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633185957,
                        ["quant"] = 1,
                        ["id"] = "1691640321",
                        ["itemLink"] = 2032,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel chest",
            },
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_light_robe_d.dds",
                ["itemDesc"] = "Ancestor Silk Robe",
                ["oldestTime"] = 1632847690,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022963,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633022963,
                        ["quant"] = 1,
                        ["id"] = "1690390305",
                        ["itemLink"] = 602,
                    },
                    [2] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632847690,
                        ["quant"] = 1,
                        ["id"] = "1689125543",
                        ["itemLink"] = 3213,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 white normal light apparel chest",
            },
        },
        [129819] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_snowreach_medium_legs_a.dds",
                ["itemDesc"] = "Briarheart Guards",
                ["oldestTime"] = 1633003933,
                ["wasAltered"] = true,
                ["newestTime"] = 1633003933,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 415,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633003933,
                        ["quant"] = 1,
                        ["id"] = "1690253633",
                        ["itemLink"] = 422,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set briarheart legs impenetrable",
            },
        },
        [71198] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_jewelry_base_ruby_r1.dds",
                ["itemDesc"] = "Rubedite Ore",
                ["oldestTime"] = 1632845835,
                ["wasAltered"] = true,
                ["newestTime"] = 1633289798,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1633001190,
                        ["quant"] = 200,
                        ["id"] = "1690240251",
                        ["itemLink"] = 408,
                    },
                    [2] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1633001190,
                        ["quant"] = 200,
                        ["id"] = "1690240253",
                        ["itemLink"] = 408,
                    },
                    [3] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1633001191,
                        ["quant"] = 200,
                        ["id"] = "1690240255",
                        ["itemLink"] = 408,
                    },
                    [4] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1633001191,
                        ["quant"] = 200,
                        ["id"] = "1690240257",
                        ["itemLink"] = 408,
                    },
                    [5] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 267,
                        ["timestamp"] = 1633001192,
                        ["quant"] = 200,
                        ["id"] = "1690240261",
                        ["itemLink"] = 408,
                    },
                    [6] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 267,
                        ["timestamp"] = 1633001193,
                        ["quant"] = 200,
                        ["id"] = "1690240267",
                        ["itemLink"] = 408,
                    },
                    [7] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 267,
                        ["timestamp"] = 1633001193,
                        ["quant"] = 200,
                        ["id"] = "1690240269",
                        ["itemLink"] = 408,
                    },
                    [8] = 
                    {
                        ["price"] = 11990,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1633001194,
                        ["quant"] = 200,
                        ["id"] = "1690240271",
                        ["itemLink"] = 408,
                    },
                    [9] = 
                    {
                        ["price"] = 11990,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1633001194,
                        ["quant"] = 200,
                        ["id"] = "1690240273",
                        ["itemLink"] = 408,
                    },
                    [10] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 267,
                        ["timestamp"] = 1633001196,
                        ["quant"] = 200,
                        ["id"] = "1690240277",
                        ["itemLink"] = 408,
                    },
                    [11] = 
                    {
                        ["price"] = 10857,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633001197,
                        ["quant"] = 200,
                        ["id"] = "1690240281",
                        ["itemLink"] = 408,
                    },
                    [12] = 
                    {
                        ["price"] = 10857,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633001198,
                        ["quant"] = 200,
                        ["id"] = "1690240283",
                        ["itemLink"] = 408,
                    },
                    [13] = 
                    {
                        ["price"] = 10784,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633001198,
                        ["quant"] = 200,
                        ["id"] = "1690240285",
                        ["itemLink"] = 408,
                    },
                    [14] = 
                    {
                        ["price"] = 10784,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633001199,
                        ["quant"] = 200,
                        ["id"] = "1690240289",
                        ["itemLink"] = 408,
                    },
                    [15] = 
                    {
                        ["price"] = 10784,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633001201,
                        ["quant"] = 200,
                        ["id"] = "1690240297",
                        ["itemLink"] = 408,
                    },
                    [16] = 
                    {
                        ["price"] = 11606,
                        ["guild"] = 1,
                        ["buyer"] = 537,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633024354,
                        ["quant"] = 200,
                        ["id"] = "1690401267",
                        ["itemLink"] = 408,
                    },
                    [17] = 
                    {
                        ["price"] = 11606,
                        ["guild"] = 1,
                        ["buyer"] = 537,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633024356,
                        ["quant"] = 200,
                        ["id"] = "1690401271",
                        ["itemLink"] = 408,
                    },
                    [18] = 
                    {
                        ["price"] = 11606,
                        ["guild"] = 1,
                        ["buyer"] = 537,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633024356,
                        ["quant"] = 200,
                        ["id"] = "1690401275",
                        ["itemLink"] = 408,
                    },
                    [19] = 
                    {
                        ["price"] = 11606,
                        ["guild"] = 1,
                        ["buyer"] = 537,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633024357,
                        ["quant"] = 200,
                        ["id"] = "1690401279",
                        ["itemLink"] = 408,
                    },
                    [20] = 
                    {
                        ["price"] = 5752,
                        ["guild"] = 1,
                        ["buyer"] = 537,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633024357,
                        ["quant"] = 100,
                        ["id"] = "1690401285",
                        ["itemLink"] = 408,
                    },
                    [21] = 
                    {
                        ["price"] = 10841,
                        ["guild"] = 1,
                        ["buyer"] = 537,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633024358,
                        ["quant"] = 200,
                        ["id"] = "1690401289",
                        ["itemLink"] = 408,
                    },
                    [22] = 
                    {
                        ["price"] = 10841,
                        ["guild"] = 1,
                        ["buyer"] = 537,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633024358,
                        ["quant"] = 200,
                        ["id"] = "1690401295",
                        ["itemLink"] = 408,
                    },
                    [23] = 
                    {
                        ["price"] = 10841,
                        ["guild"] = 1,
                        ["buyer"] = 537,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633024359,
                        ["quant"] = 200,
                        ["id"] = "1690401301",
                        ["itemLink"] = 408,
                    },
                    [24] = 
                    {
                        ["price"] = 12500,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 244,
                        ["timestamp"] = 1633035211,
                        ["quant"] = 200,
                        ["id"] = "1690477545",
                        ["itemLink"] = 408,
                    },
                    [25] = 
                    {
                        ["price"] = 12500,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 244,
                        ["timestamp"] = 1633035211,
                        ["quant"] = 200,
                        ["id"] = "1690477553",
                        ["itemLink"] = 408,
                    },
                    [26] = 
                    {
                        ["price"] = 12500,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 244,
                        ["timestamp"] = 1633035212,
                        ["quant"] = 200,
                        ["id"] = "1690477557",
                        ["itemLink"] = 408,
                    },
                    [27] = 
                    {
                        ["price"] = 12500,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 244,
                        ["timestamp"] = 1633035213,
                        ["quant"] = 200,
                        ["id"] = "1690477563",
                        ["itemLink"] = 408,
                    },
                    [28] = 
                    {
                        ["price"] = 12518,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633035214,
                        ["quant"] = 200,
                        ["id"] = "1690477573",
                        ["itemLink"] = 408,
                    },
                    [29] = 
                    {
                        ["price"] = 12518,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633035215,
                        ["quant"] = 200,
                        ["id"] = "1690477583",
                        ["itemLink"] = 408,
                    },
                    [30] = 
                    {
                        ["price"] = 12518,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633035215,
                        ["quant"] = 200,
                        ["id"] = "1690477587",
                        ["itemLink"] = 408,
                    },
                    [31] = 
                    {
                        ["price"] = 12518,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633035215,
                        ["quant"] = 200,
                        ["id"] = "1690477589",
                        ["itemLink"] = 408,
                    },
                    [32] = 
                    {
                        ["price"] = 12518,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633035216,
                        ["quant"] = 200,
                        ["id"] = "1690477599",
                        ["itemLink"] = 408,
                    },
                    [33] = 
                    {
                        ["price"] = 12600,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633035217,
                        ["quant"] = 200,
                        ["id"] = "1690477615",
                        ["itemLink"] = 408,
                    },
                    [34] = 
                    {
                        ["price"] = 12600,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633035218,
                        ["quant"] = 200,
                        ["id"] = "1690477619",
                        ["itemLink"] = 408,
                    },
                    [35] = 
                    {
                        ["price"] = 12600,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633035218,
                        ["quant"] = 200,
                        ["id"] = "1690477625",
                        ["itemLink"] = 408,
                    },
                    [36] = 
                    {
                        ["price"] = 11504,
                        ["guild"] = 1,
                        ["buyer"] = 688,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633047737,
                        ["quant"] = 200,
                        ["id"] = "1690583447",
                        ["itemLink"] = 408,
                    },
                    [37] = 
                    {
                        ["price"] = 12518,
                        ["guild"] = 1,
                        ["buyer"] = 688,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633047738,
                        ["quant"] = 200,
                        ["id"] = "1690583457",
                        ["itemLink"] = 408,
                    },
                    [38] = 
                    {
                        ["price"] = 12518,
                        ["guild"] = 1,
                        ["buyer"] = 688,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633047738,
                        ["quant"] = 200,
                        ["id"] = "1690583467",
                        ["itemLink"] = 408,
                    },
                    [39] = 
                    {
                        ["price"] = 12518,
                        ["guild"] = 1,
                        ["buyer"] = 688,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633047739,
                        ["quant"] = 200,
                        ["id"] = "1690583471",
                        ["itemLink"] = 408,
                    },
                    [40] = 
                    {
                        ["price"] = 12518,
                        ["guild"] = 1,
                        ["buyer"] = 688,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633047739,
                        ["quant"] = 200,
                        ["id"] = "1690583485",
                        ["itemLink"] = 408,
                    },
                    [41] = 
                    {
                        ["price"] = 10681,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 21,
                        ["timestamp"] = 1633058073,
                        ["quant"] = 200,
                        ["id"] = "1690691003",
                        ["itemLink"] = 408,
                    },
                    [42] = 
                    {
                        ["price"] = 10681,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 21,
                        ["timestamp"] = 1633058075,
                        ["quant"] = 200,
                        ["id"] = "1690691029",
                        ["itemLink"] = 408,
                    },
                    [43] = 
                    {
                        ["price"] = 10726,
                        ["guild"] = 1,
                        ["buyer"] = 834,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633068842,
                        ["quant"] = 200,
                        ["id"] = "1690771979",
                        ["itemLink"] = 408,
                    },
                    [44] = 
                    {
                        ["price"] = 10726,
                        ["guild"] = 1,
                        ["buyer"] = 834,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633068843,
                        ["quant"] = 200,
                        ["id"] = "1690771989",
                        ["itemLink"] = 408,
                    },
                    [45] = 
                    {
                        ["price"] = 11616,
                        ["guild"] = 1,
                        ["buyer"] = 834,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633068843,
                        ["quant"] = 200,
                        ["id"] = "1690771999",
                        ["itemLink"] = 408,
                    },
                    [46] = 
                    {
                        ["price"] = 11616,
                        ["guild"] = 1,
                        ["buyer"] = 834,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633068844,
                        ["quant"] = 200,
                        ["id"] = "1690772013",
                        ["itemLink"] = 408,
                    },
                    [47] = 
                    {
                        ["price"] = 11616,
                        ["guild"] = 1,
                        ["buyer"] = 834,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633068845,
                        ["quant"] = 200,
                        ["id"] = "1690772027",
                        ["itemLink"] = 408,
                    },
                    [48] = 
                    {
                        ["price"] = 11616,
                        ["guild"] = 1,
                        ["buyer"] = 834,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633068845,
                        ["quant"] = 200,
                        ["id"] = "1690772037",
                        ["itemLink"] = 408,
                    },
                    [49] = 
                    {
                        ["price"] = 11616,
                        ["guild"] = 1,
                        ["buyer"] = 834,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633068846,
                        ["quant"] = 200,
                        ["id"] = "1690772057",
                        ["itemLink"] = 408,
                    },
                    [50] = 
                    {
                        ["price"] = 12600,
                        ["guild"] = 1,
                        ["buyer"] = 924,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633094896,
                        ["quant"] = 200,
                        ["id"] = "1690918471",
                        ["itemLink"] = 408,
                    },
                    [51] = 
                    {
                        ["price"] = 12600,
                        ["guild"] = 1,
                        ["buyer"] = 924,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633094897,
                        ["quant"] = 200,
                        ["id"] = "1690918483",
                        ["itemLink"] = 408,
                    },
                    [52] = 
                    {
                        ["price"] = 12600,
                        ["guild"] = 1,
                        ["buyer"] = 924,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633094897,
                        ["quant"] = 200,
                        ["id"] = "1690918487",
                        ["itemLink"] = 408,
                    },
                    [53] = 
                    {
                        ["price"] = 10457,
                        ["guild"] = 1,
                        ["buyer"] = 939,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633098881,
                        ["quant"] = 200,
                        ["id"] = "1690948287",
                        ["itemLink"] = 408,
                    },
                    [54] = 
                    {
                        ["price"] = 10457,
                        ["guild"] = 1,
                        ["buyer"] = 939,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633098883,
                        ["quant"] = 200,
                        ["id"] = "1690948291",
                        ["itemLink"] = 408,
                    },
                    [55] = 
                    {
                        ["price"] = 10457,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633105279,
                        ["quant"] = 200,
                        ["id"] = "1691004045",
                        ["itemLink"] = 408,
                    },
                    [56] = 
                    {
                        ["price"] = 10457,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633105279,
                        ["quant"] = 200,
                        ["id"] = "1691004049",
                        ["itemLink"] = 408,
                    },
                    [57] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 979,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1633109422,
                        ["quant"] = 200,
                        ["id"] = "1691031871",
                        ["itemLink"] = 408,
                    },
                    [58] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 1011,
                        ["timestamp"] = 1633114402,
                        ["quant"] = 200,
                        ["id"] = "1691068797",
                        ["itemLink"] = 408,
                    },
                    [59] = 
                    {
                        ["price"] = 10884,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1633147971,
                        ["quant"] = 200,
                        ["id"] = "1691373717",
                        ["itemLink"] = 408,
                    },
                    [60] = 
                    {
                        ["price"] = 10884,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1633147978,
                        ["quant"] = 200,
                        ["id"] = "1691373769",
                        ["itemLink"] = 408,
                    },
                    [61] = 
                    {
                        ["price"] = 10884,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1633147981,
                        ["quant"] = 200,
                        ["id"] = "1691373789",
                        ["itemLink"] = 408,
                    },
                    [62] = 
                    {
                        ["price"] = 10800,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1633148093,
                        ["quant"] = 200,
                        ["id"] = "1691374547",
                        ["itemLink"] = 408,
                    },
                    [63] = 
                    {
                        ["price"] = 10800,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1633148096,
                        ["quant"] = 200,
                        ["id"] = "1691374567",
                        ["itemLink"] = 408,
                    },
                    [64] = 
                    {
                        ["price"] = 10800,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1633148099,
                        ["quant"] = 200,
                        ["id"] = "1691374593",
                        ["itemLink"] = 408,
                    },
                    [65] = 
                    {
                        ["price"] = 10800,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1633148110,
                        ["quant"] = 200,
                        ["id"] = "1691374749",
                        ["itemLink"] = 408,
                    },
                    [66] = 
                    {
                        ["price"] = 10655,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 21,
                        ["timestamp"] = 1633148123,
                        ["quant"] = 200,
                        ["id"] = "1691375033",
                        ["itemLink"] = 408,
                    },
                    [67] = 
                    {
                        ["price"] = 10655,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 21,
                        ["timestamp"] = 1633148125,
                        ["quant"] = 200,
                        ["id"] = "1691375061",
                        ["itemLink"] = 408,
                    },
                    [68] = 
                    {
                        ["price"] = 10800,
                        ["guild"] = 1,
                        ["buyer"] = 1248,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633148499,
                        ["quant"] = 200,
                        ["id"] = "1691377911",
                        ["itemLink"] = 408,
                    },
                    [69] = 
                    {
                        ["price"] = 10655,
                        ["guild"] = 1,
                        ["buyer"] = 1248,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633148501,
                        ["quant"] = 200,
                        ["id"] = "1691377925",
                        ["itemLink"] = 408,
                    },
                    [70] = 
                    {
                        ["price"] = 10983,
                        ["guild"] = 1,
                        ["buyer"] = 1364,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633180213,
                        ["quant"] = 200,
                        ["id"] = "1691586767",
                        ["itemLink"] = 408,
                    },
                    [71] = 
                    {
                        ["price"] = 10983,
                        ["guild"] = 1,
                        ["buyer"] = 1364,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633180215,
                        ["quant"] = 200,
                        ["id"] = "1691586773",
                        ["itemLink"] = 408,
                    },
                    [72] = 
                    {
                        ["price"] = 10983,
                        ["guild"] = 1,
                        ["buyer"] = 1364,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633180218,
                        ["quant"] = 200,
                        ["id"] = "1691586789",
                        ["itemLink"] = 408,
                    },
                    [73] = 
                    {
                        ["price"] = 11900,
                        ["guild"] = 1,
                        ["buyer"] = 1664,
                        ["wasKiosk"] = false,
                        ["seller"] = 845,
                        ["timestamp"] = 1633227797,
                        ["quant"] = 200,
                        ["id"] = "1692093867",
                        ["itemLink"] = 408,
                    },
                    [74] = 
                    {
                        ["price"] = 11900,
                        ["guild"] = 1,
                        ["buyer"] = 1664,
                        ["wasKiosk"] = false,
                        ["seller"] = 845,
                        ["timestamp"] = 1633227799,
                        ["quant"] = 200,
                        ["id"] = "1692093887",
                        ["itemLink"] = 408,
                    },
                    [75] = 
                    {
                        ["price"] = 11900,
                        ["guild"] = 1,
                        ["buyer"] = 1664,
                        ["wasKiosk"] = false,
                        ["seller"] = 845,
                        ["timestamp"] = 1633227801,
                        ["quant"] = 200,
                        ["id"] = "1692093921",
                        ["itemLink"] = 408,
                    },
                    [76] = 
                    {
                        ["price"] = 11900,
                        ["guild"] = 1,
                        ["buyer"] = 1664,
                        ["wasKiosk"] = false,
                        ["seller"] = 845,
                        ["timestamp"] = 1633227801,
                        ["quant"] = 200,
                        ["id"] = "1692093925",
                        ["itemLink"] = 408,
                    },
                    [77] = 
                    {
                        ["price"] = 10780,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633232126,
                        ["quant"] = 200,
                        ["id"] = "1692136489",
                        ["itemLink"] = 408,
                    },
                    [78] = 
                    {
                        ["price"] = 10780,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633232127,
                        ["quant"] = 200,
                        ["id"] = "1692136497",
                        ["itemLink"] = 408,
                    },
                    [79] = 
                    {
                        ["price"] = 10976,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633232128,
                        ["quant"] = 200,
                        ["id"] = "1692136503",
                        ["itemLink"] = 408,
                    },
                    [80] = 
                    {
                        ["price"] = 10976,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633232129,
                        ["quant"] = 200,
                        ["id"] = "1692136509",
                        ["itemLink"] = 408,
                    },
                    [81] = 
                    {
                        ["price"] = 11900,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633232130,
                        ["quant"] = 200,
                        ["id"] = "1692136513",
                        ["itemLink"] = 408,
                    },
                    [82] = 
                    {
                        ["price"] = 11900,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633232130,
                        ["quant"] = 200,
                        ["id"] = "1692136515",
                        ["itemLink"] = 408,
                    },
                    [83] = 
                    {
                        ["price"] = 11900,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633232131,
                        ["quant"] = 200,
                        ["id"] = "1692136525",
                        ["itemLink"] = 408,
                    },
                    [84] = 
                    {
                        ["price"] = 11900,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633232132,
                        ["quant"] = 200,
                        ["id"] = "1692136533",
                        ["itemLink"] = 408,
                    },
                    [85] = 
                    {
                        ["price"] = 11900,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633232133,
                        ["quant"] = 200,
                        ["id"] = "1692136551",
                        ["itemLink"] = 408,
                    },
                    [86] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1633232133,
                        ["quant"] = 200,
                        ["id"] = "1692136561",
                        ["itemLink"] = 408,
                    },
                    [87] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633232134,
                        ["quant"] = 200,
                        ["id"] = "1692136567",
                        ["itemLink"] = 408,
                    },
                    [88] = 
                    {
                        ["price"] = 12518,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633232135,
                        ["quant"] = 200,
                        ["id"] = "1692136575",
                        ["itemLink"] = 408,
                    },
                    [89] = 
                    {
                        ["price"] = 12518,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633232136,
                        ["quant"] = 200,
                        ["id"] = "1692136577",
                        ["itemLink"] = 408,
                    },
                    [90] = 
                    {
                        ["price"] = 12518,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633232136,
                        ["quant"] = 200,
                        ["id"] = "1692136583",
                        ["itemLink"] = 408,
                    },
                    [91] = 
                    {
                        ["price"] = 12600,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633232137,
                        ["quant"] = 200,
                        ["id"] = "1692136589",
                        ["itemLink"] = 408,
                    },
                    [92] = 
                    {
                        ["price"] = 12600,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633232138,
                        ["quant"] = 200,
                        ["id"] = "1692136595",
                        ["itemLink"] = 408,
                    },
                    [93] = 
                    {
                        ["price"] = 12600,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633232138,
                        ["quant"] = 200,
                        ["id"] = "1692136603",
                        ["itemLink"] = 408,
                    },
                    [94] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 1011,
                        ["timestamp"] = 1633232139,
                        ["quant"] = 200,
                        ["id"] = "1692136619",
                        ["itemLink"] = 408,
                    },
                    [95] = 
                    {
                        ["price"] = 10675,
                        ["guild"] = 1,
                        ["buyer"] = 143,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633289796,
                        ["quant"] = 200,
                        ["id"] = "1692625079",
                        ["itemLink"] = 408,
                    },
                    [96] = 
                    {
                        ["price"] = 10675,
                        ["guild"] = 1,
                        ["buyer"] = 143,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633289797,
                        ["quant"] = 200,
                        ["id"] = "1692625091",
                        ["itemLink"] = 408,
                    },
                    [97] = 
                    {
                        ["price"] = 10675,
                        ["guild"] = 1,
                        ["buyer"] = 143,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633289798,
                        ["quant"] = 200,
                        ["id"] = "1692625107",
                        ["itemLink"] = 408,
                    },
                    [98] = 
                    {
                        ["price"] = 10758,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632845835,
                        ["quant"] = 200,
                        ["id"] = "1689108411",
                        ["itemLink"] = 408,
                    },
                    [99] = 
                    {
                        ["price"] = 10758,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632845836,
                        ["quant"] = 200,
                        ["id"] = "1689108421",
                        ["itemLink"] = 408,
                    },
                    [100] = 
                    {
                        ["price"] = 10758,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632845836,
                        ["quant"] = 200,
                        ["id"] = "1689108429",
                        ["itemLink"] = 408,
                    },
                    [101] = 
                    {
                        ["price"] = 10758,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632845837,
                        ["quant"] = 200,
                        ["id"] = "1689108447",
                        ["itemLink"] = 408,
                    },
                    [102] = 
                    {
                        ["price"] = 10803,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1632884743,
                        ["quant"] = 200,
                        ["id"] = "1689448969",
                        ["itemLink"] = 408,
                    },
                    [103] = 
                    {
                        ["price"] = 10803,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1632884744,
                        ["quant"] = 200,
                        ["id"] = "1689448975",
                        ["itemLink"] = 408,
                    },
                    [104] = 
                    {
                        ["price"] = 10803,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1632884745,
                        ["quant"] = 200,
                        ["id"] = "1689448985",
                        ["itemLink"] = 408,
                    },
                    [105] = 
                    {
                        ["price"] = 10851,
                        ["guild"] = 1,
                        ["buyer"] = 2422,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632892464,
                        ["quant"] = 200,
                        ["id"] = "1689512245",
                        ["itemLink"] = 408,
                    },
                    [106] = 
                    {
                        ["price"] = 10851,
                        ["guild"] = 1,
                        ["buyer"] = 2422,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632892465,
                        ["quant"] = 200,
                        ["id"] = "1689512249",
                        ["itemLink"] = 408,
                    },
                    [107] = 
                    {
                        ["price"] = 10851,
                        ["guild"] = 1,
                        ["buyer"] = 2422,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632892465,
                        ["quant"] = 200,
                        ["id"] = "1689512251",
                        ["itemLink"] = 408,
                    },
                    [108] = 
                    {
                        ["price"] = 11621,
                        ["guild"] = 1,
                        ["buyer"] = 2484,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632920543,
                        ["quant"] = 200,
                        ["id"] = "1689654679",
                        ["itemLink"] = 408,
                    },
                    [109] = 
                    {
                        ["price"] = 11621,
                        ["guild"] = 1,
                        ["buyer"] = 2484,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632920544,
                        ["quant"] = 200,
                        ["id"] = "1689654693",
                        ["itemLink"] = 408,
                    },
                    [110] = 
                    {
                        ["price"] = 11621,
                        ["guild"] = 1,
                        ["buyer"] = 2484,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632920544,
                        ["quant"] = 200,
                        ["id"] = "1689654701",
                        ["itemLink"] = 408,
                    },
                    [111] = 
                    {
                        ["price"] = 11621,
                        ["guild"] = 1,
                        ["buyer"] = 2484,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632920546,
                        ["quant"] = 200,
                        ["id"] = "1689654719",
                        ["itemLink"] = 408,
                    },
                    [112] = 
                    {
                        ["price"] = 11621,
                        ["guild"] = 1,
                        ["buyer"] = 2484,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632920547,
                        ["quant"] = 200,
                        ["id"] = "1689654729",
                        ["itemLink"] = 408,
                    },
                    [113] = 
                    {
                        ["price"] = 10399,
                        ["guild"] = 1,
                        ["buyer"] = 121,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1632932719,
                        ["quant"] = 200,
                        ["id"] = "1689742199",
                        ["itemLink"] = 408,
                    },
                    [114] = 
                    {
                        ["price"] = 10477,
                        ["guild"] = 1,
                        ["buyer"] = 121,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632932720,
                        ["quant"] = 200,
                        ["id"] = "1689742211",
                        ["itemLink"] = 408,
                    },
                    [115] = 
                    {
                        ["price"] = 10477,
                        ["guild"] = 1,
                        ["buyer"] = 121,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632932721,
                        ["quant"] = 200,
                        ["id"] = "1689742227",
                        ["itemLink"] = 408,
                    },
                    [116] = 
                    {
                        ["price"] = 10477,
                        ["guild"] = 1,
                        ["buyer"] = 121,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632932721,
                        ["quant"] = 200,
                        ["id"] = "1689742239",
                        ["itemLink"] = 408,
                    },
                },
                ["totalCount"] = 116,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [45343] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_heavy_head_d.dds",
                ["itemDesc"] = "Rubedite Helm",
                ["oldestTime"] = 1632838701,
                ["wasAltered"] = true,
                ["newestTime"] = 1633244684,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 170,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633146930,
                        ["quant"] = 1,
                        ["id"] = "1691365241",
                        ["itemLink"] = 1661,
                    },
                    [2] = 
                    {
                        ["price"] = 170,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633146930,
                        ["quant"] = 1,
                        ["id"] = "1691365251",
                        ["itemLink"] = 1662,
                    },
                    [3] = 
                    {
                        ["price"] = 170,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633146933,
                        ["quant"] = 1,
                        ["id"] = "1691365287",
                        ["itemLink"] = 1664,
                    },
                    [4] = 
                    {
                        ["price"] = 170,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633146941,
                        ["quant"] = 1,
                        ["id"] = "1691365421",
                        ["itemLink"] = 1662,
                    },
                    [5] = 
                    {
                        ["price"] = 198,
                        ["guild"] = 1,
                        ["buyer"] = 1734,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1633236163,
                        ["quant"] = 1,
                        ["id"] = "1692168735",
                        ["itemLink"] = 1664,
                    },
                    [6] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633244680,
                        ["quant"] = 1,
                        ["id"] = "1692231355",
                        ["itemLink"] = 1661,
                    },
                    [7] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633244681,
                        ["quant"] = 1,
                        ["id"] = "1692231359",
                        ["itemLink"] = 2571,
                    },
                    [8] = 
                    {
                        ["price"] = 286,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633244682,
                        ["quant"] = 1,
                        ["id"] = "1692231373",
                        ["itemLink"] = 1661,
                    },
                    [9] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633244684,
                        ["quant"] = 1,
                        ["id"] = "1692231391",
                        ["itemLink"] = 2575,
                    },
                    [10] = 
                    {
                        ["price"] = 212,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632838701,
                        ["quant"] = 1,
                        ["id"] = "1689052587",
                        ["itemLink"] = 2575,
                    },
                    [11] = 
                    {
                        ["price"] = 283,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632885623,
                        ["quant"] = 1,
                        ["id"] = "1689459305",
                        ["itemLink"] = 1662,
                    },
                    [12] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2431,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632895317,
                        ["quant"] = 1,
                        ["id"] = "1689531183",
                        ["itemLink"] = 3559,
                    },
                },
                ["totalCount"] = 12,
                ["itemAdderText"] = "cp160 white normal heavy apparel head intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_heavy_head_d.dds",
                ["itemDesc"] = "Rubedite Helm",
                ["oldestTime"] = 1632930835,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185967,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 185,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633129407,
                        ["quant"] = 1,
                        ["id"] = "1691180275",
                        ["itemLink"] = 1506,
                    },
                    [2] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633185967,
                        ["quant"] = 1,
                        ["id"] = "1691640403",
                        ["itemLink"] = 2036,
                    },
                    [3] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2516,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632930835,
                        ["quant"] = 1,
                        ["id"] = "1689728269",
                        ["itemLink"] = 3707,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp150 white normal heavy apparel head intricate",
            },
        },
        [119330] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing1.dds",
                ["itemDesc"] = "Diagram: Rough Knife, Butcher",
                ["oldestTime"] = 1632905680,
                ["wasAltered"] = true,
                ["newestTime"] = 1632905680,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 146,
                        ["guild"] = 1,
                        ["buyer"] = 2452,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1632905680,
                        ["quant"] = 1,
                        ["id"] = "1689584621",
                        ["itemLink"] = 3586,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal consumable recipe",
            },
        },
        [45347] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ashlanderv_light_robe_a.dds",
                ["itemDesc"] = "Ancestor Silk Robe",
                ["oldestTime"] = 1632843200,
                ["wasAltered"] = true,
                ["newestTime"] = 1633268080,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633009353,
                        ["quant"] = 1,
                        ["id"] = "1690285289",
                        ["itemLink"] = 467,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633009356,
                        ["quant"] = 1,
                        ["id"] = "1690285323",
                        ["itemLink"] = 467,
                    },
                    [3] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633009357,
                        ["quant"] = 1,
                        ["id"] = "1690285337",
                        ["itemLink"] = 470,
                    },
                    [4] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633011734,
                        ["quant"] = 1,
                        ["id"] = "1690302345",
                        ["itemLink"] = 520,
                    },
                    [5] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633084070,
                        ["quant"] = 1,
                        ["id"] = "1690854831",
                        ["itemLink"] = 1169,
                    },
                    [6] = 
                    {
                        ["price"] = 195,
                        ["guild"] = 1,
                        ["buyer"] = 1055,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633121632,
                        ["quant"] = 1,
                        ["id"] = "1691116725",
                        ["itemLink"] = 1441,
                    },
                    [7] = 
                    {
                        ["price"] = 283,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633185999,
                        ["quant"] = 1,
                        ["id"] = "1691640649",
                        ["itemLink"] = 1169,
                    },
                    [8] = 
                    {
                        ["price"] = 193,
                        ["guild"] = 1,
                        ["buyer"] = 1001,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633268080,
                        ["quant"] = 1,
                        ["id"] = "1692385983",
                        ["itemLink"] = 2655,
                    },
                    [9] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632843200,
                        ["quant"] = 1,
                        ["id"] = "1689085363",
                        ["itemLink"] = 467,
                    },
                },
                ["totalCount"] = 9,
                ["itemAdderText"] = "cp160 white normal light apparel chest intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_light_robe_d.dds",
                ["itemDesc"] = "Ancestor Silk Robe",
                ["oldestTime"] = 1632831879,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185966,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 199,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633185966,
                        ["quant"] = 1,
                        ["id"] = "1691640395",
                        ["itemLink"] = 2035,
                    },
                    [2] = 
                    {
                        ["price"] = 198,
                        ["guild"] = 1,
                        ["buyer"] = 2141,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632831879,
                        ["quant"] = 1,
                        ["id"] = "1689009971",
                        ["itemLink"] = 3092,
                    },
                    [3] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632843180,
                        ["quant"] = 1,
                        ["id"] = "1689085235",
                        ["itemLink"] = 3092,
                    },
                    [4] = 
                    {
                        ["price"] = 190,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632885653,
                        ["quant"] = 1,
                        ["id"] = "1689459593",
                        ["itemLink"] = 3513,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp150 white normal light apparel chest intricate",
            },
        },
        [165671] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_fur_benchfancy003.dds",
                ["itemDesc"] = "Solitude Pew, Ornate",
                ["oldestTime"] = 1633165921,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165921,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 28124,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1633165921,
                        ["quant"] = 2,
                        ["id"] = "1691500059",
                        ["itemLink"] = 1849,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [171562] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 100: True-Sworn Shields",
                ["oldestTime"] = 1633163217,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163217,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 59999,
                        ["guild"] = 1,
                        ["buyer"] = 1312,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1633163217,
                        ["quant"] = 1,
                        ["id"] = "1691486859",
                        ["itemLink"] = 1794,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [138796] = 
        {
            ["50:15:1:27:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Platinum Ring",
                ["oldestTime"] = 1632840211,
                ["wasAltered"] = true,
                ["newestTime"] = 1633316378,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 377,
                        ["timestamp"] = 1632994928,
                        ["quant"] = 1,
                        ["id"] = "1690210005",
                        ["itemLink"] = 369,
                    },
                    [2] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009413,
                        ["quant"] = 1,
                        ["id"] = "1690285965",
                        ["itemLink"] = 369,
                    },
                    [3] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009418,
                        ["quant"] = 1,
                        ["id"] = "1690286021",
                        ["itemLink"] = 369,
                    },
                    [4] = 
                    {
                        ["price"] = 919,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633012528,
                        ["quant"] = 1,
                        ["id"] = "1690306583",
                        ["itemLink"] = 369,
                    },
                    [5] = 
                    {
                        ["price"] = 975,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1633012532,
                        ["quant"] = 1,
                        ["id"] = "1690306593",
                        ["itemLink"] = 369,
                    },
                    [6] = 
                    {
                        ["price"] = 830,
                        ["guild"] = 1,
                        ["buyer"] = 609,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633037549,
                        ["quant"] = 1,
                        ["id"] = "1690495579",
                        ["itemLink"] = 369,
                    },
                    [7] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 707,
                        ["wasKiosk"] = true,
                        ["seller"] = 552,
                        ["timestamp"] = 1633052043,
                        ["quant"] = 1,
                        ["id"] = "1690626463",
                        ["itemLink"] = 369,
                    },
                    [8] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 707,
                        ["wasKiosk"] = true,
                        ["seller"] = 552,
                        ["timestamp"] = 1633052043,
                        ["quant"] = 1,
                        ["id"] = "1690626471",
                        ["itemLink"] = 369,
                    },
                    [9] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 707,
                        ["wasKiosk"] = true,
                        ["seller"] = 552,
                        ["timestamp"] = 1633052045,
                        ["quant"] = 1,
                        ["id"] = "1690626493",
                        ["itemLink"] = 369,
                    },
                    [10] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633132607,
                        ["quant"] = 1,
                        ["id"] = "1691214643",
                        ["itemLink"] = 369,
                    },
                    [11] = 
                    {
                        ["price"] = 1050,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633132609,
                        ["quant"] = 1,
                        ["id"] = "1691214653",
                        ["itemLink"] = 369,
                    },
                    [12] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633132612,
                        ["quant"] = 1,
                        ["id"] = "1691214689",
                        ["itemLink"] = 369,
                    },
                    [13] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633132618,
                        ["quant"] = 1,
                        ["id"] = "1691214733",
                        ["itemLink"] = 369,
                    },
                    [14] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633132619,
                        ["quant"] = 1,
                        ["id"] = "1691214737",
                        ["itemLink"] = 369,
                    },
                    [15] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633132631,
                        ["quant"] = 1,
                        ["id"] = "1691214847",
                        ["itemLink"] = 369,
                    },
                    [16] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633132632,
                        ["quant"] = 1,
                        ["id"] = "1691214853",
                        ["itemLink"] = 369,
                    },
                    [17] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633132633,
                        ["quant"] = 1,
                        ["id"] = "1691214857",
                        ["itemLink"] = 369,
                    },
                    [18] = 
                    {
                        ["price"] = 648,
                        ["guild"] = 1,
                        ["buyer"] = 1147,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633135985,
                        ["quant"] = 1,
                        ["id"] = "1691252641",
                        ["itemLink"] = 369,
                    },
                    [19] = 
                    {
                        ["price"] = 895,
                        ["guild"] = 1,
                        ["buyer"] = 1147,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633135986,
                        ["quant"] = 1,
                        ["id"] = "1691252645",
                        ["itemLink"] = 369,
                    },
                    [20] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1147,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633135989,
                        ["quant"] = 1,
                        ["id"] = "1691252661",
                        ["itemLink"] = 369,
                    },
                    [21] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1230,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633146157,
                        ["quant"] = 1,
                        ["id"] = "1691358091",
                        ["itemLink"] = 369,
                    },
                    [22] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1230,
                        ["wasKiosk"] = true,
                        ["seller"] = 61,
                        ["timestamp"] = 1633146158,
                        ["quant"] = 1,
                        ["id"] = "1691358107",
                        ["itemLink"] = 369,
                    },
                    [23] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633186083,
                        ["quant"] = 1,
                        ["id"] = "1691641627",
                        ["itemLink"] = 369,
                    },
                    [24] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633186084,
                        ["quant"] = 1,
                        ["id"] = "1691641633",
                        ["itemLink"] = 369,
                    },
                    [25] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1440,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633194324,
                        ["quant"] = 1,
                        ["id"] = "1691737147",
                        ["itemLink"] = 369,
                    },
                    [26] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1440,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633194326,
                        ["quant"] = 1,
                        ["id"] = "1691737167",
                        ["itemLink"] = 369,
                    },
                    [27] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1440,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633194327,
                        ["quant"] = 1,
                        ["id"] = "1691737173",
                        ["itemLink"] = 369,
                    },
                    [28] = 
                    {
                        ["price"] = 830,
                        ["guild"] = 1,
                        ["buyer"] = 1041,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633204193,
                        ["quant"] = 1,
                        ["id"] = "1691835235",
                        ["itemLink"] = 369,
                    },
                    [29] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 1041,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1633204195,
                        ["quant"] = 1,
                        ["id"] = "1691835279",
                        ["itemLink"] = 369,
                    },
                    [30] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 1041,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1633204196,
                        ["quant"] = 1,
                        ["id"] = "1691835291",
                        ["itemLink"] = 369,
                    },
                    [31] = 
                    {
                        ["price"] = 638,
                        ["guild"] = 1,
                        ["buyer"] = 1772,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633240478,
                        ["quant"] = 1,
                        ["id"] = "1692201445",
                        ["itemLink"] = 369,
                    },
                    [32] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633248631,
                        ["quant"] = 1,
                        ["id"] = "1692261711",
                        ["itemLink"] = 369,
                    },
                    [33] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633248632,
                        ["quant"] = 1,
                        ["id"] = "1692261717",
                        ["itemLink"] = 369,
                    },
                    [34] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633248633,
                        ["quant"] = 1,
                        ["id"] = "1692261721",
                        ["itemLink"] = 369,
                    },
                    [35] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633248634,
                        ["quant"] = 1,
                        ["id"] = "1692261727",
                        ["itemLink"] = 369,
                    },
                    [36] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633248635,
                        ["quant"] = 1,
                        ["id"] = "1692261731",
                        ["itemLink"] = 369,
                    },
                    [37] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1810,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1633249532,
                        ["quant"] = 1,
                        ["id"] = "1692267093",
                        ["itemLink"] = 369,
                    },
                    [38] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1810,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1633249534,
                        ["quant"] = 1,
                        ["id"] = "1692267107",
                        ["itemLink"] = 369,
                    },
                    [39] = 
                    {
                        ["price"] = 1065,
                        ["guild"] = 1,
                        ["buyer"] = 1810,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633249535,
                        ["quant"] = 1,
                        ["id"] = "1692267117",
                        ["itemLink"] = 369,
                    },
                    [40] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1898,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633274747,
                        ["quant"] = 1,
                        ["id"] = "1692460493",
                        ["itemLink"] = 369,
                    },
                    [41] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1898,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633274747,
                        ["quant"] = 1,
                        ["id"] = "1692460499",
                        ["itemLink"] = 369,
                    },
                    [42] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1898,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633274748,
                        ["quant"] = 1,
                        ["id"] = "1692460509",
                        ["itemLink"] = 369,
                    },
                    [43] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1898,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633274748,
                        ["quant"] = 1,
                        ["id"] = "1692460525",
                        ["itemLink"] = 369,
                    },
                    [44] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1898,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633274749,
                        ["quant"] = 1,
                        ["id"] = "1692460531",
                        ["itemLink"] = 369,
                    },
                    [45] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2025,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633297056,
                        ["quant"] = 1,
                        ["id"] = "1692711391",
                        ["itemLink"] = 369,
                    },
                    [46] = 
                    {
                        ["price"] = 675,
                        ["guild"] = 1,
                        ["buyer"] = 2051,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633302476,
                        ["quant"] = 1,
                        ["id"] = "1692766309",
                        ["itemLink"] = 369,
                    },
                    [47] = 
                    {
                        ["price"] = 1050,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633308942,
                        ["quant"] = 1,
                        ["id"] = "1692835021",
                        ["itemLink"] = 369,
                    },
                    [48] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633308944,
                        ["quant"] = 1,
                        ["id"] = "1692835067",
                        ["itemLink"] = 369,
                    },
                    [49] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633308952,
                        ["quant"] = 1,
                        ["id"] = "1692835213",
                        ["itemLink"] = 369,
                    },
                    [50] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633308957,
                        ["quant"] = 1,
                        ["id"] = "1692835353",
                        ["itemLink"] = 369,
                    },
                    [51] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2177,
                        ["wasKiosk"] = true,
                        ["seller"] = 281,
                        ["timestamp"] = 1632840211,
                        ["quant"] = 1,
                        ["id"] = "1689061523",
                        ["itemLink"] = 369,
                    },
                    [52] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2177,
                        ["wasKiosk"] = true,
                        ["seller"] = 281,
                        ["timestamp"] = 1632840212,
                        ["quant"] = 1,
                        ["id"] = "1689061529",
                        ["itemLink"] = 369,
                    },
                    [53] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2177,
                        ["wasKiosk"] = true,
                        ["seller"] = 281,
                        ["timestamp"] = 1632840214,
                        ["quant"] = 1,
                        ["id"] = "1689061541",
                        ["itemLink"] = 369,
                    },
                    [54] = 
                    {
                        ["price"] = 975,
                        ["guild"] = 1,
                        ["buyer"] = 1433,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632842119,
                        ["quant"] = 1,
                        ["id"] = "1689074493",
                        ["itemLink"] = 369,
                    },
                    [55] = 
                    {
                        ["price"] = 638,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1632865289,
                        ["quant"] = 1,
                        ["id"] = "1689266591",
                        ["itemLink"] = 369,
                    },
                    [56] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865295,
                        ["quant"] = 1,
                        ["id"] = "1689266707",
                        ["itemLink"] = 369,
                    },
                    [57] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865297,
                        ["quant"] = 1,
                        ["id"] = "1689266739",
                        ["itemLink"] = 369,
                    },
                    [58] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865298,
                        ["quant"] = 1,
                        ["id"] = "1689266747",
                        ["itemLink"] = 369,
                    },
                    [59] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865299,
                        ["quant"] = 1,
                        ["id"] = "1689266751",
                        ["itemLink"] = 369,
                    },
                    [60] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865299,
                        ["quant"] = 1,
                        ["id"] = "1689266759",
                        ["itemLink"] = 369,
                    },
                    [61] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865303,
                        ["quant"] = 1,
                        ["id"] = "1689266803",
                        ["itemLink"] = 369,
                    },
                    [62] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865304,
                        ["quant"] = 1,
                        ["id"] = "1689266813",
                        ["itemLink"] = 369,
                    },
                    [63] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865307,
                        ["quant"] = 1,
                        ["id"] = "1689266847",
                        ["itemLink"] = 369,
                    },
                    [64] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1632865312,
                        ["quant"] = 1,
                        ["id"] = "1689266881",
                        ["itemLink"] = 369,
                    },
                    [65] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632865320,
                        ["quant"] = 1,
                        ["id"] = "1689266953",
                        ["itemLink"] = 369,
                    },
                    [66] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632865321,
                        ["quant"] = 1,
                        ["id"] = "1689266957",
                        ["itemLink"] = 369,
                    },
                    [67] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632865322,
                        ["quant"] = 1,
                        ["id"] = "1689266963",
                        ["itemLink"] = 369,
                    },
                    [68] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2421,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632892358,
                        ["quant"] = 1,
                        ["id"] = "1689511589",
                        ["itemLink"] = 369,
                    },
                    [69] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2421,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632892359,
                        ["quant"] = 1,
                        ["id"] = "1689511597",
                        ["itemLink"] = 369,
                    },
                    [70] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2421,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632892360,
                        ["quant"] = 1,
                        ["id"] = "1689511611",
                        ["itemLink"] = 369,
                    },
                    [71] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2421,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632892362,
                        ["quant"] = 1,
                        ["id"] = "1689511623",
                        ["itemLink"] = 369,
                    },
                    [72] = 
                    {
                        ["price"] = 975,
                        ["guild"] = 1,
                        ["buyer"] = 2503,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632926861,
                        ["quant"] = 1,
                        ["id"] = "1689699787",
                        ["itemLink"] = 369,
                    },
                    [73] = 
                    {
                        ["price"] = 975,
                        ["guild"] = 1,
                        ["buyer"] = 2503,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632926862,
                        ["quant"] = 1,
                        ["id"] = "1689699793",
                        ["itemLink"] = 369,
                    },
                    [74] = 
                    {
                        ["price"] = 975,
                        ["guild"] = 1,
                        ["buyer"] = 2503,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632926862,
                        ["quant"] = 1,
                        ["id"] = "1689699797",
                        ["itemLink"] = 369,
                    },
                    [75] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 2503,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632926865,
                        ["quant"] = 1,
                        ["id"] = "1689699809",
                        ["itemLink"] = 369,
                    },
                    [76] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 2503,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1632926866,
                        ["quant"] = 1,
                        ["id"] = "1689699827",
                        ["itemLink"] = 369,
                    },
                    [77] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 2543,
                        ["wasKiosk"] = true,
                        ["seller"] = 377,
                        ["timestamp"] = 1632940532,
                        ["quant"] = 1,
                        ["id"] = "1689798107",
                        ["itemLink"] = 369,
                    },
                    [78] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 2564,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1632945817,
                        ["quant"] = 1,
                        ["id"] = "1689840639",
                        ["itemLink"] = 369,
                    },
                    [79] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 2564,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1632945823,
                        ["quant"] = 1,
                        ["id"] = "1689840677",
                        ["itemLink"] = 369,
                    },
                    [80] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 2564,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1632946050,
                        ["quant"] = 1,
                        ["id"] = "1689842225",
                        ["itemLink"] = 369,
                    },
                    [81] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 2564,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1632946050,
                        ["quant"] = 1,
                        ["id"] = "1689842233",
                        ["itemLink"] = 369,
                    },
                    [82] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 2096,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633316378,
                        ["quant"] = 1,
                        ["id"] = "1692919163",
                        ["itemLink"] = 369,
                    },
                },
                ["totalCount"] = 82,
                ["itemAdderText"] = "cp150 white normal jewelry apparel ring intricate",
            },
            ["26:0:1:27:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Copper Ring",
                ["oldestTime"] = 1632865315,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865315,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1175,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1632865315,
                        ["quant"] = 1,
                        ["id"] = "1689266897",
                        ["itemLink"] = 3331,
                    },
                    [2] = 
                    {
                        ["price"] = 1175,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1632865315,
                        ["quant"] = 1,
                        ["id"] = "1689266901",
                        ["itemLink"] = 3331,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr26 white normal jewelry apparel ring intricate",
            },
            ["1:0:1:27:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Pewter Ring",
                ["oldestTime"] = 1632865310,
                ["wasAltered"] = true,
                ["newestTime"] = 1633009423,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 445,
                        ["timestamp"] = 1633009423,
                        ["quant"] = 1,
                        ["id"] = "1690286079",
                        ["itemLink"] = 510,
                    },
                    [2] = 
                    {
                        ["price"] = 985,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1632865310,
                        ["quant"] = 1,
                        ["id"] = "1689266865",
                        ["itemLink"] = 510,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal jewelry apparel ring intricate",
            },
            ["48:0:1:27:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Copper Ring",
                ["oldestTime"] = 1632845336,
                ["wasAltered"] = true,
                ["newestTime"] = 1632845336,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 475,
                        ["guild"] = 1,
                        ["buyer"] = 2196,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632845336,
                        ["quant"] = 1,
                        ["id"] = "1689103161",
                        ["itemLink"] = 3192,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr48 white normal jewelry apparel ring intricate",
            },
            ["37:0:1:27:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Copper Ring",
                ["oldestTime"] = 1632908150,
                ["wasAltered"] = true,
                ["newestTime"] = 1633057610,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 470,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633057610,
                        ["quant"] = 1,
                        ["id"] = "1690686791",
                        ["itemLink"] = 967,
                    },
                    [2] = 
                    {
                        ["price"] = 475,
                        ["guild"] = 1,
                        ["buyer"] = 2458,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632908150,
                        ["quant"] = 1,
                        ["id"] = "1689595839",
                        ["itemLink"] = 967,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr37 white normal jewelry apparel ring intricate",
            },
            ["50:16:1:27:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Platinum Ring",
                ["oldestTime"] = 1632793708,
                ["wasAltered"] = true,
                ["newestTime"] = 1633316377,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 2,
                        ["buyer"] = 131,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1632793708,
                        ["quant"] = 1,
                        ["id"] = "1688754589",
                        ["itemLink"] = 134,
                    },
                    [2] = 
                    {
                        ["price"] = 1050,
                        ["guild"] = 2,
                        ["buyer"] = 131,
                        ["wasKiosk"] = false,
                        ["seller"] = 127,
                        ["timestamp"] = 1632793708,
                        ["quant"] = 1,
                        ["id"] = "1688754597",
                        ["itemLink"] = 134,
                    },
                    [3] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632976877,
                        ["quant"] = 1,
                        ["id"] = "1690109603",
                        ["itemLink"] = 134,
                    },
                    [4] = 
                    {
                        ["price"] = 970,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1632994929,
                        ["quant"] = 1,
                        ["id"] = "1690210011",
                        ["itemLink"] = 134,
                    },
                    [5] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633009402,
                        ["quant"] = 1,
                        ["id"] = "1690285841",
                        ["itemLink"] = 134,
                    },
                    [6] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633009404,
                        ["quant"] = 1,
                        ["id"] = "1690285861",
                        ["itemLink"] = 134,
                    },
                    [7] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633009410,
                        ["quant"] = 1,
                        ["id"] = "1690285927",
                        ["itemLink"] = 134,
                    },
                    [8] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009414,
                        ["quant"] = 1,
                        ["id"] = "1690285973",
                        ["itemLink"] = 134,
                    },
                    [9] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009416,
                        ["quant"] = 1,
                        ["id"] = "1690285995",
                        ["itemLink"] = 134,
                    },
                    [10] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 445,
                        ["timestamp"] = 1633009421,
                        ["quant"] = 1,
                        ["id"] = "1690286057",
                        ["itemLink"] = 134,
                    },
                    [11] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 445,
                        ["timestamp"] = 1633009424,
                        ["quant"] = 1,
                        ["id"] = "1690286091",
                        ["itemLink"] = 134,
                    },
                    [12] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 445,
                        ["timestamp"] = 1633009426,
                        ["quant"] = 1,
                        ["id"] = "1690286113",
                        ["itemLink"] = 134,
                    },
                    [13] = 
                    {
                        ["price"] = 975,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1633012530,
                        ["quant"] = 1,
                        ["id"] = "1690306587",
                        ["itemLink"] = 134,
                    },
                    [14] = 
                    {
                        ["price"] = 810,
                        ["guild"] = 1,
                        ["buyer"] = 346,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633019445,
                        ["quant"] = 1,
                        ["id"] = "1690362115",
                        ["itemLink"] = 134,
                    },
                    [15] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 539,
                        ["timestamp"] = 1633025270,
                        ["quant"] = 1,
                        ["id"] = "1690410445",
                        ["itemLink"] = 134,
                    },
                    [16] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 584,
                        ["wasKiosk"] = true,
                        ["seller"] = 552,
                        ["timestamp"] = 1633033875,
                        ["quant"] = 1,
                        ["id"] = "1690468847",
                        ["itemLink"] = 134,
                    },
                    [17] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 584,
                        ["wasKiosk"] = true,
                        ["seller"] = 552,
                        ["timestamp"] = 1633033877,
                        ["quant"] = 1,
                        ["id"] = "1690468855",
                        ["itemLink"] = 134,
                    },
                    [18] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 609,
                        ["wasKiosk"] = true,
                        ["seller"] = 539,
                        ["timestamp"] = 1633037548,
                        ["quant"] = 1,
                        ["id"] = "1690495571",
                        ["itemLink"] = 134,
                    },
                    [19] = 
                    {
                        ["price"] = 850,
                        ["guild"] = 1,
                        ["buyer"] = 609,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633037551,
                        ["quant"] = 1,
                        ["id"] = "1690495585",
                        ["itemLink"] = 134,
                    },
                    [20] = 
                    {
                        ["price"] = 990,
                        ["guild"] = 1,
                        ["buyer"] = 609,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633037554,
                        ["quant"] = 1,
                        ["id"] = "1690495599",
                        ["itemLink"] = 134,
                    },
                    [21] = 
                    {
                        ["price"] = 970,
                        ["guild"] = 1,
                        ["buyer"] = 636,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633041443,
                        ["quant"] = 1,
                        ["id"] = "1690523935",
                        ["itemLink"] = 134,
                    },
                    [22] = 
                    {
                        ["price"] = 970,
                        ["guild"] = 1,
                        ["buyer"] = 636,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633041444,
                        ["quant"] = 1,
                        ["id"] = "1690523945",
                        ["itemLink"] = 134,
                    },
                    [23] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 636,
                        ["wasKiosk"] = true,
                        ["seller"] = 552,
                        ["timestamp"] = 1633041446,
                        ["quant"] = 1,
                        ["id"] = "1690523967",
                        ["itemLink"] = 134,
                    },
                    [24] = 
                    {
                        ["price"] = 1025,
                        ["guild"] = 1,
                        ["buyer"] = 636,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633041449,
                        ["quant"] = 1,
                        ["id"] = "1690523993",
                        ["itemLink"] = 134,
                    },
                    [25] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 908,
                        ["wasKiosk"] = true,
                        ["seller"] = 377,
                        ["timestamp"] = 1633087521,
                        ["quant"] = 1,
                        ["id"] = "1690873355",
                        ["itemLink"] = 134,
                    },
                    [26] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 1041,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633118968,
                        ["quant"] = 1,
                        ["id"] = "1691098029",
                        ["itemLink"] = 134,
                    },
                    [27] = 
                    {
                        ["price"] = 640,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633132606,
                        ["quant"] = 1,
                        ["id"] = "1691214631",
                        ["itemLink"] = 134,
                    },
                    [28] = 
                    {
                        ["price"] = 1025,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633132608,
                        ["quant"] = 1,
                        ["id"] = "1691214649",
                        ["itemLink"] = 134,
                    },
                    [29] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633132611,
                        ["quant"] = 1,
                        ["id"] = "1691214675",
                        ["itemLink"] = 134,
                    },
                    [30] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633132611,
                        ["quant"] = 1,
                        ["id"] = "1691214683",
                        ["itemLink"] = 134,
                    },
                    [31] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633132613,
                        ["quant"] = 1,
                        ["id"] = "1691214699",
                        ["itemLink"] = 134,
                    },
                    [32] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633132635,
                        ["quant"] = 1,
                        ["id"] = "1691214871",
                        ["itemLink"] = 134,
                    },
                    [33] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633132636,
                        ["quant"] = 1,
                        ["id"] = "1691214875",
                        ["itemLink"] = 134,
                    },
                    [34] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633132636,
                        ["quant"] = 1,
                        ["id"] = "1691214885",
                        ["itemLink"] = 134,
                    },
                    [35] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1230,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1633147028,
                        ["quant"] = 1,
                        ["id"] = "1691366477",
                        ["itemLink"] = 134,
                    },
                    [36] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1230,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1633147029,
                        ["quant"] = 1,
                        ["id"] = "1691366493",
                        ["itemLink"] = 134,
                    },
                    [37] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1230,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1633147029,
                        ["quant"] = 1,
                        ["id"] = "1691366497",
                        ["itemLink"] = 134,
                    },
                    [38] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633186068,
                        ["quant"] = 1,
                        ["id"] = "1691641461",
                        ["itemLink"] = 134,
                    },
                    [39] = 
                    {
                        ["price"] = 1113,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633186080,
                        ["quant"] = 1,
                        ["id"] = "1691641607",
                        ["itemLink"] = 134,
                    },
                    [40] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633186085,
                        ["quant"] = 1,
                        ["id"] = "1691641641",
                        ["itemLink"] = 134,
                    },
                    [41] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1440,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633194328,
                        ["quant"] = 1,
                        ["id"] = "1691737185",
                        ["itemLink"] = 134,
                    },
                    [42] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 1041,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1633204195,
                        ["quant"] = 1,
                        ["id"] = "1691835261",
                        ["itemLink"] = 134,
                    },
                    [43] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1563,
                        ["wasKiosk"] = true,
                        ["seller"] = 281,
                        ["timestamp"] = 1633213296,
                        ["quant"] = 1,
                        ["id"] = "1691943351",
                        ["itemLink"] = 134,
                    },
                    [44] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633238325,
                        ["quant"] = 1,
                        ["id"] = "1692187799",
                        ["itemLink"] = 134,
                    },
                    [45] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633238326,
                        ["quant"] = 1,
                        ["id"] = "1692187805",
                        ["itemLink"] = 134,
                    },
                    [46] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633238326,
                        ["quant"] = 1,
                        ["id"] = "1692187809",
                        ["itemLink"] = 134,
                    },
                    [47] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633238327,
                        ["quant"] = 1,
                        ["id"] = "1692187813",
                        ["itemLink"] = 134,
                    },
                    [48] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1633238329,
                        ["quant"] = 1,
                        ["id"] = "1692187821",
                        ["itemLink"] = 134,
                    },
                    [49] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633238335,
                        ["quant"] = 1,
                        ["id"] = "1692187845",
                        ["itemLink"] = 134,
                    },
                    [50] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633238336,
                        ["quant"] = 1,
                        ["id"] = "1692187847",
                        ["itemLink"] = 134,
                    },
                    [51] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1748,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633238340,
                        ["quant"] = 1,
                        ["id"] = "1692187859",
                        ["itemLink"] = 134,
                    },
                    [52] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633248630,
                        ["quant"] = 1,
                        ["id"] = "1692261699",
                        ["itemLink"] = 134,
                    },
                    [53] = 
                    {
                        ["price"] = 990,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633248631,
                        ["quant"] = 1,
                        ["id"] = "1692261707",
                        ["itemLink"] = 134,
                    },
                    [54] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 1845,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633263532,
                        ["quant"] = 1,
                        ["id"] = "1692347065",
                        ["itemLink"] = 134,
                    },
                    [55] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 1870,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633269142,
                        ["quant"] = 1,
                        ["id"] = "1692395941",
                        ["itemLink"] = 134,
                    },
                    [56] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 1870,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633269143,
                        ["quant"] = 1,
                        ["id"] = "1692395961",
                        ["itemLink"] = 134,
                    },
                    [57] = 
                    {
                        ["price"] = 1050,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633294755,
                        ["quant"] = 1,
                        ["id"] = "1692687211",
                        ["itemLink"] = 134,
                    },
                    [58] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633294757,
                        ["quant"] = 1,
                        ["id"] = "1692687241",
                        ["itemLink"] = 134,
                    },
                    [59] = 
                    {
                        ["price"] = 1141,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633294758,
                        ["quant"] = 1,
                        ["id"] = "1692687259",
                        ["itemLink"] = 134,
                    },
                    [60] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 2051,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633302478,
                        ["quant"] = 1,
                        ["id"] = "1692766337",
                        ["itemLink"] = 134,
                    },
                    [61] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633308946,
                        ["quant"] = 1,
                        ["id"] = "1692835109",
                        ["itemLink"] = 134,
                    },
                    [62] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633308951,
                        ["quant"] = 1,
                        ["id"] = "1692835189",
                        ["itemLink"] = 134,
                    },
                    [63] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633308955,
                        ["quant"] = 1,
                        ["id"] = "1692835289",
                        ["itemLink"] = 134,
                    },
                    [64] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633308961,
                        ["quant"] = 1,
                        ["id"] = "1692835415",
                        ["itemLink"] = 134,
                    },
                    [65] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 2138,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1632831290,
                        ["quant"] = 1,
                        ["id"] = "1689006849",
                        ["itemLink"] = 134,
                    },
                    [66] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2177,
                        ["wasKiosk"] = true,
                        ["seller"] = 281,
                        ["timestamp"] = 1632840210,
                        ["quant"] = 1,
                        ["id"] = "1689061519",
                        ["itemLink"] = 134,
                    },
                    [67] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865296,
                        ["quant"] = 1,
                        ["id"] = "1689266719",
                        ["itemLink"] = 134,
                    },
                    [68] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865305,
                        ["quant"] = 1,
                        ["id"] = "1689266837",
                        ["itemLink"] = 134,
                    },
                    [69] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865307,
                        ["quant"] = 1,
                        ["id"] = "1689266851",
                        ["itemLink"] = 134,
                    },
                    [70] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865308,
                        ["quant"] = 1,
                        ["id"] = "1689266855",
                        ["itemLink"] = 134,
                    },
                    [71] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1632865308,
                        ["quant"] = 1,
                        ["id"] = "1689266857",
                        ["itemLink"] = 134,
                    },
                    [72] = 
                    {
                        ["price"] = 1025,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632865311,
                        ["quant"] = 1,
                        ["id"] = "1689266877",
                        ["itemLink"] = 134,
                    },
                    [73] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1632865317,
                        ["quant"] = 1,
                        ["id"] = "1689266915",
                        ["itemLink"] = 134,
                    },
                    [74] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1632865318,
                        ["quant"] = 1,
                        ["id"] = "1689266919",
                        ["itemLink"] = 134,
                    },
                    [75] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632865318,
                        ["quant"] = 1,
                        ["id"] = "1689266923",
                        ["itemLink"] = 134,
                    },
                    [76] = 
                    {
                        ["price"] = 1399,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 283,
                        ["timestamp"] = 1632865318,
                        ["quant"] = 1,
                        ["id"] = "1689266929",
                        ["itemLink"] = 134,
                    },
                    [77] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 445,
                        ["timestamp"] = 1632865325,
                        ["quant"] = 1,
                        ["id"] = "1689266979",
                        ["itemLink"] = 134,
                    },
                    [78] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1942,
                        ["wasKiosk"] = true,
                        ["seller"] = 171,
                        ["timestamp"] = 1632890254,
                        ["quant"] = 1,
                        ["id"] = "1689494291",
                        ["itemLink"] = 134,
                    },
                    [79] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1942,
                        ["wasKiosk"] = true,
                        ["seller"] = 171,
                        ["timestamp"] = 1632890254,
                        ["quant"] = 1,
                        ["id"] = "1689494293",
                        ["itemLink"] = 134,
                    },
                    [80] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 2564,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1632945821,
                        ["quant"] = 1,
                        ["id"] = "1689840663",
                        ["itemLink"] = 134,
                    },
                    [81] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 2564,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1632945821,
                        ["quant"] = 1,
                        ["id"] = "1689840667",
                        ["itemLink"] = 134,
                    },
                    [82] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 2564,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1632946051,
                        ["quant"] = 1,
                        ["id"] = "1689842239",
                        ["itemLink"] = 134,
                    },
                    [83] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 2593,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1632951863,
                        ["quant"] = 1,
                        ["id"] = "1689891093",
                        ["itemLink"] = 134,
                    },
                    [84] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 2096,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633316377,
                        ["quant"] = 1,
                        ["id"] = "1692919147",
                        ["itemLink"] = 134,
                    },
                },
                ["totalCount"] = 84,
                ["itemAdderText"] = "cp160 white normal jewelry apparel ring intricate",
            },
            ["47:0:1:27:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Copper Ring",
                ["oldestTime"] = 1633120354,
                ["wasAltered"] = true,
                ["newestTime"] = 1633120354,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 575,
                        ["guild"] = 1,
                        ["buyer"] = 1049,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633120354,
                        ["quant"] = 1,
                        ["id"] = "1691107467",
                        ["itemLink"] = 1432,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr47 white normal jewelry apparel ring intricate",
            },
        },
        [69165] = 
        {
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Endurance",
                ["oldestTime"] = 1632948470,
                ["wasAltered"] = true,
                ["newestTime"] = 1632948470,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3860,
                        ["guild"] = 1,
                        ["buyer"] = 538,
                        ["wasKiosk"] = true,
                        ["seller"] = 159,
                        ["timestamp"] = 1632948470,
                        ["quant"] = 1,
                        ["id"] = "1689861351",
                        ["itemLink"] = 3799,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set endurance ring healthy",
            },
        },
        [69167] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Endurance",
                ["oldestTime"] = 1633183937,
                ["wasAltered"] = true,
                ["newestTime"] = 1633183937,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 1384,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633183937,
                        ["quant"] = 1,
                        ["id"] = "1691621125",
                        ["itemLink"] = 1967,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set endurance ring arcane",
            },
        },
        [97072] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_hands_d.dds",
                ["itemDesc"] = "Plague Doctor's Gauntlets",
                ["oldestTime"] = 1633035295,
                ["wasAltered"] = true,
                ["newestTime"] = 1633035295,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3200,
                        ["guild"] = 1,
                        ["buyer"] = 596,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633035295,
                        ["quant"] = 1,
                        ["id"] = "1690478047",
                        ["itemLink"] = 761,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set plague doctor hands divines",
            },
        },
        [69169] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Endurance",
                ["oldestTime"] = 1632959577,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309083,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 306,
                        ["wasKiosk"] = true,
                        ["seller"] = 171,
                        ["timestamp"] = 1632984288,
                        ["quant"] = 1,
                        ["id"] = "1690155549",
                        ["itemLink"] = 308,
                    },
                    [2] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 778,
                        ["wasKiosk"] = false,
                        ["seller"] = 388,
                        ["timestamp"] = 1633309083,
                        ["quant"] = 1,
                        ["id"] = "1692837177",
                        ["itemLink"] = 2965,
                    },
                    [3] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 1384,
                        ["wasKiosk"] = true,
                        ["seller"] = 1077,
                        ["timestamp"] = 1632959577,
                        ["quant"] = 1,
                        ["id"] = "1689957101",
                        ["itemLink"] = 308,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set endurance ring robust",
            },
        },
        [45874] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_potionpotency.dds",
                ["itemDesc"] = "Superb Glyph of Potion Boost",
                ["oldestTime"] = 1633204564,
                ["wasAltered"] = true,
                ["newestTime"] = 1633204564,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 120,
                        ["guild"] = 1,
                        ["buyer"] = 1516,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633204564,
                        ["quant"] = 1,
                        ["id"] = "1691839115",
                        ["itemLink"] = 2234,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 green fine miscellaneous jewelry glyph",
            },
        },
        [167989] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 97: Wayward Guardian Shoulders",
                ["oldestTime"] = 1633008399,
                ["wasAltered"] = true,
                ["newestTime"] = 1633008399,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 437,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1633008399,
                        ["quant"] = 1,
                        ["id"] = "1690279145",
                        ["itemLink"] = 444,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [160569] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 86: Sea Giant Maces",
                ["oldestTime"] = 1633280957,
                ["wasAltered"] = true,
                ["newestTime"] = 1633280957,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 933,
                        ["wasKiosk"] = true,
                        ["seller"] = 1450,
                        ["timestamp"] = 1633280957,
                        ["quant"] = 1,
                        ["id"] = "1692524443",
                        ["itemLink"] = 2736,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45884] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_increasespelldamage.dds",
                ["itemDesc"] = "Superb Glyph of Increase Magical Harm",
                ["oldestTime"] = 1632826379,
                ["wasAltered"] = true,
                ["newestTime"] = 1632826379,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 130,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 527,
                        ["timestamp"] = 1632826379,
                        ["quant"] = 1,
                        ["id"] = "1688971227",
                        ["itemLink"] = 3030,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 green fine miscellaneous jewelry glyph",
            },
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_increasespelldamage.dds",
                ["itemDesc"] = "Truly Superb Glyph of Increase Magical Harm",
                ["oldestTime"] = 1632846786,
                ["wasAltered"] = true,
                ["newestTime"] = 1633284394,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7200,
                        ["guild"] = 1,
                        ["buyer"] = 818,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633065514,
                        ["quant"] = 1,
                        ["id"] = "1690751713",
                        ["itemLink"] = 1062,
                    },
                    [2] = 
                    {
                        ["price"] = 7200,
                        ["guild"] = 1,
                        ["buyer"] = 818,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633065515,
                        ["quant"] = 1,
                        ["id"] = "1690751731",
                        ["itemLink"] = 1062,
                    },
                    [3] = 
                    {
                        ["price"] = 7200,
                        ["guild"] = 1,
                        ["buyer"] = 818,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633065516,
                        ["quant"] = 1,
                        ["id"] = "1690751741",
                        ["itemLink"] = 1062,
                    },
                    [4] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 158,
                        ["wasKiosk"] = false,
                        ["seller"] = 173,
                        ["timestamp"] = 1633122320,
                        ["quant"] = 1,
                        ["id"] = "1691121717",
                        ["itemLink"] = 1062,
                    },
                    [5] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 158,
                        ["wasKiosk"] = false,
                        ["seller"] = 173,
                        ["timestamp"] = 1633122321,
                        ["quant"] = 1,
                        ["id"] = "1691121723",
                        ["itemLink"] = 1062,
                    },
                    [6] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 1245,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633148140,
                        ["quant"] = 1,
                        ["id"] = "1691375225",
                        ["itemLink"] = 1062,
                    },
                    [7] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 1392,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633199047,
                        ["quant"] = 1,
                        ["id"] = "1691779805",
                        ["itemLink"] = 1062,
                    },
                    [8] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 1826,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633254134,
                        ["quant"] = 1,
                        ["id"] = "1692296917",
                        ["itemLink"] = 1062,
                    },
                    [9] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 1826,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633254135,
                        ["quant"] = 1,
                        ["id"] = "1692296921",
                        ["itemLink"] = 1062,
                    },
                    [10] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 1826,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1633254136,
                        ["quant"] = 1,
                        ["id"] = "1692296923",
                        ["itemLink"] = 1062,
                    },
                    [11] = 
                    {
                        ["price"] = 7640,
                        ["guild"] = 1,
                        ["buyer"] = 1948,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1633284391,
                        ["quant"] = 1,
                        ["id"] = "1692559479",
                        ["itemLink"] = 1062,
                    },
                    [12] = 
                    {
                        ["price"] = 7640,
                        ["guild"] = 1,
                        ["buyer"] = 1948,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1633284394,
                        ["quant"] = 1,
                        ["id"] = "1692559525",
                        ["itemLink"] = 1062,
                    },
                    [13] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 13,
                        ["wasKiosk"] = false,
                        ["seller"] = 673,
                        ["timestamp"] = 1632846786,
                        ["quant"] = 1,
                        ["id"] = "1689116767",
                        ["itemLink"] = 1062,
                    },
                    [14] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 13,
                        ["wasKiosk"] = false,
                        ["seller"] = 173,
                        ["timestamp"] = 1632846788,
                        ["quant"] = 1,
                        ["id"] = "1689116781",
                        ["itemLink"] = 1062,
                    },
                    [15] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 13,
                        ["wasKiosk"] = false,
                        ["seller"] = 673,
                        ["timestamp"] = 1632848409,
                        ["quant"] = 1,
                        ["id"] = "1689131371",
                        ["itemLink"] = 1062,
                    },
                    [16] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 47,
                        ["wasKiosk"] = false,
                        ["seller"] = 173,
                        ["timestamp"] = 1632873183,
                        ["quant"] = 1,
                        ["id"] = "1689324833",
                        ["itemLink"] = 1062,
                    },
                    [17] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 47,
                        ["wasKiosk"] = false,
                        ["seller"] = 173,
                        ["timestamp"] = 1632873185,
                        ["quant"] = 1,
                        ["id"] = "1689324859",
                        ["itemLink"] = 1062,
                    },
                    [18] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 672,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632883640,
                        ["quant"] = 1,
                        ["id"] = "1689435011",
                        ["itemLink"] = 1062,
                    },
                    [19] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 672,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632883642,
                        ["quant"] = 1,
                        ["id"] = "1689435027",
                        ["itemLink"] = 1062,
                    },
                    [20] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 2600,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632953107,
                        ["quant"] = 1,
                        ["id"] = "1689902271",
                        ["itemLink"] = 1062,
                    },
                    [21] = 
                    {
                        ["price"] = 7200,
                        ["guild"] = 1,
                        ["buyer"] = 2600,
                        ["wasKiosk"] = true,
                        ["seller"] = 569,
                        ["timestamp"] = 1632953109,
                        ["quant"] = 1,
                        ["id"] = "1689902307",
                        ["itemLink"] = 1062,
                    },
                    [22] = 
                    {
                        ["price"] = 7200,
                        ["guild"] = 1,
                        ["buyer"] = 2600,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632953111,
                        ["quant"] = 1,
                        ["id"] = "1689902343",
                        ["itemLink"] = 1062,
                    },
                    [23] = 
                    {
                        ["price"] = 7200,
                        ["guild"] = 1,
                        ["buyer"] = 2600,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632953120,
                        ["quant"] = 1,
                        ["id"] = "1689902387",
                        ["itemLink"] = 1062,
                    },
                },
                ["totalCount"] = 23,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous jewelry glyph",
            },
        },
        [166973] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 90: Thorn Legion Axes",
                ["oldestTime"] = 1633296455,
                ["wasAltered"] = true,
                ["newestTime"] = 1633296455,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 2021,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633296455,
                        ["quant"] = 1,
                        ["id"] = "1692705603",
                        ["itemLink"] = 2882,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [151617] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Northern Elsweyr Treasure Map V",
                ["oldestTime"] = 1633149339,
                ["wasAltered"] = true,
                ["newestTime"] = 1633149339,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1250,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633149339,
                        ["quant"] = 1,
                        ["id"] = "1691385171",
                        ["itemLink"] = 1702,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [45634] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Rislav's Righteous Red Kvass",
                ["oldestTime"] = 1632844347,
                ["wasAltered"] = true,
                ["newestTime"] = 1632844347,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 603,
                        ["timestamp"] = 1632844347,
                        ["quant"] = 1,
                        ["id"] = "1689094041",
                        ["itemLink"] = 3186,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [117827] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_str_varinthicounterstraight001.dds",
                ["itemDesc"] = "Redguard Counter, Bar Island",
                ["oldestTime"] = 1632873025,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294648,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 2011,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633294648,
                        ["quant"] = 1,
                        ["id"] = "1692685637",
                        ["itemLink"] = 2867,
                    },
                    [2] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 2307,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632873025,
                        ["quant"] = 1,
                        ["id"] = "1689323795",
                        ["itemLink"] = 2867,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [171589] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 99: Waking Flame Legs",
                ["oldestTime"] = 1632981897,
                ["wasAltered"] = true,
                ["newestTime"] = 1632981897,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 199999,
                        ["guild"] = 1,
                        ["buyer"] = 282,
                        ["wasKiosk"] = true,
                        ["seller"] = 283,
                        ["timestamp"] = 1632981897,
                        ["quant"] = 1,
                        ["id"] = "1690141131",
                        ["itemLink"] = 292,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [175942] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Leyawiin Carpet, Large Carmine Octad",
                ["oldestTime"] = 1632857079,
                ["wasAltered"] = true,
                ["newestTime"] = 1632857079,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 2240,
                        ["wasKiosk"] = true,
                        ["seller"] = 100,
                        ["timestamp"] = 1632857079,
                        ["quant"] = 1,
                        ["id"] = "1689206571",
                        ["itemLink"] = 3276,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45641] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Melon-Radish Salad",
                ["oldestTime"] = 1632839870,
                ["wasAltered"] = true,
                ["newestTime"] = 1633306747,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633306747,
                        ["quant"] = 1,
                        ["id"] = "1692807041",
                        ["itemLink"] = 2948,
                    },
                    [2] = 
                    {
                        ["price"] = 69,
                        ["guild"] = 1,
                        ["buyer"] = 2174,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1632839870,
                        ["quant"] = 1,
                        ["id"] = "1689059485",
                        ["itemLink"] = 2948,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [88140] = 
        {
            ["50:16:4:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_heavy_chest_a.dds",
                ["itemDesc"] = "Alessian Cuirass",
                ["oldestTime"] = 1633052740,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052740,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 718,
                        ["wasKiosk"] = true,
                        ["seller"] = 71,
                        ["timestamp"] = 1633052740,
                        ["quant"] = 1,
                        ["id"] = "1690632515",
                        ["itemLink"] = 910,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set alessian order chest training",
            },
        },
        [45646] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Colovian Roast Turkey",
                ["oldestTime"] = 1632520200,
                ["wasAltered"] = true,
                ["newestTime"] = 1632520200,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 2,
                        ["buyer"] = 114,
                        ["wasKiosk"] = false,
                        ["seller"] = 117,
                        ["timestamp"] = 1632520200,
                        ["quant"] = 3,
                        ["id"] = "1686355103",
                        ["itemLink"] = 92,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [23119] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_wood_base_yew_r1.dds",
                ["itemDesc"] = "Rough Yew",
                ["oldestTime"] = 1632884698,
                ["wasAltered"] = true,
                ["newestTime"] = 1632884699,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5072,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 244,
                        ["timestamp"] = 1632884698,
                        ["quant"] = 200,
                        ["id"] = "1689448449",
                        ["itemLink"] = 3499,
                    },
                    [2] = 
                    {
                        ["price"] = 5072,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 244,
                        ["timestamp"] = 1632884699,
                        ["quant"] = 200,
                        ["id"] = "1689448459",
                        ["itemLink"] = 3499,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [160592] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_antiquities_nord.dds",
                ["itemDesc"] = "Etched Corundum",
                ["oldestTime"] = 1632913264,
                ["wasAltered"] = true,
                ["newestTime"] = 1633179775,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 387,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633179775,
                        ["quant"] = 1,
                        ["id"] = "1691583931",
                        ["itemLink"] = 1920,
                    },
                    [2] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2466,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632913264,
                        ["quant"] = 1,
                        ["id"] = "1689613465",
                        ["itemLink"] = 1920,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [23126] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_cloth_base_spidersilk_r2.dds",
                ["itemDesc"] = "Spidersilk",
                ["oldestTime"] = 1632769470,
                ["wasAltered"] = true,
                ["newestTime"] = 1632987738,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1150,
                        ["guild"] = 2,
                        ["buyer"] = 124,
                        ["wasKiosk"] = false,
                        ["seller"] = 125,
                        ["timestamp"] = 1632769470,
                        ["quant"] = 100,
                        ["id"] = "1688524861",
                        ["itemLink"] = 118,
                    },
                    [2] = 
                    {
                        ["price"] = 175,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 333,
                        ["timestamp"] = 1632987738,
                        ["quant"] = 10,
                        ["id"] = "1690172941",
                        ["itemLink"] = 118,
                    },
                    [3] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2560,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1632944381,
                        ["quant"] = 20,
                        ["id"] = "1689830709",
                        ["itemLink"] = 118,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [10327] = 
        {
            ["50:16:2:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_1haxe_d.dds",
                ["itemDesc"] = "Wispcutter",
                ["oldestTime"] = 1632835701,
                ["wasAltered"] = true,
                ["newestTime"] = 1632835701,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 2153,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1632835701,
                        ["quant"] = 1,
                        ["id"] = "1689032319",
                        ["itemLink"] = 3100,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set swamp raider axe one-handed powered",
            },
        },
        [45146] = 
        {
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_medium_chest_d.dds",
                ["itemDesc"] = "Rubedo Leather Jack of Health",
                ["oldestTime"] = 1633023015,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023015,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633023015,
                        ["quant"] = 1,
                        ["id"] = "1690390747",
                        ["itemLink"] = 638,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel chest well-fitted",
            },
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_medium_chest_d.dds",
                ["itemDesc"] = "Rubedo Leather Jack of Stamina",
                ["oldestTime"] = 1633023017,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023024,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 420,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1633023017,
                        ["quant"] = 1,
                        ["id"] = "1690390789",
                        ["itemLink"] = 641,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1633023024,
                        ["quant"] = 1,
                        ["id"] = "1690390867",
                        ["itemLink"] = 648,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior medium apparel chest well-fitted",
            },
        },
        [117851] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_inc_glassbottle001.dds",
                ["itemDesc"] = "Redguard Decanter, Glass",
                ["oldestTime"] = 1632824817,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294740,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9098,
                        ["guild"] = 1,
                        ["buyer"] = 2011,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1633294740,
                        ["quant"] = 1,
                        ["id"] = "1692687019",
                        ["itemLink"] = 2872,
                    },
                    [2] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 2114,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632824817,
                        ["quant"] = 1,
                        ["id"] = "1688963267",
                        ["itemLink"] = 2872,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings hearth",
            },
        },
        [4447] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_leather_base_boiled_leather_r3.dds",
                ["itemDesc"] = "Hide",
                ["oldestTime"] = 1632714083,
                ["wasAltered"] = true,
                ["newestTime"] = 1632714083,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 2,
                        ["buyer"] = 129,
                        ["wasKiosk"] = false,
                        ["seller"] = 125,
                        ["timestamp"] = 1632714083,
                        ["quant"] = 200,
                        ["id"] = "1688085791",
                        ["itemLink"] = 107,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [147302] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Prophet's Sandals",
                ["oldestTime"] = 1633196027,
                ["wasAltered"] = true,
                ["newestTime"] = 1633196027,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 995,
                        ["guild"] = 1,
                        ["buyer"] = 1454,
                        ["wasKiosk"] = true,
                        ["seller"] = 322,
                        ["timestamp"] = 1633196027,
                        ["quant"] = 1,
                        ["id"] = "1691750677",
                        ["itemLink"] = 2147,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [171881] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 103: Black Fin Legion Boots",
                ["oldestTime"] = 1633050355,
                ["wasAltered"] = true,
                ["newestTime"] = 1633126646,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 688,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1633050355,
                        ["quant"] = 1,
                        ["id"] = "1690608877",
                        ["itemLink"] = 889,
                    },
                    [2] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 353,
                        ["timestamp"] = 1633125353,
                        ["quant"] = 1,
                        ["id"] = "1691145451",
                        ["itemLink"] = 889,
                    },
                    [3] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 1089,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633126646,
                        ["quant"] = 1,
                        ["id"] = "1691155475",
                        ["itemLink"] = 889,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [160618] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 88: Ancestral Orc Helmets",
                ["oldestTime"] = 1632927107,
                ["wasAltered"] = true,
                ["newestTime"] = 1632927107,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 2505,
                        ["wasKiosk"] = true,
                        ["seller"] = 269,
                        ["timestamp"] = 1632927107,
                        ["quant"] = 1,
                        ["id"] = "1689701449",
                        ["itemLink"] = 3689,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [134763] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 58: Fang Lair Helmets",
                ["oldestTime"] = 1633052134,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052134,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12529,
                        ["guild"] = 1,
                        ["buyer"] = 242,
                        ["wasKiosk"] = false,
                        ["seller"] = 712,
                        ["timestamp"] = 1633052134,
                        ["quant"] = 1,
                        ["id"] = "1690627345",
                        ["itemLink"] = 898,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [43628] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Auridon Treasure Map IV",
                ["oldestTime"] = 1632769512,
                ["wasAltered"] = true,
                ["newestTime"] = 1632769512,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 2,
                        ["buyer"] = 124,
                        ["wasKiosk"] = false,
                        ["seller"] = 111,
                        ["timestamp"] = 1632769512,
                        ["quant"] = 1,
                        ["id"] = "1688525049",
                        ["itemLink"] = 124,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [43630] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Auridon Treasure Map VI",
                ["oldestTime"] = 1632858414,
                ["wasAltered"] = true,
                ["newestTime"] = 1632858414,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 499,
                        ["guild"] = 1,
                        ["buyer"] = 733,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1632858414,
                        ["quant"] = 1,
                        ["id"] = "1689218547",
                        ["itemLink"] = 3291,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [95343] = 
        {
            ["50:16:2:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_staff_a.dds",
                ["itemDesc"] = "Restoration Staff of the Fire",
                ["oldestTime"] = 1632921815,
                ["wasAltered"] = true,
                ["newestTime"] = 1632921815,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2491,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1632921815,
                        ["quant"] = 1,
                        ["id"] = "1689663269",
                        ["itemLink"] = 3657,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set way of fire healing staff two-handed defending",
            },
        },
        [160624] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 88: Ancestral Orc Swords",
                ["oldestTime"] = 1633055093,
                ["wasAltered"] = true,
                ["newestTime"] = 1633055093,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5772,
                        ["guild"] = 1,
                        ["buyer"] = 745,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633055093,
                        ["quant"] = 1,
                        ["id"] = "1690655399",
                        ["itemLink"] = 945,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [129652] = 
        {
            ["50:16:3:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_1hsword_a.dds",
                ["itemDesc"] = "Sword of the Pariah",
                ["oldestTime"] = 1633069369,
                ["wasAltered"] = true,
                ["newestTime"] = 1633069369,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 304,
                        ["wasKiosk"] = true,
                        ["seller"] = 577,
                        ["timestamp"] = 1633069369,
                        ["quant"] = 1,
                        ["id"] = "1690774123",
                        ["itemLink"] = 1080,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set mark of the pariah sword one-handed sharpened",
            },
        },
        [43639] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Greenshade Treasure Map III",
                ["oldestTime"] = 1633182527,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182527,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 389,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182527,
                        ["quant"] = 1,
                        ["id"] = "1691608279",
                        ["itemLink"] = 1960,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [68473] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_snowreach_medium_legs_a.dds",
                ["itemDesc"] = "Briarheart Guards",
                ["oldestTime"] = 1633023042,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023042,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633023042,
                        ["quant"] = 1,
                        ["id"] = "1690390999",
                        ["itemLink"] = 666,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set briarheart legs well-fitted",
            },
        },
        [171900] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 101: Ivory Brigade Chests",
                ["oldestTime"] = 1632873256,
                ["wasAltered"] = true,
                ["newestTime"] = 1633226677,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 602,
                        ["wasKiosk"] = true,
                        ["seller"] = 604,
                        ["timestamp"] = 1633036122,
                        ["quant"] = 1,
                        ["id"] = "1690484825",
                        ["itemLink"] = 772,
                    },
                    [2] = 
                    {
                        ["price"] = 23000,
                        ["guild"] = 1,
                        ["buyer"] = 1654,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633226677,
                        ["quant"] = 1,
                        ["id"] = "1692081953",
                        ["itemLink"] = 772,
                    },
                    [3] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 2309,
                        ["wasKiosk"] = true,
                        ["seller"] = 1899,
                        ["timestamp"] = 1632873256,
                        ["quant"] = 1,
                        ["id"] = "1689325443",
                        ["itemLink"] = 772,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [74114] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_abahswatch_2hhammer_a.dds",
                ["itemDesc"] = "Maul of Fury",
                ["oldestTime"] = 1633270952,
                ["wasAltered"] = true,
                ["newestTime"] = 1633270952,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 1420,
                        ["wasKiosk"] = true,
                        ["seller"] = 1201,
                        ["timestamp"] = 1633270952,
                        ["quant"] = 1,
                        ["id"] = "1692415927",
                        ["itemLink"] = 2669,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set warrior's fury mace two-handed sharpened",
            },
        },
        [68230] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Velothi View Vintage Malbec",
                ["oldestTime"] = 1633185105,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185105,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633185105,
                        ["quant"] = 1,
                        ["id"] = "1691629995",
                        ["itemLink"] = 1985,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [171911] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_ivory_brigade.dds",
                ["itemDesc"] = "Ivory Brigade Clasp",
                ["oldestTime"] = 1632829506,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297221,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 26990,
                        ["guild"] = 1,
                        ["buyer"] = 574,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633032687,
                        ["quant"] = 4,
                        ["id"] = "1690462309",
                        ["itemLink"] = 745,
                    },
                    [2] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 574,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633032690,
                        ["quant"] = 1,
                        ["id"] = "1690462323",
                        ["itemLink"] = 745,
                    },
                    [3] = 
                    {
                        ["price"] = 36000,
                        ["guild"] = 1,
                        ["buyer"] = 574,
                        ["wasKiosk"] = true,
                        ["seller"] = 539,
                        ["timestamp"] = 1633032693,
                        ["quant"] = 5,
                        ["id"] = "1690462337",
                        ["itemLink"] = 745,
                    },
                    [4] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 741,
                        ["wasKiosk"] = true,
                        ["seller"] = 732,
                        ["timestamp"] = 1633054691,
                        ["quant"] = 5,
                        ["id"] = "1690651705",
                        ["itemLink"] = 745,
                    },
                    [5] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 741,
                        ["wasKiosk"] = true,
                        ["seller"] = 732,
                        ["timestamp"] = 1633054692,
                        ["quant"] = 5,
                        ["id"] = "1690651715",
                        ["itemLink"] = 745,
                    },
                    [6] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 798,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633062504,
                        ["quant"] = 4,
                        ["id"] = "1690729601",
                        ["itemLink"] = 745,
                    },
                    [7] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 798,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633062509,
                        ["quant"] = 1,
                        ["id"] = "1690729637",
                        ["itemLink"] = 745,
                    },
                    [8] = 
                    {
                        ["price"] = 12800,
                        ["guild"] = 1,
                        ["buyer"] = 835,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633068991,
                        ["quant"] = 2,
                        ["id"] = "1690772777",
                        ["itemLink"] = 745,
                    },
                    [9] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 935,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633097909,
                        ["quant"] = 2,
                        ["id"] = "1690942579",
                        ["itemLink"] = 745,
                    },
                    [10] = 
                    {
                        ["price"] = 38400,
                        ["guild"] = 1,
                        ["buyer"] = 935,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633097941,
                        ["quant"] = 6,
                        ["id"] = "1690942683",
                        ["itemLink"] = 745,
                    },
                    [11] = 
                    {
                        ["price"] = 6990,
                        ["guild"] = 1,
                        ["buyer"] = 17,
                        ["wasKiosk"] = false,
                        ["seller"] = 333,
                        ["timestamp"] = 1633120511,
                        ["quant"] = 1,
                        ["id"] = "1691108305",
                        ["itemLink"] = 745,
                    },
                    [12] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1317,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633164565,
                        ["quant"] = 7,
                        ["id"] = "1691493811",
                        ["itemLink"] = 745,
                    },
                    [13] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 62,
                        ["timestamp"] = 1633185373,
                        ["quant"] = 5,
                        ["id"] = "1691633279",
                        ["itemLink"] = 745,
                    },
                    [14] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 62,
                        ["timestamp"] = 1633185391,
                        ["quant"] = 1,
                        ["id"] = "1691633613",
                        ["itemLink"] = 745,
                    },
                    [15] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 1415,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633190300,
                        ["quant"] = 3,
                        ["id"] = "1691691375",
                        ["itemLink"] = 745,
                    },
                    [16] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1415,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633190301,
                        ["quant"] = 2,
                        ["id"] = "1691691389",
                        ["itemLink"] = 745,
                    },
                    [17] = 
                    {
                        ["price"] = 23200,
                        ["guild"] = 1,
                        ["buyer"] = 1519,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633205004,
                        ["quant"] = 4,
                        ["id"] = "1691842397",
                        ["itemLink"] = 745,
                    },
                    [18] = 
                    {
                        ["price"] = 62000,
                        ["guild"] = 1,
                        ["buyer"] = 574,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633205513,
                        ["quant"] = 10,
                        ["id"] = "1691847841",
                        ["itemLink"] = 745,
                    },
                    [19] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 574,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633205515,
                        ["quant"] = 2,
                        ["id"] = "1691847851",
                        ["itemLink"] = 745,
                    },
                    [20] = 
                    {
                        ["price"] = 14775,
                        ["guild"] = 1,
                        ["buyer"] = 73,
                        ["wasKiosk"] = false,
                        ["seller"] = 333,
                        ["timestamp"] = 1633219284,
                        ["quant"] = 2,
                        ["id"] = "1692005315",
                        ["itemLink"] = 745,
                    },
                    [21] = 
                    {
                        ["price"] = 7100,
                        ["guild"] = 1,
                        ["buyer"] = 73,
                        ["wasKiosk"] = false,
                        ["seller"] = 647,
                        ["timestamp"] = 1633219285,
                        ["quant"] = 1,
                        ["id"] = "1692005325",
                        ["itemLink"] = 745,
                    },
                    [22] = 
                    {
                        ["price"] = 7100,
                        ["guild"] = 1,
                        ["buyer"] = 73,
                        ["wasKiosk"] = false,
                        ["seller"] = 647,
                        ["timestamp"] = 1633219286,
                        ["quant"] = 1,
                        ["id"] = "1692005335",
                        ["itemLink"] = 745,
                    },
                    [23] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 73,
                        ["wasKiosk"] = false,
                        ["seller"] = 647,
                        ["timestamp"] = 1633219287,
                        ["quant"] = 2,
                        ["id"] = "1692005343",
                        ["itemLink"] = 745,
                    },
                    [24] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 73,
                        ["wasKiosk"] = false,
                        ["seller"] = 647,
                        ["timestamp"] = 1633219288,
                        ["quant"] = 2,
                        ["id"] = "1692005351",
                        ["itemLink"] = 745,
                    },
                    [25] = 
                    {
                        ["price"] = 216562,
                        ["guild"] = 1,
                        ["buyer"] = 1776,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633241022,
                        ["quant"] = 38,
                        ["id"] = "1692204541",
                        ["itemLink"] = 745,
                    },
                    [26] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1838,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633261199,
                        ["quant"] = 1,
                        ["id"] = "1692331647",
                        ["itemLink"] = 745,
                    },
                    [27] = 
                    {
                        ["price"] = 43000,
                        ["guild"] = 1,
                        ["buyer"] = 1838,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633261200,
                        ["quant"] = 8,
                        ["id"] = "1692331653",
                        ["itemLink"] = 745,
                    },
                    [28] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 1838,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633261202,
                        ["quant"] = 4,
                        ["id"] = "1692331659",
                        ["itemLink"] = 745,
                    },
                    [29] = 
                    {
                        ["price"] = 34000,
                        ["guild"] = 1,
                        ["buyer"] = 1838,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633261204,
                        ["quant"] = 6,
                        ["id"] = "1692331663",
                        ["itemLink"] = 745,
                    },
                    [30] = 
                    {
                        ["price"] = 22796,
                        ["guild"] = 1,
                        ["buyer"] = 1838,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633261206,
                        ["quant"] = 4,
                        ["id"] = "1692331667",
                        ["itemLink"] = 745,
                    },
                    [31] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1838,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633261316,
                        ["quant"] = 10,
                        ["id"] = "1692332609",
                        ["itemLink"] = 745,
                    },
                    [32] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1838,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633261318,
                        ["quant"] = 10,
                        ["id"] = "1692332619",
                        ["itemLink"] = 745,
                    },
                    [33] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1838,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633261319,
                        ["quant"] = 10,
                        ["id"] = "1692332633",
                        ["itemLink"] = 745,
                    },
                    [34] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1838,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633261321,
                        ["quant"] = 10,
                        ["id"] = "1692332645",
                        ["itemLink"] = 745,
                    },
                    [35] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1838,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633261323,
                        ["quant"] = 10,
                        ["id"] = "1692332665",
                        ["itemLink"] = 745,
                    },
                    [36] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1838,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633261324,
                        ["quant"] = 10,
                        ["id"] = "1692332689",
                        ["itemLink"] = 745,
                    },
                    [37] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1838,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633261326,
                        ["quant"] = 10,
                        ["id"] = "1692332709",
                        ["itemLink"] = 745,
                    },
                    [38] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1838,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633261328,
                        ["quant"] = 10,
                        ["id"] = "1692332735",
                        ["itemLink"] = 745,
                    },
                    [39] = 
                    {
                        ["price"] = 81000,
                        ["guild"] = 1,
                        ["buyer"] = 1796,
                        ["wasKiosk"] = true,
                        ["seller"] = 1128,
                        ["timestamp"] = 1633292406,
                        ["quant"] = 15,
                        ["id"] = "1692656393",
                        ["itemLink"] = 745,
                    },
                    [40] = 
                    {
                        ["price"] = 84500,
                        ["guild"] = 1,
                        ["buyer"] = 1796,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633292410,
                        ["quant"] = 13,
                        ["id"] = "1692656455",
                        ["itemLink"] = 745,
                    },
                    [41] = 
                    {
                        ["price"] = 190000,
                        ["guild"] = 1,
                        ["buyer"] = 1796,
                        ["wasKiosk"] = true,
                        ["seller"] = 33,
                        ["timestamp"] = 1633292424,
                        ["quant"] = 31,
                        ["id"] = "1692656575",
                        ["itemLink"] = 745,
                    },
                    [42] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 17,
                        ["wasKiosk"] = false,
                        ["seller"] = 62,
                        ["timestamp"] = 1633297216,
                        ["quant"] = 2,
                        ["id"] = "1692712703",
                        ["itemLink"] = 745,
                    },
                    [43] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 17,
                        ["wasKiosk"] = false,
                        ["seller"] = 491,
                        ["timestamp"] = 1633297219,
                        ["quant"] = 5,
                        ["id"] = "1692712727",
                        ["itemLink"] = 745,
                    },
                    [44] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 17,
                        ["wasKiosk"] = false,
                        ["seller"] = 491,
                        ["timestamp"] = 1633297221,
                        ["quant"] = 5,
                        ["id"] = "1692712751",
                        ["itemLink"] = 745,
                    },
                    [45] = 
                    {
                        ["price"] = 85709,
                        ["guild"] = 1,
                        ["buyer"] = 1838,
                        ["wasKiosk"] = true,
                        ["seller"] = 2123,
                        ["timestamp"] = 1632829506,
                        ["quant"] = 10,
                        ["id"] = "1688995835",
                        ["itemLink"] = 745,
                    },
                    [46] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1838,
                        ["wasKiosk"] = true,
                        ["seller"] = 224,
                        ["timestamp"] = 1632829507,
                        ["quant"] = 5,
                        ["id"] = "1688995839",
                        ["itemLink"] = 745,
                    },
                    [47] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1838,
                        ["wasKiosk"] = true,
                        ["seller"] = 224,
                        ["timestamp"] = 1632829509,
                        ["quant"] = 5,
                        ["id"] = "1688995845",
                        ["itemLink"] = 745,
                    },
                    [48] = 
                    {
                        ["price"] = 139999,
                        ["guild"] = 1,
                        ["buyer"] = 2469,
                        ["wasKiosk"] = true,
                        ["seller"] = 277,
                        ["timestamp"] = 1632912622,
                        ["quant"] = 10,
                        ["id"] = "1689610769",
                        ["itemLink"] = 745,
                    },
                    [49] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 2469,
                        ["wasKiosk"] = true,
                        ["seller"] = 224,
                        ["timestamp"] = 1632912626,
                        ["quant"] = 5,
                        ["id"] = "1689610789",
                        ["itemLink"] = 745,
                    },
                    [50] = 
                    {
                        ["price"] = 22500,
                        ["guild"] = 1,
                        ["buyer"] = 2549,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632941468,
                        ["quant"] = 3,
                        ["id"] = "1689805407",
                        ["itemLink"] = 745,
                    },
                },
                ["totalCount"] = 50,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [139401] = 
        {
            ["50:15:1:31:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Platinum Ring",
                ["oldestTime"] = 1633124386,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311273,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 8,
                        ["wasKiosk"] = false,
                        ["seller"] = 9,
                        ["timestamp"] = 1633311273,
                        ["quant"] = 1,
                        ["id"] = "1692863391",
                        ["itemLink"] = 5,
                    },
                    [2] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1075,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633124386,
                        ["quant"] = 1,
                        ["id"] = "1691137451",
                        ["itemLink"] = 5,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp150 white normal jewelry apparel ring bloodthirsty",
            },
        },
        [134538] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Clockwork Illuminator, Capsule Tower",
                ["oldestTime"] = 1632952207,
                ["wasAltered"] = true,
                ["newestTime"] = 1632952207,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 249000,
                        ["guild"] = 1,
                        ["buyer"] = 2594,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632952207,
                        ["quant"] = 1,
                        ["id"] = "1689893899",
                        ["itemLink"] = 3847,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [142219] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 70: Elder Argonian Axes",
                ["oldestTime"] = 1632915188,
                ["wasAltered"] = true,
                ["newestTime"] = 1632915188,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 2474,
                        ["wasKiosk"] = true,
                        ["seller"] = 2475,
                        ["timestamp"] = 1632915188,
                        ["quant"] = 1,
                        ["id"] = "1689624609",
                        ["itemLink"] = 3640,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [73868] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 31: Skinchanger Swords",
                ["oldestTime"] = 1633205016,
                ["wasAltered"] = true,
                ["newestTime"] = 1633205016,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 698,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1633205016,
                        ["quant"] = 1,
                        ["id"] = "1691842507",
                        ["itemLink"] = 2242,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [139661] = 
        {
            ["1:0:4:28:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Exemplary Swift Necklace",
                ["oldestTime"] = 1632838323,
                ["wasAltered"] = true,
                ["newestTime"] = 1633306739,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 204,
                        ["wasKiosk"] = true,
                        ["seller"] = 205,
                        ["timestamp"] = 1632974566,
                        ["quant"] = 1,
                        ["id"] = "1690093343",
                        ["itemLink"] = 216,
                    },
                    [2] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 524,
                        ["wasKiosk"] = true,
                        ["seller"] = 163,
                        ["timestamp"] = 1633022863,
                        ["quant"] = 1,
                        ["id"] = "1690389825",
                        ["itemLink"] = 216,
                    },
                    [3] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1309,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633161279,
                        ["quant"] = 1,
                        ["id"] = "1691472875",
                        ["itemLink"] = 216,
                    },
                    [4] = 
                    {
                        ["price"] = 2999,
                        ["guild"] = 1,
                        ["buyer"] = 2072,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633306739,
                        ["quant"] = 1,
                        ["id"] = "1692806969",
                        ["itemLink"] = 216,
                    },
                    [5] = 
                    {
                        ["price"] = 3750,
                        ["guild"] = 1,
                        ["buyer"] = 2096,
                        ["wasKiosk"] = true,
                        ["seller"] = 269,
                        ["timestamp"] = 1632838323,
                        ["quant"] = 1,
                        ["id"] = "1689049859",
                        ["itemLink"] = 216,
                    },
                    [6] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 2382,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632884537,
                        ["quant"] = 1,
                        ["id"] = "1689446679",
                        ["itemLink"] = 216,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 purple epic jewelry apparel neck swift",
            },
        },
        [68495] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_snowreach_medium_legs_a.dds",
                ["itemDesc"] = "Briarheart Guards",
                ["oldestTime"] = 1633121101,
                ["wasAltered"] = true,
                ["newestTime"] = 1633121101,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11995,
                        ["guild"] = 1,
                        ["buyer"] = 1052,
                        ["wasKiosk"] = true,
                        ["seller"] = 322,
                        ["timestamp"] = 1633121101,
                        ["quant"] = 1,
                        ["id"] = "1691111839",
                        ["itemLink"] = 1434,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set briarheart legs divines",
            },
        },
        [170130] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Style Page: Thurvokun Mask",
                ["oldestTime"] = 1632925352,
                ["wasAltered"] = true,
                ["newestTime"] = 1632925352,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2200000,
                        ["guild"] = 1,
                        ["buyer"] = 2499,
                        ["wasKiosk"] = true,
                        ["seller"] = 1234,
                        ["timestamp"] = 1632925352,
                        ["quant"] = 1,
                        ["id"] = "1689689063",
                        ["itemLink"] = 3685,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [176019] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Plate, Utensils",
                ["oldestTime"] = 1633205947,
                ["wasAltered"] = true,
                ["newestTime"] = 1633244679,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 2,
                        ["buyer"] = 139,
                        ["wasKiosk"] = false,
                        ["seller"] = 117,
                        ["timestamp"] = 1633205947,
                        ["quant"] = 1,
                        ["id"] = "1691854071",
                        ["itemLink"] = 152,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1792,
                        ["wasKiosk"] = true,
                        ["seller"] = 625,
                        ["timestamp"] = 1633244679,
                        ["quant"] = 1,
                        ["id"] = "1692231347",
                        ["itemLink"] = 152,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [43668] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Shadowfen Treasure Map II",
                ["oldestTime"] = 1633047203,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309079,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 682,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633047203,
                        ["quant"] = 1,
                        ["id"] = "1690577477",
                        ["itemLink"] = 869,
                    },
                    [2] = 
                    {
                        ["price"] = 385,
                        ["guild"] = 1,
                        ["buyer"] = 682,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633309079,
                        ["quant"] = 1,
                        ["id"] = "1692837137",
                        ["itemLink"] = 869,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [80791] = 
        {
            ["50:16:3:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_dagger_d.dds",
                ["itemDesc"] = "Elegant Dagger",
                ["oldestTime"] = 1632940770,
                ["wasAltered"] = true,
                ["newestTime"] = 1632940770,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 2544,
                        ["wasKiosk"] = true,
                        ["seller"] = 697,
                        ["timestamp"] = 1632940770,
                        ["quant"] = 1,
                        ["id"] = "1689799825",
                        ["itemLink"] = 3768,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set queen's elegance dagger one-handed sharpened",
            },
        },
        [43673] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Eastmarch Treasure Map I",
                ["oldestTime"] = 1633011635,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310228,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 454,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633011635,
                        ["quant"] = 1,
                        ["id"] = "1690301475",
                        ["itemLink"] = 517,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 994,
                        ["wasKiosk"] = true,
                        ["seller"] = 86,
                        ["timestamp"] = 1633112398,
                        ["quant"] = 1,
                        ["id"] = "1691054997",
                        ["itemLink"] = 517,
                    },
                    [3] = 
                    {
                        ["price"] = 379,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182522,
                        ["quant"] = 1,
                        ["id"] = "1691608239",
                        ["itemLink"] = 517,
                    },
                    [4] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633310228,
                        ["quant"] = 1,
                        ["id"] = "1692851265",
                        ["itemLink"] = 517,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [68507] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_trinimac_light_hands_a.dds",
                ["itemDesc"] = "Gloves of Trinimac's Valor",
                ["oldestTime"] = 1633166765,
                ["wasAltered"] = true,
                ["newestTime"] = 1633166765,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 797,
                        ["wasKiosk"] = true,
                        ["seller"] = 360,
                        ["timestamp"] = 1633166765,
                        ["quant"] = 1,
                        ["id"] = "1691503889",
                        ["itemLink"] = 1867,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set trinimac's valor hands reinforced",
            },
        },
        [76879] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 34: Assassins League Axes",
                ["oldestTime"] = 1632962130,
                ["wasAltered"] = true,
                ["newestTime"] = 1632962130,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 2640,
                        ["wasKiosk"] = true,
                        ["seller"] = 981,
                        ["timestamp"] = 1632962130,
                        ["quant"] = 1,
                        ["id"] = "1689976403",
                        ["itemLink"] = 3932,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [166045] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_u26_components_runestones_063.dds",
                ["itemDesc"] = "Indeko",
                ["oldestTime"] = 1633071616,
                ["wasAltered"] = true,
                ["newestTime"] = 1633194030,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 848,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1633071616,
                        ["quant"] = 5,
                        ["id"] = "1690788401",
                        ["itemLink"] = 1094,
                    },
                    [2] = 
                    {
                        ["price"] = 16528,
                        ["guild"] = 1,
                        ["buyer"] = 848,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633071625,
                        ["quant"] = 5,
                        ["id"] = "1690788429",
                        ["itemLink"] = 1094,
                    },
                    [3] = 
                    {
                        ["price"] = 2290,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 333,
                        ["timestamp"] = 1633194029,
                        ["quant"] = 1,
                        ["id"] = "1691735313",
                        ["itemLink"] = 1094,
                    },
                    [4] = 
                    {
                        ["price"] = 11400,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 76,
                        ["timestamp"] = 1633194030,
                        ["quant"] = 5,
                        ["id"] = "1691735319",
                        ["itemLink"] = 1094,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 white normal materials essence runestone",
            },
        },
        [115769] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Argonian Stool, Woven",
                ["oldestTime"] = 1632958379,
                ["wasAltered"] = true,
                ["newestTime"] = 1632958379,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 1472,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632958379,
                        ["quant"] = 1,
                        ["id"] = "1689946651",
                        ["itemLink"] = 3912,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [69279] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Willpower",
                ["oldestTime"] = 1632885074,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227633,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 521,
                        ["wasKiosk"] = false,
                        ["seller"] = 944,
                        ["timestamp"] = 1633227633,
                        ["quant"] = 1,
                        ["id"] = "1692092281",
                        ["itemLink"] = 2407,
                    },
                    [2] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 2386,
                        ["wasKiosk"] = true,
                        ["seller"] = 171,
                        ["timestamp"] = 1632885074,
                        ["quant"] = 1,
                        ["id"] = "1689454579",
                        ["itemLink"] = 3501,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set willpower ring robust",
            },
        },
        [115946] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Breton Stool, Plain",
                ["oldestTime"] = 1632958374,
                ["wasAltered"] = true,
                ["newestTime"] = 1632958374,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1472,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632958374,
                        ["quant"] = 1,
                        ["id"] = "1689946613",
                        ["itemLink"] = 3911,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [43681] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "The Rift Treasure Map III",
                ["oldestTime"] = 1632520177,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310222,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 2,
                        ["buyer"] = 114,
                        ["wasKiosk"] = false,
                        ["seller"] = 115,
                        ["timestamp"] = 1632520177,
                        ["quant"] = 1,
                        ["id"] = "1686354943",
                        ["itemLink"] = 91,
                    },
                    [2] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 2,
                        ["buyer"] = 124,
                        ["wasKiosk"] = false,
                        ["seller"] = 125,
                        ["timestamp"] = 1632637990,
                        ["quant"] = 1,
                        ["id"] = "1687416871",
                        ["itemLink"] = 91,
                    },
                    [3] = 
                    {
                        ["price"] = 472,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633310222,
                        ["quant"] = 1,
                        ["id"] = "1692851223",
                        ["itemLink"] = 91,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [56994] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Corinthean Roast Kagouti",
                ["oldestTime"] = 1632923739,
                ["wasAltered"] = true,
                ["newestTime"] = 1632923739,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632923739,
                        ["quant"] = 1,
                        ["id"] = "1689677521",
                        ["itemLink"] = 3677,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [56995] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Hammerfell Antelope Stew",
                ["oldestTime"] = 1633155618,
                ["wasAltered"] = true,
                ["newestTime"] = 1633155618,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1450,
                        ["guild"] = 1,
                        ["buyer"] = 1281,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633155618,
                        ["quant"] = 1,
                        ["id"] = "1691436429",
                        ["itemLink"] = 1745,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [125860] = 
        {
            ["50:16:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_light_shirt_a.dds",
                ["itemDesc"] = "Impregnable Armor Jerkin",
                ["oldestTime"] = 1633274673,
                ["wasAltered"] = true,
                ["newestTime"] = 1633274673,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1897,
                        ["wasKiosk"] = true,
                        ["seller"] = 377,
                        ["timestamp"] = 1633274673,
                        ["quant"] = 1,
                        ["id"] = "1692459735",
                        ["itemLink"] = 2697,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set impregnable armor chest impenetrable",
            },
        },
        [43562] = 
        {
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_head_d.dds",
                ["itemDesc"] = "Rubedite Helm",
                ["oldestTime"] = 1632950129,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950129,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 141,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632950129,
                        ["quant"] = 1,
                        ["id"] = "1689875225",
                        ["itemLink"] = 3820,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal heavy apparel head",
            },
        },
        [167846] = 
        {
            ["50:16:4:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_waywardguardianmed_head_a.dds",
                ["itemDesc"] = "Witch-Knight's Helmet",
                ["oldestTime"] = 1633204854,
                ["wasAltered"] = true,
                ["newestTime"] = 1633204854,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1518,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633204854,
                        ["quant"] = 1,
                        ["id"] = "1691840741",
                        ["itemLink"] = 2237,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set witch-knight's defiance head reinforced",
            },
        },
        [56999] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Orcish Bratwurst on Bun",
                ["oldestTime"] = 1633052644,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052644,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633052644,
                        ["quant"] = 1,
                        ["id"] = "1690631413",
                        ["itemLink"] = 905,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [97192] = 
        {
            ["50:16:2:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_hands_d.dds",
                ["itemDesc"] = "Plague Doctor's Gauntlets",
                ["oldestTime"] = 1632939959,
                ["wasAltered"] = true,
                ["newestTime"] = 1632939959,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 2541,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1632939959,
                        ["quant"] = 1,
                        ["id"] = "1689794469",
                        ["itemLink"] = 3766,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set plague doctor hands training",
            },
        },
        [151857] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_run_gazebo001.dds",
                ["itemDesc"] = "Elsweyr Gazebo, Ancient Stone",
                ["oldestTime"] = 1632947104,
                ["wasAltered"] = true,
                ["newestTime"] = 1632947104,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150000,
                        ["guild"] = 1,
                        ["buyer"] = 2569,
                        ["wasKiosk"] = true,
                        ["seller"] = 669,
                        ["timestamp"] = 1632947104,
                        ["quant"] = 1,
                        ["id"] = "1689851505",
                        ["itemLink"] = 3793,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings structures",
            },
        },
        [124664] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/fragment_pet_sentry_head.dds",
                ["itemDesc"] = "Dwarven Theodolite Head",
                ["oldestTime"] = 1632946762,
                ["wasAltered"] = true,
                ["newestTime"] = 1632946762,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2567,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1632946762,
                        ["quant"] = 1,
                        ["id"] = "1689848409",
                        ["itemLink"] = 3791,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [129857] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_trinimac_light_hands_a.dds",
                ["itemDesc"] = "Gloves of Trinimac's Valor",
                ["oldestTime"] = 1632939504,
                ["wasAltered"] = true,
                ["newestTime"] = 1632939504,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2539,
                        ["wasKiosk"] = true,
                        ["seller"] = 237,
                        ["timestamp"] = 1632939504,
                        ["quant"] = 1,
                        ["id"] = "1689791403",
                        ["itemLink"] = 3761,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set trinimac's valor hands impenetrable",
            },
        },
        [97196] = 
        {
            ["50:16:4:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_waist_d.dds",
                ["itemDesc"] = "Plague Doctor's Girdle",
                ["oldestTime"] = 1632940890,
                ["wasAltered"] = true,
                ["newestTime"] = 1632940890,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3700,
                        ["guild"] = 1,
                        ["buyer"] = 2545,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632940890,
                        ["quant"] = 1,
                        ["id"] = "1689800515",
                        ["itemLink"] = 3771,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set plague doctor waist training",
            },
        },
        [86781] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_hands_d.dds",
                ["itemDesc"] = "Gloves of Necropotence",
                ["oldestTime"] = 1633280934,
                ["wasAltered"] = true,
                ["newestTime"] = 1633280934,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15550,
                        ["guild"] = 1,
                        ["buyer"] = 1932,
                        ["wasKiosk"] = true,
                        ["seller"] = 494,
                        ["timestamp"] = 1633280934,
                        ["quant"] = 1,
                        ["id"] = "1692524179",
                        ["itemLink"] = 2735,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set necropotence hands divines",
            },
        },
        [133550] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/container_sealed_polymorph_001.dds",
                ["itemDesc"] = "Runebox: Clockwork Reliquary",
                ["oldestTime"] = 1632844625,
                ["wasAltered"] = true,
                ["newestTime"] = 1632844625,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000000,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1632844625,
                        ["quant"] = 1,
                        ["id"] = "1689096067",
                        ["itemLink"] = 3187,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable container",
            },
        },
        [74931] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_light_legs_a.dds",
                ["itemDesc"] = "Breeches of the Shadow Dancer",
                ["oldestTime"] = 1632924207,
                ["wasAltered"] = true,
                ["newestTime"] = 1632924207,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 2494,
                        ["wasKiosk"] = true,
                        ["seller"] = 655,
                        ["timestamp"] = 1632924207,
                        ["quant"] = 1,
                        ["id"] = "1689681095",
                        ["itemLink"] = 3679,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set shadow dancer's raiment legs impenetrable",
            },
        },
        [171968] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_chest_a.dds",
                ["itemDesc"] = "Jerkin of Frostbite",
                ["oldestTime"] = 1633308725,
                ["wasAltered"] = true,
                ["newestTime"] = 1633308725,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1040,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633308725,
                        ["quant"] = 1,
                        ["id"] = "1692831855",
                        ["itemLink"] = 2963,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite chest infused",
            },
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_chest_a.dds",
                ["itemDesc"] = "Jerkin of Frostbite",
                ["oldestTime"] = 1632925264,
                ["wasAltered"] = true,
                ["newestTime"] = 1632925264,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1775,
                        ["guild"] = 1,
                        ["buyer"] = 1448,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1632925264,
                        ["quant"] = 1,
                        ["id"] = "1689688567",
                        ["itemLink"] = 3683,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set frostbite chest infused",
            },
        },
        [122801] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_telvanni_bow_a.dds",
                ["itemDesc"] = "War Maiden's Bow",
                ["oldestTime"] = 1633056325,
                ["wasAltered"] = true,
                ["newestTime"] = 1633056325,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 755,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633056325,
                        ["quant"] = 1,
                        ["id"] = "1690668481",
                        ["itemLink"] = 954,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set war maiden bow two-handed infused",
            },
        },
        [46023] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Ginseng Tonic",
                ["oldestTime"] = 1633214821,
                ["wasAltered"] = true,
                ["newestTime"] = 1633214821,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 35,
                        ["guild"] = 1,
                        ["buyer"] = 1578,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1633214821,
                        ["quant"] = 1,
                        ["id"] = "1691957359",
                        ["itemLink"] = 2303,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [140467] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 65: Huntsman Chests",
                ["oldestTime"] = 1633191111,
                ["wasAltered"] = true,
                ["newestTime"] = 1633236125,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 80000,
                        ["guild"] = 1,
                        ["buyer"] = 1422,
                        ["wasKiosk"] = true,
                        ["seller"] = 534,
                        ["timestamp"] = 1633191111,
                        ["quant"] = 1,
                        ["id"] = "1691701443",
                        ["itemLink"] = 2108,
                    },
                    [2] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 1733,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633236125,
                        ["quant"] = 1,
                        ["id"] = "1692168485",
                        ["itemLink"] = 2108,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [123216] = 
        {
            ["50:16:4:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_staff_a.dds",
                ["itemDesc"] = "Vanguard's Challenge Inferno Staff",
                ["oldestTime"] = 1632910852,
                ["wasAltered"] = true,
                ["newestTime"] = 1632910852,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1560,
                        ["guild"] = 1,
                        ["buyer"] = 2459,
                        ["wasKiosk"] = true,
                        ["seller"] = 529,
                        ["timestamp"] = 1632910852,
                        ["quant"] = 1,
                        ["id"] = "1689603901",
                        ["itemLink"] = 3606,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set vanguard's challenge flame staff two-handed precise",
            },
        },
        [130297] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_tre_dec_vrdlaureltree_branch002.dds",
                ["itemDesc"] = "Branch, Forked Laurel",
                ["oldestTime"] = 1632895670,
                ["wasAltered"] = true,
                ["newestTime"] = 1632895671,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50,
                        ["guild"] = 1,
                        ["buyer"] = 2432,
                        ["wasKiosk"] = true,
                        ["seller"] = 530,
                        ["timestamp"] = 1632895670,
                        ["quant"] = 1,
                        ["id"] = "1689533153",
                        ["itemLink"] = 3561,
                    },
                    [2] = 
                    {
                        ["price"] = 60,
                        ["guild"] = 1,
                        ["buyer"] = 2432,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1632895671,
                        ["quant"] = 1,
                        ["id"] = "1689533177",
                        ["itemLink"] = 3561,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine furnishings conservatory",
            },
        },
        [139702] = 
        {
            ["50:16:3:31:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Julianos",
                ["oldestTime"] = 1632836224,
                ["wasAltered"] = true,
                ["newestTime"] = 1632886320,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 57499,
                        ["guild"] = 1,
                        ["buyer"] = 2159,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632836224,
                        ["quant"] = 1,
                        ["id"] = "1689035475",
                        ["itemLink"] = 3106,
                    },
                    [2] = 
                    {
                        ["price"] = 57499,
                        ["guild"] = 1,
                        ["buyer"] = 2392,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632886312,
                        ["quant"] = 1,
                        ["id"] = "1689465255",
                        ["itemLink"] = 3106,
                    },
                    [3] = 
                    {
                        ["price"] = 57499,
                        ["guild"] = 1,
                        ["buyer"] = 2392,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632886320,
                        ["quant"] = 1,
                        ["id"] = "1689465319",
                        ["itemLink"] = 3106,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set law of julianos ring bloodthirsty",
            },
        },
        [160556] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 85: Greymoor Swords",
                ["oldestTime"] = 1632889724,
                ["wasAltered"] = true,
                ["newestTime"] = 1632889724,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1770,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632889724,
                        ["quant"] = 1,
                        ["id"] = "1689490909",
                        ["itemLink"] = 3535,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [115781] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Argonian Medallion, Stone",
                ["oldestTime"] = 1632882794,
                ["wasAltered"] = true,
                ["newestTime"] = 1632882794,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4900,
                        ["guild"] = 1,
                        ["buyer"] = 2369,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632882794,
                        ["quant"] = 1,
                        ["id"] = "1689426325",
                        ["itemLink"] = 3481,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [149353] = 
        {
            ["50:16:4:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_pellitine_dagger_a.dds",
                ["itemDesc"] = "Crafty Alfiq's Dagger",
                ["oldestTime"] = 1632877639,
                ["wasAltered"] = true,
                ["newestTime"] = 1632877639,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2337,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632877639,
                        ["quant"] = 1,
                        ["id"] = "1689369347",
                        ["itemLink"] = 3434,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set crafty alfiq dagger one-handed charged",
            },
        },
        [134512] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing2.dds",
                ["itemDesc"] = "Diagram: Clockwork Table, Octagonal",
                ["oldestTime"] = 1632876491,
                ["wasAltered"] = true,
                ["newestTime"] = 1632876491,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 144,
                        ["wasKiosk"] = false,
                        ["seller"] = 105,
                        ["timestamp"] = 1632876491,
                        ["quant"] = 1,
                        ["id"] = "1689357177",
                        ["itemLink"] = 3427,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [137927] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 62: Sapiarch Gloves",
                ["oldestTime"] = 1633075126,
                ["wasAltered"] = true,
                ["newestTime"] = 1633075126,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 862,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633075126,
                        ["quant"] = 1,
                        ["id"] = "1690811339",
                        ["itemLink"] = 1106,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [119278] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing4.dds",
                ["itemDesc"] = "Diagram: Redguard Candelabra, Twisted",
                ["oldestTime"] = 1632873378,
                ["wasAltered"] = true,
                ["newestTime"] = 1632873378,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 1733,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632873378,
                        ["quant"] = 1,
                        ["id"] = "1689325995",
                        ["itemLink"] = 3400,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [175549] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Blackwood Treasure Map III",
                ["oldestTime"] = 1633057623,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293480,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 49990,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 333,
                        ["timestamp"] = 1633057623,
                        ["quant"] = 1,
                        ["id"] = "1690686895",
                        ["itemLink"] = 969,
                    },
                    [2] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 709,
                        ["timestamp"] = 1633057625,
                        ["quant"] = 1,
                        ["id"] = "1690686917",
                        ["itemLink"] = 969,
                    },
                    [3] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 501,
                        ["timestamp"] = 1633057631,
                        ["quant"] = 1,
                        ["id"] = "1690686959",
                        ["itemLink"] = 969,
                    },
                    [4] = 
                    {
                        ["price"] = 64246,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 765,
                        ["timestamp"] = 1633057670,
                        ["quant"] = 1,
                        ["id"] = "1690687283",
                        ["itemLink"] = 969,
                    },
                    [5] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 1023,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633115904,
                        ["quant"] = 1,
                        ["id"] = "1691077887",
                        ["itemLink"] = 969,
                    },
                    [6] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 15,
                        ["wasKiosk"] = false,
                        ["seller"] = 763,
                        ["timestamp"] = 1633142762,
                        ["quant"] = 1,
                        ["id"] = "1691322671",
                        ["itemLink"] = 969,
                    },
                    [7] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 1217,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633143533,
                        ["quant"] = 1,
                        ["id"] = "1691331645",
                        ["itemLink"] = 969,
                    },
                    [8] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 521,
                        ["timestamp"] = 1633156799,
                        ["quant"] = 1,
                        ["id"] = "1691444669",
                        ["itemLink"] = 969,
                    },
                    [9] = 
                    {
                        ["price"] = 33998,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 95,
                        ["timestamp"] = 1633250698,
                        ["quant"] = 1,
                        ["id"] = "1692274993",
                        ["itemLink"] = 969,
                    },
                    [10] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 153,
                        ["timestamp"] = 1633250701,
                        ["quant"] = 1,
                        ["id"] = "1692275021",
                        ["itemLink"] = 969,
                    },
                    [11] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 195,
                        ["timestamp"] = 1633250702,
                        ["quant"] = 1,
                        ["id"] = "1692275031",
                        ["itemLink"] = 969,
                    },
                    [12] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 763,
                        ["timestamp"] = 1633250703,
                        ["quant"] = 1,
                        ["id"] = "1692275037",
                        ["itemLink"] = 969,
                    },
                    [13] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 763,
                        ["timestamp"] = 1633250703,
                        ["quant"] = 1,
                        ["id"] = "1692275045",
                        ["itemLink"] = 969,
                    },
                    [14] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 2000,
                        ["wasKiosk"] = true,
                        ["seller"] = 50,
                        ["timestamp"] = 1633293473,
                        ["quant"] = 1,
                        ["id"] = "1692668907",
                        ["itemLink"] = 969,
                    },
                    [15] = 
                    {
                        ["price"] = 52025,
                        ["guild"] = 1,
                        ["buyer"] = 2000,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633293474,
                        ["quant"] = 1,
                        ["id"] = "1692668929",
                        ["itemLink"] = 969,
                    },
                    [16] = 
                    {
                        ["price"] = 58366,
                        ["guild"] = 1,
                        ["buyer"] = 2000,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633293477,
                        ["quant"] = 1,
                        ["id"] = "1692668953",
                        ["itemLink"] = 969,
                    },
                    [17] = 
                    {
                        ["price"] = 60213,
                        ["guild"] = 1,
                        ["buyer"] = 2000,
                        ["wasKiosk"] = true,
                        ["seller"] = 240,
                        ["timestamp"] = 1633293480,
                        ["quant"] = 1,
                        ["id"] = "1692668959",
                        ["itemLink"] = 969,
                    },
                },
                ["totalCount"] = 17,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [64500] = 
        {
            ["50:10:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_stardew.dds",
                ["itemDesc"] = "Star Dew",
                ["oldestTime"] = 1632861621,
                ["wasAltered"] = true,
                ["newestTime"] = 1632861621,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1632861621,
                        ["quant"] = 200,
                        ["id"] = "1689241903",
                        ["itemLink"] = 3308,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp100 white normal materials potion solvent",
            },
        },
        [46015] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Comberry Chai",
                ["oldestTime"] = 1633052786,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052858,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 375,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 442,
                        ["timestamp"] = 1633052786,
                        ["quant"] = 1,
                        ["id"] = "1690633129",
                        ["itemLink"] = 916,
                    },
                    [2] = 
                    {
                        ["price"] = 1263,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1633052858,
                        ["quant"] = 1,
                        ["id"] = "1690633823",
                        ["itemLink"] = 916,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [45760] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_staff_d.dds",
                ["itemDesc"] = "Faceless Staff",
                ["oldestTime"] = 1633183979,
                ["wasAltered"] = true,
                ["newestTime"] = 1633183979,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 1385,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1633183979,
                        ["quant"] = 1,
                        ["id"] = "1691621497",
                        ["itemLink"] = 1968,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set light of cyrodiil frost staff two-handed charged",
            },
        },
        [28609] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_vendor_fuel_meat_001.dds",
                ["itemDesc"] = "Game",
                ["oldestTime"] = 1632861582,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305852,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1633305852,
                        ["quant"] = 50,
                        ["id"] = "1692798961",
                        ["itemLink"] = 2940,
                    },
                    [2] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1632861582,
                        ["quant"] = 200,
                        ["id"] = "1689241627",
                        ["itemLink"] = 2940,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [147394] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_medium_feet_a.dds",
                ["itemDesc"] = "Deadly Boots",
                ["oldestTime"] = 1632991135,
                ["wasAltered"] = true,
                ["newestTime"] = 1632991135,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 355,
                        ["wasKiosk"] = true,
                        ["seller"] = 356,
                        ["timestamp"] = 1632991135,
                        ["quant"] = 1,
                        ["id"] = "1690192359",
                        ["itemLink"] = 354,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set deadly strike feet impenetrable",
            },
        },
        [45251] = 
        {
            ["50:16:2:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_medium_chest_d.dds",
                ["itemDesc"] = "Rubedo Leather Jack of Health",
                ["oldestTime"] = 1632998579,
                ["wasAltered"] = true,
                ["newestTime"] = 1632998579,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 174,
                        ["guild"] = 1,
                        ["buyer"] = 390,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632998579,
                        ["quant"] = 1,
                        ["id"] = "1690225527",
                        ["itemLink"] = 390,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel chest invigorating",
            },
        },
        [135379] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_medium_chest_a.dds",
                ["itemDesc"] = "Gryphon's Jack",
                ["oldestTime"] = 1632857793,
                ["wasAltered"] = true,
                ["newestTime"] = 1632857793,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1632857793,
                        ["quant"] = 1,
                        ["id"] = "1689212295",
                        ["itemLink"] = 3289,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set gryphon's ferocity chest divines",
            },
        },
        [64709] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/notes_004.dds",
                ["itemDesc"] = "Recipe: Psijic Ambrosia, Fragment VII",
                ["oldestTime"] = 1633220724,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310230,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 499,
                        ["guild"] = 1,
                        ["buyer"] = 285,
                        ["wasKiosk"] = false,
                        ["seller"] = 149,
                        ["timestamp"] = 1633220724,
                        ["quant"] = 1,
                        ["id"] = "1692019365",
                        ["itemLink"] = 2345,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2020,
                        ["wasKiosk"] = true,
                        ["seller"] = 802,
                        ["timestamp"] = 1633295796,
                        ["quant"] = 1,
                        ["id"] = "1692698373",
                        ["itemLink"] = 2345,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 802,
                        ["timestamp"] = 1633310230,
                        ["quant"] = 1,
                        ["id"] = "1692851285",
                        ["itemLink"] = 2345,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [175988] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Leyawiin Basket, Hamper Tall",
                ["oldestTime"] = 1632857084,
                ["wasAltered"] = true,
                ["newestTime"] = 1632857084,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2240,
                        ["wasKiosk"] = true,
                        ["seller"] = 100,
                        ["timestamp"] = 1632857084,
                        ["quant"] = 1,
                        ["id"] = "1689206595",
                        ["itemLink"] = 3277,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [156615] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 81: New Moon Priest Gloves",
                ["oldestTime"] = 1633187453,
                ["wasAltered"] = true,
                ["newestTime"] = 1633187453,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1070,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633187453,
                        ["quant"] = 1,
                        ["id"] = "1691656795",
                        ["itemLink"] = 2079,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [4442] = 
        {
            ["1:0:1:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_jewelry_base_emerald_r2.dds",
                ["itemDesc"] = "Emerald",
                ["oldestTime"] = 1633240451,
                ["wasAltered"] = true,
                ["newestTime"] = 1633240451,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1772,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633240451,
                        ["quant"] = 80,
                        ["id"] = "1692201255",
                        ["itemLink"] = 2533,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials armor trait training",
            },
        },
        [7445] = 
        {
            ["50:16:2:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_dagger_d.dds",
                ["itemDesc"] = "Draws-the-Sap Dagger",
                ["oldestTime"] = 1632848793,
                ["wasAltered"] = true,
                ["newestTime"] = 1632848793,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 2208,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1632848793,
                        ["quant"] = 1,
                        ["id"] = "1689134513",
                        ["itemLink"] = 3227,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set robes of the hist dagger one-handed infused",
            },
        },
        [114890] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_furniture_base_bast_fiber.dds",
                ["itemDesc"] = "Bast",
                ["oldestTime"] = 1632954460,
                ["wasAltered"] = true,
                ["newestTime"] = 1633043908,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2964,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 295,
                        ["timestamp"] = 1633043907,
                        ["quant"] = 114,
                        ["id"] = "1690545585",
                        ["itemLink"] = 841,
                    },
                    [2] = 
                    {
                        ["price"] = 6049,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 449,
                        ["timestamp"] = 1633043908,
                        ["quant"] = 200,
                        ["id"] = "1690545599",
                        ["itemLink"] = 841,
                    },
                    [3] = 
                    {
                        ["price"] = 4186,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 295,
                        ["timestamp"] = 1632954460,
                        ["quant"] = 161,
                        ["id"] = "1689913901",
                        ["itemLink"] = 841,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials furnishing",
            },
        },
        [123103] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_hlaalu_medium_shoulders_a.dds",
                ["itemDesc"] = "Defiler's Arm Cops",
                ["oldestTime"] = 1632845216,
                ["wasAltered"] = true,
                ["newestTime"] = 1632845216,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 2195,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1632845216,
                        ["quant"] = 1,
                        ["id"] = "1689102073",
                        ["itemLink"] = 3190,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set defiler shoulders invigorating",
            },
        },
        [132556] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_cwc_inc_scrollplate001.dds",
                ["itemDesc"] = "Crafting Motif 56: Apostle Gloves",
                ["oldestTime"] = 1632919893,
                ["wasAltered"] = true,
                ["newestTime"] = 1632919893,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9267,
                        ["guild"] = 1,
                        ["buyer"] = 862,
                        ["wasKiosk"] = true,
                        ["seller"] = 547,
                        ["timestamp"] = 1632919893,
                        ["quant"] = 1,
                        ["id"] = "1689650929",
                        ["itemLink"] = 3649,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [165762] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_inc_smallpot004.dds",
                ["itemDesc"] = "Solitude Serving Bowl, Metal",
                ["oldestTime"] = 1632985323,
                ["wasAltered"] = true,
                ["newestTime"] = 1632985323,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 317,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1632985323,
                        ["quant"] = 1,
                        ["id"] = "1690161443",
                        ["itemLink"] = 322,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings hearth",
            },
        },
        [46030] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Blue Road Marathon",
                ["oldestTime"] = 1632975965,
                ["wasAltered"] = true,
                ["newestTime"] = 1632975965,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1050,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1632975965,
                        ["quant"] = 1,
                        ["id"] = "1690102379",
                        ["itemLink"] = 231,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [57039] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Spicy Wyress Wine",
                ["oldestTime"] = 1632923731,
                ["wasAltered"] = true,
                ["newestTime"] = 1632923731,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632923731,
                        ["quant"] = 1,
                        ["id"] = "1689677463",
                        ["itemLink"] = 3676,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [56966] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Dragonstar Radish Kebabs",
                ["oldestTime"] = 1633060728,
                ["wasAltered"] = true,
                ["newestTime"] = 1633060728,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633060728,
                        ["quant"] = 1,
                        ["id"] = "1690716441",
                        ["itemLink"] = 1019,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [130029] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 79: Refabricated Boots",
                ["oldestTime"] = 1633306119,
                ["wasAltered"] = true,
                ["newestTime"] = 1633306119,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 67,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633306119,
                        ["quant"] = 1,
                        ["id"] = "1692801035",
                        ["itemLink"] = 2944,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45967] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Pickled Carrot Slurry",
                ["oldestTime"] = 1633060725,
                ["wasAltered"] = true,
                ["newestTime"] = 1633060725,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633060725,
                        ["quant"] = 1,
                        ["id"] = "1690716425",
                        ["itemLink"] = 1017,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [30163] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_flower_mountain_flower_r1.dds",
                ["itemDesc"] = "Mountain Flower",
                ["oldestTime"] = 1632825599,
                ["wasAltered"] = true,
                ["newestTime"] = 1633234922,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 462,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1633013742,
                        ["quant"] = 25,
                        ["id"] = "1690315035",
                        ["itemLink"] = 528,
                    },
                    [2] = 
                    {
                        ["price"] = 32636,
                        ["guild"] = 1,
                        ["buyer"] = 1242,
                        ["wasKiosk"] = true,
                        ["seller"] = 344,
                        ["timestamp"] = 1633147947,
                        ["quant"] = 199,
                        ["id"] = "1691373447",
                        ["itemLink"] = 528,
                    },
                    [3] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633154449,
                        ["quant"] = 50,
                        ["id"] = "1691427283",
                        ["itemLink"] = 528,
                    },
                    [4] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633234922,
                        ["quant"] = 13,
                        ["id"] = "1692160343",
                        ["itemLink"] = 528,
                    },
                    [5] = 
                    {
                        ["price"] = 35800,
                        ["guild"] = 1,
                        ["buyer"] = 1252,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1632825599,
                        ["quant"] = 200,
                        ["id"] = "1688966929",
                        ["itemLink"] = 528,
                    },
                    [6] = 
                    {
                        ["price"] = 17999,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1632884371,
                        ["quant"] = 100,
                        ["id"] = "1689444387",
                        ["itemLink"] = 528,
                    },
                    [7] = 
                    {
                        ["price"] = 5408,
                        ["guild"] = 1,
                        ["buyer"] = 919,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632911081,
                        ["quant"] = 32,
                        ["id"] = "1689604519",
                        ["itemLink"] = 528,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [69910] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_light_hands_d.dds",
                ["itemDesc"] = "Gloves of Julianos",
                ["oldestTime"] = 1632976057,
                ["wasAltered"] = true,
                ["newestTime"] = 1632976057,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9999,
                        ["guild"] = 1,
                        ["buyer"] = 219,
                        ["wasKiosk"] = true,
                        ["seller"] = 220,
                        ["timestamp"] = 1632976057,
                        ["quant"] = 1,
                        ["id"] = "1690103201",
                        ["itemLink"] = 233,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set law of julianos hands divines",
            },
        },
        [34335] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_bandage_001.dds",
                ["itemDesc"] = "Yerba Mate",
                ["oldestTime"] = 1633305823,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305856,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 725,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1633305823,
                        ["quant"] = 100,
                        ["id"] = "1692798627",
                        ["itemLink"] = 2935,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633305856,
                        ["quant"] = 200,
                        ["id"] = "1692798999",
                        ["itemLink"] = 2935,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [119029] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing2.dds",
                ["itemDesc"] = "Diagram: Orcish Lantern, Hooded",
                ["oldestTime"] = 1633287092,
                ["wasAltered"] = true,
                ["newestTime"] = 1633287092,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 276,
                        ["guild"] = 1,
                        ["buyer"] = 1961,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633287092,
                        ["quant"] = 1,
                        ["id"] = "1692593073",
                        ["itemLink"] = 2762,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [86743] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Necropotence",
                ["oldestTime"] = 1633163917,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163917,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 256,
                        ["timestamp"] = 1633163917,
                        ["quant"] = 1,
                        ["id"] = "1691490355",
                        ["itemLink"] = 1814,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set necropotence ring arcane",
            },
        },
        [69277] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Willpower",
                ["oldestTime"] = 1633063304,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227632,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 801,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633063304,
                        ["quant"] = 1,
                        ["id"] = "1690734493",
                        ["itemLink"] = 1041,
                    },
                    [2] = 
                    {
                        ["price"] = 4050,
                        ["guild"] = 1,
                        ["buyer"] = 306,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1633197315,
                        ["quant"] = 1,
                        ["id"] = "1691762027",
                        ["itemLink"] = 2150,
                    },
                    [3] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 521,
                        ["wasKiosk"] = false,
                        ["seller"] = 944,
                        ["timestamp"] = 1633227632,
                        ["quant"] = 1,
                        ["id"] = "1692092277",
                        ["itemLink"] = 2406,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set willpower ring arcane",
            },
        },
        [116415] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_orc_lsb_wtgorcbanner001.dds",
                ["itemDesc"] = "Orcish Banner, Hammer Fist",
                ["oldestTime"] = 1633295260,
                ["wasAltered"] = true,
                ["newestTime"] = 1633295260,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2572,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1633295260,
                        ["quant"] = 1,
                        ["id"] = "1692692719",
                        ["itemLink"] = 2878,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings parlor",
            },
        },
        [147366] = 
        {
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_medium_feet_a.dds",
                ["itemDesc"] = "Deadly Boots",
                ["oldestTime"] = 1633200875,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200875,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 1038,
                        ["wasKiosk"] = true,
                        ["seller"] = 586,
                        ["timestamp"] = 1633200875,
                        ["quant"] = 1,
                        ["id"] = "1691798523",
                        ["itemLink"] = 2206,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set deadly strike feet infused",
            },
        },
        [126427] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_vrd_fur_telshelvesorganic002.dds",
                ["itemDesc"] = "Telvanni Shelves, Organic",
                ["oldestTime"] = 1633315454,
                ["wasAltered"] = true,
                ["newestTime"] = 1633315454,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 32300,
                        ["guild"] = 1,
                        ["buyer"] = 98,
                        ["wasKiosk"] = true,
                        ["seller"] = 99,
                        ["timestamp"] = 1633315454,
                        ["quant"] = 1,
                        ["id"] = "1692909753",
                        ["itemLink"] = 71,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings library",
            },
        },
        [140508] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 67: Welkynar Shoulders",
                ["oldestTime"] = 1633146935,
                ["wasAltered"] = true,
                ["newestTime"] = 1633222681,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 704,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633146935,
                        ["quant"] = 1,
                        ["id"] = "1691365321",
                        ["itemLink"] = 1666,
                    },
                    [2] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 1621,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1633222670,
                        ["quant"] = 1,
                        ["id"] = "1692039227",
                        ["itemLink"] = 1666,
                    },
                    [3] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 1621,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1633222681,
                        ["quant"] = 1,
                        ["id"] = "1692039365",
                        ["itemLink"] = 1666,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [180701] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_medium_waist_a.dds",
                ["itemDesc"] = "Plaguebreak Belt",
                ["oldestTime"] = 1633140128,
                ["wasAltered"] = true,
                ["newestTime"] = 1633140128,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2222,
                        ["guild"] = 1,
                        ["buyer"] = 1181,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633140128,
                        ["quant"] = 1,
                        ["id"] = "1691291583",
                        ["itemLink"] = 1595,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set plaguebreak waist impenetrable",
            },
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_medium_waist_a.dds",
                ["itemDesc"] = "Plaguebreak Belt",
                ["oldestTime"] = 1632883611,
                ["wasAltered"] = true,
                ["newestTime"] = 1632883611,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 1212,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1632883611,
                        ["quant"] = 1,
                        ["id"] = "1689434591",
                        ["itemLink"] = 3484,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set plaguebreak waist impenetrable",
            },
        },
        [126942] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Hlaalu Bookcase, Orderly",
                ["oldestTime"] = 1633234168,
                ["wasAltered"] = true,
                ["newestTime"] = 1633234168,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 180000,
                        ["guild"] = 1,
                        ["buyer"] = 1720,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633234168,
                        ["quant"] = 1,
                        ["id"] = "1692155251",
                        ["itemLink"] = 2462,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [57055] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Senchal Dancer Tonic",
                ["oldestTime"] = 1633297010,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297010,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 348,
                        ["wasKiosk"] = false,
                        ["seller"] = 107,
                        ["timestamp"] = 1633297010,
                        ["quant"] = 1,
                        ["id"] = "1692711025",
                        ["itemLink"] = 2887,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45280] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_light_head_d.dds",
                ["itemDesc"] = "Ancestor Silk Hat of Health",
                ["oldestTime"] = 1632936824,
                ["wasAltered"] = true,
                ["newestTime"] = 1632936824,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 425,
                        ["guild"] = 1,
                        ["buyer"] = 226,
                        ["wasKiosk"] = false,
                        ["seller"] = 526,
                        ["timestamp"] = 1632936824,
                        ["quant"] = 1,
                        ["id"] = "1689773991",
                        ["itemLink"] = 3742,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel head divines",
            },
        },
        [139641] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Alinor Runner, Royal",
                ["oldestTime"] = 1633270468,
                ["wasAltered"] = true,
                ["newestTime"] = 1633270468,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 95000,
                        ["guild"] = 1,
                        ["buyer"] = 1875,
                        ["wasKiosk"] = true,
                        ["seller"] = 530,
                        ["timestamp"] = 1633270468,
                        ["quant"] = 1,
                        ["id"] = "1692409335",
                        ["itemLink"] = 2666,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [43746] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Clockwork City Treasure Map I",
                ["oldestTime"] = 1633000941,
                ["wasAltered"] = true,
                ["newestTime"] = 1633149342,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 399,
                        ["guild"] = 1,
                        ["buyer"] = 396,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633000941,
                        ["quant"] = 1,
                        ["id"] = "1690238385",
                        ["itemLink"] = 399,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1250,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633149342,
                        ["quant"] = 1,
                        ["id"] = "1691385207",
                        ["itemLink"] = 399,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [147683] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 72: Meridian Axes",
                ["oldestTime"] = 1633054953,
                ["wasAltered"] = true,
                ["newestTime"] = 1633054953,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 743,
                        ["wasKiosk"] = true,
                        ["seller"] = 505,
                        ["timestamp"] = 1633054953,
                        ["quant"] = 1,
                        ["id"] = "1690654211",
                        ["itemLink"] = 943,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [114404] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_alt_inc_wineglass003.dds",
                ["itemDesc"] = "High Elf Goblet, Glass",
                ["oldestTime"] = 1632984843,
                ["wasAltered"] = true,
                ["newestTime"] = 1632984843,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 310,
                        ["wasKiosk"] = true,
                        ["seller"] = 312,
                        ["timestamp"] = 1632984843,
                        ["quant"] = 1,
                        ["id"] = "1690159173",
                        ["itemLink"] = 317,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings hearth",
            },
        },
        [119023] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Orcish Bowl, Rugged",
                ["oldestTime"] = 1633244667,
                ["wasAltered"] = true,
                ["newestTime"] = 1633244667,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50,
                        ["guild"] = 1,
                        ["buyer"] = 1792,
                        ["wasKiosk"] = true,
                        ["seller"] = 33,
                        ["timestamp"] = 1633244667,
                        ["quant"] = 1,
                        ["id"] = "1692231223",
                        ["itemLink"] = 2566,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [69275] = 
        {
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Willpower",
                ["oldestTime"] = 1633012276,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227634,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3428,
                        ["guild"] = 1,
                        ["buyer"] = 458,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633012276,
                        ["quant"] = 1,
                        ["id"] = "1690305643",
                        ["itemLink"] = 527,
                    },
                    [2] = 
                    {
                        ["price"] = 3428,
                        ["guild"] = 1,
                        ["buyer"] = 801,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633063294,
                        ["quant"] = 1,
                        ["id"] = "1690734401",
                        ["itemLink"] = 1038,
                    },
                    [3] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 521,
                        ["wasKiosk"] = false,
                        ["seller"] = 944,
                        ["timestamp"] = 1633227634,
                        ["quant"] = 1,
                        ["id"] = "1692092283",
                        ["itemLink"] = 2408,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set willpower ring healthy",
            },
        },
        [117735] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_inc_rugrunner002.dds",
                ["itemDesc"] = "Redguard Runner, Sun",
                ["oldestTime"] = 1633225304,
                ["wasAltered"] = true,
                ["newestTime"] = 1633225304,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6200,
                        ["guild"] = 1,
                        ["buyer"] = 1642,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633225304,
                        ["quant"] = 1,
                        ["id"] = "1692067195",
                        ["itemLink"] = 2382,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings parlor",
            },
        },
        [117992] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_uni_str_spellcraftingruinwallbrick001.dds",
                ["itemDesc"] = "Rough Block, Stone Section",
                ["oldestTime"] = 1633115757,
                ["wasAltered"] = true,
                ["newestTime"] = 1633115757,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30,
                        ["guild"] = 1,
                        ["buyer"] = 1020,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633115757,
                        ["quant"] = 2,
                        ["id"] = "1691076905",
                        ["itemLink"] = 1395,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal furnishings structures",
            },
        },
        [135145] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_platinum_dust.dds",
                ["itemDesc"] = "Platinum Dust",
                ["oldestTime"] = 1632859221,
                ["wasAltered"] = true,
                ["newestTime"] = 1633312220,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40915,
                        ["guild"] = 1,
                        ["buyer"] = 35,
                        ["wasKiosk"] = false,
                        ["seller"] = 21,
                        ["timestamp"] = 1633312217,
                        ["quant"] = 200,
                        ["id"] = "1692872841",
                        ["itemLink"] = 24,
                    },
                    [2] = 
                    {
                        ["price"] = 40915,
                        ["guild"] = 1,
                        ["buyer"] = 35,
                        ["wasKiosk"] = false,
                        ["seller"] = 21,
                        ["timestamp"] = 1633312220,
                        ["quant"] = 200,
                        ["id"] = "1692872853",
                        ["itemLink"] = 24,
                    },
                    [3] = 
                    {
                        ["price"] = 43500,
                        ["guild"] = 1,
                        ["buyer"] = 143,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1632968932,
                        ["quant"] = 200,
                        ["id"] = "1690045791",
                        ["itemLink"] = 24,
                    },
                    [4] = 
                    {
                        ["price"] = 43500,
                        ["guild"] = 1,
                        ["buyer"] = 143,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1632968933,
                        ["quant"] = 200,
                        ["id"] = "1690045797",
                        ["itemLink"] = 24,
                    },
                    [5] = 
                    {
                        ["price"] = 40377,
                        ["guild"] = 1,
                        ["buyer"] = 265,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632981308,
                        ["quant"] = 200,
                        ["id"] = "1690138147",
                        ["itemLink"] = 24,
                    },
                    [6] = 
                    {
                        ["price"] = 40772,
                        ["guild"] = 1,
                        ["buyer"] = 265,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632981309,
                        ["quant"] = 200,
                        ["id"] = "1690138149",
                        ["itemLink"] = 24,
                    },
                    [7] = 
                    {
                        ["price"] = 41033,
                        ["guild"] = 1,
                        ["buyer"] = 490,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633017766,
                        ["quant"] = 200,
                        ["id"] = "1690346845",
                        ["itemLink"] = 24,
                    },
                    [8] = 
                    {
                        ["price"] = 41033,
                        ["guild"] = 1,
                        ["buyer"] = 490,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633017768,
                        ["quant"] = 200,
                        ["id"] = "1690346853",
                        ["itemLink"] = 24,
                    },
                    [9] = 
                    {
                        ["price"] = 48000,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633035241,
                        ["quant"] = 200,
                        ["id"] = "1690477793",
                        ["itemLink"] = 24,
                    },
                    [10] = 
                    {
                        ["price"] = 48000,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633035241,
                        ["quant"] = 200,
                        ["id"] = "1690477797",
                        ["itemLink"] = 24,
                    },
                    [11] = 
                    {
                        ["price"] = 48000,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633035242,
                        ["quant"] = 200,
                        ["id"] = "1690477801",
                        ["itemLink"] = 24,
                    },
                    [12] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 244,
                        ["timestamp"] = 1633035242,
                        ["quant"] = 200,
                        ["id"] = "1690477805",
                        ["itemLink"] = 24,
                    },
                    [13] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 244,
                        ["timestamp"] = 1633035243,
                        ["quant"] = 200,
                        ["id"] = "1690477809",
                        ["itemLink"] = 24,
                    },
                    [14] = 
                    {
                        ["price"] = 40517,
                        ["guild"] = 1,
                        ["buyer"] = 490,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633054138,
                        ["quant"] = 200,
                        ["id"] = "1690646813",
                        ["itemLink"] = 24,
                    },
                    [15] = 
                    {
                        ["price"] = 40517,
                        ["guild"] = 1,
                        ["buyer"] = 490,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633054140,
                        ["quant"] = 200,
                        ["id"] = "1690646849",
                        ["itemLink"] = 24,
                    },
                    [16] = 
                    {
                        ["price"] = 41063,
                        ["guild"] = 1,
                        ["buyer"] = 863,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633075244,
                        ["quant"] = 200,
                        ["id"] = "1690812297",
                        ["itemLink"] = 24,
                    },
                    [17] = 
                    {
                        ["price"] = 43000,
                        ["guild"] = 1,
                        ["buyer"] = 490,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633083532,
                        ["quant"] = 200,
                        ["id"] = "1690852643",
                        ["itemLink"] = 24,
                    },
                    [18] = 
                    {
                        ["price"] = 43000,
                        ["guild"] = 1,
                        ["buyer"] = 490,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633083532,
                        ["quant"] = 200,
                        ["id"] = "1690852645",
                        ["itemLink"] = 24,
                    },
                    [19] = 
                    {
                        ["price"] = 41412,
                        ["guild"] = 1,
                        ["buyer"] = 979,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633109447,
                        ["quant"] = 200,
                        ["id"] = "1691032179",
                        ["itemLink"] = 24,
                    },
                    [20] = 
                    {
                        ["price"] = 41412,
                        ["guild"] = 1,
                        ["buyer"] = 979,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633109448,
                        ["quant"] = 200,
                        ["id"] = "1691032205",
                        ["itemLink"] = 24,
                    },
                    [21] = 
                    {
                        ["price"] = 42354,
                        ["guild"] = 1,
                        ["buyer"] = 979,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633109449,
                        ["quant"] = 200,
                        ["id"] = "1691032217",
                        ["itemLink"] = 24,
                    },
                    [22] = 
                    {
                        ["price"] = 22871,
                        ["guild"] = 1,
                        ["buyer"] = 979,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633109452,
                        ["quant"] = 108,
                        ["id"] = "1691032243",
                        ["itemLink"] = 24,
                    },
                    [23] = 
                    {
                        ["price"] = 43300,
                        ["guild"] = 1,
                        ["buyer"] = 979,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1633109454,
                        ["quant"] = 200,
                        ["id"] = "1691032255",
                        ["itemLink"] = 24,
                    },
                    [24] = 
                    {
                        ["price"] = 43300,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 144,
                        ["timestamp"] = 1633114412,
                        ["quant"] = 200,
                        ["id"] = "1691068875",
                        ["itemLink"] = 24,
                    },
                    [25] = 
                    {
                        ["price"] = 48000,
                        ["guild"] = 1,
                        ["buyer"] = 1130,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633134176,
                        ["quant"] = 200,
                        ["id"] = "1691232591",
                        ["itemLink"] = 24,
                    },
                    [26] = 
                    {
                        ["price"] = 48000,
                        ["guild"] = 1,
                        ["buyer"] = 1130,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633134179,
                        ["quant"] = 200,
                        ["id"] = "1691232609",
                        ["itemLink"] = 24,
                    },
                    [27] = 
                    {
                        ["price"] = 40904,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 21,
                        ["timestamp"] = 1633148085,
                        ["quant"] = 200,
                        ["id"] = "1691374453",
                        ["itemLink"] = 24,
                    },
                    [28] = 
                    {
                        ["price"] = 40904,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 21,
                        ["timestamp"] = 1633148087,
                        ["quant"] = 200,
                        ["id"] = "1691374485",
                        ["itemLink"] = 24,
                    },
                    [29] = 
                    {
                        ["price"] = 40513,
                        ["guild"] = 1,
                        ["buyer"] = 1246,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633148228,
                        ["quant"] = 200,
                        ["id"] = "1691375671",
                        ["itemLink"] = 24,
                    },
                    [30] = 
                    {
                        ["price"] = 44000,
                        ["guild"] = 1,
                        ["buyer"] = 1246,
                        ["wasKiosk"] = true,
                        ["seller"] = 1011,
                        ["timestamp"] = 1633148229,
                        ["quant"] = 200,
                        ["id"] = "1691375679",
                        ["itemLink"] = 24,
                    },
                    [31] = 
                    {
                        ["price"] = 44000,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 1011,
                        ["timestamp"] = 1633154384,
                        ["quant"] = 200,
                        ["id"] = "1691426863",
                        ["itemLink"] = 24,
                    },
                    [32] = 
                    {
                        ["price"] = 46400,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633154384,
                        ["quant"] = 200,
                        ["id"] = "1691426865",
                        ["itemLink"] = 24,
                    },
                    [33] = 
                    {
                        ["price"] = 46400,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633154385,
                        ["quant"] = 200,
                        ["id"] = "1691426871",
                        ["itemLink"] = 24,
                    },
                    [34] = 
                    {
                        ["price"] = 46400,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633154386,
                        ["quant"] = 200,
                        ["id"] = "1691426881",
                        ["itemLink"] = 24,
                    },
                    [35] = 
                    {
                        ["price"] = 46400,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633154387,
                        ["quant"] = 200,
                        ["id"] = "1691426883",
                        ["itemLink"] = 24,
                    },
                    [36] = 
                    {
                        ["price"] = 46400,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633154387,
                        ["quant"] = 200,
                        ["id"] = "1691426889",
                        ["itemLink"] = 24,
                    },
                    [37] = 
                    {
                        ["price"] = 41490,
                        ["guild"] = 1,
                        ["buyer"] = 1364,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633180194,
                        ["quant"] = 200,
                        ["id"] = "1691586651",
                        ["itemLink"] = 24,
                    },
                    [38] = 
                    {
                        ["price"] = 41490,
                        ["guild"] = 1,
                        ["buyer"] = 1364,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633180197,
                        ["quant"] = 200,
                        ["id"] = "1691586675",
                        ["itemLink"] = 24,
                    },
                    [39] = 
                    {
                        ["price"] = 46400,
                        ["guild"] = 1,
                        ["buyer"] = 1611,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633220377,
                        ["quant"] = 200,
                        ["id"] = "1692015861",
                        ["itemLink"] = 24,
                    },
                    [40] = 
                    {
                        ["price"] = 46400,
                        ["guild"] = 1,
                        ["buyer"] = 1611,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633220377,
                        ["quant"] = 200,
                        ["id"] = "1692015867",
                        ["itemLink"] = 24,
                    },
                    [41] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 521,
                        ["wasKiosk"] = false,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633227637,
                        ["quant"] = 3,
                        ["id"] = "1692092305",
                        ["itemLink"] = 24,
                    },
                    [42] = 
                    {
                        ["price"] = 40979,
                        ["guild"] = 1,
                        ["buyer"] = 1692,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633230586,
                        ["quant"] = 200,
                        ["id"] = "1692120753",
                        ["itemLink"] = 24,
                    },
                    [43] = 
                    {
                        ["price"] = 41358,
                        ["guild"] = 1,
                        ["buyer"] = 1692,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633230587,
                        ["quant"] = 200,
                        ["id"] = "1692120763",
                        ["itemLink"] = 24,
                    },
                    [44] = 
                    {
                        ["price"] = 41358,
                        ["guild"] = 1,
                        ["buyer"] = 1692,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633230588,
                        ["quant"] = 200,
                        ["id"] = "1692120773",
                        ["itemLink"] = 24,
                    },
                    [45] = 
                    {
                        ["price"] = 23499,
                        ["guild"] = 1,
                        ["buyer"] = 1754,
                        ["wasKiosk"] = true,
                        ["seller"] = 277,
                        ["timestamp"] = 1633239201,
                        ["quant"] = 100,
                        ["id"] = "1692192573",
                        ["itemLink"] = 24,
                    },
                    [46] = 
                    {
                        ["price"] = 40499,
                        ["guild"] = 1,
                        ["buyer"] = 490,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633280095,
                        ["quant"] = 200,
                        ["id"] = "1692516463",
                        ["itemLink"] = 24,
                    },
                    [47] = 
                    {
                        ["price"] = 40499,
                        ["guild"] = 1,
                        ["buyer"] = 490,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633280096,
                        ["quant"] = 200,
                        ["id"] = "1692516467",
                        ["itemLink"] = 24,
                    },
                    [48] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 2003,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633293851,
                        ["quant"] = 200,
                        ["id"] = "1692674147",
                        ["itemLink"] = 24,
                    },
                    [49] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 2003,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633293852,
                        ["quant"] = 200,
                        ["id"] = "1692674159",
                        ["itemLink"] = 24,
                    },
                    [50] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 2003,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633293853,
                        ["quant"] = 200,
                        ["id"] = "1692674171",
                        ["itemLink"] = 24,
                    },
                    [51] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 2003,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633293855,
                        ["quant"] = 200,
                        ["id"] = "1692674199",
                        ["itemLink"] = 24,
                    },
                    [52] = 
                    {
                        ["price"] = 40858,
                        ["guild"] = 1,
                        ["buyer"] = 490,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632859221,
                        ["quant"] = 200,
                        ["id"] = "1689224297",
                        ["itemLink"] = 24,
                    },
                    [53] = 
                    {
                        ["price"] = 40858,
                        ["guild"] = 1,
                        ["buyer"] = 490,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632859222,
                        ["quant"] = 200,
                        ["id"] = "1689224311",
                        ["itemLink"] = 24,
                    },
                    [54] = 
                    {
                        ["price"] = 40858,
                        ["guild"] = 1,
                        ["buyer"] = 490,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632859225,
                        ["quant"] = 200,
                        ["id"] = "1689224359",
                        ["itemLink"] = 24,
                    },
                    [55] = 
                    {
                        ["price"] = 41174,
                        ["guild"] = 1,
                        ["buyer"] = 490,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632872884,
                        ["quant"] = 200,
                        ["id"] = "1689322351",
                        ["itemLink"] = 24,
                    },
                    [56] = 
                    {
                        ["price"] = 41174,
                        ["guild"] = 1,
                        ["buyer"] = 490,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632872885,
                        ["quant"] = 200,
                        ["id"] = "1689322363",
                        ["itemLink"] = 24,
                    },
                    [57] = 
                    {
                        ["price"] = 41020,
                        ["guild"] = 1,
                        ["buyer"] = 681,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632891991,
                        ["quant"] = 200,
                        ["id"] = "1689508303",
                        ["itemLink"] = 24,
                    },
                    [58] = 
                    {
                        ["price"] = 41020,
                        ["guild"] = 1,
                        ["buyer"] = 681,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632891992,
                        ["quant"] = 200,
                        ["id"] = "1689508307",
                        ["itemLink"] = 24,
                    },
                    [59] = 
                    {
                        ["price"] = 41399,
                        ["guild"] = 1,
                        ["buyer"] = 863,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1632929825,
                        ["quant"] = 200,
                        ["id"] = "1689721443",
                        ["itemLink"] = 24,
                    },
                    [60] = 
                    {
                        ["price"] = 41399,
                        ["guild"] = 1,
                        ["buyer"] = 863,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1632929827,
                        ["quant"] = 200,
                        ["id"] = "1689721459",
                        ["itemLink"] = 24,
                    },
                    [61] = 
                    {
                        ["price"] = 41497,
                        ["guild"] = 1,
                        ["buyer"] = 863,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632929828,
                        ["quant"] = 200,
                        ["id"] = "1689721475",
                        ["itemLink"] = 24,
                    },
                    [62] = 
                    {
                        ["price"] = 41497,
                        ["guild"] = 1,
                        ["buyer"] = 863,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632929830,
                        ["quant"] = 200,
                        ["id"] = "1689721493",
                        ["itemLink"] = 24,
                    },
                    [63] = 
                    {
                        ["price"] = 47000,
                        ["guild"] = 1,
                        ["buyer"] = 2566,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632946454,
                        ["quant"] = 200,
                        ["id"] = "1689845513",
                        ["itemLink"] = 24,
                    },
                    [64] = 
                    {
                        ["price"] = 47000,
                        ["guild"] = 1,
                        ["buyer"] = 2566,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632946455,
                        ["quant"] = 200,
                        ["id"] = "1689845519",
                        ["itemLink"] = 24,
                    },
                    [65] = 
                    {
                        ["price"] = 43000,
                        ["guild"] = 1,
                        ["buyer"] = 1574,
                        ["wasKiosk"] = true,
                        ["seller"] = 267,
                        ["timestamp"] = 1632952937,
                        ["quant"] = 200,
                        ["id"] = "1689900713",
                        ["itemLink"] = 24,
                    },
                    [66] = 
                    {
                        ["price"] = 43000,
                        ["guild"] = 1,
                        ["buyer"] = 1574,
                        ["wasKiosk"] = true,
                        ["seller"] = 267,
                        ["timestamp"] = 1632952938,
                        ["quant"] = 200,
                        ["id"] = "1689900745",
                        ["itemLink"] = 24,
                    },
                    [67] = 
                    {
                        ["price"] = 43000,
                        ["guild"] = 1,
                        ["buyer"] = 1574,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1632962612,
                        ["quant"] = 200,
                        ["id"] = "1689981187",
                        ["itemLink"] = 24,
                    },
                    [68] = 
                    {
                        ["price"] = 43000,
                        ["guild"] = 1,
                        ["buyer"] = 1574,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1632962614,
                        ["quant"] = 200,
                        ["id"] = "1689981193",
                        ["itemLink"] = 24,
                    },
                },
                ["totalCount"] = 68,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [171498] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing4.dds",
                ["itemDesc"] = "Diagram: Dwarven Divider, Ornate Polished",
                ["oldestTime"] = 1633236836,
                ["wasAltered"] = true,
                ["newestTime"] = 1633236836,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 175950,
                        ["guild"] = 1,
                        ["buyer"] = 1741,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633236836,
                        ["quant"] = 1,
                        ["id"] = "1692174519",
                        ["itemLink"] = 2497,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [132587] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 57: Ebonshadow Daggers",
                ["oldestTime"] = 1632852241,
                ["wasAltered"] = true,
                ["newestTime"] = 1632852241,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 161,
                        ["timestamp"] = 1632852241,
                        ["quant"] = 1,
                        ["id"] = "1689160777",
                        ["itemLink"] = 3251,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [97260] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_waist_d.dds",
                ["itemDesc"] = "Sash of a Mother's Sorrow",
                ["oldestTime"] = 1632973549,
                ["wasAltered"] = true,
                ["newestTime"] = 1632973549,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1632973549,
                        ["quant"] = 1,
                        ["id"] = "1690087083",
                        ["itemLink"] = 205,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set mother's sorrow waist divines",
            },
        },
        [54509] = 
        {
            ["50:16:1:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Platinum Ring",
                ["oldestTime"] = 1632944351,
                ["wasAltered"] = true,
                ["newestTime"] = 1633231725,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1698,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1633231725,
                        ["quant"] = 1,
                        ["id"] = "1692132641",
                        ["itemLink"] = 2442,
                    },
                    [2] = 
                    {
                        ["price"] = 216,
                        ["guild"] = 1,
                        ["buyer"] = 2559,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632944351,
                        ["quant"] = 1,
                        ["id"] = "1689830511",
                        ["itemLink"] = 3783,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 white normal jewelry apparel ring arcane",
            },
        },
        [54510] = 
        {
            ["50:16:2:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Platinum Ring of Reduce Spell Cost",
                ["oldestTime"] = 1633282981,
                ["wasAltered"] = true,
                ["newestTime"] = 1633282981,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 475,
                        ["guild"] = 1,
                        ["buyer"] = 184,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633282981,
                        ["quant"] = 1,
                        ["id"] = "1692546825",
                        ["itemLink"] = 2747,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel ring robust",
            },
            ["50:16:1:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Platinum Ring",
                ["oldestTime"] = 1633131348,
                ["wasAltered"] = true,
                ["newestTime"] = 1633131348,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 1110,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633131348,
                        ["quant"] = 1,
                        ["id"] = "1691201045",
                        ["itemLink"] = 1517,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal jewelry apparel ring robust",
            },
        },
        [54511] = 
        {
            ["50:15:1:24:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Platinum Ring",
                ["oldestTime"] = 1632911735,
                ["wasAltered"] = true,
                ["newestTime"] = 1633301484,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 435,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632994939,
                        ["quant"] = 1,
                        ["id"] = "1690210041",
                        ["itemLink"] = 374,
                    },
                    [2] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633127146,
                        ["quant"] = 1,
                        ["id"] = "1691159779",
                        ["itemLink"] = 374,
                    },
                    [3] = 
                    {
                        ["price"] = 375,
                        ["guild"] = 1,
                        ["buyer"] = 1230,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633146167,
                        ["quant"] = 1,
                        ["id"] = "1691358177",
                        ["itemLink"] = 374,
                    },
                    [4] = 
                    {
                        ["price"] = 375,
                        ["guild"] = 1,
                        ["buyer"] = 1230,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633146168,
                        ["quant"] = 1,
                        ["id"] = "1691358181",
                        ["itemLink"] = 374,
                    },
                    [5] = 
                    {
                        ["price"] = 375,
                        ["guild"] = 1,
                        ["buyer"] = 1230,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633146168,
                        ["quant"] = 1,
                        ["id"] = "1691358183",
                        ["itemLink"] = 374,
                    },
                    [6] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633186050,
                        ["quant"] = 1,
                        ["id"] = "1691641181",
                        ["itemLink"] = 374,
                    },
                    [7] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633186051,
                        ["quant"] = 1,
                        ["id"] = "1691641199",
                        ["itemLink"] = 374,
                    },
                    [8] = 
                    {
                        ["price"] = 465,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633186056,
                        ["quant"] = 1,
                        ["id"] = "1691641303",
                        ["itemLink"] = 374,
                    },
                    [9] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186063,
                        ["quant"] = 1,
                        ["id"] = "1691641391",
                        ["itemLink"] = 374,
                    },
                    [10] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294062,
                        ["quant"] = 1,
                        ["id"] = "1692676485",
                        ["itemLink"] = 374,
                    },
                    [11] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294065,
                        ["quant"] = 1,
                        ["id"] = "1692676509",
                        ["itemLink"] = 374,
                    },
                    [12] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294069,
                        ["quant"] = 1,
                        ["id"] = "1692676551",
                        ["itemLink"] = 374,
                    },
                    [13] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294073,
                        ["quant"] = 1,
                        ["id"] = "1692676595",
                        ["itemLink"] = 374,
                    },
                    [14] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294076,
                        ["quant"] = 1,
                        ["id"] = "1692676615",
                        ["itemLink"] = 374,
                    },
                    [15] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294076,
                        ["quant"] = 1,
                        ["id"] = "1692676625",
                        ["itemLink"] = 374,
                    },
                    [16] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294077,
                        ["quant"] = 1,
                        ["id"] = "1692676631",
                        ["itemLink"] = 374,
                    },
                    [17] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294078,
                        ["quant"] = 1,
                        ["id"] = "1692676635",
                        ["itemLink"] = 374,
                    },
                    [18] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294079,
                        ["quant"] = 1,
                        ["id"] = "1692676643",
                        ["itemLink"] = 374,
                    },
                    [19] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294082,
                        ["quant"] = 1,
                        ["id"] = "1692676683",
                        ["itemLink"] = 374,
                    },
                    [20] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294083,
                        ["quant"] = 1,
                        ["id"] = "1692676693",
                        ["itemLink"] = 374,
                    },
                    [21] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301477,
                        ["quant"] = 1,
                        ["id"] = "1692755949",
                        ["itemLink"] = 374,
                    },
                    [22] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301481,
                        ["quant"] = 1,
                        ["id"] = "1692755971",
                        ["itemLink"] = 374,
                    },
                    [23] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301482,
                        ["quant"] = 1,
                        ["id"] = "1692755981",
                        ["itemLink"] = 374,
                    },
                    [24] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301484,
                        ["quant"] = 1,
                        ["id"] = "1692755991",
                        ["itemLink"] = 374,
                    },
                    [25] = 
                    {
                        ["price"] = 352,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 399,
                        ["timestamp"] = 1632911735,
                        ["quant"] = 1,
                        ["id"] = "1689607361",
                        ["itemLink"] = 374,
                    },
                    [26] = 
                    {
                        ["price"] = 375,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 379,
                        ["timestamp"] = 1632911736,
                        ["quant"] = 1,
                        ["id"] = "1689607373",
                        ["itemLink"] = 374,
                    },
                    [27] = 
                    {
                        ["price"] = 425,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 332,
                        ["timestamp"] = 1632911737,
                        ["quant"] = 1,
                        ["id"] = "1689607393",
                        ["itemLink"] = 374,
                    },
                },
                ["totalCount"] = 27,
                ["itemAdderText"] = "cp150 white normal jewelry apparel ring ornate",
            },
            ["50:16:1:24:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Platinum Ring",
                ["oldestTime"] = 1632911736,
                ["wasAltered"] = true,
                ["newestTime"] = 1633301485,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632994938,
                        ["quant"] = 1,
                        ["id"] = "1690210037",
                        ["itemLink"] = 373,
                    },
                    [2] = 
                    {
                        ["price"] = 335,
                        ["guild"] = 1,
                        ["buyer"] = 1110,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633131349,
                        ["quant"] = 1,
                        ["id"] = "1691201071",
                        ["itemLink"] = 373,
                    },
                    [3] = 
                    {
                        ["price"] = 335,
                        ["guild"] = 1,
                        ["buyer"] = 1110,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633131350,
                        ["quant"] = 1,
                        ["id"] = "1691201081",
                        ["itemLink"] = 373,
                    },
                    [4] = 
                    {
                        ["price"] = 335,
                        ["guild"] = 1,
                        ["buyer"] = 1110,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633131351,
                        ["quant"] = 1,
                        ["id"] = "1691201099",
                        ["itemLink"] = 373,
                    },
                    [5] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633186047,
                        ["quant"] = 1,
                        ["id"] = "1691641139",
                        ["itemLink"] = 373,
                    },
                    [6] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633186048,
                        ["quant"] = 1,
                        ["id"] = "1691641155",
                        ["itemLink"] = 373,
                    },
                    [7] = 
                    {
                        ["price"] = 465,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633186055,
                        ["quant"] = 1,
                        ["id"] = "1691641275",
                        ["itemLink"] = 373,
                    },
                    [8] = 
                    {
                        ["price"] = 465,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633186055,
                        ["quant"] = 1,
                        ["id"] = "1691641291",
                        ["itemLink"] = 373,
                    },
                    [9] = 
                    {
                        ["price"] = 506,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 530,
                        ["timestamp"] = 1633186057,
                        ["quant"] = 1,
                        ["id"] = "1691641317",
                        ["itemLink"] = 373,
                    },
                    [10] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 445,
                        ["timestamp"] = 1633186074,
                        ["quant"] = 1,
                        ["id"] = "1691641545",
                        ["itemLink"] = 373,
                    },
                    [11] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294060,
                        ["quant"] = 1,
                        ["id"] = "1692676471",
                        ["itemLink"] = 373,
                    },
                    [12] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294061,
                        ["quant"] = 1,
                        ["id"] = "1692676481",
                        ["itemLink"] = 373,
                    },
                    [13] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294062,
                        ["quant"] = 1,
                        ["id"] = "1692676491",
                        ["itemLink"] = 373,
                    },
                    [14] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294064,
                        ["quant"] = 1,
                        ["id"] = "1692676501",
                        ["itemLink"] = 373,
                    },
                    [15] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294067,
                        ["quant"] = 1,
                        ["id"] = "1692676531",
                        ["itemLink"] = 373,
                    },
                    [16] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294068,
                        ["quant"] = 1,
                        ["id"] = "1692676539",
                        ["itemLink"] = 373,
                    },
                    [17] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294071,
                        ["quant"] = 1,
                        ["id"] = "1692676567",
                        ["itemLink"] = 373,
                    },
                    [18] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294072,
                        ["quant"] = 1,
                        ["id"] = "1692676589",
                        ["itemLink"] = 373,
                    },
                    [19] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294074,
                        ["quant"] = 1,
                        ["id"] = "1692676607",
                        ["itemLink"] = 373,
                    },
                    [20] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294079,
                        ["quant"] = 1,
                        ["id"] = "1692676645",
                        ["itemLink"] = 373,
                    },
                    [21] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2005,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633294081,
                        ["quant"] = 1,
                        ["id"] = "1692676669",
                        ["itemLink"] = 373,
                    },
                    [22] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301454,
                        ["quant"] = 1,
                        ["id"] = "1692755709",
                        ["itemLink"] = 373,
                    },
                    [23] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301455,
                        ["quant"] = 1,
                        ["id"] = "1692755733",
                        ["itemLink"] = 373,
                    },
                    [24] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301473,
                        ["quant"] = 1,
                        ["id"] = "1692755911",
                        ["itemLink"] = 373,
                    },
                    [25] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301479,
                        ["quant"] = 1,
                        ["id"] = "1692755957",
                        ["itemLink"] = 373,
                    },
                    [26] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301480,
                        ["quant"] = 1,
                        ["id"] = "1692755967",
                        ["itemLink"] = 373,
                    },
                    [27] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301483,
                        ["quant"] = 1,
                        ["id"] = "1692755985",
                        ["itemLink"] = 373,
                    },
                    [28] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633301485,
                        ["quant"] = 1,
                        ["id"] = "1692755995",
                        ["itemLink"] = 373,
                    },
                    [29] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 379,
                        ["timestamp"] = 1632911736,
                        ["quant"] = 1,
                        ["id"] = "1689607385",
                        ["itemLink"] = 373,
                    },
                    [30] = 
                    {
                        ["price"] = 425,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 332,
                        ["timestamp"] = 1632911738,
                        ["quant"] = 1,
                        ["id"] = "1689607405",
                        ["itemLink"] = 373,
                    },
                    [31] = 
                    {
                        ["price"] = 425,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 332,
                        ["timestamp"] = 1632911738,
                        ["quant"] = 1,
                        ["id"] = "1689607413",
                        ["itemLink"] = 373,
                    },
                    [32] = 
                    {
                        ["price"] = 425,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 442,
                        ["timestamp"] = 1632911739,
                        ["quant"] = 1,
                        ["id"] = "1689607421",
                        ["itemLink"] = 373,
                    },
                    [33] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 332,
                        ["timestamp"] = 1632911739,
                        ["quant"] = 1,
                        ["id"] = "1689607427",
                        ["itemLink"] = 373,
                    },
                    [34] = 
                    {
                        ["price"] = 498,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 109,
                        ["timestamp"] = 1632911742,
                        ["quant"] = 1,
                        ["id"] = "1689607437",
                        ["itemLink"] = 373,
                    },
                    [35] = 
                    {
                        ["price"] = 498,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 109,
                        ["timestamp"] = 1632911742,
                        ["quant"] = 1,
                        ["id"] = "1689607439",
                        ["itemLink"] = 373,
                    },
                },
                ["totalCount"] = 35,
                ["itemAdderText"] = "cp160 white normal jewelry apparel ring ornate",
            },
        },
        [180716] = 
        {
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_medium_feet_a.dds",
                ["itemDesc"] = "Plaguebreak Boots",
                ["oldestTime"] = 1633112132,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112132,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 989,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633112132,
                        ["quant"] = 1,
                        ["id"] = "1691053289",
                        ["itemLink"] = 1341,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set plaguebreak feet invigorating",
            },
        },
        [175601] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_inc_leycathedraltapestry001.dds",
                ["itemDesc"] = "Leyawiin Tapestry, Floral",
                ["oldestTime"] = 1633063865,
                ["wasAltered"] = true,
                ["newestTime"] = 1633063865,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 36000,
                        ["guild"] = 1,
                        ["buyer"] = 805,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633063865,
                        ["quant"] = 1,
                        ["id"] = "1690739487",
                        ["itemLink"] = 1044,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings parlor",
            },
        },
        [57842] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 17: Xivkyn Helmets",
                ["oldestTime"] = 1633182989,
                ["wasAltered"] = true,
                ["newestTime"] = 1633280103,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1379,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633182989,
                        ["quant"] = 1,
                        ["id"] = "1691611813",
                        ["itemLink"] = 1962,
                    },
                    [2] = 
                    {
                        ["price"] = 15102,
                        ["guild"] = 1,
                        ["buyer"] = 1926,
                        ["wasKiosk"] = true,
                        ["seller"] = 765,
                        ["timestamp"] = 1633280103,
                        ["quant"] = 1,
                        ["id"] = "1692516521",
                        ["itemLink"] = 1962,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45299] = 
        {
            ["46:0:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_1hhammer_d.dds",
                ["itemDesc"] = "Ebon Mace",
                ["oldestTime"] = 1633084668,
                ["wasAltered"] = true,
                ["newestTime"] = 1633084668,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633084668,
                        ["quant"] = 1,
                        ["id"] = "1690857145",
                        ["itemLink"] = 1196,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr46 white normal weapon mace one-handed intricate",
            },
            ["50:16:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_1hhammer_d.dds",
                ["itemDesc"] = "Rubedite Mace",
                ["oldestTime"] = 1632826467,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309695,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633009385,
                        ["quant"] = 1,
                        ["id"] = "1690285633",
                        ["itemLink"] = 498,
                    },
                    [2] = 
                    {
                        ["price"] = 151,
                        ["guild"] = 1,
                        ["buyer"] = 842,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633071014,
                        ["quant"] = 1,
                        ["id"] = "1690783789",
                        ["itemLink"] = 1085,
                    },
                    [3] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633185894,
                        ["quant"] = 1,
                        ["id"] = "1691639427",
                        ["itemLink"] = 1996,
                    },
                    [4] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633185907,
                        ["quant"] = 1,
                        ["id"] = "1691639711",
                        ["itemLink"] = 2006,
                    },
                    [5] = 
                    {
                        ["price"] = 151,
                        ["guild"] = 1,
                        ["buyer"] = 1001,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633268059,
                        ["quant"] = 1,
                        ["id"] = "1692385863",
                        ["itemLink"] = 1996,
                    },
                    [6] = 
                    {
                        ["price"] = 160,
                        ["guild"] = 1,
                        ["buyer"] = 1001,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633268061,
                        ["quant"] = 1,
                        ["id"] = "1692385881",
                        ["itemLink"] = 2649,
                    },
                    [7] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633309691,
                        ["quant"] = 1,
                        ["id"] = "1692845797",
                        ["itemLink"] = 2649,
                    },
                    [8] = 
                    {
                        ["price"] = 265,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633309695,
                        ["quant"] = 1,
                        ["id"] = "1692845847",
                        ["itemLink"] = 1085,
                    },
                    [9] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632826467,
                        ["quant"] = 1,
                        ["id"] = "1688971685",
                        ["itemLink"] = 1996,
                    },
                    [10] = 
                    {
                        ["price"] = 984,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1632843159,
                        ["quant"] = 1,
                        ["id"] = "1689085099",
                        ["itemLink"] = 3173,
                    },
                },
                ["totalCount"] = 10,
                ["itemAdderText"] = "cp160 white normal weapon mace one-handed intricate",
            },
            ["50:15:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_1hhammer_d.dds",
                ["itemDesc"] = "Rubedite Mace",
                ["oldestTime"] = 1632838994,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309696,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633185898,
                        ["quant"] = 1,
                        ["id"] = "1691639521",
                        ["itemLink"] = 2000,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633185899,
                        ["quant"] = 1,
                        ["id"] = "1691639553",
                        ["itemLink"] = 2001,
                    },
                    [3] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633309696,
                        ["quant"] = 1,
                        ["id"] = "1692845867",
                        ["itemLink"] = 2979,
                    },
                    [4] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2167,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632838994,
                        ["quant"] = 1,
                        ["id"] = "1689054223",
                        ["itemLink"] = 2000,
                    },
                    [5] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2591,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632951461,
                        ["quant"] = 1,
                        ["id"] = "1689886919",
                        ["itemLink"] = 2001,
                    },
                    [6] = 
                    {
                        ["price"] = 272,
                        ["guild"] = 1,
                        ["buyer"] = 2591,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632951463,
                        ["quant"] = 1,
                        ["id"] = "1689886955",
                        ["itemLink"] = 2001,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "cp150 white normal weapon mace one-handed intricate",
            },
        },
        [171764] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_str_markintfireplace001.dds",
                ["itemDesc"] = "Markarth Fireplace, Stone",
                ["oldestTime"] = 1633030993,
                ["wasAltered"] = true,
                ["newestTime"] = 1633030993,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24999,
                        ["guild"] = 1,
                        ["buyer"] = 562,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633030993,
                        ["quant"] = 1,
                        ["id"] = "1690450919",
                        ["itemLink"] = 713,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings structures",
            },
        },
        [147701] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 73: Anequina Boots",
                ["oldestTime"] = 1633008894,
                ["wasAltered"] = true,
                ["newestTime"] = 1633008894,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 430,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1633008894,
                        ["quant"] = 1,
                        ["id"] = "1690282161",
                        ["itemLink"] = 450,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [5366] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_damageshield.dds",
                ["itemDesc"] = "Superb Glyph of Hardening",
                ["oldestTime"] = 1632881734,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297968,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 227,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633297968,
                        ["quant"] = 1,
                        ["id"] = "1692720481",
                        ["itemLink"] = 2898,
                    },
                    [2] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632881734,
                        ["quant"] = 1,
                        ["id"] = "1689414559",
                        ["itemLink"] = 2898,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp150 green fine miscellaneous weapon glyph",
            },
        },
        [171897] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 101: Ivory Brigade Belts",
                ["oldestTime"] = 1633052086,
                ["wasAltered"] = true,
                ["newestTime"] = 1633277800,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 242,
                        ["wasKiosk"] = false,
                        ["seller"] = 604,
                        ["timestamp"] = 1633052086,
                        ["quant"] = 1,
                        ["id"] = "1690626853",
                        ["itemLink"] = 895,
                    },
                    [2] = 
                    {
                        ["price"] = 7700,
                        ["guild"] = 1,
                        ["buyer"] = 238,
                        ["wasKiosk"] = false,
                        ["seller"] = 65,
                        ["timestamp"] = 1633181474,
                        ["quant"] = 1,
                        ["id"] = "1691599213",
                        ["itemLink"] = 895,
                    },
                    [3] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1470,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633198011,
                        ["quant"] = 1,
                        ["id"] = "1691769561",
                        ["itemLink"] = 895,
                    },
                    [4] = 
                    {
                        ["price"] = 8700,
                        ["guild"] = 1,
                        ["buyer"] = 1570,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633213978,
                        ["quant"] = 1,
                        ["id"] = "1691949057",
                        ["itemLink"] = 895,
                    },
                    [5] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1770,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633240304,
                        ["quant"] = 1,
                        ["id"] = "1692199849",
                        ["itemLink"] = 895,
                    },
                    [6] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1842,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633262540,
                        ["quant"] = 1,
                        ["id"] = "1692339953",
                        ["itemLink"] = 895,
                    },
                    [7] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 624,
                        ["wasKiosk"] = false,
                        ["seller"] = 1450,
                        ["timestamp"] = 1633277800,
                        ["quant"] = 1,
                        ["id"] = "1692493475",
                        ["itemLink"] = 895,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [57848] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 17: Xivkyn Swords",
                ["oldestTime"] = 1633171749,
                ["wasAltered"] = true,
                ["newestTime"] = 1633218827,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3800,
                        ["guild"] = 1,
                        ["buyer"] = 1341,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633171749,
                        ["quant"] = 1,
                        ["id"] = "1691528645",
                        ["itemLink"] = 1884,
                    },
                    [2] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1571,
                        ["wasKiosk"] = true,
                        ["seller"] = 61,
                        ["timestamp"] = 1633218827,
                        ["quant"] = 1,
                        ["id"] = "1691999251",
                        ["itemLink"] = 1884,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [56057] = 
        {
            ["1:0:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_medium_legs_a.dds",
                ["itemDesc"] = "Rawhide Guards",
                ["oldestTime"] = 1632875485,
                ["wasAltered"] = true,
                ["newestTime"] = 1632875485,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 2324,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1632875485,
                        ["quant"] = 1,
                        ["id"] = "1689346423",
                        ["itemLink"] = 3414,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal medium apparel legs nirnhoned",
            },
        },
        [147399] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_medium_waist_a.dds",
                ["itemDesc"] = "Deadly Belt",
                ["oldestTime"] = 1632993771,
                ["wasAltered"] = true,
                ["newestTime"] = 1632993771,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 369,
                        ["wasKiosk"] = true,
                        ["seller"] = 356,
                        ["timestamp"] = 1632993771,
                        ["quant"] = 1,
                        ["id"] = "1690204661",
                        ["itemLink"] = 364,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set deadly strike waist impenetrable",
            },
        },
        [142699] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_elderarg_light_robe_a.dds",
                ["itemDesc"] = "Bright-Throat's Boast Robe",
                ["oldestTime"] = 1633131649,
                ["wasAltered"] = true,
                ["newestTime"] = 1633131649,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3999,
                        ["guild"] = 1,
                        ["buyer"] = 1114,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633131649,
                        ["quant"] = 1,
                        ["id"] = "1691204811",
                        ["itemLink"] = 1534,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set bright-throat's boast chest impenetrable",
            },
        },
        [57582] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 15: Dwemer Maces",
                ["oldestTime"] = 1633179687,
                ["wasAltered"] = true,
                ["newestTime"] = 1633179687,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1700,
                        ["guild"] = 1,
                        ["buyer"] = 1296,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1633179687,
                        ["quant"] = 1,
                        ["id"] = "1691583733",
                        ["itemLink"] = 1917,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [116477] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_orc_inc_wtgtapestrylarge001.dds",
                ["itemDesc"] = "Orcish Tapestry, War",
                ["oldestTime"] = 1633226096,
                ["wasAltered"] = true,
                ["newestTime"] = 1633226096,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16497,
                        ["guild"] = 1,
                        ["buyer"] = 1650,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1633226096,
                        ["quant"] = 1,
                        ["id"] = "1692075353",
                        ["itemLink"] = 2393,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings parlor",
            },
        },
        [126974] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_alchemy2.dds",
                ["itemDesc"] = "Formula: Indoril Shelf, Block",
                ["oldestTime"] = 1633188824,
                ["wasAltered"] = true,
                ["newestTime"] = 1633188824,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1450,
                        ["guild"] = 1,
                        ["buyer"] = 1408,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633188824,
                        ["quant"] = 1,
                        ["id"] = "1691675957",
                        ["itemLink"] = 2088,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [45567] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Timber Mammoth Ale",
                ["oldestTime"] = 1633242698,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242698,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 430,
                        ["guild"] = 1,
                        ["buyer"] = 348,
                        ["wasKiosk"] = false,
                        ["seller"] = 739,
                        ["timestamp"] = 1633242698,
                        ["quant"] = 1,
                        ["id"] = "1692215353",
                        ["itemLink"] = 2550,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
    },
}
