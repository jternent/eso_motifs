GS15DataSavedVariables =
{
    ["listingseu"] = 
    {
    },
    ["listingsna"] = 
    {
    },
    ["dataeu"] = 
    {
    },
    ["datana"] = 
    {
        [69888] = 
        {
            ["50:16:5:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_staff_d.dds",
                ["itemDesc"] = "Inferno Staff of Julianos",
                ["oldestTime"] = 1632979143,
                ["wasAltered"] = true,
                ["newestTime"] = 1632979143,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 93077,
                        ["guild"] = 1,
                        ["buyer"] = 254,
                        ["wasKiosk"] = true,
                        ["seller"] = 255,
                        ["timestamp"] = 1632979143,
                        ["quant"] = 1,
                        ["id"] = "1690126395",
                        ["itemLink"] = 258,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary weapon set law of julianos flame staff two-handed sharpened",
            },
        },
        [141825] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_inc_reliccase005.dds",
                ["itemDesc"] = "Relic Vault, Impenetrable",
                ["oldestTime"] = 1633165943,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165943,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 34500,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 586,
                        ["timestamp"] = 1633165943,
                        ["quant"] = 1,
                        ["id"] = "1691500163",
                        ["itemLink"] = 1852,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings workshop",
            },
        },
        [74242] = 
        {
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_abahswatch_light_legs_a.dds",
                ["itemDesc"] = "Breeches of Transmutation",
                ["oldestTime"] = 1633137379,
                ["wasAltered"] = true,
                ["newestTime"] = 1633137379,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1164,
                        ["wasKiosk"] = true,
                        ["seller"] = 145,
                        ["timestamp"] = 1633137379,
                        ["quant"] = 1,
                        ["id"] = "1691265267",
                        ["itemLink"] = 1580,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set robes of transmutation legs infused",
            },
        },
        [139525] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing4.dds",
                ["itemDesc"] = "Diagram: Alinor Sconce, Lantern",
                ["oldestTime"] = 1633292407,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292407,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 169420,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1633292407,
                        ["quant"] = 1,
                        ["id"] = "1692656401",
                        ["itemLink"] = 2830,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [45574] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Dark Seducer",
                ["oldestTime"] = 1632838121,
                ["wasAltered"] = true,
                ["newestTime"] = 1633208650,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 1542,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633208650,
                        ["quant"] = 1,
                        ["id"] = "1691890109",
                        ["itemLink"] = 2266,
                    },
                    [2] = 
                    {
                        ["price"] = 1988,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632838121,
                        ["quant"] = 1,
                        ["id"] = "1689047983",
                        ["itemLink"] = 2266,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45321] = 
        {
            ["50:16:1:19:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ashlanderv_medium_chest_a.dds",
                ["itemDesc"] = "Rubedo Leather Jack",
                ["oldestTime"] = 1633023026,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185984,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 507,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1633023026,
                        ["quant"] = 1,
                        ["id"] = "1690390875",
                        ["itemLink"] = 650,
                    },
                    [2] = 
                    {
                        ["price"] = 648,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633023032,
                        ["quant"] = 1,
                        ["id"] = "1690390917",
                        ["itemLink"] = 656,
                    },
                    [3] = 
                    {
                        ["price"] = 648,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633023033,
                        ["quant"] = 1,
                        ["id"] = "1690390925",
                        ["itemLink"] = 657,
                    },
                    [4] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633185984,
                        ["quant"] = 1,
                        ["id"] = "1691640545",
                        ["itemLink"] = 657,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp160 white normal medium apparel chest ornate",
            },
        },
        [167947] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 95: Nighthollow Bows",
                ["oldestTime"] = 1633086149,
                ["wasAltered"] = true,
                ["newestTime"] = 1633086149,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 901,
                        ["wasKiosk"] = true,
                        ["seller"] = 505,
                        ["timestamp"] = 1633086149,
                        ["quant"] = 1,
                        ["id"] = "1690864559",
                        ["itemLink"] = 1216,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [167183] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 92: Ancestral Akaviri Maces",
                ["oldestTime"] = 1633147905,
                ["wasAltered"] = true,
                ["newestTime"] = 1633279108,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 521,
                        ["timestamp"] = 1633147905,
                        ["quant"] = 1,
                        ["id"] = "1691373169",
                        ["itemLink"] = 1679,
                    },
                    [2] = 
                    {
                        ["price"] = 95000,
                        ["guild"] = 1,
                        ["buyer"] = 1919,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633279108,
                        ["quant"] = 1,
                        ["id"] = "1692505927",
                        ["itemLink"] = 1679,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [144144] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_staff_a.dds",
                ["itemDesc"] = "Spell Strategist Inferno Staff",
                ["oldestTime"] = 1633141949,
                ["wasAltered"] = true,
                ["newestTime"] = 1633141949,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 613,
                        ["wasKiosk"] = true,
                        ["seller"] = 145,
                        ["timestamp"] = 1633141949,
                        ["quant"] = 1,
                        ["id"] = "1691312501",
                        ["itemLink"] = 1617,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set spell strategist flame staff two-handed precise",
            },
        },
        [34321] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_cooking_grilled_chicken.dds",
                ["itemDesc"] = "Poultry",
                ["oldestTime"] = 1633134963,
                ["wasAltered"] = true,
                ["newestTime"] = 1633280512,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5499,
                        ["guild"] = 1,
                        ["buyer"] = 1135,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633134963,
                        ["quant"] = 200,
                        ["id"] = "1691240733",
                        ["itemLink"] = 1555,
                    },
                    [2] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 1927,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633280512,
                        ["quant"] = 200,
                        ["id"] = "1692520701",
                        ["itemLink"] = 1555,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [59922] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_smith_potion_008.dds",
                ["itemDesc"] = "Charcoal of Remorse",
                ["oldestTime"] = 1632970330,
                ["wasAltered"] = true,
                ["newestTime"] = 1632970330,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2533,
                        ["guild"] = 1,
                        ["buyer"] = 165,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632970330,
                        ["quant"] = 17,
                        ["id"] = "1690059829",
                        ["itemLink"] = 177,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [181523] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_str_housingleywallint001.dds",
                ["itemDesc"] = "Leyawiin Wall, Wainscoted",
                ["oldestTime"] = 1632842016,
                ["wasAltered"] = true,
                ["newestTime"] = 1632842016,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1847,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1632842016,
                        ["quant"] = 1,
                        ["id"] = "1689074003",
                        ["itemLink"] = 3159,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings structures",
            },
        },
        [45588] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Yerba Syrah Wine",
                ["oldestTime"] = 1633158031,
                ["wasAltered"] = true,
                ["newestTime"] = 1633158031,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 76,
                        ["guild"] = 1,
                        ["buyer"] = 1293,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633158031,
                        ["quant"] = 1,
                        ["id"] = "1691454347",
                        ["itemLink"] = 1775,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [71701] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 25: Aldmeri Dominion Staves",
                ["oldestTime"] = 1632818337,
                ["wasAltered"] = true,
                ["newestTime"] = 1632818337,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3999,
                        ["guild"] = 1,
                        ["buyer"] = 2097,
                        ["wasKiosk"] = true,
                        ["seller"] = 283,
                        ["timestamp"] = 1632818337,
                        ["quant"] = 1,
                        ["id"] = "1688937195",
                        ["itemLink"] = 3005,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [101142] = 
        {
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Soulshine",
                ["oldestTime"] = 1632793709,
                ["wasAltered"] = true,
                ["newestTime"] = 1632876188,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 2,
                        ["buyer"] = 131,
                        ["wasKiosk"] = false,
                        ["seller"] = 111,
                        ["timestamp"] = 1632793709,
                        ["quant"] = 1,
                        ["id"] = "1688754625",
                        ["itemLink"] = 136,
                    },
                    [2] = 
                    {
                        ["price"] = 2700,
                        ["guild"] = 1,
                        ["buyer"] = 2329,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632876188,
                        ["quant"] = 1,
                        ["id"] = "1689353699",
                        ["itemLink"] = 136,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set soulshine ring healthy",
            },
        },
        [115991] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Breton Runner, Bordered",
                ["oldestTime"] = 1632888239,
                ["wasAltered"] = true,
                ["newestTime"] = 1632888239,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 58000,
                        ["guild"] = 1,
                        ["buyer"] = 2360,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632888239,
                        ["quant"] = 1,
                        ["id"] = "1689480731",
                        ["itemLink"] = 3527,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [174873] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Band of Zenithar",
                ["oldestTime"] = 1633218669,
                ["wasAltered"] = true,
                ["newestTime"] = 1633218669,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633218669,
                        ["quant"] = 1,
                        ["id"] = "1691997387",
                        ["itemLink"] = 2330,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set frostbite ring robust",
            },
        },
        [45082] = 
        {
            ["50:16:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_medium_waist_d.dds",
                ["itemDesc"] = "Rubedo Leather Belt of Magicka",
                ["oldestTime"] = 1632936835,
                ["wasAltered"] = true,
                ["newestTime"] = 1632936835,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 226,
                        ["wasKiosk"] = false,
                        ["seller"] = 501,
                        ["timestamp"] = 1632936835,
                        ["quant"] = 1,
                        ["id"] = "1689774029",
                        ["itemLink"] = 3746,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel waist impenetrable",
            },
        },
        [100635] = 
        {
            ["50:16:5:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_dagger_d.dds",
                ["itemDesc"] = "Spriggan's Dagger",
                ["oldestTime"] = 1633208179,
                ["wasAltered"] = true,
                ["newestTime"] = 1633208179,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 164500,
                        ["guild"] = 1,
                        ["buyer"] = 1540,
                        ["wasKiosk"] = true,
                        ["seller"] = 626,
                        ["timestamp"] = 1633208179,
                        ["quant"] = 1,
                        ["id"] = "1691885033",
                        ["itemLink"] = 2261,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary weapon set spriggan's thorns dagger one-handed precise",
            },
        },
        [45341] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_heavy_feet_a.dds",
                ["itemDesc"] = "Rubedite Sabatons",
                ["oldestTime"] = 1632843202,
                ["wasAltered"] = true,
                ["newestTime"] = 1633244682,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 235,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 442,
                        ["timestamp"] = 1633009342,
                        ["quant"] = 1,
                        ["id"] = "1690285189",
                        ["itemLink"] = 454,
                    },
                    [2] = 
                    {
                        ["price"] = 265,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633084074,
                        ["quant"] = 1,
                        ["id"] = "1690854865",
                        ["itemLink"] = 1173,
                    },
                    [3] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1055,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633121634,
                        ["quant"] = 1,
                        ["id"] = "1691116763",
                        ["itemLink"] = 1442,
                    },
                    [4] = 
                    {
                        ["price"] = 265,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633129400,
                        ["quant"] = 1,
                        ["id"] = "1691180191",
                        ["itemLink"] = 1503,
                    },
                    [5] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633244679,
                        ["quant"] = 1,
                        ["id"] = "1692231343",
                        ["itemLink"] = 2569,
                    },
                    [6] = 
                    {
                        ["price"] = 277,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633244682,
                        ["quant"] = 1,
                        ["id"] = "1692231367",
                        ["itemLink"] = 2573,
                    },
                    [7] = 
                    {
                        ["price"] = 864,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1632843202,
                        ["quant"] = 1,
                        ["id"] = "1689085395",
                        ["itemLink"] = 2569,
                    },
                    [8] = 
                    {
                        ["price"] = 265,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632865263,
                        ["quant"] = 1,
                        ["id"] = "1689266329",
                        ["itemLink"] = 1173,
                    },
                    [9] = 
                    {
                        ["price"] = 135,
                        ["guild"] = 1,
                        ["buyer"] = 2431,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1632895316,
                        ["quant"] = 1,
                        ["id"] = "1689531175",
                        ["itemLink"] = 1503,
                    },
                    [10] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2516,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632930837,
                        ["quant"] = 1,
                        ["id"] = "1689728275",
                        ["itemLink"] = 1442,
                    },
                    [11] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632950132,
                        ["quant"] = 1,
                        ["id"] = "1689875257",
                        ["itemLink"] = 3824,
                    },
                    [12] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632950132,
                        ["quant"] = 1,
                        ["id"] = "1689875263",
                        ["itemLink"] = 3825,
                    },
                },
                ["totalCount"] = 12,
                ["itemAdderText"] = "cp160 white normal heavy apparel feet intricate",
            },
            ["1:0:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_heavy_feet_a.dds",
                ["itemDesc"] = "Iron Sabatons",
                ["oldestTime"] = 1633213529,
                ["wasAltered"] = true,
                ["newestTime"] = 1633213529,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 120,
                        ["guild"] = 1,
                        ["buyer"] = 1567,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633213529,
                        ["quant"] = 1,
                        ["id"] = "1691945355",
                        ["itemLink"] = 2290,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal heavy apparel feet intricate",
            },
            ["33:0:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_heavy_feet_c.dds",
                ["itemDesc"] = "Orichalc Sabatons",
                ["oldestTime"] = 1633129394,
                ["wasAltered"] = true,
                ["newestTime"] = 1633129394,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 79,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633129394,
                        ["quant"] = 1,
                        ["id"] = "1691180129",
                        ["itemLink"] = 1501,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr33 white normal heavy apparel feet intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_heavy_feet_a.dds",
                ["itemDesc"] = "Rubedite Sabatons",
                ["oldestTime"] = 1632843204,
                ["wasAltered"] = true,
                ["newestTime"] = 1633028907,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 381,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633009359,
                        ["quant"] = 1,
                        ["id"] = "1690285355",
                        ["itemLink"] = 472,
                    },
                    [2] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633028907,
                        ["quant"] = 1,
                        ["id"] = "1690436729",
                        ["itemLink"] = 699,
                    },
                    [3] = 
                    {
                        ["price"] = 864,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1632843204,
                        ["quant"] = 1,
                        ["id"] = "1689085411",
                        ["itemLink"] = 3183,
                    },
                    [4] = 
                    {
                        ["price"] = 161,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1632865262,
                        ["quant"] = 1,
                        ["id"] = "1689266319",
                        ["itemLink"] = 699,
                    },
                    [5] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2431,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632895317,
                        ["quant"] = 1,
                        ["id"] = "1689531189",
                        ["itemLink"] = 3560,
                    },
                    [6] = 
                    {
                        ["price"] = 195,
                        ["guild"] = 1,
                        ["buyer"] = 2202,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632913791,
                        ["quant"] = 1,
                        ["id"] = "1689616123",
                        ["itemLink"] = 3633,
                    },
                    [7] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2516,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1632930831,
                        ["quant"] = 1,
                        ["id"] = "1689728259",
                        ["itemLink"] = 699,
                    },
                    [8] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2516,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632930832,
                        ["quant"] = 1,
                        ["id"] = "1689728261",
                        ["itemLink"] = 699,
                    },
                    [9] = 
                    {
                        ["price"] = 381,
                        ["guild"] = 1,
                        ["buyer"] = 2660,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632966348,
                        ["quant"] = 1,
                        ["id"] = "1690018373",
                        ["itemLink"] = 3963,
                    },
                },
                ["totalCount"] = 9,
                ["itemAdderText"] = "cp150 white normal heavy apparel feet intricate",
            },
        },
        [43550] = 
        {
            ["50:16:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_medium_chest_d.dds",
                ["itemDesc"] = "Rubedo Leather Jack of Health",
                ["oldestTime"] = 1632847695,
                ["wasAltered"] = true,
                ["newestTime"] = 1632847695,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 533,
                        ["timestamp"] = 1632847695,
                        ["quant"] = 1,
                        ["id"] = "1689125593",
                        ["itemLink"] = 3219,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel chest",
            },
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_medium_chest_d.dds",
                ["itemDesc"] = "Rubedo Leather Jack",
                ["oldestTime"] = 1632847690,
                ["wasAltered"] = true,
                ["newestTime"] = 1632847690,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 171,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1632847690,
                        ["quant"] = 1,
                        ["id"] = "1689125547",
                        ["itemLink"] = 3214,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal medium apparel chest",
            },
        },
        [178463] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_scraps_scaled_hide.dds",
                ["itemDesc"] = "Scaly Cloth Scrap",
                ["oldestTime"] = 1632892683,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310289,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 49995,
                        ["guild"] = 1,
                        ["buyer"] = 335,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1632988157,
                        ["quant"] = 1,
                        ["id"] = "1690175307",
                        ["itemLink"] = 340,
                    },
                    [2] = 
                    {
                        ["price"] = 168000,
                        ["guild"] = 1,
                        ["buyer"] = 961,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633103714,
                        ["quant"] = 4,
                        ["id"] = "1690989173",
                        ["itemLink"] = 340,
                    },
                    [3] = 
                    {
                        ["price"] = 80000,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633113923,
                        ["quant"] = 2,
                        ["id"] = "1691065181",
                        ["itemLink"] = 340,
                    },
                    [4] = 
                    {
                        ["price"] = 80000,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633113925,
                        ["quant"] = 2,
                        ["id"] = "1691065191",
                        ["itemLink"] = 340,
                    },
                    [5] = 
                    {
                        ["price"] = 80000,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633113926,
                        ["quant"] = 2,
                        ["id"] = "1691065199",
                        ["itemLink"] = 340,
                    },
                    [6] = 
                    {
                        ["price"] = 80000,
                        ["guild"] = 1,
                        ["buyer"] = 1059,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633121819,
                        ["quant"] = 2,
                        ["id"] = "1691118193",
                        ["itemLink"] = 340,
                    },
                    [7] = 
                    {
                        ["price"] = 43000,
                        ["guild"] = 1,
                        ["buyer"] = 1962,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633287149,
                        ["quant"] = 1,
                        ["id"] = "1692593535",
                        ["itemLink"] = 340,
                    },
                    [8] = 
                    {
                        ["price"] = 62000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1633292461,
                        ["quant"] = 1,
                        ["id"] = "1692656951",
                        ["itemLink"] = 340,
                    },
                    [9] = 
                    {
                        ["price"] = 46000,
                        ["guild"] = 1,
                        ["buyer"] = 2089,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633310289,
                        ["quant"] = 1,
                        ["id"] = "1692852193",
                        ["itemLink"] = 340,
                    },
                    [10] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 2423,
                        ["wasKiosk"] = true,
                        ["seller"] = 240,
                        ["timestamp"] = 1632892683,
                        ["quant"] = 1,
                        ["id"] = "1689513747",
                        ["itemLink"] = 340,
                    },
                    [11] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 2423,
                        ["wasKiosk"] = true,
                        ["seller"] = 240,
                        ["timestamp"] = 1632892777,
                        ["quant"] = 1,
                        ["id"] = "1689514419",
                        ["itemLink"] = 340,
                    },
                },
                ["totalCount"] = 11,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [160545] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 85: Greymoor Boots",
                ["oldestTime"] = 1632895262,
                ["wasAltered"] = true,
                ["newestTime"] = 1632895262,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 2430,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1632895262,
                        ["quant"] = 1,
                        ["id"] = "1689530943",
                        ["itemLink"] = 3557,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [115746] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Argonian Mat, Tidy Reed",
                ["oldestTime"] = 1633119042,
                ["wasAltered"] = true,
                ["newestTime"] = 1633119042,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1043,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633119042,
                        ["quant"] = 1,
                        ["id"] = "1691098377",
                        ["itemLink"] = 1427,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [172068] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_robe_a.dds",
                ["itemDesc"] = "Robe of Frostbite",
                ["oldestTime"] = 1633222549,
                ["wasAltered"] = true,
                ["newestTime"] = 1633222549,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1377,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633222549,
                        ["quant"] = 1,
                        ["id"] = "1692038043",
                        ["itemLink"] = 2359,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set frostbite chest invigorating",
            },
            ["46:0:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_robe_a.dds",
                ["itemDesc"] = "Robe of Frostbite",
                ["oldestTime"] = 1633045832,
                ["wasAltered"] = true,
                ["newestTime"] = 1633045832,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 599,
                        ["guild"] = 1,
                        ["buyer"] = 674,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633045832,
                        ["quant"] = 1,
                        ["id"] = "1690564901",
                        ["itemLink"] = 858,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr46 blue superior light apparel set frostbite chest invigorating",
            },
        },
        [45350] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_light_head_d.dds",
                ["itemDesc"] = "Ancestor Silk Hat",
                ["oldestTime"] = 1632841096,
                ["wasAltered"] = true,
                ["newestTime"] = 1633236164,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 864,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633009372,
                        ["quant"] = 1,
                        ["id"] = "1690285501",
                        ["itemLink"] = 487,
                    },
                    [2] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 780,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633059421,
                        ["quant"] = 1,
                        ["id"] = "1690704585",
                        ["itemLink"] = 995,
                    },
                    [3] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084095,
                        ["quant"] = 1,
                        ["id"] = "1690854995",
                        ["itemLink"] = 1182,
                    },
                    [4] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633186012,
                        ["quant"] = 1,
                        ["id"] = "1691640721",
                        ["itemLink"] = 2058,
                    },
                    [5] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1734,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1633236164,
                        ["quant"] = 1,
                        ["id"] = "1692168749",
                        ["itemLink"] = 2493,
                    },
                    [6] = 
                    {
                        ["price"] = 273,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632841096,
                        ["quant"] = 1,
                        ["id"] = "1689067941",
                        ["itemLink"] = 995,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "cp160 white normal light apparel head intricate",
            },
            ["1:0:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_light_head_b.dds",
                ["itemDesc"] = "Homespun Hat",
                ["oldestTime"] = 1633136217,
                ["wasAltered"] = true,
                ["newestTime"] = 1633136217,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 110,
                        ["guild"] = 1,
                        ["buyer"] = 1150,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633136217,
                        ["quant"] = 1,
                        ["id"] = "1691255345",
                        ["itemLink"] = 1569,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal light apparel head intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_light_head_d.dds",
                ["itemDesc"] = "Ancestor Silk Hat",
                ["oldestTime"] = 1633022932,
                ["wasAltered"] = true,
                ["newestTime"] = 1633084684,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 138,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633022932,
                        ["quant"] = 1,
                        ["id"] = "1690390231",
                        ["itemLink"] = 598,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084684,
                        ["quant"] = 1,
                        ["id"] = "1690857377",
                        ["itemLink"] = 1210,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp150 white normal light apparel head intricate",
            },
        },
        [122665] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redoran_heavy_chest_a.dds",
                ["itemDesc"] = "Warrior-Poet's Cuirass",
                ["oldestTime"] = 1633129698,
                ["wasAltered"] = true,
                ["newestTime"] = 1633129698,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2850,
                        ["guild"] = 1,
                        ["buyer"] = 1098,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1633129698,
                        ["quant"] = 1,
                        ["id"] = "1691182825",
                        ["itemLink"] = 1508,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set warrior-poet chest well-fitted",
            },
        },
        [161066] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_greyhosthvy_shoulder_a.dds",
                ["itemDesc"] = "Pauldrons of Eternal Vigor",
                ["oldestTime"] = 1633241624,
                ["wasAltered"] = true,
                ["newestTime"] = 1633241624,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 1780,
                        ["wasKiosk"] = true,
                        ["seller"] = 1781,
                        ["timestamp"] = 1633241624,
                        ["quant"] = 1,
                        ["id"] = "1692209661",
                        ["itemLink"] = 2540,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set eternal vigor shoulders well-fitted",
            },
        },
        [45356] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_medium_chest_d.dds",
                ["itemDesc"] = "Rubedo Leather Jack",
                ["oldestTime"] = 1632839968,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185996,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 275,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1633009350,
                        ["quant"] = 1,
                        ["id"] = "1690285247",
                        ["itemLink"] = 462,
                    },
                    [2] = 
                    {
                        ["price"] = 864,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633009369,
                        ["quant"] = 1,
                        ["id"] = "1690285479",
                        ["itemLink"] = 484,
                    },
                    [3] = 
                    {
                        ["price"] = 196,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1633023006,
                        ["quant"] = 1,
                        ["id"] = "1690390643",
                        ["itemLink"] = 629,
                    },
                    [4] = 
                    {
                        ["price"] = 320,
                        ["guild"] = 1,
                        ["buyer"] = 780,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633059428,
                        ["quant"] = 1,
                        ["id"] = "1690704675",
                        ["itemLink"] = 1002,
                    },
                    [5] = 
                    {
                        ["price"] = 171,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633146940,
                        ["quant"] = 1,
                        ["id"] = "1691365401",
                        ["itemLink"] = 1672,
                    },
                    [6] = 
                    {
                        ["price"] = 275,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633185996,
                        ["quant"] = 1,
                        ["id"] = "1691640635",
                        ["itemLink"] = 2050,
                    },
                    [7] = 
                    {
                        ["price"] = 255,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 896,
                        ["timestamp"] = 1632839968,
                        ["quant"] = 1,
                        ["id"] = "1689060219",
                        ["itemLink"] = 3142,
                    },
                    [8] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632839970,
                        ["quant"] = 1,
                        ["id"] = "1689060245",
                        ["itemLink"] = 1672,
                    },
                    [9] = 
                    {
                        ["price"] = 256,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 240,
                        ["timestamp"] = 1632885646,
                        ["quant"] = 1,
                        ["id"] = "1689459535",
                        ["itemLink"] = 3142,
                    },
                    [10] = 
                    {
                        ["price"] = 275,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1632885647,
                        ["quant"] = 1,
                        ["id"] = "1689459545",
                        ["itemLink"] = 3511,
                    },
                    [11] = 
                    {
                        ["price"] = 305,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1632885649,
                        ["quant"] = 1,
                        ["id"] = "1689459565",
                        ["itemLink"] = 3512,
                    },
                    [12] = 
                    {
                        ["price"] = 275,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632956409,
                        ["quant"] = 1,
                        ["id"] = "1689931699",
                        ["itemLink"] = 3896,
                    },
                },
                ["totalCount"] = 12,
                ["itemAdderText"] = "cp160 white normal medium apparel chest intricate",
            },
            ["33:0:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ashlanderv_medium_chest_a.dds",
                ["itemDesc"] = "Leather Jack",
                ["oldestTime"] = 1633136216,
                ["wasAltered"] = true,
                ["newestTime"] = 1633136216,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99,
                        ["guild"] = 1,
                        ["buyer"] = 1150,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633136216,
                        ["quant"] = 1,
                        ["id"] = "1691255321",
                        ["itemLink"] = 1568,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr33 white normal medium apparel chest intricate",
            },
            ["47:0:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_medium_chest_d.dds",
                ["itemDesc"] = "Fell Jack",
                ["oldestTime"] = 1633059425,
                ["wasAltered"] = true,
                ["newestTime"] = 1633059425,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99,
                        ["guild"] = 1,
                        ["buyer"] = 780,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633059425,
                        ["quant"] = 1,
                        ["id"] = "1690704637",
                        ["itemLink"] = 997,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr47 white normal medium apparel chest intricate",
            },
            ["1:0:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ashlanderv_medium_chest_a.dds",
                ["itemDesc"] = "Rawhide Jack",
                ["oldestTime"] = 1633268077,
                ["wasAltered"] = true,
                ["newestTime"] = 1633268077,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1001,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633268077,
                        ["quant"] = 1,
                        ["id"] = "1692385961",
                        ["itemLink"] = 2652,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal medium apparel chest intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_medium_chest_d.dds",
                ["itemDesc"] = "Rubedo Leather Jack",
                ["oldestTime"] = 1633009370,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185984,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 864,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633009370,
                        ["quant"] = 1,
                        ["id"] = "1690285489",
                        ["itemLink"] = 485,
                    },
                    [2] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 780,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633059427,
                        ["quant"] = 1,
                        ["id"] = "1690704661",
                        ["itemLink"] = 1001,
                    },
                    [3] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633185984,
                        ["quant"] = 1,
                        ["id"] = "1691640529",
                        ["itemLink"] = 485,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp150 white normal medium apparel chest intricate",
            },
        },
        [180783] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_heavy_head_a.dds",
                ["itemDesc"] = "Hrothgar's Helm",
                ["oldestTime"] = 1633002931,
                ["wasAltered"] = true,
                ["newestTime"] = 1633002931,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 412,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633002931,
                        ["quant"] = 1,
                        ["id"] = "1690249389",
                        ["itemLink"] = 420,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set hrothgar's chill head infused",
            },
        },
        [172083] = 
        {
            ["50:16:4:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_bow_a.dds",
                ["itemDesc"] = "Bow of Frostbite",
                ["oldestTime"] = 1633082097,
                ["wasAltered"] = true,
                ["newestTime"] = 1633082097,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 885,
                        ["wasKiosk"] = true,
                        ["seller"] = 442,
                        ["timestamp"] = 1633082097,
                        ["quant"] = 1,
                        ["id"] = "1690844249",
                        ["itemLink"] = 1129,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set frostbite bow two-handed decisive",
            },
        },
        [75062] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of the Shadow Dancer",
                ["oldestTime"] = 1633280835,
                ["wasAltered"] = true,
                ["newestTime"] = 1633280835,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6485,
                        ["guild"] = 1,
                        ["buyer"] = 1929,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633280835,
                        ["quant"] = 1,
                        ["id"] = "1692523441",
                        ["itemLink"] = 2733,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set shadow dancer's raiment neck arcane",
            },
        },
        [176439] = 
        {
            ["1:0:3:46:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_pants_light.dds",
                ["itemDesc"] = "Companion's Breeches",
                ["oldestTime"] = 1632954947,
                ["wasAltered"] = true,
                ["newestTime"] = 1633053499,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 727,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1633053499,
                        ["quant"] = 1,
                        ["id"] = "1690640589",
                        ["itemLink"] = 934,
                    },
                    [2] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 2606,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1632954947,
                        ["quant"] = 1,
                        ["id"] = "1689917905",
                        ["itemLink"] = 934,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior light apparel legs shattering",
            },
        },
        [120889] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_fan_mphpurpglowbush001.dds",
                ["itemDesc"] = "Glow Bush, Purple",
                ["oldestTime"] = 1632879894,
                ["wasAltered"] = true,
                ["newestTime"] = 1632879894,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 2331,
                        ["wasKiosk"] = true,
                        ["seller"] = 232,
                        ["timestamp"] = 1632879894,
                        ["quant"] = 1,
                        ["id"] = "1689395247",
                        ["itemLink"] = 3449,
                    },
                    [2] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 2331,
                        ["wasKiosk"] = true,
                        ["seller"] = 232,
                        ["timestamp"] = 1632879894,
                        ["quant"] = 1,
                        ["id"] = "1689395251",
                        ["itemLink"] = 3449,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings conservatory",
            },
        },
        [119357] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Common Counter, Island Stall",
                ["oldestTime"] = 1633071532,
                ["wasAltered"] = true,
                ["newestTime"] = 1633071532,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 140,
                        ["guild"] = 1,
                        ["buyer"] = 847,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1633071532,
                        ["quant"] = 1,
                        ["id"] = "1690787825",
                        ["itemLink"] = 1093,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [99648] = 
        {
            ["50:16:2:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Spinner's Necklace",
                ["oldestTime"] = 1632966109,
                ["wasAltered"] = true,
                ["newestTime"] = 1632966109,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1133,
                        ["guild"] = 1,
                        ["buyer"] = 2658,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1632966109,
                        ["quant"] = 1,
                        ["id"] = "1690016325",
                        ["itemLink"] = 3961,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set spinner's garments neck arcane",
            },
        },
        [145985] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_alchemy2.dds",
                ["itemDesc"] = "Formula: Murkmire Brazier, Shell",
                ["oldestTime"] = 1632859346,
                ["wasAltered"] = true,
                ["newestTime"] = 1632859346,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25027,
                        ["guild"] = 1,
                        ["buyer"] = 193,
                        ["wasKiosk"] = true,
                        ["seller"] = 1756,
                        ["timestamp"] = 1632859346,
                        ["quant"] = 1,
                        ["id"] = "1689225597",
                        ["itemLink"] = 3295,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [149058] = 
        {
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Undertaker's Ring",
                ["oldestTime"] = 1632839079,
                ["wasAltered"] = true,
                ["newestTime"] = 1632839079,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4900,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 547,
                        ["timestamp"] = 1632839079,
                        ["quant"] = 1,
                        ["id"] = "1689055027",
                        ["itemLink"] = 3124,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set call of the undertaker ring healthy",
            },
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Undertaker's Ring",
                ["oldestTime"] = 1633163910,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163910,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1102,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 530,
                        ["timestamp"] = 1633163910,
                        ["quant"] = 1,
                        ["id"] = "1691490313",
                        ["itemLink"] = 1803,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set call of the undertaker ring healthy",
            },
        },
        [98883] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Swamp Raider's Necklace",
                ["oldestTime"] = 1633042158,
                ["wasAltered"] = true,
                ["newestTime"] = 1633042158,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 646,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633042158,
                        ["quant"] = 1,
                        ["id"] = "1690529827",
                        ["itemLink"] = 813,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set swamp raider neck robust",
            },
        },
        [172104] = 
        {
            ["50:16:2:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_bow_a.dds",
                ["itemDesc"] = "Bow of Frostbite",
                ["oldestTime"] = 1633045834,
                ["wasAltered"] = true,
                ["newestTime"] = 1633045834,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 674,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633045834,
                        ["quant"] = 1,
                        ["id"] = "1690564917",
                        ["itemLink"] = 859,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set frostbite bow two-handed training",
            },
        },
        [45897] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Stir-Fried Garlic Beef",
                ["oldestTime"] = 1633306722,
                ["wasAltered"] = true,
                ["newestTime"] = 1633306722,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633306722,
                        ["quant"] = 2,
                        ["id"] = "1692806793",
                        ["itemLink"] = 2945,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [160586] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 87: Ancestral Nord Maces",
                ["oldestTime"] = 1632830612,
                ["wasAltered"] = true,
                ["newestTime"] = 1632830612,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3750,
                        ["guild"] = 1,
                        ["buyer"] = 2135,
                        ["wasKiosk"] = true,
                        ["seller"] = 269,
                        ["timestamp"] = 1632830612,
                        ["quant"] = 1,
                        ["id"] = "1689001821",
                        ["itemLink"] = 3084,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [172107] = 
        {
            ["50:16:4:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_staff_a.dds",
                ["itemDesc"] = "Lightning Staff of Frostbite",
                ["oldestTime"] = 1633016591,
                ["wasAltered"] = true,
                ["newestTime"] = 1633016591,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 473,
                        ["wasKiosk"] = true,
                        ["seller"] = 474,
                        ["timestamp"] = 1633016591,
                        ["quant"] = 1,
                        ["id"] = "1690338215",
                        ["itemLink"] = 543,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set frostbite lightning staff two-handed training",
            },
        },
        [181580] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting2.dds",
                ["itemDesc"] = "Praxis: Leyawiin Post, Stone Garden",
                ["oldestTime"] = 1632876478,
                ["wasAltered"] = true,
                ["newestTime"] = 1633060389,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 333,
                        ["wasKiosk"] = false,
                        ["seller"] = 43,
                        ["timestamp"] = 1633035661,
                        ["quant"] = 1,
                        ["id"] = "1690480311",
                        ["itemLink"] = 768,
                    },
                    [2] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 43,
                        ["timestamp"] = 1633060389,
                        ["quant"] = 1,
                        ["id"] = "1690713589",
                        ["itemLink"] = 768,
                    },
                    [3] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 144,
                        ["wasKiosk"] = false,
                        ["seller"] = 79,
                        ["timestamp"] = 1632876478,
                        ["quant"] = 1,
                        ["id"] = "1689357039",
                        ["itemLink"] = 768,
                    },
                    [4] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 626,
                        ["wasKiosk"] = false,
                        ["seller"] = 9,
                        ["timestamp"] = 1632935002,
                        ["quant"] = 1,
                        ["id"] = "1689760595",
                        ["itemLink"] = 768,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [118349] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_exc_varmarketproduce001.dds",
                ["itemDesc"] = "Box of Plums",
                ["oldestTime"] = 1633113864,
                ["wasAltered"] = true,
                ["newestTime"] = 1633113864,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 1005,
                        ["wasKiosk"] = true,
                        ["seller"] = 17,
                        ["timestamp"] = 1633113864,
                        ["quant"] = 1,
                        ["id"] = "1691064603",
                        ["itemLink"] = 1372,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings hearth",
            },
        },
        [181583] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Leyawiin Archway, Garden",
                ["oldestTime"] = 1633040995,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292249,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 630,
                        ["wasKiosk"] = true,
                        ["seller"] = 351,
                        ["timestamp"] = 1633040995,
                        ["quant"] = 1,
                        ["id"] = "1690520999",
                        ["itemLink"] = 801,
                    },
                    [2] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 639,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1633041743,
                        ["quant"] = 1,
                        ["id"] = "1690526495",
                        ["itemLink"] = 801,
                    },
                    [3] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 929,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633096486,
                        ["quant"] = 1,
                        ["id"] = "1690931925",
                        ["itemLink"] = 801,
                    },
                    [4] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633292249,
                        ["quant"] = 1,
                        ["id"] = "1692654355",
                        ["itemLink"] = 801,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [127057] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Indoril Tapestry, Almalexia",
                ["oldestTime"] = 1633138435,
                ["wasAltered"] = true,
                ["newestTime"] = 1633138435,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 1105,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633138435,
                        ["quant"] = 1,
                        ["id"] = "1691276777",
                        ["itemLink"] = 1585,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [115026] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_ghost_vital_glow_dust.dds",
                ["itemDesc"] = "Aetherial Dust",
                ["oldestTime"] = 1632872625,
                ["wasAltered"] = true,
                ["newestTime"] = 1633206606,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 444999,
                        ["guild"] = 1,
                        ["buyer"] = 1035,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633117880,
                        ["quant"] = 1,
                        ["id"] = "1691090623",
                        ["itemLink"] = 1419,
                    },
                    [2] = 
                    {
                        ["price"] = 450000,
                        ["guild"] = 1,
                        ["buyer"] = 1209,
                        ["wasKiosk"] = true,
                        ["seller"] = 1011,
                        ["timestamp"] = 1633143154,
                        ["quant"] = 1,
                        ["id"] = "1691327029",
                        ["itemLink"] = 1419,
                    },
                    [3] = 
                    {
                        ["price"] = 480000,
                        ["guild"] = 1,
                        ["buyer"] = 1252,
                        ["wasKiosk"] = true,
                        ["seller"] = 1011,
                        ["timestamp"] = 1633149796,
                        ["quant"] = 1,
                        ["id"] = "1691388995",
                        ["itemLink"] = 1419,
                    },
                    [4] = 
                    {
                        ["price"] = 460000,
                        ["guild"] = 1,
                        ["buyer"] = 1252,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633156654,
                        ["quant"] = 1,
                        ["id"] = "1691443373",
                        ["itemLink"] = 1419,
                    },
                    [5] = 
                    {
                        ["price"] = 510000,
                        ["guild"] = 1,
                        ["buyer"] = 1531,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1633206606,
                        ["quant"] = 1,
                        ["id"] = "1691863099",
                        ["itemLink"] = 1419,
                    },
                    [6] = 
                    {
                        ["price"] = 450000,
                        ["guild"] = 1,
                        ["buyer"] = 2303,
                        ["wasKiosk"] = true,
                        ["seller"] = 2048,
                        ["timestamp"] = 1632872625,
                        ["quant"] = 1,
                        ["id"] = "1689319963",
                        ["itemLink"] = 1419,
                    },
                    [7] = 
                    {
                        ["price"] = 475000,
                        ["guild"] = 1,
                        ["buyer"] = 2303,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1632872631,
                        ["quant"] = 1,
                        ["id"] = "1689320011",
                        ["itemLink"] = 1419,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr01 gold legendary materials ingredient",
            },
        },
        [100692] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_2haxe_d.dds",
                ["itemDesc"] = "Spriggan's Battle Axe",
                ["oldestTime"] = 1633199287,
                ["wasAltered"] = true,
                ["newestTime"] = 1633199287,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 1475,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633199287,
                        ["quant"] = 1,
                        ["id"] = "1691782211",
                        ["itemLink"] = 2174,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set spriggan's thorns axe two-handed charged",
            },
        },
        [118357] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_exc_varharborfishes003.dds",
                ["itemDesc"] = "Fish, Small",
                ["oldestTime"] = 1633124166,
                ["wasAltered"] = true,
                ["newestTime"] = 1633124166,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1071,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633124166,
                        ["quant"] = 4,
                        ["id"] = "1691136153",
                        ["itemLink"] = 1459,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings hearth",
            },
        },
        [95574] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_light_hands_a.dds",
                ["itemDesc"] = "Gloves of Martial Knowledge",
                ["oldestTime"] = 1633022972,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022972,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633022972,
                        ["quant"] = 1,
                        ["id"] = "1690390357",
                        ["itemLink"] = 612,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set way of martial knowledge hands invigorating",
            },
        },
        [180823] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_heavy_head_a.dds",
                ["itemDesc"] = "Hrothgar's Helm",
                ["oldestTime"] = 1633112498,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112498,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 991,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633112498,
                        ["quant"] = 1,
                        ["id"] = "1691055487",
                        ["itemLink"] = 1354,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set hrothgar's chill head well-fitted",
            },
        },
        [172121] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Ring",
                ["oldestTime"] = 1633045364,
                ["wasAltered"] = true,
                ["newestTime"] = 1633198100,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8167,
                        ["guild"] = 1,
                        ["buyer"] = 671,
                        ["wasKiosk"] = true,
                        ["seller"] = 600,
                        ["timestamp"] = 1633045364,
                        ["quant"] = 1,
                        ["id"] = "1690559589",
                        ["itemLink"] = 852,
                    },
                    [2] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 671,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633045366,
                        ["quant"] = 1,
                        ["id"] = "1690559609",
                        ["itemLink"] = 852,
                    },
                    [3] = 
                    {
                        ["price"] = 3700,
                        ["guild"] = 1,
                        ["buyer"] = 774,
                        ["wasKiosk"] = true,
                        ["seller"] = 660,
                        ["timestamp"] = 1633058249,
                        ["quant"] = 1,
                        ["id"] = "1690692669",
                        ["itemLink"] = 852,
                    },
                    [4] = 
                    {
                        ["price"] = 12500,
                        ["guild"] = 1,
                        ["buyer"] = 860,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633074444,
                        ["quant"] = 1,
                        ["id"] = "1690807363",
                        ["itemLink"] = 852,
                    },
                    [5] = 
                    {
                        ["price"] = 2355,
                        ["guild"] = 1,
                        ["buyer"] = 646,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633198100,
                        ["quant"] = 1,
                        ["id"] = "1691770165",
                        ["itemLink"] = 852,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set deadlands assassin ring robust",
            },
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Ring",
                ["oldestTime"] = 1633074441,
                ["wasAltered"] = true,
                ["newestTime"] = 1633302450,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3050,
                        ["guild"] = 1,
                        ["buyer"] = 860,
                        ["wasKiosk"] = true,
                        ["seller"] = 492,
                        ["timestamp"] = 1633074441,
                        ["quant"] = 1,
                        ["id"] = "1690807333",
                        ["itemLink"] = 1104,
                    },
                    [2] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 1369,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633180963,
                        ["quant"] = 1,
                        ["id"] = "1691592177",
                        ["itemLink"] = 1104,
                    },
                    [3] = 
                    {
                        ["price"] = 660,
                        ["guild"] = 1,
                        ["buyer"] = 1369,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1633180967,
                        ["quant"] = 1,
                        ["id"] = "1691592235",
                        ["itemLink"] = 1104,
                    },
                    [4] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 1389,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633185044,
                        ["quant"] = 1,
                        ["id"] = "1691629469",
                        ["itemLink"] = 1104,
                    },
                    [5] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633218686,
                        ["quant"] = 1,
                        ["id"] = "1691997593",
                        ["itemLink"] = 1104,
                    },
                    [6] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1813,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633249719,
                        ["quant"] = 1,
                        ["id"] = "1692268813",
                        ["itemLink"] = 1104,
                    },
                    [7] = 
                    {
                        ["price"] = 975,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 190,
                        ["timestamp"] = 1633291164,
                        ["quant"] = 1,
                        ["id"] = "1692640367",
                        ["itemLink"] = 1104,
                    },
                    [8] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2051,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633302450,
                        ["quant"] = 1,
                        ["id"] = "1692766055",
                        ["itemLink"] = 1104,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set deadlands assassin ring robust",
            },
            ["50:16:2:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Ring",
                ["oldestTime"] = 1632994946,
                ["wasAltered"] = true,
                ["newestTime"] = 1633204861,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 353,
                        ["timestamp"] = 1632994946,
                        ["quant"] = 1,
                        ["id"] = "1690210061",
                        ["itemLink"] = 376,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 959,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633103208,
                        ["quant"] = 1,
                        ["id"] = "1690985781",
                        ["itemLink"] = 376,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1518,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633204861,
                        ["quant"] = 1,
                        ["id"] = "1691840789",
                        ["itemLink"] = 376,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set deadlands assassin ring robust",
            },
        },
        [43610] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Rivenspire Treasure Map IV",
                ["oldestTime"] = 1632999570,
                ["wasAltered"] = true,
                ["newestTime"] = 1633149353,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 392,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1632999570,
                        ["quant"] = 1,
                        ["id"] = "1690231205",
                        ["itemLink"] = 394,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1250,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633149353,
                        ["quant"] = 1,
                        ["id"] = "1691385369",
                        ["itemLink"] = 394,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [45147] = 
        {
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_medium_feet_d.dds",
                ["itemDesc"] = "Rubedo Leather Boots of Stamina",
                ["oldestTime"] = 1633023000,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023021,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 110,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633023000,
                        ["quant"] = 1,
                        ["id"] = "1690390561",
                        ["itemLink"] = 624,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633023021,
                        ["quant"] = 1,
                        ["id"] = "1690390843",
                        ["itemLink"] = 645,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine medium apparel feet well-fitted",
            },
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_medium_feet_d.dds",
                ["itemDesc"] = "Rubedo Leather Boots of Magicka",
                ["oldestTime"] = 1633023010,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023010,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633023010,
                        ["quant"] = 1,
                        ["id"] = "1690390683",
                        ["itemLink"] = 633,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel feet well-fitted",
            },
            ["50:16:1:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_medium_feet_a.dds",
                ["itemDesc"] = "Rubedo Leather Boots",
                ["oldestTime"] = 1633023028,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023028,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633023028,
                        ["quant"] = 1,
                        ["id"] = "1690390889",
                        ["itemLink"] = 652,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal medium apparel feet well-fitted",
            },
        },
        [43612] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Rivenspire Treasure Map VI",
                ["oldestTime"] = 1633115984,
                ["wasAltered"] = true,
                ["newestTime"] = 1633115984,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1024,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633115984,
                        ["quant"] = 1,
                        ["id"] = "1691078749",
                        ["itemLink"] = 1408,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [139615] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_jewelry_3.dds",
                ["itemDesc"] = "Sketch: Alinor Chalice, Ornate",
                ["oldestTime"] = 1632888246,
                ["wasAltered"] = true,
                ["newestTime"] = 1633123015,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1066,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633123015,
                        ["quant"] = 1,
                        ["id"] = "1691127303",
                        ["itemLink"] = 1456,
                    },
                    [2] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 2360,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632888246,
                        ["quant"] = 1,
                        ["id"] = "1689480829",
                        ["itemLink"] = 1456,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45152] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_medium_waist_d.dds",
                ["itemDesc"] = "Rubedo Leather Belt of Magicka",
                ["oldestTime"] = 1633023011,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023011,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 340,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633023011,
                        ["quant"] = 1,
                        ["id"] = "1690390695",
                        ["itemLink"] = 634,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel waist well-fitted",
            },
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_medium_waist_d.dds",
                ["itemDesc"] = "Rubedo Leather Belt of Health",
                ["oldestTime"] = 1633023022,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023023,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633023022,
                        ["quant"] = 1,
                        ["id"] = "1690390847",
                        ["itemLink"] = 646,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633023023,
                        ["quant"] = 1,
                        ["id"] = "1690390859",
                        ["itemLink"] = 647,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine medium apparel waist well-fitted",
            },
        },
        [175969] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing2.dds",
                ["itemDesc"] = "Diagram: Leyawiin Lantern, Stationary",
                ["oldestTime"] = 1632882186,
                ["wasAltered"] = true,
                ["newestTime"] = 1633272472,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1091,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633127251,
                        ["quant"] = 1,
                        ["id"] = "1691160687",
                        ["itemLink"] = 1493,
                    },
                    [2] = 
                    {
                        ["price"] = 395,
                        ["guild"] = 1,
                        ["buyer"] = 1643,
                        ["wasKiosk"] = true,
                        ["seller"] = 911,
                        ["timestamp"] = 1633272472,
                        ["quant"] = 1,
                        ["id"] = "1692431803",
                        ["itemLink"] = 1493,
                    },
                    [3] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2365,
                        ["wasKiosk"] = true,
                        ["seller"] = 100,
                        ["timestamp"] = 1632882186,
                        ["quant"] = 1,
                        ["id"] = "1689420379",
                        ["itemLink"] = 1493,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [69218] = 
        {
            ["50:16:4:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_d.dds",
                ["itemDesc"] = "Inferno Staff of Willpower",
                ["oldestTime"] = 1633110958,
                ["wasAltered"] = true,
                ["newestTime"] = 1633110958,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 899,
                        ["guild"] = 1,
                        ["buyer"] = 983,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633110958,
                        ["quant"] = 1,
                        ["id"] = "1691043375",
                        ["itemLink"] = 1326,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set willpower flame staff two-handed decisive",
            },
            ["23:0:4:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_staff_b.dds",
                ["itemDesc"] = "Inferno Staff of Willpower",
                ["oldestTime"] = 1632921256,
                ["wasAltered"] = true,
                ["newestTime"] = 1632921256,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2487,
                        ["wasKiosk"] = true,
                        ["seller"] = 529,
                        ["timestamp"] = 1632921256,
                        ["quant"] = 1,
                        ["id"] = "1689659541",
                        ["itemLink"] = 3655,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr23 purple epic weapon set willpower flame staff two-handed decisive",
            },
        },
        [68195] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Hearty Garlic Corn Chowder",
                ["oldestTime"] = 1632840217,
                ["wasAltered"] = true,
                ["newestTime"] = 1633307811,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20,
                        ["guild"] = 1,
                        ["buyer"] = 1330,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633167654,
                        ["quant"] = 1,
                        ["id"] = "1691508553",
                        ["itemLink"] = 1869,
                    },
                    [2] = 
                    {
                        ["price"] = 27,
                        ["guild"] = 1,
                        ["buyer"] = 184,
                        ["wasKiosk"] = true,
                        ["seller"] = 78,
                        ["timestamp"] = 1633244954,
                        ["quant"] = 1,
                        ["id"] = "1692233423",
                        ["itemLink"] = 1869,
                    },
                    [3] = 
                    {
                        ["price"] = 86,
                        ["guild"] = 1,
                        ["buyer"] = 1262,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1633307811,
                        ["quant"] = 1,
                        ["id"] = "1692821301",
                        ["itemLink"] = 1869,
                    },
                    [4] = 
                    {
                        ["price"] = 27,
                        ["guild"] = 1,
                        ["buyer"] = 2175,
                        ["wasKiosk"] = true,
                        ["seller"] = 78,
                        ["timestamp"] = 1632840217,
                        ["quant"] = 1,
                        ["id"] = "1689061555",
                        ["itemLink"] = 1869,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [160613] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 88: Ancestral Orc Boots",
                ["oldestTime"] = 1632906319,
                ["wasAltered"] = true,
                ["newestTime"] = 1633161533,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1310,
                        ["wasKiosk"] = true,
                        ["seller"] = 1214,
                        ["timestamp"] = 1633161533,
                        ["quant"] = 1,
                        ["id"] = "1691474019",
                        ["itemLink"] = 1791,
                    },
                    [2] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 2453,
                        ["wasKiosk"] = true,
                        ["seller"] = 894,
                        ["timestamp"] = 1632906319,
                        ["quant"] = 1,
                        ["id"] = "1689588235",
                        ["itemLink"] = 1791,
                    },
                    [3] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 1381,
                        ["wasKiosk"] = true,
                        ["seller"] = 269,
                        ["timestamp"] = 1632911829,
                        ["quant"] = 1,
                        ["id"] = "1689607761",
                        ["itemLink"] = 1791,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45158] = 
        {
            ["50:16:2:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_1haxe_d.dds",
                ["itemDesc"] = "Rubedite Axe of Shock",
                ["oldestTime"] = 1633094740,
                ["wasAltered"] = true,
                ["newestTime"] = 1633094740,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 63,
                        ["wasKiosk"] = false,
                        ["seller"] = 257,
                        ["timestamp"] = 1633094740,
                        ["quant"] = 1,
                        ["id"] = "1690917415",
                        ["itemLink"] = 1249,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon axe one-handed defending",
            },
        },
        [117096] = 
        {
            ["50:16:4:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_bow_a.dds",
                ["itemDesc"] = "Bow of the Powerful Assault",
                ["oldestTime"] = 1632885917,
                ["wasAltered"] = true,
                ["newestTime"] = 1632885917,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 2391,
                        ["wasKiosk"] = true,
                        ["seller"] = 145,
                        ["timestamp"] = 1632885917,
                        ["quant"] = 1,
                        ["id"] = "1689462129",
                        ["itemLink"] = 3519,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set powerful assault bow two-handed infused",
            },
        },
        [45929] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Chorrol Corn on the Cob",
                ["oldestTime"] = 1632965168,
                ["wasAltered"] = true,
                ["newestTime"] = 1632965168,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 2,
                        ["buyer"] = 134,
                        ["wasKiosk"] = false,
                        ["seller"] = 117,
                        ["timestamp"] = 1632965168,
                        ["quant"] = 1,
                        ["id"] = "1690008067",
                        ["itemLink"] = 144,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [167274] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 94: Ancestral Reach Bows",
                ["oldestTime"] = 1632967242,
                ["wasAltered"] = true,
                ["newestTime"] = 1632967242,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 2667,
                        ["wasKiosk"] = true,
                        ["seller"] = 514,
                        ["timestamp"] = 1632967242,
                        ["quant"] = 1,
                        ["id"] = "1690026829",
                        ["itemLink"] = 3973,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [142187] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 68: Honor Guard Axes",
                ["oldestTime"] = 1633106700,
                ["wasAltered"] = true,
                ["newestTime"] = 1633106700,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 970,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633106700,
                        ["quant"] = 1,
                        ["id"] = "1691013357",
                        ["itemLink"] = 1302,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [27244] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_book_001.dds",
                ["itemDesc"] = "Crafting Motif 4: Nord Style",
                ["oldestTime"] = 1632820722,
                ["wasAltered"] = true,
                ["newestTime"] = 1633229581,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 484,
                        ["wasKiosk"] = true,
                        ["seller"] = 492,
                        ["timestamp"] = 1633017928,
                        ["quant"] = 1,
                        ["id"] = "1690348933",
                        ["itemLink"] = 562,
                    },
                    [2] = 
                    {
                        ["price"] = 362,
                        ["guild"] = 1,
                        ["buyer"] = 1681,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633229581,
                        ["quant"] = 1,
                        ["id"] = "1692111387",
                        ["itemLink"] = 562,
                    },
                    [3] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 2103,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632820722,
                        ["quant"] = 1,
                        ["id"] = "1688947309",
                        ["itemLink"] = 562,
                    },
                    [4] = 
                    {
                        ["price"] = 241,
                        ["guild"] = 1,
                        ["buyer"] = 2103,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1632820726,
                        ["quant"] = 1,
                        ["id"] = "1688947355",
                        ["itemLink"] = 562,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior consumable motif",
            },
        },
        [175981] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Divider, Sturdy",
                ["oldestTime"] = 1633058546,
                ["wasAltered"] = true,
                ["newestTime"] = 1633179515,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 425,
                        ["guild"] = 1,
                        ["buyer"] = 776,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1633058546,
                        ["quant"] = 1,
                        ["id"] = "1690695639",
                        ["itemLink"] = 989,
                    },
                    [2] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 655,
                        ["wasKiosk"] = false,
                        ["seller"] = 911,
                        ["timestamp"] = 1633091043,
                        ["quant"] = 1,
                        ["id"] = "1690894565",
                        ["itemLink"] = 989,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1091,
                        ["wasKiosk"] = true,
                        ["seller"] = 625,
                        ["timestamp"] = 1633127228,
                        ["quant"] = 1,
                        ["id"] = "1691160379",
                        ["itemLink"] = 989,
                    },
                    [4] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1362,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633179515,
                        ["quant"] = 1,
                        ["id"] = "1691583111",
                        ["itemLink"] = 989,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [167279] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 94: Ancestral Reach Legs",
                ["oldestTime"] = 1632960696,
                ["wasAltered"] = true,
                ["newestTime"] = 1632960696,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 119000,
                        ["guild"] = 1,
                        ["buyer"] = 2417,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632960696,
                        ["quant"] = 1,
                        ["id"] = "1689965493",
                        ["itemLink"] = 3922,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [171889] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 103: Black Fin Legion Shields",
                ["oldestTime"] = 1633073491,
                ["wasAltered"] = true,
                ["newestTime"] = 1633073491,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 49995,
                        ["guild"] = 1,
                        ["buyer"] = 854,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1633073491,
                        ["quant"] = 1,
                        ["id"] = "1690800597",
                        ["itemLink"] = 1101,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [115827] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Argonian Bark, Painted",
                ["oldestTime"] = 1633292303,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292303,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633292303,
                        ["quant"] = 1,
                        ["id"] = "1692655053",
                        ["itemLink"] = 2819,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [172404] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_hvy_head_a.dds",
                ["itemDesc"] = "Bog Raider's Helm",
                ["oldestTime"] = 1633083034,
                ["wasAltered"] = true,
                ["newestTime"] = 1633083034,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 360,
                        ["guild"] = 1,
                        ["buyer"] = 889,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633083034,
                        ["quant"] = 1,
                        ["id"] = "1690850395",
                        ["itemLink"] = 1139,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set bog raider head invigorating",
            },
        },
        [165749] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_inc_toolscraper001.dds",
                ["itemDesc"] = "Solitude Scraper, Simple",
                ["oldestTime"] = 1632888113,
                ["wasAltered"] = true,
                ["newestTime"] = 1632888113,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2404,
                        ["wasKiosk"] = true,
                        ["seller"] = 17,
                        ["timestamp"] = 1632888113,
                        ["quant"] = 1,
                        ["id"] = "1689479705",
                        ["itemLink"] = 3526,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings workshop",
            },
        },
        [126840] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_alchemy4.dds",
                ["itemDesc"] = "Formula: Daedric Brazier, Table",
                ["oldestTime"] = 1632913344,
                ["wasAltered"] = true,
                ["newestTime"] = 1632958151,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 499,
                        ["guild"] = 1,
                        ["buyer"] = 1361,
                        ["wasKiosk"] = true,
                        ["seller"] = 283,
                        ["timestamp"] = 1632913344,
                        ["quant"] = 1,
                        ["id"] = "1689614041",
                        ["itemLink"] = 3629,
                    },
                    [2] = 
                    {
                        ["price"] = 499,
                        ["guild"] = 1,
                        ["buyer"] = 2619,
                        ["wasKiosk"] = true,
                        ["seller"] = 283,
                        ["timestamp"] = 1632958151,
                        ["quant"] = 1,
                        ["id"] = "1689945215",
                        ["itemLink"] = 3629,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [126841] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_alchemy4.dds",
                ["itemDesc"] = "Formula: Daedric Brazier, Standing",
                ["oldestTime"] = 1633014709,
                ["wasAltered"] = true,
                ["newestTime"] = 1633266507,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 699,
                        ["guild"] = 1,
                        ["buyer"] = 467,
                        ["wasKiosk"] = true,
                        ["seller"] = 283,
                        ["timestamp"] = 1633014709,
                        ["quant"] = 1,
                        ["id"] = "1690323643",
                        ["itemLink"] = 534,
                    },
                    [2] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1857,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633266507,
                        ["quant"] = 1,
                        ["id"] = "1692371483",
                        ["itemLink"] = 534,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [56959] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Orcish No-Rhubarb Salad",
                ["oldestTime"] = 1632865318,
                ["wasAltered"] = true,
                ["newestTime"] = 1633122926,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1069,
                        ["guild"] = 1,
                        ["buyer"] = 1066,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633122926,
                        ["quant"] = 1,
                        ["id"] = "1691126835",
                        ["itemLink"] = 1450,
                    },
                    [2] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 2261,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632865318,
                        ["quant"] = 1,
                        ["id"] = "1689266927",
                        ["itemLink"] = 1450,
                    },
                    [3] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 2641,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632962374,
                        ["quant"] = 1,
                        ["id"] = "1689978551",
                        ["itemLink"] = 1450,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [95616] = 
        {
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_light_hands_a.dds",
                ["itemDesc"] = "Gloves of Martial Knowledge",
                ["oldestTime"] = 1633114510,
                ["wasAltered"] = true,
                ["newestTime"] = 1633114510,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1013,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633114510,
                        ["quant"] = 1,
                        ["id"] = "1691069425",
                        ["itemLink"] = 1382,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set way of martial knowledge hands training",
            },
        },
        [43650] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Reaper's March Treasure Map II",
                ["oldestTime"] = 1633251754,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310220,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1822,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633251754,
                        ["quant"] = 1,
                        ["id"] = "1692282889",
                        ["itemLink"] = 2607,
                    },
                    [2] = 
                    {
                        ["price"] = 428,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633310220,
                        ["quant"] = 1,
                        ["id"] = "1692851211",
                        ["itemLink"] = 2607,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [43657] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Stonefalls Treasure Map III",
                ["oldestTime"] = 1632825709,
                ["wasAltered"] = true,
                ["newestTime"] = 1633115977,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1024,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633115977,
                        ["quant"] = 1,
                        ["id"] = "1691078649",
                        ["itemLink"] = 1407,
                    },
                    [2] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2117,
                        ["wasKiosk"] = true,
                        ["seller"] = 86,
                        ["timestamp"] = 1632825709,
                        ["quant"] = 1,
                        ["id"] = "1688967757",
                        ["itemLink"] = 1407,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [166796] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Solitude Rug, Plain",
                ["oldestTime"] = 1633240437,
                ["wasAltered"] = true,
                ["newestTime"] = 1633240437,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1772,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633240437,
                        ["quant"] = 1,
                        ["id"] = "1692201129",
                        ["itemLink"] = 2531,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [43662] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Deshaan Treasure Map II",
                ["oldestTime"] = 1632999547,
                ["wasAltered"] = true,
                ["newestTime"] = 1632999547,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 392,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1632999547,
                        ["quant"] = 1,
                        ["id"] = "1690231009",
                        ["itemLink"] = 392,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [176018] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Plate, Set",
                ["oldestTime"] = 1633179509,
                ["wasAltered"] = true,
                ["newestTime"] = 1633179509,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1362,
                        ["wasKiosk"] = true,
                        ["seller"] = 1108,
                        ["timestamp"] = 1633179509,
                        ["quant"] = 1,
                        ["id"] = "1691583071",
                        ["itemLink"] = 1916,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [166043] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Western Skyrim Treasure Map IV",
                ["oldestTime"] = 1633173235,
                ["wasAltered"] = true,
                ["newestTime"] = 1633240061,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1347,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633173235,
                        ["quant"] = 1,
                        ["id"] = "1691536655",
                        ["itemLink"] = 1891,
                    },
                    [2] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1765,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633240061,
                        ["quant"] = 1,
                        ["id"] = "1692197619",
                        ["itemLink"] = 1891,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [172444] = 
        {
            ["50:16:2:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_hvy_head_a.dds",
                ["itemDesc"] = "Bog Raider's Helm",
                ["oldestTime"] = 1633096649,
                ["wasAltered"] = true,
                ["newestTime"] = 1633096649,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 664,
                        ["guild"] = 1,
                        ["buyer"] = 931,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1633096649,
                        ["quant"] = 1,
                        ["id"] = "1690933637",
                        ["itemLink"] = 1266,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set bog raider head training",
            },
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_hvy_head_a.dds",
                ["itemDesc"] = "Bog Raider's Helm",
                ["oldestTime"] = 1633053002,
                ["wasAltered"] = true,
                ["newestTime"] = 1633053002,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 716,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633053002,
                        ["quant"] = 1,
                        ["id"] = "1690635887",
                        ["itemLink"] = 927,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set bog raider head training",
            },
        },
        [166813] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Solitude Bench, Sturdy",
                ["oldestTime"] = 1633240436,
                ["wasAltered"] = true,
                ["newestTime"] = 1633240436,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1772,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633240436,
                        ["quant"] = 1,
                        ["id"] = "1692201117",
                        ["itemLink"] = 2530,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [68254] = 
        {
            ["50:15:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_dom_stew_002.dds",
                ["itemDesc"] = "Withered Tree Inn Venison Pot Roast",
                ["oldestTime"] = 1632914872,
                ["wasAltered"] = true,
                ["newestTime"] = 1632914872,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 2473,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1632914872,
                        ["quant"] = 100,
                        ["id"] = "1689622633",
                        ["itemLink"] = 3638,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 purple epic consumable food",
            },
        },
        [167327] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_str_bridgefoot001.dds",
                ["itemDesc"] = "Solitude Foot Bridge, Wood-Planked",
                ["oldestTime"] = 1632984816,
                ["wasAltered"] = true,
                ["newestTime"] = 1632984816,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 310,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1632984816,
                        ["quant"] = 2,
                        ["id"] = "1690158923",
                        ["itemLink"] = 315,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings structures",
            },
        },
        [54177] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_outfitter_potion_014.dds",
                ["itemDesc"] = "Dreugh Wax",
                ["oldestTime"] = 1632824960,
                ["wasAltered"] = true,
                ["newestTime"] = 1633316245,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8250,
                        ["guild"] = 1,
                        ["buyer"] = 284,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1632981995,
                        ["quant"] = 1,
                        ["id"] = "1690141587",
                        ["itemLink"] = 293,
                    },
                    [2] = 
                    {
                        ["price"] = 241800,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1632986547,
                        ["quant"] = 13,
                        ["id"] = "1690167489",
                        ["itemLink"] = 293,
                    },
                    [3] = 
                    {
                        ["price"] = 297600,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1632986550,
                        ["quant"] = 16,
                        ["id"] = "1690167495",
                        ["itemLink"] = 293,
                    },
                    [4] = 
                    {
                        ["price"] = 297600,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1632986551,
                        ["quant"] = 16,
                        ["id"] = "1690167497",
                        ["itemLink"] = 293,
                    },
                    [5] = 
                    {
                        ["price"] = 297600,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1632986554,
                        ["quant"] = 16,
                        ["id"] = "1690167503",
                        ["itemLink"] = 293,
                    },
                    [6] = 
                    {
                        ["price"] = 297600,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1632986555,
                        ["quant"] = 16,
                        ["id"] = "1690167505",
                        ["itemLink"] = 293,
                    },
                    [7] = 
                    {
                        ["price"] = 297600,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1632986558,
                        ["quant"] = 16,
                        ["id"] = "1690167511",
                        ["itemLink"] = 293,
                    },
                    [8] = 
                    {
                        ["price"] = 76000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632986564,
                        ["quant"] = 4,
                        ["id"] = "1690167533",
                        ["itemLink"] = 293,
                    },
                    [9] = 
                    {
                        ["price"] = 38009,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632986567,
                        ["quant"] = 2,
                        ["id"] = "1690167541",
                        ["itemLink"] = 293,
                    },
                    [10] = 
                    {
                        ["price"] = 38009,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632986569,
                        ["quant"] = 2,
                        ["id"] = "1690167543",
                        ["itemLink"] = 293,
                    },
                    [11] = 
                    {
                        ["price"] = 19000,
                        ["guild"] = 1,
                        ["buyer"] = 363,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1632992727,
                        ["quant"] = 1,
                        ["id"] = "1690199621",
                        ["itemLink"] = 293,
                    },
                    [12] = 
                    {
                        ["price"] = 38000,
                        ["guild"] = 1,
                        ["buyer"] = 363,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1632992728,
                        ["quant"] = 2,
                        ["id"] = "1690199633",
                        ["itemLink"] = 293,
                    },
                    [13] = 
                    {
                        ["price"] = 350000,
                        ["guild"] = 1,
                        ["buyer"] = 628,
                        ["wasKiosk"] = true,
                        ["seller"] = 43,
                        ["timestamp"] = 1633040773,
                        ["quant"] = 20,
                        ["id"] = "1690519161",
                        ["itemLink"] = 293,
                    },
                    [14] = 
                    {
                        ["price"] = 76000,
                        ["guild"] = 1,
                        ["buyer"] = 804,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633063705,
                        ["quant"] = 4,
                        ["id"] = "1690738725",
                        ["itemLink"] = 293,
                    },
                    [15] = 
                    {
                        ["price"] = 37996,
                        ["guild"] = 1,
                        ["buyer"] = 804,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633063709,
                        ["quant"] = 2,
                        ["id"] = "1690738757",
                        ["itemLink"] = 293,
                    },
                    [16] = 
                    {
                        ["price"] = 37996,
                        ["guild"] = 1,
                        ["buyer"] = 804,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633063711,
                        ["quant"] = 2,
                        ["id"] = "1690738777",
                        ["itemLink"] = 293,
                    },
                    [17] = 
                    {
                        ["price"] = 38160,
                        ["guild"] = 1,
                        ["buyer"] = 837,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633069722,
                        ["quant"] = 2,
                        ["id"] = "1690776723",
                        ["itemLink"] = 293,
                    },
                    [18] = 
                    {
                        ["price"] = 38160,
                        ["guild"] = 1,
                        ["buyer"] = 837,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633069725,
                        ["quant"] = 2,
                        ["id"] = "1690776739",
                        ["itemLink"] = 293,
                    },
                    [19] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 841,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633071012,
                        ["quant"] = 1,
                        ["id"] = "1690783783",
                        ["itemLink"] = 293,
                    },
                    [20] = 
                    {
                        ["price"] = 77200,
                        ["guild"] = 1,
                        ["buyer"] = 898,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633085002,
                        ["quant"] = 4,
                        ["id"] = "1690858525",
                        ["itemLink"] = 293,
                    },
                    [21] = 
                    {
                        ["price"] = 77200,
                        ["guild"] = 1,
                        ["buyer"] = 898,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633085003,
                        ["quant"] = 4,
                        ["id"] = "1690858527",
                        ["itemLink"] = 293,
                    },
                    [22] = 
                    {
                        ["price"] = 38800,
                        ["guild"] = 1,
                        ["buyer"] = 898,
                        ["wasKiosk"] = true,
                        ["seller"] = 732,
                        ["timestamp"] = 1633085004,
                        ["quant"] = 2,
                        ["id"] = "1690858531",
                        ["itemLink"] = 293,
                    },
                    [23] = 
                    {
                        ["price"] = 18980,
                        ["guild"] = 1,
                        ["buyer"] = 1121,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633132760,
                        ["quant"] = 1,
                        ["id"] = "1691216429",
                        ["itemLink"] = 293,
                    },
                    [24] = 
                    {
                        ["price"] = 19101,
                        ["guild"] = 1,
                        ["buyer"] = 1121,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633132762,
                        ["quant"] = 1,
                        ["id"] = "1691216461",
                        ["itemLink"] = 293,
                    },
                    [25] = 
                    {
                        ["price"] = 165000,
                        ["guild"] = 1,
                        ["buyer"] = 1162,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633137205,
                        ["quant"] = 10,
                        ["id"] = "1691264047",
                        ["itemLink"] = 293,
                    },
                    [26] = 
                    {
                        ["price"] = 165000,
                        ["guild"] = 1,
                        ["buyer"] = 1162,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633137205,
                        ["quant"] = 10,
                        ["id"] = "1691264051",
                        ["itemLink"] = 293,
                    },
                    [27] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1162,
                        ["wasKiosk"] = true,
                        ["seller"] = 6,
                        ["timestamp"] = 1633137206,
                        ["quant"] = 3,
                        ["id"] = "1691264065",
                        ["itemLink"] = 293,
                    },
                    [28] = 
                    {
                        ["price"] = 949999,
                        ["guild"] = 1,
                        ["buyer"] = 1199,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633142208,
                        ["quant"] = 50,
                        ["id"] = "1691315627",
                        ["itemLink"] = 293,
                    },
                    [29] = 
                    {
                        ["price"] = 188990,
                        ["guild"] = 1,
                        ["buyer"] = 582,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1633142789,
                        ["quant"] = 10,
                        ["id"] = "1691322865",
                        ["itemLink"] = 293,
                    },
                    [30] = 
                    {
                        ["price"] = 38000,
                        ["guild"] = 1,
                        ["buyer"] = 1212,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633143238,
                        ["quant"] = 2,
                        ["id"] = "1691328113",
                        ["itemLink"] = 293,
                    },
                    [31] = 
                    {
                        ["price"] = 148000,
                        ["guild"] = 1,
                        ["buyer"] = 1225,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633144954,
                        ["quant"] = 8,
                        ["id"] = "1691346787",
                        ["itemLink"] = 293,
                    },
                    [32] = 
                    {
                        ["price"] = 37000,
                        ["guild"] = 1,
                        ["buyer"] = 1225,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633144963,
                        ["quant"] = 2,
                        ["id"] = "1691346845",
                        ["itemLink"] = 293,
                    },
                    [33] = 
                    {
                        ["price"] = 37000,
                        ["guild"] = 1,
                        ["buyer"] = 1225,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633144966,
                        ["quant"] = 2,
                        ["id"] = "1691346851",
                        ["itemLink"] = 293,
                    },
                    [34] = 
                    {
                        ["price"] = 37000,
                        ["guild"] = 1,
                        ["buyer"] = 1225,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633144971,
                        ["quant"] = 2,
                        ["id"] = "1691346875",
                        ["itemLink"] = 293,
                    },
                    [35] = 
                    {
                        ["price"] = 189000,
                        ["guild"] = 1,
                        ["buyer"] = 1225,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633144979,
                        ["quant"] = 10,
                        ["id"] = "1691346925",
                        ["itemLink"] = 293,
                    },
                    [36] = 
                    {
                        ["price"] = 189000,
                        ["guild"] = 1,
                        ["buyer"] = 1225,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633144989,
                        ["quant"] = 10,
                        ["id"] = "1691346975",
                        ["itemLink"] = 293,
                    },
                    [37] = 
                    {
                        ["price"] = 189000,
                        ["guild"] = 1,
                        ["buyer"] = 954,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633146341,
                        ["quant"] = 10,
                        ["id"] = "1691359761",
                        ["itemLink"] = 293,
                    },
                    [38] = 
                    {
                        ["price"] = 18500,
                        ["guild"] = 1,
                        ["buyer"] = 1271,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633153521,
                        ["quant"] = 1,
                        ["id"] = "1691419639",
                        ["itemLink"] = 293,
                    },
                    [39] = 
                    {
                        ["price"] = 18500,
                        ["guild"] = 1,
                        ["buyer"] = 1271,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633153524,
                        ["quant"] = 1,
                        ["id"] = "1691419661",
                        ["itemLink"] = 293,
                    },
                    [40] = 
                    {
                        ["price"] = 189500,
                        ["guild"] = 1,
                        ["buyer"] = 1271,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633153531,
                        ["quant"] = 10,
                        ["id"] = "1691419733",
                        ["itemLink"] = 293,
                    },
                    [41] = 
                    {
                        ["price"] = 18550,
                        ["guild"] = 1,
                        ["buyer"] = 1414,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1633189556,
                        ["quant"] = 1,
                        ["id"] = "1691684999",
                        ["itemLink"] = 293,
                    },
                    [42] = 
                    {
                        ["price"] = 18550,
                        ["guild"] = 1,
                        ["buyer"] = 1414,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1633189557,
                        ["quant"] = 1,
                        ["id"] = "1691685013",
                        ["itemLink"] = 293,
                    },
                    [43] = 
                    {
                        ["price"] = 18550,
                        ["guild"] = 1,
                        ["buyer"] = 1414,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1633189558,
                        ["quant"] = 1,
                        ["id"] = "1691685021",
                        ["itemLink"] = 293,
                    },
                    [44] = 
                    {
                        ["price"] = 18550,
                        ["guild"] = 1,
                        ["buyer"] = 1414,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1633189558,
                        ["quant"] = 1,
                        ["id"] = "1691685035",
                        ["itemLink"] = 293,
                    },
                    [45] = 
                    {
                        ["price"] = 18550,
                        ["guild"] = 1,
                        ["buyer"] = 1414,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1633189559,
                        ["quant"] = 1,
                        ["id"] = "1691685047",
                        ["itemLink"] = 293,
                    },
                    [46] = 
                    {
                        ["price"] = 38800,
                        ["guild"] = 1,
                        ["buyer"] = 1419,
                        ["wasKiosk"] = true,
                        ["seller"] = 590,
                        ["timestamp"] = 1633190916,
                        ["quant"] = 2,
                        ["id"] = "1691698727",
                        ["itemLink"] = 293,
                    },
                    [47] = 
                    {
                        ["price"] = 38800,
                        ["guild"] = 1,
                        ["buyer"] = 1419,
                        ["wasKiosk"] = true,
                        ["seller"] = 590,
                        ["timestamp"] = 1633190918,
                        ["quant"] = 2,
                        ["id"] = "1691698751",
                        ["itemLink"] = 293,
                    },
                    [48] = 
                    {
                        ["price"] = 378000,
                        ["guild"] = 1,
                        ["buyer"] = 1443,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633194480,
                        ["quant"] = 20,
                        ["id"] = "1691738283",
                        ["itemLink"] = 293,
                    },
                    [49] = 
                    {
                        ["price"] = 175000,
                        ["guild"] = 1,
                        ["buyer"] = 1460,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633196811,
                        ["quant"] = 10,
                        ["id"] = "1691756719",
                        ["itemLink"] = 293,
                    },
                    [50] = 
                    {
                        ["price"] = 175000,
                        ["guild"] = 1,
                        ["buyer"] = 1460,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633196832,
                        ["quant"] = 10,
                        ["id"] = "1691756855",
                        ["itemLink"] = 293,
                    },
                    [51] = 
                    {
                        ["price"] = 148800,
                        ["guild"] = 1,
                        ["buyer"] = 1478,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633199528,
                        ["quant"] = 8,
                        ["id"] = "1691784569",
                        ["itemLink"] = 293,
                    },
                    [52] = 
                    {
                        ["price"] = 223200,
                        ["guild"] = 1,
                        ["buyer"] = 1478,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633199539,
                        ["quant"] = 12,
                        ["id"] = "1691784641",
                        ["itemLink"] = 293,
                    },
                    [53] = 
                    {
                        ["price"] = 223200,
                        ["guild"] = 1,
                        ["buyer"] = 1478,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633199547,
                        ["quant"] = 12,
                        ["id"] = "1691784683",
                        ["itemLink"] = 293,
                    },
                    [54] = 
                    {
                        ["price"] = 152000,
                        ["guild"] = 1,
                        ["buyer"] = 1478,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633199550,
                        ["quant"] = 8,
                        ["id"] = "1691784713",
                        ["itemLink"] = 293,
                    },
                    [55] = 
                    {
                        ["price"] = 189000,
                        ["guild"] = 1,
                        ["buyer"] = 476,
                        ["wasKiosk"] = false,
                        ["seller"] = 35,
                        ["timestamp"] = 1633200183,
                        ["quant"] = 10,
                        ["id"] = "1691792203",
                        ["itemLink"] = 293,
                    },
                    [56] = 
                    {
                        ["price"] = 223200,
                        ["guild"] = 1,
                        ["buyer"] = 1505,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633203041,
                        ["quant"] = 12,
                        ["id"] = "1691823175",
                        ["itemLink"] = 293,
                    },
                    [57] = 
                    {
                        ["price"] = 223200,
                        ["guild"] = 1,
                        ["buyer"] = 1505,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633203043,
                        ["quant"] = 12,
                        ["id"] = "1691823221",
                        ["itemLink"] = 293,
                    },
                    [58] = 
                    {
                        ["price"] = 223200,
                        ["guild"] = 1,
                        ["buyer"] = 1505,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633203045,
                        ["quant"] = 12,
                        ["id"] = "1691823263",
                        ["itemLink"] = 293,
                    },
                    [59] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 1520,
                        ["wasKiosk"] = true,
                        ["seller"] = 33,
                        ["timestamp"] = 1633205154,
                        ["quant"] = 1,
                        ["id"] = "1691843985",
                        ["itemLink"] = 293,
                    },
                    [60] = 
                    {
                        ["price"] = 147000,
                        ["guild"] = 1,
                        ["buyer"] = 508,
                        ["wasKiosk"] = false,
                        ["seller"] = 75,
                        ["timestamp"] = 1633211219,
                        ["quant"] = 8,
                        ["id"] = "1691917663",
                        ["itemLink"] = 293,
                    },
                    [61] = 
                    {
                        ["price"] = 37000,
                        ["guild"] = 1,
                        ["buyer"] = 508,
                        ["wasKiosk"] = false,
                        ["seller"] = 148,
                        ["timestamp"] = 1633211222,
                        ["quant"] = 2,
                        ["id"] = "1691917729",
                        ["itemLink"] = 293,
                    },
                    [62] = 
                    {
                        ["price"] = 37000,
                        ["guild"] = 1,
                        ["buyer"] = 508,
                        ["wasKiosk"] = false,
                        ["seller"] = 148,
                        ["timestamp"] = 1633211227,
                        ["quant"] = 2,
                        ["id"] = "1691917795",
                        ["itemLink"] = 293,
                    },
                    [63] = 
                    {
                        ["price"] = 37000,
                        ["guild"] = 1,
                        ["buyer"] = 508,
                        ["wasKiosk"] = false,
                        ["seller"] = 148,
                        ["timestamp"] = 1633211232,
                        ["quant"] = 2,
                        ["id"] = "1691917865",
                        ["itemLink"] = 293,
                    },
                    [64] = 
                    {
                        ["price"] = 37000,
                        ["guild"] = 1,
                        ["buyer"] = 508,
                        ["wasKiosk"] = false,
                        ["seller"] = 148,
                        ["timestamp"] = 1633211236,
                        ["quant"] = 2,
                        ["id"] = "1691917949",
                        ["itemLink"] = 293,
                    },
                    [65] = 
                    {
                        ["price"] = 55740,
                        ["guild"] = 1,
                        ["buyer"] = 508,
                        ["wasKiosk"] = false,
                        ["seller"] = 158,
                        ["timestamp"] = 1633211241,
                        ["quant"] = 3,
                        ["id"] = "1691918049",
                        ["itemLink"] = 293,
                    },
                    [66] = 
                    {
                        ["price"] = 36800,
                        ["guild"] = 1,
                        ["buyer"] = 1580,
                        ["wasKiosk"] = true,
                        ["seller"] = 763,
                        ["timestamp"] = 1633214852,
                        ["quant"] = 2,
                        ["id"] = "1691957613",
                        ["itemLink"] = 293,
                    },
                    [67] = 
                    {
                        ["price"] = 188000,
                        ["guild"] = 1,
                        ["buyer"] = 1614,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633221119,
                        ["quant"] = 10,
                        ["id"] = "1692023075",
                        ["itemLink"] = 293,
                    },
                    [68] = 
                    {
                        ["price"] = 188000,
                        ["guild"] = 1,
                        ["buyer"] = 1649,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1633226044,
                        ["quant"] = 10,
                        ["id"] = "1692074581",
                        ["itemLink"] = 293,
                    },
                    [69] = 
                    {
                        ["price"] = 189000,
                        ["guild"] = 1,
                        ["buyer"] = 1649,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633226453,
                        ["quant"] = 10,
                        ["id"] = "1692079577",
                        ["itemLink"] = 293,
                    },
                    [70] = 
                    {
                        ["price"] = 79596,
                        ["guild"] = 1,
                        ["buyer"] = 1655,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633226730,
                        ["quant"] = 4,
                        ["id"] = "1692082673",
                        ["itemLink"] = 293,
                    },
                    [71] = 
                    {
                        ["price"] = 151600,
                        ["guild"] = 1,
                        ["buyer"] = 1663,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633227554,
                        ["quant"] = 8,
                        ["id"] = "1692091151",
                        ["itemLink"] = 293,
                    },
                    [72] = 
                    {
                        ["price"] = 151600,
                        ["guild"] = 1,
                        ["buyer"] = 1663,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633227555,
                        ["quant"] = 8,
                        ["id"] = "1692091169",
                        ["itemLink"] = 293,
                    },
                    [73] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1729,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633235591,
                        ["quant"] = 1,
                        ["id"] = "1692165073",
                        ["itemLink"] = 293,
                    },
                    [74] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1729,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633235595,
                        ["quant"] = 1,
                        ["id"] = "1692165097",
                        ["itemLink"] = 293,
                    },
                    [75] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1729,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633235608,
                        ["quant"] = 1,
                        ["id"] = "1692165179",
                        ["itemLink"] = 293,
                    },
                    [76] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1017,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633236409,
                        ["quant"] = 1,
                        ["id"] = "1692171169",
                        ["itemLink"] = 293,
                    },
                    [77] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1017,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633236409,
                        ["quant"] = 1,
                        ["id"] = "1692171175",
                        ["itemLink"] = 293,
                    },
                    [78] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1017,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633236410,
                        ["quant"] = 1,
                        ["id"] = "1692171185",
                        ["itemLink"] = 293,
                    },
                    [79] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1017,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633236411,
                        ["quant"] = 1,
                        ["id"] = "1692171191",
                        ["itemLink"] = 293,
                    },
                    [80] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1017,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633236411,
                        ["quant"] = 1,
                        ["id"] = "1692171199",
                        ["itemLink"] = 293,
                    },
                    [81] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1017,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633236412,
                        ["quant"] = 1,
                        ["id"] = "1692171205",
                        ["itemLink"] = 293,
                    },
                    [82] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1017,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633236412,
                        ["quant"] = 1,
                        ["id"] = "1692171209",
                        ["itemLink"] = 293,
                    },
                    [83] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1017,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633236413,
                        ["quant"] = 1,
                        ["id"] = "1692171217",
                        ["itemLink"] = 293,
                    },
                    [84] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1017,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633236414,
                        ["quant"] = 1,
                        ["id"] = "1692171229",
                        ["itemLink"] = 293,
                    },
                    [85] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1017,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633236414,
                        ["quant"] = 1,
                        ["id"] = "1692171239",
                        ["itemLink"] = 293,
                    },
                    [86] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1017,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633236415,
                        ["quant"] = 1,
                        ["id"] = "1692171247",
                        ["itemLink"] = 293,
                    },
                    [87] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1017,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633236418,
                        ["quant"] = 1,
                        ["id"] = "1692171257",
                        ["itemLink"] = 293,
                    },
                    [88] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1017,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633236419,
                        ["quant"] = 1,
                        ["id"] = "1692171261",
                        ["itemLink"] = 293,
                    },
                    [89] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1017,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633236422,
                        ["quant"] = 1,
                        ["id"] = "1692171277",
                        ["itemLink"] = 293,
                    },
                    [90] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1017,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633236423,
                        ["quant"] = 1,
                        ["id"] = "1692171291",
                        ["itemLink"] = 293,
                    },
                    [91] = 
                    {
                        ["price"] = 38800,
                        ["guild"] = 1,
                        ["buyer"] = 1381,
                        ["wasKiosk"] = true,
                        ["seller"] = 590,
                        ["timestamp"] = 1633236436,
                        ["quant"] = 2,
                        ["id"] = "1692171453",
                        ["itemLink"] = 293,
                    },
                    [92] = 
                    {
                        ["price"] = 151999,
                        ["guild"] = 1,
                        ["buyer"] = 1738,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633236634,
                        ["quant"] = 8,
                        ["id"] = "1692173073",
                        ["itemLink"] = 293,
                    },
                    [93] = 
                    {
                        ["price"] = 189000,
                        ["guild"] = 1,
                        ["buyer"] = 1753,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633238829,
                        ["quant"] = 10,
                        ["id"] = "1692190213",
                        ["itemLink"] = 293,
                    },
                    [94] = 
                    {
                        ["price"] = 129500,
                        ["guild"] = 1,
                        ["buyer"] = 476,
                        ["wasKiosk"] = false,
                        ["seller"] = 95,
                        ["timestamp"] = 1633246115,
                        ["quant"] = 7,
                        ["id"] = "1692243739",
                        ["itemLink"] = 293,
                    },
                    [95] = 
                    {
                        ["price"] = 286400,
                        ["guild"] = 1,
                        ["buyer"] = 27,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633286190,
                        ["quant"] = 16,
                        ["id"] = "1692579125",
                        ["itemLink"] = 293,
                    },
                    [96] = 
                    {
                        ["price"] = 286400,
                        ["guild"] = 1,
                        ["buyer"] = 27,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633286191,
                        ["quant"] = 16,
                        ["id"] = "1692579135",
                        ["itemLink"] = 293,
                    },
                    [97] = 
                    {
                        ["price"] = 286400,
                        ["guild"] = 1,
                        ["buyer"] = 27,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633286192,
                        ["quant"] = 16,
                        ["id"] = "1692579145",
                        ["itemLink"] = 293,
                    },
                    [98] = 
                    {
                        ["price"] = 286400,
                        ["guild"] = 1,
                        ["buyer"] = 27,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633286193,
                        ["quant"] = 16,
                        ["id"] = "1692579151",
                        ["itemLink"] = 293,
                    },
                    [99] = 
                    {
                        ["price"] = 286400,
                        ["guild"] = 1,
                        ["buyer"] = 27,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633286194,
                        ["quant"] = 16,
                        ["id"] = "1692579159",
                        ["itemLink"] = 293,
                    },
                    [100] = 
                    {
                        ["price"] = 18998,
                        ["guild"] = 1,
                        ["buyer"] = 27,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633286197,
                        ["quant"] = 1,
                        ["id"] = "1692579171",
                        ["itemLink"] = 293,
                    },
                    [101] = 
                    {
                        ["price"] = 151999,
                        ["guild"] = 1,
                        ["buyer"] = 1990,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633292472,
                        ["quant"] = 8,
                        ["id"] = "1692657051",
                        ["itemLink"] = 293,
                    },
                    [102] = 
                    {
                        ["price"] = 151999,
                        ["guild"] = 1,
                        ["buyer"] = 1990,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633292473,
                        ["quant"] = 8,
                        ["id"] = "1692657055",
                        ["itemLink"] = 293,
                    },
                    [103] = 
                    {
                        ["price"] = 75200,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 30,
                        ["timestamp"] = 1633302530,
                        ["quant"] = 4,
                        ["id"] = "1692766819",
                        ["itemLink"] = 293,
                    },
                    [104] = 
                    {
                        ["price"] = 75200,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 30,
                        ["timestamp"] = 1633302531,
                        ["quant"] = 4,
                        ["id"] = "1692766827",
                        ["itemLink"] = 293,
                    },
                    [105] = 
                    {
                        ["price"] = 75200,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 30,
                        ["timestamp"] = 1633302532,
                        ["quant"] = 4,
                        ["id"] = "1692766837",
                        ["itemLink"] = 293,
                    },
                    [106] = 
                    {
                        ["price"] = 151999,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 56,
                        ["timestamp"] = 1633302533,
                        ["quant"] = 8,
                        ["id"] = "1692766853",
                        ["itemLink"] = 293,
                    },
                    [107] = 
                    {
                        ["price"] = 151999,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 56,
                        ["timestamp"] = 1633302533,
                        ["quant"] = 8,
                        ["id"] = "1692766861",
                        ["itemLink"] = 293,
                    },
                    [108] = 
                    {
                        ["price"] = 151999,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 56,
                        ["timestamp"] = 1633302535,
                        ["quant"] = 8,
                        ["id"] = "1692766887",
                        ["itemLink"] = 293,
                    },
                    [109] = 
                    {
                        ["price"] = 151999,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 56,
                        ["timestamp"] = 1633302535,
                        ["quant"] = 8,
                        ["id"] = "1692766889",
                        ["itemLink"] = 293,
                    },
                    [110] = 
                    {
                        ["price"] = 151999,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 56,
                        ["timestamp"] = 1633302536,
                        ["quant"] = 8,
                        ["id"] = "1692766899",
                        ["itemLink"] = 293,
                    },
                    [111] = 
                    {
                        ["price"] = 152000,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 30,
                        ["timestamp"] = 1633302537,
                        ["quant"] = 8,
                        ["id"] = "1692766921",
                        ["itemLink"] = 293,
                    },
                    [112] = 
                    {
                        ["price"] = 95000,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 1402,
                        ["timestamp"] = 1633302538,
                        ["quant"] = 5,
                        ["id"] = "1692766931",
                        ["itemLink"] = 293,
                    },
                    [113] = 
                    {
                        ["price"] = 19000,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 199,
                        ["timestamp"] = 1633302538,
                        ["quant"] = 1,
                        ["id"] = "1692766939",
                        ["itemLink"] = 293,
                    },
                    [114] = 
                    {
                        ["price"] = 95000,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 31,
                        ["timestamp"] = 1633302539,
                        ["quant"] = 5,
                        ["id"] = "1692766947",
                        ["itemLink"] = 293,
                    },
                    [115] = 
                    {
                        ["price"] = 18500,
                        ["guild"] = 1,
                        ["buyer"] = 2067,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633305958,
                        ["quant"] = 1,
                        ["id"] = "1692799927",
                        ["itemLink"] = 293,
                    },
                    [116] = 
                    {
                        ["price"] = 18500,
                        ["guild"] = 1,
                        ["buyer"] = 2067,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633305961,
                        ["quant"] = 1,
                        ["id"] = "1692799955",
                        ["itemLink"] = 293,
                    },
                    [117] = 
                    {
                        ["price"] = 38800,
                        ["guild"] = 1,
                        ["buyer"] = 2086,
                        ["wasKiosk"] = true,
                        ["seller"] = 590,
                        ["timestamp"] = 1633310181,
                        ["quant"] = 2,
                        ["id"] = "1692851023",
                        ["itemLink"] = 293,
                    },
                    [118] = 
                    {
                        ["price"] = 98575,
                        ["guild"] = 1,
                        ["buyer"] = 102,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633316245,
                        ["quant"] = 5,
                        ["id"] = "1692917593",
                        ["itemLink"] = 293,
                    },
                    [119] = 
                    {
                        ["price"] = 73996,
                        ["guild"] = 1,
                        ["buyer"] = 2115,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1632824960,
                        ["quant"] = 4,
                        ["id"] = "1688964157",
                        ["itemLink"] = 293,
                    },
                    [120] = 
                    {
                        ["price"] = 73996,
                        ["guild"] = 1,
                        ["buyer"] = 2115,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1632825850,
                        ["quant"] = 4,
                        ["id"] = "1688968437",
                        ["itemLink"] = 293,
                    },
                    [121] = 
                    {
                        ["price"] = 55497,
                        ["guild"] = 1,
                        ["buyer"] = 2115,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1632825852,
                        ["quant"] = 3,
                        ["id"] = "1688968443",
                        ["itemLink"] = 293,
                    },
                    [122] = 
                    {
                        ["price"] = 39000,
                        ["guild"] = 1,
                        ["buyer"] = 2115,
                        ["wasKiosk"] = true,
                        ["seller"] = 763,
                        ["timestamp"] = 1632825855,
                        ["quant"] = 2,
                        ["id"] = "1688968451",
                        ["itemLink"] = 293,
                    },
                    [123] = 
                    {
                        ["price"] = 850000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 82,
                        ["timestamp"] = 1632848366,
                        ["quant"] = 40,
                        ["id"] = "1689131087",
                        ["itemLink"] = 293,
                    },
                    [124] = 
                    {
                        ["price"] = 850000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 82,
                        ["timestamp"] = 1632848367,
                        ["quant"] = 40,
                        ["id"] = "1689131105",
                        ["itemLink"] = 293,
                    },
                    [125] = 
                    {
                        ["price"] = 19000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1632852941,
                        ["quant"] = 1,
                        ["id"] = "1689166629",
                        ["itemLink"] = 293,
                    },
                    [126] = 
                    {
                        ["price"] = 38000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1632852941,
                        ["quant"] = 2,
                        ["id"] = "1689166631",
                        ["itemLink"] = 293,
                    },
                    [127] = 
                    {
                        ["price"] = 37160,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632859467,
                        ["quant"] = 2,
                        ["id"] = "1689226445",
                        ["itemLink"] = 293,
                    },
                    [128] = 
                    {
                        ["price"] = 79020,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 2123,
                        ["timestamp"] = 1632862017,
                        ["quant"] = 4,
                        ["id"] = "1689244561",
                        ["itemLink"] = 293,
                    },
                    [129] = 
                    {
                        ["price"] = 79160,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 90,
                        ["timestamp"] = 1632862018,
                        ["quant"] = 4,
                        ["id"] = "1689244573",
                        ["itemLink"] = 293,
                    },
                    [130] = 
                    {
                        ["price"] = 79160,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 90,
                        ["timestamp"] = 1632862030,
                        ["quant"] = 4,
                        ["id"] = "1689244637",
                        ["itemLink"] = 293,
                    },
                    [131] = 
                    {
                        ["price"] = 79160,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 90,
                        ["timestamp"] = 1632862050,
                        ["quant"] = 4,
                        ["id"] = "1689244737",
                        ["itemLink"] = 293,
                    },
                    [132] = 
                    {
                        ["price"] = 78000,
                        ["guild"] = 1,
                        ["buyer"] = 2252,
                        ["wasKiosk"] = true,
                        ["seller"] = 146,
                        ["timestamp"] = 1632863207,
                        ["quant"] = 4,
                        ["id"] = "1689252577",
                        ["itemLink"] = 293,
                    },
                    [133] = 
                    {
                        ["price"] = 78000,
                        ["guild"] = 1,
                        ["buyer"] = 2252,
                        ["wasKiosk"] = true,
                        ["seller"] = 146,
                        ["timestamp"] = 1632863211,
                        ["quant"] = 4,
                        ["id"] = "1689252597",
                        ["itemLink"] = 293,
                    },
                    [134] = 
                    {
                        ["price"] = 78000,
                        ["guild"] = 1,
                        ["buyer"] = 2252,
                        ["wasKiosk"] = true,
                        ["seller"] = 146,
                        ["timestamp"] = 1632863214,
                        ["quant"] = 4,
                        ["id"] = "1689252615",
                        ["itemLink"] = 293,
                    },
                    [135] = 
                    {
                        ["price"] = 78000,
                        ["guild"] = 1,
                        ["buyer"] = 2252,
                        ["wasKiosk"] = true,
                        ["seller"] = 146,
                        ["timestamp"] = 1632863216,
                        ["quant"] = 4,
                        ["id"] = "1689252627",
                        ["itemLink"] = 293,
                    },
                    [136] = 
                    {
                        ["price"] = 78000,
                        ["guild"] = 1,
                        ["buyer"] = 2252,
                        ["wasKiosk"] = true,
                        ["seller"] = 146,
                        ["timestamp"] = 1632863218,
                        ["quant"] = 4,
                        ["id"] = "1689252645",
                        ["itemLink"] = 293,
                    },
                    [137] = 
                    {
                        ["price"] = 78000,
                        ["guild"] = 1,
                        ["buyer"] = 2252,
                        ["wasKiosk"] = true,
                        ["seller"] = 146,
                        ["timestamp"] = 1632863221,
                        ["quant"] = 4,
                        ["id"] = "1689252663",
                        ["itemLink"] = 293,
                    },
                    [138] = 
                    {
                        ["price"] = 198000,
                        ["guild"] = 1,
                        ["buyer"] = 2254,
                        ["wasKiosk"] = true,
                        ["seller"] = 378,
                        ["timestamp"] = 1632863815,
                        ["quant"] = 10,
                        ["id"] = "1689257207",
                        ["itemLink"] = 293,
                    },
                    [139] = 
                    {
                        ["price"] = 199000,
                        ["guild"] = 1,
                        ["buyer"] = 2254,
                        ["wasKiosk"] = true,
                        ["seller"] = 1899,
                        ["timestamp"] = 1632863819,
                        ["quant"] = 10,
                        ["id"] = "1689257219",
                        ["itemLink"] = 293,
                    },
                    [140] = 
                    {
                        ["price"] = 19500,
                        ["guild"] = 1,
                        ["buyer"] = 906,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1632867209,
                        ["quant"] = 1,
                        ["id"] = "1689282685",
                        ["itemLink"] = 293,
                    },
                    [141] = 
                    {
                        ["price"] = 19600,
                        ["guild"] = 1,
                        ["buyer"] = 2276,
                        ["wasKiosk"] = true,
                        ["seller"] = 65,
                        ["timestamp"] = 1632867627,
                        ["quant"] = 1,
                        ["id"] = "1689285331",
                        ["itemLink"] = 293,
                    },
                    [142] = 
                    {
                        ["price"] = 19600,
                        ["guild"] = 1,
                        ["buyer"] = 2276,
                        ["wasKiosk"] = true,
                        ["seller"] = 65,
                        ["timestamp"] = 1632867629,
                        ["quant"] = 1,
                        ["id"] = "1689285341",
                        ["itemLink"] = 293,
                    },
                    [143] = 
                    {
                        ["price"] = 156800,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 515,
                        ["timestamp"] = 1632873652,
                        ["quant"] = 8,
                        ["id"] = "1689327927",
                        ["itemLink"] = 293,
                    },
                    [144] = 
                    {
                        ["price"] = 989999,
                        ["guild"] = 1,
                        ["buyer"] = 2434,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632897412,
                        ["quant"] = 50,
                        ["id"] = "1689545417",
                        ["itemLink"] = 293,
                    },
                    [145] = 
                    {
                        ["price"] = 54000,
                        ["guild"] = 1,
                        ["buyer"] = 150,
                        ["wasKiosk"] = false,
                        ["seller"] = 1535,
                        ["timestamp"] = 1632917336,
                        ["quant"] = 3,
                        ["id"] = "1689637547",
                        ["itemLink"] = 293,
                    },
                    [146] = 
                    {
                        ["price"] = 58000,
                        ["guild"] = 1,
                        ["buyer"] = 150,
                        ["wasKiosk"] = false,
                        ["seller"] = 299,
                        ["timestamp"] = 1632917338,
                        ["quant"] = 3,
                        ["id"] = "1689637569",
                        ["itemLink"] = 293,
                    },
                    [147] = 
                    {
                        ["price"] = 19500,
                        ["guild"] = 1,
                        ["buyer"] = 150,
                        ["wasKiosk"] = false,
                        ["seller"] = 216,
                        ["timestamp"] = 1632917340,
                        ["quant"] = 1,
                        ["id"] = "1689637605",
                        ["itemLink"] = 293,
                    },
                    [148] = 
                    {
                        ["price"] = 19500,
                        ["guild"] = 1,
                        ["buyer"] = 150,
                        ["wasKiosk"] = false,
                        ["seller"] = 216,
                        ["timestamp"] = 1632917341,
                        ["quant"] = 1,
                        ["id"] = "1689637617",
                        ["itemLink"] = 293,
                    },
                    [149] = 
                    {
                        ["price"] = 19500,
                        ["guild"] = 1,
                        ["buyer"] = 150,
                        ["wasKiosk"] = false,
                        ["seller"] = 216,
                        ["timestamp"] = 1632917342,
                        ["quant"] = 1,
                        ["id"] = "1689637631",
                        ["itemLink"] = 293,
                    },
                    [150] = 
                    {
                        ["price"] = 19500,
                        ["guild"] = 1,
                        ["buyer"] = 150,
                        ["wasKiosk"] = false,
                        ["seller"] = 216,
                        ["timestamp"] = 1632917342,
                        ["quant"] = 1,
                        ["id"] = "1689637645",
                        ["itemLink"] = 293,
                    },
                    [151] = 
                    {
                        ["price"] = 99000,
                        ["guild"] = 1,
                        ["buyer"] = 150,
                        ["wasKiosk"] = false,
                        ["seller"] = 276,
                        ["timestamp"] = 1632917343,
                        ["quant"] = 5,
                        ["id"] = "1689637661",
                        ["itemLink"] = 293,
                    },
                    [152] = 
                    {
                        ["price"] = 1105440,
                        ["guild"] = 1,
                        ["buyer"] = 2483,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632920200,
                        ["quant"] = 56,
                        ["id"] = "1689652633",
                        ["itemLink"] = 293,
                    },
                    [153] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1212,
                        ["wasKiosk"] = true,
                        ["seller"] = 966,
                        ["timestamp"] = 1632931828,
                        ["quant"] = 1,
                        ["id"] = "1689734765",
                        ["itemLink"] = 293,
                    },
                    [154] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1212,
                        ["wasKiosk"] = true,
                        ["seller"] = 966,
                        ["timestamp"] = 1632931829,
                        ["quant"] = 1,
                        ["id"] = "1689734775",
                        ["itemLink"] = 293,
                    },
                    [155] = 
                    {
                        ["price"] = 150000,
                        ["guild"] = 1,
                        ["buyer"] = 2553,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1632941941,
                        ["quant"] = 8,
                        ["id"] = "1689808421",
                        ["itemLink"] = 293,
                    },
                    [156] = 
                    {
                        ["price"] = 150000,
                        ["guild"] = 1,
                        ["buyer"] = 505,
                        ["wasKiosk"] = false,
                        ["seller"] = 75,
                        ["timestamp"] = 1632956102,
                        ["quant"] = 8,
                        ["id"] = "1689928401",
                        ["itemLink"] = 293,
                    },
                    [157] = 
                    {
                        ["price"] = 18580,
                        ["guild"] = 1,
                        ["buyer"] = 783,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632957384,
                        ["quant"] = 1,
                        ["id"] = "1689938451",
                        ["itemLink"] = 293,
                    },
                    [158] = 
                    {
                        ["price"] = 38000,
                        ["guild"] = 1,
                        ["buyer"] = 783,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1632957385,
                        ["quant"] = 2,
                        ["id"] = "1689938463",
                        ["itemLink"] = 293,
                    },
                    [159] = 
                    {
                        ["price"] = 38000,
                        ["guild"] = 1,
                        ["buyer"] = 2644,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1632962739,
                        ["quant"] = 2,
                        ["id"] = "1689982399",
                        ["itemLink"] = 293,
                    },
                    [160] = 
                    {
                        ["price"] = 19000,
                        ["guild"] = 1,
                        ["buyer"] = 2644,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1632962739,
                        ["quant"] = 1,
                        ["id"] = "1689982421",
                        ["itemLink"] = 293,
                    },
                    [161] = 
                    {
                        ["price"] = 68000,
                        ["guild"] = 1,
                        ["buyer"] = 1354,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632963579,
                        ["quant"] = 4,
                        ["id"] = "1689991917",
                        ["itemLink"] = 293,
                    },
                    [162] = 
                    {
                        ["price"] = 68000,
                        ["guild"] = 1,
                        ["buyer"] = 1354,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632963580,
                        ["quant"] = 4,
                        ["id"] = "1689991925",
                        ["itemLink"] = 293,
                    },
                    [163] = 
                    {
                        ["price"] = 68000,
                        ["guild"] = 1,
                        ["buyer"] = 1354,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632963581,
                        ["quant"] = 4,
                        ["id"] = "1689991933",
                        ["itemLink"] = 293,
                    },
                    [164] = 
                    {
                        ["price"] = 68000,
                        ["guild"] = 1,
                        ["buyer"] = 1354,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632963582,
                        ["quant"] = 4,
                        ["id"] = "1689991947",
                        ["itemLink"] = 293,
                    },
                    [165] = 
                    {
                        ["price"] = 72000,
                        ["guild"] = 1,
                        ["buyer"] = 1354,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632963586,
                        ["quant"] = 4,
                        ["id"] = "1689991963",
                        ["itemLink"] = 293,
                    },
                },
                ["totalCount"] = 165,
                ["itemAdderText"] = "rr01 gold legendary materials tannin",
            },
        },
        [23204] = 
        {
            ["1:0:1:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_jewelry_base_amethyst_r3.dds",
                ["itemDesc"] = "Amethyst",
                ["oldestTime"] = 1632987705,
                ["wasAltered"] = true,
                ["newestTime"] = 1632987705,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2123,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 190,
                        ["timestamp"] = 1632987705,
                        ["quant"] = 200,
                        ["id"] = "1690172825",
                        ["itemLink"] = 336,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials weapon trait charged",
            },
        },
        [175781] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Old Orsinium Greatsword",
                ["oldestTime"] = 1633106499,
                ["wasAltered"] = true,
                ["newestTime"] = 1633106499,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 969,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633106499,
                        ["quant"] = 1,
                        ["id"] = "1691012137",
                        ["itemLink"] = 1300,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [123048] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_hlaalu_2haxe_a.dds",
                ["itemDesc"] = "Defiler's Battle Axe",
                ["oldestTime"] = 1633287873,
                ["wasAltered"] = true,
                ["newestTime"] = 1633287873,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1965,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633287873,
                        ["quant"] = 1,
                        ["id"] = "1692603529",
                        ["itemLink"] = 2766,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set defiler axe two-handed defending",
            },
        },
        [119465] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning3.dds",
                ["itemDesc"] = "Design: Oranges, Bunch",
                ["oldestTime"] = 1632930599,
                ["wasAltered"] = true,
                ["newestTime"] = 1632930599,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 2194,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632930599,
                        ["quant"] = 1,
                        ["id"] = "1689726499",
                        ["itemLink"] = 3704,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [115883] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning3.dds",
                ["itemDesc"] = "Design: Wood Elf Bowl, Striped",
                ["oldestTime"] = 1633307979,
                ["wasAltered"] = true,
                ["newestTime"] = 1633307979,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2076,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633307979,
                        ["quant"] = 1,
                        ["id"] = "1692822563",
                        ["itemLink"] = 2957,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [43692] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Stros M'Kai Treasure Map II",
                ["oldestTime"] = 1633182508,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182508,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 299,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182508,
                        ["quant"] = 1,
                        ["id"] = "1691608091",
                        ["itemLink"] = 1948,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [171949] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Amulet of Frostbite",
                ["oldestTime"] = 1633191576,
                ["wasAltered"] = true,
                ["newestTime"] = 1633264996,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1159,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633191576,
                        ["quant"] = 1,
                        ["id"] = "1691708329",
                        ["itemLink"] = 2111,
                    },
                    [2] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1159,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633191578,
                        ["quant"] = 1,
                        ["id"] = "1691708349",
                        ["itemLink"] = 2111,
                    },
                    [3] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1852,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633264996,
                        ["quant"] = 1,
                        ["id"] = "1692359001",
                        ["itemLink"] = 2111,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set frostbite neck arcane",
            },
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Amulet of Frostbite",
                ["oldestTime"] = 1633218650,
                ["wasAltered"] = true,
                ["newestTime"] = 1633235010,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4642,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1633218650,
                        ["quant"] = 1,
                        ["id"] = "1691997195",
                        ["itemLink"] = 2328,
                    },
                    [2] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 108,
                        ["timestamp"] = 1633235010,
                        ["quant"] = 1,
                        ["id"] = "1692160807",
                        ["itemLink"] = 2328,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set frostbite neck arcane",
            },
        },
        [139586] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing3.dds",
                ["itemDesc"] = "Diagram: Fireplace Tools, Wrought Iron",
                ["oldestTime"] = 1632966097,
                ["wasAltered"] = true,
                ["newestTime"] = 1632966097,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 2093,
                        ["wasKiosk"] = true,
                        ["seller"] = 261,
                        ["timestamp"] = 1632966097,
                        ["quant"] = 1,
                        ["id"] = "1690016267",
                        ["itemLink"] = 3960,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [26802] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_plant_creature_vines.dds",
                ["itemDesc"] = "Frost Mirriam",
                ["oldestTime"] = 1633018085,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305872,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6700,
                        ["guild"] = 1,
                        ["buyer"] = 495,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1633018085,
                        ["quant"] = 100,
                        ["id"] = "1690350415",
                        ["itemLink"] = 568,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 704,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633051494,
                        ["quant"] = 20,
                        ["id"] = "1690620895",
                        ["itemLink"] = 568,
                    },
                    [3] = 
                    {
                        ["price"] = 13995,
                        ["guild"] = 1,
                        ["buyer"] = 822,
                        ["wasKiosk"] = true,
                        ["seller"] = 322,
                        ["timestamp"] = 1633066192,
                        ["quant"] = 200,
                        ["id"] = "1690757621",
                        ["itemLink"] = 568,
                    },
                    [4] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 1289,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633157201,
                        ["quant"] = 200,
                        ["id"] = "1691449329",
                        ["itemLink"] = 568,
                    },
                    [5] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 447,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633297243,
                        ["quant"] = 20,
                        ["id"] = "1692713025",
                        ["itemLink"] = 568,
                    },
                    [6] = 
                    {
                        ["price"] = 5513,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633305835,
                        ["quant"] = 100,
                        ["id"] = "1692798753",
                        ["itemLink"] = 568,
                    },
                    [7] = 
                    {
                        ["price"] = 12500,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633305837,
                        ["quant"] = 200,
                        ["id"] = "1692798757",
                        ["itemLink"] = 568,
                    },
                    [8] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633305872,
                        ["quant"] = 200,
                        ["id"] = "1692799167",
                        ["itemLink"] = 568,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "rr01 purple epic materials ingredient",
            },
        },
        [45979] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Sweet Scamp Mazte",
                ["oldestTime"] = 1633011824,
                ["wasAltered"] = true,
                ["newestTime"] = 1633011824,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633011824,
                        ["quant"] = 1,
                        ["id"] = "1690302857",
                        ["itemLink"] = 524,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [135604] = 
        {
            ["50:16:4:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_psijicorder_light_robe_a.dds",
                ["itemDesc"] = "Vanus's Robe",
                ["oldestTime"] = 1633222694,
                ["wasAltered"] = true,
                ["newestTime"] = 1633222694,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 1623,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633222694,
                        ["quant"] = 1,
                        ["id"] = "1692039499",
                        ["itemLink"] = 2362,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set wisdom of vanus chest reinforced",
            },
        },
        [135244] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nocturnal_1haxe_a.dds",
                ["itemDesc"] = "Gloom-Graced Axe",
                ["oldestTime"] = 1633149489,
                ["wasAltered"] = true,
                ["newestTime"] = 1633149489,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 27500,
                        ["guild"] = 1,
                        ["buyer"] = 1114,
                        ["wasKiosk"] = true,
                        ["seller"] = 626,
                        ["timestamp"] = 1633149489,
                        ["quant"] = 1,
                        ["id"] = "1691386215",
                        ["itemLink"] = 1709,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set grace of gloom axe one-handed sharpened",
            },
        },
        [153629] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/plate_of_sugarskulls.dds",
                ["itemDesc"] = "Bewitched Sugar Skulls",
                ["oldestTime"] = 1632847080,
                ["wasAltered"] = true,
                ["newestTime"] = 1633312904,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4970,
                        ["guild"] = 1,
                        ["buyer"] = 13,
                        ["wasKiosk"] = false,
                        ["seller"] = 10,
                        ["timestamp"] = 1633311455,
                        ["quant"] = 5,
                        ["id"] = "1692864861",
                        ["itemLink"] = 9,
                    },
                    [2] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 44,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633312904,
                        ["quant"] = 50,
                        ["id"] = "1692879439",
                        ["itemLink"] = 9,
                    },
                    [3] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 637,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633041547,
                        ["quant"] = 20,
                        ["id"] = "1690524803",
                        ["itemLink"] = 9,
                    },
                    [4] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 644,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633041985,
                        ["quant"] = 20,
                        ["id"] = "1690528527",
                        ["itemLink"] = 9,
                    },
                    [5] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 644,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633041986,
                        ["quant"] = 20,
                        ["id"] = "1690528535",
                        ["itemLink"] = 9,
                    },
                    [6] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 644,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633041987,
                        ["quant"] = 20,
                        ["id"] = "1690528547",
                        ["itemLink"] = 9,
                    },
                    [7] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 644,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633041988,
                        ["quant"] = 20,
                        ["id"] = "1690528551",
                        ["itemLink"] = 9,
                    },
                    [8] = 
                    {
                        ["price"] = 100000,
                        ["guild"] = 1,
                        ["buyer"] = 914,
                        ["wasKiosk"] = true,
                        ["seller"] = 479,
                        ["timestamp"] = 1633089167,
                        ["quant"] = 100,
                        ["id"] = "1690884513",
                        ["itemLink"] = 9,
                    },
                    [9] = 
                    {
                        ["price"] = 15999,
                        ["guild"] = 1,
                        ["buyer"] = 637,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633118108,
                        ["quant"] = 20,
                        ["id"] = "1691092239",
                        ["itemLink"] = 9,
                    },
                    [10] = 
                    {
                        ["price"] = 15999,
                        ["guild"] = 1,
                        ["buyer"] = 803,
                        ["wasKiosk"] = false,
                        ["seller"] = 34,
                        ["timestamp"] = 1633195680,
                        ["quant"] = 20,
                        ["id"] = "1691748155",
                        ["itemLink"] = 9,
                    },
                    [11] = 
                    {
                        ["price"] = 15999,
                        ["guild"] = 1,
                        ["buyer"] = 1224,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633208053,
                        ["quant"] = 20,
                        ["id"] = "1691882605",
                        ["itemLink"] = 9,
                    },
                    [12] = 
                    {
                        ["price"] = 4970,
                        ["guild"] = 1,
                        ["buyer"] = 1930,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633280844,
                        ["quant"] = 5,
                        ["id"] = "1692523517",
                        ["itemLink"] = 9,
                    },
                    [13] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 1954,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633286158,
                        ["quant"] = 50,
                        ["id"] = "1692578919",
                        ["itemLink"] = 9,
                    },
                    [14] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 1954,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633286160,
                        ["quant"] = 50,
                        ["id"] = "1692578933",
                        ["itemLink"] = 9,
                    },
                    [15] = 
                    {
                        ["price"] = 4970,
                        ["guild"] = 1,
                        ["buyer"] = 13,
                        ["wasKiosk"] = false,
                        ["seller"] = 10,
                        ["timestamp"] = 1632847080,
                        ["quant"] = 5,
                        ["id"] = "1689119105",
                        ["itemLink"] = 9,
                    },
                    [16] = 
                    {
                        ["price"] = 15999,
                        ["guild"] = 1,
                        ["buyer"] = 2428,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632894462,
                        ["quant"] = 20,
                        ["id"] = "1689526607",
                        ["itemLink"] = 9,
                    },
                    [17] = 
                    {
                        ["price"] = 15999,
                        ["guild"] = 1,
                        ["buyer"] = 2546,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632940996,
                        ["quant"] = 20,
                        ["id"] = "1689801581",
                        ["itemLink"] = 9,
                    },
                    [18] = 
                    {
                        ["price"] = 15999,
                        ["guild"] = 1,
                        ["buyer"] = 26,
                        ["wasKiosk"] = false,
                        ["seller"] = 34,
                        ["timestamp"] = 1632955260,
                        ["quant"] = 20,
                        ["id"] = "1689920483",
                        ["itemLink"] = 9,
                    },
                    [19] = 
                    {
                        ["price"] = 15999,
                        ["guild"] = 1,
                        ["buyer"] = 794,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632958667,
                        ["quant"] = 20,
                        ["id"] = "1689949427",
                        ["itemLink"] = 9,
                    },
                    [20] = 
                    {
                        ["price"] = 15999,
                        ["guild"] = 1,
                        ["buyer"] = 794,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632958672,
                        ["quant"] = 20,
                        ["id"] = "1689949503",
                        ["itemLink"] = 9,
                    },
                },
                ["totalCount"] = 20,
                ["itemAdderText"] = "rr01 gold legendary consumable food",
            },
        },
        [102071] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Stygian Ring",
                ["oldestTime"] = 1633126375,
                ["wasAltered"] = true,
                ["newestTime"] = 1633126375,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 29999,
                        ["guild"] = 1,
                        ["buyer"] = 1086,
                        ["wasKiosk"] = true,
                        ["seller"] = 185,
                        ["timestamp"] = 1633126375,
                        ["quant"] = 1,
                        ["id"] = "1691153107",
                        ["itemLink"] = 1489,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set stygian ring robust",
            },
        },
        [178457] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Nibenese Court Wizard Gloves",
                ["oldestTime"] = 1632952519,
                ["wasAltered"] = true,
                ["newestTime"] = 1632952519,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 2597,
                        ["wasKiosk"] = true,
                        ["seller"] = 1061,
                        ["timestamp"] = 1632952519,
                        ["quant"] = 1,
                        ["id"] = "1689897011",
                        ["itemLink"] = 3850,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [45306] = 
        {
            ["50:16:1:19:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_heavy_feet_d.dds",
                ["itemDesc"] = "Rubedite Sabatons",
                ["oldestTime"] = 1632950134,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950134,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 324,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1632950134,
                        ["quant"] = 1,
                        ["id"] = "1689875277",
                        ["itemLink"] = 3828,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal heavy apparel feet ornate",
            },
            ["50:15:1:19:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_heavy_feet_d.dds",
                ["itemDesc"] = "Rubedite Sabatons",
                ["oldestTime"] = 1632950134,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950134,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 315,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 528,
                        ["timestamp"] = 1632950134,
                        ["quant"] = 1,
                        ["id"] = "1689875271",
                        ["itemLink"] = 3827,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 white normal heavy apparel feet ornate",
            },
        },
        [119482] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning3.dds",
                ["itemDesc"] = "Design: Basket of Tomatoes",
                ["oldestTime"] = 1633226358,
                ["wasAltered"] = true,
                ["newestTime"] = 1633226358,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1013,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633226358,
                        ["quant"] = 1,
                        ["id"] = "1692078165",
                        ["itemLink"] = 2396,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [171963] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_robe_a.dds",
                ["itemDesc"] = "Robe of Frostbite",
                ["oldestTime"] = 1633215989,
                ["wasAltered"] = true,
                ["newestTime"] = 1633215989,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 960,
                        ["guild"] = 1,
                        ["buyer"] = 327,
                        ["wasKiosk"] = false,
                        ["seller"] = 502,
                        ["timestamp"] = 1633215989,
                        ["quant"] = 1,
                        ["id"] = "1691968303",
                        ["itemLink"] = 2313,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite chest infused",
            },
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_robe_a.dds",
                ["itemDesc"] = "Robe of Frostbite",
                ["oldestTime"] = 1633243552,
                ["wasAltered"] = true,
                ["newestTime"] = 1633243552,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1332,
                        ["wasKiosk"] = true,
                        ["seller"] = 442,
                        ["timestamp"] = 1633243552,
                        ["quant"] = 1,
                        ["id"] = "1692222171",
                        ["itemLink"] = 2560,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set frostbite chest infused",
            },
        },
        [171978] = 
        {
            ["50:16:3:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_bow_a.dds",
                ["itemDesc"] = "Bow of Frostbite",
                ["oldestTime"] = 1633278912,
                ["wasAltered"] = true,
                ["newestTime"] = 1633296787,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 590,
                        ["guild"] = 1,
                        ["buyer"] = 1159,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633278912,
                        ["quant"] = 1,
                        ["id"] = "1692504307",
                        ["itemLink"] = 2724,
                    },
                    [2] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 2022,
                        ["wasKiosk"] = true,
                        ["seller"] = 442,
                        ["timestamp"] = 1633296787,
                        ["quant"] = 1,
                        ["id"] = "1692708607",
                        ["itemLink"] = 2724,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior weapon set frostbite bow two-handed powered",
            },
        },
        [158304] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 83: Pyre Watch Staves",
                ["oldestTime"] = 1633171999,
                ["wasAltered"] = true,
                ["newestTime"] = 1633171999,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 53943,
                        ["guild"] = 1,
                        ["buyer"] = 1343,
                        ["wasKiosk"] = true,
                        ["seller"] = 240,
                        ["timestamp"] = 1633171999,
                        ["quant"] = 1,
                        ["id"] = "1691530055",
                        ["itemLink"] = 1885,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [96955] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/collectible_memento_swallowable_sword.dds",
                ["itemDesc"] = "Disposable Swallower's Sword",
                ["oldestTime"] = 1632883944,
                ["wasAltered"] = true,
                ["newestTime"] = 1632883944,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50,
                        ["guild"] = 1,
                        ["buyer"] = 2378,
                        ["wasKiosk"] = true,
                        ["seller"] = 2379,
                        ["timestamp"] = 1632883944,
                        ["quant"] = 115,
                        ["id"] = "1689437981",
                        ["itemLink"] = 3495,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal consumable trophy",
            },
        },
        [119037] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Orcish Sack, Grain",
                ["oldestTime"] = 1632880384,
                ["wasAltered"] = true,
                ["newestTime"] = 1632880384,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 980,
                        ["guild"] = 1,
                        ["buyer"] = 1217,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632880384,
                        ["quant"] = 1,
                        ["id"] = "1689401009",
                        ["itemLink"] = 3458,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [34333] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_berry_002.dds",
                ["itemDesc"] = "Guarana",
                ["oldestTime"] = 1632861584,
                ["wasAltered"] = true,
                ["newestTime"] = 1632861584,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1632861584,
                        ["quant"] = 200,
                        ["id"] = "1689241655",
                        ["itemLink"] = 3306,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [117785] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_fur_varbookcasecombined002.dds",
                ["itemDesc"] = "Redguard Bookcase, Piled",
                ["oldestTime"] = 1632855815,
                ["wasAltered"] = true,
                ["newestTime"] = 1632855815,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 23000,
                        ["guild"] = 1,
                        ["buyer"] = 789,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632855815,
                        ["quant"] = 1,
                        ["id"] = "1689197145",
                        ["itemLink"] = 3267,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings library",
            },
        },
        [43507] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Glenumbra Treasure Map I",
                ["oldestTime"] = 1632851008,
                ["wasAltered"] = true,
                ["newestTime"] = 1632851008,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 175,
                        ["wasKiosk"] = false,
                        ["seller"] = 865,
                        ["timestamp"] = 1632851008,
                        ["quant"] = 1,
                        ["id"] = "1689152065",
                        ["itemLink"] = 3233,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [151747] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_lsb_akavirilantern003.dds",
                ["itemDesc"] = "Hakoshae Lantern, Crimson",
                ["oldestTime"] = 1633148000,
                ["wasAltered"] = true,
                ["newestTime"] = 1633148000,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 130686,
                        ["guild"] = 1,
                        ["buyer"] = 1243,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1633148000,
                        ["quant"] = 6,
                        ["id"] = "1691373877",
                        ["itemLink"] = 1680,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [151748] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_inc_ruglarge001.dds",
                ["itemDesc"] = "Elsweyr Carpet, Botanical Grand",
                ["oldestTime"] = 1633252633,
                ["wasAltered"] = true,
                ["newestTime"] = 1633252633,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 36000,
                        ["guild"] = 1,
                        ["buyer"] = 1824,
                        ["wasKiosk"] = true,
                        ["seller"] = 1668,
                        ["timestamp"] = 1633252633,
                        ["quant"] = 2,
                        ["id"] = "1692289707",
                        ["itemLink"] = 2610,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings parlor",
            },
        },
        [118948] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing4.dds",
                ["itemDesc"] = "Diagram: High Elf Brazier, Winged",
                ["oldestTime"] = 1632834083,
                ["wasAltered"] = true,
                ["newestTime"] = 1632834083,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 2147,
                        ["wasKiosk"] = true,
                        ["seller"] = 100,
                        ["timestamp"] = 1632834083,
                        ["quant"] = 1,
                        ["id"] = "1689022113",
                        ["itemLink"] = 3095,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [180843] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_heavy_head_a.dds",
                ["itemDesc"] = "Hrothgar's Helm",
                ["oldestTime"] = 1632830311,
                ["wasAltered"] = true,
                ["newestTime"] = 1632830311,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1870,
                        ["guild"] = 1,
                        ["buyer"] = 2134,
                        ["wasKiosk"] = true,
                        ["seller"] = 1112,
                        ["timestamp"] = 1632830311,
                        ["quant"] = 1,
                        ["id"] = "1689000357",
                        ["itemLink"] = 3073,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set hrothgar's chill head reinforced",
            },
        },
        [171918] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 102: Sul-Xan Daggers",
                ["oldestTime"] = 1633292560,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292560,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 256,
                        ["timestamp"] = 1633292560,
                        ["quant"] = 1,
                        ["id"] = "1692658269",
                        ["itemLink"] = 2841,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [152061] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Elsweyr Table, Square",
                ["oldestTime"] = 1633228951,
                ["wasAltered"] = true,
                ["newestTime"] = 1633228951,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6999,
                        ["guild"] = 1,
                        ["buyer"] = 890,
                        ["wasKiosk"] = true,
                        ["seller"] = 283,
                        ["timestamp"] = 1633228951,
                        ["quant"] = 1,
                        ["id"] = "1692106423",
                        ["itemLink"] = 2428,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [118985] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: High Elf Bed, Single",
                ["oldestTime"] = 1632958146,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292407,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1992,
                        ["wasKiosk"] = true,
                        ["seller"] = 600,
                        ["timestamp"] = 1633292407,
                        ["quant"] = 1,
                        ["id"] = "1692656397",
                        ["itemLink"] = 2829,
                    },
                    [2] = 
                    {
                        ["price"] = 50,
                        ["guild"] = 1,
                        ["buyer"] = 2619,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632958146,
                        ["quant"] = 1,
                        ["id"] = "1689945197",
                        ["itemLink"] = 2829,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [96970] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Night Mother",
                ["oldestTime"] = 1633163918,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163918,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1550,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 92,
                        ["timestamp"] = 1633163918,
                        ["quant"] = 1,
                        ["id"] = "1691490357",
                        ["itemLink"] = 1815,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set night mother's embrace ring robust",
            },
            ["50:16:2:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Night Mother",
                ["oldestTime"] = 1632968112,
                ["wasAltered"] = true,
                ["newestTime"] = 1633053381,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 726,
                        ["wasKiosk"] = true,
                        ["seller"] = 237,
                        ["timestamp"] = 1633053380,
                        ["quant"] = 1,
                        ["id"] = "1690639565",
                        ["itemLink"] = 931,
                    },
                    [2] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 726,
                        ["wasKiosk"] = true,
                        ["seller"] = 237,
                        ["timestamp"] = 1633053381,
                        ["quant"] = 1,
                        ["id"] = "1690639575",
                        ["itemLink"] = 931,
                    },
                    [3] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 2672,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1632968112,
                        ["quant"] = 1,
                        ["id"] = "1690036613",
                        ["itemLink"] = 931,
                    },
                    [4] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 2672,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1632968113,
                        ["quant"] = 1,
                        ["id"] = "1690036619",
                        ["itemLink"] = 931,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set night mother's embrace ring robust",
            },
        },
        [139609] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing3.dds",
                ["itemDesc"] = "Diagram: Alinor Table Setting, Complete",
                ["oldestTime"] = 1633279259,
                ["wasAltered"] = true,
                ["newestTime"] = 1633279259,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1923,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633279259,
                        ["quant"] = 1,
                        ["id"] = "1692507171",
                        ["itemLink"] = 2729,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [71716] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 26: Daggerfall Covenant Shoulders",
                ["oldestTime"] = 1633279207,
                ["wasAltered"] = true,
                ["newestTime"] = 1633279207,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1920,
                        ["wasKiosk"] = true,
                        ["seller"] = 510,
                        ["timestamp"] = 1633279207,
                        ["quant"] = 1,
                        ["id"] = "1692506871",
                        ["itemLink"] = 2727,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [30157] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_cloth_serrated_leaves.dds",
                ["itemDesc"] = "Blessed Thistle",
                ["oldestTime"] = 1632854860,
                ["wasAltered"] = true,
                ["newestTime"] = 1633277168,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 462,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1633013752,
                        ["quant"] = 20,
                        ["id"] = "1690315073",
                        ["itemLink"] = 529,
                    },
                    [2] = 
                    {
                        ["price"] = 31995,
                        ["guild"] = 1,
                        ["buyer"] = 919,
                        ["wasKiosk"] = true,
                        ["seller"] = 322,
                        ["timestamp"] = 1633090593,
                        ["quant"] = 200,
                        ["id"] = "1690892071",
                        ["itemLink"] = 529,
                    },
                    [3] = 
                    {
                        ["price"] = 34000,
                        ["guild"] = 1,
                        ["buyer"] = 976,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633109104,
                        ["quant"] = 200,
                        ["id"] = "1691029757",
                        ["itemLink"] = 529,
                    },
                    [4] = 
                    {
                        ["price"] = 7446,
                        ["guild"] = 1,
                        ["buyer"] = 1326,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633166689,
                        ["quant"] = 51,
                        ["id"] = "1691503531",
                        ["itemLink"] = 529,
                    },
                    [5] = 
                    {
                        ["price"] = 3320,
                        ["guild"] = 1,
                        ["buyer"] = 1561,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633213134,
                        ["quant"] = 20,
                        ["id"] = "1691941805",
                        ["itemLink"] = 529,
                    },
                    [6] = 
                    {
                        ["price"] = 33200,
                        ["guild"] = 1,
                        ["buyer"] = 1908,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633277163,
                        ["quant"] = 200,
                        ["id"] = "1692487843",
                        ["itemLink"] = 529,
                    },
                    [7] = 
                    {
                        ["price"] = 17113,
                        ["guild"] = 1,
                        ["buyer"] = 1908,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633277168,
                        ["quant"] = 100,
                        ["id"] = "1692487887",
                        ["itemLink"] = 529,
                    },
                    [8] = 
                    {
                        ["price"] = 8750,
                        ["guild"] = 1,
                        ["buyer"] = 2232,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632854860,
                        ["quant"] = 50,
                        ["id"] = "1689182869",
                        ["itemLink"] = 529,
                    },
                    [9] = 
                    {
                        ["price"] = 4375,
                        ["guild"] = 1,
                        ["buyer"] = 2232,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632854863,
                        ["quant"] = 25,
                        ["id"] = "1689182873",
                        ["itemLink"] = 529,
                    },
                    [10] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2599,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632952763,
                        ["quant"] = 10,
                        ["id"] = "1689899195",
                        ["itemLink"] = 529,
                    },
                    [11] = 
                    {
                        ["price"] = 9240,
                        ["guild"] = 1,
                        ["buyer"] = 2655,
                        ["wasKiosk"] = true,
                        ["seller"] = 1535,
                        ["timestamp"] = 1632965428,
                        ["quant"] = 60,
                        ["id"] = "1690010775",
                        ["itemLink"] = 529,
                    },
                },
                ["totalCount"] = 11,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [77518] = 
        {
            ["50:16:5:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Flanking",
                ["oldestTime"] = 1633251533,
                ["wasAltered"] = true,
                ["newestTime"] = 1633287846,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 1821,
                        ["wasKiosk"] = true,
                        ["seller"] = 261,
                        ["timestamp"] = 1633251533,
                        ["quant"] = 1,
                        ["id"] = "1692281179",
                        ["itemLink"] = 2606,
                    },
                    [2] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 1821,
                        ["wasKiosk"] = true,
                        ["seller"] = 261,
                        ["timestamp"] = 1633287846,
                        ["quant"] = 1,
                        ["id"] = "1692603097",
                        ["itemLink"] = 2606,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 gold legendary jewelry apparel set flanking strategist ring robust",
            },
        },
        [122831] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_telvanni_light_head_a.dds",
                ["itemDesc"] = "War Maiden's Hat",
                ["oldestTime"] = 1632941486,
                ["wasAltered"] = true,
                ["newestTime"] = 1632941486,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2550,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1632941486,
                        ["quant"] = 1,
                        ["id"] = "1689805637",
                        ["itemLink"] = 3773,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set war maiden head divines",
            },
        },
        [171984] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_robe_a.dds",
                ["itemDesc"] = "Robe of Frostbite",
                ["oldestTime"] = 1633313172,
                ["wasAltered"] = true,
                ["newestTime"] = 1633313172,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 49,
                        ["wasKiosk"] = true,
                        ["seller"] = 51,
                        ["timestamp"] = 1633313172,
                        ["quant"] = 1,
                        ["id"] = "1692881757",
                        ["itemLink"] = 36,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite chest divines",
            },
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_robe_a.dds",
                ["itemDesc"] = "Robe of Frostbite",
                ["oldestTime"] = 1633197327,
                ["wasAltered"] = true,
                ["newestTime"] = 1633197327,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1690,
                        ["guild"] = 1,
                        ["buyer"] = 1462,
                        ["wasKiosk"] = true,
                        ["seller"] = 1112,
                        ["timestamp"] = 1633197327,
                        ["quant"] = 1,
                        ["id"] = "1691762085",
                        ["itemLink"] = 2151,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set frostbite chest divines",
            },
        },
        [116919] = 
        {
            ["50:16:4:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_1haxe_a.dds",
                ["itemDesc"] = "Axe of the Phoenix",
                ["oldestTime"] = 1633278475,
                ["wasAltered"] = true,
                ["newestTime"] = 1633278475,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200000,
                        ["guild"] = 1,
                        ["buyer"] = 1915,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1633278475,
                        ["quant"] = 1,
                        ["id"] = "1692500229",
                        ["itemLink"] = 2722,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set phoenix axe one-handed powered",
            },
        },
        [115195] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bre_fur_tablesquare001.dds",
                ["itemDesc"] = "Breton Table, Square",
                ["oldestTime"] = 1633273344,
                ["wasAltered"] = true,
                ["newestTime"] = 1633273344,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 48,
                        ["wasKiosk"] = false,
                        ["seller"] = 99,
                        ["timestamp"] = 1633273344,
                        ["quant"] = 1,
                        ["id"] = "1692441289",
                        ["itemLink"] = 2685,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings dining",
            },
        },
        [116179] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Nord Table, Dining",
                ["oldestTime"] = 1632836160,
                ["wasAltered"] = true,
                ["newestTime"] = 1633235807,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1732,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633235807,
                        ["quant"] = 1,
                        ["id"] = "1692166413",
                        ["itemLink"] = 2486,
                    },
                    [2] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2158,
                        ["wasKiosk"] = true,
                        ["seller"] = 100,
                        ["timestamp"] = 1632836160,
                        ["quant"] = 1,
                        ["id"] = "1689035061",
                        ["itemLink"] = 2486,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [69206] = 
        {
            ["50:16:4:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_staff_c.dds",
                ["itemDesc"] = "Ice Staff of Willpower",
                ["oldestTime"] = 1633269667,
                ["wasAltered"] = true,
                ["newestTime"] = 1633269667,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1360,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1633269667,
                        ["quant"] = 1,
                        ["id"] = "1692401305",
                        ["itemLink"] = 2662,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set willpower frost staff two-handed precise",
            },
        },
        [123349] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Coward's Gear Necklace",
                ["oldestTime"] = 1633201973,
                ["wasAltered"] = true,
                ["newestTime"] = 1633201973,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 778,
                        ["wasKiosk"] = false,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633201973,
                        ["quant"] = 1,
                        ["id"] = "1691810257",
                        ["itemLink"] = 2218,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set coward's gear neck robust",
            },
        },
        [95490] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_light_hands_a.dds",
                ["itemDesc"] = "Gloves of Martial Knowledge",
                ["oldestTime"] = 1633022982,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022982,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633022982,
                        ["quant"] = 1,
                        ["id"] = "1690390459",
                        ["itemLink"] = 622,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set way of martial knowledge hands divines",
            },
        },
        [117719] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_fur_sofa001.dds",
                ["itemDesc"] = "Redguard Sofa, Desert Flame",
                ["oldestTime"] = 1633271792,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292802,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1884,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633271792,
                        ["quant"] = 1,
                        ["id"] = "1692423859",
                        ["itemLink"] = 2678,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1884,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633271795,
                        ["quant"] = 1,
                        ["id"] = "1692423905",
                        ["itemLink"] = 2678,
                    },
                    [3] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1995,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633292802,
                        ["quant"] = 1,
                        ["id"] = "1692661213",
                        ["itemLink"] = 2678,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior furnishings parlor",
            },
        },
        [145365] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_arg_lsb_mrklampshell001.dds",
                ["itemDesc"] = "Murkmire Brazier, Shell",
                ["oldestTime"] = 1633250391,
                ["wasAltered"] = true,
                ["newestTime"] = 1633250391,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 52900,
                        ["guild"] = 1,
                        ["buyer"] = 1818,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1633250391,
                        ["quant"] = 4,
                        ["id"] = "1692272875",
                        ["itemLink"] = 2597,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings lighting",
            },
        },
        [45903] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Cheese Pork Schnitzel",
                ["oldestTime"] = 1633242691,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242691,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 348,
                        ["wasKiosk"] = false,
                        ["seller"] = 479,
                        ["timestamp"] = 1633242691,
                        ["quant"] = 1,
                        ["id"] = "1692215255",
                        ["itemLink"] = 2548,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [147930] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_plaque_drenched_fabric.dds",
                ["itemDesc"] = "Plague-Drenched Fabric",
                ["oldestTime"] = 1633112597,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112597,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 996,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633112597,
                        ["quant"] = 1,
                        ["id"] = "1691056159",
                        ["itemLink"] = 1357,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [82060] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 36: Dark Brotherhood Daggers",
                ["oldestTime"] = 1632944178,
                ["wasAltered"] = true,
                ["newestTime"] = 1633067280,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8999,
                        ["guild"] = 1,
                        ["buyer"] = 830,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633067280,
                        ["quant"] = 1,
                        ["id"] = "1690762987",
                        ["itemLink"] = 1073,
                    },
                    [2] = 
                    {
                        ["price"] = 5250,
                        ["guild"] = 1,
                        ["buyer"] = 2558,
                        ["wasKiosk"] = true,
                        ["seller"] = 159,
                        ["timestamp"] = 1632944178,
                        ["quant"] = 1,
                        ["id"] = "1689828233",
                        ["itemLink"] = 1073,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [43538] = 
        {
            ["50:16:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_heavy_feet_d.dds",
                ["itemDesc"] = "Rubedite Sabatons of Stamina",
                ["oldestTime"] = 1633186026,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186026,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633186026,
                        ["quant"] = 1,
                        ["id"] = "1691640969",
                        ["itemLink"] = 2063,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel feet",
            },
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_heavy_feet_d.dds",
                ["itemDesc"] = "Rubedite Sabatons",
                ["oldestTime"] = 1632847687,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185948,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 84,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633185948,
                        ["quant"] = 1,
                        ["id"] = "1691640213",
                        ["itemLink"] = 2025,
                    },
                    [2] = 
                    {
                        ["price"] = 141,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1632847687,
                        ["quant"] = 1,
                        ["id"] = "1689125511",
                        ["itemLink"] = 3208,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 white normal heavy apparel feet",
            },
        },
        [167952] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 95: Nighthollow Legs",
                ["oldestTime"] = 1633128037,
                ["wasAltered"] = true,
                ["newestTime"] = 1633128037,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 418,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1633128037,
                        ["quant"] = 1,
                        ["id"] = "1691167657",
                        ["itemLink"] = 1495,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [64222] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_heavy_armor_vendor_component_002.dds",
                ["itemDesc"] = "Perfect Roe",
                ["oldestTime"] = 1632840576,
                ["wasAltered"] = true,
                ["newestTime"] = 1633257548,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 58000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 30,
                        ["timestamp"] = 1632980619,
                        ["quant"] = 1,
                        ["id"] = "1690133499",
                        ["itemLink"] = 266,
                    },
                    [2] = 
                    {
                        ["price"] = 56000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 30,
                        ["timestamp"] = 1632980620,
                        ["quant"] = 1,
                        ["id"] = "1690133503",
                        ["itemLink"] = 266,
                    },
                    [3] = 
                    {
                        ["price"] = 56000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 30,
                        ["timestamp"] = 1632980620,
                        ["quant"] = 1,
                        ["id"] = "1690133505",
                        ["itemLink"] = 266,
                    },
                    [4] = 
                    {
                        ["price"] = 56000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 30,
                        ["timestamp"] = 1632980621,
                        ["quant"] = 1,
                        ["id"] = "1690133511",
                        ["itemLink"] = 266,
                    },
                    [5] = 
                    {
                        ["price"] = 274999,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 34,
                        ["timestamp"] = 1632980622,
                        ["quant"] = 5,
                        ["id"] = "1690133515",
                        ["itemLink"] = 266,
                    },
                    [6] = 
                    {
                        ["price"] = 119999,
                        ["guild"] = 1,
                        ["buyer"] = 289,
                        ["wasKiosk"] = true,
                        ["seller"] = 290,
                        ["timestamp"] = 1632982647,
                        ["quant"] = 2,
                        ["id"] = "1690145995",
                        ["itemLink"] = 266,
                    },
                    [7] = 
                    {
                        ["price"] = 54999,
                        ["guild"] = 1,
                        ["buyer"] = 361,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632992113,
                        ["quant"] = 1,
                        ["id"] = "1690196811",
                        ["itemLink"] = 266,
                    },
                    [8] = 
                    {
                        ["price"] = 54999,
                        ["guild"] = 1,
                        ["buyer"] = 361,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632992113,
                        ["quant"] = 1,
                        ["id"] = "1690196819",
                        ["itemLink"] = 266,
                    },
                    [9] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 496,
                        ["wasKiosk"] = true,
                        ["seller"] = 461,
                        ["timestamp"] = 1633018290,
                        ["quant"] = 1,
                        ["id"] = "1690352531",
                        ["itemLink"] = 266,
                    },
                    [10] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 496,
                        ["wasKiosk"] = true,
                        ["seller"] = 461,
                        ["timestamp"] = 1633018292,
                        ["quant"] = 1,
                        ["id"] = "1690352537",
                        ["itemLink"] = 266,
                    },
                    [11] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 496,
                        ["wasKiosk"] = true,
                        ["seller"] = 461,
                        ["timestamp"] = 1633018292,
                        ["quant"] = 1,
                        ["id"] = "1690352545",
                        ["itemLink"] = 266,
                    },
                    [12] = 
                    {
                        ["price"] = 315000,
                        ["guild"] = 1,
                        ["buyer"] = 496,
                        ["wasKiosk"] = true,
                        ["seller"] = 255,
                        ["timestamp"] = 1633018298,
                        ["quant"] = 5,
                        ["id"] = "1690352571",
                        ["itemLink"] = 266,
                    },
                    [13] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 511,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633020728,
                        ["quant"] = 1,
                        ["id"] = "1690370687",
                        ["itemLink"] = 266,
                    },
                    [14] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 511,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633020728,
                        ["quant"] = 1,
                        ["id"] = "1690370697",
                        ["itemLink"] = 266,
                    },
                    [15] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 511,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633020729,
                        ["quant"] = 1,
                        ["id"] = "1690370707",
                        ["itemLink"] = 266,
                    },
                    [16] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 511,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633020730,
                        ["quant"] = 1,
                        ["id"] = "1690370719",
                        ["itemLink"] = 266,
                    },
                    [17] = 
                    {
                        ["price"] = 315000,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 255,
                        ["timestamp"] = 1633021697,
                        ["quant"] = 5,
                        ["id"] = "1690381119",
                        ["itemLink"] = 266,
                    },
                    [18] = 
                    {
                        ["price"] = 315000,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 255,
                        ["timestamp"] = 1633021698,
                        ["quant"] = 5,
                        ["id"] = "1690381139",
                        ["itemLink"] = 266,
                    },
                    [19] = 
                    {
                        ["price"] = 315000,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 255,
                        ["timestamp"] = 1633021699,
                        ["quant"] = 5,
                        ["id"] = "1690381153",
                        ["itemLink"] = 266,
                    },
                    [20] = 
                    {
                        ["price"] = 315000,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 255,
                        ["timestamp"] = 1633021701,
                        ["quant"] = 5,
                        ["id"] = "1690381171",
                        ["itemLink"] = 266,
                    },
                    [21] = 
                    {
                        ["price"] = 315000,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 255,
                        ["timestamp"] = 1633021701,
                        ["quant"] = 5,
                        ["id"] = "1690381187",
                        ["itemLink"] = 266,
                    },
                    [22] = 
                    {
                        ["price"] = 315000,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 255,
                        ["timestamp"] = 1633021703,
                        ["quant"] = 5,
                        ["id"] = "1690381213",
                        ["itemLink"] = 266,
                    },
                    [23] = 
                    {
                        ["price"] = 51085,
                        ["guild"] = 1,
                        ["buyer"] = 511,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633033870,
                        ["quant"] = 1,
                        ["id"] = "1690468807",
                        ["itemLink"] = 266,
                    },
                    [24] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1338,
                        ["wasKiosk"] = true,
                        ["seller"] = 271,
                        ["timestamp"] = 1633170999,
                        ["quant"] = 1,
                        ["id"] = "1691525677",
                        ["itemLink"] = 266,
                    },
                    [25] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1338,
                        ["wasKiosk"] = true,
                        ["seller"] = 271,
                        ["timestamp"] = 1633171001,
                        ["quant"] = 1,
                        ["id"] = "1691525689",
                        ["itemLink"] = 266,
                    },
                    [26] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1338,
                        ["wasKiosk"] = true,
                        ["seller"] = 271,
                        ["timestamp"] = 1633171003,
                        ["quant"] = 1,
                        ["id"] = "1691525711",
                        ["itemLink"] = 266,
                    },
                    [27] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1338,
                        ["wasKiosk"] = true,
                        ["seller"] = 271,
                        ["timestamp"] = 1633171004,
                        ["quant"] = 1,
                        ["id"] = "1691525721",
                        ["itemLink"] = 266,
                    },
                    [28] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1338,
                        ["wasKiosk"] = true,
                        ["seller"] = 271,
                        ["timestamp"] = 1633171006,
                        ["quant"] = 1,
                        ["id"] = "1691525729",
                        ["itemLink"] = 266,
                    },
                    [29] = 
                    {
                        ["price"] = 168000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 30,
                        ["timestamp"] = 1633238951,
                        ["quant"] = 3,
                        ["id"] = "1692190713",
                        ["itemLink"] = 266,
                    },
                    [30] = 
                    {
                        ["price"] = 54000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 615,
                        ["timestamp"] = 1633238951,
                        ["quant"] = 1,
                        ["id"] = "1692190717",
                        ["itemLink"] = 266,
                    },
                    [31] = 
                    {
                        ["price"] = 54000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 615,
                        ["timestamp"] = 1633238952,
                        ["quant"] = 1,
                        ["id"] = "1692190729",
                        ["itemLink"] = 266,
                    },
                    [32] = 
                    {
                        ["price"] = 54000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 615,
                        ["timestamp"] = 1633238953,
                        ["quant"] = 1,
                        ["id"] = "1692190735",
                        ["itemLink"] = 266,
                    },
                    [33] = 
                    {
                        ["price"] = 54000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 615,
                        ["timestamp"] = 1633238953,
                        ["quant"] = 1,
                        ["id"] = "1692190741",
                        ["itemLink"] = 266,
                    },
                    [34] = 
                    {
                        ["price"] = 54000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 615,
                        ["timestamp"] = 1633238954,
                        ["quant"] = 1,
                        ["id"] = "1692190745",
                        ["itemLink"] = 266,
                    },
                    [35] = 
                    {
                        ["price"] = 54000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 615,
                        ["timestamp"] = 1633238955,
                        ["quant"] = 1,
                        ["id"] = "1692190749",
                        ["itemLink"] = 266,
                    },
                    [36] = 
                    {
                        ["price"] = 54000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 615,
                        ["timestamp"] = 1633238955,
                        ["quant"] = 1,
                        ["id"] = "1692190757",
                        ["itemLink"] = 266,
                    },
                    [37] = 
                    {
                        ["price"] = 54000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 615,
                        ["timestamp"] = 1633238956,
                        ["quant"] = 1,
                        ["id"] = "1692190763",
                        ["itemLink"] = 266,
                    },
                    [38] = 
                    {
                        ["price"] = 54000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 615,
                        ["timestamp"] = 1633238956,
                        ["quant"] = 1,
                        ["id"] = "1692190767",
                        ["itemLink"] = 266,
                    },
                    [39] = 
                    {
                        ["price"] = 56000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 30,
                        ["timestamp"] = 1633238959,
                        ["quant"] = 1,
                        ["id"] = "1692190775",
                        ["itemLink"] = 266,
                    },
                    [40] = 
                    {
                        ["price"] = 49623,
                        ["guild"] = 1,
                        ["buyer"] = 1833,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633257548,
                        ["quant"] = 1,
                        ["id"] = "1692315197",
                        ["itemLink"] = 266,
                    },
                    [41] = 
                    {
                        ["price"] = 262500,
                        ["guild"] = 1,
                        ["buyer"] = 2180,
                        ["wasKiosk"] = true,
                        ["seller"] = 269,
                        ["timestamp"] = 1632840576,
                        ["quant"] = 5,
                        ["id"] = "1689063603",
                        ["itemLink"] = 266,
                    },
                    [42] = 
                    {
                        ["price"] = 105000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 269,
                        ["timestamp"] = 1632858855,
                        ["quant"] = 2,
                        ["id"] = "1689221331",
                        ["itemLink"] = 266,
                    },
                    [43] = 
                    {
                        ["price"] = 56000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 30,
                        ["timestamp"] = 1632858864,
                        ["quant"] = 1,
                        ["id"] = "1689221369",
                        ["itemLink"] = 266,
                    },
                    [44] = 
                    {
                        ["price"] = 56000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 30,
                        ["timestamp"] = 1632899950,
                        ["quant"] = 1,
                        ["id"] = "1689558615",
                        ["itemLink"] = 266,
                    },
                    [45] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 225,
                        ["timestamp"] = 1632899951,
                        ["quant"] = 1,
                        ["id"] = "1689558619",
                        ["itemLink"] = 266,
                    },
                    [46] = 
                    {
                        ["price"] = 54999,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 56,
                        ["timestamp"] = 1632899951,
                        ["quant"] = 1,
                        ["id"] = "1689558623",
                        ["itemLink"] = 266,
                    },
                    [47] = 
                    {
                        ["price"] = 105000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 269,
                        ["timestamp"] = 1632899952,
                        ["quant"] = 2,
                        ["id"] = "1689558627",
                        ["itemLink"] = 266,
                    },
                    [48] = 
                    {
                        ["price"] = 56000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 30,
                        ["timestamp"] = 1632899952,
                        ["quant"] = 1,
                        ["id"] = "1689558637",
                        ["itemLink"] = 266,
                    },
                    [49] = 
                    {
                        ["price"] = 105000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 269,
                        ["timestamp"] = 1632899953,
                        ["quant"] = 2,
                        ["id"] = "1689558639",
                        ["itemLink"] = 266,
                    },
                    [50] = 
                    {
                        ["price"] = 105000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 269,
                        ["timestamp"] = 1632943194,
                        ["quant"] = 2,
                        ["id"] = "1689819265",
                        ["itemLink"] = 266,
                    },
                    [51] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 275,
                        ["timestamp"] = 1632943195,
                        ["quant"] = 1,
                        ["id"] = "1689819271",
                        ["itemLink"] = 266,
                    },
                    [52] = 
                    {
                        ["price"] = 105000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 269,
                        ["timestamp"] = 1632943196,
                        ["quant"] = 2,
                        ["id"] = "1689819283",
                        ["itemLink"] = 266,
                    },
                },
                ["totalCount"] = 52,
                ["itemAdderText"] = "rr01 gold legendary materials ingredient",
            },
        },
        [77590] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_nightshade_01.dds",
                ["itemDesc"] = "Nightshade",
                ["oldestTime"] = 1632918419,
                ["wasAltered"] = true,
                ["newestTime"] = 1633301283,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22999,
                        ["guild"] = 1,
                        ["buyer"] = 278,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1632981545,
                        ["quant"] = 100,
                        ["id"] = "1690139525",
                        ["itemLink"] = 289,
                    },
                    [2] = 
                    {
                        ["price"] = 44000,
                        ["guild"] = 1,
                        ["buyer"] = 752,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633055881,
                        ["quant"] = 200,
                        ["id"] = "1690662937",
                        ["itemLink"] = 289,
                    },
                    [3] = 
                    {
                        ["price"] = 5730,
                        ["guild"] = 1,
                        ["buyer"] = 423,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633115737,
                        ["quant"] = 25,
                        ["id"] = "1691076755",
                        ["itemLink"] = 289,
                    },
                    [4] = 
                    {
                        ["price"] = 45317,
                        ["guild"] = 1,
                        ["buyer"] = 423,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633115743,
                        ["quant"] = 200,
                        ["id"] = "1691076799",
                        ["itemLink"] = 289,
                    },
                    [5] = 
                    {
                        ["price"] = 48000,
                        ["guild"] = 1,
                        ["buyer"] = 1722,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1633234525,
                        ["quant"] = 200,
                        ["id"] = "1692157919",
                        ["itemLink"] = 289,
                    },
                    [6] = 
                    {
                        ["price"] = 46000,
                        ["guild"] = 1,
                        ["buyer"] = 2047,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633301283,
                        ["quant"] = 200,
                        ["id"] = "1692754547",
                        ["itemLink"] = 289,
                    },
                    [7] = 
                    {
                        ["price"] = 5600,
                        ["guild"] = 1,
                        ["buyer"] = 2479,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632918419,
                        ["quant"] = 28,
                        ["id"] = "1689642421",
                        ["itemLink"] = 289,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [26848] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_fireessence.dds",
                ["itemDesc"] = "Superb Glyph of Flame",
                ["oldestTime"] = 1633148050,
                ["wasAltered"] = true,
                ["newestTime"] = 1633251476,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 227,
                        ["guild"] = 1,
                        ["buyer"] = 1244,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633148050,
                        ["quant"] = 1,
                        ["id"] = "1691374185",
                        ["itemLink"] = 1688,
                    },
                    [2] = 
                    {
                        ["price"] = 75,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633251476,
                        ["quant"] = 1,
                        ["id"] = "1692280565",
                        ["itemLink"] = 1688,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp150 green fine miscellaneous weapon glyph",
            },
            ["50:15:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_fireessence.dds",
                ["itemDesc"] = "Superb Glyph of Flame",
                ["oldestTime"] = 1632851714,
                ["wasAltered"] = true,
                ["newestTime"] = 1633251489,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 620,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633251489,
                        ["quant"] = 1,
                        ["id"] = "1692280639",
                        ["itemLink"] = 2602,
                    },
                    [2] = 
                    {
                        ["price"] = 620,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632851714,
                        ["quant"] = 1,
                        ["id"] = "1689156881",
                        ["itemLink"] = 2602,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp150 purple epic miscellaneous weapon glyph",
            },
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_fireessence.dds",
                ["itemDesc"] = "Truly Superb Glyph of Flame",
                ["oldestTime"] = 1632851450,
                ["wasAltered"] = true,
                ["newestTime"] = 1633233369,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 672,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1633045369,
                        ["quant"] = 1,
                        ["id"] = "1690559641",
                        ["itemLink"] = 853,
                    },
                    [2] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 686,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1633047458,
                        ["quant"] = 1,
                        ["id"] = "1690580203",
                        ["itemLink"] = 853,
                    },
                    [3] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 986,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1633111565,
                        ["quant"] = 1,
                        ["id"] = "1691048665",
                        ["itemLink"] = 853,
                    },
                    [4] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 1560,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1633212506,
                        ["quant"] = 1,
                        ["id"] = "1691935383",
                        ["itemLink"] = 853,
                    },
                    [5] = 
                    {
                        ["price"] = 7935,
                        ["guild"] = 1,
                        ["buyer"] = 1715,
                        ["wasKiosk"] = true,
                        ["seller"] = 1716,
                        ["timestamp"] = 1633233369,
                        ["quant"] = 1,
                        ["id"] = "1692148367",
                        ["itemLink"] = 853,
                    },
                    [6] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 2218,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1632851450,
                        ["quant"] = 1,
                        ["id"] = "1689154675",
                        ["itemLink"] = 853,
                    },
                    [7] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 1058,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1632861161,
                        ["quant"] = 1,
                        ["id"] = "1689239327",
                        ["itemLink"] = 853,
                    },
                    [8] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 2272,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1632866874,
                        ["quant"] = 1,
                        ["id"] = "1689280539",
                        ["itemLink"] = 853,
                    },
                    [9] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 47,
                        ["wasKiosk"] = false,
                        ["seller"] = 673,
                        ["timestamp"] = 1632873294,
                        ["quant"] = 1,
                        ["id"] = "1689325621",
                        ["itemLink"] = 853,
                    },
                    [10] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 765,
                        ["wasKiosk"] = false,
                        ["seller"] = 673,
                        ["timestamp"] = 1632886027,
                        ["quant"] = 1,
                        ["id"] = "1689463409",
                        ["itemLink"] = 853,
                    },
                    [11] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 1714,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1632908229,
                        ["quant"] = 1,
                        ["id"] = "1689595993",
                        ["itemLink"] = 853,
                    },
                    [12] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 1973,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1632922454,
                        ["quant"] = 1,
                        ["id"] = "1689669331",
                        ["itemLink"] = 853,
                    },
                    [13] = 
                    {
                        ["price"] = 7935,
                        ["guild"] = 1,
                        ["buyer"] = 1327,
                        ["wasKiosk"] = true,
                        ["seller"] = 1716,
                        ["timestamp"] = 1632930538,
                        ["quant"] = 1,
                        ["id"] = "1689725935",
                        ["itemLink"] = 853,
                    },
                },
                ["totalCount"] = 13,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous weapon glyph",
            },
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_fireessence.dds",
                ["itemDesc"] = "Truly Superb Glyph of Flame",
                ["oldestTime"] = 1632881736,
                ["wasAltered"] = true,
                ["newestTime"] = 1633235435,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633032466,
                        ["quant"] = 1,
                        ["id"] = "1690460923",
                        ["itemLink"] = 733,
                    },
                    [2] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633032467,
                        ["quant"] = 1,
                        ["id"] = "1690460929",
                        ["itemLink"] = 734,
                    },
                    [3] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 1244,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633148037,
                        ["quant"] = 1,
                        ["id"] = "1691374097",
                        ["itemLink"] = 1683,
                    },
                    [4] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 1244,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633148039,
                        ["quant"] = 1,
                        ["id"] = "1691374107",
                        ["itemLink"] = 1684,
                    },
                    [5] = 
                    {
                        ["price"] = 160,
                        ["guild"] = 1,
                        ["buyer"] = 1639,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633225372,
                        ["quant"] = 1,
                        ["id"] = "1692068221",
                        ["itemLink"] = 2386,
                    },
                    [6] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1725,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633235435,
                        ["quant"] = 1,
                        ["id"] = "1692164043",
                        ["itemLink"] = 2482,
                    },
                    [7] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632881736,
                        ["quant"] = 1,
                        ["id"] = "1689414599",
                        ["itemLink"] = 2482,
                    },
                    [8] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632885355,
                        ["quant"] = 1,
                        ["id"] = "1689456613",
                        ["itemLink"] = 734,
                    },
                    [9] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 2555,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632942580,
                        ["quant"] = 1,
                        ["id"] = "1689814483",
                        ["itemLink"] = 3777,
                    },
                },
                ["totalCount"] = 9,
                ["itemAdderText"] = "cp160 white normal miscellaneous weapon glyph",
            },
        },
        [115216] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bre_fur_chair002.dds",
                ["itemDesc"] = "Breton Armchair, Padded",
                ["oldestTime"] = 1633238320,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238320,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 102630,
                        ["guild"] = 1,
                        ["buyer"] = 1745,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1633238320,
                        ["quant"] = 6,
                        ["id"] = "1692187769",
                        ["itemLink"] = 2515,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [57058] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Wamasu Spew",
                ["oldestTime"] = 1632956045,
                ["wasAltered"] = true,
                ["newestTime"] = 1632956045,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 295,
                        ["guild"] = 1,
                        ["buyer"] = 2046,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632956045,
                        ["quant"] = 1,
                        ["id"] = "1689927907",
                        ["itemLink"] = 3867,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [177123] = 
        {
            ["1:0:2:51:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_pants_light.dds",
                ["itemDesc"] = "Companion's Breeches",
                ["oldestTime"] = 1632972931,
                ["wasAltered"] = true,
                ["newestTime"] = 1632972931,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 189,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1632972931,
                        ["quant"] = 1,
                        ["id"] = "1690082399",
                        ["itemLink"] = 201,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine light apparel legs vigorous",
            },
        },
        [114969] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 44: Silken Ring Belts",
                ["oldestTime"] = 1632992892,
                ["wasAltered"] = true,
                ["newestTime"] = 1632992892,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11900,
                        ["guild"] = 1,
                        ["buyer"] = 365,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632992892,
                        ["quant"] = 1,
                        ["id"] = "1690200205",
                        ["itemLink"] = 362,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [135397] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_staff_c.dds",
                ["itemDesc"] = "Gryphon's Restoration Staff",
                ["oldestTime"] = 1632963262,
                ["wasAltered"] = true,
                ["newestTime"] = 1632963262,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 83,
                        ["wasKiosk"] = true,
                        ["seller"] = 51,
                        ["timestamp"] = 1632963262,
                        ["quant"] = 1,
                        ["id"] = "1689988459",
                        ["itemLink"] = 3940,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set gryphon's ferocity healing staff two-handed precise",
            },
        },
        [135142] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_silver_refined.dds",
                ["itemDesc"] = "Silver Ounce",
                ["oldestTime"] = 1633016630,
                ["wasAltered"] = true,
                ["newestTime"] = 1633219150,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 34000,
                        ["guild"] = 1,
                        ["buyer"] = 475,
                        ["wasKiosk"] = true,
                        ["seller"] = 476,
                        ["timestamp"] = 1633016630,
                        ["quant"] = 200,
                        ["id"] = "1690338699",
                        ["itemLink"] = 544,
                    },
                    [2] = 
                    {
                        ["price"] = 12500,
                        ["guild"] = 1,
                        ["buyer"] = 1141,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633135377,
                        ["quant"] = 100,
                        ["id"] = "1691246929",
                        ["itemLink"] = 544,
                    },
                    [3] = 
                    {
                        ["price"] = 34000,
                        ["guild"] = 1,
                        ["buyer"] = 1603,
                        ["wasKiosk"] = true,
                        ["seller"] = 476,
                        ["timestamp"] = 1633219150,
                        ["quant"] = 200,
                        ["id"] = "1692003625",
                        ["itemLink"] = 544,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [130023] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 52: Redoran Staves",
                ["oldestTime"] = 1633190564,
                ["wasAltered"] = true,
                ["newestTime"] = 1633190564,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13999,
                        ["guild"] = 1,
                        ["buyer"] = 450,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633190564,
                        ["quant"] = 1,
                        ["id"] = "1691693995",
                        ["itemLink"] = 2101,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [151859] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_str_altgreenhouse001.dds",
                ["itemDesc"] = "Alinor Greenhouse, Summer",
                ["oldestTime"] = 1632879978,
                ["wasAltered"] = true,
                ["newestTime"] = 1633231821,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 144444,
                        ["guild"] = 1,
                        ["buyer"] = 1699,
                        ["wasKiosk"] = true,
                        ["seller"] = 1700,
                        ["timestamp"] = 1633231821,
                        ["quant"] = 1,
                        ["id"] = "1692133339",
                        ["itemLink"] = 2444,
                    },
                    [2] = 
                    {
                        ["price"] = 144444,
                        ["guild"] = 1,
                        ["buyer"] = 2331,
                        ["wasKiosk"] = true,
                        ["seller"] = 1700,
                        ["timestamp"] = 1632879978,
                        ["quant"] = 1,
                        ["id"] = "1689396607",
                        ["itemLink"] = 2444,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary furnishings structures",
            },
        },
        [165791] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_inc_soupbowl002.dds",
                ["itemDesc"] = "Solitude Dinner Bowl, Vegetable Soup",
                ["oldestTime"] = 1632985322,
                ["wasAltered"] = true,
                ["newestTime"] = 1632985322,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 317,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1632985322,
                        ["quant"] = 1,
                        ["id"] = "1690161437",
                        ["itemLink"] = 321,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings hearth",
            },
        },
        [152042] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Elsweyr Bookshelf, Elegant Wooden",
                ["oldestTime"] = 1633014736,
                ["wasAltered"] = true,
                ["newestTime"] = 1633014736,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2680,
                        ["guild"] = 1,
                        ["buyer"] = 467,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633014736,
                        ["quant"] = 1,
                        ["id"] = "1690323787",
                        ["itemLink"] = 535,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [132595] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 57: Ebonshadow Swords",
                ["oldestTime"] = 1633229988,
                ["wasAltered"] = true,
                ["newestTime"] = 1633229988,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1687,
                        ["wasKiosk"] = true,
                        ["seller"] = 161,
                        ["timestamp"] = 1633229988,
                        ["quant"] = 1,
                        ["id"] = "1692115677",
                        ["itemLink"] = 2437,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [34345] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_berry_004.dds",
                ["itemDesc"] = "Surilie Grapes",
                ["oldestTime"] = 1632849870,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305828,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 985,
                        ["guild"] = 1,
                        ["buyer"] = 1683,
                        ["wasKiosk"] = true,
                        ["seller"] = 442,
                        ["timestamp"] = 1633229637,
                        ["quant"] = 100,
                        ["id"] = "1692112029",
                        ["itemLink"] = 2435,
                    },
                    [2] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633305828,
                        ["quant"] = 200,
                        ["id"] = "1692798693",
                        ["itemLink"] = 2435,
                    },
                    [3] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632849870,
                        ["quant"] = 200,
                        ["id"] = "1689142823",
                        ["itemLink"] = 2435,
                    },
                    [4] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1632849872,
                        ["quant"] = 100,
                        ["id"] = "1689142841",
                        ["itemLink"] = 2435,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [57837] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 17: Xivkyn Boots",
                ["oldestTime"] = 1632827166,
                ["wasAltered"] = true,
                ["newestTime"] = 1633280101,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 1926,
                        ["wasKiosk"] = true,
                        ["seller"] = 944,
                        ["timestamp"] = 1633280101,
                        ["quant"] = 1,
                        ["id"] = "1692516501",
                        ["itemLink"] = 2730,
                    },
                    [2] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 1849,
                        ["wasKiosk"] = true,
                        ["seller"] = 894,
                        ["timestamp"] = 1632827166,
                        ["quant"] = 1,
                        ["id"] = "1688976921",
                        ["itemLink"] = 2730,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [126928] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Redoran Settee, Fungal Cushion",
                ["oldestTime"] = 1633227772,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227772,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 65000,
                        ["guild"] = 1,
                        ["buyer"] = 521,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633227772,
                        ["quant"] = 1,
                        ["id"] = "1692093539",
                        ["itemLink"] = 2415,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [56047] = 
        {
            ["1:0:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_light_hands_a.dds",
                ["itemDesc"] = "Homespun Gloves",
                ["oldestTime"] = 1632974864,
                ["wasAltered"] = true,
                ["newestTime"] = 1633290130,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 206,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1632974864,
                        ["quant"] = 1,
                        ["id"] = "1690094857",
                        ["itemLink"] = 217,
                    },
                    [2] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 878,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633078796,
                        ["quant"] = 1,
                        ["id"] = "1690830901",
                        ["itemLink"] = 217,
                    },
                    [3] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1358,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633177093,
                        ["quant"] = 1,
                        ["id"] = "1691563359",
                        ["itemLink"] = 217,
                    },
                    [4] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 1669,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633228597,
                        ["quant"] = 1,
                        ["id"] = "1692103063",
                        ["itemLink"] = 217,
                    },
                    [5] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1977,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633290130,
                        ["quant"] = 1,
                        ["id"] = "1692628619",
                        ["itemLink"] = 217,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 white normal light apparel hands nirnhoned",
            },
            ["50:15:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_light_hands_d.dds",
                ["itemDesc"] = "Ancestor Silk Gloves",
                ["oldestTime"] = 1632874769,
                ["wasAltered"] = true,
                ["newestTime"] = 1632874769,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4999,
                        ["guild"] = 1,
                        ["buyer"] = 2320,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632874769,
                        ["quant"] = 1,
                        ["id"] = "1689339221",
                        ["itemLink"] = 3408,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 white normal light apparel hands nirnhoned",
            },
        },
        [172329] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_1hhammer_a.dds",
                ["itemDesc"] = "Bog Raider's Mace",
                ["oldestTime"] = 1633048873,
                ["wasAltered"] = true,
                ["newestTime"] = 1633048873,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 690,
                        ["wasKiosk"] = true,
                        ["seller"] = 691,
                        ["timestamp"] = 1633048873,
                        ["quant"] = 1,
                        ["id"] = "1690594317",
                        ["itemLink"] = 878,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set bog raider mace one-handed precise",
            },
        },
        [76844] = 
        {
            ["50:15:1:9:1250817"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_poison_002_red_005.dds",
                ["itemDesc"] = "Escapist's Poison IX",
                ["oldestTime"] = 1632986699,
                ["wasAltered"] = true,
                ["newestTime"] = 1633127275,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14700,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 324,
                        ["timestamp"] = 1632986699,
                        ["quant"] = 100,
                        ["id"] = "1690167961",
                        ["itemLink"] = 329,
                    },
                    [2] = 
                    {
                        ["price"] = 14700,
                        ["guild"] = 1,
                        ["buyer"] = 670,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633045289,
                        ["quant"] = 100,
                        ["id"] = "1690559039",
                        ["itemLink"] = 329,
                    },
                    [3] = 
                    {
                        ["price"] = 14700,
                        ["guild"] = 1,
                        ["buyer"] = 670,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633045290,
                        ["quant"] = 100,
                        ["id"] = "1690559045",
                        ["itemLink"] = 329,
                    },
                    [4] = 
                    {
                        ["price"] = 14700,
                        ["guild"] = 1,
                        ["buyer"] = 670,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633045293,
                        ["quant"] = 100,
                        ["id"] = "1690559077",
                        ["itemLink"] = 329,
                    },
                    [5] = 
                    {
                        ["price"] = 14700,
                        ["guild"] = 1,
                        ["buyer"] = 670,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633045295,
                        ["quant"] = 100,
                        ["id"] = "1690559095",
                        ["itemLink"] = 329,
                    },
                    [6] = 
                    {
                        ["price"] = 14700,
                        ["guild"] = 1,
                        ["buyer"] = 1092,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633127268,
                        ["quant"] = 100,
                        ["id"] = "1691161017",
                        ["itemLink"] = 329,
                    },
                    [7] = 
                    {
                        ["price"] = 14700,
                        ["guild"] = 1,
                        ["buyer"] = 1092,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633127269,
                        ["quant"] = 100,
                        ["id"] = "1691161037",
                        ["itemLink"] = 329,
                    },
                    [8] = 
                    {
                        ["price"] = 14700,
                        ["guild"] = 1,
                        ["buyer"] = 1092,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633127269,
                        ["quant"] = 100,
                        ["id"] = "1691161057",
                        ["itemLink"] = 329,
                    },
                    [9] = 
                    {
                        ["price"] = 14700,
                        ["guild"] = 1,
                        ["buyer"] = 1092,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633127270,
                        ["quant"] = 100,
                        ["id"] = "1691161077",
                        ["itemLink"] = 329,
                    },
                    [10] = 
                    {
                        ["price"] = 14700,
                        ["guild"] = 1,
                        ["buyer"] = 1092,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633127271,
                        ["quant"] = 100,
                        ["id"] = "1691161097",
                        ["itemLink"] = 329,
                    },
                    [11] = 
                    {
                        ["price"] = 14700,
                        ["guild"] = 1,
                        ["buyer"] = 1092,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633127272,
                        ["quant"] = 100,
                        ["id"] = "1691161111",
                        ["itemLink"] = 329,
                    },
                    [12] = 
                    {
                        ["price"] = 14700,
                        ["guild"] = 1,
                        ["buyer"] = 1092,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633127273,
                        ["quant"] = 100,
                        ["id"] = "1691161153",
                        ["itemLink"] = 329,
                    },
                    [13] = 
                    {
                        ["price"] = 14700,
                        ["guild"] = 1,
                        ["buyer"] = 1092,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633127274,
                        ["quant"] = 100,
                        ["id"] = "1691161173",
                        ["itemLink"] = 329,
                    },
                    [14] = 
                    {
                        ["price"] = 14700,
                        ["guild"] = 1,
                        ["buyer"] = 1092,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633127275,
                        ["quant"] = 100,
                        ["id"] = "1691161185",
                        ["itemLink"] = 329,
                    },
                    [15] = 
                    {
                        ["price"] = 14700,
                        ["guild"] = 1,
                        ["buyer"] = 1092,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633127275,
                        ["quant"] = 100,
                        ["id"] = "1691161195",
                        ["itemLink"] = 329,
                    },
                },
                ["totalCount"] = 15,
                ["itemAdderText"] = "cp150 white normal consumable poison",
            },
            ["50:15:1:9:1245443"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_poison_002_red_005.dds",
                ["itemDesc"] = "Escapist's Poison IX",
                ["oldestTime"] = 1632842264,
                ["wasAltered"] = true,
                ["newestTime"] = 1633236511,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14500,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 324,
                        ["timestamp"] = 1632986694,
                        ["quant"] = 100,
                        ["id"] = "1690167943",
                        ["itemLink"] = 328,
                    },
                    [2] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 670,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633045287,
                        ["quant"] = 100,
                        ["id"] = "1690559019",
                        ["itemLink"] = 328,
                    },
                    [3] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 670,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633045288,
                        ["quant"] = 100,
                        ["id"] = "1690559027",
                        ["itemLink"] = 328,
                    },
                    [4] = 
                    {
                        ["price"] = 14500,
                        ["guild"] = 1,
                        ["buyer"] = 1521,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633205045,
                        ["quant"] = 100,
                        ["id"] = "1691842965",
                        ["itemLink"] = 328,
                    },
                    [5] = 
                    {
                        ["price"] = 14500,
                        ["guild"] = 1,
                        ["buyer"] = 1521,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633205050,
                        ["quant"] = 100,
                        ["id"] = "1691843027",
                        ["itemLink"] = 328,
                    },
                    [6] = 
                    {
                        ["price"] = 14500,
                        ["guild"] = 1,
                        ["buyer"] = 1521,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1633205096,
                        ["quant"] = 100,
                        ["id"] = "1691843425",
                        ["itemLink"] = 328,
                    },
                    [7] = 
                    {
                        ["price"] = 14500,
                        ["guild"] = 1,
                        ["buyer"] = 38,
                        ["wasKiosk"] = false,
                        ["seller"] = 324,
                        ["timestamp"] = 1633236511,
                        ["quant"] = 100,
                        ["id"] = "1692171977",
                        ["itemLink"] = 328,
                    },
                    [8] = 
                    {
                        ["price"] = 2100,
                        ["guild"] = 1,
                        ["buyer"] = 2189,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1632842264,
                        ["quant"] = 15,
                        ["id"] = "1689075469",
                        ["itemLink"] = 328,
                    },
                    [9] = 
                    {
                        ["price"] = 2100,
                        ["guild"] = 1,
                        ["buyer"] = 2189,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1632842267,
                        ["quant"] = 15,
                        ["id"] = "1689075513",
                        ["itemLink"] = 328,
                    },
                    [10] = 
                    {
                        ["price"] = 2100,
                        ["guild"] = 1,
                        ["buyer"] = 2189,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1632842270,
                        ["quant"] = 15,
                        ["id"] = "1689075539",
                        ["itemLink"] = 328,
                    },
                    [11] = 
                    {
                        ["price"] = 14500,
                        ["guild"] = 1,
                        ["buyer"] = 2189,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1632842273,
                        ["quant"] = 100,
                        ["id"] = "1689075571",
                        ["itemLink"] = 328,
                    },
                    [12] = 
                    {
                        ["price"] = 14500,
                        ["guild"] = 1,
                        ["buyer"] = 2189,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1632842276,
                        ["quant"] = 100,
                        ["id"] = "1689075595",
                        ["itemLink"] = 328,
                    },
                    [13] = 
                    {
                        ["price"] = 14500,
                        ["guild"] = 1,
                        ["buyer"] = 2189,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1632842279,
                        ["quant"] = 100,
                        ["id"] = "1689075615",
                        ["itemLink"] = 328,
                    },
                    [14] = 
                    {
                        ["price"] = 14500,
                        ["guild"] = 1,
                        ["buyer"] = 2189,
                        ["wasKiosk"] = true,
                        ["seller"] = 324,
                        ["timestamp"] = 1632842283,
                        ["quant"] = 100,
                        ["id"] = "1689075653",
                        ["itemLink"] = 328,
                    },
                },
                ["totalCount"] = 14,
                ["itemAdderText"] = "cp150 white normal consumable poison",
            },
        },
        [56948] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Rabbit Haunch with Cheese Grits",
                ["oldestTime"] = 1633185116,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185116,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633185116,
                        ["quant"] = 1,
                        ["id"] = "1691630203",
                        ["itemLink"] = 1988,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [57587] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_dwemer_shiny_tube.dds",
                ["itemDesc"] = "Dwemer Frame",
                ["oldestTime"] = 1632890618,
                ["wasAltered"] = true,
                ["newestTime"] = 1633231768,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6650,
                        ["guild"] = 1,
                        ["buyer"] = 151,
                        ["wasKiosk"] = false,
                        ["seller"] = 199,
                        ["timestamp"] = 1633048140,
                        ["quant"] = 7,
                        ["id"] = "1690587305",
                        ["itemLink"] = 876,
                    },
                    [2] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 62,
                        ["timestamp"] = 1633185357,
                        ["quant"] = 2,
                        ["id"] = "1691633043",
                        ["itemLink"] = 876,
                    },
                    [3] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 1541,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1633208474,
                        ["quant"] = 1,
                        ["id"] = "1691887535",
                        ["itemLink"] = 876,
                    },
                    [4] = 
                    {
                        ["price"] = 4400,
                        ["guild"] = 1,
                        ["buyer"] = 1541,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633208475,
                        ["quant"] = 4,
                        ["id"] = "1691887549",
                        ["itemLink"] = 876,
                    },
                    [5] = 
                    {
                        ["price"] = 10395,
                        ["guild"] = 1,
                        ["buyer"] = 447,
                        ["wasKiosk"] = true,
                        ["seller"] = 327,
                        ["timestamp"] = 1633223484,
                        ["quant"] = 11,
                        ["id"] = "1692048813",
                        ["itemLink"] = 876,
                    },
                    [6] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633231768,
                        ["quant"] = 2,
                        ["id"] = "1692133143",
                        ["itemLink"] = 876,
                    },
                    [7] = 
                    {
                        ["price"] = 1025,
                        ["guild"] = 1,
                        ["buyer"] = 2410,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632890618,
                        ["quant"] = 1,
                        ["id"] = "1689496581",
                        ["itemLink"] = 876,
                    },
                    [8] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632925707,
                        ["quant"] = 2,
                        ["id"] = "1689692211",
                        ["itemLink"] = 876,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [135156] = 
        {
            ["1:0:1:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/jewelrycrafting_trait_refined_antimony.dds",
                ["itemDesc"] = "Antimony",
                ["oldestTime"] = 1633125409,
                ["wasAltered"] = true,
                ["newestTime"] = 1633158269,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 166,
                        ["timestamp"] = 1633125409,
                        ["quant"] = 10,
                        ["id"] = "1691145735",
                        ["itemLink"] = 1474,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633158267,
                        ["quant"] = 10,
                        ["id"] = "1691455925",
                        ["itemLink"] = 1474,
                    },
                    [3] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633158268,
                        ["quant"] = 10,
                        ["id"] = "1691455933",
                        ["itemLink"] = 1474,
                    },
                    [4] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633158269,
                        ["quant"] = 10,
                        ["id"] = "1691455943",
                        ["itemLink"] = 1474,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 white normal materials jewelry trait healthy",
            },
        },
        [69748] = 
        {
            ["50:16:4:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_d.dds",
                ["itemDesc"] = "Inferno Staff of Julianos",
                ["oldestTime"] = 1633212451,
                ["wasAltered"] = true,
                ["newestTime"] = 1633212451,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 1560,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633212451,
                        ["quant"] = 1,
                        ["id"] = "1691935063",
                        ["itemLink"] = 2287,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set law of julianos flame staff two-handed precise",
            },
        },
        [117219] = 
        {
            ["50:16:4:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_staff_a.dds",
                ["itemDesc"] = "Lightning Staff of the Powerful Assault",
                ["oldestTime"] = 1633203357,
                ["wasAltered"] = true,
                ["newestTime"] = 1633203357,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 157912,
                        ["guild"] = 1,
                        ["buyer"] = 949,
                        ["wasKiosk"] = true,
                        ["seller"] = 1509,
                        ["timestamp"] = 1633203357,
                        ["quant"] = 1,
                        ["id"] = "1691827377",
                        ["itemLink"] = 2231,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set powerful assault lightning staff two-handed decisive",
            },
        },
        [181565] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Turret, Castle",
                ["oldestTime"] = 1632935546,
                ["wasAltered"] = true,
                ["newestTime"] = 1633235060,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 79,
                        ["timestamp"] = 1633060415,
                        ["quant"] = 1,
                        ["id"] = "1690713735",
                        ["itemLink"] = 1014,
                    },
                    [2] = 
                    {
                        ["price"] = 85000,
                        ["guild"] = 1,
                        ["buyer"] = 1371,
                        ["wasKiosk"] = true,
                        ["seller"] = 1372,
                        ["timestamp"] = 1633181168,
                        ["quant"] = 1,
                        ["id"] = "1691595243",
                        ["itemLink"] = 1014,
                    },
                    [3] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1727,
                        ["wasKiosk"] = true,
                        ["seller"] = 827,
                        ["timestamp"] = 1633235060,
                        ["quant"] = 1,
                        ["id"] = "1692161009",
                        ["itemLink"] = 1014,
                    },
                    [4] = 
                    {
                        ["price"] = 85000,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 604,
                        ["timestamp"] = 1632935546,
                        ["quant"] = 1,
                        ["id"] = "1689766055",
                        ["itemLink"] = 1014,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [45940] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Radishes in Rice",
                ["oldestTime"] = 1633172337,
                ["wasAltered"] = true,
                ["newestTime"] = 1633172337,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1345,
                        ["wasKiosk"] = true,
                        ["seller"] = 61,
                        ["timestamp"] = 1633172337,
                        ["quant"] = 1,
                        ["id"] = "1691532045",
                        ["itemLink"] = 1888,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [122873] = 
        {
            ["50:16:2:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_telvanni_light_head_a.dds",
                ["itemDesc"] = "War Maiden's Hat",
                ["oldestTime"] = 1632936826,
                ["wasAltered"] = true,
                ["newestTime"] = 1632936826,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 226,
                        ["wasKiosk"] = false,
                        ["seller"] = 527,
                        ["timestamp"] = 1632936826,
                        ["quant"] = 1,
                        ["id"] = "1689773997",
                        ["itemLink"] = 3743,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set war maiden head reinforced",
            },
        },
        [172026] = 
        {
            ["50:16:4:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_robe_a.dds",
                ["itemDesc"] = "Robe of Frostbite",
                ["oldestTime"] = 1633069685,
                ["wasAltered"] = true,
                ["newestTime"] = 1633069685,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3800,
                        ["guild"] = 1,
                        ["buyer"] = 836,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1633069685,
                        ["quant"] = 1,
                        ["id"] = "1690776625",
                        ["itemLink"] = 1081,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set frostbite chest reinforced",
            },
        },
        [118267] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_inc_varpuzzlepaintings003.dds",
                ["itemDesc"] = "Painting of Autumn, Bolted",
                ["oldestTime"] = 1633238161,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238161,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1999,
                        ["guild"] = 1,
                        ["buyer"] = 1745,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633238161,
                        ["quant"] = 1,
                        ["id"] = "1692186579",
                        ["itemLink"] = 2505,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings gallery",
            },
        },
        [135164] = 
        {
            ["50:16:2:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nocturnal_1haxe_a.dds",
                ["itemDesc"] = "Gloom-Graced Axe",
                ["oldestTime"] = 1632961934,
                ["wasAltered"] = true,
                ["newestTime"] = 1632961934,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1850,
                        ["guild"] = 1,
                        ["buyer"] = 2638,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1632961934,
                        ["quant"] = 1,
                        ["id"] = "1689974741",
                        ["itemLink"] = 3930,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set grace of gloom axe one-handed infused",
            },
        },
        [124669] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/fragment_costume_sixthhouse_incense.dds",
                ["itemDesc"] = "Sixth House Incense of Toolwork",
                ["oldestTime"] = 1633134443,
                ["wasAltered"] = true,
                ["newestTime"] = 1633134443,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1133,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633134443,
                        ["quant"] = 1,
                        ["id"] = "1691235179",
                        ["itemLink"] = 1551,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [30160] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_flower_vipers_bugloss_r1.dds",
                ["itemDesc"] = "Bugloss",
                ["oldestTime"] = 1632825543,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294588,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 265,
                        ["wasKiosk"] = true,
                        ["seller"] = 267,
                        ["timestamp"] = 1632981238,
                        ["quant"] = 200,
                        ["id"] = "1690137827",
                        ["itemLink"] = 273,
                    },
                    [2] = 
                    {
                        ["price"] = 5750,
                        ["guild"] = 1,
                        ["buyer"] = 420,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1633006245,
                        ["quant"] = 25,
                        ["id"] = "1690266407",
                        ["itemLink"] = 273,
                    },
                    [3] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 919,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633090549,
                        ["quant"] = 60,
                        ["id"] = "1690891905",
                        ["itemLink"] = 273,
                    },
                    [4] = 
                    {
                        ["price"] = 3728,
                        ["guild"] = 1,
                        ["buyer"] = 919,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633090553,
                        ["quant"] = 16,
                        ["id"] = "1690891925",
                        ["itemLink"] = 273,
                    },
                    [5] = 
                    {
                        ["price"] = 44000,
                        ["guild"] = 1,
                        ["buyer"] = 1242,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633148009,
                        ["quant"] = 200,
                        ["id"] = "1691373935",
                        ["itemLink"] = 273,
                    },
                    [6] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633154415,
                        ["quant"] = 4,
                        ["id"] = "1691427103",
                        ["itemLink"] = 273,
                    },
                    [7] = 
                    {
                        ["price"] = 11500,
                        ["guild"] = 1,
                        ["buyer"] = 1366,
                        ["wasKiosk"] = true,
                        ["seller"] = 944,
                        ["timestamp"] = 1633180548,
                        ["quant"] = 50,
                        ["id"] = "1691588887",
                        ["itemLink"] = 273,
                    },
                    [8] = 
                    {
                        ["price"] = 23999,
                        ["guild"] = 1,
                        ["buyer"] = 1366,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633180553,
                        ["quant"] = 100,
                        ["id"] = "1691588935",
                        ["itemLink"] = 273,
                    },
                    [9] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 1366,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633180554,
                        ["quant"] = 100,
                        ["id"] = "1691588947",
                        ["itemLink"] = 273,
                    },
                    [10] = 
                    {
                        ["price"] = 50800,
                        ["guild"] = 1,
                        ["buyer"] = 1514,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633204221,
                        ["quant"] = 200,
                        ["id"] = "1691835631",
                        ["itemLink"] = 273,
                    },
                    [11] = 
                    {
                        ["price"] = 53313,
                        ["guild"] = 1,
                        ["buyer"] = 1514,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633204223,
                        ["quant"] = 200,
                        ["id"] = "1691835655",
                        ["itemLink"] = 273,
                    },
                    [12] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1697,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633231700,
                        ["quant"] = 4,
                        ["id"] = "1692132445",
                        ["itemLink"] = 273,
                    },
                    [13] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 1697,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633231701,
                        ["quant"] = 100,
                        ["id"] = "1692132449",
                        ["itemLink"] = 273,
                    },
                    [14] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 1697,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633231703,
                        ["quant"] = 100,
                        ["id"] = "1692132459",
                        ["itemLink"] = 273,
                    },
                    [15] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1867,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633267964,
                        ["quant"] = 4,
                        ["id"] = "1692384549",
                        ["itemLink"] = 273,
                    },
                    [16] = 
                    {
                        ["price"] = 1435,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 99,
                        ["timestamp"] = 1633294582,
                        ["quant"] = 7,
                        ["id"] = "1692684817",
                        ["itemLink"] = 273,
                    },
                    [17] = 
                    {
                        ["price"] = 3029,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633294588,
                        ["quant"] = 13,
                        ["id"] = "1692684865",
                        ["itemLink"] = 273,
                    },
                    [18] = 
                    {
                        ["price"] = 5900,
                        ["guild"] = 1,
                        ["buyer"] = 1252,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632825543,
                        ["quant"] = 25,
                        ["id"] = "1688966411",
                        ["itemLink"] = 273,
                    },
                    [19] = 
                    {
                        ["price"] = 43745,
                        ["guild"] = 1,
                        ["buyer"] = 1252,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1632825543,
                        ["quant"] = 184,
                        ["id"] = "1688966419",
                        ["itemLink"] = 273,
                    },
                    [20] = 
                    {
                        ["price"] = 1864,
                        ["guild"] = 1,
                        ["buyer"] = 2294,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632871342,
                        ["quant"] = 8,
                        ["id"] = "1689312257",
                        ["itemLink"] = 273,
                    },
                    [21] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2552,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632941732,
                        ["quant"] = 10,
                        ["id"] = "1689807315",
                        ["itemLink"] = 273,
                    },
                },
                ["totalCount"] = 21,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [176727] = 
        {
            ["1:0:3:48:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_pants_light.dds",
                ["itemDesc"] = "Companion's Breeches",
                ["oldestTime"] = 1632862310,
                ["wasAltered"] = true,
                ["newestTime"] = 1633241999,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 807,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633064117,
                        ["quant"] = 1,
                        ["id"] = "1690740983",
                        ["itemLink"] = 1048,
                    },
                    [2] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 93,
                        ["wasKiosk"] = false,
                        ["seller"] = 408,
                        ["timestamp"] = 1633241999,
                        ["quant"] = 1,
                        ["id"] = "1692211803",
                        ["itemLink"] = 1048,
                    },
                    [3] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 2250,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1632862310,
                        ["quant"] = 1,
                        ["id"] = "1689246495",
                        ["itemLink"] = 1048,
                    },
                    [4] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 2250,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1632947584,
                        ["quant"] = 1,
                        ["id"] = "1689855431",
                        ["itemLink"] = 1048,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior light apparel legs soothing",
            },
        },
    },
}
