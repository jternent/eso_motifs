GS05DataSavedVariables =
{
    ["listingseu"] = 
    {
    },
    ["listingsna"] = 
    {
    },
    ["dataeu"] = 
    {
    },
    ["datana"] = 
    {
        [68608] = 
        {
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_heavy_chest_a.dds",
                ["itemDesc"] = "Cuirass of the Pariah",
                ["oldestTime"] = 1633027499,
                ["wasAltered"] = true,
                ["newestTime"] = 1633027499,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 334,
                        ["wasKiosk"] = false,
                        ["seller"] = 360,
                        ["timestamp"] = 1633027499,
                        ["quant"] = 1,
                        ["id"] = "1690423823",
                        ["itemLink"] = 687,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set mark of the pariah chest infused",
            },
        },
        [181507] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_inc_leyunfinishedpainting001.dds",
                ["itemDesc"] = "Blackwood Cottage Painting, Unframed",
                ["oldestTime"] = 1633042591,
                ["wasAltered"] = true,
                ["newestTime"] = 1633042591,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 63600,
                        ["guild"] = 1,
                        ["buyer"] = 645,
                        ["wasKiosk"] = true,
                        ["seller"] = 17,
                        ["timestamp"] = 1633042591,
                        ["quant"] = 1,
                        ["id"] = "1690534547",
                        ["itemLink"] = 830,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings gallery",
            },
        },
        [129796] = 
        {
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_heavy_chest_a.dds",
                ["itemDesc"] = "Cuirass of the Pariah",
                ["oldestTime"] = 1633049781,
                ["wasAltered"] = true,
                ["newestTime"] = 1633049781,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 334,
                        ["wasKiosk"] = false,
                        ["seller"] = 597,
                        ["timestamp"] = 1633049781,
                        ["quant"] = 1,
                        ["id"] = "1690602541",
                        ["itemLink"] = 884,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set mark of the pariah chest training",
            },
        },
        [126983] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Telvanni Nightstand, Organic",
                ["oldestTime"] = 1633227674,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227674,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 521,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633227674,
                        ["quant"] = 1,
                        ["id"] = "1692092675",
                        ["itemLink"] = 2410,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [178440] = 
        {
            ["1:0:4:50:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_gloves_heavy.dds",
                ["itemDesc"] = "Companion's Gauntlets",
                ["oldestTime"] = 1633132535,
                ["wasAltered"] = true,
                ["newestTime"] = 1633132535,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1499999,
                        ["guild"] = 1,
                        ["buyer"] = 1119,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633132535,
                        ["quant"] = 1,
                        ["id"] = "1691213757",
                        ["itemLink"] = 1542,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic heavy apparel hands bolstered",
            },
        },
        [178441] = 
        {
            ["1:0:4:51:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_gloves_heavy.dds",
                ["itemDesc"] = "Companion's Gauntlets",
                ["oldestTime"] = 1633054488,
                ["wasAltered"] = true,
                ["newestTime"] = 1633054488,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100000,
                        ["guild"] = 1,
                        ["buyer"] = 735,
                        ["wasKiosk"] = true,
                        ["seller"] = 47,
                        ["timestamp"] = 1633054488,
                        ["quant"] = 1,
                        ["id"] = "1690650113",
                        ["itemLink"] = 940,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic heavy apparel hands vigorous",
            },
        },
        [139018] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_soup_004.dds",
                ["itemDesc"] = "Artaeum Takeaway Broth",
                ["oldestTime"] = 1632956844,
                ["wasAltered"] = true,
                ["newestTime"] = 1633279364,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 582,
                        ["wasKiosk"] = true,
                        ["seller"] = 583,
                        ["timestamp"] = 1633033862,
                        ["quant"] = 1,
                        ["id"] = "1690468749",
                        ["itemLink"] = 753,
                    },
                    [2] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 582,
                        ["wasKiosk"] = true,
                        ["seller"] = 583,
                        ["timestamp"] = 1633033863,
                        ["quant"] = 1,
                        ["id"] = "1690468759",
                        ["itemLink"] = 753,
                    },
                    [3] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 582,
                        ["wasKiosk"] = true,
                        ["seller"] = 583,
                        ["timestamp"] = 1633033864,
                        ["quant"] = 1,
                        ["id"] = "1690468765",
                        ["itemLink"] = 753,
                    },
                    [4] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 582,
                        ["wasKiosk"] = true,
                        ["seller"] = 583,
                        ["timestamp"] = 1633033865,
                        ["quant"] = 1,
                        ["id"] = "1690468779",
                        ["itemLink"] = 753,
                    },
                    [5] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 582,
                        ["wasKiosk"] = true,
                        ["seller"] = 583,
                        ["timestamp"] = 1633033866,
                        ["quant"] = 1,
                        ["id"] = "1690468787",
                        ["itemLink"] = 753,
                    },
                    [6] = 
                    {
                        ["price"] = 8684,
                        ["guild"] = 1,
                        ["buyer"] = 340,
                        ["wasKiosk"] = false,
                        ["seller"] = 10,
                        ["timestamp"] = 1633078520,
                        ["quant"] = 1,
                        ["id"] = "1690828877",
                        ["itemLink"] = 753,
                    },
                    [7] = 
                    {
                        ["price"] = 66000,
                        ["guild"] = 1,
                        ["buyer"] = 1017,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633115121,
                        ["quant"] = 10,
                        ["id"] = "1691072901",
                        ["itemLink"] = 753,
                    },
                    [8] = 
                    {
                        ["price"] = 66000,
                        ["guild"] = 1,
                        ["buyer"] = 1489,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633200572,
                        ["quant"] = 10,
                        ["id"] = "1691795539",
                        ["itemLink"] = 753,
                    },
                    [9] = 
                    {
                        ["price"] = 66000,
                        ["guild"] = 1,
                        ["buyer"] = 1924,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633279364,
                        ["quant"] = 10,
                        ["id"] = "1692508589",
                        ["itemLink"] = 753,
                    },
                    [10] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2616,
                        ["wasKiosk"] = true,
                        ["seller"] = 583,
                        ["timestamp"] = 1632956844,
                        ["quant"] = 1,
                        ["id"] = "1689934777",
                        ["itemLink"] = 753,
                    },
                    [11] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2616,
                        ["wasKiosk"] = true,
                        ["seller"] = 583,
                        ["timestamp"] = 1632956847,
                        ["quant"] = 1,
                        ["id"] = "1689934797",
                        ["itemLink"] = 753,
                    },
                },
                ["totalCount"] = 11,
                ["itemAdderText"] = "rr01 gold legendary consumable food",
            },
        },
        [114955] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 45: Mazzatun Bows",
                ["oldestTime"] = 1632934364,
                ["wasAltered"] = true,
                ["newestTime"] = 1632962918,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 2524,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1632934364,
                        ["quant"] = 1,
                        ["id"] = "1689754865",
                        ["itemLink"] = 3723,
                    },
                    [2] = 
                    {
                        ["price"] = 11999,
                        ["guild"] = 1,
                        ["buyer"] = 2645,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632962918,
                        ["quant"] = 1,
                        ["id"] = "1689985169",
                        ["itemLink"] = 3723,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45324] = 
        {
            ["50:15:1:19:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_medium_head_d.dds",
                ["itemDesc"] = "Rubedo Leather Helmet",
                ["oldestTime"] = 1633016246,
                ["wasAltered"] = true,
                ["newestTime"] = 1633016246,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 338,
                        ["guild"] = 1,
                        ["buyer"] = 470,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1633016246,
                        ["quant"] = 1,
                        ["id"] = "1690335483",
                        ["itemLink"] = 539,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 white normal medium apparel head ornate",
            },
        },
        [77583] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_poisonmaking_reagent_scuttle.dds",
                ["itemDesc"] = "Beetle Scuttle",
                ["oldestTime"] = 1632953139,
                ["wasAltered"] = true,
                ["newestTime"] = 1632953139,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4200,
                        ["guild"] = 1,
                        ["buyer"] = 2601,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1632953139,
                        ["quant"] = 20,
                        ["id"] = "1689902529",
                        ["itemLink"] = 3853,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [71699] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 25: Aldmeri Dominion Shields",
                ["oldestTime"] = 1633067258,
                ["wasAltered"] = true,
                ["newestTime"] = 1633067258,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6900,
                        ["guild"] = 1,
                        ["buyer"] = 830,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633067258,
                        ["quant"] = 1,
                        ["id"] = "1690762707",
                        ["itemLink"] = 1072,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [176409] = 
        {
            ["1:0:2:46:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_belt_medium.dds",
                ["itemDesc"] = "Companion's Belt",
                ["oldestTime"] = 1633133064,
                ["wasAltered"] = true,
                ["newestTime"] = 1633133064,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1123,
                        ["wasKiosk"] = true,
                        ["seller"] = 1108,
                        ["timestamp"] = 1633133064,
                        ["quant"] = 1,
                        ["id"] = "1691219975",
                        ["itemLink"] = 1544,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine medium apparel waist shattering",
            },
        },
        [102170] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_draugr_medium_legs_a.dds",
                ["itemDesc"] = "Stygian Guards",
                ["oldestTime"] = 1633100333,
                ["wasAltered"] = true,
                ["newestTime"] = 1633100333,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 945,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633100333,
                        ["quant"] = 1,
                        ["id"] = "1690960011",
                        ["itemLink"] = 1281,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set stygian legs impenetrable",
            },
        },
        [45854] = 
        {
            ["21:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_001.dds",
                ["itemDesc"] = "Kuta",
                ["oldestTime"] = 1632821092,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305865,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 29548,
                        ["guild"] = 1,
                        ["buyer"] = 212,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1632975412,
                        ["quant"] = 8,
                        ["id"] = "1690098665",
                        ["itemLink"] = 222,
                    },
                    [2] = 
                    {
                        ["price"] = 29548,
                        ["guild"] = 1,
                        ["buyer"] = 212,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1632975414,
                        ["quant"] = 8,
                        ["id"] = "1690098677",
                        ["itemLink"] = 222,
                    },
                    [3] = 
                    {
                        ["price"] = 11618,
                        ["guild"] = 1,
                        ["buyer"] = 241,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632977830,
                        ["quant"] = 3,
                        ["id"] = "1690117037",
                        ["itemLink"] = 222,
                    },
                    [4] = 
                    {
                        ["price"] = 11618,
                        ["guild"] = 1,
                        ["buyer"] = 241,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632977832,
                        ["quant"] = 3,
                        ["id"] = "1690117053",
                        ["itemLink"] = 222,
                    },
                    [5] = 
                    {
                        ["price"] = 77713,
                        ["guild"] = 1,
                        ["buyer"] = 241,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1632977834,
                        ["quant"] = 20,
                        ["id"] = "1690117063",
                        ["itemLink"] = 222,
                    },
                    [6] = 
                    {
                        ["price"] = 77713,
                        ["guild"] = 1,
                        ["buyer"] = 241,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1632977835,
                        ["quant"] = 20,
                        ["id"] = "1690117073",
                        ["itemLink"] = 222,
                    },
                    [7] = 
                    {
                        ["price"] = 19500,
                        ["guild"] = 1,
                        ["buyer"] = 241,
                        ["wasKiosk"] = true,
                        ["seller"] = 244,
                        ["timestamp"] = 1632977837,
                        ["quant"] = 5,
                        ["id"] = "1690117091",
                        ["itemLink"] = 222,
                    },
                    [8] = 
                    {
                        ["price"] = 3953,
                        ["guild"] = 1,
                        ["buyer"] = 346,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632990037,
                        ["quant"] = 1,
                        ["id"] = "1690187259",
                        ["itemLink"] = 222,
                    },
                    [9] = 
                    {
                        ["price"] = 27300,
                        ["guild"] = 1,
                        ["buyer"] = 375,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1632994712,
                        ["quant"] = 7,
                        ["id"] = "1690209115",
                        ["itemLink"] = 222,
                    },
                    [10] = 
                    {
                        ["price"] = 35379,
                        ["guild"] = 1,
                        ["buyer"] = 375,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1632994713,
                        ["quant"] = 9,
                        ["id"] = "1690209123",
                        ["itemLink"] = 222,
                    },
                    [11] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 562,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633053128,
                        ["quant"] = 1,
                        ["id"] = "1690637309",
                        ["itemLink"] = 222,
                    },
                    [12] = 
                    {
                        ["price"] = 3750,
                        ["guild"] = 1,
                        ["buyer"] = 562,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633053128,
                        ["quant"] = 1,
                        ["id"] = "1690637313",
                        ["itemLink"] = 222,
                    },
                    [13] = 
                    {
                        ["price"] = 7968,
                        ["guild"] = 1,
                        ["buyer"] = 562,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633053129,
                        ["quant"] = 2,
                        ["id"] = "1690637323",
                        ["itemLink"] = 222,
                    },
                    [14] = 
                    {
                        ["price"] = 18750,
                        ["guild"] = 1,
                        ["buyer"] = 852,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633073211,
                        ["quant"] = 5,
                        ["id"] = "1690798839",
                        ["itemLink"] = 222,
                    },
                    [15] = 
                    {
                        ["price"] = 30592,
                        ["guild"] = 1,
                        ["buyer"] = 852,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633073212,
                        ["quant"] = 8,
                        ["id"] = "1690798845",
                        ["itemLink"] = 222,
                    },
                    [16] = 
                    {
                        ["price"] = 11618,
                        ["guild"] = 1,
                        ["buyer"] = 852,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633073215,
                        ["quant"] = 3,
                        ["id"] = "1690798853",
                        ["itemLink"] = 222,
                    },
                    [17] = 
                    {
                        ["price"] = 11618,
                        ["guild"] = 1,
                        ["buyer"] = 852,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633073216,
                        ["quant"] = 3,
                        ["id"] = "1690798855",
                        ["itemLink"] = 222,
                    },
                    [18] = 
                    {
                        ["price"] = 19375,
                        ["guild"] = 1,
                        ["buyer"] = 852,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633073216,
                        ["quant"] = 5,
                        ["id"] = "1690798857",
                        ["itemLink"] = 222,
                    },
                    [19] = 
                    {
                        ["price"] = 22500,
                        ["guild"] = 1,
                        ["buyer"] = 938,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633098684,
                        ["quant"] = 6,
                        ["id"] = "1690946483",
                        ["itemLink"] = 222,
                    },
                    [20] = 
                    {
                        ["price"] = 27223,
                        ["guild"] = 1,
                        ["buyer"] = 938,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633098686,
                        ["quant"] = 7,
                        ["id"] = "1690946495",
                        ["itemLink"] = 222,
                    },
                    [21] = 
                    {
                        ["price"] = 27223,
                        ["guild"] = 1,
                        ["buyer"] = 938,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633098687,
                        ["quant"] = 7,
                        ["id"] = "1690946511",
                        ["itemLink"] = 222,
                    },
                    [22] = 
                    {
                        ["price"] = 27223,
                        ["guild"] = 1,
                        ["buyer"] = 938,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633098688,
                        ["quant"] = 7,
                        ["id"] = "1690946517",
                        ["itemLink"] = 222,
                    },
                    [23] = 
                    {
                        ["price"] = 3800,
                        ["guild"] = 1,
                        ["buyer"] = 999,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633112805,
                        ["quant"] = 1,
                        ["id"] = "1691057261",
                        ["itemLink"] = 222,
                    },
                    [24] = 
                    {
                        ["price"] = 18750,
                        ["guild"] = 1,
                        ["buyer"] = 1047,
                        ["wasKiosk"] = true,
                        ["seller"] = 590,
                        ["timestamp"] = 1633119675,
                        ["quant"] = 5,
                        ["id"] = "1691103107",
                        ["itemLink"] = 222,
                    },
                    [25] = 
                    {
                        ["price"] = 18750,
                        ["guild"] = 1,
                        ["buyer"] = 1047,
                        ["wasKiosk"] = true,
                        ["seller"] = 590,
                        ["timestamp"] = 1633119675,
                        ["quant"] = 5,
                        ["id"] = "1691103111",
                        ["itemLink"] = 222,
                    },
                    [26] = 
                    {
                        ["price"] = 159960,
                        ["guild"] = 1,
                        ["buyer"] = 1047,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1633119677,
                        ["quant"] = 40,
                        ["id"] = "1691103115",
                        ["itemLink"] = 222,
                    },
                    [27] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 1047,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633119679,
                        ["quant"] = 10,
                        ["id"] = "1691103117",
                        ["itemLink"] = 222,
                    },
                    [28] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 1079,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633124977,
                        ["quant"] = 1,
                        ["id"] = "1691142425",
                        ["itemLink"] = 222,
                    },
                    [29] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 1149,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633136097,
                        ["quant"] = 2,
                        ["id"] = "1691253655",
                        ["itemLink"] = 222,
                    },
                    [30] = 
                    {
                        ["price"] = 6900,
                        ["guild"] = 1,
                        ["buyer"] = 26,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633153349,
                        ["quant"] = 2,
                        ["id"] = "1691418557",
                        ["itemLink"] = 222,
                    },
                    [31] = 
                    {
                        ["price"] = 6900,
                        ["guild"] = 1,
                        ["buyer"] = 26,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633153350,
                        ["quant"] = 2,
                        ["id"] = "1691418563",
                        ["itemLink"] = 222,
                    },
                    [32] = 
                    {
                        ["price"] = 6900,
                        ["guild"] = 1,
                        ["buyer"] = 26,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633153350,
                        ["quant"] = 2,
                        ["id"] = "1691418571",
                        ["itemLink"] = 222,
                    },
                    [33] = 
                    {
                        ["price"] = 6900,
                        ["guild"] = 1,
                        ["buyer"] = 26,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633153366,
                        ["quant"] = 2,
                        ["id"] = "1691418653",
                        ["itemLink"] = 222,
                    },
                    [34] = 
                    {
                        ["price"] = 6900,
                        ["guild"] = 1,
                        ["buyer"] = 26,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633153366,
                        ["quant"] = 2,
                        ["id"] = "1691418661",
                        ["itemLink"] = 222,
                    },
                    [35] = 
                    {
                        ["price"] = 38000,
                        ["guild"] = 1,
                        ["buyer"] = 1053,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633165517,
                        ["quant"] = 10,
                        ["id"] = "1691498683",
                        ["itemLink"] = 222,
                    },
                    [36] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1478,
                        ["wasKiosk"] = true,
                        ["seller"] = 649,
                        ["timestamp"] = 1633199558,
                        ["quant"] = 5,
                        ["id"] = "1691784791",
                        ["itemLink"] = 222,
                    },
                    [37] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1493,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1633201197,
                        ["quant"] = 2,
                        ["id"] = "1691802631",
                        ["itemLink"] = 222,
                    },
                    [38] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1579,
                        ["wasKiosk"] = true,
                        ["seller"] = 622,
                        ["timestamp"] = 1633214850,
                        ["quant"] = 1,
                        ["id"] = "1691957585",
                        ["itemLink"] = 222,
                    },
                    [39] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1579,
                        ["wasKiosk"] = true,
                        ["seller"] = 622,
                        ["timestamp"] = 1633214850,
                        ["quant"] = 1,
                        ["id"] = "1691957591",
                        ["itemLink"] = 222,
                    },
                    [40] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1579,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633214852,
                        ["quant"] = 2,
                        ["id"] = "1691957601",
                        ["itemLink"] = 222,
                    },
                    [41] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1579,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633214852,
                        ["quant"] = 2,
                        ["id"] = "1691957615",
                        ["itemLink"] = 222,
                    },
                    [42] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1579,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633214853,
                        ["quant"] = 2,
                        ["id"] = "1691957619",
                        ["itemLink"] = 222,
                    },
                    [43] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1579,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633214853,
                        ["quant"] = 2,
                        ["id"] = "1691957623",
                        ["itemLink"] = 222,
                    },
                    [44] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1579,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633214854,
                        ["quant"] = 2,
                        ["id"] = "1691957629",
                        ["itemLink"] = 222,
                    },
                    [45] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1579,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633214855,
                        ["quant"] = 2,
                        ["id"] = "1691957633",
                        ["itemLink"] = 222,
                    },
                    [46] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1677,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633229250,
                        ["quant"] = 5,
                        ["id"] = "1692108821",
                        ["itemLink"] = 222,
                    },
                    [47] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1794,
                        ["wasKiosk"] = true,
                        ["seller"] = 1480,
                        ["timestamp"] = 1633244995,
                        ["quant"] = 3,
                        ["id"] = "1692233743",
                        ["itemLink"] = 222,
                    },
                    [48] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1794,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633244997,
                        ["quant"] = 2,
                        ["id"] = "1692233751",
                        ["itemLink"] = 222,
                    },
                    [49] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1794,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633244999,
                        ["quant"] = 2,
                        ["id"] = "1692233765",
                        ["itemLink"] = 222,
                    },
                    [50] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1794,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633245000,
                        ["quant"] = 2,
                        ["id"] = "1692233771",
                        ["itemLink"] = 222,
                    },
                    [51] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1794,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1633245001,
                        ["quant"] = 2,
                        ["id"] = "1692233777",
                        ["itemLink"] = 222,
                    },
                    [52] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1794,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1633245002,
                        ["quant"] = 2,
                        ["id"] = "1692233783",
                        ["itemLink"] = 222,
                    },
                    [53] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 900,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633257691,
                        ["quant"] = 1,
                        ["id"] = "1692315721",
                        ["itemLink"] = 222,
                    },
                    [54] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1652,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633283266,
                        ["quant"] = 2,
                        ["id"] = "1692549341",
                        ["itemLink"] = 222,
                    },
                    [55] = 
                    {
                        ["price"] = 122500,
                        ["guild"] = 1,
                        ["buyer"] = 2066,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633305865,
                        ["quant"] = 35,
                        ["id"] = "1692799129",
                        ["itemLink"] = 222,
                    },
                    [56] = 
                    {
                        ["price"] = 7238,
                        ["guild"] = 1,
                        ["buyer"] = 1079,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1632821092,
                        ["quant"] = 2,
                        ["id"] = "1688948467",
                        ["itemLink"] = 222,
                    },
                    [57] = 
                    {
                        ["price"] = 3953,
                        ["guild"] = 1,
                        ["buyer"] = 2225,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632853450,
                        ["quant"] = 1,
                        ["id"] = "1689170925",
                        ["itemLink"] = 222,
                    },
                    [58] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 649,
                        ["timestamp"] = 1632862439,
                        ["quant"] = 5,
                        ["id"] = "1689247541",
                        ["itemLink"] = 222,
                    },
                    [59] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 649,
                        ["timestamp"] = 1632862441,
                        ["quant"] = 5,
                        ["id"] = "1689247553",
                        ["itemLink"] = 222,
                    },
                    [60] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 649,
                        ["timestamp"] = 1632862441,
                        ["quant"] = 5,
                        ["id"] = "1689247567",
                        ["itemLink"] = 222,
                    },
                    [61] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 1729,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632872404,
                        ["quant"] = 1,
                        ["id"] = "1689318161",
                        ["itemLink"] = 222,
                    },
                    [62] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 2573,
                        ["wasKiosk"] = true,
                        ["seller"] = 267,
                        ["timestamp"] = 1632947776,
                        ["quant"] = 10,
                        ["id"] = "1689856679",
                        ["itemLink"] = 222,
                    },
                    [63] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 2652,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632964360,
                        ["quant"] = 4,
                        ["id"] = "1689998983",
                        ["itemLink"] = 222,
                    },
                    [64] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 2652,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632964361,
                        ["quant"] = 4,
                        ["id"] = "1689999003",
                        ["itemLink"] = 222,
                    },
                    [65] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 2652,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632964362,
                        ["quant"] = 4,
                        ["id"] = "1689999021",
                        ["itemLink"] = 222,
                    },
                },
                ["totalCount"] = 65,
                ["itemAdderText"] = "rr21 gold legendary materials aspect runestone",
            },
        },
        [176159] = 
        {
            ["1:0:3:44:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_boots_medium.dds",
                ["itemDesc"] = "Companion's Boots",
                ["oldestTime"] = 1633315189,
                ["wasAltered"] = true,
                ["newestTime"] = 1633315189,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 91,
                        ["wasKiosk"] = true,
                        ["seller"] = 92,
                        ["timestamp"] = 1633315189,
                        ["quant"] = 1,
                        ["id"] = "1692905625",
                        ["itemLink"] = 67,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior medium apparel feet prolific",
            },
        },
        [176416] = 
        {
            ["1:0:2:46:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_belt_heavy.dds",
                ["itemDesc"] = "Companion's Girdle",
                ["oldestTime"] = 1633211793,
                ["wasAltered"] = true,
                ["newestTime"] = 1633211793,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1555,
                        ["wasKiosk"] = true,
                        ["seller"] = 252,
                        ["timestamp"] = 1633211793,
                        ["quant"] = 1,
                        ["id"] = "1691925761",
                        ["itemLink"] = 2283,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine heavy apparel waist shattering",
            },
        },
        [166945] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Solitude Bread, Rustic Sliced",
                ["oldestTime"] = 1633226362,
                ["wasAltered"] = true,
                ["newestTime"] = 1633226362,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1013,
                        ["wasKiosk"] = true,
                        ["seller"] = 92,
                        ["timestamp"] = 1633226362,
                        ["quant"] = 1,
                        ["id"] = "1692078215",
                        ["itemLink"] = 2397,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [172066] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_staff_a.dds",
                ["itemDesc"] = "Restoration Staff of Frostbite",
                ["oldestTime"] = 1633222551,
                ["wasAltered"] = true,
                ["newestTime"] = 1633222551,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 790,
                        ["guild"] = 1,
                        ["buyer"] = 1377,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633222551,
                        ["quant"] = 1,
                        ["id"] = "1692038059",
                        ["itemLink"] = 2360,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set frostbite healing staff two-handed charged",
            },
        },
        [45603] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Orsinium Pink Zinfandel",
                ["oldestTime"] = 1633122942,
                ["wasAltered"] = true,
                ["newestTime"] = 1633122942,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4300,
                        ["guild"] = 1,
                        ["buyer"] = 1066,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633122942,
                        ["quant"] = 1,
                        ["id"] = "1691126877",
                        ["itemLink"] = 1455,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [122917] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_telvanni_light_shirt_a.dds",
                ["itemDesc"] = "War Maiden's Jerkin",
                ["oldestTime"] = 1632958191,
                ["wasAltered"] = true,
                ["newestTime"] = 1632958191,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2620,
                        ["wasKiosk"] = true,
                        ["seller"] = 1273,
                        ["timestamp"] = 1632958191,
                        ["quant"] = 1,
                        ["id"] = "1689945427",
                        ["itemLink"] = 3908,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set war maiden chest invigorating",
            },
        },
        [45607] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Blackwood Mint Chai",
                ["oldestTime"] = 1632874523,
                ["wasAltered"] = true,
                ["newestTime"] = 1632874523,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1632874523,
                        ["quant"] = 1,
                        ["id"] = "1689336331",
                        ["itemLink"] = 3406,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45352] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_light_shirt_d.dds",
                ["itemDesc"] = "Ancestor Silk Jerkin",
                ["oldestTime"] = 1632843194,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186018,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 275,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633009351,
                        ["quant"] = 1,
                        ["id"] = "1690285251",
                        ["itemLink"] = 463,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009367,
                        ["quant"] = 1,
                        ["id"] = "1690285461",
                        ["itemLink"] = 482,
                    },
                    [3] = 
                    {
                        ["price"] = 171,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633022937,
                        ["quant"] = 1,
                        ["id"] = "1690390249",
                        ["itemLink"] = 600,
                    },
                    [4] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633084076,
                        ["quant"] = 1,
                        ["id"] = "1690854883",
                        ["itemLink"] = 600,
                    },
                    [5] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633185989,
                        ["quant"] = 1,
                        ["id"] = "1691640593",
                        ["itemLink"] = 482,
                    },
                    [6] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633185990,
                        ["quant"] = 1,
                        ["id"] = "1691640601",
                        ["itemLink"] = 600,
                    },
                    [7] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633186018,
                        ["quant"] = 1,
                        ["id"] = "1691640835",
                        ["itemLink"] = 2061,
                    },
                    [8] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632843194,
                        ["quant"] = 1,
                        ["id"] = "1689085343",
                        ["itemLink"] = 3181,
                    },
                    [9] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632843197,
                        ["quant"] = 1,
                        ["id"] = "1689085357",
                        ["itemLink"] = 600,
                    },
                },
                ["totalCount"] = 9,
                ["itemAdderText"] = "cp160 white normal light apparel chest intricate",
            },
            ["39:0:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_light_shirt_d.dds",
                ["itemDesc"] = "Spidersilk Jerkin",
                ["oldestTime"] = 1633059420,
                ["wasAltered"] = true,
                ["newestTime"] = 1633059420,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 111,
                        ["guild"] = 1,
                        ["buyer"] = 780,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633059420,
                        ["quant"] = 1,
                        ["id"] = "1690704575",
                        ["itemLink"] = 993,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr39 white normal light apparel chest intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_light_shirt_d.dds",
                ["itemDesc"] = "Ancestor Silk Jerkin",
                ["oldestTime"] = 1633022935,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022935,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 165,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633022935,
                        ["quant"] = 1,
                        ["id"] = "1690390247",
                        ["itemLink"] = 599,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 white normal light apparel chest intricate",
            },
        },
        [45353] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_shoulders_d.dds",
                ["itemDesc"] = "Ancestor Silk Epaulets",
                ["oldestTime"] = 1632841095,
                ["wasAltered"] = true,
                ["newestTime"] = 1633268078,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 780,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1633059422,
                        ["quant"] = 1,
                        ["id"] = "1690704591",
                        ["itemLink"] = 996,
                    },
                    [2] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 850,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1633072305,
                        ["quant"] = 1,
                        ["id"] = "1690793435",
                        ["itemLink"] = 1099,
                    },
                    [3] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084079,
                        ["quant"] = 1,
                        ["id"] = "1690854921",
                        ["itemLink"] = 1175,
                    },
                    [4] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084081,
                        ["quant"] = 1,
                        ["id"] = "1690854935",
                        ["itemLink"] = 1176,
                    },
                    [5] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633186019,
                        ["quant"] = 1,
                        ["id"] = "1691640845",
                        ["itemLink"] = 1175,
                    },
                    [6] = 
                    {
                        ["price"] = 125,
                        ["guild"] = 1,
                        ["buyer"] = 1001,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633268078,
                        ["quant"] = 1,
                        ["id"] = "1692385971",
                        ["itemLink"] = 2653,
                    },
                    [7] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632841095,
                        ["quant"] = 1,
                        ["id"] = "1689067935",
                        ["itemLink"] = 2653,
                    },
                    [8] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632843193,
                        ["quant"] = 1,
                        ["id"] = "1689085337",
                        ["itemLink"] = 3180,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "cp160 white normal light apparel shoulders intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_light_shoulders_d.dds",
                ["itemDesc"] = "Ancestor Silk Epaulets",
                ["oldestTime"] = 1632941439,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185968,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633084680,
                        ["quant"] = 1,
                        ["id"] = "1690857325",
                        ["itemLink"] = 1204,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084680,
                        ["quant"] = 1,
                        ["id"] = "1690857333",
                        ["itemLink"] = 1205,
                    },
                    [3] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633185968,
                        ["quant"] = 1,
                        ["id"] = "1691640417",
                        ["itemLink"] = 2037,
                    },
                    [4] = 
                    {
                        ["price"] = 227,
                        ["guild"] = 1,
                        ["buyer"] = 2548,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632941439,
                        ["quant"] = 1,
                        ["id"] = "1689805053",
                        ["itemLink"] = 1205,
                    },
                    [5] = 
                    {
                        ["price"] = 290,
                        ["guild"] = 1,
                        ["buyer"] = 2561,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632944591,
                        ["quant"] = 1,
                        ["id"] = "1689831911",
                        ["itemLink"] = 1205,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "cp150 white normal light apparel shoulders intricate",
            },
        },
        [43563] = 
        {
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_medium_head_d.dds",
                ["itemDesc"] = "Rubedo Leather Helmet",
                ["oldestTime"] = 1632847687,
                ["wasAltered"] = true,
                ["newestTime"] = 1632847688,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 141,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1632847687,
                        ["quant"] = 1,
                        ["id"] = "1689125519",
                        ["itemLink"] = 3209,
                    },
                    [2] = 
                    {
                        ["price"] = 141,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1632847688,
                        ["quant"] = 1,
                        ["id"] = "1689125525",
                        ["itemLink"] = 3210,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 white normal medium apparel head",
            },
        },
        [156716] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Southern Elsweyr Treasure Map I",
                ["oldestTime"] = 1633182521,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310231,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 379,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182521,
                        ["quant"] = 1,
                        ["id"] = "1691608229",
                        ["itemLink"] = 1957,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 626,
                        ["timestamp"] = 1633310231,
                        ["quant"] = 1,
                        ["id"] = "1692851295",
                        ["itemLink"] = 1957,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [171567] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_fulgid_epidote.dds",
                ["itemDesc"] = "Fulgid Epidote",
                ["oldestTime"] = 1633131270,
                ["wasAltered"] = true,
                ["newestTime"] = 1633131270,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 207,
                        ["wasKiosk"] = false,
                        ["seller"] = 166,
                        ["timestamp"] = 1633131270,
                        ["quant"] = 1,
                        ["id"] = "1691200149",
                        ["itemLink"] = 1516,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [145969] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Bowl of Worms",
                ["oldestTime"] = 1632865535,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865535,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20027,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 1756,
                        ["timestamp"] = 1632865535,
                        ["quant"] = 1,
                        ["id"] = "1689268877",
                        ["itemLink"] = 3344,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [46131] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_cloth_famin.dds",
                ["itemDesc"] = "Kresh Fiber",
                ["oldestTime"] = 1633045141,
                ["wasAltered"] = true,
                ["newestTime"] = 1633267418,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4200,
                        ["guild"] = 1,
                        ["buyer"] = 667,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633045141,
                        ["quant"] = 70,
                        ["id"] = "1690557749",
                        ["itemLink"] = 847,
                    },
                    [2] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 800,
                        ["wasKiosk"] = true,
                        ["seller"] = 803,
                        ["timestamp"] = 1633063437,
                        ["quant"] = 50,
                        ["id"] = "1690735691",
                        ["itemLink"] = 847,
                    },
                    [3] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1861,
                        ["wasKiosk"] = true,
                        ["seller"] = 803,
                        ["timestamp"] = 1633267418,
                        ["quant"] = 50,
                        ["id"] = "1692378135",
                        ["itemLink"] = 847,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [79415] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_dagger_a.dds",
                ["itemDesc"] = "Dagger of the Pariah",
                ["oldestTime"] = 1633109141,
                ["wasAltered"] = true,
                ["newestTime"] = 1633109141,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3800,
                        ["guild"] = 1,
                        ["buyer"] = 977,
                        ["wasKiosk"] = true,
                        ["seller"] = 695,
                        ["timestamp"] = 1633109141,
                        ["quant"] = 1,
                        ["id"] = "1691030049",
                        ["itemLink"] = 1313,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set mark of the pariah dagger one-handed defending",
            },
        },
        [23099] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_leather_base_boiled_leather_r3.dds",
                ["itemDesc"] = "Leather",
                ["oldestTime"] = 1632769485,
                ["wasAltered"] = true,
                ["newestTime"] = 1633290276,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 850,
                        ["guild"] = 2,
                        ["buyer"] = 124,
                        ["wasKiosk"] = false,
                        ["seller"] = 125,
                        ["timestamp"] = 1632769485,
                        ["quant"] = 100,
                        ["id"] = "1688524933",
                        ["itemLink"] = 121,
                    },
                    [2] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1950,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633284650,
                        ["quant"] = 75,
                        ["id"] = "1692563077",
                        ["itemLink"] = 121,
                    },
                    [3] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1957,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633286723,
                        ["quant"] = 200,
                        ["id"] = "1692587725",
                        ["itemLink"] = 121,
                    },
                    [4] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1980,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633290276,
                        ["quant"] = 200,
                        ["id"] = "1692630775",
                        ["itemLink"] = 121,
                    },
                    [5] = 
                    {
                        ["price"] = 3433,
                        ["guild"] = 1,
                        ["buyer"] = 2239,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1632856997,
                        ["quant"] = 200,
                        ["id"] = "1689206051",
                        ["itemLink"] = 121,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [74559] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 33: Thieves Guild Bows",
                ["oldestTime"] = 1632929248,
                ["wasAltered"] = true,
                ["newestTime"] = 1632929248,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 2510,
                        ["wasKiosk"] = true,
                        ["seller"] = 374,
                        ["timestamp"] = 1632929248,
                        ["quant"] = 1,
                        ["id"] = "1689715861",
                        ["itemLink"] = 3694,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [132161] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_vrd_inc_hlasewingbox001.dds",
                ["itemDesc"] = "Dres Sewing Kit, Master's",
                ["oldestTime"] = 1633165959,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165959,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633165959,
                        ["quant"] = 1,
                        ["id"] = "1691500339",
                        ["itemLink"] = 1856,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings workshop",
            },
        },
        [181570] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Leyawiin Alcove, Castle",
                ["oldestTime"] = 1633054972,
                ["wasAltered"] = true,
                ["newestTime"] = 1633054972,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 744,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633054972,
                        ["quant"] = 1,
                        ["id"] = "1690654379",
                        ["itemLink"] = 944,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [74564] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 33: Thieves Guild Legs",
                ["oldestTime"] = 1632841476,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292441,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18999,
                        ["guild"] = 1,
                        ["buyer"] = 1991,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633292441,
                        ["quant"] = 1,
                        ["id"] = "1692656735",
                        ["itemLink"] = 2835,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2184,
                        ["wasKiosk"] = true,
                        ["seller"] = 374,
                        ["timestamp"] = 1632841476,
                        ["quant"] = 1,
                        ["id"] = "1689071239",
                        ["itemLink"] = 2835,
                    },
                    [3] = 
                    {
                        ["price"] = 3700,
                        ["guild"] = 1,
                        ["buyer"] = 2582,
                        ["wasKiosk"] = true,
                        ["seller"] = 159,
                        ["timestamp"] = 1632949755,
                        ["quant"] = 1,
                        ["id"] = "1689872497",
                        ["itemLink"] = 2835,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [156486] = 
        {
            ["20:0:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_medium_waist_b.dds",
                ["itemDesc"] = "New Moon Acolyte's Belt",
                ["oldestTime"] = 1632825629,
                ["wasAltered"] = true,
                ["newestTime"] = 1632825629,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2116,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1632825629,
                        ["quant"] = 1,
                        ["id"] = "1688967185",
                        ["itemLink"] = 3023,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr20 blue superior medium apparel set new moon acolyte waist training",
            },
        },
        [46151] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_walking_dead_mort_heart.dds",
                ["itemDesc"] = "Daedra Heart",
                ["oldestTime"] = 1632871507,
                ["wasAltered"] = true,
                ["newestTime"] = 1633086253,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4700,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 199,
                        ["timestamp"] = 1633086253,
                        ["quant"] = 94,
                        ["id"] = "1690864917",
                        ["itemLink"] = 1218,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2292,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632871507,
                        ["quant"] = 28,
                        ["id"] = "1689312857",
                        ["itemLink"] = 1218,
                    },
                    [3] = 
                    {
                        ["price"] = 45,
                        ["guild"] = 1,
                        ["buyer"] = 2466,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1632912324,
                        ["quant"] = 1,
                        ["id"] = "1689609865",
                        ["itemLink"] = 1218,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [95304] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_shield_a.dds",
                ["itemDesc"] = "Shield of the Fire",
                ["oldestTime"] = 1633291952,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291952,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 197,
                        ["timestamp"] = 1633291952,
                        ["quant"] = 1,
                        ["id"] = "1692651277",
                        ["itemLink"] = 2801,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine apparel weapon set way of fire shield off hand divines",
            },
        },
        [171593] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 99: Waking Flame Staves",
                ["oldestTime"] = 1633292544,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292544,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633292544,
                        ["quant"] = 1,
                        ["id"] = "1692658101",
                        ["itemLink"] = 2839,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [180554] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_light_waist_a.dds",
                ["itemDesc"] = "Sash of Dark Convergence",
                ["oldestTime"] = 1633230404,
                ["wasAltered"] = true,
                ["newestTime"] = 1633230404,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 1691,
                        ["wasKiosk"] = true,
                        ["seller"] = 356,
                        ["timestamp"] = 1633230404,
                        ["quant"] = 1,
                        ["id"] = "1692119005",
                        ["itemLink"] = 2439,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set dark convergence waist invigorating",
            },
        },
        [172108] = 
        {
            ["50:16:2:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_staff_a.dds",
                ["itemDesc"] = "Restoration Staff of Frostbite",
                ["oldestTime"] = 1633045837,
                ["wasAltered"] = true,
                ["newestTime"] = 1633045837,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 674,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633045837,
                        ["quant"] = 1,
                        ["id"] = "1690564935",
                        ["itemLink"] = 860,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set frostbite healing staff two-handed training",
            },
        },
        [175953] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Chair, Slatted",
                ["oldestTime"] = 1632870339,
                ["wasAltered"] = true,
                ["newestTime"] = 1633272496,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 2,
                        ["buyer"] = 114,
                        ["wasKiosk"] = false,
                        ["seller"] = 117,
                        ["timestamp"] = 1632870339,
                        ["quant"] = 1,
                        ["id"] = "1689305543",
                        ["itemLink"] = 140,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 31,
                        ["wasKiosk"] = false,
                        ["seller"] = 512,
                        ["timestamp"] = 1633200570,
                        ["quant"] = 1,
                        ["id"] = "1691795527",
                        ["itemLink"] = 140,
                    },
                    [3] = 
                    {
                        ["price"] = 299,
                        ["guild"] = 1,
                        ["buyer"] = 1208,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633226226,
                        ["quant"] = 1,
                        ["id"] = "1692076809",
                        ["itemLink"] = 140,
                    },
                    [4] = 
                    {
                        ["price"] = 850,
                        ["guild"] = 1,
                        ["buyer"] = 1643,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633272496,
                        ["quant"] = 1,
                        ["id"] = "1692431947",
                        ["itemLink"] = 140,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [149334] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_pellitine_staff_a.dds",
                ["itemDesc"] = "Crafty Alfiq's Inferno Staff",
                ["oldestTime"] = 1633043499,
                ["wasAltered"] = true,
                ["newestTime"] = 1633043499,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 23000,
                        ["guild"] = 1,
                        ["buyer"] = 659,
                        ["wasKiosk"] = true,
                        ["seller"] = 660,
                        ["timestamp"] = 1633043499,
                        ["quant"] = 1,
                        ["id"] = "1690541603",
                        ["itemLink"] = 836,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set crafty alfiq flame staff two-handed sharpened",
            },
        },
        [176987] = 
        {
            ["1:0:2:50:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_boots_medium.dds",
                ["itemDesc"] = "Companion's Boots",
                ["oldestTime"] = 1632978956,
                ["wasAltered"] = true,
                ["newestTime"] = 1632978956,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 620,
                        ["guild"] = 1,
                        ["buyer"] = 251,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1632978956,
                        ["quant"] = 1,
                        ["id"] = "1690125643",
                        ["itemLink"] = 255,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine medium apparel feet bolstered",
            },
        },
        [172124] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_1hhammer_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Mace",
                ["oldestTime"] = 1633046147,
                ["wasAltered"] = true,
                ["newestTime"] = 1633046147,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 678,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633046147,
                        ["quant"] = 1,
                        ["id"] = "1690567779",
                        ["itemLink"] = 865,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set deadlands assassin mace one-handed infused",
            },
        },
        [71261] = 
        {
            ["50:16:2:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_ring_a.dds",
                ["itemDesc"] = "Signet of the Pariah",
                ["oldestTime"] = 1633027460,
                ["wasAltered"] = true,
                ["newestTime"] = 1633027460,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 334,
                        ["wasKiosk"] = false,
                        ["seller"] = 353,
                        ["timestamp"] = 1633027460,
                        ["quant"] = 1,
                        ["id"] = "1690423479",
                        ["itemLink"] = 684,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set mark of the pariah ring healthy",
            },
        },
        [75358] = 
        {
            ["10:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_potion_base_oil_2_r2.dds",
                ["itemDesc"] = "Ichor",
                ["oldestTime"] = 1633194398,
                ["wasAltered"] = true,
                ["newestTime"] = 1633194402,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 803,
                        ["wasKiosk"] = false,
                        ["seller"] = 158,
                        ["timestamp"] = 1633194398,
                        ["quant"] = 200,
                        ["id"] = "1691737617",
                        ["itemLink"] = 2131,
                    },
                    [2] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 803,
                        ["wasKiosk"] = false,
                        ["seller"] = 158,
                        ["timestamp"] = 1633194400,
                        ["quant"] = 200,
                        ["id"] = "1691737619",
                        ["itemLink"] = 2131,
                    },
                    [3] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 803,
                        ["wasKiosk"] = false,
                        ["seller"] = 158,
                        ["timestamp"] = 1633194401,
                        ["quant"] = 200,
                        ["id"] = "1691737625",
                        ["itemLink"] = 2131,
                    },
                    [4] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 803,
                        ["wasKiosk"] = false,
                        ["seller"] = 158,
                        ["timestamp"] = 1633194402,
                        ["quant"] = 200,
                        ["id"] = "1691737633",
                        ["itemLink"] = 2131,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr10 white normal materials poison solvent",
            },
        },
        [180575] = 
        {
            ["50:16:4:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_light_waist_a.dds",
                ["itemDesc"] = "Sash of Dark Convergence",
                ["oldestTime"] = 1633012095,
                ["wasAltered"] = true,
                ["newestTime"] = 1633012095,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 457,
                        ["wasKiosk"] = true,
                        ["seller"] = 43,
                        ["timestamp"] = 1633012095,
                        ["quant"] = 1,
                        ["id"] = "1690304567",
                        ["itemLink"] = 526,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set dark convergence waist sturdy",
            },
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_light_waist_a.dds",
                ["itemDesc"] = "Sash of Dark Convergence",
                ["oldestTime"] = 1633100497,
                ["wasAltered"] = true,
                ["newestTime"] = 1633232003,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 946,
                        ["wasKiosk"] = true,
                        ["seller"] = 762,
                        ["timestamp"] = 1633100497,
                        ["quant"] = 1,
                        ["id"] = "1690960971",
                        ["itemLink"] = 1282,
                    },
                    [2] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 1701,
                        ["wasKiosk"] = true,
                        ["seller"] = 356,
                        ["timestamp"] = 1633232003,
                        ["quant"] = 1,
                        ["id"] = "1692134993",
                        ["itemLink"] = 2446,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior light apparel set dark convergence waist sturdy",
            },
        },
        [115809] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Argonian Mortar and Pestle, Bone",
                ["oldestTime"] = 1633234998,
                ["wasAltered"] = true,
                ["newestTime"] = 1633234998,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633234998,
                        ["quant"] = 1,
                        ["id"] = "1692160717",
                        ["itemLink"] = 2478,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [180578] = 
        {
            ["50:16:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_1hsword_a.dds",
                ["itemDesc"] = "Sword of Dark Convergence",
                ["oldestTime"] = 1633229354,
                ["wasAltered"] = true,
                ["newestTime"] = 1633229354,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1679,
                        ["wasKiosk"] = true,
                        ["seller"] = 356,
                        ["timestamp"] = 1633229354,
                        ["quant"] = 1,
                        ["id"] = "1692109687",
                        ["itemLink"] = 2432,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set dark convergence sword one-handed training",
            },
        },
        [126563] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_dwe_inc_orreryb001.dds",
                ["itemDesc"] = "Dwarven Orrery, Reference",
                ["oldestTime"] = 1633045227,
                ["wasAltered"] = true,
                ["newestTime"] = 1633045227,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 668,
                        ["wasKiosk"] = true,
                        ["seller"] = 669,
                        ["timestamp"] = 1633045227,
                        ["quant"] = 1,
                        ["id"] = "1690558419",
                        ["itemLink"] = 850,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings workshop",
            },
        },
        [175974] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing4.dds",
                ["itemDesc"] = "Diagram: Leyawiin Brazier, Copper",
                ["oldestTime"] = 1633292411,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292411,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 499000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 1450,
                        ["timestamp"] = 1633292411,
                        ["quant"] = 1,
                        ["id"] = "1692656463",
                        ["itemLink"] = 2833,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [92265] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Twin Sisters",
                ["oldestTime"] = 1633281509,
                ["wasAltered"] = true,
                ["newestTime"] = 1633281509,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3261,
                        ["guild"] = 1,
                        ["buyer"] = 1935,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1633281509,
                        ["quant"] = 1,
                        ["id"] = "1692530669",
                        ["itemLink"] = 2740,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set twin sisters ring robust",
            },
        },
        [175980] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing3.dds",
                ["itemDesc"] = "Diagram: Leyawiin Chandelier, Twin Lanterns",
                ["oldestTime"] = 1633220963,
                ["wasAltered"] = true,
                ["newestTime"] = 1633220963,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 676,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633220963,
                        ["quant"] = 1,
                        ["id"] = "1692021249",
                        ["itemLink"] = 2348,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [171886] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 103: Black Fin Legion Helmets",
                ["oldestTime"] = 1632960371,
                ["wasAltered"] = true,
                ["newestTime"] = 1633298764,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 66000,
                        ["guild"] = 1,
                        ["buyer"] = 281,
                        ["wasKiosk"] = false,
                        ["seller"] = 43,
                        ["timestamp"] = 1633021604,
                        ["quant"] = 1,
                        ["id"] = "1690379945",
                        ["itemLink"] = 582,
                    },
                    [2] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 521,
                        ["wasKiosk"] = false,
                        ["seller"] = 6,
                        ["timestamp"] = 1633298764,
                        ["quant"] = 1,
                        ["id"] = "1692729115",
                        ["itemLink"] = 582,
                    },
                    [3] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 2626,
                        ["wasKiosk"] = true,
                        ["seller"] = 513,
                        ["timestamp"] = 1632960371,
                        ["quant"] = 1,
                        ["id"] = "1689962453",
                        ["itemLink"] = 582,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [71279] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_ring_a.dds",
                ["itemDesc"] = "Signet of the Pariah",
                ["oldestTime"] = 1633163923,
                ["wasAltered"] = true,
                ["newestTime"] = 1633211072,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 353,
                        ["timestamp"] = 1633163923,
                        ["quant"] = 1,
                        ["id"] = "1691490403",
                        ["itemLink"] = 1822,
                    },
                    [2] = 
                    {
                        ["price"] = 2663,
                        ["guild"] = 1,
                        ["buyer"] = 1553,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633211072,
                        ["quant"] = 1,
                        ["id"] = "1691916259",
                        ["itemLink"] = 1822,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set mark of the pariah ring arcane",
            },
        },
        [77424] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_darkbrotherhoodv2_heavy_chest_a.dds",
                ["itemDesc"] = "Sithis' Cuirass",
                ["oldestTime"] = 1633200765,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200765,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 1491,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633200765,
                        ["quant"] = 1,
                        ["id"] = "1691797369",
                        ["itemLink"] = 2201,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set sithis' touch chest invigorating",
            },
        },
        [45938] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Grilled Hare",
                ["oldestTime"] = 1633261615,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261615,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633261615,
                        ["quant"] = 1,
                        ["id"] = "1692334419",
                        ["itemLink"] = 2621,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [171892] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 103: Black Fin Legion Swords",
                ["oldestTime"] = 1633021624,
                ["wasAltered"] = true,
                ["newestTime"] = 1633021624,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 281,
                        ["wasKiosk"] = false,
                        ["seller"] = 514,
                        ["timestamp"] = 1633021624,
                        ["quant"] = 1,
                        ["id"] = "1690380305",
                        ["itemLink"] = 585,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [118901] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_aqa_seasponge001.dds",
                ["itemDesc"] = "Sea Sponge",
                ["oldestTime"] = 1633199361,
                ["wasAltered"] = true,
                ["newestTime"] = 1633199361,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 870,
                        ["guild"] = 1,
                        ["buyer"] = 1476,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633199361,
                        ["quant"] = 1,
                        ["id"] = "1691782855",
                        ["itemLink"] = 2175,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings conservatory",
            },
        },
        [42871] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_fishing_centipede.dds",
                ["itemDesc"] = "Crawlers, Foul Bait",
                ["oldestTime"] = 1633009595,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294334,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 446,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633009595,
                        ["quant"] = 200,
                        ["id"] = "1690287357",
                        ["itemLink"] = 512,
                    },
                    [2] = 
                    {
                        ["price"] = 3200,
                        ["guild"] = 1,
                        ["buyer"] = 446,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633009598,
                        ["quant"] = 200,
                        ["id"] = "1690287367",
                        ["itemLink"] = 512,
                    },
                    [3] = 
                    {
                        ["price"] = 3200,
                        ["guild"] = 1,
                        ["buyer"] = 446,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633009601,
                        ["quant"] = 200,
                        ["id"] = "1690287385",
                        ["itemLink"] = 512,
                    },
                    [4] = 
                    {
                        ["price"] = 3200,
                        ["guild"] = 1,
                        ["buyer"] = 446,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633009602,
                        ["quant"] = 200,
                        ["id"] = "1690287389",
                        ["itemLink"] = 512,
                    },
                    [5] = 
                    {
                        ["price"] = 3200,
                        ["guild"] = 1,
                        ["buyer"] = 446,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633009604,
                        ["quant"] = 200,
                        ["id"] = "1690287401",
                        ["itemLink"] = 512,
                    },
                    [6] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1814,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633249807,
                        ["quant"] = 137,
                        ["id"] = "1692269719",
                        ["itemLink"] = 512,
                    },
                    [7] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2006,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633294334,
                        ["quant"] = 200,
                        ["id"] = "1692681221",
                        ["itemLink"] = 512,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr01 white normal miscellaneous lure",
            },
        },
        [43641] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Greenshade Treasure Map V",
                ["oldestTime"] = 1633182528,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182528,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 389,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182528,
                        ["quant"] = 1,
                        ["id"] = "1691608295",
                        ["itemLink"] = 1961,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [56954] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Rumare Slaughterfish Pie",
                ["oldestTime"] = 1632865320,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865320,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 2261,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1632865320,
                        ["quant"] = 1,
                        ["id"] = "1689266945",
                        ["itemLink"] = 3333,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [68219] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Hagraven's Tonic",
                ["oldestTime"] = 1633219271,
                ["wasAltered"] = true,
                ["newestTime"] = 1633219271,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20,
                        ["guild"] = 1,
                        ["buyer"] = 1262,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633219271,
                        ["quant"] = 1,
                        ["id"] = "1692005253",
                        ["itemLink"] = 2341,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [116093] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing3.dds",
                ["itemDesc"] = "Diagram: Khajiit Candle, Clawfoot",
                ["oldestTime"] = 1633226331,
                ["wasAltered"] = true,
                ["newestTime"] = 1633226331,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1013,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633226331,
                        ["quant"] = 1,
                        ["id"] = "1692077905",
                        ["itemLink"] = 2395,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [177023] = 
        {
            ["1:0:3:50:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_boots_medium.dds",
                ["itemDesc"] = "Companion's Boots",
                ["oldestTime"] = 1632886659,
                ["wasAltered"] = true,
                ["newestTime"] = 1632886659,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 699,
                        ["guild"] = 1,
                        ["buyer"] = 2396,
                        ["wasKiosk"] = true,
                        ["seller"] = 177,
                        ["timestamp"] = 1632886659,
                        ["quant"] = 1,
                        ["id"] = "1689468237",
                        ["itemLink"] = 3523,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior medium apparel feet bolstered",
            },
        },
        [172160] = 
        {
            ["46:0:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_legs_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Guards",
                ["oldestTime"] = 1633099366,
                ["wasAltered"] = true,
                ["newestTime"] = 1633099366,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 499,
                        ["guild"] = 1,
                        ["buyer"] = 940,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633099366,
                        ["quant"] = 1,
                        ["id"] = "1690952523",
                        ["itemLink"] = 1276,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr46 green fine medium apparel set deadlands assassin legs divines",
            },
        },
        [71297] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_ring_a.dds",
                ["itemDesc"] = "Signet of the Pariah",
                ["oldestTime"] = 1632793709,
                ["wasAltered"] = true,
                ["newestTime"] = 1633049774,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 2,
                        ["buyer"] = 131,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1632793709,
                        ["quant"] = 1,
                        ["id"] = "1688754613",
                        ["itemLink"] = 135,
                    },
                    [2] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 334,
                        ["wasKiosk"] = false,
                        ["seller"] = 695,
                        ["timestamp"] = 1633049770,
                        ["quant"] = 1,
                        ["id"] = "1690602385",
                        ["itemLink"] = 135,
                    },
                    [3] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 334,
                        ["wasKiosk"] = false,
                        ["seller"] = 696,
                        ["timestamp"] = 1633049774,
                        ["quant"] = 1,
                        ["id"] = "1690602439",
                        ["itemLink"] = 135,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set mark of the pariah ring robust",
            },
        },
        [166786] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Solitude Candlestick, Horn",
                ["oldestTime"] = 1633014707,
                ["wasAltered"] = true,
                ["newestTime"] = 1633115075,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 570,
                        ["guild"] = 1,
                        ["buyer"] = 467,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633014707,
                        ["quant"] = 1,
                        ["id"] = "1690323631",
                        ["itemLink"] = 533,
                    },
                    [2] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1016,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633115075,
                        ["quant"] = 1,
                        ["id"] = "1691072369",
                        ["itemLink"] = 533,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [177028] = 
        {
            ["1:0:3:50:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_belt_heavy.dds",
                ["itemDesc"] = "Companion's Girdle",
                ["oldestTime"] = 1632978426,
                ["wasAltered"] = true,
                ["newestTime"] = 1633295509,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 49999,
                        ["guild"] = 1,
                        ["buyer"] = 249,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1632978426,
                        ["quant"] = 1,
                        ["id"] = "1690121605",
                        ["itemLink"] = 250,
                    },
                    [2] = 
                    {
                        ["price"] = 49999,
                        ["guild"] = 1,
                        ["buyer"] = 1204,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633142403,
                        ["quant"] = 1,
                        ["id"] = "1691318387",
                        ["itemLink"] = 250,
                    },
                    [3] = 
                    {
                        ["price"] = 49999,
                        ["guild"] = 1,
                        ["buyer"] = 2001,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633293812,
                        ["quant"] = 1,
                        ["id"] = "1692673719",
                        ["itemLink"] = 250,
                    },
                    [4] = 
                    {
                        ["price"] = 49999,
                        ["guild"] = 1,
                        ["buyer"] = 2019,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633295509,
                        ["quant"] = 1,
                        ["id"] = "1692696321",
                        ["itemLink"] = 250,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior heavy apparel waist bolstered",
            },
        },
        [139654] = 
        {
            ["1:0:4:33:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Exemplary Infused Ring",
                ["oldestTime"] = 1632847963,
                ["wasAltered"] = true,
                ["newestTime"] = 1633316345,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1633163928,
                        ["quant"] = 1,
                        ["id"] = "1691490439",
                        ["itemLink"] = 1823,
                    },
                    [2] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633163930,
                        ["quant"] = 1,
                        ["id"] = "1691490455",
                        ["itemLink"] = 1823,
                    },
                    [3] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633163931,
                        ["quant"] = 1,
                        ["id"] = "1691490459",
                        ["itemLink"] = 1823,
                    },
                    [4] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 506,
                        ["timestamp"] = 1633163931,
                        ["quant"] = 1,
                        ["id"] = "1691490463",
                        ["itemLink"] = 1823,
                    },
                    [5] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 1313,
                        ["timestamp"] = 1633163932,
                        ["quant"] = 1,
                        ["id"] = "1691490465",
                        ["itemLink"] = 1823,
                    },
                    [6] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633163933,
                        ["quant"] = 1,
                        ["id"] = "1691490477",
                        ["itemLink"] = 1823,
                    },
                    [7] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 534,
                        ["timestamp"] = 1633163934,
                        ["quant"] = 1,
                        ["id"] = "1691490479",
                        ["itemLink"] = 1823,
                    },
                    [8] = 
                    {
                        ["price"] = 4995,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 322,
                        ["timestamp"] = 1633163936,
                        ["quant"] = 1,
                        ["id"] = "1691490495",
                        ["itemLink"] = 1823,
                    },
                    [9] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 603,
                        ["timestamp"] = 1633163938,
                        ["quant"] = 1,
                        ["id"] = "1691490505",
                        ["itemLink"] = 1823,
                    },
                    [10] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2096,
                        ["wasKiosk"] = true,
                        ["seller"] = 61,
                        ["timestamp"] = 1633316343,
                        ["quant"] = 1,
                        ["id"] = "1692918723",
                        ["itemLink"] = 1823,
                    },
                    [11] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2096,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1633316345,
                        ["quant"] = 1,
                        ["id"] = "1692918753",
                        ["itemLink"] = 1823,
                    },
                    [12] = 
                    {
                        ["price"] = 850,
                        ["guild"] = 1,
                        ["buyer"] = 2204,
                        ["wasKiosk"] = true,
                        ["seller"] = 269,
                        ["timestamp"] = 1632847963,
                        ["quant"] = 1,
                        ["id"] = "1689127205",
                        ["itemLink"] = 1823,
                    },
                    [13] = 
                    {
                        ["price"] = 1064,
                        ["guild"] = 1,
                        ["buyer"] = 2051,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1632934526,
                        ["quant"] = 1,
                        ["id"] = "1689755967",
                        ["itemLink"] = 1823,
                    },
                    [14] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 2051,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1632934528,
                        ["quant"] = 1,
                        ["id"] = "1689755989",
                        ["itemLink"] = 1823,
                    },
                },
                ["totalCount"] = 14,
                ["itemAdderText"] = "rr01 purple epic jewelry apparel ring infused",
            },
        },
        [180617] = 
        {
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_medium_hands_a.dds",
                ["itemDesc"] = "Plaguebreak Bracers",
                ["oldestTime"] = 1633112141,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112141,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8999,
                        ["guild"] = 1,
                        ["buyer"] = 989,
                        ["wasKiosk"] = true,
                        ["seller"] = 990,
                        ["timestamp"] = 1633112141,
                        ["quant"] = 1,
                        ["id"] = "1691053365",
                        ["itemLink"] = 1342,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set plaguebreak hands infused",
            },
        },
        [123530] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Knight Slayer Ring",
                ["oldestTime"] = 1633113812,
                ["wasAltered"] = true,
                ["newestTime"] = 1633113812,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 940,
                        ["guild"] = 1,
                        ["buyer"] = 1003,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633113812,
                        ["quant"] = 1,
                        ["id"] = "1691064293",
                        ["itemLink"] = 1366,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set knight slayer ring arcane",
            },
        },
        [101515] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Witchman's Ring",
                ["oldestTime"] = 1633163915,
                ["wasAltered"] = true,
                ["newestTime"] = 1633211063,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1421,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633163915,
                        ["quant"] = 1,
                        ["id"] = "1691490343",
                        ["itemLink"] = 1811,
                    },
                    [2] = 
                    {
                        ["price"] = 1450,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633163915,
                        ["quant"] = 1,
                        ["id"] = "1691490345",
                        ["itemLink"] = 1811,
                    },
                    [3] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 1553,
                        ["wasKiosk"] = true,
                        ["seller"] = 597,
                        ["timestamp"] = 1633211063,
                        ["quant"] = 1,
                        ["id"] = "1691916213",
                        ["itemLink"] = 1811,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set witchman armor ring robust",
            },
        },
        [155021] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Marauder's Haste",
                ["oldestTime"] = 1633163907,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163907,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 655,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633163907,
                        ["quant"] = 1,
                        ["id"] = "1691490287",
                        ["itemLink"] = 1796,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set marauder's haste ring arcane",
            },
        },
        [147742] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 75: Sunspire Shoulders",
                ["oldestTime"] = 1633143425,
                ["wasAltered"] = true,
                ["newestTime"] = 1633143425,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1213,
                        ["wasKiosk"] = true,
                        ["seller"] = 1215,
                        ["timestamp"] = 1633143425,
                        ["quant"] = 1,
                        ["id"] = "1691330777",
                        ["itemLink"] = 1635,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [133065] = 
        {
            ["50:16:4:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nocturnal_2hhammer_a.dds",
                ["itemDesc"] = "Maul of Unfathomable Darkness",
                ["oldestTime"] = 1632963797,
                ["wasAltered"] = true,
                ["newestTime"] = 1632963797,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2648,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632963797,
                        ["quant"] = 1,
                        ["id"] = "1689993981",
                        ["itemLink"] = 3942,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set unfathomable darkness mace two-handed powered",
            },
        },
        [100399] = 
        {
            ["50:16:4:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_1hhammer_d.dds",
                ["itemDesc"] = "Vampire Lord's Mace",
                ["oldestTime"] = 1632963462,
                ["wasAltered"] = true,
                ["newestTime"] = 1632963462,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2647,
                        ["wasKiosk"] = true,
                        ["seller"] = 474,
                        ["timestamp"] = 1632963462,
                        ["quant"] = 1,
                        ["id"] = "1689990665",
                        ["itemLink"] = 3941,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set vampire lord mace one-handed infused",
            },
        },
        [180512] = 
        {
            ["50:16:4:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_light_waist_a.dds",
                ["itemDesc"] = "Sash of Dark Convergence",
                ["oldestTime"] = 1632962111,
                ["wasAltered"] = true,
                ["newestTime"] = 1632962111,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7534,
                        ["guild"] = 1,
                        ["buyer"] = 2480,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632962111,
                        ["quant"] = 1,
                        ["id"] = "1689976265",
                        ["itemLink"] = 3931,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set dark convergence waist reinforced",
            },
        },
        [130034] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 79: Refabricated Helmets",
                ["oldestTime"] = 1632950244,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950244,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25800,
                        ["guild"] = 1,
                        ["buyer"] = 2586,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1632950244,
                        ["quant"] = 1,
                        ["id"] = "1689876185",
                        ["itemLink"] = 3836,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [72851] = 
        {
            ["50:16:4:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_light_head_a.dds",
                ["itemDesc"] = "Hat of Bahraha's Curse",
                ["oldestTime"] = 1633017983,
                ["wasAltered"] = true,
                ["newestTime"] = 1633017983,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 489,
                        ["wasKiosk"] = true,
                        ["seller"] = 374,
                        ["timestamp"] = 1633017983,
                        ["quant"] = 1,
                        ["id"] = "1690349313",
                        ["itemLink"] = 567,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set bahraha's curse head reinforced",
            },
        },
        [172180] = 
        {
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_legs_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Guards",
                ["oldestTime"] = 1633225746,
                ["wasAltered"] = true,
                ["newestTime"] = 1633225746,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1645,
                        ["wasKiosk"] = true,
                        ["seller"] = 1417,
                        ["timestamp"] = 1633225746,
                        ["quant"] = 1,
                        ["id"] = "1692071759",
                        ["itemLink"] = 2388,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set deadlands assassin legs well-fitted",
            },
        },
        [156629] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 80: Shield of Senchal Belts",
                ["oldestTime"] = 1632947164,
                ["wasAltered"] = true,
                ["newestTime"] = 1632947164,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 2570,
                        ["wasKiosk"] = true,
                        ["seller"] = 31,
                        ["timestamp"] = 1632947164,
                        ["quant"] = 1,
                        ["id"] = "1689851841",
                        ["itemLink"] = 3795,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45277] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_light_robe_d.dds",
                ["itemDesc"] = "Ancestor Silk Robe of Health",
                ["oldestTime"] = 1632936830,
                ["wasAltered"] = true,
                ["newestTime"] = 1632936830,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 226,
                        ["wasKiosk"] = false,
                        ["seller"] = 442,
                        ["timestamp"] = 1632936830,
                        ["quant"] = 1,
                        ["id"] = "1689774013",
                        ["itemLink"] = 3745,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel chest divines",
            },
        },
        [45207] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_light_robe_d.dds",
                ["itemDesc"] = "Ancestor Silk Robe of Health",
                ["oldestTime"] = 1633022971,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022971,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633022971,
                        ["quant"] = 1,
                        ["id"] = "1690390343",
                        ["itemLink"] = 611,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel chest infused",
            },
        },
        [139416] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_runecrafter_armor_component_005.dds",
                ["itemDesc"] = "Pulverized Titanium",
                ["oldestTime"] = 1632827183,
                ["wasAltered"] = true,
                ["newestTime"] = 1632827183,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15881,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632827183,
                        ["quant"] = 200,
                        ["id"] = "1688977043",
                        ["itemLink"] = 3059,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials raw trait",
            },
        },
        [126759] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_uni_inc_yarnball001.dds",
                ["itemDesc"] = "Sir Socks's Ball of Yarn",
                ["oldestTime"] = 1632935709,
                ["wasAltered"] = true,
                ["newestTime"] = 1632935710,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 493,
                        ["timestamp"] = 1632935709,
                        ["quant"] = 1,
                        ["id"] = "1689767097",
                        ["itemLink"] = 3734,
                    },
                    [2] = 
                    {
                        ["price"] = 1731,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 493,
                        ["timestamp"] = 1632935710,
                        ["quant"] = 1,
                        ["id"] = "1689767103",
                        ["itemLink"] = 3734,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior furnishings undercroft",
            },
        },
        [140448] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 63: Dremora Bows",
                ["oldestTime"] = 1632930208,
                ["wasAltered"] = true,
                ["newestTime"] = 1632961728,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 66600,
                        ["guild"] = 1,
                        ["buyer"] = 2510,
                        ["wasKiosk"] = true,
                        ["seller"] = 611,
                        ["timestamp"] = 1632930208,
                        ["quant"] = 1,
                        ["id"] = "1689723613",
                        ["itemLink"] = 3699,
                    },
                    [2] = 
                    {
                        ["price"] = 59800,
                        ["guild"] = 1,
                        ["buyer"] = 2375,
                        ["wasKiosk"] = true,
                        ["seller"] = 611,
                        ["timestamp"] = 1632961728,
                        ["quant"] = 1,
                        ["id"] = "1689972675",
                        ["itemLink"] = 3699,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45211] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_light_legs_d.dds",
                ["itemDesc"] = "Ancestor Silk Breeches of Magicka",
                ["oldestTime"] = 1633022964,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022965,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633022964,
                        ["quant"] = 1,
                        ["id"] = "1690390311",
                        ["itemLink"] = 604,
                    },
                    [2] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633022965,
                        ["quant"] = 1,
                        ["id"] = "1690390315",
                        ["itemLink"] = 605,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine light apparel legs infused",
            },
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_legs_d.dds",
                ["itemDesc"] = "Ancestor Silk Breeches of Magicka",
                ["oldestTime"] = 1632977279,
                ["wasAltered"] = true,
                ["newestTime"] = 1632977279,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 231,
                        ["wasKiosk"] = true,
                        ["seller"] = 51,
                        ["timestamp"] = 1632977279,
                        ["quant"] = 1,
                        ["id"] = "1690113029",
                        ["itemLink"] = 242,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel legs infused",
            },
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_light_legs_d.dds",
                ["itemDesc"] = "Ancestor Silk Breeches of Magicka",
                ["oldestTime"] = 1633022981,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022981,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 531,
                        ["timestamp"] = 1633022981,
                        ["quant"] = 1,
                        ["id"] = "1690390451",
                        ["itemLink"] = 621,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel legs infused",
            },
        },
        [142683] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_elderarg_light_chest_a.dds",
                ["itemDesc"] = "Bright-Throat's Boast Jerkin",
                ["oldestTime"] = 1632921131,
                ["wasAltered"] = true,
                ["newestTime"] = 1632921131,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1632921131,
                        ["quant"] = 1,
                        ["id"] = "1689658245",
                        ["itemLink"] = 3654,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set bright-throat's boast chest reinforced",
            },
        },
        [134761] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 58: Fang Lair Daggers",
                ["oldestTime"] = 1632919881,
                ["wasAltered"] = true,
                ["newestTime"] = 1632919881,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 862,
                        ["wasKiosk"] = true,
                        ["seller"] = 261,
                        ["timestamp"] = 1632919881,
                        ["quant"] = 1,
                        ["id"] = "1689650857",
                        ["itemLink"] = 3647,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [54174] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_light_armor_vendor_001.dds",
                ["itemDesc"] = "Hemming",
                ["oldestTime"] = 1632848335,
                ["wasAltered"] = true,
                ["newestTime"] = 1632981228,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 265,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1632981228,
                        ["quant"] = 200,
                        ["id"] = "1690137767",
                        ["itemLink"] = 271,
                    },
                    [2] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632848335,
                        ["quant"] = 200,
                        ["id"] = "1689130885",
                        ["itemLink"] = 271,
                    },
                    [3] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 2205,
                        ["timestamp"] = 1632848336,
                        ["quant"] = 200,
                        ["id"] = "1689130897",
                        ["itemLink"] = 271,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine materials tannin",
            },
        },
        [166047] = 
        {
            ["50:15:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_u26_enchantment_037.dds",
                ["itemDesc"] = "Superb Glyph of Prismatic Recovery",
                ["oldestTime"] = 1632993886,
                ["wasAltered"] = true,
                ["newestTime"] = 1633133658,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 371,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632993886,
                        ["quant"] = 1,
                        ["id"] = "1690205049",
                        ["itemLink"] = 367,
                    },
                    [2] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 1126,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633133658,
                        ["quant"] = 1,
                        ["id"] = "1691227281",
                        ["itemLink"] = 367,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp150 gold legendary miscellaneous jewelry glyph",
            },
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_u26_enchantment_037.dds",
                ["itemDesc"] = "Truly Superb Glyph of Prismatic Recovery",
                ["oldestTime"] = 1633058071,
                ["wasAltered"] = true,
                ["newestTime"] = 1633058079,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 771,
                        ["wasKiosk"] = true,
                        ["seller"] = 605,
                        ["timestamp"] = 1633058071,
                        ["quant"] = 1,
                        ["id"] = "1690690991",
                        ["itemLink"] = 982,
                    },
                    [2] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 771,
                        ["wasKiosk"] = true,
                        ["seller"] = 696,
                        ["timestamp"] = 1633058079,
                        ["quant"] = 1,
                        ["id"] = "1690691069",
                        ["itemLink"] = 982,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous jewelry glyph",
            },
        },
        [175776] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Old Orsinium Bow",
                ["oldestTime"] = 1632780930,
                ["wasAltered"] = true,
                ["newestTime"] = 1632780930,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 2,
                        ["buyer"] = 127,
                        ["wasKiosk"] = false,
                        ["seller"] = 130,
                        ["timestamp"] = 1632780930,
                        ["quant"] = 1,
                        ["id"] = "1688621177",
                        ["itemLink"] = 127,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [100769] = 
        {
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Seventh Legion's Ring",
                ["oldestTime"] = 1633163935,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163935,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4400,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633163935,
                        ["quant"] = 1,
                        ["id"] = "1691490485",
                        ["itemLink"] = 1826,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set seventh legion brute ring healthy",
            },
        },
        [172280] = 
        {
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_legs_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Guards",
                ["oldestTime"] = 1633146890,
                ["wasAltered"] = true,
                ["newestTime"] = 1633146890,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1237,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1633146890,
                        ["quant"] = 1,
                        ["id"] = "1691364753",
                        ["itemLink"] = 1655,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set deadlands assassin legs training",
            },
        },
        [43683] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "The Rift Treasure Map V",
                ["oldestTime"] = 1633011633,
                ["wasAltered"] = true,
                ["newestTime"] = 1633011633,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 454,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633011633,
                        ["quant"] = 1,
                        ["id"] = "1690301443",
                        ["itemLink"] = 516,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [49129] = 
        {
            ["10:0:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_medium_legs_a.dds",
                ["itemDesc"] = "Guards of the Night Mother",
                ["oldestTime"] = 1632911085,
                ["wasAltered"] = true,
                ["newestTime"] = 1632911085,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2463,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632911085,
                        ["quant"] = 1,
                        ["id"] = "1689604527",
                        ["itemLink"] = 3612,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr10 blue superior medium apparel set night mother's gaze legs training",
            },
        },
        [140453] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 63: Dremora Legs",
                ["oldestTime"] = 1632821365,
                ["wasAltered"] = true,
                ["newestTime"] = 1632821365,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 110000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632821365,
                        ["quant"] = 1,
                        ["id"] = "1688949301",
                        ["itemLink"] = 3013,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [64713] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_laurel.dds",
                ["itemDesc"] = "Laurel",
                ["oldestTime"] = 1632910605,
                ["wasAltered"] = true,
                ["newestTime"] = 1632910605,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632910605,
                        ["quant"] = 13,
                        ["id"] = "1689602961",
                        ["itemLink"] = 3601,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [119207] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing3.dds",
                ["itemDesc"] = "Diagram: Redguard Mug, Full",
                ["oldestTime"] = 1632865528,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865528,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19000,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 177,
                        ["timestamp"] = 1632865528,
                        ["quant"] = 1,
                        ["id"] = "1689268851",
                        ["itemLink"] = 3339,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [172200] = 
        {
            ["50:16:2:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_legs_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Guards",
                ["oldestTime"] = 1633124679,
                ["wasAltered"] = true,
                ["newestTime"] = 1633124679,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1078,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633124679,
                        ["quant"] = 1,
                        ["id"] = "1691139927",
                        ["itemLink"] = 1465,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set deadlands assassin legs reinforced",
            },
        },
        [68207] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Capon Tomato-Beet Casserole",
                ["oldestTime"] = 1632907619,
                ["wasAltered"] = true,
                ["newestTime"] = 1632907619,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 2456,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1632907619,
                        ["quant"] = 1,
                        ["id"] = "1689594589",
                        ["itemLink"] = 3593,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [180470] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_light_waist_a.dds",
                ["itemDesc"] = "Sash of Dark Convergence",
                ["oldestTime"] = 1632906880,
                ["wasAltered"] = true,
                ["newestTime"] = 1632906880,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 33500,
                        ["guild"] = 1,
                        ["buyer"] = 375,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1632906880,
                        ["quant"] = 1,
                        ["id"] = "1689591653",
                        ["itemLink"] = 3592,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set dark convergence waist divines",
            },
        },
        [176555] = 
        {
            ["1:0:2:47:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_boots_medium.dds",
                ["itemDesc"] = "Companion's Boots",
                ["oldestTime"] = 1633290938,
                ["wasAltered"] = true,
                ["newestTime"] = 1633290938,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1985,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1633290938,
                        ["quant"] = 1,
                        ["id"] = "1692637771",
                        ["itemLink"] = 2787,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine medium apparel feet aggressive",
            },
        },
        [116095] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Khajiit Banner, Claw",
                ["oldestTime"] = 1632905678,
                ["wasAltered"] = true,
                ["newestTime"] = 1632905678,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 125,
                        ["guild"] = 1,
                        ["buyer"] = 2452,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632905678,
                        ["quant"] = 1,
                        ["id"] = "1689584617",
                        ["itemLink"] = 3585,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [126558] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_dun_lsb_postlight003.dds",
                ["itemDesc"] = "Indoril Streetlight, Stone",
                ["oldestTime"] = 1632884182,
                ["wasAltered"] = true,
                ["newestTime"] = 1632884182,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3405,
                        ["guild"] = 1,
                        ["buyer"] = 2380,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1632884182,
                        ["quant"] = 1,
                        ["id"] = "1689441457",
                        ["itemLink"] = 3496,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings lighting",
            },
        },
        [147374] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_medium_hands_a.dds",
                ["itemDesc"] = "Deadly Bracers",
                ["oldestTime"] = 1632993798,
                ["wasAltered"] = true,
                ["newestTime"] = 1632993798,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 370,
                        ["wasKiosk"] = true,
                        ["seller"] = 356,
                        ["timestamp"] = 1632993798,
                        ["quant"] = 1,
                        ["id"] = "1690204807",
                        ["itemLink"] = 366,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set deadly strike hands divines",
            },
        },
        [139233] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_fur_highendtable001.dds",
                ["itemDesc"] = "Alinor Nightstand, Noble",
                ["oldestTime"] = 1632881286,
                ["wasAltered"] = true,
                ["newestTime"] = 1632881286,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25914,
                        ["guild"] = 1,
                        ["buyer"] = 2357,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1632881286,
                        ["quant"] = 1,
                        ["id"] = "1689409515",
                        ["itemLink"] = 3465,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings suite",
            },
        },
        [175667] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_inc_leyplantpot007.dds",
                ["itemDesc"] = "Leyawiin Vase, Table",
                ["oldestTime"] = 1633271690,
                ["wasAltered"] = true,
                ["newestTime"] = 1633271690,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 23000,
                        ["guild"] = 1,
                        ["buyer"] = 1883,
                        ["wasKiosk"] = true,
                        ["seller"] = 17,
                        ["timestamp"] = 1633271690,
                        ["quant"] = 1,
                        ["id"] = "1692422355",
                        ["itemLink"] = 2677,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings hearth",
            },
        },
        [180657] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_medium_hands_a.dds",
                ["itemDesc"] = "Plaguebreak Bracers",
                ["oldestTime"] = 1632878359,
                ["wasAltered"] = true,
                ["newestTime"] = 1632878359,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 670,
                        ["wasKiosk"] = true,
                        ["seller"] = 145,
                        ["timestamp"] = 1632878359,
                        ["quant"] = 1,
                        ["id"] = "1689376283",
                        ["itemLink"] = 3439,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set plaguebreak hands well-fitted",
            },
        },
        [160603] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 89: Ancestral High Elf Maces",
                ["oldestTime"] = 1633205009,
                ["wasAltered"] = true,
                ["newestTime"] = 1633214046,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 698,
                        ["wasKiosk"] = true,
                        ["seller"] = 33,
                        ["timestamp"] = 1633205009,
                        ["quant"] = 1,
                        ["id"] = "1691842439",
                        ["itemLink"] = 2240,
                    },
                    [2] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 1571,
                        ["wasKiosk"] = true,
                        ["seller"] = 1214,
                        ["timestamp"] = 1633214046,
                        ["quant"] = 1,
                        ["id"] = "1691950135",
                        ["itemLink"] = 2240,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [34311] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/provisioner_apple.dds",
                ["itemDesc"] = "Apples",
                ["oldestTime"] = 1632861576,
                ["wasAltered"] = true,
                ["newestTime"] = 1632861576,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 802,
                        ["timestamp"] = 1632861576,
                        ["quant"] = 200,
                        ["id"] = "1689241579",
                        ["itemLink"] = 3305,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [123166] = 
        {
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Vanguard's Challenge Ring",
                ["oldestTime"] = 1632932637,
                ["wasAltered"] = true,
                ["newestTime"] = 1633206610,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2399,
                        ["guild"] = 1,
                        ["buyer"] = 42,
                        ["wasKiosk"] = false,
                        ["seller"] = 158,
                        ["timestamp"] = 1633206610,
                        ["quant"] = 1,
                        ["id"] = "1691863169",
                        ["itemLink"] = 2254,
                    },
                    [2] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 196,
                        ["wasKiosk"] = true,
                        ["seller"] = 785,
                        ["timestamp"] = 1632932637,
                        ["quant"] = 1,
                        ["id"] = "1689741513",
                        ["itemLink"] = 2254,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set vanguard's challenge ring healthy",
            },
        },
        [156612] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 81: New Moon Priest Bows",
                ["oldestTime"] = 1632941248,
                ["wasAltered"] = true,
                ["newestTime"] = 1633234836,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1499,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 277,
                        ["timestamp"] = 1633234836,
                        ["quant"] = 1,
                        ["id"] = "1692159905",
                        ["itemLink"] = 2473,
                    },
                    [2] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 2547,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1632941248,
                        ["quant"] = 1,
                        ["id"] = "1689804033",
                        ["itemLink"] = 2473,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [126611] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_fan_forestanemone002.dds",
                ["itemDesc"] = "Vvardenfell Anemone, Sprout",
                ["oldestTime"] = 1632851089,
                ["wasAltered"] = true,
                ["newestTime"] = 1632851089,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 175,
                        ["wasKiosk"] = false,
                        ["seller"] = 669,
                        ["timestamp"] = 1632851089,
                        ["quant"] = 1,
                        ["id"] = "1689152511",
                        ["itemLink"] = 3235,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings conservatory",
            },
        },
        [45918] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Tarragon Chicken",
                ["oldestTime"] = 1632839852,
                ["wasAltered"] = true,
                ["newestTime"] = 1632839852,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 27,
                        ["guild"] = 1,
                        ["buyer"] = 2173,
                        ["wasKiosk"] = true,
                        ["seller"] = 531,
                        ["timestamp"] = 1632839852,
                        ["quant"] = 1,
                        ["id"] = "1689059321",
                        ["itemLink"] = 3132,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [102072] = 
        {
            ["50:16:5:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Stygian Necklace",
                ["oldestTime"] = 1633126347,
                ["wasAltered"] = true,
                ["newestTime"] = 1633126347,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1249999,
                        ["guild"] = 1,
                        ["buyer"] = 1086,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633126347,
                        ["quant"] = 1,
                        ["id"] = "1691152831",
                        ["itemLink"] = 1488,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary jewelry apparel set stygian neck robust",
            },
        },
        [126441] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_vrd_fur_hlascreen003.dds",
                ["itemDesc"] = "Dres Divider, Honeycomb",
                ["oldestTime"] = 1632839058,
                ["wasAltered"] = true,
                ["newestTime"] = 1632839058,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 883,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632839058,
                        ["quant"] = 1,
                        ["id"] = "1689054905",
                        ["itemLink"] = 3122,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings suite",
            },
        },
        [180687] = 
        {
            ["50:16:3:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_2hsword_a.dds",
                ["itemDesc"] = "Plaguebreak Greatsword",
                ["oldestTime"] = 1633195590,
                ["wasAltered"] = true,
                ["newestTime"] = 1633195590,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 803,
                        ["wasKiosk"] = false,
                        ["seller"] = 207,
                        ["timestamp"] = 1633195590,
                        ["quant"] = 1,
                        ["id"] = "1691747255",
                        ["itemLink"] = 2139,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set plaguebreak sword two-handed sharpened",
            },
        },
        [77519] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of Flanking",
                ["oldestTime"] = 1632830383,
                ["wasAltered"] = true,
                ["newestTime"] = 1632830383,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7200,
                        ["guild"] = 1,
                        ["buyer"] = 1918,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1632830383,
                        ["quant"] = 1,
                        ["id"] = "1689000667",
                        ["itemLink"] = 3083,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set flanking strategist neck robust",
            },
        },
        [147720] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 74: Pellitine Daggers",
                ["oldestTime"] = 1632821555,
                ["wasAltered"] = true,
                ["newestTime"] = 1632821555,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 633,
                        ["timestamp"] = 1632821555,
                        ["quant"] = 1,
                        ["id"] = "1688950101",
                        ["itemLink"] = 3014,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [151741] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_lsb_sconce002.dds",
                ["itemDesc"] = "Elsweyr Sconce, Candle Engraved",
                ["oldestTime"] = 1633200995,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200995,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 1492,
                        ["wasKiosk"] = true,
                        ["seller"] = 323,
                        ["timestamp"] = 1633200995,
                        ["quant"] = 3,
                        ["id"] = "1691800529",
                        ["itemLink"] = 2208,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings lighting",
            },
        },
        [90313] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_1hsword_a.dds",
                ["itemDesc"] = "Sword of the Desert Rose",
                ["oldestTime"] = 1633308650,
                ["wasAltered"] = true,
                ["newestTime"] = 1633308650,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 94995,
                        ["guild"] = 1,
                        ["buyer"] = 2080,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1633308650,
                        ["quant"] = 1,
                        ["id"] = "1692830877",
                        ["itemLink"] = 2961,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set desert rose sword one-handed sharpened",
            },
        },
        [175551] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Blackwood Treasure Map V",
                ["oldestTime"] = 1632948542,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293475,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 162,
                        ["timestamp"] = 1633057668,
                        ["quant"] = 1,
                        ["id"] = "1690687267",
                        ["itemLink"] = 972,
                    },
                    [2] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 513,
                        ["timestamp"] = 1633057669,
                        ["quant"] = 1,
                        ["id"] = "1690687277",
                        ["itemLink"] = 972,
                    },
                    [3] = 
                    {
                        ["price"] = 66022,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 109,
                        ["timestamp"] = 1633057671,
                        ["quant"] = 1,
                        ["id"] = "1690687289",
                        ["itemLink"] = 972,
                    },
                    [4] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 513,
                        ["timestamp"] = 1633075825,
                        ["quant"] = 1,
                        ["id"] = "1690815841",
                        ["itemLink"] = 972,
                    },
                    [5] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 454,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1633131883,
                        ["quant"] = 1,
                        ["id"] = "1691207263",
                        ["itemLink"] = 972,
                    },
                    [6] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 153,
                        ["timestamp"] = 1633146744,
                        ["quant"] = 1,
                        ["id"] = "1691363283",
                        ["itemLink"] = 972,
                    },
                    [7] = 
                    {
                        ["price"] = 49999,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 521,
                        ["timestamp"] = 1633146747,
                        ["quant"] = 1,
                        ["id"] = "1691363293",
                        ["itemLink"] = 972,
                    },
                    [8] = 
                    {
                        ["price"] = 49999,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 521,
                        ["timestamp"] = 1633146747,
                        ["quant"] = 1,
                        ["id"] = "1691363297",
                        ["itemLink"] = 972,
                    },
                    [9] = 
                    {
                        ["price"] = 49999,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 521,
                        ["timestamp"] = 1633146751,
                        ["quant"] = 1,
                        ["id"] = "1691363345",
                        ["itemLink"] = 972,
                    },
                    [10] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1260,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633150583,
                        ["quant"] = 1,
                        ["id"] = "1691396431",
                        ["itemLink"] = 972,
                    },
                    [11] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 521,
                        ["timestamp"] = 1633156798,
                        ["quant"] = 1,
                        ["id"] = "1691444659",
                        ["itemLink"] = 972,
                    },
                    [12] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 332,
                        ["wasKiosk"] = false,
                        ["seller"] = 502,
                        ["timestamp"] = 1633211955,
                        ["quant"] = 1,
                        ["id"] = "1691928191",
                        ["itemLink"] = 972,
                    },
                    [13] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 56,
                        ["timestamp"] = 1633227286,
                        ["quant"] = 1,
                        ["id"] = "1692088055",
                        ["itemLink"] = 972,
                    },
                    [14] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 615,
                        ["timestamp"] = 1633227287,
                        ["quant"] = 1,
                        ["id"] = "1692088073",
                        ["itemLink"] = 972,
                    },
                    [15] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 763,
                        ["timestamp"] = 1633250694,
                        ["quant"] = 1,
                        ["id"] = "1692274953",
                        ["itemLink"] = 972,
                    },
                    [16] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 763,
                        ["timestamp"] = 1633250695,
                        ["quant"] = 1,
                        ["id"] = "1692274965",
                        ["itemLink"] = 972,
                    },
                    [17] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 763,
                        ["timestamp"] = 1633250696,
                        ["quant"] = 1,
                        ["id"] = "1692274969",
                        ["itemLink"] = 972,
                    },
                    [18] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 153,
                        ["timestamp"] = 1633250701,
                        ["quant"] = 1,
                        ["id"] = "1692275015",
                        ["itemLink"] = 972,
                    },
                    [19] = 
                    {
                        ["price"] = 34000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 1128,
                        ["timestamp"] = 1633284044,
                        ["quant"] = 1,
                        ["id"] = "1692556127",
                        ["itemLink"] = 972,
                    },
                    [20] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 2000,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633293475,
                        ["quant"] = 1,
                        ["id"] = "1692668939",
                        ["itemLink"] = 972,
                    },
                    [21] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 2576,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1632948542,
                        ["quant"] = 1,
                        ["id"] = "1689862065",
                        ["itemLink"] = 972,
                    },
                },
                ["totalCount"] = 21,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [45850] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_003.dds",
                ["itemDesc"] = "Ta",
                ["oldestTime"] = 1632925147,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294371,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 2007,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1633294371,
                        ["quant"] = 100,
                        ["id"] = "1692681887",
                        ["itemLink"] = 2863,
                    },
                    [2] = 
                    {
                        ["price"] = 1999,
                        ["guild"] = 1,
                        ["buyer"] = 2496,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1632925147,
                        ["quant"] = 200,
                        ["id"] = "1689687731",
                        ["itemLink"] = 2863,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials aspect runestone",
            },
        },
        [93755] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_shield_a.dds",
                ["itemDesc"] = "Shield of Cyrodiil's Ward",
                ["oldestTime"] = 1633291949,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291949,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 22,
                        ["timestamp"] = 1633291949,
                        ["quant"] = 1,
                        ["id"] = "1692651235",
                        ["itemLink"] = 2799,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic apparel weapon set ward of cyrodiil shield off hand divines",
            },
        },
        [57057] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Five-Fireball Infusion",
                ["oldestTime"] = 1633290945,
                ["wasAltered"] = true,
                ["newestTime"] = 1633290945,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 107,
                        ["timestamp"] = 1633290945,
                        ["quant"] = 1,
                        ["id"] = "1692637803",
                        ["itemLink"] = 2788,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [132547] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 54: Bloodforge Swords",
                ["oldestTime"] = 1633001285,
                ["wasAltered"] = true,
                ["newestTime"] = 1633001285,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22499,
                        ["guild"] = 1,
                        ["buyer"] = 404,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633001285,
                        ["quant"] = 1,
                        ["id"] = "1690240703",
                        ["itemLink"] = 412,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [137924] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 62: Sapiarch Bows",
                ["oldestTime"] = 1633233456,
                ["wasAltered"] = true,
                ["newestTime"] = 1633279206,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 351,
                        ["timestamp"] = 1633233456,
                        ["quant"] = 1,
                        ["id"] = "1692149311",
                        ["itemLink"] = 2455,
                    },
                    [2] = 
                    {
                        ["price"] = 8999,
                        ["guild"] = 1,
                        ["buyer"] = 1920,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633279206,
                        ["quant"] = 1,
                        ["id"] = "1692506865",
                        ["itemLink"] = 2455,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [153697] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_exc_telescope001.dds",
                ["itemDesc"] = "Clockwork Telescope, Stargazers",
                ["oldestTime"] = 1633288543,
                ["wasAltered"] = true,
                ["newestTime"] = 1633288543,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 85000,
                        ["guild"] = 1,
                        ["buyer"] = 1973,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633288543,
                        ["quant"] = 1,
                        ["id"] = "1692610243",
                        ["itemLink"] = 2770,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings workshop",
            },
        },
        [135155] = 
        {
            ["1:0:1:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/jewelrycrafting_trait_refined_cobalt.dds",
                ["itemDesc"] = "Cobalt",
                ["oldestTime"] = 1633179769,
                ["wasAltered"] = true,
                ["newestTime"] = 1633179771,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 387,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633179769,
                        ["quant"] = 10,
                        ["id"] = "1691583917",
                        ["itemLink"] = 1919,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 387,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633179771,
                        ["quant"] = 10,
                        ["id"] = "1691583919",
                        ["itemLink"] = 1919,
                    },
                    [3] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 387,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633179771,
                        ["quant"] = 10,
                        ["id"] = "1691583921",
                        ["itemLink"] = 1919,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials jewelry trait arcane",
            },
        },
        [120519] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_tre_trp_rmplainstree003.dds",
                ["itemDesc"] = "Tree, Healthy Privet",
                ["oldestTime"] = 1633225259,
                ["wasAltered"] = true,
                ["newestTime"] = 1633225259,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 799,
                        ["guild"] = 1,
                        ["buyer"] = 1642,
                        ["wasKiosk"] = true,
                        ["seller"] = 99,
                        ["timestamp"] = 1633225259,
                        ["quant"] = 1,
                        ["id"] = "1692066635",
                        ["itemLink"] = 2381,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings conservatory",
            },
        },
        [147712] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 73: Anequina Swords",
                ["oldestTime"] = 1632939814,
                ["wasAltered"] = true,
                ["newestTime"] = 1633230248,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1618,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633222256,
                        ["quant"] = 1,
                        ["id"] = "1692035267",
                        ["itemLink"] = 2356,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1687,
                        ["wasKiosk"] = true,
                        ["seller"] = 1689,
                        ["timestamp"] = 1633230248,
                        ["quant"] = 1,
                        ["id"] = "1692117343",
                        ["itemLink"] = 2356,
                    },
                    [3] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1872,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632939814,
                        ["quant"] = 1,
                        ["id"] = "1689793821",
                        ["itemLink"] = 2356,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [137929] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 62: Sapiarch Legs",
                ["oldestTime"] = 1633217208,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261713,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9999,
                        ["guild"] = 1,
                        ["buyer"] = 1596,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633217208,
                        ["quant"] = 1,
                        ["id"] = "1691982131",
                        ["itemLink"] = 2323,
                    },
                    [2] = 
                    {
                        ["price"] = 22500,
                        ["guild"] = 1,
                        ["buyer"] = 1327,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633261713,
                        ["quant"] = 1,
                        ["id"] = "1692335107",
                        ["itemLink"] = 2323,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [30154] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_mushroom_white_cap_r1.dds",
                ["itemDesc"] = "White Cap",
                ["oldestTime"] = 1633199969,
                ["wasAltered"] = true,
                ["newestTime"] = 1633208684,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18600,
                        ["guild"] = 1,
                        ["buyer"] = 1484,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633199969,
                        ["quant"] = 200,
                        ["id"] = "1691789373",
                        ["itemLink"] = 2183,
                    },
                    [2] = 
                    {
                        ["price"] = 18600,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633208684,
                        ["quant"] = 200,
                        ["id"] = "1691890591",
                        ["itemLink"] = 2183,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [150731] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_dragons_blood.dds",
                ["itemDesc"] = "Dragon's Blood",
                ["oldestTime"] = 1633071130,
                ["wasAltered"] = true,
                ["newestTime"] = 1633282075,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 843,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633071130,
                        ["quant"] = 20,
                        ["id"] = "1690784435",
                        ["itemLink"] = 1088,
                    },
                    [2] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 843,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633071132,
                        ["quant"] = 20,
                        ["id"] = "1690784443",
                        ["itemLink"] = 1088,
                    },
                    [3] = 
                    {
                        ["price"] = 110500,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 957,
                        ["timestamp"] = 1633194075,
                        ["quant"] = 92,
                        ["id"] = "1691735687",
                        ["itemLink"] = 1088,
                    },
                    [4] = 
                    {
                        ["price"] = 17600,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 95,
                        ["timestamp"] = 1633282075,
                        ["quant"] = 16,
                        ["id"] = "1692537631",
                        ["itemLink"] = 1088,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [116172] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Nord Bed, Sleigh",
                ["oldestTime"] = 1632876454,
                ["wasAltered"] = true,
                ["newestTime"] = 1632876454,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 144,
                        ["wasKiosk"] = false,
                        ["seller"] = 100,
                        ["timestamp"] = 1632876454,
                        ["quant"] = 1,
                        ["id"] = "1689356591",
                        ["itemLink"] = 3426,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [176128] = 
        {
            ["1:0:2:44:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_belt_heavy.dds",
                ["itemDesc"] = "Companion's Girdle",
                ["oldestTime"] = 1633271493,
                ["wasAltered"] = true,
                ["newestTime"] = 1633271493,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1882,
                        ["wasKiosk"] = true,
                        ["seller"] = 530,
                        ["timestamp"] = 1633271493,
                        ["quant"] = 1,
                        ["id"] = "1692420791",
                        ["itemLink"] = 2672,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine heavy apparel waist prolific",
            },
        },
        [129668] = 
        {
            ["50:16:4:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_dagger_a.dds",
                ["itemDesc"] = "Dagger of the Pariah",
                ["oldestTime"] = 1633269643,
                ["wasAltered"] = true,
                ["newestTime"] = 1633269643,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4999,
                        ["guild"] = 1,
                        ["buyer"] = 1360,
                        ["wasKiosk"] = true,
                        ["seller"] = 163,
                        ["timestamp"] = 1633269643,
                        ["quant"] = 1,
                        ["id"] = "1692401041",
                        ["itemLink"] = 2661,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set mark of the pariah dagger one-handed charged",
            },
        },
        [176591] = 
        {
            ["1:0:3:47:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_boots_medium.dds",
                ["itemDesc"] = "Companion's Boots",
                ["oldestTime"] = 1633137519,
                ["wasAltered"] = true,
                ["newestTime"] = 1633209476,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 48888,
                        ["guild"] = 1,
                        ["buyer"] = 434,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633137519,
                        ["quant"] = 1,
                        ["id"] = "1691266543",
                        ["itemLink"] = 1581,
                    },
                    [2] = 
                    {
                        ["price"] = 48888,
                        ["guild"] = 1,
                        ["buyer"] = 1550,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633209476,
                        ["quant"] = 1,
                        ["id"] = "1691899793",
                        ["itemLink"] = 1581,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior medium apparel feet aggressive",
            },
        },
        [160976] = 
        {
            ["50:16:4:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_greyhostmed_chest_a.dds",
                ["itemDesc"] = "Venomous Jack",
                ["oldestTime"] = 1633105609,
                ["wasAltered"] = true,
                ["newestTime"] = 1633105609,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3999,
                        ["guild"] = 1,
                        ["buyer"] = 965,
                        ["wasKiosk"] = true,
                        ["seller"] = 966,
                        ["timestamp"] = 1633105609,
                        ["quant"] = 1,
                        ["id"] = "1691006373",
                        ["itemLink"] = 1297,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set venomous smite chest training",
            },
        },
        [180433] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_2hhammer_a.dds",
                ["itemDesc"] = "Maul of Dark Convergence",
                ["oldestTime"] = 1633125847,
                ["wasAltered"] = true,
                ["newestTime"] = 1633125847,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5423,
                        ["guild"] = 1,
                        ["buyer"] = 1084,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633125847,
                        ["quant"] = 1,
                        ["id"] = "1691148683",
                        ["itemLink"] = 1484,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set dark convergence mace two-handed infused",
            },
        },
        [149121] = 
        {
            ["50:16:4:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_hammer_a.dds",
                ["itemDesc"] = "Undertaker's Mace",
                ["oldestTime"] = 1633086566,
                ["wasAltered"] = true,
                ["newestTime"] = 1633086566,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 137,
                        ["wasKiosk"] = true,
                        ["seller"] = 872,
                        ["timestamp"] = 1633086566,
                        ["quant"] = 1,
                        ["id"] = "1690867107",
                        ["itemLink"] = 1222,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set call of the undertaker mace one-handed defending",
            },
        },
        [132963] = 
        {
            ["50:16:4:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_apostle_staff_a.dds",
                ["itemDesc"] = "Mad Tinkerer's Inferno Staff",
                ["oldestTime"] = 1633268325,
                ["wasAltered"] = true,
                ["newestTime"] = 1633268325,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1999,
                        ["guild"] = 1,
                        ["buyer"] = 1868,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633268325,
                        ["quant"] = 1,
                        ["id"] = "1692388097",
                        ["itemLink"] = 2658,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set mad tinkerer flame staff two-handed charged",
            },
        },
        [176596] = 
        {
            ["1:0:3:47:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_belt_heavy.dds",
                ["itemDesc"] = "Companion's Girdle",
                ["oldestTime"] = 1633166593,
                ["wasAltered"] = true,
                ["newestTime"] = 1633166593,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1325,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633166593,
                        ["quant"] = 1,
                        ["id"] = "1691503347",
                        ["itemLink"] = 1863,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior heavy apparel waist aggressive",
            },
        },
        [139221] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_fur_bench001.dds",
                ["itemDesc"] = "Alinor Bench, Verdant",
                ["oldestTime"] = 1633040059,
                ["wasAltered"] = true,
                ["newestTime"] = 1633040059,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 33000,
                        ["guild"] = 1,
                        ["buyer"] = 621,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633040059,
                        ["quant"] = 1,
                        ["id"] = "1690513481",
                        ["itemLink"] = 788,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [77063] = 
        {
            ["50:16:2:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_minotaur_bow_a.dds",
                ["itemDesc"] = "Bow of Morihaus",
                ["oldestTime"] = 1632520137,
                ["wasAltered"] = true,
                ["newestTime"] = 1632520137,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 234,
                        ["guild"] = 2,
                        ["buyer"] = 114,
                        ["wasKiosk"] = false,
                        ["seller"] = 116,
                        ["timestamp"] = 1632520137,
                        ["quant"] = 1,
                        ["id"] = "1686354523",
                        ["itemLink"] = 89,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set hide of morihaus bow two-handed training",
            },
        },
        [167944] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 95: Nighthollow Axes",
                ["oldestTime"] = 1633107972,
                ["wasAltered"] = true,
                ["newestTime"] = 1633107972,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 973,
                        ["wasKiosk"] = true,
                        ["seller"] = 505,
                        ["timestamp"] = 1633107972,
                        ["quant"] = 1,
                        ["id"] = "1691021853",
                        ["itemLink"] = 1304,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [156571] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_humanoid_daedra_fire_salts.dds",
                ["itemDesc"] = "Gilding Salts",
                ["oldestTime"] = 1633019604,
                ["wasAltered"] = true,
                ["newestTime"] = 1633019604,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 198,
                        ["guild"] = 1,
                        ["buyer"] = 503,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633019604,
                        ["quant"] = 2,
                        ["id"] = "1690363037",
                        ["itemLink"] = 576,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [43614] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Alik'r Treasure Map II",
                ["oldestTime"] = 1633066209,
                ["wasAltered"] = true,
                ["newestTime"] = 1633066209,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 420,
                        ["guild"] = 1,
                        ["buyer"] = 823,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633066209,
                        ["quant"] = 1,
                        ["id"] = "1690757735",
                        ["itemLink"] = 1066,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [176699] = 
        {
            ["1:0:2:48:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_boots_medium.dds",
                ["itemDesc"] = "Companion's Boots",
                ["oldestTime"] = 1633247075,
                ["wasAltered"] = true,
                ["newestTime"] = 1633247075,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2040,
                        ["guild"] = 1,
                        ["buyer"] = 1803,
                        ["wasKiosk"] = true,
                        ["seller"] = 1161,
                        ["timestamp"] = 1633247075,
                        ["quant"] = 1,
                        ["id"] = "1692249923",
                        ["itemLink"] = 2581,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine medium apparel feet soothing",
            },
        },
        [159451] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_col_inc_dbhtapestryakatoshhourglasssm001.dds",
                ["itemDesc"] = "Hourglass Banner, Akatosh",
                ["oldestTime"] = 1632851191,
                ["wasAltered"] = true,
                ["newestTime"] = 1632851191,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20999,
                        ["guild"] = 1,
                        ["buyer"] = 175,
                        ["wasKiosk"] = false,
                        ["seller"] = 290,
                        ["timestamp"] = 1632851191,
                        ["quant"] = 1,
                        ["id"] = "1689153089",
                        ["itemLink"] = 3242,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings parlor",
            },
        },
        [132719] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_apostle_staff_a.dds",
                ["itemDesc"] = "Livewire Restoration Staff",
                ["oldestTime"] = 1633233932,
                ["wasAltered"] = true,
                ["newestTime"] = 1633233932,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 899,
                        ["guild"] = 1,
                        ["buyer"] = 1370,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633233932,
                        ["quant"] = 1,
                        ["id"] = "1692153541",
                        ["itemLink"] = 2460,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set livewire healing staff two-handed precise",
            },
        },
        [95453] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of Martial Knowledge",
                ["oldestTime"] = 1633065271,
                ["wasAltered"] = true,
                ["newestTime"] = 1633065271,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 818,
                        ["wasKiosk"] = true,
                        ["seller"] = 256,
                        ["timestamp"] = 1633065271,
                        ["quant"] = 1,
                        ["id"] = "1690749493",
                        ["itemLink"] = 1059,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set way of martial knowledge neck arcane",
            },
            ["50:16:2:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of Martial Knowledge",
                ["oldestTime"] = 1632994947,
                ["wasAltered"] = true,
                ["newestTime"] = 1632994947,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1632994947,
                        ["quant"] = 1,
                        ["id"] = "1690210067",
                        ["itemLink"] = 377,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set way of martial knowledge neck arcane",
            },
        },
        [102110] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_draugr_medium_legs_a.dds",
                ["itemDesc"] = "Stygian Guards",
                ["oldestTime"] = 1632714204,
                ["wasAltered"] = true,
                ["newestTime"] = 1632714204,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 2,
                        ["buyer"] = 129,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1632714204,
                        ["quant"] = 1,
                        ["id"] = "1688086653",
                        ["itemLink"] = 114,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set stygian legs divines",
            },
        },
        [139546] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Alinor Bench, Marble",
                ["oldestTime"] = 1632971350,
                ["wasAltered"] = true,
                ["newestTime"] = 1633207811,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 181,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632971350,
                        ["quant"] = 1,
                        ["id"] = "1690070391",
                        ["itemLink"] = 195,
                    },
                    [2] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1537,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633207811,
                        ["quant"] = 1,
                        ["id"] = "1691880099",
                        ["itemLink"] = 195,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [121518] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_buoyant_armiger_r2.dds",
                ["itemDesc"] = "Volcanic Viridian",
                ["oldestTime"] = 1633121507,
                ["wasAltered"] = true,
                ["newestTime"] = 1633121507,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1054,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633121507,
                        ["quant"] = 3,
                        ["id"] = "1691115459",
                        ["itemLink"] = 1438,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [137953] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_leather_phlegm.dds",
                ["itemDesc"] = "Culanda Lacquer",
                ["oldestTime"] = 1633056219,
                ["wasAltered"] = true,
                ["newestTime"] = 1633205148,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13600,
                        ["guild"] = 1,
                        ["buyer"] = 460,
                        ["wasKiosk"] = true,
                        ["seller"] = 732,
                        ["timestamp"] = 1633056219,
                        ["quant"] = 4,
                        ["id"] = "1690667051",
                        ["itemLink"] = 952,
                    },
                    [2] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 271,
                        ["timestamp"] = 1633185375,
                        ["quant"] = 5,
                        ["id"] = "1691633315",
                        ["itemLink"] = 952,
                    },
                    [3] = 
                    {
                        ["price"] = 12354,
                        ["guild"] = 1,
                        ["buyer"] = 1520,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633205148,
                        ["quant"] = 3,
                        ["id"] = "1691843887",
                        ["itemLink"] = 952,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [167363] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Solitude Post, Stone Wall",
                ["oldestTime"] = 1633222371,
                ["wasAltered"] = true,
                ["newestTime"] = 1633222371,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3899,
                        ["guild"] = 1,
                        ["buyer"] = 1619,
                        ["wasKiosk"] = true,
                        ["seller"] = 494,
                        ["timestamp"] = 1633222371,
                        ["quant"] = 1,
                        ["id"] = "1692036091",
                        ["itemLink"] = 2357,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [180707] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_2hsword_a.dds",
                ["itemDesc"] = "Plaguebreak Greatsword",
                ["oldestTime"] = 1633273652,
                ["wasAltered"] = true,
                ["newestTime"] = 1633273652,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1893,
                        ["wasKiosk"] = true,
                        ["seller"] = 43,
                        ["timestamp"] = 1633273652,
                        ["quant"] = 1,
                        ["id"] = "1692445879",
                        ["itemLink"] = 2688,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set plaguebreak sword two-handed charged",
            },
        },
        [172260] = 
        {
            ["50:16:2:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_legs_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Guards",
                ["oldestTime"] = 1633073614,
                ["wasAltered"] = true,
                ["newestTime"] = 1633073614,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 225,
                        ["guild"] = 1,
                        ["buyer"] = 855,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633073614,
                        ["quant"] = 1,
                        ["id"] = "1690801447",
                        ["itemLink"] = 1102,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set deadlands assassin legs sturdy",
            },
        },
        [130021] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 52: Redoran Shields",
                ["oldestTime"] = 1633171415,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182079,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14999,
                        ["guild"] = 1,
                        ["buyer"] = 1340,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633171415,
                        ["quant"] = 1,
                        ["id"] = "1691527401",
                        ["itemLink"] = 1883,
                    },
                    [2] = 
                    {
                        ["price"] = 19000,
                        ["guild"] = 1,
                        ["buyer"] = 1376,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633182079,
                        ["quant"] = 1,
                        ["id"] = "1691604481",
                        ["itemLink"] = 1883,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [180454] = 
        {
            ["50:16:3:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_2hhammer_a.dds",
                ["itemDesc"] = "Maul of Dark Convergence",
                ["oldestTime"] = 1632838001,
                ["wasAltered"] = true,
                ["newestTime"] = 1632838001,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8972,
                        ["guild"] = 1,
                        ["buyer"] = 718,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1632838001,
                        ["quant"] = 1,
                        ["id"] = "1689047167",
                        ["itemLink"] = 3117,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set dark convergence mace two-handed powered",
            },
        },
        [45359] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_medium_head_d.dds",
                ["itemDesc"] = "Rubedo Leather Helmet",
                ["oldestTime"] = 1632840314,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186023,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1633009343,
                        ["quant"] = 1,
                        ["id"] = "1690285195",
                        ["itemLink"] = 455,
                    },
                    [2] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1633009343,
                        ["quant"] = 1,
                        ["id"] = "1690285197",
                        ["itemLink"] = 456,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009362,
                        ["quant"] = 1,
                        ["id"] = "1690285403",
                        ["itemLink"] = 476,
                    },
                    [4] = 
                    {
                        ["price"] = 194,
                        ["guild"] = 1,
                        ["buyer"] = 456,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1633011728,
                        ["quant"] = 1,
                        ["id"] = "1690302329",
                        ["itemLink"] = 519,
                    },
                    [5] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633023004,
                        ["quant"] = 1,
                        ["id"] = "1690390617",
                        ["itemLink"] = 476,
                    },
                    [6] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084100,
                        ["quant"] = 1,
                        ["id"] = "1690855019",
                        ["itemLink"] = 1184,
                    },
                    [7] = 
                    {
                        ["price"] = 141,
                        ["guild"] = 1,
                        ["buyer"] = 1150,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633136220,
                        ["quant"] = 1,
                        ["id"] = "1691255377",
                        ["itemLink"] = 519,
                    },
                    [8] = 
                    {
                        ["price"] = 141,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633146928,
                        ["quant"] = 1,
                        ["id"] = "1691365219",
                        ["itemLink"] = 1659,
                    },
                    [9] = 
                    {
                        ["price"] = 242,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633185979,
                        ["quant"] = 1,
                        ["id"] = "1691640481",
                        ["itemLink"] = 2044,
                    },
                    [10] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1633185984,
                        ["quant"] = 1,
                        ["id"] = "1691640521",
                        ["itemLink"] = 2046,
                    },
                    [11] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1633186023,
                        ["quant"] = 1,
                        ["id"] = "1691640901",
                        ["itemLink"] = 519,
                    },
                    [12] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632840314,
                        ["quant"] = 1,
                        ["id"] = "1689062307",
                        ["itemLink"] = 2044,
                    },
                    [13] = 
                    {
                        ["price"] = 141,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 240,
                        ["timestamp"] = 1632885640,
                        ["quant"] = 1,
                        ["id"] = "1689459499",
                        ["itemLink"] = 476,
                    },
                    [14] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1632885641,
                        ["quant"] = 1,
                        ["id"] = "1689459509",
                        ["itemLink"] = 456,
                    },
                    [15] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1632885642,
                        ["quant"] = 1,
                        ["id"] = "1689459511",
                        ["itemLink"] = 1659,
                    },
                    [16] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1632885643,
                        ["quant"] = 1,
                        ["id"] = "1689459513",
                        ["itemLink"] = 3507,
                    },
                    [17] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1632885644,
                        ["quant"] = 1,
                        ["id"] = "1689459521",
                        ["itemLink"] = 3508,
                    },
                    [18] = 
                    {
                        ["price"] = 181,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 108,
                        ["timestamp"] = 1632922800,
                        ["quant"] = 1,
                        ["id"] = "1689672051",
                        ["itemLink"] = 1184,
                    },
                    [19] = 
                    {
                        ["price"] = 322,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1632956411,
                        ["quant"] = 1,
                        ["id"] = "1689931725",
                        ["itemLink"] = 1659,
                    },
                    [20] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632956414,
                        ["quant"] = 1,
                        ["id"] = "1689931771",
                        ["itemLink"] = 3508,
                    },
                },
                ["totalCount"] = 20,
                ["itemAdderText"] = "cp160 white normal medium apparel head intricate",
            },
            ["47:0:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_medium_head_d.dds",
                ["itemDesc"] = "Fell Helmet",
                ["oldestTime"] = 1633059426,
                ["wasAltered"] = true,
                ["newestTime"] = 1633059426,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99,
                        ["guild"] = 1,
                        ["buyer"] = 780,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633059426,
                        ["quant"] = 1,
                        ["id"] = "1690704647",
                        ["itemLink"] = 998,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr47 white normal medium apparel head intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ashlanderv_medium_head_a.dds",
                ["itemDesc"] = "Rubedo Leather Helmet",
                ["oldestTime"] = 1632839966,
                ["wasAltered"] = true,
                ["newestTime"] = 1633009365,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009365,
                        ["quant"] = 1,
                        ["id"] = "1690285445",
                        ["itemLink"] = 480,
                    },
                    [2] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632839966,
                        ["quant"] = 1,
                        ["id"] = "1689060189",
                        ["itemLink"] = 3138,
                    },
                    [3] = 
                    {
                        ["price"] = 190,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632885641,
                        ["quant"] = 1,
                        ["id"] = "1689459505",
                        ["itemLink"] = 3138,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp150 white normal medium apparel head intricate",
            },
        },
        [99304] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_medium_waist_d.dds",
                ["itemDesc"] = "Sword-Singer's Belt",
                ["oldestTime"] = 1633023029,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023029,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 599,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633023029,
                        ["quant"] = 1,
                        ["id"] = "1690390895",
                        ["itemLink"] = 653,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set sword-singer waist infused",
            },
        },
        [64489] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_colossus_iron.dds",
                ["itemDesc"] = "Rubedite Ingot",
                ["oldestTime"] = 1632587343,
                ["wasAltered"] = true,
                ["newestTime"] = 1633303960,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 2,
                        ["buyer"] = 120,
                        ["wasKiosk"] = false,
                        ["seller"] = 121,
                        ["timestamp"] = 1632587343,
                        ["quant"] = 200,
                        ["id"] = "1686903033",
                        ["itemLink"] = 97,
                    },
                    [2] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 2,
                        ["buyer"] = 120,
                        ["wasKiosk"] = false,
                        ["seller"] = 121,
                        ["timestamp"] = 1632587346,
                        ["quant"] = 200,
                        ["id"] = "1686903077",
                        ["itemLink"] = 97,
                    },
                    [3] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 2,
                        ["buyer"] = 120,
                        ["wasKiosk"] = false,
                        ["seller"] = 121,
                        ["timestamp"] = 1632587348,
                        ["quant"] = 200,
                        ["id"] = "1686903117",
                        ["itemLink"] = 97,
                    },
                    [4] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 2,
                        ["buyer"] = 120,
                        ["wasKiosk"] = false,
                        ["seller"] = 121,
                        ["timestamp"] = 1632587350,
                        ["quant"] = 200,
                        ["id"] = "1686903165",
                        ["itemLink"] = 97,
                    },
                    [5] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 265,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632981262,
                        ["quant"] = 200,
                        ["id"] = "1690137929",
                        ["itemLink"] = 97,
                    },
                    [6] = 
                    {
                        ["price"] = 1970,
                        ["guild"] = 1,
                        ["buyer"] = 429,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1633007295,
                        ["quant"] = 200,
                        ["id"] = "1690273001",
                        ["itemLink"] = 97,
                    },
                    [7] = 
                    {
                        ["price"] = 1828,
                        ["guild"] = 1,
                        ["buyer"] = 833,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633068593,
                        ["quant"] = 200,
                        ["id"] = "1690770433",
                        ["itemLink"] = 97,
                    },
                    [8] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 484,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633085973,
                        ["quant"] = 200,
                        ["id"] = "1690863455",
                        ["itemLink"] = 97,
                    },
                    [9] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 484,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633086002,
                        ["quant"] = 200,
                        ["id"] = "1690863599",
                        ["itemLink"] = 97,
                    },
                    [10] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 963,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633103999,
                        ["quant"] = 200,
                        ["id"] = "1690991705",
                        ["itemLink"] = 97,
                    },
                    [11] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 963,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633104000,
                        ["quant"] = 200,
                        ["id"] = "1690991721",
                        ["itemLink"] = 97,
                    },
                    [12] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 963,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633104002,
                        ["quant"] = 200,
                        ["id"] = "1690991729",
                        ["itemLink"] = 97,
                    },
                    [13] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633135287,
                        ["quant"] = 200,
                        ["id"] = "1691245511",
                        ["itemLink"] = 97,
                    },
                    [14] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633135289,
                        ["quant"] = 200,
                        ["id"] = "1691245535",
                        ["itemLink"] = 97,
                    },
                    [15] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633135289,
                        ["quant"] = 200,
                        ["id"] = "1691245541",
                        ["itemLink"] = 97,
                    },
                    [16] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 1139,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633135290,
                        ["quant"] = 200,
                        ["id"] = "1691245561",
                        ["itemLink"] = 97,
                    },
                    [17] = 
                    {
                        ["price"] = 1828,
                        ["guild"] = 1,
                        ["buyer"] = 1253,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633149844,
                        ["quant"] = 200,
                        ["id"] = "1691389379",
                        ["itemLink"] = 97,
                    },
                    [18] = 
                    {
                        ["price"] = 1828,
                        ["guild"] = 1,
                        ["buyer"] = 1253,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633149845,
                        ["quant"] = 200,
                        ["id"] = "1691389381",
                        ["itemLink"] = 97,
                    },
                    [19] = 
                    {
                        ["price"] = 1828,
                        ["guild"] = 1,
                        ["buyer"] = 1253,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633149848,
                        ["quant"] = 200,
                        ["id"] = "1691389409",
                        ["itemLink"] = 97,
                    },
                    [20] = 
                    {
                        ["price"] = 1828,
                        ["guild"] = 1,
                        ["buyer"] = 1253,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633149848,
                        ["quant"] = 200,
                        ["id"] = "1691389417",
                        ["itemLink"] = 97,
                    },
                    [21] = 
                    {
                        ["price"] = 1828,
                        ["guild"] = 1,
                        ["buyer"] = 1253,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633149849,
                        ["quant"] = 200,
                        ["id"] = "1691389423",
                        ["itemLink"] = 97,
                    },
                    [22] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 1277,
                        ["wasKiosk"] = true,
                        ["seller"] = 944,
                        ["timestamp"] = 1633154970,
                        ["quant"] = 200,
                        ["id"] = "1691431189",
                        ["itemLink"] = 97,
                    },
                    [23] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 1277,
                        ["wasKiosk"] = true,
                        ["seller"] = 944,
                        ["timestamp"] = 1633154972,
                        ["quant"] = 200,
                        ["id"] = "1691431211",
                        ["itemLink"] = 97,
                    },
                    [24] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 1444,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633194669,
                        ["quant"] = 200,
                        ["id"] = "1691739735",
                        ["itemLink"] = 97,
                    },
                    [25] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 1444,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633194671,
                        ["quant"] = 200,
                        ["id"] = "1691739743",
                        ["itemLink"] = 97,
                    },
                    [26] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 1444,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633194673,
                        ["quant"] = 200,
                        ["id"] = "1691739755",
                        ["itemLink"] = 97,
                    },
                    [27] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 1444,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1633195340,
                        ["quant"] = 200,
                        ["id"] = "1691745191",
                        ["itemLink"] = 97,
                    },
                    [28] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 1444,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1633195342,
                        ["quant"] = 200,
                        ["id"] = "1691745211",
                        ["itemLink"] = 97,
                    },
                    [29] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 1444,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1633195344,
                        ["quant"] = 200,
                        ["id"] = "1691745233",
                        ["itemLink"] = 97,
                    },
                    [30] = 
                    {
                        ["price"] = 1970,
                        ["guild"] = 1,
                        ["buyer"] = 1444,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1633195346,
                        ["quant"] = 200,
                        ["id"] = "1691745263",
                        ["itemLink"] = 97,
                    },
                    [31] = 
                    {
                        ["price"] = 1970,
                        ["guild"] = 1,
                        ["buyer"] = 1444,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1633195348,
                        ["quant"] = 200,
                        ["id"] = "1691745275",
                        ["itemLink"] = 97,
                    },
                    [32] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633219730,
                        ["quant"] = 200,
                        ["id"] = "1692008961",
                        ["itemLink"] = 97,
                    },
                    [33] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633219730,
                        ["quant"] = 200,
                        ["id"] = "1692008975",
                        ["itemLink"] = 97,
                    },
                    [34] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633219731,
                        ["quant"] = 200,
                        ["id"] = "1692008981",
                        ["itemLink"] = 97,
                    },
                    [35] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633219732,
                        ["quant"] = 200,
                        ["id"] = "1692008991",
                        ["itemLink"] = 97,
                    },
                    [36] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633219735,
                        ["quant"] = 200,
                        ["id"] = "1692009021",
                        ["itemLink"] = 97,
                    },
                    [37] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633219736,
                        ["quant"] = 200,
                        ["id"] = "1692009035",
                        ["itemLink"] = 97,
                    },
                    [38] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633219740,
                        ["quant"] = 200,
                        ["id"] = "1692009085",
                        ["itemLink"] = 97,
                    },
                    [39] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1664,
                        ["wasKiosk"] = false,
                        ["seller"] = 75,
                        ["timestamp"] = 1633227782,
                        ["quant"] = 200,
                        ["id"] = "1692093645",
                        ["itemLink"] = 97,
                    },
                    [40] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1664,
                        ["wasKiosk"] = false,
                        ["seller"] = 75,
                        ["timestamp"] = 1633227784,
                        ["quant"] = 200,
                        ["id"] = "1692093677",
                        ["itemLink"] = 97,
                    },
                    [41] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1855,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633265801,
                        ["quant"] = 200,
                        ["id"] = "1692366813",
                        ["itemLink"] = 97,
                    },
                    [42] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1855,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633265810,
                        ["quant"] = 200,
                        ["id"] = "1692366935",
                        ["itemLink"] = 97,
                    },
                    [43] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633271252,
                        ["quant"] = 200,
                        ["id"] = "1692419157",
                        ["itemLink"] = 97,
                    },
                    [44] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633271253,
                        ["quant"] = 200,
                        ["id"] = "1692419165",
                        ["itemLink"] = 97,
                    },
                    [45] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633271254,
                        ["quant"] = 200,
                        ["id"] = "1692419169",
                        ["itemLink"] = 97,
                    },
                    [46] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633271255,
                        ["quant"] = 200,
                        ["id"] = "1692419175",
                        ["itemLink"] = 97,
                    },
                    [47] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633271255,
                        ["quant"] = 200,
                        ["id"] = "1692419179",
                        ["itemLink"] = 97,
                    },
                    [48] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633271256,
                        ["quant"] = 200,
                        ["id"] = "1692419193",
                        ["itemLink"] = 97,
                    },
                    [49] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633271257,
                        ["quant"] = 200,
                        ["id"] = "1692419201",
                        ["itemLink"] = 97,
                    },
                    [50] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633271258,
                        ["quant"] = 200,
                        ["id"] = "1692419207",
                        ["itemLink"] = 97,
                    },
                    [51] = 
                    {
                        ["price"] = 1970,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1633271259,
                        ["quant"] = 200,
                        ["id"] = "1692419219",
                        ["itemLink"] = 97,
                    },
                    [52] = 
                    {
                        ["price"] = 1970,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1633271260,
                        ["quant"] = 200,
                        ["id"] = "1692419231",
                        ["itemLink"] = 97,
                    },
                    [53] = 
                    {
                        ["price"] = 1970,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1633271260,
                        ["quant"] = 200,
                        ["id"] = "1692419237",
                        ["itemLink"] = 97,
                    },
                    [54] = 
                    {
                        ["price"] = 1970,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1633271261,
                        ["quant"] = 200,
                        ["id"] = "1692419241",
                        ["itemLink"] = 97,
                    },
                    [55] = 
                    {
                        ["price"] = 1970,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1633271262,
                        ["quant"] = 200,
                        ["id"] = "1692419249",
                        ["itemLink"] = 97,
                    },
                    [56] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1633271263,
                        ["quant"] = 200,
                        ["id"] = "1692419251",
                        ["itemLink"] = 97,
                    },
                    [57] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1633271264,
                        ["quant"] = 200,
                        ["id"] = "1692419257",
                        ["itemLink"] = 97,
                    },
                    [58] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633271264,
                        ["quant"] = 200,
                        ["id"] = "1692419263",
                        ["itemLink"] = 97,
                    },
                    [59] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633271265,
                        ["quant"] = 200,
                        ["id"] = "1692419269",
                        ["itemLink"] = 97,
                    },
                    [60] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633271266,
                        ["quant"] = 200,
                        ["id"] = "1692419273",
                        ["itemLink"] = 97,
                    },
                    [61] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633271267,
                        ["quant"] = 200,
                        ["id"] = "1692419279",
                        ["itemLink"] = 97,
                    },
                    [62] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633271268,
                        ["quant"] = 200,
                        ["id"] = "1692419285",
                        ["itemLink"] = 97,
                    },
                    [63] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633271268,
                        ["quant"] = 200,
                        ["id"] = "1692419291",
                        ["itemLink"] = 97,
                    },
                    [64] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1633271269,
                        ["quant"] = 200,
                        ["id"] = "1692419297",
                        ["itemLink"] = 97,
                    },
                    [65] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1633271270,
                        ["quant"] = 200,
                        ["id"] = "1692419307",
                        ["itemLink"] = 97,
                    },
                    [66] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1633271271,
                        ["quant"] = 200,
                        ["id"] = "1692419315",
                        ["itemLink"] = 97,
                    },
                    [67] = 
                    {
                        ["price"] = 2324,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633271272,
                        ["quant"] = 200,
                        ["id"] = "1692419323",
                        ["itemLink"] = 97,
                    },
                    [68] = 
                    {
                        ["price"] = 2324,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633271272,
                        ["quant"] = 200,
                        ["id"] = "1692419329",
                        ["itemLink"] = 97,
                    },
                    [69] = 
                    {
                        ["price"] = 2326,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633271273,
                        ["quant"] = 200,
                        ["id"] = "1692419339",
                        ["itemLink"] = 97,
                    },
                    [70] = 
                    {
                        ["price"] = 2326,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633271274,
                        ["quant"] = 200,
                        ["id"] = "1692419353",
                        ["itemLink"] = 97,
                    },
                    [71] = 
                    {
                        ["price"] = 2326,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633271275,
                        ["quant"] = 200,
                        ["id"] = "1692419369",
                        ["itemLink"] = 97,
                    },
                    [72] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1633271275,
                        ["quant"] = 200,
                        ["id"] = "1692419379",
                        ["itemLink"] = 97,
                    },
                    [73] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1633271276,
                        ["quant"] = 200,
                        ["id"] = "1692419391",
                        ["itemLink"] = 97,
                    },
                    [74] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633271277,
                        ["quant"] = 200,
                        ["id"] = "1692419403",
                        ["itemLink"] = 97,
                    },
                    [75] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2053,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633303954,
                        ["quant"] = 200,
                        ["id"] = "1692779741",
                        ["itemLink"] = 97,
                    },
                    [76] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2053,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633303956,
                        ["quant"] = 200,
                        ["id"] = "1692779749",
                        ["itemLink"] = 97,
                    },
                    [77] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2053,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633303957,
                        ["quant"] = 200,
                        ["id"] = "1692779763",
                        ["itemLink"] = 97,
                    },
                    [78] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2053,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633303959,
                        ["quant"] = 200,
                        ["id"] = "1692779785",
                        ["itemLink"] = 97,
                    },
                    [79] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2053,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633303960,
                        ["quant"] = 200,
                        ["id"] = "1692779795",
                        ["itemLink"] = 97,
                    },
                    [80] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1632816831,
                        ["quant"] = 200,
                        ["id"] = "1688929333",
                        ["itemLink"] = 97,
                    },
                    [81] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1632816831,
                        ["quant"] = 200,
                        ["id"] = "1688929343",
                        ["itemLink"] = 97,
                    },
                    [82] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1632816832,
                        ["quant"] = 200,
                        ["id"] = "1688929353",
                        ["itemLink"] = 97,
                    },
                    [83] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1632816832,
                        ["quant"] = 200,
                        ["id"] = "1688929361",
                        ["itemLink"] = 97,
                    },
                    [84] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1632816834,
                        ["quant"] = 200,
                        ["id"] = "1688929381",
                        ["itemLink"] = 97,
                    },
                    [85] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1632816835,
                        ["quant"] = 200,
                        ["id"] = "1688929397",
                        ["itemLink"] = 97,
                    },
                    [86] = 
                    {
                        ["price"] = 2335,
                        ["guild"] = 1,
                        ["buyer"] = 2243,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632859228,
                        ["quant"] = 200,
                        ["id"] = "1689224407",
                        ["itemLink"] = 97,
                    },
                    [87] = 
                    {
                        ["price"] = 2335,
                        ["guild"] = 1,
                        ["buyer"] = 2243,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632859229,
                        ["quant"] = 200,
                        ["id"] = "1689224419",
                        ["itemLink"] = 97,
                    },
                    [88] = 
                    {
                        ["price"] = 2324,
                        ["guild"] = 1,
                        ["buyer"] = 2332,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632877011,
                        ["quant"] = 200,
                        ["id"] = "1689361919",
                        ["itemLink"] = 97,
                    },
                },
                ["totalCount"] = 88,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [176483] = 
        {
            ["1:0:4:46:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_boots_medium.dds",
                ["itemDesc"] = "Companion's Boots",
                ["oldestTime"] = 1633136945,
                ["wasAltered"] = true,
                ["newestTime"] = 1633136945,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 65090,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633136945,
                        ["quant"] = 1,
                        ["id"] = "1691261917",
                        ["itemLink"] = 1577,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic medium apparel feet shattering",
            },
        },
        [100587] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Spriggan's Ring",
                ["oldestTime"] = 1632895699,
                ["wasAltered"] = true,
                ["newestTime"] = 1632895699,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2213,
                        ["guild"] = 1,
                        ["buyer"] = 2433,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1632895699,
                        ["quant"] = 1,
                        ["id"] = "1689533343",
                        ["itemLink"] = 3563,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set spriggan's thorns ring robust",
            },
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Spriggan's Ring",
                ["oldestTime"] = 1632858174,
                ["wasAltered"] = true,
                ["newestTime"] = 1633199640,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1481,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1633199640,
                        ["quant"] = 1,
                        ["id"] = "1691785823",
                        ["itemLink"] = 2181,
                    },
                    [2] = 
                    {
                        ["price"] = 22507,
                        ["guild"] = 1,
                        ["buyer"] = 2242,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1632858174,
                        ["quant"] = 1,
                        ["id"] = "1689215663",
                        ["itemLink"] = 2181,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set spriggan's thorns ring robust",
            },
        },
        [175852] = 
        {
            ["1:0:3:43:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_belt_medium.dds",
                ["itemDesc"] = "Companion's Belt",
                ["oldestTime"] = 1632861102,
                ["wasAltered"] = true,
                ["newestTime"] = 1632861102,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 2245,
                        ["wasKiosk"] = false,
                        ["seller"] = 8,
                        ["timestamp"] = 1632861102,
                        ["quant"] = 1,
                        ["id"] = "1689238967",
                        ["itemLink"] = 3298,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior medium apparel waist quickened",
            },
        },
        [119021] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Orcish Shelf, Short",
                ["oldestTime"] = 1632875174,
                ["wasAltered"] = true,
                ["newestTime"] = 1632875174,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 109,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632875174,
                        ["quant"] = 1,
                        ["id"] = "1689343057",
                        ["itemLink"] = 3413,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [57070] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Fyr's Hyperagonal Potation",
                ["oldestTime"] = 1633052736,
                ["wasAltered"] = true,
                ["newestTime"] = 1633214820,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 136,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633052736,
                        ["quant"] = 1,
                        ["id"] = "1690632439",
                        ["itemLink"] = 908,
                    },
                    [2] = 
                    {
                        ["price"] = 32,
                        ["guild"] = 1,
                        ["buyer"] = 1578,
                        ["wasKiosk"] = true,
                        ["seller"] = 711,
                        ["timestamp"] = 1633214820,
                        ["quant"] = 1,
                        ["id"] = "1691957353",
                        ["itemLink"] = 908,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [96971] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of the Night Mother",
                ["oldestTime"] = 1633163920,
                ["wasAltered"] = true,
                ["newestTime"] = 1633265000,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1700,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 237,
                        ["timestamp"] = 1633163920,
                        ["quant"] = 1,
                        ["id"] = "1691490375",
                        ["itemLink"] = 1817,
                    },
                    [2] = 
                    {
                        ["price"] = 807,
                        ["guild"] = 1,
                        ["buyer"] = 1852,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1633265000,
                        ["quant"] = 1,
                        ["id"] = "1692359059",
                        ["itemLink"] = 1817,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set night mother's embrace neck robust",
            },
            ["50:16:2:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of the Night Mother",
                ["oldestTime"] = 1632994942,
                ["wasAltered"] = true,
                ["newestTime"] = 1632994942,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 475,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1632994942,
                        ["quant"] = 1,
                        ["id"] = "1690210051",
                        ["itemLink"] = 375,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set night mother's embrace neck robust",
            },
        },
        [178462] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_rok_els_moonrock001.dds",
                ["itemDesc"] = "Inscribed Shard",
                ["oldestTime"] = 1632894832,
                ["wasAltered"] = true,
                ["newestTime"] = 1633246032,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 374,
                        ["timestamp"] = 1633098340,
                        ["quant"] = 5,
                        ["id"] = "1690944581",
                        ["itemLink"] = 1272,
                    },
                    [2] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633102891,
                        ["quant"] = 4,
                        ["id"] = "1690982807",
                        ["itemLink"] = 1272,
                    },
                    [3] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 374,
                        ["timestamp"] = 1633113919,
                        ["quant"] = 1,
                        ["id"] = "1691065149",
                        ["itemLink"] = 1272,
                    },
                    [4] = 
                    {
                        ["price"] = 71104,
                        ["guild"] = 1,
                        ["buyer"] = 1024,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633116144,
                        ["quant"] = 8,
                        ["id"] = "1691079745",
                        ["itemLink"] = 1272,
                    },
                    [5] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1544,
                        ["wasKiosk"] = true,
                        ["seller"] = 1450,
                        ["timestamp"] = 1633209226,
                        ["quant"] = 1,
                        ["id"] = "1691897095",
                        ["itemLink"] = 1272,
                    },
                    [6] = 
                    {
                        ["price"] = 8999,
                        ["guild"] = 1,
                        ["buyer"] = 1544,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633209227,
                        ["quant"] = 1,
                        ["id"] = "1691897103",
                        ["itemLink"] = 1272,
                    },
                    [7] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1544,
                        ["wasKiosk"] = true,
                        ["seller"] = 43,
                        ["timestamp"] = 1633209228,
                        ["quant"] = 2,
                        ["id"] = "1691897139",
                        ["itemLink"] = 1272,
                    },
                    [8] = 
                    {
                        ["price"] = 95000,
                        ["guild"] = 1,
                        ["buyer"] = 88,
                        ["wasKiosk"] = true,
                        ["seller"] = 775,
                        ["timestamp"] = 1633224866,
                        ["quant"] = 10,
                        ["id"] = "1692062941",
                        ["itemLink"] = 1272,
                    },
                    [9] = 
                    {
                        ["price"] = 47500,
                        ["guild"] = 1,
                        ["buyer"] = 88,
                        ["wasKiosk"] = true,
                        ["seller"] = 775,
                        ["timestamp"] = 1633224883,
                        ["quant"] = 5,
                        ["id"] = "1692063129",
                        ["itemLink"] = 1272,
                    },
                    [10] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633235061,
                        ["quant"] = 1,
                        ["id"] = "1692161017",
                        ["itemLink"] = 1272,
                    },
                    [11] = 
                    {
                        ["price"] = 59400,
                        ["guild"] = 1,
                        ["buyer"] = 1799,
                        ["wasKiosk"] = true,
                        ["seller"] = 775,
                        ["timestamp"] = 1633246032,
                        ["quant"] = 6,
                        ["id"] = "1692243203",
                        ["itemLink"] = 1272,
                    },
                    [12] = 
                    {
                        ["price"] = 100000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 775,
                        ["timestamp"] = 1632894832,
                        ["quant"] = 10,
                        ["id"] = "1689528427",
                        ["itemLink"] = 1272,
                    },
                    [13] = 
                    {
                        ["price"] = 76000,
                        ["guild"] = 1,
                        ["buyer"] = 2479,
                        ["wasKiosk"] = true,
                        ["seller"] = 775,
                        ["timestamp"] = 1632918392,
                        ["quant"] = 8,
                        ["id"] = "1689642307",
                        ["itemLink"] = 1272,
                    },
                },
                ["totalCount"] = 13,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [135141] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_silver_dust.dds",
                ["itemDesc"] = "Silver Dust",
                ["oldestTime"] = 1632884664,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185039,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 35200,
                        ["guild"] = 1,
                        ["buyer"] = 1389,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633185039,
                        ["quant"] = 176,
                        ["id"] = "1691629443",
                        ["itemLink"] = 1983,
                    },
                    [2] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 244,
                        ["timestamp"] = 1632884664,
                        ["quant"] = 200,
                        ["id"] = "1689447979",
                        ["itemLink"] = 1983,
                    },
                    [3] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 244,
                        ["timestamp"] = 1632884665,
                        ["quant"] = 200,
                        ["id"] = "1689447981",
                        ["itemLink"] = 1983,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [122610] = 
        {
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Warrior-Poet's Ring",
                ["oldestTime"] = 1633298143,
                ["wasAltered"] = true,
                ["newestTime"] = 1633298143,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 2032,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1633298143,
                        ["quant"] = 1,
                        ["id"] = "1692722545",
                        ["itemLink"] = 2901,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set warrior-poet ring healthy",
            },
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Warrior-Poet's Ring",
                ["oldestTime"] = 1633281111,
                ["wasAltered"] = true,
                ["newestTime"] = 1633281111,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4300,
                        ["guild"] = 1,
                        ["buyer"] = 1934,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1633281111,
                        ["quant"] = 1,
                        ["id"] = "1692525841",
                        ["itemLink"] = 2739,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set warrior-poet ring healthy",
            },
        },
        [97267] = 
        {
            ["50:16:4:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_dagger_d.dds",
                ["itemDesc"] = "Dagger of a Mother's Sorrow",
                ["oldestTime"] = 1633160269,
                ["wasAltered"] = true,
                ["newestTime"] = 1633160269,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1303,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633160269,
                        ["quant"] = 1,
                        ["id"] = "1691466099",
                        ["itemLink"] = 1789,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set mother's sorrow dagger one-handed precise",
            },
        },
        [101108] = 
        {
            ["50:16:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_staff_d.dds",
                ["itemDesc"] = "Smuggler's Inferno Staff",
                ["oldestTime"] = 1632988917,
                ["wasAltered"] = true,
                ["newestTime"] = 1632988917,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 339,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632988917,
                        ["quant"] = 1,
                        ["id"] = "1690180437",
                        ["itemLink"] = 344,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set skooma smuggler flame staff two-handed training",
            },
        },
        [175967] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing4.dds",
                ["itemDesc"] = "Diagram: Leyawiin Sconce, Gilded Lantern",
                ["oldestTime"] = 1633173604,
                ["wasAltered"] = true,
                ["newestTime"] = 1633173604,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 720000,
                        ["guild"] = 1,
                        ["buyer"] = 824,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633173604,
                        ["quant"] = 1,
                        ["id"] = "1691539021",
                        ["itemLink"] = 1893,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [86006] = 
        {
            ["50:16:2:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Werewolf Hide Ring",
                ["oldestTime"] = 1633249730,
                ["wasAltered"] = true,
                ["newestTime"] = 1633249730,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1813,
                        ["wasKiosk"] = true,
                        ["seller"] = 445,
                        ["timestamp"] = 1633249730,
                        ["quant"] = 1,
                        ["id"] = "1692268917",
                        ["itemLink"] = 2593,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set hide of the werewolf ring robust",
            },
        },
        [45639] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Apple Baked Fish",
                ["oldestTime"] = 1633052718,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052718,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 59,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1633052718,
                        ["quant"] = 1,
                        ["id"] = "1690632273",
                        ["itemLink"] = 906,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [56056] = 
        {
            ["1:0:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_medium_head_b.dds",
                ["itemDesc"] = "Rawhide Helmet",
                ["oldestTime"] = 1633237863,
                ["wasAltered"] = true,
                ["newestTime"] = 1633237863,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 168,
                        ["wasKiosk"] = false,
                        ["seller"] = 207,
                        ["timestamp"] = 1633237863,
                        ["quant"] = 1,
                        ["id"] = "1692184525",
                        ["itemLink"] = 2500,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal medium apparel head nirnhoned",
            },
            ["50:16:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_medium_head_a.dds",
                ["itemDesc"] = "Rubedo Leather Helmet",
                ["oldestTime"] = 1633084039,
                ["wasAltered"] = true,
                ["newestTime"] = 1633084039,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633084039,
                        ["quant"] = 1,
                        ["id"] = "1690854667",
                        ["itemLink"] = 1168,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal medium apparel head nirnhoned",
            },
        },
        [177129] = 
        {
            ["1:0:2:51:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_belt_medium.dds",
                ["itemDesc"] = "Companion's Belt",
                ["oldestTime"] = 1633117441,
                ["wasAltered"] = true,
                ["newestTime"] = 1633117441,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1032,
                        ["wasKiosk"] = true,
                        ["seller"] = 252,
                        ["timestamp"] = 1633117441,
                        ["quant"] = 1,
                        ["id"] = "1691087861",
                        ["itemLink"] = 1416,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine medium apparel waist vigorous",
            },
        },
        [159482] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Style Page: Jephrine Paladin Sword",
                ["oldestTime"] = 1632911298,
                ["wasAltered"] = true,
                ["newestTime"] = 1632911298,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 548,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632911298,
                        ["quant"] = 1,
                        ["id"] = "1689605263",
                        ["itemLink"] = 3613,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [29947] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_chest_d.dds",
                ["itemDesc"] = "Daggerfall Champion's Breastplate of the Wyrd Tree",
                ["oldestTime"] = 1632966076,
                ["wasAltered"] = true,
                ["newestTime"] = 1632966076,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2658,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632966076,
                        ["quant"] = 1,
                        ["id"] = "1690016151",
                        ["itemLink"] = 3959,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set wyrd tree's blessing chest impenetrable",
            },
        },
        [160605] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 89: Ancestral High Elf Shoulders",
                ["oldestTime"] = 1633143394,
                ["wasAltered"] = true,
                ["newestTime"] = 1633143394,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5700,
                        ["guild"] = 1,
                        ["buyer"] = 1213,
                        ["wasKiosk"] = true,
                        ["seller"] = 1214,
                        ["timestamp"] = 1633143394,
                        ["quant"] = 1,
                        ["id"] = "1691330363",
                        ["itemLink"] = 1629,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [178429] = 
        {
            ["1:0:3:48:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_gloves_heavy.dds",
                ["itemDesc"] = "Companion's Gauntlets",
                ["oldestTime"] = 1633080307,
                ["wasAltered"] = true,
                ["newestTime"] = 1633080307,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5200,
                        ["guild"] = 1,
                        ["buyer"] = 880,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633080307,
                        ["quant"] = 1,
                        ["id"] = "1690836621",
                        ["itemLink"] = 1124,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior heavy apparel hands soothing",
            },
        },
        [56862] = 
        {
            ["1:0:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_potent_nirncrux_stone.dds",
                ["itemDesc"] = "Fortified Nirncrux",
                ["oldestTime"] = 1632825528,
                ["wasAltered"] = true,
                ["newestTime"] = 1633313604,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9302,
                        ["guild"] = 1,
                        ["buyer"] = 60,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633313599,
                        ["quant"] = 4,
                        ["id"] = "1692886779",
                        ["itemLink"] = 42,
                    },
                    [2] = 
                    {
                        ["price"] = 9302,
                        ["guild"] = 1,
                        ["buyer"] = 60,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633313600,
                        ["quant"] = 4,
                        ["id"] = "1692886801",
                        ["itemLink"] = 42,
                    },
                    [3] = 
                    {
                        ["price"] = 6977,
                        ["guild"] = 1,
                        ["buyer"] = 60,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633313602,
                        ["quant"] = 3,
                        ["id"] = "1692886843",
                        ["itemLink"] = 42,
                    },
                    [4] = 
                    {
                        ["price"] = 9303,
                        ["guild"] = 1,
                        ["buyer"] = 60,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633313604,
                        ["quant"] = 4,
                        ["id"] = "1692886885",
                        ["itemLink"] = 42,
                    },
                    [5] = 
                    {
                        ["price"] = 4697,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632973563,
                        ["quant"] = 2,
                        ["id"] = "1690087147",
                        ["itemLink"] = 42,
                    },
                    [6] = 
                    {
                        ["price"] = 9394,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632973564,
                        ["quant"] = 4,
                        ["id"] = "1690087155",
                        ["itemLink"] = 42,
                    },
                    [7] = 
                    {
                        ["price"] = 9394,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632973565,
                        ["quant"] = 4,
                        ["id"] = "1690087159",
                        ["itemLink"] = 42,
                    },
                    [8] = 
                    {
                        ["price"] = 9394,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632973566,
                        ["quant"] = 4,
                        ["id"] = "1690087165",
                        ["itemLink"] = 42,
                    },
                    [9] = 
                    {
                        ["price"] = 40600,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1632983194,
                        ["quant"] = 20,
                        ["id"] = "1690148885",
                        ["itemLink"] = 42,
                    },
                    [10] = 
                    {
                        ["price"] = 9712,
                        ["guild"] = 1,
                        ["buyer"] = 396,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633000955,
                        ["quant"] = 4,
                        ["id"] = "1690238435",
                        ["itemLink"] = 42,
                    },
                    [11] = 
                    {
                        ["price"] = 9712,
                        ["guild"] = 1,
                        ["buyer"] = 396,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633000956,
                        ["quant"] = 4,
                        ["id"] = "1690238441",
                        ["itemLink"] = 42,
                    },
                    [12] = 
                    {
                        ["price"] = 9712,
                        ["guild"] = 1,
                        ["buyer"] = 396,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633000957,
                        ["quant"] = 4,
                        ["id"] = "1690238447",
                        ["itemLink"] = 42,
                    },
                    [13] = 
                    {
                        ["price"] = 18200,
                        ["guild"] = 1,
                        ["buyer"] = 396,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633000958,
                        ["quant"] = 7,
                        ["id"] = "1690238449",
                        ["itemLink"] = 42,
                    },
                    [14] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 448,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633011244,
                        ["quant"] = 3,
                        ["id"] = "1690299265",
                        ["itemLink"] = 42,
                    },
                    [15] = 
                    {
                        ["price"] = 11675,
                        ["guild"] = 1,
                        ["buyer"] = 448,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633011246,
                        ["quant"] = 5,
                        ["id"] = "1690299307",
                        ["itemLink"] = 42,
                    },
                    [16] = 
                    {
                        ["price"] = 11675,
                        ["guild"] = 1,
                        ["buyer"] = 448,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633011247,
                        ["quant"] = 5,
                        ["id"] = "1690299325",
                        ["itemLink"] = 42,
                    },
                    [17] = 
                    {
                        ["price"] = 11675,
                        ["guild"] = 1,
                        ["buyer"] = 448,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633011248,
                        ["quant"] = 5,
                        ["id"] = "1690299339",
                        ["itemLink"] = 42,
                    },
                    [18] = 
                    {
                        ["price"] = 25200,
                        ["guild"] = 1,
                        ["buyer"] = 448,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633011250,
                        ["quant"] = 9,
                        ["id"] = "1690299369",
                        ["itemLink"] = 42,
                    },
                    [19] = 
                    {
                        ["price"] = 18900,
                        ["guild"] = 1,
                        ["buyer"] = 553,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633028055,
                        ["quant"] = 7,
                        ["id"] = "1690429051",
                        ["itemLink"] = 42,
                    },
                    [20] = 
                    {
                        ["price"] = 23000,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633068273,
                        ["quant"] = 10,
                        ["id"] = "1690768833",
                        ["itemLink"] = 42,
                    },
                    [21] = 
                    {
                        ["price"] = 4628,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633097073,
                        ["quant"] = 2,
                        ["id"] = "1690936593",
                        ["itemLink"] = 42,
                    },
                    [22] = 
                    {
                        ["price"] = 4800,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 171,
                        ["timestamp"] = 1633097077,
                        ["quant"] = 2,
                        ["id"] = "1690936623",
                        ["itemLink"] = 42,
                    },
                    [23] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 171,
                        ["timestamp"] = 1633097078,
                        ["quant"] = 5,
                        ["id"] = "1690936625",
                        ["itemLink"] = 42,
                    },
                    [24] = 
                    {
                        ["price"] = 9354,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633097078,
                        ["quant"] = 4,
                        ["id"] = "1690936633",
                        ["itemLink"] = 42,
                    },
                    [25] = 
                    {
                        ["price"] = 9354,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633097079,
                        ["quant"] = 4,
                        ["id"] = "1690936641",
                        ["itemLink"] = 42,
                    },
                    [26] = 
                    {
                        ["price"] = 11572,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633097079,
                        ["quant"] = 5,
                        ["id"] = "1690936649",
                        ["itemLink"] = 42,
                    },
                    [27] = 
                    {
                        ["price"] = 4400,
                        ["guild"] = 1,
                        ["buyer"] = 1319,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633165374,
                        ["quant"] = 2,
                        ["id"] = "1691497783",
                        ["itemLink"] = 42,
                    },
                    [28] = 
                    {
                        ["price"] = 32480,
                        ["guild"] = 1,
                        ["buyer"] = 1364,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633180248,
                        ["quant"] = 16,
                        ["id"] = "1691586945",
                        ["itemLink"] = 42,
                    },
                    [29] = 
                    {
                        ["price"] = 4677,
                        ["guild"] = 1,
                        ["buyer"] = 396,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633186252,
                        ["quant"] = 2,
                        ["id"] = "1691643125",
                        ["itemLink"] = 42,
                    },
                    [30] = 
                    {
                        ["price"] = 9355,
                        ["guild"] = 1,
                        ["buyer"] = 396,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633186253,
                        ["quant"] = 4,
                        ["id"] = "1691643133",
                        ["itemLink"] = 42,
                    },
                    [31] = 
                    {
                        ["price"] = 4708,
                        ["guild"] = 1,
                        ["buyer"] = 396,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633186253,
                        ["quant"] = 2,
                        ["id"] = "1691643139",
                        ["itemLink"] = 42,
                    },
                    [32] = 
                    {
                        ["price"] = 9416,
                        ["guild"] = 1,
                        ["buyer"] = 396,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633186254,
                        ["quant"] = 4,
                        ["id"] = "1691643149",
                        ["itemLink"] = 42,
                    },
                    [33] = 
                    {
                        ["price"] = 84000,
                        ["guild"] = 1,
                        ["buyer"] = 396,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633186255,
                        ["quant"] = 35,
                        ["id"] = "1691643155",
                        ["itemLink"] = 42,
                    },
                    [34] = 
                    {
                        ["price"] = 61600,
                        ["guild"] = 1,
                        ["buyer"] = 1426,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633192321,
                        ["quant"] = 22,
                        ["id"] = "1691716241",
                        ["itemLink"] = 42,
                    },
                    [35] = 
                    {
                        ["price"] = 10150,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633280920,
                        ["quant"] = 5,
                        ["id"] = "1692524061",
                        ["itemLink"] = 42,
                    },
                    [36] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1252,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1632825528,
                        ["quant"] = 4,
                        ["id"] = "1688966333",
                        ["itemLink"] = 42,
                    },
                    [37] = 
                    {
                        ["price"] = 11768,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632852927,
                        ["quant"] = 5,
                        ["id"] = "1689166483",
                        ["itemLink"] = 42,
                    },
                    [38] = 
                    {
                        ["price"] = 11768,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632852928,
                        ["quant"] = 5,
                        ["id"] = "1689166491",
                        ["itemLink"] = 42,
                    },
                    [39] = 
                    {
                        ["price"] = 7061,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632852930,
                        ["quant"] = 3,
                        ["id"] = "1689166509",
                        ["itemLink"] = 42,
                    },
                    [40] = 
                    {
                        ["price"] = 11769,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632852931,
                        ["quant"] = 5,
                        ["id"] = "1689166519",
                        ["itemLink"] = 42,
                    },
                    [41] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 42,
                        ["wasKiosk"] = false,
                        ["seller"] = 244,
                        ["timestamp"] = 1632881207,
                        ["quant"] = 10,
                        ["id"] = "1689408697",
                        ["itemLink"] = 42,
                    },
                    [42] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1065,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1632881459,
                        ["quant"] = 2,
                        ["id"] = "1689411175",
                        ["itemLink"] = 42,
                    },
                    [43] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632897756,
                        ["quant"] = 10,
                        ["id"] = "1689547303",
                        ["itemLink"] = 42,
                    },
                },
                ["totalCount"] = 43,
                ["itemAdderText"] = "rr01 white normal materials armor trait nirnhoned",
            },
        },
        [178431] = 
        {
            ["1:0:3:50:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_gloves_heavy.dds",
                ["itemDesc"] = "Companion's Gauntlets",
                ["oldestTime"] = 1633031206,
                ["wasAltered"] = true,
                ["newestTime"] = 1633295500,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 29999,
                        ["guild"] = 1,
                        ["buyer"] = 564,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633031206,
                        ["quant"] = 1,
                        ["id"] = "1690452469",
                        ["itemLink"] = 715,
                    },
                    [2] = 
                    {
                        ["price"] = 22500,
                        ["guild"] = 1,
                        ["buyer"] = 1441,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633194350,
                        ["quant"] = 1,
                        ["id"] = "1691737313",
                        ["itemLink"] = 715,
                    },
                    [3] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 2001,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633293810,
                        ["quant"] = 1,
                        ["id"] = "1692673677",
                        ["itemLink"] = 715,
                    },
                    [4] = 
                    {
                        ["price"] = 49999,
                        ["guild"] = 1,
                        ["buyer"] = 2019,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633295500,
                        ["quant"] = 1,
                        ["id"] = "1692696083",
                        ["itemLink"] = 715,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior heavy apparel hands bolstered",
            },
        },
    },
}
