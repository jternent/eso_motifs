GS01DataSavedVariables =
{
    ["listingseu"] = 
    {
    },
    ["listingsna"] = 
    {
    },
    ["dataeu"] = 
    {
    },
    ["datana"] = 
    {
        [120835] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_col_lsb_dbhcandlelabra001.dds",
                ["itemDesc"] = "Brotherhood Candelabra, Table",
                ["oldestTime"] = 1632984822,
                ["wasAltered"] = true,
                ["newestTime"] = 1632984822,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 310,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1632984822,
                        ["quant"] = 1,
                        ["id"] = "1690159037",
                        ["itemLink"] = 316,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings lighting",
            },
        },
        [150789] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_dragons_bile.dds",
                ["itemDesc"] = "Dragon's Bile",
                ["oldestTime"] = 1632871891,
                ["wasAltered"] = true,
                ["newestTime"] = 1633098677,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4200,
                        ["guild"] = 1,
                        ["buyer"] = 937,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633098673,
                        ["quant"] = 20,
                        ["id"] = "1690946361",
                        ["itemLink"] = 1274,
                    },
                    [2] = 
                    {
                        ["price"] = 4200,
                        ["guild"] = 1,
                        ["buyer"] = 937,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633098675,
                        ["quant"] = 20,
                        ["id"] = "1690946389",
                        ["itemLink"] = 1274,
                    },
                    [3] = 
                    {
                        ["price"] = 4200,
                        ["guild"] = 1,
                        ["buyer"] = 937,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633098677,
                        ["quant"] = 20,
                        ["id"] = "1690946405",
                        ["itemLink"] = 1274,
                    },
                    [4] = 
                    {
                        ["price"] = 44000,
                        ["guild"] = 1,
                        ["buyer"] = 151,
                        ["wasKiosk"] = false,
                        ["seller"] = 31,
                        ["timestamp"] = 1632871891,
                        ["quant"] = 200,
                        ["id"] = "1689315275",
                        ["itemLink"] = 1274,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [167431] = 
        {
            ["50:16:2:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Amulet of the Radiant Bastion",
                ["oldestTime"] = 1632837934,
                ["wasAltered"] = true,
                ["newestTime"] = 1632837934,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 549,
                        ["guild"] = 1,
                        ["buyer"] = 718,
                        ["wasKiosk"] = true,
                        ["seller"] = 530,
                        ["timestamp"] = 1632837934,
                        ["quant"] = 1,
                        ["id"] = "1689046961",
                        ["itemLink"] = 3116,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set radiant bastion neck healthy",
            },
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Amulet of the Radiant Bastion",
                ["oldestTime"] = 1633163932,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163933,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2990,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633163932,
                        ["quant"] = 1,
                        ["id"] = "1691490467",
                        ["itemLink"] = 1824,
                    },
                    [2] = 
                    {
                        ["price"] = 2990,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633163933,
                        ["quant"] = 1,
                        ["id"] = "1691490473",
                        ["itemLink"] = 1824,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set radiant bastion neck healthy",
            },
        },
        [171272] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Style Page: Opal Iceheart Bow",
                ["oldestTime"] = 1633297349,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297349,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 37999,
                        ["guild"] = 1,
                        ["buyer"] = 2027,
                        ["wasKiosk"] = true,
                        ["seller"] = 451,
                        ["timestamp"] = 1633297349,
                        ["quant"] = 1,
                        ["id"] = "1692713941",
                        ["itemLink"] = 2889,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [167177] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 92: Ancestral Akaviri Bows",
                ["oldestTime"] = 1632940075,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292564,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 130000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 43,
                        ["timestamp"] = 1633125695,
                        ["quant"] = 1,
                        ["id"] = "1691147739",
                        ["itemLink"] = 1479,
                    },
                    [2] = 
                    {
                        ["price"] = 110000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633292564,
                        ["quant"] = 1,
                        ["id"] = "1692658305",
                        ["itemLink"] = 1479,
                    },
                    [3] = 
                    {
                        ["price"] = 199990,
                        ["guild"] = 1,
                        ["buyer"] = 2542,
                        ["wasKiosk"] = true,
                        ["seller"] = 608,
                        ["timestamp"] = 1632940075,
                        ["quant"] = 1,
                        ["id"] = "1689795005",
                        ["itemLink"] = 1479,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [172298] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_staff_a.dds",
                ["itemDesc"] = "Bog Raider's Lightning Staff",
                ["oldestTime"] = 1633166678,
                ["wasAltered"] = true,
                ["newestTime"] = 1633166678,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 599,
                        ["guild"] = 1,
                        ["buyer"] = 889,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633166678,
                        ["quant"] = 1,
                        ["id"] = "1691503505",
                        ["itemLink"] = 1864,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set bog raider lightning staff two-handed infused",
            },
        },
        [57611] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 20: Yokudan Daggers",
                ["oldestTime"] = 1633187472,
                ["wasAltered"] = true,
                ["newestTime"] = 1633187472,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1070,
                        ["wasKiosk"] = true,
                        ["seller"] = 22,
                        ["timestamp"] = 1633187472,
                        ["quant"] = 1,
                        ["id"] = "1691657017",
                        ["itemLink"] = 2080,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [178444] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_inc_leywoodframepainting005.dds",
                ["itemDesc"] = "A Study in Structure Painting, Wood",
                ["oldestTime"] = 1633061715,
                ["wasAltered"] = true,
                ["newestTime"] = 1633061715,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 37500,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 611,
                        ["timestamp"] = 1633061715,
                        ["quant"] = 1,
                        ["id"] = "1690723061",
                        ["itemLink"] = 1030,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings gallery",
            },
        },
        [97037] = 
        {
            ["50:16:4:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_1haxe_d.dds",
                ["itemDesc"] = "Plague Doctor's Axe",
                ["oldestTime"] = 1633067627,
                ["wasAltered"] = true,
                ["newestTime"] = 1633067627,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 765,
                        ["wasKiosk"] = false,
                        ["seller"] = 354,
                        ["timestamp"] = 1633067627,
                        ["quant"] = 1,
                        ["id"] = "1690765363",
                        ["itemLink"] = 1075,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set plague doctor axe one-handed infused",
            },
        },
        [171791] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Markarth Wall, Windowed Stone",
                ["oldestTime"] = 1632970770,
                ["wasAltered"] = true,
                ["newestTime"] = 1632970770,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6900,
                        ["guild"] = 1,
                        ["buyer"] = 172,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632970770,
                        ["quant"] = 1,
                        ["id"] = "1690064011",
                        ["itemLink"] = 185,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [43536] = 
        {
            ["50:14:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Electrum Ring",
                ["oldestTime"] = 1633119128,
                ["wasAltered"] = true,
                ["newestTime"] = 1633275187,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633119128,
                        ["quant"] = 1,
                        ["id"] = "1691098773",
                        ["itemLink"] = 1428,
                    },
                    [2] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633119129,
                        ["quant"] = 1,
                        ["id"] = "1691098781",
                        ["itemLink"] = 1429,
                    },
                    [3] = 
                    {
                        ["price"] = 20,
                        ["guild"] = 1,
                        ["buyer"] = 398,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633136221,
                        ["quant"] = 1,
                        ["id"] = "1691255383",
                        ["itemLink"] = 1429,
                    },
                    [4] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1045,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633275187,
                        ["quant"] = 1,
                        ["id"] = "1692465549",
                        ["itemLink"] = 2698,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp140 white normal jewelry apparel ring",
            },
        },
        [171794] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting2.dds",
                ["itemDesc"] = "Praxis: Markarth Platform, Circular",
                ["oldestTime"] = 1632970985,
                ["wasAltered"] = true,
                ["newestTime"] = 1632970985,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 172,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632970985,
                        ["quant"] = 1,
                        ["id"] = "1690065619",
                        ["itemLink"] = 190,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [43540] = 
        {
            ["50:16:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_heavy_legs_d.dds",
                ["itemDesc"] = "Rubedite Greaves of Stamina",
                ["oldestTime"] = 1633185958,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185958,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 174,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633185958,
                        ["quant"] = 1,
                        ["id"] = "1691640337",
                        ["itemLink"] = 2033,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel legs",
            },
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_heavy_legs_d.dds",
                ["itemDesc"] = "Rubedite Greaves",
                ["oldestTime"] = 1633185950,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185951,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 125,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633185950,
                        ["quant"] = 1,
                        ["id"] = "1691640243",
                        ["itemLink"] = 2027,
                    },
                    [2] = 
                    {
                        ["price"] = 128,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633185951,
                        ["quant"] = 1,
                        ["id"] = "1691640255",
                        ["itemLink"] = 2028,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 white normal heavy apparel legs",
            },
        },
        [102168] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_draugr_medium_hands_a.dds",
                ["itemDesc"] = "Stygian Bracers",
                ["oldestTime"] = 1632891732,
                ["wasAltered"] = true,
                ["newestTime"] = 1633144531,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 1221,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633144531,
                        ["quant"] = 1,
                        ["id"] = "1691343027",
                        ["itemLink"] = 1644,
                    },
                    [2] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 2415,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1632891732,
                        ["quant"] = 1,
                        ["id"] = "1689506005",
                        ["itemLink"] = 1644,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic medium apparel set stygian hands impenetrable",
            },
        },
        [77081] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ooth_2hsword_a.dds",
                ["itemDesc"] = "Greatsword of Flanking",
                ["oldestTime"] = 1633193243,
                ["wasAltered"] = true,
                ["newestTime"] = 1633193243,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 1432,
                        ["wasKiosk"] = true,
                        ["seller"] = 474,
                        ["timestamp"] = 1633193243,
                        ["quant"] = 1,
                        ["id"] = "1691726593",
                        ["itemLink"] = 2121,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set flanking strategist sword two-handed infused",
            },
        },
        [167962] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 96: Arkthzand Armory Belts",
                ["oldestTime"] = 1632906321,
                ["wasAltered"] = true,
                ["newestTime"] = 1632906321,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 2453,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632906321,
                        ["quant"] = 1,
                        ["id"] = "1689588255",
                        ["itemLink"] = 3590,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [172315] = 
        {
            ["50:16:3:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_bow_a.dds",
                ["itemDesc"] = "Bog Raider's Bow",
                ["oldestTime"] = 1633289443,
                ["wasAltered"] = true,
                ["newestTime"] = 1633289443,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 513,
                        ["guild"] = 1,
                        ["buyer"] = 202,
                        ["wasKiosk"] = false,
                        ["seller"] = 526,
                        ["timestamp"] = 1633289443,
                        ["quant"] = 1,
                        ["id"] = "1692620413",
                        ["itemLink"] = 2772,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set bog raider bow two-handed powered",
            },
        },
        [153628] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/event_halloween_2016_spooky_recipe.dds",
                ["itemDesc"] = "Recipe: Bewitched Sugar Skulls",
                ["oldestTime"] = 1633186948,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261603,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 179999,
                        ["guild"] = 1,
                        ["buyer"] = 1400,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633186948,
                        ["quant"] = 1,
                        ["id"] = "1691651571",
                        ["itemLink"] = 2076,
                    },
                    [2] = 
                    {
                        ["price"] = 179999,
                        ["guild"] = 1,
                        ["buyer"] = 1616,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633231206,
                        ["quant"] = 1,
                        ["id"] = "1692125787",
                        ["itemLink"] = 2076,
                    },
                    [3] = 
                    {
                        ["price"] = 179999,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633261603,
                        ["quant"] = 1,
                        ["id"] = "1692334397",
                        ["itemLink"] = 2076,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 gold legendary consumable recipe",
            },
        },
        [180766] = 
        {
            ["50:16:5:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Hrothgar's Amulet",
                ["oldestTime"] = 1633146554,
                ["wasAltered"] = true,
                ["newestTime"] = 1633146554,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 499999,
                        ["guild"] = 1,
                        ["buyer"] = 1233,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1633146554,
                        ["quant"] = 1,
                        ["id"] = "1691361417",
                        ["itemLink"] = 1654,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary jewelry apparel set hrothgar's chill neck healthy",
            },
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Hrothgar's Amulet",
                ["oldestTime"] = 1633224903,
                ["wasAltered"] = true,
                ["newestTime"] = 1633224903,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 33333,
                        ["guild"] = 1,
                        ["buyer"] = 1300,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633224903,
                        ["quant"] = 1,
                        ["id"] = "1692063317",
                        ["itemLink"] = 2380,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set hrothgar's chill neck healthy",
            },
        },
        [166943] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning3.dds",
                ["itemDesc"] = "Design: Solitude Breakfast, Sausages and Ham",
                ["oldestTime"] = 1633056356,
                ["wasAltered"] = true,
                ["newestTime"] = 1633056356,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 747,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633056356,
                        ["quant"] = 1,
                        ["id"] = "1690668715",
                        ["itemLink"] = 955,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45344] = 
        {
            ["1:0:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_heavy_legs_a.dds",
                ["itemDesc"] = "Iron Greaves",
                ["oldestTime"] = 1633072301,
                ["wasAltered"] = true,
                ["newestTime"] = 1633072301,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 125,
                        ["guild"] = 1,
                        ["buyer"] = 850,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633072301,
                        ["quant"] = 1,
                        ["id"] = "1690793381",
                        ["itemLink"] = 1095,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal heavy apparel legs intricate",
            },
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_heavy_legs_a.dds",
                ["itemDesc"] = "Rubedite Greaves",
                ["oldestTime"] = 1632889277,
                ["wasAltered"] = true,
                ["newestTime"] = 1633249599,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 197,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1633028923,
                        ["quant"] = 1,
                        ["id"] = "1690436781",
                        ["itemLink"] = 704,
                    },
                    [2] = 
                    {
                        ["price"] = 240,
                        ["guild"] = 1,
                        ["buyer"] = 850,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1633072304,
                        ["quant"] = 1,
                        ["id"] = "1690793427",
                        ["itemLink"] = 1098,
                    },
                    [3] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084085,
                        ["quant"] = 1,
                        ["id"] = "1690854975",
                        ["itemLink"] = 1179,
                    },
                    [4] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633084105,
                        ["quant"] = 1,
                        ["id"] = "1690855045",
                        ["itemLink"] = 1187,
                    },
                    [5] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633084109,
                        ["quant"] = 1,
                        ["id"] = "1690855065",
                        ["itemLink"] = 1188,
                    },
                    [6] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1055,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633121633,
                        ["quant"] = 1,
                        ["id"] = "1691116743",
                        ["itemLink"] = 1179,
                    },
                    [7] = 
                    {
                        ["price"] = 185,
                        ["guild"] = 1,
                        ["buyer"] = 1734,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633236161,
                        ["quant"] = 1,
                        ["id"] = "1692168711",
                        ["itemLink"] = 1098,
                    },
                    [8] = 
                    {
                        ["price"] = 310,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633244683,
                        ["quant"] = 1,
                        ["id"] = "1692231377",
                        ["itemLink"] = 2574,
                    },
                    [9] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1811,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633249599,
                        ["quant"] = 1,
                        ["id"] = "1692267609",
                        ["itemLink"] = 2589,
                    },
                    [10] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2408,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1632889277,
                        ["quant"] = 1,
                        ["id"] = "1689487537",
                        ["itemLink"] = 1179,
                    },
                    [11] = 
                    {
                        ["price"] = 240,
                        ["guild"] = 1,
                        ["buyer"] = 2660,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1632966356,
                        ["quant"] = 1,
                        ["id"] = "1690018461",
                        ["itemLink"] = 3966,
                    },
                },
                ["totalCount"] = 11,
                ["itemAdderText"] = "cp160 white normal heavy apparel legs intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_heavy_legs_d.dds",
                ["itemDesc"] = "Rubedite Greaves",
                ["oldestTime"] = 1632885620,
                ["wasAltered"] = true,
                ["newestTime"] = 1633084682,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084682,
                        ["quant"] = 1,
                        ["id"] = "1690857353",
                        ["itemLink"] = 1208,
                    },
                    [2] = 
                    {
                        ["price"] = 238,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 240,
                        ["timestamp"] = 1632885620,
                        ["quant"] = 1,
                        ["id"] = "1689459249",
                        ["itemLink"] = 3505,
                    },
                    [3] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2660,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632966351,
                        ["quant"] = 1,
                        ["id"] = "1690018407",
                        ["itemLink"] = 3964,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp150 white normal heavy apparel legs intricate",
            },
        },
        [165670] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_fur_benchfancy002.dds",
                ["itemDesc"] = "Solitude Pew, Noble Long",
                ["oldestTime"] = 1633165896,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165897,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633165896,
                        ["quant"] = 1,
                        ["id"] = "1691499901",
                        ["itemLink"] = 1848,
                    },
                    [2] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633165897,
                        ["quant"] = 1,
                        ["id"] = "1691499909",
                        ["itemLink"] = 1848,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [45096] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_heavy_feet_d.dds",
                ["itemDesc"] = "Rubedite Sabatons of Stamina",
                ["oldestTime"] = 1632856299,
                ["wasAltered"] = true,
                ["newestTime"] = 1632856299,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 533,
                        ["timestamp"] = 1632856299,
                        ["quant"] = 1,
                        ["id"] = "1689200549",
                        ["itemLink"] = 3268,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel feet reinforced",
            },
            ["50:16:4:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_heavy_feet_d.dds",
                ["itemDesc"] = "Rubedite Sabatons of Magicka",
                ["oldestTime"] = 1633186030,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186030,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 425,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1633186030,
                        ["quant"] = 1,
                        ["id"] = "1691641007",
                        ["itemLink"] = 2065,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel feet reinforced",
            },
            ["50:16:2:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_heavy_feet_d.dds",
                ["itemDesc"] = "Rubedite Sabatons of Magicka",
                ["oldestTime"] = 1632847693,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185973,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 533,
                        ["timestamp"] = 1633185973,
                        ["quant"] = 1,
                        ["id"] = "1691640453",
                        ["itemLink"] = 2040,
                    },
                    [2] = 
                    {
                        ["price"] = 185,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632847693,
                        ["quant"] = 1,
                        ["id"] = "1689125573",
                        ["itemLink"] = 3216,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine heavy apparel feet reinforced",
            },
        },
        [160554] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 85: Greymoor Shoulders",
                ["oldestTime"] = 1632974905,
                ["wasAltered"] = true,
                ["newestTime"] = 1632974905,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8200,
                        ["guild"] = 1,
                        ["buyer"] = 208,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1632974905,
                        ["quant"] = 1,
                        ["id"] = "1690095033",
                        ["itemLink"] = 218,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45099] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_heavy_legs_d.dds",
                ["itemDesc"] = "Rubedite Greaves of Magicka",
                ["oldestTime"] = 1633186032,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186032,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 440,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633186032,
                        ["quant"] = 1,
                        ["id"] = "1691641021",
                        ["itemLink"] = 2066,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel legs reinforced",
            },
            ["50:16:1:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_heavy_legs_d.dds",
                ["itemDesc"] = "Rubedite Greaves",
                ["oldestTime"] = 1633185969,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185969,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1633185969,
                        ["quant"] = 1,
                        ["id"] = "1691640433",
                        ["itemLink"] = 2039,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal heavy apparel legs reinforced",
            },
        },
        [77357] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_darkbrotherhoodv2_heavy_head_a.dds",
                ["itemDesc"] = "Sithis' Helm",
                ["oldestTime"] = 1633117791,
                ["wasAltered"] = true,
                ["newestTime"] = 1633117791,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 1034,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633117791,
                        ["quant"] = 1,
                        ["id"] = "1691090323",
                        ["itemLink"] = 1418,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set sithis' touch head reinforced",
            },
        },
        [100403] = 
        {
            ["50:16:4:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_2hsword_d.dds",
                ["itemDesc"] = "Vampire Lord's Greatsword",
                ["oldestTime"] = 1632870529,
                ["wasAltered"] = true,
                ["newestTime"] = 1632870529,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6200,
                        ["guild"] = 1,
                        ["buyer"] = 670,
                        ["wasKiosk"] = true,
                        ["seller"] = 816,
                        ["timestamp"] = 1632870529,
                        ["quant"] = 1,
                        ["id"] = "1689307025",
                        ["itemLink"] = 3386,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set vampire lord sword two-handed infused",
            },
        },
        [145974] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Murkmire Pot, Handmade",
                ["oldestTime"] = 1633109414,
                ["wasAltered"] = true,
                ["newestTime"] = 1633109414,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18850,
                        ["guild"] = 1,
                        ["buyer"] = 979,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1633109414,
                        ["quant"] = 1,
                        ["id"] = "1691031817",
                        ["itemLink"] = 1319,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [23095] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_leather_base_fur_r2.dds",
                ["itemDesc"] = "Leather Scraps",
                ["oldestTime"] = 1632852951,
                ["wasAltered"] = true,
                ["newestTime"] = 1632961564,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852951,
                        ["quant"] = 200,
                        ["id"] = "1689166707",
                        ["itemLink"] = 3256,
                    },
                    [2] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852952,
                        ["quant"] = 200,
                        ["id"] = "1689166717",
                        ["itemLink"] = 3256,
                    },
                    [3] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852956,
                        ["quant"] = 200,
                        ["id"] = "1689166745",
                        ["itemLink"] = 3256,
                    },
                    [4] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852959,
                        ["quant"] = 200,
                        ["id"] = "1689166771",
                        ["itemLink"] = 3256,
                    },
                    [5] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632852961,
                        ["quant"] = 200,
                        ["id"] = "1689166787",
                        ["itemLink"] = 3256,
                    },
                    [6] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961237,
                        ["quant"] = 200,
                        ["id"] = "1689969777",
                        ["itemLink"] = 3256,
                    },
                    [7] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961237,
                        ["quant"] = 200,
                        ["id"] = "1689969787",
                        ["itemLink"] = 3256,
                    },
                    [8] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961282,
                        ["quant"] = 200,
                        ["id"] = "1689970153",
                        ["itemLink"] = 3256,
                    },
                    [9] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961555,
                        ["quant"] = 200,
                        ["id"] = "1689971533",
                        ["itemLink"] = 3256,
                    },
                    [10] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961556,
                        ["quant"] = 200,
                        ["id"] = "1689971537",
                        ["itemLink"] = 3256,
                    },
                    [11] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961557,
                        ["quant"] = 200,
                        ["id"] = "1689971543",
                        ["itemLink"] = 3256,
                    },
                    [12] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961557,
                        ["quant"] = 200,
                        ["id"] = "1689971545",
                        ["itemLink"] = 3256,
                    },
                    [13] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961558,
                        ["quant"] = 200,
                        ["id"] = "1689971551",
                        ["itemLink"] = 3256,
                    },
                    [14] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961558,
                        ["quant"] = 200,
                        ["id"] = "1689971559",
                        ["itemLink"] = 3256,
                    },
                    [15] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961559,
                        ["quant"] = 200,
                        ["id"] = "1689971563",
                        ["itemLink"] = 3256,
                    },
                    [16] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961560,
                        ["quant"] = 200,
                        ["id"] = "1689971571",
                        ["itemLink"] = 3256,
                    },
                    [17] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961560,
                        ["quant"] = 200,
                        ["id"] = "1689971587",
                        ["itemLink"] = 3256,
                    },
                    [18] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961561,
                        ["quant"] = 200,
                        ["id"] = "1689971589",
                        ["itemLink"] = 3256,
                    },
                    [19] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961561,
                        ["quant"] = 200,
                        ["id"] = "1689971601",
                        ["itemLink"] = 3256,
                    },
                    [20] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961562,
                        ["quant"] = 200,
                        ["id"] = "1689971617",
                        ["itemLink"] = 3256,
                    },
                    [21] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961562,
                        ["quant"] = 200,
                        ["id"] = "1689971621",
                        ["itemLink"] = 3256,
                    },
                    [22] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961563,
                        ["quant"] = 200,
                        ["id"] = "1689971635",
                        ["itemLink"] = 3256,
                    },
                    [23] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961564,
                        ["quant"] = 200,
                        ["id"] = "1689971645",
                        ["itemLink"] = 3256,
                    },
                },
                ["totalCount"] = 23,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [71736] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_ragada_r2.dds",
                ["itemDesc"] = "Ancient Sandstone",
                ["oldestTime"] = 1632969767,
                ["wasAltered"] = true,
                ["newestTime"] = 1632969767,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5445,
                        ["guild"] = 1,
                        ["buyer"] = 157,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632969767,
                        ["quant"] = 55,
                        ["id"] = "1690054763",
                        ["itemLink"] = 165,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [176185] = 
        {
            ["1:0:4:44:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_shoulders_light.dds",
                ["itemDesc"] = "Companion's Epaulets",
                ["oldestTime"] = 1633282477,
                ["wasAltered"] = true,
                ["newestTime"] = 1633282477,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 65000,
                        ["guild"] = 1,
                        ["buyer"] = 1940,
                        ["wasKiosk"] = true,
                        ["seller"] = 775,
                        ["timestamp"] = 1633282477,
                        ["quant"] = 1,
                        ["id"] = "1692540991",
                        ["itemLink"] = 2743,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic light apparel shoulders prolific",
            },
        },
        [122940] = 
        {
            ["50:16:4:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_telvanni_light_waist_a.dds",
                ["itemDesc"] = "War Maiden's Sash",
                ["oldestTime"] = 1632872154,
                ["wasAltered"] = true,
                ["newestTime"] = 1632872154,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9999,
                        ["guild"] = 1,
                        ["buyer"] = 2298,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632872154,
                        ["quant"] = 1,
                        ["id"] = "1689316545",
                        ["itemLink"] = 3392,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set war maiden waist sturdy",
            },
        },
        [74558] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 33: Thieves Guild Boots",
                ["oldestTime"] = 1633091066,
                ["wasAltered"] = true,
                ["newestTime"] = 1633091066,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 655,
                        ["wasKiosk"] = false,
                        ["seller"] = 374,
                        ["timestamp"] = 1633091066,
                        ["quant"] = 1,
                        ["id"] = "1690894963",
                        ["itemLink"] = 1244,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45632] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Hello Handsome Porter",
                ["oldestTime"] = 1633122938,
                ["wasAltered"] = true,
                ["newestTime"] = 1633122938,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3300,
                        ["guild"] = 1,
                        ["buyer"] = 1066,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633122938,
                        ["quant"] = 1,
                        ["id"] = "1691126865",
                        ["itemLink"] = 1454,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [54339] = 
        {
            ["50:15:1:9:8454917"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/consumable_potion_001_type_005.dds",
                ["itemDesc"] = "Essence of Health",
                ["oldestTime"] = 1632968970,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297478,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 146,
                        ["timestamp"] = 1632968970,
                        ["quant"] = 200,
                        ["id"] = "1690046025",
                        ["itemLink"] = 162,
                    },
                    [2] = 
                    {
                        ["price"] = 68724,
                        ["guild"] = 1,
                        ["buyer"] = 1067,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633123083,
                        ["quant"] = 200,
                        ["id"] = "1691127899",
                        ["itemLink"] = 162,
                    },
                    [3] = 
                    {
                        ["price"] = 68724,
                        ["guild"] = 1,
                        ["buyer"] = 1203,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633142359,
                        ["quant"] = 200,
                        ["id"] = "1691317735",
                        ["itemLink"] = 162,
                    },
                    [4] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 1203,
                        ["wasKiosk"] = true,
                        ["seller"] = 146,
                        ["timestamp"] = 1633142360,
                        ["quant"] = 200,
                        ["id"] = "1691317755",
                        ["itemLink"] = 162,
                    },
                    [5] = 
                    {
                        ["price"] = 68655,
                        ["guild"] = 1,
                        ["buyer"] = 1954,
                        ["wasKiosk"] = true,
                        ["seller"] = 1318,
                        ["timestamp"] = 1633297475,
                        ["quant"] = 199,
                        ["id"] = "1692715823",
                        ["itemLink"] = 162,
                    },
                    [6] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 1954,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633297478,
                        ["quant"] = 200,
                        ["id"] = "1692715863",
                        ["itemLink"] = 162,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "cp150 white normal consumable potion",
            },
        },
        [180805] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_heavy_shoulders_a.dds",
                ["itemDesc"] = "Hrothgar's Pauldrons",
                ["oldestTime"] = 1633112502,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112502,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 991,
                        ["wasKiosk"] = true,
                        ["seller"] = 356,
                        ["timestamp"] = 1633112502,
                        ["quant"] = 1,
                        ["id"] = "1691055503",
                        ["itemLink"] = 1355,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set hrothgar's chill shoulders divines",
            },
        },
        [175945] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Table, Sturdy Square",
                ["oldestTime"] = 1633035650,
                ["wasAltered"] = true,
                ["newestTime"] = 1633035650,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 333,
                        ["wasKiosk"] = false,
                        ["seller"] = 195,
                        ["timestamp"] = 1633035650,
                        ["quant"] = 1,
                        ["id"] = "1690480245",
                        ["itemLink"] = 765,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [149322] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_pellitine_light_legs_a.dds",
                ["itemDesc"] = "Crafty Alfiq's Breeches",
                ["oldestTime"] = 1632944659,
                ["wasAltered"] = true,
                ["newestTime"] = 1632944659,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 2562,
                        ["wasKiosk"] = true,
                        ["seller"] = 547,
                        ["timestamp"] = 1632944659,
                        ["quant"] = 1,
                        ["id"] = "1689832377",
                        ["itemLink"] = 3787,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set crafty alfiq legs reinforced",
            },
        },
        [161101] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_greyhosthvy_chest_a.dds",
                ["itemDesc"] = "Cuirass of Eternal Vigor",
                ["oldestTime"] = 1633311366,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311366,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6999,
                        ["guild"] = 1,
                        ["buyer"] = 11,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633311366,
                        ["quant"] = 1,
                        ["id"] = "1692864145",
                        ["itemLink"] = 8,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set eternal vigor chest impenetrable",
            },
        },
        [180814] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_bow_a.dds",
                ["itemDesc"] = "Hrothgar's Bow",
                ["oldestTime"] = 1633290762,
                ["wasAltered"] = true,
                ["newestTime"] = 1633290762,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1983,
                        ["wasKiosk"] = true,
                        ["seller"] = 47,
                        ["timestamp"] = 1633290762,
                        ["quant"] = 1,
                        ["id"] = "1692636255",
                        ["itemLink"] = 2786,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set hrothgar's chill bow two-handed precise",
            },
            ["50:16:4:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_bow_a.dds",
                ["itemDesc"] = "Hrothgar's Bow",
                ["oldestTime"] = 1633112428,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112428,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2222,
                        ["guild"] = 1,
                        ["buyer"] = 991,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633112428,
                        ["quant"] = 1,
                        ["id"] = "1691055121",
                        ["itemLink"] = 1346,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set hrothgar's chill bow two-handed precise",
            },
        },
        [119376] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Banana, Wax",
                ["oldestTime"] = 1633071531,
                ["wasAltered"] = true,
                ["newestTime"] = 1633071531,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 125,
                        ["guild"] = 1,
                        ["buyer"] = 847,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633071531,
                        ["quant"] = 1,
                        ["id"] = "1690787821",
                        ["itemLink"] = 1092,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [176977] = 
        {
            ["1:0:2:50:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_shoulders_light.dds",
                ["itemDesc"] = "Companion's Epaulets",
                ["oldestTime"] = 1633064348,
                ["wasAltered"] = true,
                ["newestTime"] = 1633064348,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1606,
                        ["guild"] = 1,
                        ["buyer"] = 811,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1633064348,
                        ["quant"] = 1,
                        ["id"] = "1690743335",
                        ["itemLink"] = 1050,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine light apparel shoulders bolstered",
            },
        },
        [176723] = 
        {
            ["1:0:3:48:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_chest_light.dds",
                ["itemDesc"] = "Companion's Jerkin",
                ["oldestTime"] = 1632979655,
                ["wasAltered"] = true,
                ["newestTime"] = 1633136489,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13333,
                        ["guild"] = 1,
                        ["buyer"] = 249,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1632979655,
                        ["quant"] = 1,
                        ["id"] = "1690129369",
                        ["itemLink"] = 259,
                    },
                    [2] = 
                    {
                        ["price"] = 13333,
                        ["guild"] = 1,
                        ["buyer"] = 1154,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633136489,
                        ["quant"] = 1,
                        ["id"] = "1691257645",
                        ["itemLink"] = 259,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior light apparel chest soothing",
            },
        },
        [176725] = 
        {
            ["1:0:3:48:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_shoulders_light.dds",
                ["itemDesc"] = "Companion's Epaulets",
                ["oldestTime"] = 1632961841,
                ["wasAltered"] = true,
                ["newestTime"] = 1633190905,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 807,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633064131,
                        ["quant"] = 1,
                        ["id"] = "1690741171",
                        ["itemLink"] = 1049,
                    },
                    [2] = 
                    {
                        ["price"] = 89999,
                        ["guild"] = 1,
                        ["buyer"] = 1418,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633190905,
                        ["quant"] = 1,
                        ["id"] = "1691698645",
                        ["itemLink"] = 1049,
                    },
                    [3] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 2637,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1632961841,
                        ["quant"] = 1,
                        ["id"] = "1689974081",
                        ["itemLink"] = 1049,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior light apparel shoulders soothing",
            },
        },
        [4439] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_wood_rough_ash.dds",
                ["itemDesc"] = "Rough Ash",
                ["oldestTime"] = 1633185030,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185030,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6755,
                        ["guild"] = 1,
                        ["buyer"] = 1389,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633185030,
                        ["quant"] = 193,
                        ["id"] = "1691629413",
                        ["itemLink"] = 1982,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [51545] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_medium_legs_d.dds",
                ["itemDesc"] = "Guards of Hunding's Rage",
                ["oldestTime"] = 1632850009,
                ["wasAltered"] = true,
                ["newestTime"] = 1632864476,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 275,
                        ["wasKiosk"] = false,
                        ["seller"] = 65,
                        ["timestamp"] = 1632850009,
                        ["quant"] = 1,
                        ["id"] = "1689144347",
                        ["itemLink"] = 3229,
                    },
                    [2] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2255,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1632864476,
                        ["quant"] = 1,
                        ["id"] = "1689261439",
                        ["itemLink"] = 3323,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic medium apparel set hunding's rage legs divines",
            },
        },
        [127070] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Redoran Spoon, Wooden",
                ["oldestTime"] = 1633291920,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291920,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9900,
                        ["guild"] = 1,
                        ["buyer"] = 90,
                        ["wasKiosk"] = false,
                        ["seller"] = 288,
                        ["timestamp"] = 1633291920,
                        ["quant"] = 1,
                        ["id"] = "1692651025",
                        ["itemLink"] = 2793,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [137823] = 
        {
            ["50:16:2:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of Hunding's Rage",
                ["oldestTime"] = 1632930973,
                ["wasAltered"] = true,
                ["newestTime"] = 1632930973,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19999,
                        ["guild"] = 1,
                        ["buyer"] = 475,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1632930973,
                        ["quant"] = 1,
                        ["id"] = "1689729041",
                        ["itemLink"] = 3713,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set hunding's rage neck robust",
            },
        },
        [68192] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Firsthold Fruit and Cheese Plate",
                ["oldestTime"] = 1633049552,
                ["wasAltered"] = true,
                ["newestTime"] = 1633282482,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20,
                        ["guild"] = 1,
                        ["buyer"] = 40,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633049552,
                        ["quant"] = 1,
                        ["id"] = "1690600099",
                        ["itemLink"] = 880,
                    },
                    [2] = 
                    {
                        ["price"] = 143,
                        ["guild"] = 1,
                        ["buyer"] = 839,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1633151653,
                        ["quant"] = 1,
                        ["id"] = "1691405327",
                        ["itemLink"] = 880,
                    },
                    [3] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1293,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1633158007,
                        ["quant"] = 1,
                        ["id"] = "1691454105",
                        ["itemLink"] = 880,
                    },
                    [4] = 
                    {
                        ["price"] = 527,
                        ["guild"] = 1,
                        ["buyer"] = 1345,
                        ["wasKiosk"] = true,
                        ["seller"] = 360,
                        ["timestamp"] = 1633172332,
                        ["quant"] = 1,
                        ["id"] = "1691532027",
                        ["itemLink"] = 880,
                    },
                    [5] = 
                    {
                        ["price"] = 15,
                        ["guild"] = 1,
                        ["buyer"] = 1488,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633200463,
                        ["quant"] = 1,
                        ["id"] = "1691794535",
                        ["itemLink"] = 880,
                    },
                    [6] = 
                    {
                        ["price"] = 20,
                        ["guild"] = 1,
                        ["buyer"] = 976,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633282482,
                        ["quant"] = 1,
                        ["id"] = "1692541063",
                        ["itemLink"] = 880,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [75361] = 
        {
            ["40:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_potion_base_oil_3_r2.dds",
                ["itemDesc"] = "Terebinthine",
                ["oldestTime"] = 1633030262,
                ["wasAltered"] = true,
                ["newestTime"] = 1633178497,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 299,
                        ["guild"] = 1,
                        ["buyer"] = 286,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633030262,
                        ["quant"] = 13,
                        ["id"] = "1690445587",
                        ["itemLink"] = 711,
                    },
                    [2] = 
                    {
                        ["price"] = 11340,
                        ["guild"] = 1,
                        ["buyer"] = 1344,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633178496,
                        ["quant"] = 81,
                        ["id"] = "1691573887",
                        ["itemLink"] = 711,
                    },
                    [3] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 1344,
                        ["wasKiosk"] = true,
                        ["seller"] = 803,
                        ["timestamp"] = 1633178497,
                        ["quant"] = 60,
                        ["id"] = "1691573889",
                        ["itemLink"] = 711,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr40 white normal materials poison solvent",
            },
        },
        [75362] = 
        {
            ["50:1:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_potion_base_oil_3_r3.dds",
                ["itemDesc"] = "Pitch-Bile",
                ["oldestTime"] = 1633185578,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185578,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11970,
                        ["guild"] = 1,
                        ["buyer"] = 1392,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633185578,
                        ["quant"] = 63,
                        ["id"] = "1691635867",
                        ["itemLink"] = 1989,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp10 white normal materials poison solvent",
            },
        },
        [71268] = 
        {
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_neck_a.dds",
                ["itemDesc"] = "Briarheart Collar",
                ["oldestTime"] = 1633206097,
                ["wasAltered"] = true,
                ["newestTime"] = 1633206097,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11557,
                        ["guild"] = 1,
                        ["buyer"] = 1526,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1633206097,
                        ["quant"] = 1,
                        ["id"] = "1691856541",
                        ["itemLink"] = 2252,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set briarheart neck healthy",
            },
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_neck_a.dds",
                ["itemDesc"] = "Briarheart Collar",
                ["oldestTime"] = 1632840361,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163916,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633163909,
                        ["quant"] = 1,
                        ["id"] = "1691490305",
                        ["itemLink"] = 1800,
                    },
                    [2] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 695,
                        ["timestamp"] = 1633163916,
                        ["quant"] = 1,
                        ["id"] = "1691490351",
                        ["itemLink"] = 1800,
                    },
                    [3] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2178,
                        ["wasKiosk"] = true,
                        ["seller"] = 8,
                        ["timestamp"] = 1632840361,
                        ["quant"] = 1,
                        ["id"] = "1689062481",
                        ["itemLink"] = 1800,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set briarheart neck healthy",
            },
        },
        [180837] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_staff_a.dds",
                ["itemDesc"] = "Hrothgar's Lightning Staff",
                ["oldestTime"] = 1633112449,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112449,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12345,
                        ["guild"] = 1,
                        ["buyer"] = 991,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633112449,
                        ["quant"] = 1,
                        ["id"] = "1691055311",
                        ["itemLink"] = 1351,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set hrothgar's chill lightning staff two-handed defending",
            },
        },
        [147303] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Prophet's Wraps",
                ["oldestTime"] = 1633172315,
                ["wasAltered"] = true,
                ["newestTime"] = 1633172315,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 1339,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1633172315,
                        ["quant"] = 1,
                        ["id"] = "1691531951",
                        ["itemLink"] = 1886,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [95594] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_light_feet_a.dds",
                ["itemDesc"] = "Shoes of Martial Knowledge",
                ["oldestTime"] = 1633022974,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022975,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633022974,
                        ["quant"] = 1,
                        ["id"] = "1690390387",
                        ["itemLink"] = 615,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633022975,
                        ["quant"] = 1,
                        ["id"] = "1690390399",
                        ["itemLink"] = 615,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior light apparel set way of martial knowledge feet sturdy",
            },
        },
        [68203] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Braised Rabbit with Spring Vegetables",
                ["oldestTime"] = 1633076260,
                ["wasAltered"] = true,
                ["newestTime"] = 1633076260,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 2,
                        ["buyer"] = 137,
                        ["wasKiosk"] = false,
                        ["seller"] = 117,
                        ["timestamp"] = 1633076260,
                        ["quant"] = 1,
                        ["id"] = "1690817975",
                        ["itemLink"] = 150,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [160620] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 88: Ancestral Orc Maces",
                ["oldestTime"] = 1632823344,
                ["wasAltered"] = true,
                ["newestTime"] = 1632970199,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 160,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632970199,
                        ["quant"] = 1,
                        ["id"] = "1690058897",
                        ["itemLink"] = 174,
                    },
                    [2] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1632823344,
                        ["quant"] = 1,
                        ["id"] = "1688957889",
                        ["itemLink"] = 174,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [51565] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_book_001.dds",
                ["itemDesc"] = "Crafting Motif 12: Barbaric Style",
                ["oldestTime"] = 1632820714,
                ["wasAltered"] = true,
                ["newestTime"] = 1633304374,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 316,
                        ["guild"] = 1,
                        ["buyer"] = 411,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633002674,
                        ["quant"] = 1,
                        ["id"] = "1690247317",
                        ["itemLink"] = 419,
                    },
                    [2] = 
                    {
                        ["price"] = 316,
                        ["guild"] = 1,
                        ["buyer"] = 1152,
                        ["wasKiosk"] = true,
                        ["seller"] = 660,
                        ["timestamp"] = 1633136344,
                        ["quant"] = 1,
                        ["id"] = "1691256595",
                        ["itemLink"] = 419,
                    },
                    [3] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 2056,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633304374,
                        ["quant"] = 1,
                        ["id"] = "1692783733",
                        ["itemLink"] = 419,
                    },
                    [4] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 2103,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1632820714,
                        ["quant"] = 1,
                        ["id"] = "1688947255",
                        ["itemLink"] = 419,
                    },
                    [5] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 2210,
                        ["wasKiosk"] = true,
                        ["seller"] = 533,
                        ["timestamp"] = 1632849304,
                        ["quant"] = 1,
                        ["id"] = "1689138259",
                        ["itemLink"] = 419,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [87918] = 
        {
            ["50:16:4:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_staff_a.dds",
                ["itemDesc"] = "Deadly Restoration Staff",
                ["oldestTime"] = 1633018744,
                ["wasAltered"] = true,
                ["newestTime"] = 1633018744,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14500,
                        ["guild"] = 1,
                        ["buyer"] = 499,
                        ["wasKiosk"] = true,
                        ["seller"] = 356,
                        ["timestamp"] = 1633018744,
                        ["quant"] = 1,
                        ["id"] = "1690356133",
                        ["itemLink"] = 571,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set deadly strike healing staff two-handed defending",
            },
        },
        [119407] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Common Cargo, Reinforced",
                ["oldestTime"] = 1633071528,
                ["wasAltered"] = true,
                ["newestTime"] = 1633071528,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 69,
                        ["guild"] = 1,
                        ["buyer"] = 847,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633071528,
                        ["quant"] = 1,
                        ["id"] = "1690787809",
                        ["itemLink"] = 1091,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [87920] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_1haxe_a.dds",
                ["itemDesc"] = "Deadly Axe",
                ["oldestTime"] = 1632883884,
                ["wasAltered"] = true,
                ["newestTime"] = 1632883884,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 2376,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1632883884,
                        ["quant"] = 1,
                        ["id"] = "1689437231",
                        ["itemLink"] = 3493,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set deadly strike axe one-handed sharpened",
            },
        },
        [58481] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_medium_feet_a.dds",
                ["itemDesc"] = "Boots of the Twice-Born Star",
                ["oldestTime"] = 1633292240,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292240,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1990,
                        ["wasKiosk"] = true,
                        ["seller"] = 832,
                        ["timestamp"] = 1633292240,
                        ["quant"] = 1,
                        ["id"] = "1692654231",
                        ["itemLink"] = 2813,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set twice-born star feet divines",
            },
        },
        [68210] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Withered Tree Inn Venison Pot Roast",
                ["oldestTime"] = 1633184419,
                ["wasAltered"] = true,
                ["newestTime"] = 1633184419,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7182,
                        ["guild"] = 1,
                        ["buyer"] = 1387,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633184419,
                        ["quant"] = 1,
                        ["id"] = "1691624149",
                        ["itemLink"] = 1974,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [88436] = 
        {
            ["50:16:3:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_2hsword_a.dds",
                ["itemDesc"] = "Greatsword of Cyrodiil's Crest",
                ["oldestTime"] = 1633052768,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052768,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9999,
                        ["guild"] = 1,
                        ["buyer"] = 718,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1633052768,
                        ["quant"] = 1,
                        ["id"] = "1690632893",
                        ["itemLink"] = 915,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set crest of cyrodiil sword two-handed sharpened",
            },
        },
        [71286] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_neck_a.dds",
                ["itemDesc"] = "Briarheart Collar",
                ["oldestTime"] = 1632870497,
                ["wasAltered"] = true,
                ["newestTime"] = 1632870497,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11500,
                        ["guild"] = 1,
                        ["buyer"] = 2289,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1632870497,
                        ["quant"] = 1,
                        ["id"] = "1689306791",
                        ["itemLink"] = 3385,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set briarheart neck arcane",
            },
            ["50:16:2:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_neck_a.dds",
                ["itemDesc"] = "Briarheart Collar",
                ["oldestTime"] = 1633183441,
                ["wasAltered"] = true,
                ["newestTime"] = 1633183441,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1381,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633183441,
                        ["quant"] = 1,
                        ["id"] = "1691616313",
                        ["itemLink"] = 1964,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set briarheart neck arcane",
            },
        },
        [147319] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Sai Sahan's Boots",
                ["oldestTime"] = 1633293802,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293802,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2002,
                        ["wasKiosk"] = true,
                        ["seller"] = 1108,
                        ["timestamp"] = 1633293802,
                        ["quant"] = 1,
                        ["id"] = "1692673549",
                        ["itemLink"] = 2859,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [171896] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 101: Ivory Brigade Axes",
                ["oldestTime"] = 1633027659,
                ["wasAltered"] = true,
                ["newestTime"] = 1633314482,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 74,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633314482,
                        ["quant"] = 1,
                        ["id"] = "1692896251",
                        ["itemLink"] = 59,
                    },
                    [2] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 551,
                        ["wasKiosk"] = true,
                        ["seller"] = 552,
                        ["timestamp"] = 1633027659,
                        ["quant"] = 1,
                        ["id"] = "1690425491",
                        ["itemLink"] = 59,
                    },
                    [3] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1196,
                        ["wasKiosk"] = true,
                        ["seller"] = 6,
                        ["timestamp"] = 1633142022,
                        ["quant"] = 1,
                        ["id"] = "1691313075",
                        ["itemLink"] = 59,
                    },
                    [4] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 514,
                        ["timestamp"] = 1633164787,
                        ["quant"] = 1,
                        ["id"] = "1691495003",
                        ["itemLink"] = 59,
                    },
                    [5] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 956,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633187504,
                        ["quant"] = 1,
                        ["id"] = "1691657299",
                        ["itemLink"] = 59,
                    },
                    [6] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 242,
                        ["wasKiosk"] = false,
                        ["seller"] = 930,
                        ["timestamp"] = 1633195641,
                        ["quant"] = 1,
                        ["id"] = "1691747601",
                        ["itemLink"] = 59,
                    },
                    [7] = 
                    {
                        ["price"] = 9990,
                        ["guild"] = 1,
                        ["buyer"] = 1570,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633214353,
                        ["quant"] = 1,
                        ["id"] = "1691953159",
                        ["itemLink"] = 59,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [176761] = 
        {
            ["1:0:4:48:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_shoulders_light.dds",
                ["itemDesc"] = "Companion's Epaulets",
                ["oldestTime"] = 1633154610,
                ["wasAltered"] = true,
                ["newestTime"] = 1633154610,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1499999,
                        ["guild"] = 1,
                        ["buyer"] = 408,
                        ["wasKiosk"] = false,
                        ["seller"] = 93,
                        ["timestamp"] = 1633154610,
                        ["quant"] = 1,
                        ["id"] = "1691428867",
                        ["itemLink"] = 1741,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic light apparel shoulders soothing",
            },
        },
        [137852] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 61: Psijic Axes",
                ["oldestTime"] = 1633305649,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305649,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11111,
                        ["guild"] = 1,
                        ["buyer"] = 2065,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1633305649,
                        ["quant"] = 1,
                        ["id"] = "1692796965",
                        ["itemLink"] = 2932,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [172158] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_hands_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Bracers",
                ["oldestTime"] = 1633088252,
                ["wasAltered"] = true,
                ["newestTime"] = 1633088252,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 912,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633088252,
                        ["quant"] = 1,
                        ["id"] = "1690877667",
                        ["itemLink"] = 1234,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set deadlands assassin hands divines",
            },
        },
        [180865] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_heavy_shoulders_a.dds",
                ["itemDesc"] = "Hrothgar's Pauldrons",
                ["oldestTime"] = 1632955312,
                ["wasAltered"] = true,
                ["newestTime"] = 1633056991,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 760,
                        ["wasKiosk"] = true,
                        ["seller"] = 356,
                        ["timestamp"] = 1633056991,
                        ["quant"] = 1,
                        ["id"] = "1690678513",
                        ["itemLink"] = 961,
                    },
                    [2] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 2609,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1632955312,
                        ["quant"] = 1,
                        ["id"] = "1689920817",
                        ["itemLink"] = 3863,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set hrothgar's chill shoulders impenetrable",
            },
        },
        [68226] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Honest Lassie Honey Tea",
                ["oldestTime"] = 1633076201,
                ["wasAltered"] = true,
                ["newestTime"] = 1633076201,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 2,
                        ["buyer"] = 137,
                        ["wasKiosk"] = false,
                        ["seller"] = 117,
                        ["timestamp"] = 1633076201,
                        ["quant"] = 1,
                        ["id"] = "1690817857",
                        ["itemLink"] = 149,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [98691] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Hist Sap",
                ["oldestTime"] = 1633163912,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163912,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1150,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633163912,
                        ["quant"] = 1,
                        ["id"] = "1691490319",
                        ["itemLink"] = 1806,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set robes of the hist ring arcane",
            },
            ["50:16:2:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Hist Sap",
                ["oldestTime"] = 1633035500,
                ["wasAltered"] = true,
                ["newestTime"] = 1633035500,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 598,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633035500,
                        ["quant"] = 1,
                        ["id"] = "1690479005",
                        ["itemLink"] = 763,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set robes of the hist ring arcane",
            },
        },
        [56965] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Savory Thorn Cornbread",
                ["oldestTime"] = 1633185115,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185115,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633185115,
                        ["quant"] = 1,
                        ["id"] = "1691630175",
                        ["itemLink"] = 1987,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [142730] = 
        {
            ["50:16:2:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_elderarg_1hsword_a.dds",
                ["itemDesc"] = "Bright-Throat's Boast Sword",
                ["oldestTime"] = 1633290748,
                ["wasAltered"] = true,
                ["newestTime"] = 1633290748,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1999,
                        ["guild"] = 1,
                        ["buyer"] = 1983,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633290748,
                        ["quant"] = 1,
                        ["id"] = "1692636073",
                        ["itemLink"] = 2784,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set bright-throat's boast sword one-handed decisive",
            },
        },
        [97088] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_staff_d.dds",
                ["itemDesc"] = "Plague Doctor's Restoration Staff",
                ["oldestTime"] = 1632964779,
                ["wasAltered"] = true,
                ["newestTime"] = 1632964779,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1655,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1632964779,
                        ["quant"] = 1,
                        ["id"] = "1690003889",
                        ["itemLink"] = 3947,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set plague doctor healing staff two-handed precise",
            },
        },
        [125908] = 
        {
            ["50:16:4:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_2haxe_a.dds",
                ["itemDesc"] = "Impregnable Armor Battle Axe",
                ["oldestTime"] = 1632964367,
                ["wasAltered"] = true,
                ["newestTime"] = 1632964367,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2650,
                        ["wasKiosk"] = true,
                        ["seller"] = 531,
                        ["timestamp"] = 1632964367,
                        ["quant"] = 1,
                        ["id"] = "1689999085",
                        ["itemLink"] = 3944,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set impregnable armor axe two-handed decisive",
            },
        },
        [144830] = 
        {
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Battalion Defender Necklace",
                ["oldestTime"] = 1632949196,
                ["wasAltered"] = true,
                ["newestTime"] = 1632949196,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2580,
                        ["wasKiosk"] = true,
                        ["seller"] = 785,
                        ["timestamp"] = 1632949196,
                        ["quant"] = 1,
                        ["id"] = "1689867471",
                        ["itemLink"] = 3805,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set battalion defender neck healthy",
            },
        },
        [43631] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Grahtwood Treasure Map I",
                ["oldestTime"] = 1632943738,
                ["wasAltered"] = true,
                ["newestTime"] = 1632943738,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2188,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1632943738,
                        ["quant"] = 1,
                        ["id"] = "1689824815",
                        ["itemLink"] = 3782,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [71568] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 23: Malacath Belts",
                ["oldestTime"] = 1632852083,
                ["wasAltered"] = true,
                ["newestTime"] = 1633214058,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1279,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633155360,
                        ["quant"] = 1,
                        ["id"] = "1691433861",
                        ["itemLink"] = 1744,
                    },
                    [2] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1571,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633214058,
                        ["quant"] = 1,
                        ["id"] = "1691950201",
                        ["itemLink"] = 1744,
                    },
                    [3] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 261,
                        ["timestamp"] = 1632852083,
                        ["quant"] = 1,
                        ["id"] = "1689159841",
                        ["itemLink"] = 1744,
                    },
                    [4] = 
                    {
                        ["price"] = 11181,
                        ["guild"] = 1,
                        ["buyer"] = 1872,
                        ["wasKiosk"] = true,
                        ["seller"] = 765,
                        ["timestamp"] = 1632941321,
                        ["quant"] = 1,
                        ["id"] = "1689804533",
                        ["itemLink"] = 1744,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [51345] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_book_001.dds",
                ["itemDesc"] = "Crafting Motif 13: Primal Style",
                ["oldestTime"] = 1632820729,
                ["wasAltered"] = true,
                ["newestTime"] = 1633304580,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 434,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633008111,
                        ["quant"] = 1,
                        ["id"] = "1690277515",
                        ["itemLink"] = 442,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1180,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1633140070,
                        ["quant"] = 1,
                        ["id"] = "1691290779",
                        ["itemLink"] = 442,
                    },
                    [3] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2056,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633304360,
                        ["quant"] = 1,
                        ["id"] = "1692783527",
                        ["itemLink"] = 442,
                    },
                    [4] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 2062,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633304580,
                        ["quant"] = 1,
                        ["id"] = "1692786077",
                        ["itemLink"] = 442,
                    },
                    [5] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2103,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1632820729,
                        ["quant"] = 1,
                        ["id"] = "1688947375",
                        ["itemLink"] = 442,
                    },
                    [6] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2210,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632849265,
                        ["quant"] = 1,
                        ["id"] = "1689138163",
                        ["itemLink"] = 442,
                    },
                    [7] = 
                    {
                        ["price"] = 555,
                        ["guild"] = 1,
                        ["buyer"] = 2273,
                        ["wasKiosk"] = true,
                        ["seller"] = 494,
                        ["timestamp"] = 1632867103,
                        ["quant"] = 1,
                        ["id"] = "1689282001",
                        ["itemLink"] = 442,
                    },
                    [8] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2103,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1632899014,
                        ["quant"] = 1,
                        ["id"] = "1689552489",
                        ["itemLink"] = 442,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [149065] = 
        {
            ["50:16:4:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_2hsword_a.dds",
                ["itemDesc"] = "Undertaker's Greatsword",
                ["oldestTime"] = 1632943230,
                ["wasAltered"] = true,
                ["newestTime"] = 1632943230,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6365,
                        ["guild"] = 1,
                        ["buyer"] = 464,
                        ["wasKiosk"] = true,
                        ["seller"] = 626,
                        ["timestamp"] = 1632943230,
                        ["quant"] = 1,
                        ["id"] = "1689819533",
                        ["itemLink"] = 3779,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set call of the undertaker sword two-handed infused",
            },
        },
        [180905] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_heavy_shoulders_a.dds",
                ["itemDesc"] = "Hrothgar's Pauldrons",
                ["oldestTime"] = 1632933237,
                ["wasAltered"] = true,
                ["newestTime"] = 1632933237,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3300,
                        ["guild"] = 1,
                        ["buyer"] = 63,
                        ["wasKiosk"] = false,
                        ["seller"] = 408,
                        ["timestamp"] = 1632933237,
                        ["quant"] = 1,
                        ["id"] = "1689745781",
                        ["itemLink"] = 3720,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set hrothgar's chill shoulders sturdy",
            },
        },
        [68214] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Heart's Day Rose Tea",
                ["oldestTime"] = 1633261630,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261630,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633261630,
                        ["quant"] = 1,
                        ["id"] = "1692334517",
                        ["itemLink"] = 2625,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [180885] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_heavy_shoulders_a.dds",
                ["itemDesc"] = "Hrothgar's Pauldrons",
                ["oldestTime"] = 1632830312,
                ["wasAltered"] = true,
                ["newestTime"] = 1632830312,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2134,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1632830312,
                        ["quant"] = 1,
                        ["id"] = "1689000361",
                        ["itemLink"] = 3074,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set hrothgar's chill shoulders invigorating",
            },
        },
        [176022] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Wagon, Covered",
                ["oldestTime"] = 1633292348,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292348,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 340000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 1082,
                        ["timestamp"] = 1633292348,
                        ["quant"] = 1,
                        ["id"] = "1692655581",
                        ["itemLink"] = 2823,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [172951] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_medium_legs_d.dds",
                ["itemDesc"] = "Heartland Conqueror's Guards",
                ["oldestTime"] = 1633268447,
                ["wasAltered"] = true,
                ["newestTime"] = 1633268447,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9997,
                        ["guild"] = 1,
                        ["buyer"] = 1691,
                        ["wasKiosk"] = true,
                        ["seller"] = 220,
                        ["timestamp"] = 1633268447,
                        ["quant"] = 1,
                        ["id"] = "1692389347",
                        ["itemLink"] = 2659,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set heartland conqueror legs divines",
            },
        },
        [69528] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 21: Ancient Orc Axes",
                ["oldestTime"] = 1633127603,
                ["wasAltered"] = true,
                ["newestTime"] = 1633216795,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1094,
                        ["wasKiosk"] = true,
                        ["seller"] = 911,
                        ["timestamp"] = 1633127603,
                        ["quant"] = 1,
                        ["id"] = "1691164525",
                        ["itemLink"] = 1494,
                    },
                    [2] = 
                    {
                        ["price"] = 14160,
                        ["guild"] = 1,
                        ["buyer"] = 1592,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633216795,
                        ["quant"] = 1,
                        ["id"] = "1691976551",
                        ["itemLink"] = 1494,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45581] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: West Weald Wallop",
                ["oldestTime"] = 1632923724,
                ["wasAltered"] = true,
                ["newestTime"] = 1632923724,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632923724,
                        ["quant"] = 1,
                        ["id"] = "1689677415",
                        ["itemLink"] = 3672,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45210] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_light_head_d.dds",
                ["itemDesc"] = "Ancestor Silk Hat of Magicka",
                ["oldestTime"] = 1633022969,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022977,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633022969,
                        ["quant"] = 1,
                        ["id"] = "1690390329",
                        ["itemLink"] = 609,
                    },
                    [2] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633022977,
                        ["quant"] = 1,
                        ["id"] = "1690390423",
                        ["itemLink"] = 617,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine light apparel head infused",
            },
        },
        [176027] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Deadlands Bookcase, Ashen",
                ["oldestTime"] = 1633190544,
                ["wasAltered"] = true,
                ["newestTime"] = 1633190544,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 450,
                        ["wasKiosk"] = true,
                        ["seller"] = 71,
                        ["timestamp"] = 1633190544,
                        ["quant"] = 1,
                        ["id"] = "1691693769",
                        ["itemLink"] = 2099,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [123843] = 
        {
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_light_hands_a.dds",
                ["itemDesc"] = "Wizard's Riposte Gloves",
                ["oldestTime"] = 1632910906,
                ["wasAltered"] = true,
                ["newestTime"] = 1632910906,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2459,
                        ["wasKiosk"] = true,
                        ["seller"] = 827,
                        ["timestamp"] = 1632910906,
                        ["quant"] = 1,
                        ["id"] = "1689604043",
                        ["itemLink"] = 3607,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set wizard's riposte hands invigorating",
            },
        },
        [99466] = 
        {
            ["22:0:2:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of the Order of Diagna",
                ["oldestTime"] = 1632875832,
                ["wasAltered"] = true,
                ["newestTime"] = 1632875832,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 745,
                        ["guild"] = 1,
                        ["buyer"] = 2325,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1632875832,
                        ["quant"] = 1,
                        ["id"] = "1689350357",
                        ["itemLink"] = 3422,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr22 green fine jewelry apparel set order of diagna neck healthy",
            },
        },
        [149406] = 
        {
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_pellitine_light_legs_a.dds",
                ["itemDesc"] = "Crafty Alfiq's Breeches",
                ["oldestTime"] = 1633191084,
                ["wasAltered"] = true,
                ["newestTime"] = 1633191084,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1350,
                        ["guild"] = 1,
                        ["buyer"] = 1420,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633191084,
                        ["quant"] = 1,
                        ["id"] = "1691700957",
                        ["itemLink"] = 2106,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set crafty alfiq legs training",
            },
        },
        [27039] = 
        {
            ["50:15:1:9:1245443"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/consumable_potion_008_type_005.dds",
                ["itemDesc"] = "Essence of Immovability",
                ["oldestTime"] = 1632927526,
                ["wasAltered"] = true,
                ["newestTime"] = 1633151649,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4832,
                        ["guild"] = 1,
                        ["buyer"] = 1266,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633151649,
                        ["quant"] = 16,
                        ["id"] = "1691405281",
                        ["itemLink"] = 1730,
                    },
                    [2] = 
                    {
                        ["price"] = 77000,
                        ["guild"] = 1,
                        ["buyer"] = 2507,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1632927526,
                        ["quant"] = 200,
                        ["id"] = "1689704405",
                        ["itemLink"] = 1730,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp150 white normal consumable potion",
            },
        },
        [54176] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_runecrafter_potion_sp_name_001.dds",
                ["itemDesc"] = "Elegant Lining",
                ["oldestTime"] = 1632819728,
                ["wasAltered"] = true,
                ["newestTime"] = 1633281965,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1332,
                        ["guild"] = 1,
                        ["buyer"] = 270,
                        ["wasKiosk"] = true,
                        ["seller"] = 271,
                        ["timestamp"] = 1632981410,
                        ["quant"] = 4,
                        ["id"] = "1690138637",
                        ["itemLink"] = 282,
                    },
                    [2] = 
                    {
                        ["price"] = 1332,
                        ["guild"] = 1,
                        ["buyer"] = 270,
                        ["wasKiosk"] = true,
                        ["seller"] = 271,
                        ["timestamp"] = 1632981414,
                        ["quant"] = 4,
                        ["id"] = "1690138663",
                        ["itemLink"] = 282,
                    },
                    [3] = 
                    {
                        ["price"] = 44700,
                        ["guild"] = 1,
                        ["buyer"] = 350,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1632993531,
                        ["quant"] = 149,
                        ["id"] = "1690203325",
                        ["itemLink"] = 282,
                    },
                    [4] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633064532,
                        ["quant"] = 20,
                        ["id"] = "1690744683",
                        ["itemLink"] = 282,
                    },
                    [5] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633064533,
                        ["quant"] = 20,
                        ["id"] = "1690744689",
                        ["itemLink"] = 282,
                    },
                    [6] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633064534,
                        ["quant"] = 20,
                        ["id"] = "1690744697",
                        ["itemLink"] = 282,
                    },
                    [7] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633064535,
                        ["quant"] = 20,
                        ["id"] = "1690744703",
                        ["itemLink"] = 282,
                    },
                    [8] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633064535,
                        ["quant"] = 20,
                        ["id"] = "1690744709",
                        ["itemLink"] = 282,
                    },
                    [9] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633064537,
                        ["quant"] = 20,
                        ["id"] = "1690744725",
                        ["itemLink"] = 282,
                    },
                    [10] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633064538,
                        ["quant"] = 20,
                        ["id"] = "1690744735",
                        ["itemLink"] = 282,
                    },
                    [11] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633064540,
                        ["quant"] = 20,
                        ["id"] = "1690744775",
                        ["itemLink"] = 282,
                    },
                    [12] = 
                    {
                        ["price"] = 1332,
                        ["guild"] = 1,
                        ["buyer"] = 677,
                        ["wasKiosk"] = true,
                        ["seller"] = 271,
                        ["timestamp"] = 1633067710,
                        ["quant"] = 4,
                        ["id"] = "1690765727",
                        ["itemLink"] = 282,
                    },
                    [13] = 
                    {
                        ["price"] = 1332,
                        ["guild"] = 1,
                        ["buyer"] = 677,
                        ["wasKiosk"] = true,
                        ["seller"] = 271,
                        ["timestamp"] = 1633067712,
                        ["quant"] = 4,
                        ["id"] = "1690765745",
                        ["itemLink"] = 282,
                    },
                    [14] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 436,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633118377,
                        ["quant"] = 4,
                        ["id"] = "1691094275",
                        ["itemLink"] = 282,
                    },
                    [15] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 436,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633118379,
                        ["quant"] = 4,
                        ["id"] = "1691094291",
                        ["itemLink"] = 282,
                    },
                    [16] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 436,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633118381,
                        ["quant"] = 4,
                        ["id"] = "1691094309",
                        ["itemLink"] = 282,
                    },
                    [17] = 
                    {
                        ["price"] = 2412,
                        ["guild"] = 1,
                        ["buyer"] = 1155,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633136539,
                        ["quant"] = 8,
                        ["id"] = "1691257925",
                        ["itemLink"] = 282,
                    },
                    [18] = 
                    {
                        ["price"] = 32400,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633190111,
                        ["quant"] = 108,
                        ["id"] = "1691688813",
                        ["itemLink"] = 282,
                    },
                    [19] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 508,
                        ["wasKiosk"] = false,
                        ["seller"] = 75,
                        ["timestamp"] = 1633211209,
                        ["quant"] = 20,
                        ["id"] = "1691917497",
                        ["itemLink"] = 282,
                    },
                    [20] = 
                    {
                        ["price"] = 9300,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633280944,
                        ["quant"] = 31,
                        ["id"] = "1692524301",
                        ["itemLink"] = 282,
                    },
                    [21] = 
                    {
                        ["price"] = 1332,
                        ["guild"] = 1,
                        ["buyer"] = 1936,
                        ["wasKiosk"] = true,
                        ["seller"] = 271,
                        ["timestamp"] = 1633281965,
                        ["quant"] = 4,
                        ["id"] = "1692536787",
                        ["itemLink"] = 282,
                    },
                    [22] = 
                    {
                        ["price"] = 330,
                        ["guild"] = 1,
                        ["buyer"] = 285,
                        ["wasKiosk"] = false,
                        ["seller"] = 944,
                        ["timestamp"] = 1632819728,
                        ["quant"] = 1,
                        ["id"] = "1688942113",
                        ["itemLink"] = 282,
                    },
                    [23] = 
                    {
                        ["price"] = 69999,
                        ["guild"] = 1,
                        ["buyer"] = 1497,
                        ["wasKiosk"] = false,
                        ["seller"] = 330,
                        ["timestamp"] = 1632837954,
                        ["quant"] = 200,
                        ["id"] = "1689047033",
                        ["itemLink"] = 282,
                    },
                    [24] = 
                    {
                        ["price"] = 1332,
                        ["guild"] = 1,
                        ["buyer"] = 2338,
                        ["wasKiosk"] = true,
                        ["seller"] = 271,
                        ["timestamp"] = 1632877789,
                        ["quant"] = 4,
                        ["id"] = "1689370765",
                        ["itemLink"] = 282,
                    },
                    [25] = 
                    {
                        ["price"] = 4648,
                        ["guild"] = 1,
                        ["buyer"] = 2363,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1632881859,
                        ["quant"] = 14,
                        ["id"] = "1689416443",
                        ["itemLink"] = 282,
                    },
                    [26] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 75,
                        ["timestamp"] = 1632889916,
                        ["quant"] = 20,
                        ["id"] = "1689491715",
                        ["itemLink"] = 282,
                    },
                    [27] = 
                    {
                        ["price"] = 12760,
                        ["guild"] = 1,
                        ["buyer"] = 2484,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632920529,
                        ["quant"] = 40,
                        ["id"] = "1689654607",
                        ["itemLink"] = 282,
                    },
                },
                ["totalCount"] = 27,
                ["itemAdderText"] = "rr01 purple epic materials tannin",
            },
        },
        [165715] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_con_smallbox001.dds",
                ["itemDesc"] = "Solitude Jewelry Box, Wolf's-Head",
                ["oldestTime"] = 1633200990,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200990,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 1492,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633200990,
                        ["quant"] = 1,
                        ["id"] = "1691800463",
                        ["itemLink"] = 2207,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings parlor",
            },
        },
        [149432] = 
        {
            ["50:16:2:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Darloc Brae's Amulet",
                ["oldestTime"] = 1632875548,
                ["wasAltered"] = true,
                ["newestTime"] = 1632875548,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 595,
                        ["guild"] = 1,
                        ["buyer"] = 2325,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1632875548,
                        ["quant"] = 1,
                        ["id"] = "1689347299",
                        ["itemLink"] = 3417,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set vesture of darloc brae neck robust",
            },
        },
        [135162] = 
        {
            ["50:16:2:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Gloom-Graced Ring",
                ["oldestTime"] = 1632875541,
                ["wasAltered"] = true,
                ["newestTime"] = 1632875541,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 512,
                        ["guild"] = 1,
                        ["buyer"] = 2325,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1632875541,
                        ["quant"] = 1,
                        ["id"] = "1689347167",
                        ["itemLink"] = 3416,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set grace of gloom ring healthy",
            },
        },
        [54180] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_wood_mastic.dds",
                ["itemDesc"] = "Mastic",
                ["oldestTime"] = 1632848385,
                ["wasAltered"] = true,
                ["newestTime"] = 1633313593,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6250,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633313593,
                        ["quant"] = 5,
                        ["id"] = "1692886657",
                        ["itemLink"] = 40,
                    },
                    [2] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 428,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633007189,
                        ["quant"] = 50,
                        ["id"] = "1690272223",
                        ["itemLink"] = 40,
                    },
                    [3] = 
                    {
                        ["price"] = 4800,
                        ["guild"] = 1,
                        ["buyer"] = 616,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1633061758,
                        ["quant"] = 4,
                        ["id"] = "1690723563",
                        ["itemLink"] = 40,
                    },
                    [4] = 
                    {
                        ["price"] = 4800,
                        ["guild"] = 1,
                        ["buyer"] = 616,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1633061760,
                        ["quant"] = 4,
                        ["id"] = "1690723577",
                        ["itemLink"] = 40,
                    },
                    [5] = 
                    {
                        ["price"] = 4800,
                        ["guild"] = 1,
                        ["buyer"] = 616,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1633061761,
                        ["quant"] = 4,
                        ["id"] = "1690723593",
                        ["itemLink"] = 40,
                    },
                    [6] = 
                    {
                        ["price"] = 4800,
                        ["guild"] = 1,
                        ["buyer"] = 616,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1633061762,
                        ["quant"] = 4,
                        ["id"] = "1690723617",
                        ["itemLink"] = 40,
                    },
                    [7] = 
                    {
                        ["price"] = 4800,
                        ["guild"] = 1,
                        ["buyer"] = 616,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1633061763,
                        ["quant"] = 4,
                        ["id"] = "1690723633",
                        ["itemLink"] = 40,
                    },
                    [8] = 
                    {
                        ["price"] = 12500,
                        ["guild"] = 1,
                        ["buyer"] = 890,
                        ["wasKiosk"] = true,
                        ["seller"] = 732,
                        ["timestamp"] = 1633083069,
                        ["quant"] = 10,
                        ["id"] = "1690850531",
                        ["itemLink"] = 40,
                    },
                    [9] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 436,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633118390,
                        ["quant"] = 4,
                        ["id"] = "1691094371",
                        ["itemLink"] = 40,
                    },
                    [10] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1054,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633121505,
                        ["quant"] = 1,
                        ["id"] = "1691115435",
                        ["itemLink"] = 40,
                    },
                    [11] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 1274,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633154116,
                        ["quant"] = 10,
                        ["id"] = "1691424351",
                        ["itemLink"] = 40,
                    },
                    [12] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 494,
                        ["wasKiosk"] = false,
                        ["seller"] = 1480,
                        ["timestamp"] = 1633204720,
                        ["quant"] = 4,
                        ["id"] = "1691840055",
                        ["itemLink"] = 40,
                    },
                    [13] = 
                    {
                        ["price"] = 4400,
                        ["guild"] = 1,
                        ["buyer"] = 1744,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633238086,
                        ["quant"] = 4,
                        ["id"] = "1692186237",
                        ["itemLink"] = 40,
                    },
                    [14] = 
                    {
                        ["price"] = 4400,
                        ["guild"] = 1,
                        ["buyer"] = 1744,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633238089,
                        ["quant"] = 4,
                        ["id"] = "1692186245",
                        ["itemLink"] = 40,
                    },
                    [15] = 
                    {
                        ["price"] = 4400,
                        ["guild"] = 1,
                        ["buyer"] = 1744,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633238092,
                        ["quant"] = 4,
                        ["id"] = "1692186253",
                        ["itemLink"] = 40,
                    },
                    [16] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1853,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633265251,
                        ["quant"] = 1,
                        ["id"] = "1692361649",
                        ["itemLink"] = 40,
                    },
                    [17] = 
                    {
                        ["price"] = 390000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 1318,
                        ["timestamp"] = 1632848385,
                        ["quant"] = 200,
                        ["id"] = "1689131283",
                        ["itemLink"] = 40,
                    },
                    [18] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2314,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632874272,
                        ["quant"] = 1,
                        ["id"] = "1689333647",
                        ["itemLink"] = 40,
                    },
                    [19] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 75,
                        ["timestamp"] = 1632889911,
                        ["quant"] = 10,
                        ["id"] = "1689491699",
                        ["itemLink"] = 40,
                    },
                    [20] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 75,
                        ["timestamp"] = 1632889912,
                        ["quant"] = 10,
                        ["id"] = "1689491703",
                        ["itemLink"] = 40,
                    },
                    [21] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 2422,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1632892407,
                        ["quant"] = 10,
                        ["id"] = "1689511985",
                        ["itemLink"] = 40,
                    },
                    [22] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 2422,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1632892408,
                        ["quant"] = 10,
                        ["id"] = "1689511987",
                        ["itemLink"] = 40,
                    },
                    [23] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632919248,
                        ["quant"] = 11,
                        ["id"] = "1689647775",
                        ["itemLink"] = 40,
                    },
                },
                ["totalCount"] = 23,
                ["itemAdderText"] = "rr01 purple epic materials resin",
            },
        },
        [100517] = 
        {
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_light_feet_d.dds",
                ["itemDesc"] = "Vampire Lord's Shoes",
                ["oldestTime"] = 1632856866,
                ["wasAltered"] = true,
                ["newestTime"] = 1632856866,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2238,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1632856866,
                        ["quant"] = 1,
                        ["id"] = "1689204807",
                        ["itemLink"] = 3275,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set vampire lord feet invigorating",
            },
        },
        [172198] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_hands_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Bracers",
                ["oldestTime"] = 1633094759,
                ["wasAltered"] = true,
                ["newestTime"] = 1633094759,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 713,
                        ["guild"] = 1,
                        ["buyer"] = 63,
                        ["wasKiosk"] = false,
                        ["seller"] = 662,
                        ["timestamp"] = 1633094759,
                        ["quant"] = 1,
                        ["id"] = "1690917505",
                        ["itemLink"] = 1254,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set deadlands assassin hands reinforced",
            },
        },
        [57037] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Dreugh Spit",
                ["oldestTime"] = 1632875167,
                ["wasAltered"] = true,
                ["newestTime"] = 1632875167,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 144,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1632875167,
                        ["quant"] = 1,
                        ["id"] = "1689342999",
                        ["itemLink"] = 3412,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [152077] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Elsweyr Streetlight, Inlaid Stone",
                ["oldestTime"] = 1632865590,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865590,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 2194,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632865590,
                        ["quant"] = 1,
                        ["id"] = "1689269295",
                        ["itemLink"] = 3357,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [74921] = 
        {
            ["50:16:3:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_bow_a.dds",
                ["itemDesc"] = "Bow of the Shadow Dancer",
                ["oldestTime"] = 1633125835,
                ["wasAltered"] = true,
                ["newestTime"] = 1633125835,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 1084,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633125835,
                        ["quant"] = 1,
                        ["id"] = "1691148611",
                        ["itemLink"] = 1481,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set shadow dancer's raiment bow two-handed sharpened",
            },
        },
        [139644] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Alinor Tapestry, Alinor Dusk",
                ["oldestTime"] = 1632865550,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865550,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1632865550,
                        ["quant"] = 1,
                        ["id"] = "1689268999",
                        ["itemLink"] = 3351,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [116160] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Nord Shelf, Braced",
                ["oldestTime"] = 1633058544,
                ["wasAltered"] = true,
                ["newestTime"] = 1633058544,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 776,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633058544,
                        ["quant"] = 1,
                        ["id"] = "1690695627",
                        ["itemLink"] = 988,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [94380] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_2hhammer_d.dds",
                ["itemDesc"] = "Maul of the Veiled Heritance",
                ["oldestTime"] = 1633131396,
                ["wasAltered"] = true,
                ["newestTime"] = 1633131396,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 899,
                        ["guild"] = 1,
                        ["buyer"] = 1111,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633131396,
                        ["quant"] = 1,
                        ["id"] = "1691201491",
                        ["itemLink"] = 1519,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set armor of the veiled heritance mace two-handed decisive",
            },
        },
        [155254] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dragonguardmed_legs_a.dds",
                ["itemDesc"] = "Dragonguard Elite's Guards",
                ["oldestTime"] = 1632862308,
                ["wasAltered"] = true,
                ["newestTime"] = 1632862308,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1583,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1632862308,
                        ["quant"] = 1,
                        ["id"] = "1689246483",
                        ["itemLink"] = 3314,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set dragonguard elite legs divines",
            },
        },
        [118190] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bre_con_cratesmall004.dds",
                ["itemDesc"] = "Basket of Corn",
                ["oldestTime"] = 1633278763,
                ["wasAltered"] = true,
                ["newestTime"] = 1633278763,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1917,
                        ["wasKiosk"] = true,
                        ["seller"] = 17,
                        ["timestamp"] = 1633278763,
                        ["quant"] = 1,
                        ["id"] = "1692503189",
                        ["itemLink"] = 2723,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings hearth",
            },
        },
        [115243] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bre_lsb_canwallsimple001.dds",
                ["itemDesc"] = "Breton Sconce, Wall",
                ["oldestTime"] = 1633238197,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238197,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30710,
                        ["guild"] = 1,
                        ["buyer"] = 1746,
                        ["wasKiosk"] = true,
                        ["seller"] = 99,
                        ["timestamp"] = 1633238197,
                        ["quant"] = 2,
                        ["id"] = "1692186757",
                        ["itemLink"] = 2507,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [135344] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Gryphon's Ring",
                ["oldestTime"] = 1633042156,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163919,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 646,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633042156,
                        ["quant"] = 1,
                        ["id"] = "1690529813",
                        ["itemLink"] = 812,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 646,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633042157,
                        ["quant"] = 1,
                        ["id"] = "1690529823",
                        ["itemLink"] = 812,
                    },
                    [3] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 51,
                        ["timestamp"] = 1633163909,
                        ["quant"] = 1,
                        ["id"] = "1691490301",
                        ["itemLink"] = 812,
                    },
                    [4] = 
                    {
                        ["price"] = 1580,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 649,
                        ["timestamp"] = 1633163919,
                        ["quant"] = 1,
                        ["id"] = "1691490371",
                        ["itemLink"] = 812,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set gryphon's ferocity ring robust",
            },
        },
        [42862] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_slaughterfish.dds",
                ["itemDesc"] = "Trodh",
                ["oldestTime"] = 1632904244,
                ["wasAltered"] = true,
                ["newestTime"] = 1633095887,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 120000,
                        ["guild"] = 1,
                        ["buyer"] = 928,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1633095881,
                        ["quant"] = 200,
                        ["id"] = "1690925943",
                        ["itemLink"] = 1264,
                    },
                    [2] = 
                    {
                        ["price"] = 72385,
                        ["guild"] = 1,
                        ["buyer"] = 928,
                        ["wasKiosk"] = true,
                        ["seller"] = 159,
                        ["timestamp"] = 1633095887,
                        ["quant"] = 100,
                        ["id"] = "1690926023",
                        ["itemLink"] = 1264,
                    },
                    [3] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 218,
                        ["timestamp"] = 1632904244,
                        ["quant"] = 20,
                        ["id"] = "1689579603",
                        ["itemLink"] = 1264,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal consumable fish",
            },
        },
        [116106] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning3.dds",
                ["itemDesc"] = "Design: Khajiit Jug, Amber",
                ["oldestTime"] = 1632843088,
                ["wasAltered"] = true,
                ["newestTime"] = 1632843088,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1361,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1632843088,
                        ["quant"] = 1,
                        ["id"] = "1689084817",
                        ["itemLink"] = 3166,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [95667] = 
        {
            ["50:16:4:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_1hsword_a.dds",
                ["itemDesc"] = "Sword of the Air",
                ["oldestTime"] = 1632990202,
                ["wasAltered"] = true,
                ["newestTime"] = 1632990202,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1632990202,
                        ["quant"] = 1,
                        ["id"] = "1690188289",
                        ["itemLink"] = 347,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set way of air sword one-handed powered",
            },
        },
        [93781] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_medium_shoulders_a.dds",
                ["itemDesc"] = "Arm Cops of Cyrodiil's Ward",
                ["oldestTime"] = 1632836267,
                ["wasAltered"] = true,
                ["newestTime"] = 1632836267,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 2160,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1632836267,
                        ["quant"] = 1,
                        ["id"] = "1689036091",
                        ["itemLink"] = 3110,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set ward of cyrodiil shoulders well-fitted",
            },
        },
        [118958] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: High Elf Bed, Verdant",
                ["oldestTime"] = 1632836161,
                ["wasAltered"] = true,
                ["newestTime"] = 1632836161,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2158,
                        ["wasKiosk"] = true,
                        ["seller"] = 100,
                        ["timestamp"] = 1632836161,
                        ["quant"] = 1,
                        ["id"] = "1689035077",
                        ["itemLink"] = 3103,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [141737] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/notes_004.dds",
                ["itemDesc"] = "Welkynar Style Motif Fragment",
                ["oldestTime"] = 1632820057,
                ["wasAltered"] = true,
                ["newestTime"] = 1632854099,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1498,
                        ["guild"] = 1,
                        ["buyer"] = 2101,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632820057,
                        ["quant"] = 2,
                        ["id"] = "1688944547",
                        ["itemLink"] = 3011,
                    },
                    [2] = 
                    {
                        ["price"] = 5992,
                        ["guild"] = 1,
                        ["buyer"] = 2101,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632854099,
                        ["quant"] = 8,
                        ["id"] = "1689176381",
                        ["itemLink"] = 3011,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [175569] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Ja'zennji Siir Bracers",
                ["oldestTime"] = 1633298427,
                ["wasAltered"] = true,
                ["newestTime"] = 1633298427,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1803,
                        ["guild"] = 1,
                        ["buyer"] = 48,
                        ["wasKiosk"] = false,
                        ["seller"] = 1161,
                        ["timestamp"] = 1633298427,
                        ["quant"] = 1,
                        ["id"] = "1692725477",
                        ["itemLink"] = 2904,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [160952] = 
        {
            ["50:16:4:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_grayhost_staff_a.dds",
                ["itemDesc"] = "Venomous Ice Staff",
                ["oldestTime"] = 1633181611,
                ["wasAltered"] = true,
                ["newestTime"] = 1633181611,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1360,
                        ["wasKiosk"] = true,
                        ["seller"] = 531,
                        ["timestamp"] = 1633181611,
                        ["quant"] = 1,
                        ["id"] = "1691600411",
                        ["itemLink"] = 1930,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set venomous smite frost staff two-handed decisive",
            },
        },
        [147641] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_fan_giantginger001.dds",
                ["itemDesc"] = "Garlas Alpinia, Tall",
                ["oldestTime"] = 1633141010,
                ["wasAltered"] = true,
                ["newestTime"] = 1633141010,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1299,
                        ["guild"] = 1,
                        ["buyer"] = 1187,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633141010,
                        ["quant"] = 1,
                        ["id"] = "1691301267",
                        ["itemLink"] = 1611,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings conservatory",
            },
        },
        [167354] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting2.dds",
                ["itemDesc"] = "Praxis: Solitude Wall, Low Stone",
                ["oldestTime"] = 1633014700,
                ["wasAltered"] = true,
                ["newestTime"] = 1633014700,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 467,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1633014700,
                        ["quant"] = 1,
                        ["id"] = "1690323585",
                        ["itemLink"] = 532,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [167867] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_waywardguardianmed_legs_a.dds",
                ["itemDesc"] = "Witch-Knight's Guards",
                ["oldestTime"] = 1633280810,
                ["wasAltered"] = true,
                ["newestTime"] = 1633280810,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1928,
                        ["wasKiosk"] = true,
                        ["seller"] = 896,
                        ["timestamp"] = 1633280810,
                        ["quant"] = 1,
                        ["id"] = "1692523241",
                        ["itemLink"] = 2732,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set witch-knight's defiance legs impenetrable",
            },
        },
        [175548] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Blackwood Treasure Map II",
                ["oldestTime"] = 1632999537,
                ["wasAltered"] = true,
                ["newestTime"] = 1633284043,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 392,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1632999537,
                        ["quant"] = 1,
                        ["id"] = "1690230877",
                        ["itemLink"] = 391,
                    },
                    [2] = 
                    {
                        ["price"] = 32350,
                        ["guild"] = 1,
                        ["buyer"] = 595,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1633035264,
                        ["quant"] = 1,
                        ["id"] = "1690477937",
                        ["itemLink"] = 391,
                    },
                    [3] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 397,
                        ["wasKiosk"] = false,
                        ["seller"] = 513,
                        ["timestamp"] = 1633036073,
                        ["quant"] = 1,
                        ["id"] = "1690484267",
                        ["itemLink"] = 391,
                    },
                    [4] = 
                    {
                        ["price"] = 39995,
                        ["guild"] = 1,
                        ["buyer"] = 694,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1633049584,
                        ["quant"] = 1,
                        ["id"] = "1690600657",
                        ["itemLink"] = 391,
                    },
                    [5] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 491,
                        ["timestamp"] = 1633057629,
                        ["quant"] = 1,
                        ["id"] = "1690686945",
                        ["itemLink"] = 391,
                    },
                    [6] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 351,
                        ["timestamp"] = 1633057630,
                        ["quant"] = 1,
                        ["id"] = "1690686957",
                        ["itemLink"] = 391,
                    },
                    [7] = 
                    {
                        ["price"] = 55500,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 162,
                        ["timestamp"] = 1633057665,
                        ["quant"] = 1,
                        ["id"] = "1690687253",
                        ["itemLink"] = 391,
                    },
                    [8] = 
                    {
                        ["price"] = 49000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 763,
                        ["timestamp"] = 1633075826,
                        ["quant"] = 1,
                        ["id"] = "1690815847",
                        ["itemLink"] = 391,
                    },
                    [9] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 1235,
                        ["timestamp"] = 1633146745,
                        ["quant"] = 1,
                        ["id"] = "1691363287",
                        ["itemLink"] = 391,
                    },
                    [10] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 521,
                        ["timestamp"] = 1633156799,
                        ["quant"] = 1,
                        ["id"] = "1691444673",
                        ["itemLink"] = 391,
                    },
                    [11] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 332,
                        ["wasKiosk"] = false,
                        ["seller"] = 709,
                        ["timestamp"] = 1633211969,
                        ["quant"] = 1,
                        ["id"] = "1691928533",
                        ["itemLink"] = 391,
                    },
                    [12] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 615,
                        ["timestamp"] = 1633227288,
                        ["quant"] = 1,
                        ["id"] = "1692088083",
                        ["itemLink"] = 391,
                    },
                    [13] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 734,
                        ["timestamp"] = 1633234414,
                        ["quant"] = 1,
                        ["id"] = "1692157009",
                        ["itemLink"] = 391,
                    },
                    [14] = 
                    {
                        ["price"] = 49000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 763,
                        ["timestamp"] = 1633234416,
                        ["quant"] = 1,
                        ["id"] = "1692157037",
                        ["itemLink"] = 391,
                    },
                    [15] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 763,
                        ["timestamp"] = 1633250694,
                        ["quant"] = 1,
                        ["id"] = "1692274955",
                        ["itemLink"] = 391,
                    },
                    [16] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 930,
                        ["timestamp"] = 1633284043,
                        ["quant"] = 1,
                        ["id"] = "1692556111",
                        ["itemLink"] = 391,
                    },
                },
                ["totalCount"] = 16,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [139419] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_smith_potion_014.dds",
                ["itemDesc"] = "Pulverized Dibellium",
                ["oldestTime"] = 1633298207,
                ["wasAltered"] = true,
                ["newestTime"] = 1633298207,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 808,
                        ["guild"] = 1,
                        ["buyer"] = 2034,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633298207,
                        ["quant"] = 2,
                        ["id"] = "1692723061",
                        ["itemLink"] = 2902,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials raw trait",
            },
        },
        [167358] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Solitude Shed, Wood Lean-To",
                ["oldestTime"] = 1633040330,
                ["wasAltered"] = true,
                ["newestTime"] = 1633040330,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 623,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633040330,
                        ["quant"] = 1,
                        ["id"] = "1690515743",
                        ["itemLink"] = 796,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [165699] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_fur_endtablefancy004.dds",
                ["itemDesc"] = "Solitude Nightstand, Noble Drawers",
                ["oldestTime"] = 1633297836,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297836,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15532,
                        ["guild"] = 1,
                        ["buyer"] = 2029,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1633297836,
                        ["quant"] = 1,
                        ["id"] = "1692719229",
                        ["itemLink"] = 2891,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings suite",
            },
        },
        [175808] = 
        {
            ["1:0:2:43:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_shoulders_light.dds",
                ["itemDesc"] = "Companion's Epaulets",
                ["oldestTime"] = 1633031853,
                ["wasAltered"] = true,
                ["newestTime"] = 1633031853,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 567,
                        ["wasKiosk"] = true,
                        ["seller"] = 50,
                        ["timestamp"] = 1633031853,
                        ["quant"] = 1,
                        ["id"] = "1690456083",
                        ["itemLink"] = 722,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine light apparel shoulders quickened",
            },
        },
        [176833] = 
        {
            ["1:0:2:49:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_shoulders_light.dds",
                ["itemDesc"] = "Companion's Epaulets",
                ["oldestTime"] = 1633247082,
                ["wasAltered"] = true,
                ["newestTime"] = 1633247082,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1803,
                        ["wasKiosk"] = true,
                        ["seller"] = 252,
                        ["timestamp"] = 1633247082,
                        ["quant"] = 1,
                        ["id"] = "1692249981",
                        ["itemLink"] = 2582,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine light apparel shoulders augmented",
            },
        },
        [97218] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of a Mother's Sorrow",
                ["oldestTime"] = 1632884562,
                ["wasAltered"] = true,
                ["newestTime"] = 1633017776,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2554,
                        ["guild"] = 1,
                        ["buyer"] = 489,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1633017776,
                        ["quant"] = 1,
                        ["id"] = "1690346949",
                        ["itemLink"] = 557,
                    },
                    [2] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 2383,
                        ["wasKiosk"] = true,
                        ["seller"] = 691,
                        ["timestamp"] = 1632884562,
                        ["quant"] = 1,
                        ["id"] = "1689447051",
                        ["itemLink"] = 557,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set mother's sorrow neck arcane",
            },
            ["50:16:5:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of a Mother's Sorrow",
                ["oldestTime"] = 1633248488,
                ["wasAltered"] = true,
                ["newestTime"] = 1633288529,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 125000,
                        ["guild"] = 1,
                        ["buyer"] = 1296,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633248488,
                        ["quant"] = 1,
                        ["id"] = "1692260955",
                        ["itemLink"] = 2586,
                    },
                    [2] = 
                    {
                        ["price"] = 149998,
                        ["guild"] = 1,
                        ["buyer"] = 1972,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633288529,
                        ["quant"] = 1,
                        ["id"] = "1692610125",
                        ["itemLink"] = 2586,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 gold legendary jewelry apparel set mother's sorrow neck arcane",
            },
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of a Mother's Sorrow",
                ["oldestTime"] = 1632885248,
                ["wasAltered"] = true,
                ["newestTime"] = 1633300840,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 1678,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633229258,
                        ["quant"] = 1,
                        ["id"] = "1692108909",
                        ["itemLink"] = 2431,
                    },
                    [2] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 2044,
                        ["wasKiosk"] = true,
                        ["seller"] = 1668,
                        ["timestamp"] = 1633300840,
                        ["quant"] = 1,
                        ["id"] = "1692749497",
                        ["itemLink"] = 2431,
                    },
                    [3] = 
                    {
                        ["price"] = 22900,
                        ["guild"] = 1,
                        ["buyer"] = 2388,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632885248,
                        ["quant"] = 1,
                        ["id"] = "1689455739",
                        ["itemLink"] = 2431,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set mother's sorrow neck arcane",
            },
            ["50:16:2:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of a Mother's Sorrow",
                ["oldestTime"] = 1632842969,
                ["wasAltered"] = true,
                ["newestTime"] = 1632842969,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 770,
                        ["guild"] = 1,
                        ["buyer"] = 451,
                        ["wasKiosk"] = false,
                        ["seller"] = 662,
                        ["timestamp"] = 1632842969,
                        ["quant"] = 1,
                        ["id"] = "1689083853",
                        ["itemLink"] = 3164,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set mother's sorrow neck arcane",
            },
        },
        [156611] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 81: New Moon Priest Boots",
                ["oldestTime"] = 1632930542,
                ["wasAltered"] = true,
                ["newestTime"] = 1633008885,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1995,
                        ["guild"] = 1,
                        ["buyer"] = 359,
                        ["wasKiosk"] = true,
                        ["seller"] = 322,
                        ["timestamp"] = 1632992098,
                        ["quant"] = 1,
                        ["id"] = "1690196741",
                        ["itemLink"] = 360,
                    },
                    [2] = 
                    {
                        ["price"] = 2981,
                        ["guild"] = 1,
                        ["buyer"] = 430,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1633008885,
                        ["quant"] = 1,
                        ["id"] = "1690282097",
                        ["itemLink"] = 360,
                    },
                    [3] = 
                    {
                        ["price"] = 2775,
                        ["guild"] = 1,
                        ["buyer"] = 2514,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1632930542,
                        ["quant"] = 1,
                        ["id"] = "1689725973",
                        ["itemLink"] = 360,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [64708] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/notes_004.dds",
                ["itemDesc"] = "Recipe: Psijic Ambrosia, Fragment VI",
                ["oldestTime"] = 1632850233,
                ["wasAltered"] = true,
                ["newestTime"] = 1633295790,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 736,
                        ["wasKiosk"] = true,
                        ["seller"] = 737,
                        ["timestamp"] = 1633054517,
                        ["quant"] = 1,
                        ["id"] = "1690650333",
                        ["itemLink"] = 941,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2020,
                        ["wasKiosk"] = true,
                        ["seller"] = 802,
                        ["timestamp"] = 1633295790,
                        ["quant"] = 1,
                        ["id"] = "1692698301",
                        ["itemLink"] = 941,
                    },
                    [3] = 
                    {
                        ["price"] = 389,
                        ["guild"] = 1,
                        ["buyer"] = 7,
                        ["wasKiosk"] = false,
                        ["seller"] = 246,
                        ["timestamp"] = 1632850233,
                        ["quant"] = 1,
                        ["id"] = "1689146305",
                        ["itemLink"] = 941,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [102108] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_draugr_medium_hands_a.dds",
                ["itemDesc"] = "Stygian Bracers",
                ["oldestTime"] = 1632880076,
                ["wasAltered"] = true,
                ["newestTime"] = 1633295213,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633295213,
                        ["quant"] = 1,
                        ["id"] = "1692692457",
                        ["itemLink"] = 2877,
                    },
                    [2] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 2352,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1632880076,
                        ["quant"] = 1,
                        ["id"] = "1689397423",
                        ["itemLink"] = 2877,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic medium apparel set stygian hands divines",
            },
        },
        [160585] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 87: Ancestral Nord Legs",
                ["oldestTime"] = 1633294746,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294746,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 233,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633294746,
                        ["quant"] = 1,
                        ["id"] = "1692687113",
                        ["itemLink"] = 2874,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [118900] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_aqa_starfish002.dds",
                ["itemDesc"] = "Seashell, Noble Starfish",
                ["oldestTime"] = 1633292852,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292852,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1996,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633292852,
                        ["quant"] = 1,
                        ["id"] = "1692661609",
                        ["itemLink"] = 2848,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings conservatory",
            },
        },
        [139464] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/container_sealed_polymorph_001.dds",
                ["itemDesc"] = "Runebox: Big-Eared Ginger Kitten Pet",
                ["oldestTime"] = 1633148185,
                ["wasAltered"] = true,
                ["newestTime"] = 1633148185,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 179000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 149,
                        ["timestamp"] = 1633148185,
                        ["quant"] = 1,
                        ["id"] = "1691375479",
                        ["itemLink"] = 1696,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable container",
            },
        },
        [171517] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing4.dds",
                ["itemDesc"] = "Diagram: Dwarven Sideboard, Granite Polished",
                ["oldestTime"] = 1633292393,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292393,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 130000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633292393,
                        ["quant"] = 1,
                        ["id"] = "1692656225",
                        ["itemLink"] = 2827,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [175982] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Divider, Octopus",
                ["oldestTime"] = 1633292359,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292359,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 690420,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1633292359,
                        ["quant"] = 1,
                        ["id"] = "1692655713",
                        ["itemLink"] = 2824,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [77141] = 
        {
            ["50:16:4:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ooth_2hsword_a.dds",
                ["itemDesc"] = "Greatsword of Flanking",
                ["oldestTime"] = 1633287852,
                ["wasAltered"] = true,
                ["newestTime"] = 1633287852,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 84500,
                        ["guild"] = 1,
                        ["buyer"] = 1821,
                        ["wasKiosk"] = true,
                        ["seller"] = 626,
                        ["timestamp"] = 1633287852,
                        ["quant"] = 1,
                        ["id"] = "1692603215",
                        ["itemLink"] = 2764,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set flanking strategist sword two-handed defending",
            },
        },
        [129778] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_heavy_head_a.dds",
                ["itemDesc"] = "Helm of the Pariah",
                ["oldestTime"] = 1633277119,
                ["wasAltered"] = true,
                ["newestTime"] = 1633277119,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1906,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633277119,
                        ["quant"] = 1,
                        ["id"] = "1692487509",
                        ["itemLink"] = 2704,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set mark of the pariah head impenetrable",
            },
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_heavy_head_a.dds",
                ["itemDesc"] = "Helm of the Pariah",
                ["oldestTime"] = 1633278429,
                ["wasAltered"] = true,
                ["newestTime"] = 1633278429,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1902,
                        ["wasKiosk"] = true,
                        ["seller"] = 353,
                        ["timestamp"] = 1633278429,
                        ["quant"] = 1,
                        ["id"] = "1692499833",
                        ["itemLink"] = 2720,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set mark of the pariah head impenetrable",
            },
        },
        [46029] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Rihad Qishr",
                ["oldestTime"] = 1633140924,
                ["wasAltered"] = true,
                ["newestTime"] = 1633140924,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 68,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633140924,
                        ["quant"] = 1,
                        ["id"] = "1691300627",
                        ["itemLink"] = 1606,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [30158] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_forester_potion_sp_names_001.dds",
                ["itemDesc"] = "Lady's Smock",
                ["oldestTime"] = 1632823028,
                ["wasAltered"] = true,
                ["newestTime"] = 1633308487,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 68730,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633001223,
                        ["quant"] = 158,
                        ["id"] = "1690240379",
                        ["itemLink"] = 410,
                    },
                    [2] = 
                    {
                        ["price"] = 36000,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633001224,
                        ["quant"] = 100,
                        ["id"] = "1690240383",
                        ["itemLink"] = 410,
                    },
                    [3] = 
                    {
                        ["price"] = 13294,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633154446,
                        ["quant"] = 46,
                        ["id"] = "1691427245",
                        ["itemLink"] = 410,
                    },
                    [4] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 1093,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633215576,
                        ["quant"] = 100,
                        ["id"] = "1691963513",
                        ["itemLink"] = 410,
                    },
                    [5] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 750,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633227256,
                        ["quant"] = 10,
                        ["id"] = "1692087733",
                        ["itemLink"] = 410,
                    },
                    [6] = 
                    {
                        ["price"] = 64000,
                        ["guild"] = 1,
                        ["buyer"] = 750,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633227257,
                        ["quant"] = 200,
                        ["id"] = "1692087741",
                        ["itemLink"] = 410,
                    },
                    [7] = 
                    {
                        ["price"] = 17084,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 69,
                        ["timestamp"] = 1633302517,
                        ["quant"] = 50,
                        ["id"] = "1692766669",
                        ["itemLink"] = 410,
                    },
                    [8] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 2077,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633308486,
                        ["quant"] = 20,
                        ["id"] = "1692828419",
                        ["itemLink"] = 410,
                    },
                    [9] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 2077,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633308487,
                        ["quant"] = 20,
                        ["id"] = "1692828429",
                        ["itemLink"] = 410,
                    },
                    [10] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 2077,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633308487,
                        ["quant"] = 20,
                        ["id"] = "1692828437",
                        ["itemLink"] = 410,
                    },
                    [11] = 
                    {
                        ["price"] = 9500,
                        ["guild"] = 1,
                        ["buyer"] = 2110,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632823028,
                        ["quant"] = 25,
                        ["id"] = "1688955609",
                        ["itemLink"] = 410,
                    },
                    [12] = 
                    {
                        ["price"] = 15750,
                        ["guild"] = 1,
                        ["buyer"] = 336,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632860616,
                        ["quant"] = 50,
                        ["id"] = "1689235347",
                        ["itemLink"] = 410,
                    },
                    [13] = 
                    {
                        ["price"] = 1890,
                        ["guild"] = 1,
                        ["buyer"] = 436,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632964577,
                        ["quant"] = 6,
                        ["id"] = "1690001189",
                        ["itemLink"] = 410,
                    },
                },
                ["totalCount"] = 13,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [149500] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_bow_a.dds",
                ["itemDesc"] = "Darloc Brae's Bow",
                ["oldestTime"] = 1633276219,
                ["wasAltered"] = true,
                ["newestTime"] = 1633276219,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1902,
                        ["wasKiosk"] = true,
                        ["seller"] = 1689,
                        ["timestamp"] = 1633276219,
                        ["quant"] = 1,
                        ["id"] = "1692477793",
                        ["itemLink"] = 2701,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set vesture of darloc brae bow two-handed defending",
            },
        },
        [147321] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Sai Sahan's Belt",
                ["oldestTime"] = 1632861865,
                ["wasAltered"] = true,
                ["newestTime"] = 1633274187,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1334,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633274187,
                        ["quant"] = 1,
                        ["id"] = "1692453177",
                        ["itemLink"] = 2694,
                    },
                    [2] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 2249,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632861865,
                        ["quant"] = 1,
                        ["id"] = "1689243573",
                        ["itemLink"] = 2694,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [30161] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_flower_corn_flower_r1.dds",
                ["itemDesc"] = "Corn Flower",
                ["oldestTime"] = 1632823000,
                ["wasAltered"] = true,
                ["newestTime"] = 1633315137,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5100,
                        ["guild"] = 1,
                        ["buyer"] = 89,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633315137,
                        ["quant"] = 3,
                        ["id"] = "1692904871",
                        ["itemLink"] = 66,
                    },
                    [2] = 
                    {
                        ["price"] = 11250,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1633001229,
                        ["quant"] = 15,
                        ["id"] = "1690240401",
                        ["itemLink"] = 66,
                    },
                    [3] = 
                    {
                        ["price"] = 15120,
                        ["guild"] = 1,
                        ["buyer"] = 549,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633027616,
                        ["quant"] = 20,
                        ["id"] = "1690424809",
                        ["itemLink"] = 66,
                    },
                    [4] = 
                    {
                        ["price"] = 19353,
                        ["guild"] = 1,
                        ["buyer"] = 549,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633027617,
                        ["quant"] = 25,
                        ["id"] = "1690424819",
                        ["itemLink"] = 66,
                    },
                    [5] = 
                    {
                        ["price"] = 34000,
                        ["guild"] = 1,
                        ["buyer"] = 549,
                        ["wasKiosk"] = true,
                        ["seller"] = 461,
                        ["timestamp"] = 1633027638,
                        ["quant"] = 43,
                        ["id"] = "1690425137",
                        ["itemLink"] = 66,
                    },
                    [6] = 
                    {
                        ["price"] = 34000,
                        ["guild"] = 1,
                        ["buyer"] = 549,
                        ["wasKiosk"] = true,
                        ["seller"] = 461,
                        ["timestamp"] = 1633027639,
                        ["quant"] = 43,
                        ["id"] = "1690425161",
                        ["itemLink"] = 66,
                    },
                    [7] = 
                    {
                        ["price"] = 9997,
                        ["guild"] = 1,
                        ["buyer"] = 336,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633066891,
                        ["quant"] = 13,
                        ["id"] = "1690760857",
                        ["itemLink"] = 66,
                    },
                    [8] = 
                    {
                        ["price"] = 5100,
                        ["guild"] = 1,
                        ["buyer"] = 955,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633102089,
                        ["quant"] = 3,
                        ["id"] = "1690973409",
                        ["itemLink"] = 66,
                    },
                    [9] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 1172,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633139224,
                        ["quant"] = 20,
                        ["id"] = "1691283561",
                        ["itemLink"] = 66,
                    },
                    [10] = 
                    {
                        ["price"] = 5100,
                        ["guild"] = 1,
                        ["buyer"] = 1205,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633142438,
                        ["quant"] = 3,
                        ["id"] = "1691319173",
                        ["itemLink"] = 66,
                    },
                    [11] = 
                    {
                        ["price"] = 29358,
                        ["guild"] = 1,
                        ["buyer"] = 549,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633153128,
                        ["quant"] = 42,
                        ["id"] = "1691416909",
                        ["itemLink"] = 66,
                    },
                    [12] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 671,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633153762,
                        ["quant"] = 4,
                        ["id"] = "1691421329",
                        ["itemLink"] = 66,
                    },
                    [13] = 
                    {
                        ["price"] = 9200,
                        ["guild"] = 1,
                        ["buyer"] = 1304,
                        ["wasKiosk"] = true,
                        ["seller"] = 944,
                        ["timestamp"] = 1633160461,
                        ["quant"] = 9,
                        ["id"] = "1691467047",
                        ["itemLink"] = 66,
                    },
                    [14] = 
                    {
                        ["price"] = 15560,
                        ["guild"] = 1,
                        ["buyer"] = 1561,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633212989,
                        ["quant"] = 20,
                        ["id"] = "1691940581",
                        ["itemLink"] = 66,
                    },
                    [15] = 
                    {
                        ["price"] = 4648,
                        ["guild"] = 1,
                        ["buyer"] = 750,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633227263,
                        ["quant"] = 7,
                        ["id"] = "1692087823",
                        ["itemLink"] = 66,
                    },
                    [16] = 
                    {
                        ["price"] = 15745,
                        ["guild"] = 1,
                        ["buyer"] = 1764,
                        ["wasKiosk"] = true,
                        ["seller"] = 711,
                        ["timestamp"] = 1633239992,
                        ["quant"] = 20,
                        ["id"] = "1692196911",
                        ["itemLink"] = 66,
                    },
                    [17] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 750,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633247340,
                        ["quant"] = 4,
                        ["id"] = "1692252439",
                        ["itemLink"] = 66,
                    },
                    [18] = 
                    {
                        ["price"] = 10766,
                        ["guild"] = 1,
                        ["buyer"] = 919,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633264445,
                        ["quant"] = 14,
                        ["id"] = "1692354285",
                        ["itemLink"] = 66,
                    },
                    [19] = 
                    {
                        ["price"] = 19725,
                        ["guild"] = 1,
                        ["buyer"] = 919,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633264457,
                        ["quant"] = 25,
                        ["id"] = "1692354393",
                        ["itemLink"] = 66,
                    },
                    [20] = 
                    {
                        ["price"] = 19725,
                        ["guild"] = 1,
                        ["buyer"] = 1921,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633279219,
                        ["quant"] = 25,
                        ["id"] = "1692506921",
                        ["itemLink"] = 66,
                    },
                    [21] = 
                    {
                        ["price"] = 19725,
                        ["guild"] = 1,
                        ["buyer"] = 1921,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633279220,
                        ["quant"] = 25,
                        ["id"] = "1692506931",
                        ["itemLink"] = 66,
                    },
                    [22] = 
                    {
                        ["price"] = 78000,
                        ["guild"] = 1,
                        ["buyer"] = 1955,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633286485,
                        ["quant"] = 100,
                        ["id"] = "1692583443",
                        ["itemLink"] = 66,
                    },
                    [23] = 
                    {
                        ["price"] = 160000,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633294609,
                        ["quant"] = 200,
                        ["id"] = "1692685257",
                        ["itemLink"] = 66,
                    },
                    [24] = 
                    {
                        ["price"] = 19500,
                        ["guild"] = 1,
                        ["buyer"] = 2110,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632823000,
                        ["quant"] = 25,
                        ["id"] = "1688955523",
                        ["itemLink"] = 66,
                    },
                    [25] = 
                    {
                        ["price"] = 160950,
                        ["guild"] = 1,
                        ["buyer"] = 2172,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1632839705,
                        ["quant"] = 200,
                        ["id"] = "1689058177",
                        ["itemLink"] = 66,
                    },
                    [26] = 
                    {
                        ["price"] = 76699,
                        ["guild"] = 1,
                        ["buyer"] = 336,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1632860606,
                        ["quant"] = 100,
                        ["id"] = "1689235277",
                        ["itemLink"] = 66,
                    },
                    [27] = 
                    {
                        ["price"] = 3076,
                        ["guild"] = 1,
                        ["buyer"] = 336,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632860608,
                        ["quant"] = 4,
                        ["id"] = "1689235297",
                        ["itemLink"] = 66,
                    },
                    [28] = 
                    {
                        ["price"] = 151389,
                        ["guild"] = 1,
                        ["buyer"] = 2122,
                        ["wasKiosk"] = false,
                        ["seller"] = 244,
                        ["timestamp"] = 1632895328,
                        ["quant"] = 200,
                        ["id"] = "1689531245",
                        ["itemLink"] = 66,
                    },
                    [29] = 
                    {
                        ["price"] = 19000,
                        ["guild"] = 1,
                        ["buyer"] = 2122,
                        ["wasKiosk"] = false,
                        ["seller"] = 299,
                        ["timestamp"] = 1632895401,
                        ["quant"] = 25,
                        ["id"] = "1689531569",
                        ["itemLink"] = 66,
                    },
                    [30] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 750,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632921382,
                        ["quant"] = 10,
                        ["id"] = "1689660339",
                        ["itemLink"] = 66,
                    },
                    [31] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 750,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632921383,
                        ["quant"] = 10,
                        ["id"] = "1689660349",
                        ["itemLink"] = 66,
                    },
                    [32] = 
                    {
                        ["price"] = 6152,
                        ["guild"] = 1,
                        ["buyer"] = 2615,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632956831,
                        ["quant"] = 8,
                        ["id"] = "1689934745",
                        ["itemLink"] = 66,
                    },
                },
                ["totalCount"] = 32,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [114669] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_medium_head_a.dds",
                ["itemDesc"] = "Helmet of Syvarra's Scales",
                ["oldestTime"] = 1632987577,
                ["wasAltered"] = true,
                ["newestTime"] = 1632987577,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2700,
                        ["guild"] = 1,
                        ["buyer"] = 328,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632987577,
                        ["quant"] = 1,
                        ["id"] = "1690172231",
                        ["itemLink"] = 332,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set syvarra's scales head infused",
            },
        },
        [77523] = 
        {
            ["50:16:2:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Sithis' Necklace",
                ["oldestTime"] = 1632929477,
                ["wasAltered"] = true,
                ["newestTime"] = 1632929477,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 966,
                        ["wasKiosk"] = false,
                        ["seller"] = 105,
                        ["timestamp"] = 1632929477,
                        ["quant"] = 1,
                        ["id"] = "1689717991",
                        ["itemLink"] = 3695,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set sithis' touch neck robust",
            },
        },
        [69332] = 
        {
            ["50:16:4:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_shield_d.dds",
                ["itemDesc"] = "Shield of Agility",
                ["oldestTime"] = 1632857965,
                ["wasAltered"] = true,
                ["newestTime"] = 1632857965,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 977,
                        ["guild"] = 1,
                        ["buyer"] = 2241,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1632857965,
                        ["quant"] = 1,
                        ["id"] = "1689213987",
                        ["itemLink"] = 3290,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic apparel weapon set agility shield off hand sturdy",
            },
        },
        [180693] = 
        {
            ["50:16:3:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_staff_a.dds",
                ["itemDesc"] = "Plaguebreak Restoration Staff",
                ["oldestTime"] = 1633312790,
                ["wasAltered"] = true,
                ["newestTime"] = 1633312790,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 39,
                        ["wasKiosk"] = true,
                        ["seller"] = 42,
                        ["timestamp"] = 1633312790,
                        ["quant"] = 1,
                        ["id"] = "1692878403",
                        ["itemLink"] = 29,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set plaguebreak healing staff two-handed sharpened",
            },
        },
        [176016] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning3.dds",
                ["itemDesc"] = "Design: Leyawiin Meal, Clams",
                ["oldestTime"] = 1633060371,
                ["wasAltered"] = true,
                ["newestTime"] = 1633060371,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 406,
                        ["timestamp"] = 1633060371,
                        ["quant"] = 1,
                        ["id"] = "1690713451",
                        ["itemLink"] = 1012,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [140503] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 67: Welkynar Gloves",
                ["oldestTime"] = 1633107994,
                ["wasAltered"] = true,
                ["newestTime"] = 1633224865,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 973,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633107994,
                        ["quant"] = 1,
                        ["id"] = "1691022077",
                        ["itemLink"] = 1307,
                    },
                    [2] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 1118,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633132143,
                        ["quant"] = 1,
                        ["id"] = "1691209657",
                        ["itemLink"] = 1307,
                    },
                    [3] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 1641,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1633224865,
                        ["quant"] = 1,
                        ["id"] = "1692062927",
                        ["itemLink"] = 1307,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [172248] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_2hsword_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Greatsword",
                ["oldestTime"] = 1633231660,
                ["wasAltered"] = true,
                ["newestTime"] = 1633231660,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3995,
                        ["guild"] = 1,
                        ["buyer"] = 1695,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1633231660,
                        ["quant"] = 1,
                        ["id"] = "1692132023",
                        ["itemLink"] = 2441,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set deadlands assassin sword two-handed decisive",
            },
        },
        [118359] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_exc_varharborfishes005.dds",
                ["itemDesc"] = "Fish, Large",
                ["oldestTime"] = 1633124173,
                ["wasAltered"] = true,
                ["newestTime"] = 1633124173,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 1071,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633124173,
                        ["quant"] = 6,
                        ["id"] = "1691136193",
                        ["itemLink"] = 1461,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings hearth",
            },
        },
        [4570] = 
        {
            ["20:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_potion_base_water_2_r3.dds",
                ["itemDesc"] = "Pristine Water",
                ["oldestTime"] = 1632520116,
                ["wasAltered"] = true,
                ["newestTime"] = 1632520116,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 428,
                        ["guild"] = 2,
                        ["buyer"] = 114,
                        ["wasKiosk"] = false,
                        ["seller"] = 115,
                        ["timestamp"] = 1632520116,
                        ["quant"] = 4,
                        ["id"] = "1686354351",
                        ["itemLink"] = 88,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr20 white normal materials potion solvent",
            },
        },
        [137603] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Seducer",
                ["oldestTime"] = 1633017051,
                ["wasAltered"] = true,
                ["newestTime"] = 1633245384,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 42999,
                        ["guild"] = 1,
                        ["buyer"] = 482,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633017051,
                        ["quant"] = 1,
                        ["id"] = "1690342143",
                        ["itemLink"] = 548,
                    },
                    [2] = 
                    {
                        ["price"] = 42999,
                        ["guild"] = 1,
                        ["buyer"] = 482,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633017054,
                        ["quant"] = 1,
                        ["id"] = "1690342145",
                        ["itemLink"] = 548,
                    },
                    [3] = 
                    {
                        ["price"] = 42999,
                        ["guild"] = 1,
                        ["buyer"] = 1031,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633117400,
                        ["quant"] = 1,
                        ["id"] = "1691087723",
                        ["itemLink"] = 548,
                    },
                    [4] = 
                    {
                        ["price"] = 42999,
                        ["guild"] = 1,
                        ["buyer"] = 1101,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633130110,
                        ["quant"] = 1,
                        ["id"] = "1691187467",
                        ["itemLink"] = 548,
                    },
                    [5] = 
                    {
                        ["price"] = 42999,
                        ["guild"] = 1,
                        ["buyer"] = 1101,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633130111,
                        ["quant"] = 1,
                        ["id"] = "1691187487",
                        ["itemLink"] = 548,
                    },
                    [6] = 
                    {
                        ["price"] = 42999,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633202653,
                        ["quant"] = 1,
                        ["id"] = "1691818231",
                        ["itemLink"] = 548,
                    },
                    [7] = 
                    {
                        ["price"] = 42999,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633202655,
                        ["quant"] = 1,
                        ["id"] = "1691818251",
                        ["itemLink"] = 548,
                    },
                    [8] = 
                    {
                        ["price"] = 42999,
                        ["guild"] = 1,
                        ["buyer"] = 1797,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633245381,
                        ["quant"] = 1,
                        ["id"] = "1692236183",
                        ["itemLink"] = 548,
                    },
                    [9] = 
                    {
                        ["price"] = 42999,
                        ["guild"] = 1,
                        ["buyer"] = 1797,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633245384,
                        ["quant"] = 1,
                        ["id"] = "1692236211",
                        ["itemLink"] = 548,
                    },
                },
                ["totalCount"] = 9,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set armor of the seducer ring arcane",
            },
        },
        [43740] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Vvardenfell Treasure Map IV",
                ["oldestTime"] = 1633169185,
                ["wasAltered"] = true,
                ["newestTime"] = 1633169185,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 299,
                        ["guild"] = 1,
                        ["buyer"] = 1333,
                        ["wasKiosk"] = true,
                        ["seller"] = 164,
                        ["timestamp"] = 1633169185,
                        ["quant"] = 1,
                        ["id"] = "1691515315",
                        ["itemLink"] = 1878,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [119113] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning4.dds",
                ["itemDesc"] = "Design: Orcish Candle Sconce, Horn",
                ["oldestTime"] = 1633227077,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227077,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1657,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633227077,
                        ["quant"] = 1,
                        ["id"] = "1692086043",
                        ["itemLink"] = 2401,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [151774] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_str_aqueductcanalcover001.dds",
                ["itemDesc"] = "Elsweyr Platform, Wooden Small",
                ["oldestTime"] = 1633215172,
                ["wasAltered"] = true,
                ["newestTime"] = 1633215172,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2816,
                        ["guild"] = 1,
                        ["buyer"] = 1584,
                        ["wasKiosk"] = true,
                        ["seller"] = 99,
                        ["timestamp"] = 1633215172,
                        ["quant"] = 1,
                        ["id"] = "1691960283",
                        ["itemLink"] = 2310,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings structures",
            },
        },
        [64706] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/notes_004.dds",
                ["itemDesc"] = "Recipe: Psijic Ambrosia, Fragment IV",
                ["oldestTime"] = 1633220720,
                ["wasAltered"] = true,
                ["newestTime"] = 1633295801,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 439,
                        ["guild"] = 1,
                        ["buyer"] = 285,
                        ["wasKiosk"] = false,
                        ["seller"] = 896,
                        ["timestamp"] = 1633220720,
                        ["quant"] = 1,
                        ["id"] = "1692019307",
                        ["itemLink"] = 2344,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2020,
                        ["wasKiosk"] = true,
                        ["seller"] = 802,
                        ["timestamp"] = 1633295801,
                        ["quant"] = 1,
                        ["id"] = "1692698427",
                        ["itemLink"] = 2344,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [45955] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Indoril Radish Tartlets",
                ["oldestTime"] = 1633106524,
                ["wasAltered"] = true,
                ["newestTime"] = 1633140917,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 48,
                        ["guild"] = 1,
                        ["buyer"] = 969,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633106524,
                        ["quant"] = 1,
                        ["id"] = "1691012277",
                        ["itemLink"] = 1301,
                    },
                    [2] = 
                    {
                        ["price"] = 48,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633140917,
                        ["quant"] = 1,
                        ["id"] = "1691300573",
                        ["itemLink"] = 1301,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [115721] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Argonian Chimney Stack",
                ["oldestTime"] = 1633071527,
                ["wasAltered"] = true,
                ["newestTime"] = 1633150041,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40,
                        ["guild"] = 1,
                        ["buyer"] = 847,
                        ["wasKiosk"] = true,
                        ["seller"] = 170,
                        ["timestamp"] = 1633071527,
                        ["quant"] = 1,
                        ["id"] = "1690787801",
                        ["itemLink"] = 1090,
                    },
                    [2] = 
                    {
                        ["price"] = 59,
                        ["guild"] = 1,
                        ["buyer"] = 1255,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633150041,
                        ["quant"] = 1,
                        ["id"] = "1691391359",
                        ["itemLink"] = 1090,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [135138] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_pewter_refined.dds",
                ["itemDesc"] = "Pewter Ounce",
                ["oldestTime"] = 1632714094,
                ["wasAltered"] = true,
                ["newestTime"] = 1632980450,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 2,
                        ["buyer"] = 129,
                        ["wasKiosk"] = false,
                        ["seller"] = 125,
                        ["timestamp"] = 1632714094,
                        ["quant"] = 200,
                        ["id"] = "1688085837",
                        ["itemLink"] = 108,
                    },
                    [2] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 259,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1632980450,
                        ["quant"] = 200,
                        ["id"] = "1690132701",
                        ["itemLink"] = 108,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [176030] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Deadlands Chair, Ashen",
                ["oldestTime"] = 1632862364,
                ["wasAltered"] = true,
                ["newestTime"] = 1633207052,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 1533,
                        ["wasKiosk"] = true,
                        ["seller"] = 1450,
                        ["timestamp"] = 1633207052,
                        ["quant"] = 1,
                        ["id"] = "1691867973",
                        ["itemLink"] = 2256,
                    },
                    [2] = 
                    {
                        ["price"] = 10500,
                        ["guild"] = 1,
                        ["buyer"] = 2251,
                        ["wasKiosk"] = true,
                        ["seller"] = 92,
                        ["timestamp"] = 1632862364,
                        ["quant"] = 1,
                        ["id"] = "1689246875",
                        ["itemLink"] = 2256,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [178447] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_inc_leymetalframepainting009.dds",
                ["itemDesc"] = "Music in Repose Painting, Silver",
                ["oldestTime"] = 1633061722,
                ["wasAltered"] = true,
                ["newestTime"] = 1633061722,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 56448,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 765,
                        ["timestamp"] = 1633061722,
                        ["quant"] = 1,
                        ["id"] = "1690723133",
                        ["itemLink"] = 1031,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings gallery",
            },
        },
        [126949] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Hlaalu Sideboard, Scribe's",
                ["oldestTime"] = 1633190623,
                ["wasAltered"] = true,
                ["newestTime"] = 1633190623,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633190623,
                        ["quant"] = 1,
                        ["id"] = "1691694909",
                        ["itemLink"] = 2102,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [152038] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Elsweyr Barstool, Wooden",
                ["oldestTime"] = 1633138466,
                ["wasAltered"] = true,
                ["newestTime"] = 1633138466,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1105,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633138466,
                        ["quant"] = 1,
                        ["id"] = "1691277259",
                        ["itemLink"] = 1587,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [49127] = 
        {
            ["10:0:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_medium_hands_a.dds",
                ["itemDesc"] = "Bracers of the Night Mother",
                ["oldestTime"] = 1632911082,
                ["wasAltered"] = true,
                ["newestTime"] = 1633232053,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1703,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633232053,
                        ["quant"] = 1,
                        ["id"] = "1692135509",
                        ["itemLink"] = 2447,
                    },
                    [2] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2463,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632911082,
                        ["quant"] = 1,
                        ["id"] = "1689604521",
                        ["itemLink"] = 3610,
                    },
                    [3] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632917348,
                        ["quant"] = 1,
                        ["id"] = "1689637711",
                        ["itemLink"] = 2447,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr10 blue superior medium apparel set night mother's gaze hands training",
            },
        },
        [123721] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Wizard's Riposte Ring",
                ["oldestTime"] = 1633206611,
                ["wasAltered"] = true,
                ["newestTime"] = 1633206611,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2999,
                        ["guild"] = 1,
                        ["buyer"] = 42,
                        ["wasKiosk"] = false,
                        ["seller"] = 158,
                        ["timestamp"] = 1633206611,
                        ["quant"] = 1,
                        ["id"] = "1691863189",
                        ["itemLink"] = 2255,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set wizard's riposte ring arcane",
            },
        },
        [57026] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Wizard's Whiskey",
                ["oldestTime"] = 1633203127,
                ["wasAltered"] = true,
                ["newestTime"] = 1633203127,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633203127,
                        ["quant"] = 1,
                        ["id"] = "1691824255",
                        ["itemLink"] = 2223,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [165752] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_inc_game002.dds",
                ["itemDesc"] = "Solitude Game, Warrior and the Wolf",
                ["oldestTime"] = 1633201056,
                ["wasAltered"] = true,
                ["newestTime"] = 1633201056,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18500,
                        ["guild"] = 1,
                        ["buyer"] = 1492,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633201056,
                        ["quant"] = 1,
                        ["id"] = "1691801155",
                        ["itemLink"] = 2210,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings parlor",
            },
        },
        [57579] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 15: Dwemer Gloves",
                ["oldestTime"] = 1632875715,
                ["wasAltered"] = true,
                ["newestTime"] = 1632875715,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2872,
                        ["guild"] = 1,
                        ["buyer"] = 2326,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1632875715,
                        ["quant"] = 1,
                        ["id"] = "1689349225",
                        ["itemLink"] = 3419,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [165787] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_inc_foodribs001.dds",
                ["itemDesc"] = "Solitude Platter, Ribs",
                ["oldestTime"] = 1633045694,
                ["wasAltered"] = true,
                ["newestTime"] = 1633239659,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 6,
                        ["wasKiosk"] = false,
                        ["seller"] = 73,
                        ["timestamp"] = 1633045694,
                        ["quant"] = 1,
                        ["id"] = "1690563617",
                        ["itemLink"] = 854,
                    },
                    [2] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1762,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633239659,
                        ["quant"] = 1,
                        ["id"] = "1692194841",
                        ["itemLink"] = 854,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings hearth",
            },
        },
        [175597] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_fur_leylargebookshelves002.dds",
                ["itemDesc"] = "Leyawiin Bookcase, Grand Filled",
                ["oldestTime"] = 1633060683,
                ["wasAltered"] = true,
                ["newestTime"] = 1633060683,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 46167,
                        ["guild"] = 1,
                        ["buyer"] = 789,
                        ["wasKiosk"] = true,
                        ["seller"] = 312,
                        ["timestamp"] = 1633060683,
                        ["quant"] = 1,
                        ["id"] = "1690716193",
                        ["itemLink"] = 1015,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings library",
            },
        },
        [56046] = 
        {
            ["1:0:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_light_feet_a.dds",
                ["itemDesc"] = "Homespun Shoes",
                ["oldestTime"] = 1632868045,
                ["wasAltered"] = true,
                ["newestTime"] = 1633237879,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 902,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633086479,
                        ["quant"] = 1,
                        ["id"] = "1690866449",
                        ["itemLink"] = 1220,
                    },
                    [2] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1358,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633177097,
                        ["quant"] = 1,
                        ["id"] = "1691563401",
                        ["itemLink"] = 1220,
                    },
                    [3] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 1594,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633217148,
                        ["quant"] = 1,
                        ["id"] = "1691981743",
                        ["itemLink"] = 1220,
                    },
                    [4] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 168,
                        ["wasKiosk"] = false,
                        ["seller"] = 207,
                        ["timestamp"] = 1633237879,
                        ["quant"] = 1,
                        ["id"] = "1692184691",
                        ["itemLink"] = 1220,
                    },
                    [5] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1093,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1632868045,
                        ["quant"] = 1,
                        ["id"] = "1689288051",
                        ["itemLink"] = 1220,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 white normal light apparel feet nirnhoned",
            },
        },
        [115740] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Argonian Mug, Tooth",
                ["oldestTime"] = 1632981402,
                ["wasAltered"] = true,
                ["newestTime"] = 1632981402,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50,
                        ["guild"] = 1,
                        ["buyer"] = 265,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632981402,
                        ["quant"] = 1,
                        ["id"] = "1690138623",
                        ["itemLink"] = 281,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [172355] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_bow_a.dds",
                ["itemDesc"] = "Bog Raider's Bow",
                ["oldestTime"] = 1633200601,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200601,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1490,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633200601,
                        ["quant"] = 1,
                        ["id"] = "1691795915",
                        ["itemLink"] = 2191,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set bog raider bow two-handed defending",
            },
        },
        [45041] = 
        {
            ["50:16:2:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_medium_chest_d.dds",
                ["itemDesc"] = "Rubedo Leather Jack of Stamina",
                ["oldestTime"] = 1633023008,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023008,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 206,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633023008,
                        ["quant"] = 1,
                        ["id"] = "1690390669",
                        ["itemLink"] = 631,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel chest sturdy",
            },
        },
        [49138] = 
        {
            ["10:0:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_2hsword_a.dds",
                ["itemDesc"] = "Greatsword of the Night Mother",
                ["oldestTime"] = 1632917325,
                ["wasAltered"] = true,
                ["newestTime"] = 1633036747,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 570,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633031957,
                        ["quant"] = 1,
                        ["id"] = "1690456675",
                        ["itemLink"] = 724,
                    },
                    [2] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 606,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633036747,
                        ["quant"] = 1,
                        ["id"] = "1690490659",
                        ["itemLink"] = 724,
                    },
                    [3] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632917325,
                        ["quant"] = 1,
                        ["id"] = "1689637405",
                        ["itemLink"] = 724,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr10 blue superior weapon set night mother's gaze sword two-handed training",
            },
        },
        [140447] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 63: Dremora Boots",
                ["oldestTime"] = 1632992027,
                ["wasAltered"] = true,
                ["newestTime"] = 1633240488,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 359,
                        ["wasKiosk"] = true,
                        ["seller"] = 360,
                        ["timestamp"] = 1632992027,
                        ["quant"] = 1,
                        ["id"] = "1690196221",
                        ["itemLink"] = 358,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 359,
                        ["wasKiosk"] = true,
                        ["seller"] = 360,
                        ["timestamp"] = 1632992032,
                        ["quant"] = 1,
                        ["id"] = "1690196271",
                        ["itemLink"] = 358,
                    },
                    [3] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 355,
                        ["wasKiosk"] = true,
                        ["seller"] = 360,
                        ["timestamp"] = 1633240488,
                        ["quant"] = 1,
                        ["id"] = "1692201567",
                        ["itemLink"] = 358,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [176543] = 
        {
            ["1:0:2:47:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_chest_light.dds",
                ["itemDesc"] = "Companion's Jerkin",
                ["oldestTime"] = 1633189474,
                ["wasAltered"] = true,
                ["newestTime"] = 1633189474,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1413,
                        ["wasKiosk"] = true,
                        ["seller"] = 534,
                        ["timestamp"] = 1633189474,
                        ["quant"] = 1,
                        ["id"] = "1691684105",
                        ["itemLink"] = 2094,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine light apparel chest aggressive",
            },
        },
        [172406] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_hvy_shoulders_a.dds",
                ["itemDesc"] = "Bog Raider's Pauldrons",
                ["oldestTime"] = 1632857728,
                ["wasAltered"] = true,
                ["newestTime"] = 1632857728,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 530,
                        ["timestamp"] = 1632857728,
                        ["quant"] = 1,
                        ["id"] = "1689211503",
                        ["itemLink"] = 3281,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set bog raider shoulders invigorating",
            },
            ["50:16:2:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_hvy_shoulders_a.dds",
                ["itemDesc"] = "Bog Raider's Pauldrons",
                ["oldestTime"] = 1633187902,
                ["wasAltered"] = true,
                ["newestTime"] = 1633187902,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 502,
                        ["wasKiosk"] = false,
                        ["seller"] = 354,
                        ["timestamp"] = 1633187902,
                        ["quant"] = 1,
                        ["id"] = "1691663099",
                        ["itemLink"] = 2083,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set bog raider shoulders invigorating",
            },
        },
        [117710] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_fur_bookcasetall001.dds",
                ["itemDesc"] = "Redguard Cabinet, Inlaid",
                ["oldestTime"] = 1633167906,
                ["wasAltered"] = true,
                ["newestTime"] = 1633167906,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11100,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1633167906,
                        ["quant"] = 1,
                        ["id"] = "1691509951",
                        ["itemLink"] = 1871,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings library",
            },
        },
        [166903] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning3.dds",
                ["itemDesc"] = "Design: Solitude Vase, Large Sealed",
                ["oldestTime"] = 1632865529,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865529,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 2186,
                        ["timestamp"] = 1632865529,
                        ["quant"] = 1,
                        ["id"] = "1689268855",
                        ["itemLink"] = 3340,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [139640] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Alinor Rug, Alinor Seal",
                ["oldestTime"] = 1633138440,
                ["wasAltered"] = true,
                ["newestTime"] = 1633138440,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1105,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633138440,
                        ["quant"] = 1,
                        ["id"] = "1691276809",
                        ["itemLink"] = 1586,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [135161] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/jewelrycrafting_material_refined_orpiment.dds",
                ["itemDesc"] = "Ochre",
                ["oldestTime"] = 1632844478,
                ["wasAltered"] = true,
                ["newestTime"] = 1633086111,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9800,
                        ["guild"] = 1,
                        ["buyer"] = 759,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1633056911,
                        ["quant"] = 200,
                        ["id"] = "1690676713",
                        ["itemLink"] = 959,
                    },
                    [2] = 
                    {
                        ["price"] = 2149,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1633086111,
                        ["quant"] = 200,
                        ["id"] = "1690864483",
                        ["itemLink"] = 959,
                    },
                    [3] = 
                    {
                        ["price"] = 4995,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 322,
                        ["timestamp"] = 1632844478,
                        ["quant"] = 200,
                        ["id"] = "1689094999",
                        ["itemLink"] = 959,
                    },
                    [4] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 334,
                        ["timestamp"] = 1632844478,
                        ["quant"] = 200,
                        ["id"] = "1689095009",
                        ["itemLink"] = 959,
                    },
                    [5] = 
                    {
                        ["price"] = 2045,
                        ["guild"] = 1,
                        ["buyer"] = 2509,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632928826,
                        ["quant"] = 200,
                        ["id"] = "1689713523",
                        ["itemLink"] = 959,
                    },
                    [6] = 
                    {
                        ["price"] = 1620,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 158,
                        ["timestamp"] = 1632938445,
                        ["quant"] = 108,
                        ["id"] = "1689784381",
                        ["itemLink"] = 959,
                    },
                    [7] = 
                    {
                        ["price"] = 1260,
                        ["guild"] = 1,
                        ["buyer"] = 193,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632950178,
                        ["quant"] = 140,
                        ["id"] = "1689875531",
                        ["itemLink"] = 959,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr01 white normal materials furnishing",
            },
        },
        [160506] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 84: Blackreach Vanguard Staves",
                ["oldestTime"] = 1632852249,
                ["wasAltered"] = true,
                ["newestTime"] = 1632852249,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1632852249,
                        ["quant"] = 1,
                        ["id"] = "1689160823",
                        ["itemLink"] = 3253,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [57595] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 18: Akaviri Chests",
                ["oldestTime"] = 1633311913,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311913,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 25,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633311913,
                        ["quant"] = 1,
                        ["id"] = "1692868689",
                        ["itemLink"] = 19,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [64508] = 
        {
            ["50:15:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_055.dds",
                ["itemDesc"] = "Jehade",
                ["oldestTime"] = 1632816856,
                ["wasAltered"] = true,
                ["newestTime"] = 1633316277,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 228,
                        ["guild"] = 1,
                        ["buyer"] = 1881,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633271460,
                        ["quant"] = 12,
                        ["id"] = "1692420541",
                        ["itemLink"] = 2671,
                    },
                    [2] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 2,
                        ["buyer"] = 1006,
                        ["wasKiosk"] = false,
                        ["seller"] = 115,
                        ["timestamp"] = 1633316277,
                        ["quant"] = 5,
                        ["id"] = "1692917989",
                        ["itemLink"] = 2671,
                    },
                    [3] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632816856,
                        ["quant"] = 200,
                        ["id"] = "1688929649",
                        ["itemLink"] = 2671,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp150 white normal materials potency runestone",
            },
        },
        [165629] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_lsb_candlelabra001.dds",
                ["itemDesc"] = "Solitude Chandelier, Steel",
                ["oldestTime"] = 1633047272,
                ["wasAltered"] = true,
                ["newestTime"] = 1633047272,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 48000,
                        ["guild"] = 1,
                        ["buyer"] = 685,
                        ["wasKiosk"] = true,
                        ["seller"] = 323,
                        ["timestamp"] = 1633047272,
                        ["quant"] = 4,
                        ["id"] = "1690578081",
                        ["itemLink"] = 871,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [71679] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 28: Ra Gada Gloves",
                ["oldestTime"] = 1632886417,
                ["wasAltered"] = true,
                ["newestTime"] = 1633143164,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2119,
                        ["guild"] = 1,
                        ["buyer"] = 764,
                        ["wasKiosk"] = true,
                        ["seller"] = 765,
                        ["timestamp"] = 1633057258,
                        ["quant"] = 1,
                        ["id"] = "1690682017",
                        ["itemLink"] = 963,
                    },
                    [2] = 
                    {
                        ["price"] = 3198,
                        ["guild"] = 1,
                        ["buyer"] = 1057,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633121670,
                        ["quant"] = 1,
                        ["id"] = "1691117343",
                        ["itemLink"] = 963,
                    },
                    [3] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1210,
                        ["wasKiosk"] = true,
                        ["seller"] = 61,
                        ["timestamp"] = 1633143164,
                        ["quant"] = 1,
                        ["id"] = "1691327151",
                        ["itemLink"] = 963,
                    },
                    [4] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 2393,
                        ["wasKiosk"] = true,
                        ["seller"] = 2155,
                        ["timestamp"] = 1632886417,
                        ["quant"] = 1,
                        ["id"] = "1689466129",
                        ["itemLink"] = 963,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [172287] = 
        {
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Bog Raider's Amulet",
                ["oldestTime"] = 1633082468,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185045,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 458,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1633082468,
                        ["quant"] = 1,
                        ["id"] = "1690846501",
                        ["itemLink"] = 1132,
                    },
                    [2] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1633163908,
                        ["quant"] = 1,
                        ["id"] = "1691490299",
                        ["itemLink"] = 1132,
                    },
                    [3] = 
                    {
                        ["price"] = 1650,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 600,
                        ["timestamp"] = 1633163919,
                        ["quant"] = 1,
                        ["id"] = "1691490373",
                        ["itemLink"] = 1132,
                    },
                    [4] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 1389,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1633185045,
                        ["quant"] = 1,
                        ["id"] = "1691629475",
                        ["itemLink"] = 1132,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set bog raider neck healthy",
            },
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Bog Raider's Amulet",
                ["oldestTime"] = 1633038660,
                ["wasAltered"] = true,
                ["newestTime"] = 1633243565,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3450,
                        ["guild"] = 1,
                        ["buyer"] = 618,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1633038660,
                        ["quant"] = 1,
                        ["id"] = "1690503365",
                        ["itemLink"] = 780,
                    },
                    [2] = 
                    {
                        ["price"] = 3400,
                        ["guild"] = 1,
                        ["buyer"] = 196,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633147788,
                        ["quant"] = 1,
                        ["id"] = "1691372473",
                        ["itemLink"] = 780,
                    },
                    [3] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633190652,
                        ["quant"] = 1,
                        ["id"] = "1691695329",
                        ["itemLink"] = 780,
                    },
                    [4] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1332,
                        ["wasKiosk"] = true,
                        ["seller"] = 474,
                        ["timestamp"] = 1633243565,
                        ["quant"] = 1,
                        ["id"] = "1692222259",
                        ["itemLink"] = 780,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set bog raider neck healthy",
            },
        },
    },
}
