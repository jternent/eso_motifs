GS09DataSavedVariables =
{
    ["listingseu"] = 
    {
    },
    ["listingsna"] = 
    {
    },
    ["dataeu"] = 
    {
    },
    ["datana"] = 
    {
        [86786] = 
        {
            ["50:16:5:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_waist_d.dds",
                ["itemDesc"] = "Sash of Necropotence",
                ["oldestTime"] = 1633076250,
                ["wasAltered"] = true,
                ["newestTime"] = 1633076250,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 230000,
                        ["guild"] = 1,
                        ["buyer"] = 868,
                        ["wasKiosk"] = true,
                        ["seller"] = 649,
                        ["timestamp"] = 1633076250,
                        ["quant"] = 1,
                        ["id"] = "1690817959",
                        ["itemLink"] = 1113,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary light apparel set necropotence waist divines",
            },
        },
        [45060] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_heavy_chest_d.dds",
                ["itemDesc"] = "Rubedite Cuirass of Health",
                ["oldestTime"] = 1633185963,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185963,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 180,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633185963,
                        ["quant"] = 1,
                        ["id"] = "1691640371",
                        ["itemLink"] = 2034,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel chest impenetrable",
            },
        },
        [167430] = 
        {
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Radiant Bastion",
                ["oldestTime"] = 1633042154,
                ["wasAltered"] = true,
                ["newestTime"] = 1633042154,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 646,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633042154,
                        ["quant"] = 1,
                        ["id"] = "1690529789",
                        ["itemLink"] = 810,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set radiant bastion ring healthy",
            },
        },
        [180743] = 
        {
            ["50:16:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_1hhammer_a.dds",
                ["itemDesc"] = "Plaguebreak Mace",
                ["oldestTime"] = 1633237418,
                ["wasAltered"] = true,
                ["newestTime"] = 1633237418,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9200,
                        ["guild"] = 1,
                        ["buyer"] = 1569,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1633237418,
                        ["quant"] = 1,
                        ["id"] = "1692179739",
                        ["itemLink"] = 2499,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set plaguebreak mace one-handed training",
            },
        },
        [139016] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_bowl_003.dds",
                ["itemDesc"] = "Artaeum Pickled Fish Bowl",
                ["oldestTime"] = 1632865193,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311235,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 62500,
                        ["guild"] = 1,
                        ["buyer"] = 1,
                        ["wasKiosk"] = false,
                        ["seller"] = 7,
                        ["timestamp"] = 1633311235,
                        ["quant"] = 25,
                        ["id"] = "1692862949",
                        ["itemLink"] = 4,
                    },
                    [2] = 
                    {
                        ["price"] = 2250,
                        ["guild"] = 1,
                        ["buyer"] = 265,
                        ["wasKiosk"] = true,
                        ["seller"] = 269,
                        ["timestamp"] = 1632981364,
                        ["quant"] = 1,
                        ["id"] = "1690138449",
                        ["itemLink"] = 4,
                    },
                    [3] = 
                    {
                        ["price"] = 62500,
                        ["guild"] = 1,
                        ["buyer"] = 738,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633054667,
                        ["quant"] = 25,
                        ["id"] = "1690651497",
                        ["itemLink"] = 4,
                    },
                    [4] = 
                    {
                        ["price"] = 15500,
                        ["guild"] = 1,
                        ["buyer"] = 949,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1633101525,
                        ["quant"] = 5,
                        ["id"] = "1690968641",
                        ["itemLink"] = 4,
                    },
                    [5] = 
                    {
                        ["price"] = 62500,
                        ["guild"] = 1,
                        ["buyer"] = 1151,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633136307,
                        ["quant"] = 25,
                        ["id"] = "1691256289",
                        ["itemLink"] = 4,
                    },
                    [6] = 
                    {
                        ["price"] = 62500,
                        ["guild"] = 1,
                        ["buyer"] = 2258,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1632865193,
                        ["quant"] = 25,
                        ["id"] = "1689266019",
                        ["itemLink"] = 4,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 purple epic consumable food",
            },
        },
        [135433] = 
        {
            ["50:16:3:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_bow_b.dds",
                ["itemDesc"] = "Gryphon's Bow",
                ["oldestTime"] = 1633083666,
                ["wasAltered"] = true,
                ["newestTime"] = 1633083666,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1999,
                        ["guild"] = 1,
                        ["buyer"] = 892,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633083666,
                        ["quant"] = 1,
                        ["id"] = "1690852975",
                        ["itemLink"] = 1141,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set gryphon's ferocity bow two-handed sharpened",
            },
        },
        [171786] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting2.dds",
                ["itemDesc"] = "Praxis: Markarth Wall, Wide Stone",
                ["oldestTime"] = 1632971015,
                ["wasAltered"] = true,
                ["newestTime"] = 1632971015,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 172,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632971015,
                        ["quant"] = 1,
                        ["id"] = "1690065991",
                        ["itemLink"] = 191,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [30219] = 
        {
            ["1:0:1:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_enchantment_baxe_bloodstone_r2.dds",
                ["itemDesc"] = "Bloodstone",
                ["oldestTime"] = 1632861539,
                ["wasAltered"] = true,
                ["newestTime"] = 1632861542,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1632861539,
                        ["quant"] = 200,
                        ["id"] = "1689241411",
                        ["itemLink"] = 3301,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632861540,
                        ["quant"] = 200,
                        ["id"] = "1689241419",
                        ["itemLink"] = 3301,
                    },
                    [3] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632861542,
                        ["quant"] = 200,
                        ["id"] = "1689241425",
                        ["itemLink"] = 3301,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials armor trait infused",
            },
        },
        [45837] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_024.dds",
                ["itemDesc"] = "Kuoko",
                ["oldestTime"] = 1632978532,
                ["wasAltered"] = true,
                ["newestTime"] = 1633280918,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 345,
                        ["guild"] = 1,
                        ["buyer"] = 250,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632978532,
                        ["quant"] = 11,
                        ["id"] = "1690122445",
                        ["itemLink"] = 252,
                    },
                    [2] = 
                    {
                        ["price"] = 127,
                        ["guild"] = 1,
                        ["buyer"] = 897,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633178196,
                        ["quant"] = 4,
                        ["id"] = "1691571817",
                        ["itemLink"] = 252,
                    },
                    [3] = 
                    {
                        ["price"] = 256,
                        ["guild"] = 1,
                        ["buyer"] = 1931,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633280918,
                        ["quant"] = 8,
                        ["id"] = "1692524047",
                        ["itemLink"] = 252,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials essence runestone",
            },
        },
        [71695] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 25: Aldmeri Dominion Gloves",
                ["oldestTime"] = 1633253219,
                ["wasAltered"] = true,
                ["newestTime"] = 1633253219,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 2,
                        ["buyer"] = 140,
                        ["wasKiosk"] = false,
                        ["seller"] = 134,
                        ["timestamp"] = 1633253219,
                        ["quant"] = 1,
                        ["id"] = "1692292557",
                        ["itemLink"] = 159,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [172048] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_feet_a.dds",
                ["itemDesc"] = "Shoes of Frostbite",
                ["oldestTime"] = 1633045830,
                ["wasAltered"] = true,
                ["newestTime"] = 1633045830,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 555,
                        ["guild"] = 1,
                        ["buyer"] = 674,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633045830,
                        ["quant"] = 1,
                        ["id"] = "1690564877",
                        ["itemLink"] = 857,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set frostbite feet impenetrable",
            },
            ["50:16:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_feet_a.dds",
                ["itemDesc"] = "Shoes of Frostbite",
                ["oldestTime"] = 1633182290,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182290,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1377,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633182290,
                        ["quant"] = 1,
                        ["id"] = "1691606415",
                        ["itemLink"] = 1939,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite feet impenetrable",
            },
        },
        [171285] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Style Page: Opal Nightflame Mace",
                ["oldestTime"] = 1633213401,
                ["wasAltered"] = true,
                ["newestTime"] = 1633213401,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24999,
                        ["guild"] = 1,
                        ["buyer"] = 1565,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633213401,
                        ["quant"] = 1,
                        ["id"] = "1691944045",
                        ["itemLink"] = 2289,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [147736] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 75: Sunspire Daggers",
                ["oldestTime"] = 1632877961,
                ["wasAltered"] = true,
                ["newestTime"] = 1633004183,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3999,
                        ["guild"] = 1,
                        ["buyer"] = 416,
                        ["wasKiosk"] = true,
                        ["seller"] = 417,
                        ["timestamp"] = 1633004183,
                        ["quant"] = 1,
                        ["id"] = "1690255043",
                        ["itemLink"] = 425,
                    },
                    [2] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 828,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1632877961,
                        ["quant"] = 1,
                        ["id"] = "1689371919",
                        ["itemLink"] = 425,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [79385] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_1haxe_a.dds",
                ["itemDesc"] = "Axe of the Pariah",
                ["oldestTime"] = 1633026760,
                ["wasAltered"] = true,
                ["newestTime"] = 1633026760,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2666,
                        ["guild"] = 1,
                        ["buyer"] = 63,
                        ["wasKiosk"] = false,
                        ["seller"] = 237,
                        ["timestamp"] = 1633026760,
                        ["quant"] = 1,
                        ["id"] = "1690419731",
                        ["itemLink"] = 682,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set mark of the pariah axe one-handed precise",
            },
        },
        [172060] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_2hsword_a.dds",
                ["itemDesc"] = "Greatsword of Frostbite",
                ["oldestTime"] = 1633094367,
                ["wasAltered"] = true,
                ["newestTime"] = 1633094367,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 63,
                        ["wasKiosk"] = false,
                        ["seller"] = 512,
                        ["timestamp"] = 1633094367,
                        ["quant"] = 1,
                        ["id"] = "1690915259",
                        ["itemLink"] = 1248,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set frostbite sword two-handed charged",
            },
        },
        [180765] = 
        {
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Hrothgar's Ring",
                ["oldestTime"] = 1633077871,
                ["wasAltered"] = true,
                ["newestTime"] = 1633114322,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11111,
                        ["guild"] = 1,
                        ["buyer"] = 875,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633077871,
                        ["quant"] = 1,
                        ["id"] = "1690825505",
                        ["itemLink"] = 1118,
                    },
                    [2] = 
                    {
                        ["price"] = 15555,
                        ["guild"] = 1,
                        ["buyer"] = 1010,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633114322,
                        ["quant"] = 1,
                        ["id"] = "1691068221",
                        ["itemLink"] = 1118,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set hrothgar's chill ring healthy",
            },
        },
        [139294] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_inc_altplate004.dds",
                ["itemDesc"] = "Alinor Plate, Embossed",
                ["oldestTime"] = 1633270595,
                ["wasAltered"] = true,
                ["newestTime"] = 1633270595,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1876,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633270595,
                        ["quant"] = 1,
                        ["id"] = "1692411313",
                        ["itemLink"] = 2667,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings hearth",
            },
        },
        [160543] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 85: Greymoor Axes",
                ["oldestTime"] = 1633233479,
                ["wasAltered"] = true,
                ["newestTime"] = 1633233479,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633233479,
                        ["quant"] = 1,
                        ["id"] = "1692149407",
                        ["itemLink"] = 2456,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [167968] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 96: Arkthzand Armory Helmets",
                ["oldestTime"] = 1633128038,
                ["wasAltered"] = true,
                ["newestTime"] = 1633128038,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 418,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1633128038,
                        ["quant"] = 1,
                        ["id"] = "1691167665",
                        ["itemLink"] = 1497,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45345] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_heavy_shoulders_d.dds",
                ["itemDesc"] = "Rubedite Pauldron",
                ["oldestTime"] = 1632885621,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309489,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 271,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633009347,
                        ["quant"] = 1,
                        ["id"] = "1690285217",
                        ["itemLink"] = 460,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009366,
                        ["quant"] = 1,
                        ["id"] = "1690285449",
                        ["itemLink"] = 481,
                    },
                    [3] = 
                    {
                        ["price"] = 194,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1633028919,
                        ["quant"] = 1,
                        ["id"] = "1690436755",
                        ["itemLink"] = 703,
                    },
                    [4] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633084104,
                        ["quant"] = 1,
                        ["id"] = "1690855037",
                        ["itemLink"] = 1186,
                    },
                    [5] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633129400,
                        ["quant"] = 1,
                        ["id"] = "1691180185",
                        ["itemLink"] = 1502,
                    },
                    [6] = 
                    {
                        ["price"] = 160,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633146931,
                        ["quant"] = 1,
                        ["id"] = "1691365265",
                        ["itemLink"] = 460,
                    },
                    [7] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633186017,
                        ["quant"] = 1,
                        ["id"] = "1691640809",
                        ["itemLink"] = 2060,
                    },
                    [8] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633244678,
                        ["quant"] = 1,
                        ["id"] = "1692231335",
                        ["itemLink"] = 2568,
                    },
                    [9] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633244679,
                        ["quant"] = 1,
                        ["id"] = "1692231349",
                        ["itemLink"] = 2570,
                    },
                    [10] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633244681,
                        ["quant"] = 1,
                        ["id"] = "1692231365",
                        ["itemLink"] = 2572,
                    },
                    [11] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1633309489,
                        ["quant"] = 1,
                        ["id"] = "1692843369",
                        ["itemLink"] = 481,
                    },
                    [12] = 
                    {
                        ["price"] = 269,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632885621,
                        ["quant"] = 1,
                        ["id"] = "1689459269",
                        ["itemLink"] = 460,
                    },
                    [13] = 
                    {
                        ["price"] = 269,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 240,
                        ["timestamp"] = 1632885622,
                        ["quant"] = 1,
                        ["id"] = "1689459287",
                        ["itemLink"] = 2060,
                    },
                    [14] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2501,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632930580,
                        ["quant"] = 1,
                        ["id"] = "1689726315",
                        ["itemLink"] = 2570,
                    },
                    [15] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2516,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632930837,
                        ["quant"] = 1,
                        ["id"] = "1689728281",
                        ["itemLink"] = 481,
                    },
                    [16] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2660,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632966350,
                        ["quant"] = 1,
                        ["id"] = "1690018393",
                        ["itemLink"] = 2570,
                    },
                },
                ["totalCount"] = 16,
                ["itemAdderText"] = "cp160 white normal heavy apparel shoulders intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_heavy_shoulders_d.dds",
                ["itemDesc"] = "Rubedite Pauldron",
                ["oldestTime"] = 1632956407,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309492,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 194,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1633009341,
                        ["quant"] = 1,
                        ["id"] = "1690285183",
                        ["itemLink"] = 452,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633186011,
                        ["quant"] = 1,
                        ["id"] = "1691640709",
                        ["itemLink"] = 2057,
                    },
                    [3] = 
                    {
                        ["price"] = 194,
                        ["guild"] = 1,
                        ["buyer"] = 1001,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633268081,
                        ["quant"] = 1,
                        ["id"] = "1692385991",
                        ["itemLink"] = 2656,
                    },
                    [4] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633309492,
                        ["quant"] = 1,
                        ["id"] = "1692843441",
                        ["itemLink"] = 2970,
                    },
                    [5] = 
                    {
                        ["price"] = 265,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632956407,
                        ["quant"] = 1,
                        ["id"] = "1689931679",
                        ["itemLink"] = 3895,
                    },
                    [6] = 
                    {
                        ["price"] = 120,
                        ["guild"] = 1,
                        ["buyer"] = 2646,
                        ["wasKiosk"] = true,
                        ["seller"] = 356,
                        ["timestamp"] = 1632963248,
                        ["quant"] = 1,
                        ["id"] = "1689988317",
                        ["itemLink"] = 3938,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "cp150 white normal heavy apparel shoulders intricate",
            },
        },
        [171555] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 100: True-Sworn Bows",
                ["oldestTime"] = 1632863643,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293262,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 63013,
                        ["guild"] = 1,
                        ["buyer"] = 1999,
                        ["wasKiosk"] = true,
                        ["seller"] = 712,
                        ["timestamp"] = 1633293262,
                        ["quant"] = 1,
                        ["id"] = "1692666451",
                        ["itemLink"] = 2852,
                    },
                    [2] = 
                    {
                        ["price"] = 46999,
                        ["guild"] = 1,
                        ["buyer"] = 2253,
                        ["wasKiosk"] = true,
                        ["seller"] = 451,
                        ["timestamp"] = 1632863643,
                        ["quant"] = 1,
                        ["id"] = "1689256201",
                        ["itemLink"] = 2852,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [5413] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_ore_base_iron_r2.dds",
                ["itemDesc"] = "Iron Ingot",
                ["oldestTime"] = 1632714077,
                ["wasAltered"] = true,
                ["newestTime"] = 1633312786,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 40,
                        ["wasKiosk"] = true,
                        ["seller"] = 41,
                        ["timestamp"] = 1633312775,
                        ["quant"] = 200,
                        ["id"] = "1692878259",
                        ["itemLink"] = 28,
                    },
                    [2] = 
                    {
                        ["price"] = 1824,
                        ["guild"] = 1,
                        ["buyer"] = 40,
                        ["wasKiosk"] = true,
                        ["seller"] = 41,
                        ["timestamp"] = 1633312786,
                        ["quant"] = 152,
                        ["id"] = "1692878369",
                        ["itemLink"] = 28,
                    },
                    [3] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 2,
                        ["buyer"] = 129,
                        ["wasKiosk"] = false,
                        ["seller"] = 125,
                        ["timestamp"] = 1632714077,
                        ["quant"] = 200,
                        ["id"] = "1688085769",
                        ["itemLink"] = 28,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [171560] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 100: True-Sworn Legs",
                ["oldestTime"] = 1633228255,
                ["wasAltered"] = true,
                ["newestTime"] = 1633228255,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 89700,
                        ["guild"] = 1,
                        ["buyer"] = 1666,
                        ["wasKiosk"] = true,
                        ["seller"] = 712,
                        ["timestamp"] = 1633228255,
                        ["quant"] = 1,
                        ["id"] = "1692099515",
                        ["itemLink"] = 2425,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [139305] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_inc_reliccase008.dds",
                ["itemDesc"] = "Display Case, Large",
                ["oldestTime"] = 1632872251,
                ["wasAltered"] = true,
                ["newestTime"] = 1632872251,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 2300,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1632872251,
                        ["quant"] = 2,
                        ["id"] = "1689317219",
                        ["itemLink"] = 3393,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings gallery",
            },
        },
        [147499] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/container_sealed_polymorph_001.dds",
                ["itemDesc"] = "Runebox: Guar Stomp Emote",
                ["oldestTime"] = 1633257377,
                ["wasAltered"] = true,
                ["newestTime"] = 1633257377,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 54000,
                        ["guild"] = 1,
                        ["buyer"] = 1831,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633257377,
                        ["quant"] = 1,
                        ["id"] = "1692314421",
                        ["itemLink"] = 2615,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable container",
            },
        },
        [34348] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_bread_002.dds",
                ["itemDesc"] = "Wheat",
                ["oldestTime"] = 1633305851,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305855,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1549,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 344,
                        ["timestamp"] = 1633305851,
                        ["quant"] = 200,
                        ["id"] = "1692798939",
                        ["itemLink"] = 2938,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633305855,
                        ["quant"] = 200,
                        ["id"] = "1692798995",
                        ["itemLink"] = 2938,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [144942] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_staff_a.dds",
                ["itemDesc"] = "Battalion Defender Restoration Staff",
                ["oldestTime"] = 1633060229,
                ["wasAltered"] = true,
                ["newestTime"] = 1633060229,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 899,
                        ["guild"] = 1,
                        ["buyer"] = 784,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633060229,
                        ["quant"] = 1,
                        ["id"] = "1690711785",
                        ["itemLink"] = 1007,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set battalion defender healing staff two-handed charged",
            },
        },
        [86831] = 
        {
            ["50:16:2:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_1hsword_d.dds",
                ["itemDesc"] = "Sword of Necropotence",
                ["oldestTime"] = 1633212204,
                ["wasAltered"] = true,
                ["newestTime"] = 1633212204,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 1558,
                        ["wasKiosk"] = true,
                        ["seller"] = 377,
                        ["timestamp"] = 1633212204,
                        ["quant"] = 1,
                        ["id"] = "1691931555",
                        ["itemLink"] = 2286,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set necropotence sword one-handed sharpened",
            },
        },
        [97073] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_head_d.dds",
                ["itemDesc"] = "Plague Doctor's Helm",
                ["oldestTime"] = 1633228084,
                ["wasAltered"] = true,
                ["newestTime"] = 1633228084,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4999,
                        ["guild"] = 1,
                        ["buyer"] = 1026,
                        ["wasKiosk"] = true,
                        ["seller"] = 305,
                        ["timestamp"] = 1633228084,
                        ["quant"] = 1,
                        ["id"] = "1692098003",
                        ["itemLink"] = 2420,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set plague doctor head divines",
            },
        },
        [43573] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_healthabsorbtion.dds",
                ["itemDesc"] = "Superb Glyph of Absorb Health",
                ["oldestTime"] = 1633032459,
                ["wasAltered"] = true,
                ["newestTime"] = 1633251478,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633032459,
                        ["quant"] = 1,
                        ["id"] = "1690460835",
                        ["itemLink"] = 725,
                    },
                    [2] = 
                    {
                        ["price"] = 77,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 78,
                        ["timestamp"] = 1633251478,
                        ["quant"] = 1,
                        ["id"] = "1692280579",
                        ["itemLink"] = 725,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp150 green fine miscellaneous weapon glyph",
            },
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_healthabsorbtion.dds",
                ["itemDesc"] = "Truly Superb Glyph of Absorb Health",
                ["oldestTime"] = 1633031473,
                ["wasAltered"] = true,
                ["newestTime"] = 1633031473,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 211,
                        ["wasKiosk"] = false,
                        ["seller"] = 35,
                        ["timestamp"] = 1633031473,
                        ["quant"] = 1,
                        ["id"] = "1690454105",
                        ["itemLink"] = 719,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous weapon glyph",
            },
        },
        [95289] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_heavy_legs_a.dds",
                ["itemDesc"] = "Greaves of the Fire",
                ["oldestTime"] = 1633094755,
                ["wasAltered"] = true,
                ["newestTime"] = 1633094755,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 63,
                        ["wasKiosk"] = false,
                        ["seller"] = 197,
                        ["timestamp"] = 1633094755,
                        ["quant"] = 1,
                        ["id"] = "1690917493",
                        ["itemLink"] = 1253,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set way of fire legs infused",
            },
        },
        [172090] = 
        {
            ["50:16:2:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_feet_a.dds",
                ["itemDesc"] = "Shoes of Frostbite",
                ["oldestTime"] = 1633190642,
                ["wasAltered"] = true,
                ["newestTime"] = 1633190642,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 1417,
                        ["timestamp"] = 1633190642,
                        ["quant"] = 1,
                        ["id"] = "1691695175",
                        ["itemLink"] = 2103,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite feet sturdy",
            },
        },
        [45883] = 
        {
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_increaseweapondamage.dds",
                ["itemDesc"] = "Truly Superb Glyph of Increase Physical Harm",
                ["oldestTime"] = 1632831074,
                ["wasAltered"] = true,
                ["newestTime"] = 1633284399,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 211,
                        ["wasKiosk"] = false,
                        ["seller"] = 4,
                        ["timestamp"] = 1632981886,
                        ["quant"] = 1,
                        ["id"] = "1690141103",
                        ["itemLink"] = 291,
                    },
                    [2] = 
                    {
                        ["price"] = 6300,
                        ["guild"] = 1,
                        ["buyer"] = 209,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633187506,
                        ["quant"] = 1,
                        ["id"] = "1691657337",
                        ["itemLink"] = 291,
                    },
                    [3] = 
                    {
                        ["price"] = 6300,
                        ["guild"] = 1,
                        ["buyer"] = 209,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633187508,
                        ["quant"] = 1,
                        ["id"] = "1691657371",
                        ["itemLink"] = 291,
                    },
                    [4] = 
                    {
                        ["price"] = 6300,
                        ["guild"] = 1,
                        ["buyer"] = 340,
                        ["wasKiosk"] = false,
                        ["seller"] = 173,
                        ["timestamp"] = 1633208946,
                        ["quant"] = 1,
                        ["id"] = "1691893637",
                        ["itemLink"] = 291,
                    },
                    [5] = 
                    {
                        ["price"] = 6300,
                        ["guild"] = 1,
                        ["buyer"] = 340,
                        ["wasKiosk"] = false,
                        ["seller"] = 173,
                        ["timestamp"] = 1633208948,
                        ["quant"] = 1,
                        ["id"] = "1691893671",
                        ["itemLink"] = 291,
                    },
                    [6] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 1608,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1633220347,
                        ["quant"] = 1,
                        ["id"] = "1692015647",
                        ["itemLink"] = 291,
                    },
                    [7] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 1948,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633284397,
                        ["quant"] = 1,
                        ["id"] = "1692559567",
                        ["itemLink"] = 291,
                    },
                    [8] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 1948,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633284399,
                        ["quant"] = 1,
                        ["id"] = "1692559591",
                        ["itemLink"] = 291,
                    },
                    [9] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 340,
                        ["wasKiosk"] = false,
                        ["seller"] = 173,
                        ["timestamp"] = 1632831074,
                        ["quant"] = 1,
                        ["id"] = "1689004747",
                        ["itemLink"] = 291,
                    },
                    [10] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 2254,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632863771,
                        ["quant"] = 1,
                        ["id"] = "1689256909",
                        ["itemLink"] = 291,
                    },
                    [11] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 2254,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1632863772,
                        ["quant"] = 1,
                        ["id"] = "1689256917",
                        ["itemLink"] = 291,
                    },
                    [12] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 2254,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1632863773,
                        ["quant"] = 1,
                        ["id"] = "1689256923",
                        ["itemLink"] = 291,
                    },
                },
                ["totalCount"] = 12,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous jewelry glyph",
            },
        },
        [171326] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/provisioner_orange.dds",
                ["itemDesc"] = "Cyrodiil Citrus",
                ["oldestTime"] = 1632822649,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305877,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 995,
                        ["guild"] = 1,
                        ["buyer"] = 934,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633097808,
                        ["quant"] = 1,
                        ["id"] = "1690942305",
                        ["itemLink"] = 1271,
                    },
                    [2] = 
                    {
                        ["price"] = 995,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633305877,
                        ["quant"] = 1,
                        ["id"] = "1692799197",
                        ["itemLink"] = 1271,
                    },
                    [3] = 
                    {
                        ["price"] = 3200,
                        ["guild"] = 1,
                        ["buyer"] = 2108,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1632822649,
                        ["quant"] = 4,
                        ["id"] = "1688954063",
                        ["itemLink"] = 1271,
                    },
                    [4] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 2108,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1632822649,
                        ["quant"] = 1,
                        ["id"] = "1688954065",
                        ["itemLink"] = 1271,
                    },
                    [5] = 
                    {
                        ["price"] = 995,
                        ["guild"] = 1,
                        ["buyer"] = 2108,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1632822650,
                        ["quant"] = 1,
                        ["id"] = "1688954069",
                        ["itemLink"] = 1271,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 gold legendary materials ingredient",
            },
        },
        [99647] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Spinner's Ring",
                ["oldestTime"] = 1633211926,
                ["wasAltered"] = true,
                ["newestTime"] = 1633211926,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19832,
                        ["guild"] = 1,
                        ["buyer"] = 1556,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1633211926,
                        ["quant"] = 1,
                        ["id"] = "1691927771",
                        ["itemLink"] = 2284,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set spinner's garments ring arcane",
            },
        },
        [175936] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Leyawiin Tapestry, Twin Vessels",
                ["oldestTime"] = 1633300781,
                ["wasAltered"] = true,
                ["newestTime"] = 1633300781,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 2043,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633300781,
                        ["quant"] = 1,
                        ["id"] = "1692748873",
                        ["itemLink"] = 2913,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [86849] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_waist_d.dds",
                ["itemDesc"] = "Sash of Necropotence",
                ["oldestTime"] = 1632590127,
                ["wasAltered"] = true,
                ["newestTime"] = 1632590127,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 2,
                        ["buyer"] = 117,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1632590127,
                        ["quant"] = 1,
                        ["id"] = "1686937577",
                        ["itemLink"] = 98,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set necropotence waist impenetrable",
            },
        },
        [166979] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 90: Thorn Legion Gloves",
                ["oldestTime"] = 1633292575,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292575,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 125000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 762,
                        ["timestamp"] = 1633292575,
                        ["quant"] = 1,
                        ["id"] = "1692658425",
                        ["itemLink"] = 2843,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [151621] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_shimmering_sand.dds",
                ["itemDesc"] = "Shimmering Sand",
                ["oldestTime"] = 1632863015,
                ["wasAltered"] = true,
                ["newestTime"] = 1633298147,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2750,
                        ["guild"] = 1,
                        ["buyer"] = 549,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633027690,
                        ["quant"] = 1,
                        ["id"] = "1690426083",
                        ["itemLink"] = 689,
                    },
                    [2] = 
                    {
                        ["price"] = 90731,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 466,
                        ["timestamp"] = 1633042002,
                        ["quant"] = 30,
                        ["id"] = "1690528593",
                        ["itemLink"] = 689,
                    },
                    [3] = 
                    {
                        ["price"] = 5800,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 732,
                        ["timestamp"] = 1633086243,
                        ["quant"] = 2,
                        ["id"] = "1690864863",
                        ["itemLink"] = 689,
                    },
                    [4] = 
                    {
                        ["price"] = 58000,
                        ["guild"] = 1,
                        ["buyer"] = 2033,
                        ["wasKiosk"] = true,
                        ["seller"] = 31,
                        ["timestamp"] = 1633298147,
                        ["quant"] = 20,
                        ["id"] = "1692722581",
                        ["itemLink"] = 689,
                    },
                    [5] = 
                    {
                        ["price"] = 31088,
                        ["guild"] = 1,
                        ["buyer"] = 549,
                        ["wasKiosk"] = true,
                        ["seller"] = 2123,
                        ["timestamp"] = 1632863015,
                        ["quant"] = 10,
                        ["id"] = "1689251611",
                        ["itemLink"] = 689,
                    },
                    [6] = 
                    {
                        ["price"] = 64000,
                        ["guild"] = 1,
                        ["buyer"] = 2271,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1632868218,
                        ["quant"] = 20,
                        ["id"] = "1689289397",
                        ["itemLink"] = 689,
                    },
                    [7] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 2271,
                        ["wasKiosk"] = true,
                        ["seller"] = 625,
                        ["timestamp"] = 1632868220,
                        ["quant"] = 10,
                        ["id"] = "1689289407",
                        ["itemLink"] = 689,
                    },
                    [8] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 2271,
                        ["wasKiosk"] = true,
                        ["seller"] = 625,
                        ["timestamp"] = 1632868222,
                        ["quant"] = 10,
                        ["id"] = "1689289423",
                        ["itemLink"] = 689,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [139080] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_tre_sum_coraltree008.dds",
                ["itemDesc"] = "Coral Formation, Ancient Pillar Polyps",
                ["oldestTime"] = 1633042123,
                ["wasAltered"] = true,
                ["newestTime"] = 1633042123,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 645,
                        ["wasKiosk"] = true,
                        ["seller"] = 323,
                        ["timestamp"] = 1633042123,
                        ["quant"] = 2,
                        ["id"] = "1690529447",
                        ["itemLink"] = 808,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings conservatory",
            },
        },
        [115529] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_arg_lsb_mrklamp001.dds",
                ["itemDesc"] = "Argonian Lanterns, String",
                ["oldestTime"] = 1633311560,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311560,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 36000,
                        ["guild"] = 1,
                        ["buyer"] = 16,
                        ["wasKiosk"] = true,
                        ["seller"] = 17,
                        ["timestamp"] = 1633311560,
                        ["quant"] = 2,
                        ["id"] = "1692865531",
                        ["itemLink"] = 11,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [87882] = 
        {
            ["50:16:4:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_1hhammer_a.dds",
                ["itemDesc"] = "Deadly Mace",
                ["oldestTime"] = 1632993773,
                ["wasAltered"] = true,
                ["newestTime"] = 1632993773,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 369,
                        ["wasKiosk"] = true,
                        ["seller"] = 356,
                        ["timestamp"] = 1632993773,
                        ["quant"] = 1,
                        ["id"] = "1690204697",
                        ["itemLink"] = 365,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set deadly strike mace one-handed powered",
            },
        },
        [171596] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_chokeberry_extract.dds",
                ["itemDesc"] = "Chokeberry Extract",
                ["oldestTime"] = 1633121979,
                ["wasAltered"] = true,
                ["newestTime"] = 1633121979,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 21000,
                        ["guild"] = 1,
                        ["buyer"] = 1062,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633121979,
                        ["quant"] = 7,
                        ["id"] = "1691119301",
                        ["itemLink"] = 1445,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [175693] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_csb_leymerchantcartopen001.dds",
                ["itemDesc"] = "Leyawiin Merchant Stall, Portable",
                ["oldestTime"] = 1632879944,
                ["wasAltered"] = true,
                ["newestTime"] = 1632879944,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 2331,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1632879944,
                        ["quant"] = 1,
                        ["id"] = "1689396087",
                        ["itemLink"] = 3452,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings courtyard",
            },
        },
        [181582] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting2.dds",
                ["itemDesc"] = "Praxis: Leyawiin Wall, Curved Garden",
                ["oldestTime"] = 1633035664,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309209,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 333,
                        ["wasKiosk"] = false,
                        ["seller"] = 514,
                        ["timestamp"] = 1633035664,
                        ["quant"] = 1,
                        ["id"] = "1690480319",
                        ["itemLink"] = 769,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 514,
                        ["timestamp"] = 1633060385,
                        ["quant"] = 1,
                        ["id"] = "1690713557",
                        ["itemLink"] = 769,
                    },
                    [3] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 733,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1633127986,
                        ["quant"] = 1,
                        ["id"] = "1691167413",
                        ["itemLink"] = 769,
                    },
                    [4] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1589,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633216455,
                        ["quant"] = 1,
                        ["id"] = "1691972859",
                        ["itemLink"] = 769,
                    },
                    [5] = 
                    {
                        ["price"] = 6358,
                        ["guild"] = 1,
                        ["buyer"] = 778,
                        ["wasKiosk"] = false,
                        ["seller"] = 550,
                        ["timestamp"] = 1633309209,
                        ["quant"] = 1,
                        ["id"] = "1692839205",
                        ["itemLink"] = 769,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [172111] = 
        {
            ["50:16:2:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_feet_a.dds",
                ["itemDesc"] = "Shoes of Frostbite",
                ["oldestTime"] = 1633308724,
                ["wasAltered"] = true,
                ["newestTime"] = 1633308724,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1040,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1633308724,
                        ["quant"] = 1,
                        ["id"] = "1692831831",
                        ["itemLink"] = 2962,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite feet training",
            },
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_feet_a.dds",
                ["itemDesc"] = "Shoes of Frostbite",
                ["oldestTime"] = 1633045827,
                ["wasAltered"] = true,
                ["newestTime"] = 1633045827,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 674,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633045827,
                        ["quant"] = 1,
                        ["id"] = "1690564823",
                        ["itemLink"] = 855,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set frostbite feet training",
            },
        },
        [43601] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Stormhaven Treasure Map I",
                ["oldestTime"] = 1633011637,
                ["wasAltered"] = true,
                ["newestTime"] = 1633011637,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 454,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633011637,
                        ["quant"] = 1,
                        ["id"] = "1690301513",
                        ["itemLink"] = 518,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [98388] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_heavy_waist_d.dds",
                ["itemDesc"] = "Beekeeper's Girdle",
                ["oldestTime"] = 1632922146,
                ["wasAltered"] = true,
                ["newestTime"] = 1632922146,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1403,
                        ["wasKiosk"] = true,
                        ["seller"] = 442,
                        ["timestamp"] = 1632922146,
                        ["quant"] = 1,
                        ["id"] = "1689666731",
                        ["itemLink"] = 3658,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set beekeeper's gear waist well-fitted",
            },
        },
        [123736] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_light_robe_a.dds",
                ["itemDesc"] = "Wizard's Riposte Robe",
                ["oldestTime"] = 1633022976,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022976,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 529,
                        ["timestamp"] = 1633022976,
                        ["quant"] = 1,
                        ["id"] = "1690390411",
                        ["itemLink"] = 616,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set wizard's riposte chest infused",
            },
        },
        [82009] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 41: Celestial Boots",
                ["oldestTime"] = 1633052846,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052846,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 719,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633052846,
                        ["quant"] = 1,
                        ["id"] = "1690633741",
                        ["itemLink"] = 919,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [158298] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 83: Pyre Watch Gloves",
                ["oldestTime"] = 1633296507,
                ["wasAltered"] = true,
                ["newestTime"] = 1633296507,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 2021,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633296507,
                        ["quant"] = 1,
                        ["id"] = "1692706095",
                        ["itemLink"] = 2883,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [126043] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_buoyantarmiger_1hsword_a.dds",
                ["itemDesc"] = "Blade of the Warrior-Poet",
                ["oldestTime"] = 1632990212,
                ["wasAltered"] = true,
                ["newestTime"] = 1632990212,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1632990212,
                        ["quant"] = 1,
                        ["id"] = "1690188431",
                        ["itemLink"] = 348,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set warrior-poet sword one-handed decisive",
            },
        },
        [172126] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_2haxe_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Battle Axe",
                ["oldestTime"] = 1633069110,
                ["wasAltered"] = true,
                ["newestTime"] = 1633069110,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633069110,
                        ["quant"] = 1,
                        ["id"] = "1690773097",
                        ["itemLink"] = 1079,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set deadlands assassin axe two-handed infused",
            },
        },
        [45922] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Fried Green Tomatoes",
                ["oldestTime"] = 1633242682,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242682,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50,
                        ["guild"] = 1,
                        ["buyer"] = 348,
                        ["wasKiosk"] = false,
                        ["seller"] = 222,
                        ["timestamp"] = 1633242682,
                        ["quant"] = 1,
                        ["id"] = "1692215175",
                        ["itemLink"] = 2542,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [160611] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 88: Ancestral Orc Axes",
                ["oldestTime"] = 1633143396,
                ["wasAltered"] = true,
                ["newestTime"] = 1633143396,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 1213,
                        ["wasKiosk"] = true,
                        ["seller"] = 1214,
                        ["timestamp"] = 1633143396,
                        ["quant"] = 1,
                        ["id"] = "1691330397",
                        ["itemLink"] = 1631,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [76902] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 38: Draugr Helmets",
                ["oldestTime"] = 1632907336,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292390,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2700,
                        ["guild"] = 1,
                        ["buyer"] = 1991,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633292390,
                        ["quant"] = 1,
                        ["id"] = "1692656183",
                        ["itemLink"] = 2826,
                    },
                    [2] = 
                    {
                        ["price"] = 5144,
                        ["guild"] = 1,
                        ["buyer"] = 2455,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1632907336,
                        ["quant"] = 1,
                        ["id"] = "1689593629",
                        ["itemLink"] = 2826,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45671] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Dawnstar Sun's Dusk Chowder",
                ["oldestTime"] = 1632930609,
                ["wasAltered"] = true,
                ["newestTime"] = 1632930609,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 2194,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632930609,
                        ["quant"] = 1,
                        ["id"] = "1689726619",
                        ["itemLink"] = 3706,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [98408] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_heavy_waist_d.dds",
                ["itemDesc"] = "Beekeeper's Girdle",
                ["oldestTime"] = 1633087781,
                ["wasAltered"] = true,
                ["newestTime"] = 1633087781,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 909,
                        ["wasKiosk"] = true,
                        ["seller"] = 737,
                        ["timestamp"] = 1633087781,
                        ["quant"] = 1,
                        ["id"] = "1690875059",
                        ["itemLink"] = 1229,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set beekeeper's gear waist reinforced",
            },
        },
        [45163] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_2hsword_d.dds",
                ["itemDesc"] = "Rubedite Greatsword of Frost",
                ["oldestTime"] = 1632830174,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950118,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 470,
                        ["guild"] = 1,
                        ["buyer"] = 2131,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1632830174,
                        ["quant"] = 1,
                        ["id"] = "1688999333",
                        ["itemLink"] = 3064,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1632950118,
                        ["quant"] = 1,
                        ["id"] = "1689875089",
                        ["itemLink"] = 3814,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior weapon sword two-handed defending",
            },
        },
        [76908] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 38: Draugr Swords",
                ["oldestTime"] = 1632870379,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310176,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 2,
                        ["buyer"] = 114,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1632870379,
                        ["quant"] = 1,
                        ["id"] = "1689305813",
                        ["itemLink"] = 142,
                    },
                    [2] = 
                    {
                        ["price"] = 2700,
                        ["guild"] = 1,
                        ["buyer"] = 2085,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633310176,
                        ["quant"] = 1,
                        ["id"] = "1692850979",
                        ["itemLink"] = 142,
                    },
                    [3] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2397,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1632887204,
                        ["quant"] = 1,
                        ["id"] = "1689472305",
                        ["itemLink"] = 142,
                    },
                    [4] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1872,
                        ["wasKiosk"] = true,
                        ["seller"] = 729,
                        ["timestamp"] = 1632939833,
                        ["quant"] = 1,
                        ["id"] = "1689793947",
                        ["itemLink"] = 142,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [42861] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_slaughterfish.dds",
                ["itemDesc"] = "Slaughterfish",
                ["oldestTime"] = 1632884660,
                ["wasAltered"] = true,
                ["newestTime"] = 1633283502,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 218,
                        ["timestamp"] = 1633024180,
                        ["quant"] = 20,
                        ["id"] = "1690399475",
                        ["itemLink"] = 672,
                    },
                    [2] = 
                    {
                        ["price"] = 160000,
                        ["guild"] = 1,
                        ["buyer"] = 1169,
                        ["wasKiosk"] = true,
                        ["seller"] = 577,
                        ["timestamp"] = 1633138533,
                        ["quant"] = 200,
                        ["id"] = "1691277921",
                        ["itemLink"] = 672,
                    },
                    [3] = 
                    {
                        ["price"] = 18700,
                        ["guild"] = 1,
                        ["buyer"] = 1945,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633283502,
                        ["quant"] = 34,
                        ["id"] = "1692551421",
                        ["itemLink"] = 672,
                    },
                    [4] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 218,
                        ["timestamp"] = 1632884660,
                        ["quant"] = 20,
                        ["id"] = "1689447949",
                        ["itemLink"] = 672,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 white normal consumable fish",
            },
        },
        [121199] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning5.dds",
                ["itemDesc"] = "Design: Mortar and Pestle",
                ["oldestTime"] = 1632995538,
                ["wasAltered"] = true,
                ["newestTime"] = 1632995538,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 71400,
                        ["guild"] = 1,
                        ["buyer"] = 380,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1632995538,
                        ["quant"] = 1,
                        ["id"] = "1690211789",
                        ["itemLink"] = 379,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable recipe",
            },
        },
        [56944] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Sweet Skeever Gumbo",
                ["oldestTime"] = 1632923740,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242689,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1350,
                        ["guild"] = 1,
                        ["buyer"] = 348,
                        ["wasKiosk"] = false,
                        ["seller"] = 479,
                        ["timestamp"] = 1633242689,
                        ["quant"] = 1,
                        ["id"] = "1692215231",
                        ["itemLink"] = 2547,
                    },
                    [2] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632923740,
                        ["quant"] = 1,
                        ["id"] = "1689677543",
                        ["itemLink"] = 2547,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [171891] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 103: Black Fin Legion Staves",
                ["oldestTime"] = 1633021617,
                ["wasAltered"] = true,
                ["newestTime"] = 1633280781,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 281,
                        ["wasKiosk"] = false,
                        ["seller"] = 35,
                        ["timestamp"] = 1633021617,
                        ["quant"] = 1,
                        ["id"] = "1690380185",
                        ["itemLink"] = 584,
                    },
                    [2] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1129,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633133968,
                        ["quant"] = 1,
                        ["id"] = "1691230735",
                        ["itemLink"] = 584,
                    },
                    [3] = 
                    {
                        ["price"] = 49000,
                        ["guild"] = 1,
                        ["buyer"] = 550,
                        ["wasKiosk"] = false,
                        ["seller"] = 1450,
                        ["timestamp"] = 1633276035,
                        ["quant"] = 1,
                        ["id"] = "1692476301",
                        ["itemLink"] = 584,
                    },
                    [4] = 
                    {
                        ["price"] = 49000,
                        ["guild"] = 1,
                        ["buyer"] = 511,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633280781,
                        ["quant"] = 1,
                        ["id"] = "1692522961",
                        ["itemLink"] = 584,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [126581] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/justice_stolen_device_001.dds",
                ["itemDesc"] = "Dwarven Construct Repair Parts",
                ["oldestTime"] = 1633009833,
                ["wasAltered"] = true,
                ["newestTime"] = 1633204747,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19999,
                        ["guild"] = 1,
                        ["buyer"] = 447,
                        ["wasKiosk"] = true,
                        ["seller"] = 417,
                        ["timestamp"] = 1633009833,
                        ["quant"] = 1,
                        ["id"] = "1690289033",
                        ["itemLink"] = 513,
                    },
                    [2] = 
                    {
                        ["price"] = 24763,
                        ["guild"] = 1,
                        ["buyer"] = 447,
                        ["wasKiosk"] = true,
                        ["seller"] = 327,
                        ["timestamp"] = 1633119760,
                        ["quant"] = 1,
                        ["id"] = "1691103565",
                        ["itemLink"] = 513,
                    },
                    [3] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 1353,
                        ["wasKiosk"] = true,
                        ["seller"] = 732,
                        ["timestamp"] = 1633175960,
                        ["quant"] = 1,
                        ["id"] = "1691553731",
                        ["itemLink"] = 513,
                    },
                    [4] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 1129,
                        ["wasKiosk"] = true,
                        ["seller"] = 734,
                        ["timestamp"] = 1633204744,
                        ["quant"] = 1,
                        ["id"] = "1691840227",
                        ["itemLink"] = 513,
                    },
                    [5] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 1129,
                        ["wasKiosk"] = true,
                        ["seller"] = 734,
                        ["timestamp"] = 1633204745,
                        ["quant"] = 1,
                        ["id"] = "1691840235",
                        ["itemLink"] = 513,
                    },
                    [6] = 
                    {
                        ["price"] = 30500,
                        ["guild"] = 1,
                        ["buyer"] = 1129,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633204746,
                        ["quant"] = 1,
                        ["id"] = "1691840243",
                        ["itemLink"] = 513,
                    },
                    [7] = 
                    {
                        ["price"] = 31000,
                        ["guild"] = 1,
                        ["buyer"] = 1129,
                        ["wasKiosk"] = true,
                        ["seller"] = 461,
                        ["timestamp"] = 1633204747,
                        ["quant"] = 1,
                        ["id"] = "1691840249",
                        ["itemLink"] = 513,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr01 gold legendary materials furnishing",
            },
        },
        [99190] = 
        {
            ["50:16:2:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_2hhammer_d.dds",
                ["itemDesc"] = "Maul of the Hatchling's Shell",
                ["oldestTime"] = 1633193176,
                ["wasAltered"] = true,
                ["newestTime"] = 1633193176,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 1432,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1633193176,
                        ["quant"] = 1,
                        ["id"] = "1691725767",
                        ["itemLink"] = 2118,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set hatchling's shell mace two-handed decisive",
            },
        },
        [68215] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Soothing Bard's-Throat Tea",
                ["oldestTime"] = 1633261628,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261628,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633261628,
                        ["quant"] = 1,
                        ["id"] = "1692334491",
                        ["itemLink"] = 2624,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [68474] = 
        {
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_snowreach_medium_shoulders_a.dds",
                ["itemDesc"] = "Briarheart Arm Cops",
                ["oldestTime"] = 1633023025,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023043,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 533,
                        ["timestamp"] = 1633023025,
                        ["quant"] = 1,
                        ["id"] = "1690390871",
                        ["itemLink"] = 649,
                    },
                    [2] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 534,
                        ["timestamp"] = 1633023043,
                        ["quant"] = 1,
                        ["id"] = "1690391007",
                        ["itemLink"] = 649,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine medium apparel set briarheart shoulders well-fitted",
            },
        },
        [45180] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_bow_d.dds",
                ["itemDesc"] = "Ruby Ash Bow of Frost",
                ["oldestTime"] = 1633179506,
                ["wasAltered"] = true,
                ["newestTime"] = 1633179506,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 240,
                        ["guild"] = 1,
                        ["buyer"] = 1363,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633179506,
                        ["quant"] = 1,
                        ["id"] = "1691583057",
                        ["itemLink"] = 1915,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon bow two-handed defending",
            },
        },
        [134781] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 59: Scalecaller Maces",
                ["oldestTime"] = 1633222677,
                ["wasAltered"] = true,
                ["newestTime"] = 1633222677,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 1621,
                        ["wasKiosk"] = true,
                        ["seller"] = 1622,
                        ["timestamp"] = 1633222677,
                        ["quant"] = 1,
                        ["id"] = "1692039311",
                        ["itemLink"] = 2361,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [71295] = 
        {
            ["50:16:5:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_ring_a.dds",
                ["itemDesc"] = "Briarheart Band",
                ["oldestTime"] = 1632887590,
                ["wasAltered"] = true,
                ["newestTime"] = 1632887590,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900000,
                        ["guild"] = 1,
                        ["buyer"] = 2400,
                        ["wasKiosk"] = true,
                        ["seller"] = 1145,
                        ["timestamp"] = 1632887590,
                        ["quant"] = 1,
                        ["id"] = "1689475729",
                        ["itemLink"] = 3525,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary jewelry apparel set briarheart ring robust",
            },
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_ring_a.dds",
                ["itemDesc"] = "Briarheart Band",
                ["oldestTime"] = 1633026067,
                ["wasAltered"] = true,
                ["newestTime"] = 1633078359,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 542,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633026067,
                        ["quant"] = 1,
                        ["id"] = "1690414319",
                        ["itemLink"] = 679,
                    },
                    [2] = 
                    {
                        ["price"] = 4085,
                        ["guild"] = 1,
                        ["buyer"] = 876,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1633078354,
                        ["quant"] = 1,
                        ["id"] = "1690827999",
                        ["itemLink"] = 679,
                    },
                    [3] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 876,
                        ["wasKiosk"] = true,
                        ["seller"] = 529,
                        ["timestamp"] = 1633078359,
                        ["quant"] = 1,
                        ["id"] = "1690828003",
                        ["itemLink"] = 679,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set briarheart ring robust",
            },
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_ring_a.dds",
                ["itemDesc"] = "Briarheart Band",
                ["oldestTime"] = 1633017376,
                ["wasAltered"] = true,
                ["newestTime"] = 1633220027,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 485,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633017376,
                        ["quant"] = 1,
                        ["id"] = "1690344147",
                        ["itemLink"] = 552,
                    },
                    [2] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 1526,
                        ["wasKiosk"] = true,
                        ["seller"] = 232,
                        ["timestamp"] = 1633206142,
                        ["quant"] = 1,
                        ["id"] = "1691857111",
                        ["itemLink"] = 552,
                    },
                    [3] = 
                    {
                        ["price"] = 70500,
                        ["guild"] = 1,
                        ["buyer"] = 1608,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633220026,
                        ["quant"] = 1,
                        ["id"] = "1692012715",
                        ["itemLink"] = 552,
                    },
                    [4] = 
                    {
                        ["price"] = 73236,
                        ["guild"] = 1,
                        ["buyer"] = 1608,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1633220027,
                        ["quant"] = 1,
                        ["id"] = "1692012727",
                        ["itemLink"] = 552,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set briarheart ring robust",
            },
        },
        [85121] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_light_waist_d.dds",
                ["itemDesc"] = "Sash of Syrabane",
                ["oldestTime"] = 1633315875,
                ["wasAltered"] = true,
                ["newestTime"] = 1633315875,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 109,
                        ["wasKiosk"] = false,
                        ["seller"] = 107,
                        ["timestamp"] = 1633315875,
                        ["quant"] = 1,
                        ["id"] = "1692913413",
                        ["itemLink"] = 80,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set syrabane's grip waist divines",
            },
        },
        [171907] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 101: Ivory Brigade Shoulders",
                ["oldestTime"] = 1633050695,
                ["wasAltered"] = true,
                ["newestTime"] = 1633226628,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 701,
                        ["wasKiosk"] = true,
                        ["seller"] = 505,
                        ["timestamp"] = 1633050695,
                        ["quant"] = 1,
                        ["id"] = "1690611761",
                        ["itemLink"] = 891,
                    },
                    [2] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 238,
                        ["wasKiosk"] = false,
                        ["seller"] = 1128,
                        ["timestamp"] = 1633181481,
                        ["quant"] = 1,
                        ["id"] = "1691599361",
                        ["itemLink"] = 891,
                    },
                    [3] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1461,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633197070,
                        ["quant"] = 1,
                        ["id"] = "1691759513",
                        ["itemLink"] = 891,
                    },
                    [4] = 
                    {
                        ["price"] = 9900,
                        ["guild"] = 1,
                        ["buyer"] = 1570,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633214346,
                        ["quant"] = 1,
                        ["id"] = "1691953067",
                        ["itemLink"] = 891,
                    },
                    [5] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1654,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633226614,
                        ["quant"] = 1,
                        ["id"] = "1692081323",
                        ["itemLink"] = 891,
                    },
                    [6] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1654,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633226628,
                        ["quant"] = 1,
                        ["id"] = "1692081435",
                        ["itemLink"] = 891,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [177030] = 
        {
            ["1:0:3:50:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_boots_heavy.dds",
                ["itemDesc"] = "Companion's Sabatons",
                ["oldestTime"] = 1633031232,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293813,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 49999,
                        ["guild"] = 1,
                        ["buyer"] = 564,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633031232,
                        ["quant"] = 1,
                        ["id"] = "1690452619",
                        ["itemLink"] = 716,
                    },
                    [2] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1761,
                        ["wasKiosk"] = true,
                        ["seller"] = 155,
                        ["timestamp"] = 1633239651,
                        ["quant"] = 1,
                        ["id"] = "1692194733",
                        ["itemLink"] = 716,
                    },
                    [3] = 
                    {
                        ["price"] = 49999,
                        ["guild"] = 1,
                        ["buyer"] = 2001,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633293813,
                        ["quant"] = 1,
                        ["id"] = "1692673733",
                        ["itemLink"] = 716,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior heavy apparel feet bolstered",
            },
        },
        [45191] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Lightning Staff of Frost",
                ["oldestTime"] = 1632939486,
                ["wasAltered"] = true,
                ["newestTime"] = 1633179502,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 225,
                        ["guild"] = 1,
                        ["buyer"] = 1363,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633179497,
                        ["quant"] = 1,
                        ["id"] = "1691582985",
                        ["itemLink"] = 1912,
                    },
                    [2] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1363,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633179502,
                        ["quant"] = 1,
                        ["id"] = "1691583025",
                        ["itemLink"] = 1914,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2539,
                        ["wasKiosk"] = true,
                        ["seller"] = 171,
                        ["timestamp"] = 1632939486,
                        ["quant"] = 1,
                        ["id"] = "1689791113",
                        ["itemLink"] = 3759,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 blue superior weapon lightning staff two-handed defending",
            },
            ["50:16:1:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Lightning Staff",
                ["oldestTime"] = 1632826463,
                ["wasAltered"] = true,
                ["newestTime"] = 1632826463,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1632826463,
                        ["quant"] = 1,
                        ["id"] = "1688971669",
                        ["itemLink"] = 3039,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal weapon lightning staff two-handed defending",
            },
        },
        [129673] = 
        {
            ["50:16:2:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_staff_a.dds",
                ["itemDesc"] = "Restoration Staff of the Pariah",
                ["oldestTime"] = 1633278428,
                ["wasAltered"] = true,
                ["newestTime"] = 1633278428,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1902,
                        ["wasKiosk"] = true,
                        ["seller"] = 597,
                        ["timestamp"] = 1633278428,
                        ["quant"] = 1,
                        ["id"] = "1692499815",
                        ["itemLink"] = 2719,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set mark of the pariah healing staff two-handed charged",
            },
        },
        [171915] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 102: Sul-Xan Boots",
                ["oldestTime"] = 1633008426,
                ["wasAltered"] = true,
                ["newestTime"] = 1633276047,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 169000,
                        ["guild"] = 1,
                        ["buyer"] = 437,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1633008426,
                        ["quant"] = 1,
                        ["id"] = "1690279351",
                        ["itemLink"] = 446,
                    },
                    [2] = 
                    {
                        ["price"] = 100000,
                        ["guild"] = 1,
                        ["buyer"] = 550,
                        ["wasKiosk"] = false,
                        ["seller"] = 1450,
                        ["timestamp"] = 1633276047,
                        ["quant"] = 1,
                        ["id"] = "1692476359",
                        ["itemLink"] = 446,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [75149] = 
        {
            ["50:16:4:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_dagger_a.dds",
                ["itemDesc"] = "Dagger of the Night Mother",
                ["oldestTime"] = 1633244186,
                ["wasAltered"] = true,
                ["newestTime"] = 1633244186,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4200,
                        ["guild"] = 1,
                        ["buyer"] = 1788,
                        ["wasKiosk"] = true,
                        ["seller"] = 94,
                        ["timestamp"] = 1633244186,
                        ["quant"] = 1,
                        ["id"] = "1692227145",
                        ["itemLink"] = 2562,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set night mother's embrace dagger one-handed powered",
            },
        },
        [180623] = 
        {
            ["50:16:4:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_1hhammer_a.dds",
                ["itemDesc"] = "Plaguebreak Mace",
                ["oldestTime"] = 1633283359,
                ["wasAltered"] = true,
                ["newestTime"] = 1633283359,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 1944,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1633283359,
                        ["quant"] = 1,
                        ["id"] = "1692550073",
                        ["itemLink"] = 2749,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set plaguebreak mace one-handed powered",
            },
        },
        [87698] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/event_halloween_2016_spooky_recipe.dds",
                ["itemDesc"] = "Recipe: Purifying Bloody Mara",
                ["oldestTime"] = 1633135769,
                ["wasAltered"] = true,
                ["newestTime"] = 1633135769,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 1144,
                        ["wasKiosk"] = true,
                        ["seller"] = 1145,
                        ["timestamp"] = 1633135769,
                        ["quant"] = 1,
                        ["id"] = "1691251271",
                        ["itemLink"] = 1562,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable recipe",
            },
        },
        [56979] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Velothi Cabbage Soup",
                ["oldestTime"] = 1632867570,
                ["wasAltered"] = true,
                ["newestTime"] = 1632956046,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2046,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632867570,
                        ["quant"] = 1,
                        ["id"] = "1689284763",
                        ["itemLink"] = 3365,
                    },
                    [2] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2046,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632956046,
                        ["quant"] = 1,
                        ["id"] = "1689927911",
                        ["itemLink"] = 3365,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [140437] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 64: Pyandonean Legs",
                ["oldestTime"] = 1633272676,
                ["wasAltered"] = true,
                ["newestTime"] = 1633272676,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 419,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633272676,
                        ["quant"] = 1,
                        ["id"] = "1692433973",
                        ["itemLink"] = 2680,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [71574] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 23: Malacath Helmets",
                ["oldestTime"] = 1633304423,
                ["wasAltered"] = true,
                ["newestTime"] = 1633304423,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 2058,
                        ["wasKiosk"] = true,
                        ["seller"] = 1720,
                        ["timestamp"] = 1633304423,
                        ["quant"] = 1,
                        ["id"] = "1692784429",
                        ["itemLink"] = 2925,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [166040] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Western Skyrim Treasure Map I",
                ["oldestTime"] = 1632590170,
                ["wasAltered"] = true,
                ["newestTime"] = 1632590170,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 2,
                        ["buyer"] = 117,
                        ["wasKiosk"] = false,
                        ["seller"] = 122,
                        ["timestamp"] = 1632590170,
                        ["quant"] = 1,
                        ["id"] = "1686937947",
                        ["itemLink"] = 101,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [161433] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_legs_d.dds",
                ["itemDesc"] = "Stuhn's Greaves",
                ["oldestTime"] = 1632930969,
                ["wasAltered"] = true,
                ["newestTime"] = 1632930969,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 2517,
                        ["wasKiosk"] = true,
                        ["seller"] = 819,
                        ["timestamp"] = 1632930969,
                        ["quant"] = 1,
                        ["id"] = "1689729011",
                        ["itemLink"] = 3712,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set stuhn's favor legs impenetrable",
            },
        },
        [167322] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_str_solitudefireplacehi001.dds",
                ["itemDesc"] = "Solitude Fireplace, Ornate",
                ["oldestTime"] = 1633091320,
                ["wasAltered"] = true,
                ["newestTime"] = 1633091320,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 920,
                        ["wasKiosk"] = true,
                        ["seller"] = 312,
                        ["timestamp"] = 1633091320,
                        ["quant"] = 1,
                        ["id"] = "1690897033",
                        ["itemLink"] = 1245,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings structures",
            },
        },
        [71580] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 23: Malacath Swords",
                ["oldestTime"] = 1632970191,
                ["wasAltered"] = true,
                ["newestTime"] = 1633226586,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7999,
                        ["guild"] = 1,
                        ["buyer"] = 160,
                        ["wasKiosk"] = true,
                        ["seller"] = 163,
                        ["timestamp"] = 1632970191,
                        ["quant"] = 1,
                        ["id"] = "1690058799",
                        ["itemLink"] = 172,
                    },
                    [2] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633203254,
                        ["quant"] = 1,
                        ["id"] = "1691825879",
                        ["itemLink"] = 172,
                    },
                    [3] = 
                    {
                        ["price"] = 7750,
                        ["guild"] = 1,
                        ["buyer"] = 1654,
                        ["wasKiosk"] = true,
                        ["seller"] = 479,
                        ["timestamp"] = 1633226586,
                        ["quant"] = 1,
                        ["id"] = "1692080963",
                        ["itemLink"] = 172,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [95389] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_heavy_legs_a.dds",
                ["itemDesc"] = "Greaves of the Fire",
                ["oldestTime"] = 1633082636,
                ["wasAltered"] = true,
                ["newestTime"] = 1633082636,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 298,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1633082636,
                        ["quant"] = 1,
                        ["id"] = "1690848473",
                        ["itemLink"] = 1136,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set way of fire legs invigorating",
            },
        },
        [34667] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_staff_d.dds",
                ["itemDesc"] = "Stunning Wormstaff of Syrabane",
                ["oldestTime"] = 1632964386,
                ["wasAltered"] = true,
                ["newestTime"] = 1632964386,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2103,
                        ["guild"] = 1,
                        ["buyer"] = 2650,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1632964386,
                        ["quant"] = 1,
                        ["id"] = "1689999187",
                        ["itemLink"] = 3945,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set syrabane's grip lightning staff two-handed infused",
            },
        },
        [79432] = 
        {
            ["50:16:4:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_staff_a.dds",
                ["itemDesc"] = "Restoration Staff of the Pariah",
                ["oldestTime"] = 1632961765,
                ["wasAltered"] = true,
                ["newestTime"] = 1632961765,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2213,
                        ["guild"] = 1,
                        ["buyer"] = 2634,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1632961765,
                        ["quant"] = 1,
                        ["id"] = "1689973235",
                        ["itemLink"] = 3927,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set mark of the pariah healing staff two-handed decisive",
            },
        },
        [171585] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 99: Waking Flame Chests",
                ["oldestTime"] = 1632961684,
                ["wasAltered"] = true,
                ["newestTime"] = 1632961684,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 520000,
                        ["guild"] = 1,
                        ["buyer"] = 2632,
                        ["wasKiosk"] = false,
                        ["seller"] = 2633,
                        ["timestamp"] = 1632961684,
                        ["quant"] = 1,
                        ["id"] = "1689972333",
                        ["itemLink"] = 3926,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [151714] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_fur_housingwinerack001.dds",
                ["itemDesc"] = "Elsweyr Winerack, Cane Mead",
                ["oldestTime"] = 1633150058,
                ["wasAltered"] = true,
                ["newestTime"] = 1633150058,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 29000,
                        ["guild"] = 1,
                        ["buyer"] = 1256,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633150058,
                        ["quant"] = 1,
                        ["id"] = "1691391521",
                        ["itemLink"] = 1716,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings hearth",
            },
        },
        [115911] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Breton Bench, Plain",
                ["oldestTime"] = 1632957856,
                ["wasAltered"] = true,
                ["newestTime"] = 1632957856,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 727,
                        ["guild"] = 1,
                        ["buyer"] = 2618,
                        ["wasKiosk"] = true,
                        ["seller"] = 528,
                        ["timestamp"] = 1632957856,
                        ["quant"] = 1,
                        ["id"] = "1689942057",
                        ["itemLink"] = 3907,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [45093] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_2hsword_d.dds",
                ["itemDesc"] = "Rubedite Greatsword of Frost",
                ["oldestTime"] = 1632950119,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185926,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 240,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633185926,
                        ["quant"] = 1,
                        ["id"] = "1691639907",
                        ["itemLink"] = 2016,
                    },
                    [2] = 
                    {
                        ["price"] = 425,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632950119,
                        ["quant"] = 1,
                        ["id"] = "1689875103",
                        ["itemLink"] = 3815,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior weapon sword two-handed precise",
            },
        },
        [45989] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Surilie Syrah Wine",
                ["oldestTime"] = 1632898712,
                ["wasAltered"] = true,
                ["newestTime"] = 1632898712,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 290,
                        ["guild"] = 1,
                        ["buyer"] = 1304,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1632898712,
                        ["quant"] = 1,
                        ["id"] = "1689551291",
                        ["itemLink"] = 3570,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [178453] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Nibenese Court Wizard Hood",
                ["oldestTime"] = 1632952511,
                ["wasAltered"] = true,
                ["newestTime"] = 1632952511,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 2597,
                        ["wasKiosk"] = true,
                        ["seller"] = 894,
                        ["timestamp"] = 1632952511,
                        ["quant"] = 1,
                        ["id"] = "1689896947",
                        ["itemLink"] = 3849,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [156583] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 77: Stags of Z'en Maces",
                ["oldestTime"] = 1633222698,
                ["wasAltered"] = true,
                ["newestTime"] = 1633222698,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1621,
                        ["wasKiosk"] = true,
                        ["seller"] = 514,
                        ["timestamp"] = 1633222698,
                        ["quant"] = 1,
                        ["id"] = "1692039549",
                        ["itemLink"] = 2363,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [161053] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_grayhost_2hsword_a.dds",
                ["itemDesc"] = "Greatsword of Eternal Vigor",
                ["oldestTime"] = 1632951253,
                ["wasAltered"] = true,
                ["newestTime"] = 1632951253,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2222,
                        ["guild"] = 1,
                        ["buyer"] = 2589,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1632951253,
                        ["quant"] = 1,
                        ["id"] = "1689884303",
                        ["itemLink"] = 3843,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set eternal vigor sword two-handed precise",
            },
        },
        [135647] = 
        {
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_psijicorder_light_feet_a.dds",
                ["itemDesc"] = "Vanus's Shoes",
                ["oldestTime"] = 1632949649,
                ["wasAltered"] = true,
                ["newestTime"] = 1632949649,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2581,
                        ["wasKiosk"] = true,
                        ["seller"] = 531,
                        ["timestamp"] = 1632949649,
                        ["quant"] = 1,
                        ["id"] = "1689871619",
                        ["itemLink"] = 3807,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set wisdom of vanus feet invigorating",
            },
        },
        [101277] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_heavy_chest_d.dds",
                ["itemDesc"] = "Cuirass of Soulshine",
                ["oldestTime"] = 1632947991,
                ["wasAltered"] = true,
                ["newestTime"] = 1632947991,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2502,
                        ["guild"] = 1,
                        ["buyer"] = 2574,
                        ["wasKiosk"] = true,
                        ["seller"] = 494,
                        ["timestamp"] = 1632947991,
                        ["quant"] = 1,
                        ["id"] = "1689858445",
                        ["itemLink"] = 3796,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set soulshine chest sturdy",
            },
        },
        [96967] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/event_newlifefestival_2016_recipe.dds",
                ["itemDesc"] = "Recipe: Lava Foot Soup-and-Saltrice",
                ["oldestTime"] = 1632943475,
                ["wasAltered"] = true,
                ["newestTime"] = 1632943475,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 170000,
                        ["guild"] = 1,
                        ["buyer"] = 632,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1632943475,
                        ["quant"] = 1,
                        ["id"] = "1689821823",
                        ["itemLink"] = 3781,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [117164] = 
        {
            ["50:16:4:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_medium_hands_a.dds",
                ["itemDesc"] = "Bracers of the Powerful Assault",
                ["oldestTime"] = 1633254834,
                ["wasAltered"] = true,
                ["newestTime"] = 1633254834,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1829,
                        ["wasKiosk"] = true,
                        ["seller"] = 38,
                        ["timestamp"] = 1633254834,
                        ["quant"] = 1,
                        ["id"] = "1692300371",
                        ["itemLink"] = 2613,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set powerful assault hands reinforced",
            },
        },
        [175533] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_token_of_meridia.dds",
                ["itemDesc"] = "Alliance Banner-Bearer's Emblem",
                ["oldestTime"] = 1632832604,
                ["wasAltered"] = true,
                ["newestTime"] = 1633232937,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3200,
                        ["guild"] = 1,
                        ["buyer"] = 1709,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633232936,
                        ["quant"] = 2,
                        ["id"] = "1692144325",
                        ["itemLink"] = 2452,
                    },
                    [2] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1709,
                        ["wasKiosk"] = true,
                        ["seller"] = 493,
                        ["timestamp"] = 1633232937,
                        ["quant"] = 1,
                        ["id"] = "1692144337",
                        ["itemLink"] = 2452,
                    },
                    [3] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2142,
                        ["wasKiosk"] = true,
                        ["seller"] = 2143,
                        ["timestamp"] = 1632832604,
                        ["quant"] = 1,
                        ["id"] = "1689013821",
                        ["itemLink"] = 2452,
                    },
                    [4] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2142,
                        ["wasKiosk"] = true,
                        ["seller"] = 2143,
                        ["timestamp"] = 1632832605,
                        ["quant"] = 1,
                        ["id"] = "1689013825",
                        ["itemLink"] = 2452,
                    },
                    [5] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 2142,
                        ["wasKiosk"] = true,
                        ["seller"] = 894,
                        ["timestamp"] = 1632832605,
                        ["quant"] = 14,
                        ["id"] = "1689013827",
                        ["itemLink"] = 2452,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [26841] = 
        {
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_diseaseessence.dds",
                ["itemDesc"] = "Truly Superb Glyph of Foulness",
                ["oldestTime"] = 1632940825,
                ["wasAltered"] = true,
                ["newestTime"] = 1632940825,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 2530,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1632940825,
                        ["quant"] = 1,
                        ["id"] = "1689800231",
                        ["itemLink"] = 3769,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous weapon glyph",
            },
        },
        [147711] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 73: Anequina Staves",
                ["oldestTime"] = 1632939810,
                ["wasAltered"] = true,
                ["newestTime"] = 1632939810,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 1872,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1632939810,
                        ["quant"] = 1,
                        ["id"] = "1689793787",
                        ["itemLink"] = 3764,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [141744] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_malabaltor_instrument_flute.dds",
                ["itemDesc"] = "Swamp Jelly Luring Flute",
                ["oldestTime"] = 1632956479,
                ["wasAltered"] = true,
                ["newestTime"] = 1632956479,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 366,
                        ["wasKiosk"] = true,
                        ["seller"] = 281,
                        ["timestamp"] = 1632956479,
                        ["quant"] = 1,
                        ["id"] = "1689932491",
                        ["itemLink"] = 3902,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [45233] = 
        {
            ["50:16:2:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_2hsword_d.dds",
                ["itemDesc"] = "Rubedite Greatsword of Frost",
                ["oldestTime"] = 1633185924,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185924,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 175,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633185924,
                        ["quant"] = 1,
                        ["id"] = "1691639867",
                        ["itemLink"] = 2014,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon sword two-handed sharpened",
            },
            ["50:16:1:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_2hsword_c.dds",
                ["itemDesc"] = "Rubedite Greatsword",
                ["oldestTime"] = 1632826504,
                ["wasAltered"] = true,
                ["newestTime"] = 1632826504,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1632826504,
                        ["quant"] = 1,
                        ["id"] = "1688972161",
                        ["itemLink"] = 3054,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal weapon sword two-handed sharpened",
            },
        },
        [86828] = 
        {
            ["50:16:4:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_waist_d.dds",
                ["itemDesc"] = "Sash of Necropotence",
                ["oldestTime"] = 1632931041,
                ["wasAltered"] = true,
                ["newestTime"] = 1632931041,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7090,
                        ["guild"] = 1,
                        ["buyer"] = 2518,
                        ["wasKiosk"] = true,
                        ["seller"] = 1494,
                        ["timestamp"] = 1632931041,
                        ["quant"] = 1,
                        ["id"] = "1689729401",
                        ["itemLink"] = 3716,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set necropotence waist reinforced",
            },
        },
        [180659] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_medium_legs_a.dds",
                ["itemDesc"] = "Plaguebreak Guards",
                ["oldestTime"] = 1632836259,
                ["wasAltered"] = true,
                ["newestTime"] = 1633299880,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 2042,
                        ["wasKiosk"] = true,
                        ["seller"] = 802,
                        ["timestamp"] = 1633299880,
                        ["quant"] = 1,
                        ["id"] = "1692739807",
                        ["itemLink"] = 2912,
                    },
                    [2] = 
                    {
                        ["price"] = 1890,
                        ["guild"] = 1,
                        ["buyer"] = 2160,
                        ["wasKiosk"] = true,
                        ["seller"] = 1112,
                        ["timestamp"] = 1632836259,
                        ["quant"] = 1,
                        ["id"] = "1689035959",
                        ["itemLink"] = 2912,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior medium apparel set plaguebreak legs well-fitted",
            },
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_medium_legs_a.dds",
                ["itemDesc"] = "Plaguebreak Guards",
                ["oldestTime"] = 1632896373,
                ["wasAltered"] = true,
                ["newestTime"] = 1632896373,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 2434,
                        ["wasKiosk"] = true,
                        ["seller"] = 51,
                        ["timestamp"] = 1632896373,
                        ["quant"] = 1,
                        ["id"] = "1689538861",
                        ["itemLink"] = 3565,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set plaguebreak legs well-fitted",
            },
        },
        [43700] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Bleakrock Treasure Map II",
                ["oldestTime"] = 1633187102,
                ["wasAltered"] = true,
                ["newestTime"] = 1633187102,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1401,
                        ["wasKiosk"] = true,
                        ["seller"] = 1402,
                        ["timestamp"] = 1633187102,
                        ["quant"] = 1,
                        ["id"] = "1691653163",
                        ["itemLink"] = 2078,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [23221] = 
        {
            ["1:0:1:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_accessory_sp_names_002.dds",
                ["itemDesc"] = "Almandine",
                ["oldestTime"] = 1632821026,
                ["wasAltered"] = true,
                ["newestTime"] = 1632897771,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 365,
                        ["guild"] = 1,
                        ["buyer"] = 2105,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1632821026,
                        ["quant"] = 200,
                        ["id"] = "1688948153",
                        ["itemLink"] = 3012,
                    },
                    [2] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1632897771,
                        ["quant"] = 200,
                        ["id"] = "1689547333",
                        ["itemLink"] = 3012,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials armor trait well-fitted",
            },
        },
        [119276] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_alchemy4.dds",
                ["itemDesc"] = "Formula: Redguard Lantern, Delicate",
                ["oldestTime"] = 1632930331,
                ["wasAltered"] = true,
                ["newestTime"] = 1632930331,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 199999,
                        ["guild"] = 1,
                        ["buyer"] = 2513,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1632930331,
                        ["quant"] = 1,
                        ["id"] = "1689724581",
                        ["itemLink"] = 3700,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [149431] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Darloc Brae's Ring",
                ["oldestTime"] = 1633258451,
                ["wasAltered"] = true,
                ["newestTime"] = 1633258451,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1369,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1633258451,
                        ["quant"] = 1,
                        ["id"] = "1692318885",
                        ["itemLink"] = 2616,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set vesture of darloc brae ring robust",
            },
        },
        [57069] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Nocturnal's Everblack Coffee",
                ["oldestTime"] = 1633242696,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242696,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 51,
                        ["guild"] = 1,
                        ["buyer"] = 348,
                        ["wasKiosk"] = false,
                        ["seller"] = 711,
                        ["timestamp"] = 1633242696,
                        ["quant"] = 1,
                        ["id"] = "1692215331",
                        ["itemLink"] = 2549,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [45692] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Gold Coast Mudcrab Fries",
                ["oldestTime"] = 1632914272,
                ["wasAltered"] = true,
                ["newestTime"] = 1632914272,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3600,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632914272,
                        ["quant"] = 1,
                        ["id"] = "1689618749",
                        ["itemLink"] = 3636,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [140474] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 65: Huntsman Shoulders",
                ["oldestTime"] = 1633115281,
                ["wasAltered"] = true,
                ["newestTime"] = 1633115281,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 1019,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633115281,
                        ["quant"] = 1,
                        ["id"] = "1691073849",
                        ["itemLink"] = 1393,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45087] = 
        {
            ["50:16:2:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Restoration Staff of Shock",
                ["oldestTime"] = 1632826506,
                ["wasAltered"] = true,
                ["newestTime"] = 1632826506,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1632826506,
                        ["quant"] = 1,
                        ["id"] = "1688972189",
                        ["itemLink"] = 3055,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon healing staff two-handed charged",
            },
        },
        [171964] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_feet_a.dds",
                ["itemDesc"] = "Shoes of Frostbite",
                ["oldestTime"] = 1633168232,
                ["wasAltered"] = true,
                ["newestTime"] = 1633168232,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1332,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1633168232,
                        ["quant"] = 1,
                        ["id"] = "1691511615",
                        ["itemLink"] = 1875,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set frostbite feet infused",
            },
        },
        [152060] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Elsweyr Desk, Wooden",
                ["oldestTime"] = 1632888422,
                ["wasAltered"] = true,
                ["newestTime"] = 1632888422,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3884,
                        ["guild"] = 1,
                        ["buyer"] = 2405,
                        ["wasKiosk"] = true,
                        ["seller"] = 547,
                        ["timestamp"] = 1632888422,
                        ["quant"] = 1,
                        ["id"] = "1689482285",
                        ["itemLink"] = 3528,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [126867] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing3.dds",
                ["itemDesc"] = "Diagram: Dwarven Bench, Forged",
                ["oldestTime"] = 1632883684,
                ["wasAltered"] = true,
                ["newestTime"] = 1632883684,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1030,
                        ["guild"] = 1,
                        ["buyer"] = 719,
                        ["wasKiosk"] = true,
                        ["seller"] = 528,
                        ["timestamp"] = 1632883684,
                        ["quant"] = 1,
                        ["id"] = "1689435363",
                        ["itemLink"] = 3487,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [166767] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Vampiric Lamp, Amber Triple",
                ["oldestTime"] = 1633115080,
                ["wasAltered"] = true,
                ["newestTime"] = 1633115080,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1016,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633115080,
                        ["quant"] = 1,
                        ["id"] = "1691072397",
                        ["itemLink"] = 1390,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [46016] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Sweetsting Tea",
                ["oldestTime"] = 1633151699,
                ["wasAltered"] = true,
                ["newestTime"] = 1633151699,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 125,
                        ["guild"] = 1,
                        ["buyer"] = 839,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633151699,
                        ["quant"] = 1,
                        ["id"] = "1691405613",
                        ["itemLink"] = 1734,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [175944] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Table, Formal Square Low",
                ["oldestTime"] = 1632862401,
                ["wasAltered"] = true,
                ["newestTime"] = 1632862401,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 2251,
                        ["wasKiosk"] = true,
                        ["seller"] = 100,
                        ["timestamp"] = 1632862401,
                        ["quant"] = 1,
                        ["id"] = "1689247193",
                        ["itemLink"] = 3315,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [129730] = 
        {
            ["50:16:2:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_staff_c.dds",
                ["itemDesc"] = "Briarheart Inferno Staff",
                ["oldestTime"] = 1633088610,
                ["wasAltered"] = true,
                ["newestTime"] = 1633088610,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 913,
                        ["wasKiosk"] = true,
                        ["seller"] = 360,
                        ["timestamp"] = 1633088610,
                        ["quant"] = 1,
                        ["id"] = "1690880571",
                        ["itemLink"] = 1235,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set briarheart flame staff two-handed charged",
            },
        },
        [171494] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Dwarven Bed, Reach Furs",
                ["oldestTime"] = 1632865527,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865527,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 748,
                        ["timestamp"] = 1632865527,
                        ["quant"] = 1,
                        ["id"] = "1689268843",
                        ["itemLink"] = 3338,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [115908] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Breton Bed, Bunk",
                ["oldestTime"] = 1632875158,
                ["wasAltered"] = true,
                ["newestTime"] = 1632875158,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632875158,
                        ["quant"] = 1,
                        ["id"] = "1689342897",
                        ["itemLink"] = 3410,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [71259] = 
        {
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_ring_a.dds",
                ["itemDesc"] = "Briarheart Band",
                ["oldestTime"] = 1632849750,
                ["wasAltered"] = true,
                ["newestTime"] = 1632849750,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 2212,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632849750,
                        ["quant"] = 1,
                        ["id"] = "1689141995",
                        ["itemLink"] = 3228,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set briarheart ring healthy",
            },
        },
        [56984] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Eidar Banana-Radish Vichyssoise",
                ["oldestTime"] = 1633122928,
                ["wasAltered"] = true,
                ["newestTime"] = 1633122928,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1066,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633122928,
                        ["quant"] = 1,
                        ["id"] = "1691126839",
                        ["itemLink"] = 1451,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [180679] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_medium_legs_a.dds",
                ["itemDesc"] = "Plaguebreak Guards",
                ["oldestTime"] = 1632893859,
                ["wasAltered"] = true,
                ["newestTime"] = 1632893859,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 2426,
                        ["wasKiosk"] = true,
                        ["seller"] = 356,
                        ["timestamp"] = 1632893859,
                        ["quant"] = 1,
                        ["id"] = "1689522945",
                        ["itemLink"] = 3549,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set plaguebreak legs reinforced",
            },
        },
        [45657] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Monkeypig Cutlets",
                ["oldestTime"] = 1633306751,
                ["wasAltered"] = true,
                ["newestTime"] = 1633306751,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633306751,
                        ["quant"] = 1,
                        ["id"] = "1692807089",
                        ["itemLink"] = 2949,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45052] = 
        {
            ["50:16:3:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Restoration Staff of Shock",
                ["oldestTime"] = 1633305623,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305623,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633305623,
                        ["quant"] = 1,
                        ["id"] = "1692796573",
                        ["itemLink"] = 2931,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon healing staff two-handed powered",
            },
        },
        [180469] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_light_shoulder_a.dds",
                ["itemDesc"] = "Epaulets of Dark Convergence",
                ["oldestTime"] = 1633159761,
                ["wasAltered"] = true,
                ["newestTime"] = 1633159761,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1300,
                        ["wasKiosk"] = true,
                        ["seller"] = 476,
                        ["timestamp"] = 1633159761,
                        ["quant"] = 1,
                        ["id"] = "1691463863",
                        ["itemLink"] = 1786,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set dark convergence shoulders divines",
            },
        },
        [147659] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_metals_dwarven_scrap.dds",
                ["itemDesc"] = "Joke Popper Parts",
                ["oldestTime"] = 1633165384,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165384,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1999,
                        ["guild"] = 1,
                        ["buyer"] = 1320,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633165384,
                        ["quant"] = 1,
                        ["id"] = "1691497899",
                        ["itemLink"] = 1835,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable trophy",
            },
        },
        [181573] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Doorway, Wooden Frame",
                ["oldestTime"] = 1633061774,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292315,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 65000,
                        ["guild"] = 1,
                        ["buyer"] = 795,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633061774,
                        ["quant"] = 1,
                        ["id"] = "1690723803",
                        ["itemLink"] = 1032,
                    },
                    [2] = 
                    {
                        ["price"] = 65000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 1899,
                        ["timestamp"] = 1633292315,
                        ["quant"] = 1,
                        ["id"] = "1692655227",
                        ["itemLink"] = 1032,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [175565] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Ja'zennji Siir Hood",
                ["oldestTime"] = 1633298469,
                ["wasAltered"] = true,
                ["newestTime"] = 1633298469,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 479,
                        ["guild"] = 1,
                        ["buyer"] = 48,
                        ["wasKiosk"] = false,
                        ["seller"] = 266,
                        ["timestamp"] = 1633298469,
                        ["quant"] = 1,
                        ["id"] = "1692725861",
                        ["itemLink"] = 2905,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [172166] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_2haxe_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Battle Axe",
                ["oldestTime"] = 1633292061,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292061,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 22,
                        ["timestamp"] = 1633292061,
                        ["quant"] = 1,
                        ["id"] = "1692652331",
                        ["itemLink"] = 2807,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set deadlands assassin axe two-handed precise",
            },
        },
        [101919] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_soulshriven_light_head_a.dds",
                ["itemDesc"] = "Prisoner's Hat",
                ["oldestTime"] = 1633291963,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291963,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 865,
                        ["timestamp"] = 1633291963,
                        ["quant"] = 1,
                        ["id"] = "1692651385",
                        ["itemLink"] = 2804,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set prisoner's rags head divines",
            },
        },
        [135376] = 
        {
            ["50:16:2:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_staff_c.dds",
                ["itemDesc"] = "Gryphon's Lightning Staff",
                ["oldestTime"] = 1633066726,
                ["wasAltered"] = true,
                ["newestTime"] = 1633066726,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 826,
                        ["wasKiosk"] = true,
                        ["seller"] = 827,
                        ["timestamp"] = 1633066726,
                        ["quant"] = 1,
                        ["id"] = "1690760141",
                        ["itemLink"] = 1069,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set gryphon's ferocity lightning staff two-handed powered",
            },
        },
        [171985] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_feet_a.dds",
                ["itemDesc"] = "Shoes of Frostbite",
                ["oldestTime"] = 1633082071,
                ["wasAltered"] = true,
                ["newestTime"] = 1633082071,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7700,
                        ["guild"] = 1,
                        ["buyer"] = 885,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633082071,
                        ["quant"] = 1,
                        ["id"] = "1690843989",
                        ["itemLink"] = 1128,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set frostbite feet divines",
            },
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_feet_a.dds",
                ["itemDesc"] = "Shoes of Frostbite",
                ["oldestTime"] = 1633182285,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182285,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1377,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633182285,
                        ["quant"] = 1,
                        ["id"] = "1691606403",
                        ["itemLink"] = 1937,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite feet divines",
            },
        },
        [115966] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing3.dds",
                ["itemDesc"] = "Diagram: Breton Streetlight, Paired",
                ["oldestTime"] = 1633289466,
                ["wasAltered"] = true,
                ["newestTime"] = 1633289466,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 202,
                        ["wasKiosk"] = false,
                        ["seller"] = 353,
                        ["timestamp"] = 1633289466,
                        ["quant"] = 1,
                        ["id"] = "1692621013",
                        ["itemLink"] = 2774,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [171475] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Blackreach: Arkthzand Cavern Treasure Map",
                ["oldestTime"] = 1632590163,
                ["wasAltered"] = true,
                ["newestTime"] = 1633236958,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 2,
                        ["buyer"] = 117,
                        ["wasKiosk"] = false,
                        ["seller"] = 123,
                        ["timestamp"] = 1632590163,
                        ["quant"] = 1,
                        ["id"] = "1686937915",
                        ["itemLink"] = 100,
                    },
                    [2] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 809,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633236953,
                        ["quant"] = 1,
                        ["id"] = "1692175817",
                        ["itemLink"] = 100,
                    },
                    [3] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 809,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633236954,
                        ["quant"] = 1,
                        ["id"] = "1692175829",
                        ["itemLink"] = 100,
                    },
                    [4] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 809,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633236955,
                        ["quant"] = 1,
                        ["id"] = "1692175843",
                        ["itemLink"] = 100,
                    },
                    [5] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 809,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633236956,
                        ["quant"] = 1,
                        ["id"] = "1692175851",
                        ["itemLink"] = 100,
                    },
                    [6] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 809,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633236957,
                        ["quant"] = 1,
                        ["id"] = "1692175865",
                        ["itemLink"] = 100,
                    },
                    [7] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 809,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633236958,
                        ["quant"] = 1,
                        ["id"] = "1692175871",
                        ["itemLink"] = 100,
                    },
                    [8] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2477,
                        ["wasKiosk"] = true,
                        ["seller"] = 1535,
                        ["timestamp"] = 1632917090,
                        ["quant"] = 1,
                        ["id"] = "1689636079",
                        ["itemLink"] = 100,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [123348] = 
        {
            ["50:16:2:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Coward's Gear Ring",
                ["oldestTime"] = 1632911743,
                ["wasAltered"] = true,
                ["newestTime"] = 1632911743,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 299,
                        ["timestamp"] = 1632911743,
                        ["quant"] = 1,
                        ["id"] = "1689607441",
                        ["itemLink"] = 3614,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set coward's gear ring robust",
            },
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Coward's Gear Ring",
                ["oldestTime"] = 1632930063,
                ["wasAltered"] = true,
                ["newestTime"] = 1633184145,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5009,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 256,
                        ["timestamp"] = 1633163948,
                        ["quant"] = 1,
                        ["id"] = "1691490541",
                        ["itemLink"] = 1830,
                    },
                    [2] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633184145,
                        ["quant"] = 1,
                        ["id"] = "1691622557",
                        ["itemLink"] = 1830,
                    },
                    [3] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 785,
                        ["timestamp"] = 1632930063,
                        ["quant"] = 1,
                        ["id"] = "1689722513",
                        ["itemLink"] = 1830,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set coward's gear ring robust",
            },
        },
        [174846] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_bow_c.dds",
                ["itemDesc"] = "Waking Flame's Bow of Rebellion",
                ["oldestTime"] = 1633102431,
                ["wasAltered"] = true,
                ["newestTime"] = 1633102431,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 2,
                        ["buyer"] = 138,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1633102431,
                        ["quant"] = 1,
                        ["id"] = "1690977117",
                        ["itemLink"] = 151,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set deadlands assassin bow two-handed charged",
            },
        },
        [149206] = 
        {
            ["50:16:2:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_dagger_a.dds",
                ["itemDesc"] = "Undertaker's Dagger",
                ["oldestTime"] = 1633114481,
                ["wasAltered"] = true,
                ["newestTime"] = 1633114481,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 1013,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633114481,
                        ["quant"] = 1,
                        ["id"] = "1691069305",
                        ["itemLink"] = 1376,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set call of the undertaker dagger one-handed training",
            },
        },
        [176130] = 
        {
            ["1:0:2:44:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_boots_heavy.dds",
                ["itemDesc"] = "Companion's Sabatons",
                ["oldestTime"] = 1633271495,
                ["wasAltered"] = true,
                ["newestTime"] = 1633271495,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1882,
                        ["wasKiosk"] = true,
                        ["seller"] = 50,
                        ["timestamp"] = 1633271495,
                        ["quant"] = 1,
                        ["id"] = "1692420809",
                        ["itemLink"] = 2673,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine heavy apparel feet prolific",
            },
        },
        [171905] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 101: Ivory Brigade Maces",
                ["oldestTime"] = 1632877927,
                ["wasAltered"] = true,
                ["newestTime"] = 1633313764,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6750,
                        ["guild"] = 1,
                        ["buyer"] = 61,
                        ["wasKiosk"] = false,
                        ["seller"] = 63,
                        ["timestamp"] = 1633313764,
                        ["quant"] = 1,
                        ["id"] = "1692888443",
                        ["itemLink"] = 44,
                    },
                    [2] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 450,
                        ["wasKiosk"] = true,
                        ["seller"] = 351,
                        ["timestamp"] = 1633088129,
                        ["quant"] = 1,
                        ["id"] = "1690876829",
                        ["itemLink"] = 44,
                    },
                    [3] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 151,
                        ["wasKiosk"] = false,
                        ["seller"] = 276,
                        ["timestamp"] = 1633203437,
                        ["quant"] = 1,
                        ["id"] = "1691828159",
                        ["itemLink"] = 44,
                    },
                    [4] = 
                    {
                        ["price"] = 9990,
                        ["guild"] = 1,
                        ["buyer"] = 1570,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633214351,
                        ["quant"] = 1,
                        ["id"] = "1691953131",
                        ["itemLink"] = 44,
                    },
                    [5] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1727,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1633235068,
                        ["quant"] = 1,
                        ["id"] = "1692161059",
                        ["itemLink"] = 44,
                    },
                    [6] = 
                    {
                        ["price"] = 11500,
                        ["guild"] = 1,
                        ["buyer"] = 67,
                        ["wasKiosk"] = false,
                        ["seller"] = 1899,
                        ["timestamp"] = 1632877927,
                        ["quant"] = 1,
                        ["id"] = "1689371687",
                        ["itemLink"] = 44,
                    },
                    [7] = 
                    {
                        ["price"] = 9990,
                        ["guild"] = 1,
                        ["buyer"] = 1063,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1632897107,
                        ["quant"] = 1,
                        ["id"] = "1689542547",
                        ["itemLink"] = 44,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [6873] = 
        {
            ["50:16:2:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_waist_d.dds",
                ["itemDesc"] = "Wayrest Guard's Cincture",
                ["oldestTime"] = 1633025698,
                ["wasAltered"] = true,
                ["newestTime"] = 1633025698,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 540,
                        ["wasKiosk"] = true,
                        ["seller"] = 527,
                        ["timestamp"] = 1633025698,
                        ["quant"] = 1,
                        ["id"] = "1690412859",
                        ["itemLink"] = 678,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel waist sturdy",
            },
        },
        [149254] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_pellitine_shield_a.dds",
                ["itemDesc"] = "Crafty Alfiq's Shield",
                ["oldestTime"] = 1633114518,
                ["wasAltered"] = true,
                ["newestTime"] = 1633114518,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 1013,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633114518,
                        ["quant"] = 1,
                        ["id"] = "1691069503",
                        ["itemLink"] = 1386,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior apparel weapon set crafty alfiq shield off hand infused",
            },
        },
        [45831] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_020.dds",
                ["itemDesc"] = "Oko",
                ["oldestTime"] = 1632816873,
                ["wasAltered"] = true,
                ["newestTime"] = 1633306157,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7194,
                        ["guild"] = 1,
                        ["buyer"] = 265,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632981286,
                        ["quant"] = 53,
                        ["id"] = "1690138029",
                        ["itemLink"] = 275,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 349,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632990333,
                        ["quant"] = 25,
                        ["id"] = "1690188851",
                        ["itemLink"] = 275,
                    },
                    [3] = 
                    {
                        ["price"] = 59800,
                        ["guild"] = 1,
                        ["buyer"] = 78,
                        ["wasKiosk"] = false,
                        ["seller"] = 571,
                        ["timestamp"] = 1633032033,
                        ["quant"] = 200,
                        ["id"] = "1690457039",
                        ["itemLink"] = 275,
                    },
                    [4] = 
                    {
                        ["price"] = 840,
                        ["guild"] = 1,
                        ["buyer"] = 687,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633047702,
                        ["quant"] = 7,
                        ["id"] = "1690582957",
                        ["itemLink"] = 275,
                    },
                    [5] = 
                    {
                        ["price"] = 36000,
                        ["guild"] = 1,
                        ["buyer"] = 714,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1633052245,
                        ["quant"] = 200,
                        ["id"] = "1690628767",
                        ["itemLink"] = 275,
                    },
                    [6] = 
                    {
                        ["price"] = 5200,
                        ["guild"] = 1,
                        ["buyer"] = 757,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633056832,
                        ["quant"] = 26,
                        ["id"] = "1690675693",
                        ["itemLink"] = 275,
                    },
                    [7] = 
                    {
                        ["price"] = 3396,
                        ["guild"] = 1,
                        ["buyer"] = 907,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633087267,
                        ["quant"] = 25,
                        ["id"] = "1690871639",
                        ["itemLink"] = 275,
                    },
                    [8] = 
                    {
                        ["price"] = 1630,
                        ["guild"] = 1,
                        ["buyer"] = 1070,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633123959,
                        ["quant"] = 12,
                        ["id"] = "1691134219",
                        ["itemLink"] = 275,
                    },
                    [9] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1195,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633141985,
                        ["quant"] = 50,
                        ["id"] = "1691312677",
                        ["itemLink"] = 275,
                    },
                    [10] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1195,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633141986,
                        ["quant"] = 50,
                        ["id"] = "1691312681",
                        ["itemLink"] = 275,
                    },
                    [11] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1195,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633141987,
                        ["quant"] = 50,
                        ["id"] = "1691312689",
                        ["itemLink"] = 275,
                    },
                    [12] = 
                    {
                        ["price"] = 2800,
                        ["guild"] = 1,
                        ["buyer"] = 1229,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633146115,
                        ["quant"] = 14,
                        ["id"] = "1691357665",
                        ["itemLink"] = 275,
                    },
                    [13] = 
                    {
                        ["price"] = 3450,
                        ["guild"] = 1,
                        ["buyer"] = 1388,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1633185011,
                        ["quant"] = 23,
                        ["id"] = "1691629279",
                        ["itemLink"] = 275,
                    },
                    [14] = 
                    {
                        ["price"] = 6181,
                        ["guild"] = 1,
                        ["buyer"] = 1820,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633251042,
                        ["quant"] = 46,
                        ["id"] = "1692278149",
                        ["itemLink"] = 275,
                    },
                    [15] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 40,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633305299,
                        ["quant"] = 200,
                        ["id"] = "1692792719",
                        ["itemLink"] = 275,
                    },
                    [16] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 2068,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633306157,
                        ["quant"] = 50,
                        ["id"] = "1692801191",
                        ["itemLink"] = 275,
                    },
                    [17] = 
                    {
                        ["price"] = 39400,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1632816873,
                        ["quant"] = 200,
                        ["id"] = "1688929785",
                        ["itemLink"] = 275,
                    },
                    [18] = 
                    {
                        ["price"] = 19805,
                        ["guild"] = 1,
                        ["buyer"] = 2190,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1632842560,
                        ["quant"] = 100,
                        ["id"] = "1689079519",
                        ["itemLink"] = 275,
                    },
                    [19] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2522,
                        ["wasKiosk"] = true,
                        ["seller"] = 966,
                        ["timestamp"] = 1632933177,
                        ["quant"] = 50,
                        ["id"] = "1689745353",
                        ["itemLink"] = 275,
                    },
                    [20] = 
                    {
                        ["price"] = 59800,
                        ["guild"] = 1,
                        ["buyer"] = 2527,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1632936451,
                        ["quant"] = 200,
                        ["id"] = "1689771245",
                        ["itemLink"] = 275,
                    },
                    [21] = 
                    {
                        ["price"] = 59800,
                        ["guild"] = 1,
                        ["buyer"] = 2527,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1632936456,
                        ["quant"] = 200,
                        ["id"] = "1689771271",
                        ["itemLink"] = 275,
                    },
                    [22] = 
                    {
                        ["price"] = 59800,
                        ["guild"] = 1,
                        ["buyer"] = 2527,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1632936459,
                        ["quant"] = 200,
                        ["id"] = "1689771283",
                        ["itemLink"] = 275,
                    },
                },
                ["totalCount"] = 22,
                ["itemAdderText"] = "rr01 white normal materials essence runestone",
            },
        },
        [28636] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_flower_mountain_flower_r2.dds",
                ["itemDesc"] = "Rose",
                ["oldestTime"] = 1632968754,
                ["wasAltered"] = true,
                ["newestTime"] = 1633156796,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 1286,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633156796,
                        ["quant"] = 200,
                        ["id"] = "1691444637",
                        ["itemLink"] = 1768,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 790,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1632968754,
                        ["quant"] = 200,
                        ["id"] = "1690043837",
                        ["itemLink"] = 1768,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [180490] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_light_shoulders_a.dds",
                ["itemDesc"] = "Epaulets of Dark Convergence",
                ["oldestTime"] = 1633043885,
                ["wasAltered"] = true,
                ["newestTime"] = 1633043885,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633043885,
                        ["quant"] = 1,
                        ["id"] = "1690545389",
                        ["itemLink"] = 840,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set dark convergence shoulders well-fitted",
            },
        },
        [153624] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/event_halloween_2016_spooky_recipe.dds",
                ["itemDesc"] = "Recipe: Corrupting Bloody Mara",
                ["oldestTime"] = 1633261651,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261651,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 1145,
                        ["timestamp"] = 1633261651,
                        ["quant"] = 1,
                        ["id"] = "1692334711",
                        ["itemLink"] = 2628,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable recipe",
            },
        },
        [180703] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_1hhammer_a.dds",
                ["itemDesc"] = "Plaguebreak Mace",
                ["oldestTime"] = 1633235642,
                ["wasAltered"] = true,
                ["newestTime"] = 1633235642,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1731,
                        ["wasKiosk"] = true,
                        ["seller"] = 356,
                        ["timestamp"] = 1633235642,
                        ["quant"] = 1,
                        ["id"] = "1692165357",
                        ["itemLink"] = 2483,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set plaguebreak mace one-handed charged",
            },
        },
        [97293] = 
        {
            ["50:16:2:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_d.dds",
                ["itemDesc"] = "Restoration Staff of a Mother's Sorrow",
                ["oldestTime"] = 1633018423,
                ["wasAltered"] = true,
                ["newestTime"] = 1633018423,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 497,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633018423,
                        ["quant"] = 1,
                        ["id"] = "1690353565",
                        ["itemLink"] = 569,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set mother's sorrow healing staff two-handed defending",
            },
        },
        [26849] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_fireresist.dds",
                ["itemDesc"] = "Superb Glyph of Flame Resist",
                ["oldestTime"] = 1632881733,
                ["wasAltered"] = true,
                ["newestTime"] = 1632881739,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 110,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1632881733,
                        ["quant"] = 1,
                        ["id"] = "1689414537",
                        ["itemLink"] = 3468,
                    },
                    [2] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632881739,
                        ["quant"] = 1,
                        ["id"] = "1689414625",
                        ["itemLink"] = 3468,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp150 green fine miscellaneous jewelry glyph",
            },
        },
        [145532] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_deadwater_r1.dds",
                ["itemDesc"] = "Crocodile Leather",
                ["oldestTime"] = 1633232691,
                ["wasAltered"] = true,
                ["newestTime"] = 1633232691,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1708,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633232691,
                        ["quant"] = 2,
                        ["id"] = "1692141771",
                        ["itemLink"] = 2450,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [135139] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_copper_dust.dds",
                ["itemDesc"] = "Copper Dust",
                ["oldestTime"] = 1633239780,
                ["wasAltered"] = true,
                ["newestTime"] = 1633247647,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633239780,
                        ["quant"] = 14,
                        ["id"] = "1692195645",
                        ["itemLink"] = 2524,
                    },
                    [2] = 
                    {
                        ["price"] = 5100,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633239781,
                        ["quant"] = 51,
                        ["id"] = "1692195657",
                        ["itemLink"] = 2524,
                    },
                    [3] = 
                    {
                        ["price"] = 3700,
                        ["guild"] = 1,
                        ["buyer"] = 1805,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633247647,
                        ["quant"] = 37,
                        ["id"] = "1692255567",
                        ["itemLink"] = 2524,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [45540] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Jasmine Moonshine",
                ["oldestTime"] = 1632691318,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242697,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 2,
                        ["buyer"] = 127,
                        ["wasKiosk"] = false,
                        ["seller"] = 128,
                        ["timestamp"] = 1632691318,
                        ["quant"] = 1,
                        ["id"] = "1687850069",
                        ["itemLink"] = 104,
                    },
                    [2] = 
                    {
                        ["price"] = 330,
                        ["guild"] = 1,
                        ["buyer"] = 348,
                        ["wasKiosk"] = false,
                        ["seller"] = 739,
                        ["timestamp"] = 1633242697,
                        ["quant"] = 1,
                        ["id"] = "1692215339",
                        ["itemLink"] = 104,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45541] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Clarified Rose Lager",
                ["oldestTime"] = 1632923726,
                ["wasAltered"] = true,
                ["newestTime"] = 1632923726,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632923726,
                        ["quant"] = 1,
                        ["id"] = "1689677427",
                        ["itemLink"] = 3674,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [43750] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Summerset Treasure Map III",
                ["oldestTime"] = 1633182511,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182511,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 359,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182511,
                        ["quant"] = 1,
                        ["id"] = "1691608109",
                        ["itemLink"] = 1950,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [125725] = 
        {
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_medium_hands_a.dds",
                ["itemDesc"] = "Impregnable Armor Bracers",
                ["oldestTime"] = 1633020690,
                ["wasAltered"] = true,
                ["newestTime"] = 1633020690,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 509,
                        ["wasKiosk"] = true,
                        ["seller"] = 510,
                        ["timestamp"] = 1633020690,
                        ["quant"] = 1,
                        ["id"] = "1690370209",
                        ["itemLink"] = 580,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set impregnable armor hands infused",
            },
        },
        [51688] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_book_001.dds",
                ["itemDesc"] = "Crafting Motif 14: Daedric Style",
                ["oldestTime"] = 1632821371,
                ["wasAltered"] = true,
                ["newestTime"] = 1633243390,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 434,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633008106,
                        ["quant"] = 1,
                        ["id"] = "1690277497",
                        ["itemLink"] = 440,
                    },
                    [2] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 944,
                        ["wasKiosk"] = false,
                        ["seller"] = 510,
                        ["timestamp"] = 1633243390,
                        ["quant"] = 1,
                        ["id"] = "1692221267",
                        ["itemLink"] = 440,
                    },
                    [3] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 2107,
                        ["wasKiosk"] = true,
                        ["seller"] = 33,
                        ["timestamp"] = 1632821371,
                        ["quant"] = 1,
                        ["id"] = "1688949311",
                        ["itemLink"] = 440,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [115489] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_arg_inc_mrkwallmedallion001.dds",
                ["itemDesc"] = "Argonian Medallion, Stone",
                ["oldestTime"] = 1633034616,
                ["wasAltered"] = true,
                ["newestTime"] = 1633034616,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7200,
                        ["guild"] = 1,
                        ["buyer"] = 587,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633034616,
                        ["quant"] = 1,
                        ["id"] = "1690473769",
                        ["itemLink"] = 758,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings gallery",
            },
        },
        [151887] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_inc_hairbrush001.dds",
                ["itemDesc"] = "Elsweyr Brush, Body",
                ["oldestTime"] = 1633239205,
                ["wasAltered"] = true,
                ["newestTime"] = 1633239206,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 90000,
                        ["guild"] = 1,
                        ["buyer"] = 1755,
                        ["wasKiosk"] = true,
                        ["seller"] = 1756,
                        ["timestamp"] = 1633239205,
                        ["quant"] = 1,
                        ["id"] = "1692192633",
                        ["itemLink"] = 2519,
                    },
                    [2] = 
                    {
                        ["price"] = 90000,
                        ["guild"] = 1,
                        ["buyer"] = 1755,
                        ["wasKiosk"] = true,
                        ["seller"] = 1756,
                        ["timestamp"] = 1633239206,
                        ["quant"] = 1,
                        ["id"] = "1692192649",
                        ["itemLink"] = 2519,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine furnishings parlor",
            },
        },
        [172069] = 
        {
            ["50:16:2:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_feet_a.dds",
                ["itemDesc"] = "Shoes of Frostbite",
                ["oldestTime"] = 1633033482,
                ["wasAltered"] = true,
                ["newestTime"] = 1633033482,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 579,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633033482,
                        ["quant"] = 1,
                        ["id"] = "1690466521",
                        ["itemLink"] = 750,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite feet invigorating",
            },
        },
        [139500] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting2.dds",
                ["itemDesc"] = "Praxis: Alinor Pedestal, Timeworn",
                ["oldestTime"] = 1632830345,
                ["wasAltered"] = true,
                ["newestTime"] = 1632958397,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 2134,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1632830345,
                        ["quant"] = 1,
                        ["id"] = "1689000539",
                        ["itemLink"] = 3082,
                    },
                    [2] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 1472,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1632958397,
                        ["quant"] = 1,
                        ["id"] = "1689946757",
                        ["itemLink"] = 3082,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [45293] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_shield_d.dds",
                ["itemDesc"] = "Ruby Ash Shield of Stamina",
                ["oldestTime"] = 1633186006,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186006,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633186006,
                        ["quant"] = 1,
                        ["id"] = "1691640677",
                        ["itemLink"] = 2055,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine apparel weapon shield off hand divines",
            },
        },
        [49134] = 
        {
            ["10:0:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_1hhammer_a.dds",
                ["itemDesc"] = "Hammer of the Night Mother",
                ["oldestTime"] = 1632938953,
                ["wasAltered"] = true,
                ["newestTime"] = 1633231649,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1572,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633214200,
                        ["quant"] = 1,
                        ["id"] = "1691951545",
                        ["itemLink"] = 2296,
                    },
                    [2] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1695,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633231649,
                        ["quant"] = 1,
                        ["id"] = "1692131895",
                        ["itemLink"] = 2296,
                    },
                    [3] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2537,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632938953,
                        ["quant"] = 1,
                        ["id"] = "1689787379",
                        ["itemLink"] = 3757,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr10 blue superior weapon set night mother's gaze mace one-handed training",
            },
        },
        [160637] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_blackreachex_staff.dds",
                ["itemDesc"] = "Inferno Staff of Winter's Respite",
                ["oldestTime"] = 1633223190,
                ["wasAltered"] = true,
                ["newestTime"] = 1633223190,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12500,
                        ["guild"] = 1,
                        ["buyer"] = 1627,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1633223190,
                        ["quant"] = 1,
                        ["id"] = "1692045541",
                        ["itemLink"] = 2366,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set winter's respite flame staff two-handed infused",
            },
        },
        [49136] = 
        {
            ["10:0:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_2haxe_a.dds",
                ["itemDesc"] = "Battle Axe of the Night Mother",
                ["oldestTime"] = 1633272857,
                ["wasAltered"] = true,
                ["newestTime"] = 1633272857,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1888,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633272857,
                        ["quant"] = 1,
                        ["id"] = "1692435817",
                        ["itemLink"] = 2681,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr10 blue superior weapon set night mother's gaze axe two-handed training",
            },
        },
        [135153] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/jewelrycrafting_booster_raw_zircon.dds",
                ["itemDesc"] = "Zircon Grains",
                ["oldestTime"] = 1632830488,
                ["wasAltered"] = true,
                ["newestTime"] = 1633288882,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 292,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1632982896,
                        ["quant"] = 1,
                        ["id"] = "1690147161",
                        ["itemLink"] = 296,
                    },
                    [2] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 342,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1632989313,
                        ["quant"] = 2,
                        ["id"] = "1690182815",
                        ["itemLink"] = 296,
                    },
                    [3] = 
                    {
                        ["price"] = 59704,
                        ["guild"] = 1,
                        ["buyer"] = 808,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633064217,
                        ["quant"] = 8,
                        ["id"] = "1690741971",
                        ["itemLink"] = 296,
                    },
                    [4] = 
                    {
                        ["price"] = 29852,
                        ["guild"] = 1,
                        ["buyer"] = 904,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633086979,
                        ["quant"] = 4,
                        ["id"] = "1690869079",
                        ["itemLink"] = 296,
                    },
                    [5] = 
                    {
                        ["price"] = 6800,
                        ["guild"] = 1,
                        ["buyer"] = 1014,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633114606,
                        ["quant"] = 1,
                        ["id"] = "1691070017",
                        ["itemLink"] = 296,
                    },
                    [6] = 
                    {
                        ["price"] = 7463,
                        ["guild"] = 1,
                        ["buyer"] = 1014,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633114607,
                        ["quant"] = 1,
                        ["id"] = "1691070019",
                        ["itemLink"] = 296,
                    },
                    [7] = 
                    {
                        ["price"] = 13600,
                        ["guild"] = 1,
                        ["buyer"] = 196,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633115667,
                        ["quant"] = 2,
                        ["id"] = "1691076317",
                        ["itemLink"] = 296,
                    },
                    [8] = 
                    {
                        ["price"] = 77999,
                        ["guild"] = 1,
                        ["buyer"] = 1160,
                        ["wasKiosk"] = true,
                        ["seller"] = 277,
                        ["timestamp"] = 1633138408,
                        ["quant"] = 10,
                        ["id"] = "1691276495",
                        ["itemLink"] = 296,
                    },
                    [9] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 1591,
                        ["wasKiosk"] = true,
                        ["seller"] = 763,
                        ["timestamp"] = 1633216685,
                        ["quant"] = 4,
                        ["id"] = "1691975589",
                        ["itemLink"] = 296,
                    },
                    [10] = 
                    {
                        ["price"] = 6789,
                        ["guild"] = 1,
                        ["buyer"] = 1758,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633239293,
                        ["quant"] = 1,
                        ["id"] = "1692193097",
                        ["itemLink"] = 296,
                    },
                    [11] = 
                    {
                        ["price"] = 6800,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633288882,
                        ["quant"] = 1,
                        ["id"] = "1692614031",
                        ["itemLink"] = 296,
                    },
                    [12] = 
                    {
                        ["price"] = 14200,
                        ["guild"] = 1,
                        ["buyer"] = 2132,
                        ["wasKiosk"] = true,
                        ["seller"] = 944,
                        ["timestamp"] = 1632830488,
                        ["quant"] = 2,
                        ["id"] = "1689001165",
                        ["itemLink"] = 296,
                    },
                    [13] = 
                    {
                        ["price"] = 43362,
                        ["guild"] = 1,
                        ["buyer"] = 2132,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632830491,
                        ["quant"] = 6,
                        ["id"] = "1689001179",
                        ["itemLink"] = 296,
                    },
                    [14] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 1187,
                        ["wasKiosk"] = true,
                        ["seller"] = 944,
                        ["timestamp"] = 1632954921,
                        ["quant"] = 4,
                        ["id"] = "1689917703",
                        ["itemLink"] = 296,
                    },
                    [15] = 
                    {
                        ["price"] = 61200,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1632958909,
                        ["quant"] = 9,
                        ["id"] = "1689951733",
                        ["itemLink"] = 296,
                    },
                },
                ["totalCount"] = 15,
                ["itemAdderText"] = "rr01 purple epic materials raw plating",
            },
        },
        [85100] = 
        {
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_light_waist_d.dds",
                ["itemDesc"] = "Sash of Syrabane",
                ["oldestTime"] = 1633204855,
                ["wasAltered"] = true,
                ["newestTime"] = 1633204855,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 1518,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633204855,
                        ["quant"] = 1,
                        ["id"] = "1691840747",
                        ["itemLink"] = 2238,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set syrabane's grip waist infused",
            },
        },
        [49139] = 
        {
            ["10:0:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_dagger_a.dds",
                ["itemDesc"] = "Dagger of the Night Mother",
                ["oldestTime"] = 1632917324,
                ["wasAltered"] = true,
                ["newestTime"] = 1633249625,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1360,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633180726,
                        ["quant"] = 1,
                        ["id"] = "1691590229",
                        ["itemLink"] = 1927,
                    },
                    [2] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1416,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633190281,
                        ["quant"] = 1,
                        ["id"] = "1691691089",
                        ["itemLink"] = 1927,
                    },
                    [3] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1812,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633249623,
                        ["quant"] = 1,
                        ["id"] = "1692267771",
                        ["itemLink"] = 2592,
                    },
                    [4] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1812,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633249625,
                        ["quant"] = 1,
                        ["id"] = "1692267783",
                        ["itemLink"] = 2592,
                    },
                    [5] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632917324,
                        ["quant"] = 1,
                        ["id"] = "1689637393",
                        ["itemLink"] = 1927,
                    },
                    [6] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632917497,
                        ["quant"] = 1,
                        ["id"] = "1689638307",
                        ["itemLink"] = 1927,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr10 blue superior weapon set night mother's gaze dagger one-handed training",
            },
        },
        [71553] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 22: Trinimac Boots",
                ["oldestTime"] = 1632875999,
                ["wasAltered"] = true,
                ["newestTime"] = 1633195671,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 242,
                        ["wasKiosk"] = false,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633195671,
                        ["quant"] = 1,
                        ["id"] = "1691748087",
                        ["itemLink"] = 2144,
                    },
                    [2] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 2327,
                        ["wasKiosk"] = true,
                        ["seller"] = 552,
                        ["timestamp"] = 1632875999,
                        ["quant"] = 1,
                        ["id"] = "1689351963",
                        ["itemLink"] = 2144,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [68341] = 
        {
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_054.dds",
                ["itemDesc"] = "Repora",
                ["oldestTime"] = 1632852979,
                ["wasAltered"] = true,
                ["newestTime"] = 1633270110,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 196,
                        ["guild"] = 1,
                        ["buyer"] = 819,
                        ["wasKiosk"] = false,
                        ["seller"] = 502,
                        ["timestamp"] = 1633065340,
                        ["quant"] = 4,
                        ["id"] = "1690749969",
                        ["itemLink"] = 1060,
                    },
                    [2] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 819,
                        ["wasKiosk"] = false,
                        ["seller"] = 230,
                        ["timestamp"] = 1633065341,
                        ["quant"] = 200,
                        ["id"] = "1690749981",
                        ["itemLink"] = 1060,
                    },
                    [3] = 
                    {
                        ["price"] = 35,
                        ["guild"] = 1,
                        ["buyer"] = 1873,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633270110,
                        ["quant"] = 1,
                        ["id"] = "1692405879",
                        ["itemLink"] = 1060,
                    },
                    [4] = 
                    {
                        ["price"] = 12995,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 322,
                        ["timestamp"] = 1632852979,
                        ["quant"] = 200,
                        ["id"] = "1689166887",
                        ["itemLink"] = 1060,
                    },
                    [5] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632861600,
                        ["quant"] = 40,
                        ["id"] = "1689241787",
                        ["itemLink"] = 1060,
                    },
                    [6] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632883377,
                        ["quant"] = 50,
                        ["id"] = "1689431399",
                        ["itemLink"] = 1060,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "cp160 white normal materials potency runestone",
            },
        },
        [165622] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_inc_vampirelablampwallmounted002.dds",
                ["itemDesc"] = "Vampiric Sconce, Amber",
                ["oldestTime"] = 1633294167,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294167,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 397,
                        ["wasKiosk"] = false,
                        ["seller"] = 312,
                        ["timestamp"] = 1633294167,
                        ["quant"] = 1,
                        ["id"] = "1692677691",
                        ["itemLink"] = 2862,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings lighting",
            },
        },
        [130039] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 79: Refabricated Staves",
                ["oldestTime"] = 1632939726,
                ["wasAltered"] = true,
                ["newestTime"] = 1632955211,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 28500,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1632939726,
                        ["quant"] = 1,
                        ["id"] = "1689793023",
                        ["itemLink"] = 3762,
                    },
                    [2] = 
                    {
                        ["price"] = 29000,
                        ["guild"] = 1,
                        ["buyer"] = 2608,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1632955211,
                        ["quant"] = 1,
                        ["id"] = "1689920121",
                        ["itemLink"] = 3762,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [175692] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_csb_leymerchantstallopen003.dds",
                ["itemDesc"] = "Leyawiin Counter, Wide Merchant",
                ["oldestTime"] = 1633078987,
                ["wasAltered"] = true,
                ["newestTime"] = 1633078987,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 397,
                        ["wasKiosk"] = false,
                        ["seller"] = 311,
                        ["timestamp"] = 1633078987,
                        ["quant"] = 1,
                        ["id"] = "1690832067",
                        ["itemLink"] = 1122,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [45656] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Sweet Potatoes",
                ["oldestTime"] = 1633172340,
                ["wasAltered"] = true,
                ["newestTime"] = 1633306749,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 144,
                        ["guild"] = 1,
                        ["buyer"] = 1345,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633172340,
                        ["quant"] = 1,
                        ["id"] = "1691532063",
                        ["itemLink"] = 1889,
                    },
                    [2] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633306749,
                        ["quant"] = 1,
                        ["id"] = "1692807069",
                        ["itemLink"] = 1889,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [56058] = 
        {
            ["1:0:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_medium_shoulders_a.dds",
                ["itemDesc"] = "Rawhide Arm Cops",
                ["oldestTime"] = 1632995747,
                ["wasAltered"] = true,
                ["newestTime"] = 1633051816,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 381,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1632995747,
                        ["quant"] = 1,
                        ["id"] = "1690213027",
                        ["itemLink"] = 380,
                    },
                    [2] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 706,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633051816,
                        ["quant"] = 1,
                        ["id"] = "1690624501",
                        ["itemLink"] = 380,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal medium apparel shoulders nirnhoned",
            },
        },
        [172027] = 
        {
            ["50:16:2:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_feet_a.dds",
                ["itemDesc"] = "Shoes of Frostbite",
                ["oldestTime"] = 1633190644,
                ["wasAltered"] = true,
                ["newestTime"] = 1633190644,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 1417,
                        ["timestamp"] = 1633190644,
                        ["quant"] = 1,
                        ["id"] = "1691695195",
                        ["itemLink"] = 2104,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite feet reinforced",
            },
        },
        [118268] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_inc_varpuzzlepaintings004.dds",
                ["itemDesc"] = "Painting of Great Ruins, Bolted",
                ["oldestTime"] = 1633085026,
                ["wasAltered"] = true,
                ["newestTime"] = 1633085026,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 899,
                        ["wasKiosk"] = true,
                        ["seller"] = 170,
                        ["timestamp"] = 1633085026,
                        ["quant"] = 1,
                        ["id"] = "1690858549",
                        ["itemLink"] = 1215,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings gallery",
            },
        },
        [64509] = 
        {
            ["50:15:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_053.dds",
                ["itemDesc"] = "Rejera",
                ["oldestTime"] = 1632816854,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305270,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 40,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633305270,
                        ["quant"] = 200,
                        ["id"] = "1692792553",
                        ["itemLink"] = 2929,
                    },
                    [2] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1632816854,
                        ["quant"] = 100,
                        ["id"] = "1688929609",
                        ["itemLink"] = 2929,
                    },
                    [3] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1486,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1632816855,
                        ["quant"] = 100,
                        ["id"] = "1688929623",
                        ["itemLink"] = 2929,
                    },
                    [4] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 151,
                        ["wasKiosk"] = false,
                        ["seller"] = 288,
                        ["timestamp"] = 1632830649,
                        ["quant"] = 200,
                        ["id"] = "1689001949",
                        ["itemLink"] = 2929,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp150 white normal materials potency runestone",
            },
        },
        [172286] = 
        {
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Bog Raider's Ring",
                ["oldestTime"] = 1633038680,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309083,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3300,
                        ["guild"] = 1,
                        ["buyer"] = 618,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633038680,
                        ["quant"] = 1,
                        ["id"] = "1690503427",
                        ["itemLink"] = 781,
                    },
                    [2] = 
                    {
                        ["price"] = 2999,
                        ["guild"] = 1,
                        ["buyer"] = 646,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633042134,
                        ["quant"] = 1,
                        ["id"] = "1690529537",
                        ["itemLink"] = 781,
                    },
                    [3] = 
                    {
                        ["price"] = 3200,
                        ["guild"] = 1,
                        ["buyer"] = 774,
                        ["wasKiosk"] = true,
                        ["seller"] = 775,
                        ["timestamp"] = 1633058237,
                        ["quant"] = 1,
                        ["id"] = "1690692477",
                        ["itemLink"] = 781,
                    },
                    [4] = 
                    {
                        ["price"] = 3306,
                        ["guild"] = 1,
                        ["buyer"] = 774,
                        ["wasKiosk"] = true,
                        ["seller"] = 660,
                        ["timestamp"] = 1633058239,
                        ["quant"] = 1,
                        ["id"] = "1690692511",
                        ["itemLink"] = 781,
                    },
                    [5] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 306,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633106372,
                        ["quant"] = 1,
                        ["id"] = "1691011579",
                        ["itemLink"] = 781,
                    },
                    [6] = 
                    {
                        ["price"] = 3300,
                        ["guild"] = 1,
                        ["buyer"] = 538,
                        ["wasKiosk"] = true,
                        ["seller"] = 51,
                        ["timestamp"] = 1633128548,
                        ["quant"] = 1,
                        ["id"] = "1691171441",
                        ["itemLink"] = 781,
                    },
                    [7] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633163935,
                        ["quant"] = 1,
                        ["id"] = "1691490489",
                        ["itemLink"] = 781,
                    },
                    [8] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633190651,
                        ["quant"] = 1,
                        ["id"] = "1691695303",
                        ["itemLink"] = 781,
                    },
                    [9] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 306,
                        ["wasKiosk"] = true,
                        ["seller"] = 494,
                        ["timestamp"] = 1633197316,
                        ["quant"] = 1,
                        ["id"] = "1691762037",
                        ["itemLink"] = 781,
                    },
                    [10] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 778,
                        ["wasKiosk"] = false,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633201972,
                        ["quant"] = 1,
                        ["id"] = "1691810247",
                        ["itemLink"] = 781,
                    },
                    [11] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633218639,
                        ["quant"] = 1,
                        ["id"] = "1691997083",
                        ["itemLink"] = 781,
                    },
                    [12] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1774,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633240609,
                        ["quant"] = 1,
                        ["id"] = "1692202347",
                        ["itemLink"] = 781,
                    },
                    [13] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1332,
                        ["wasKiosk"] = true,
                        ["seller"] = 474,
                        ["timestamp"] = 1633243566,
                        ["quant"] = 1,
                        ["id"] = "1692222275",
                        ["itemLink"] = 781,
                    },
                    [14] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1332,
                        ["wasKiosk"] = true,
                        ["seller"] = 256,
                        ["timestamp"] = 1633243568,
                        ["quant"] = 1,
                        ["id"] = "1692222287",
                        ["itemLink"] = 781,
                    },
                    [15] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1913,
                        ["wasKiosk"] = true,
                        ["seller"] = 1128,
                        ["timestamp"] = 1633277731,
                        ["quant"] = 1,
                        ["id"] = "1692492917",
                        ["itemLink"] = 781,
                    },
                    [16] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 778,
                        ["wasKiosk"] = false,
                        ["seller"] = 388,
                        ["timestamp"] = 1633309083,
                        ["quant"] = 1,
                        ["id"] = "1692837173",
                        ["itemLink"] = 781,
                    },
                },
                ["totalCount"] = 16,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set bog raider ring healthy",
            },
            ["50:16:2:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Bog Raider's Ring",
                ["oldestTime"] = 1632793705,
                ["wasAltered"] = true,
                ["newestTime"] = 1633146167,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 2,
                        ["buyer"] = 131,
                        ["wasKiosk"] = false,
                        ["seller"] = 119,
                        ["timestamp"] = 1632793705,
                        ["quant"] = 1,
                        ["id"] = "1688754533",
                        ["itemLink"] = 129,
                    },
                    [2] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 376,
                        ["wasKiosk"] = true,
                        ["seller"] = 353,
                        ["timestamp"] = 1632994933,
                        ["quant"] = 1,
                        ["id"] = "1690210015",
                        ["itemLink"] = 129,
                    },
                    [3] = 
                    {
                        ["price"] = 445,
                        ["guild"] = 1,
                        ["buyer"] = 1115,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633131774,
                        ["quant"] = 1,
                        ["id"] = "1691206665",
                        ["itemLink"] = 129,
                    },
                    [4] = 
                    {
                        ["price"] = 310,
                        ["guild"] = 1,
                        ["buyer"] = 1230,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633146167,
                        ["quant"] = 1,
                        ["id"] = "1691358171",
                        ["itemLink"] = 129,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set bog raider ring healthy",
            },
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Bog Raider's Ring",
                ["oldestTime"] = 1633042160,
                ["wasAltered"] = true,
                ["newestTime"] = 1633264993,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 670,
                        ["guild"] = 1,
                        ["buyer"] = 646,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633042160,
                        ["quant"] = 1,
                        ["id"] = "1690529865",
                        ["itemLink"] = 816,
                    },
                    [2] = 
                    {
                        ["price"] = 775,
                        ["guild"] = 1,
                        ["buyer"] = 458,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633082471,
                        ["quant"] = 1,
                        ["id"] = "1690846523",
                        ["itemLink"] = 816,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 306,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633154139,
                        ["quant"] = 1,
                        ["id"] = "1691424509",
                        ["itemLink"] = 816,
                    },
                    [4] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1633163913,
                        ["quant"] = 1,
                        ["id"] = "1691490335",
                        ["itemLink"] = 816,
                    },
                    [5] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1389,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633185043,
                        ["quant"] = 1,
                        ["id"] = "1691629455",
                        ["itemLink"] = 816,
                    },
                    [6] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1389,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633185043,
                        ["quant"] = 1,
                        ["id"] = "1691629461",
                        ["itemLink"] = 816,
                    },
                    [7] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633218664,
                        ["quant"] = 1,
                        ["id"] = "1691997323",
                        ["itemLink"] = 816,
                    },
                    [8] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633218680,
                        ["quant"] = 1,
                        ["id"] = "1691997495",
                        ["itemLink"] = 816,
                    },
                    [9] = 
                    {
                        ["price"] = 655,
                        ["guild"] = 1,
                        ["buyer"] = 1813,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633249717,
                        ["quant"] = 1,
                        ["id"] = "1692268803",
                        ["itemLink"] = 816,
                    },
                    [10] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1813,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1633249723,
                        ["quant"] = 1,
                        ["id"] = "1692268847",
                        ["itemLink"] = 816,
                    },
                    [11] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1813,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633249725,
                        ["quant"] = 1,
                        ["id"] = "1692268869",
                        ["itemLink"] = 816,
                    },
                    [12] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1852,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633264993,
                        ["quant"] = 1,
                        ["id"] = "1692358965",
                        ["itemLink"] = 816,
                    },
                },
                ["totalCount"] = 12,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set bog raider ring healthy",
            },
        },
        [121343] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 50: Telvanni Shields",
                ["oldestTime"] = 1633198552,
                ["wasAltered"] = true,
                ["newestTime"] = 1633198552,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 1214,
                        ["timestamp"] = 1633198552,
                        ["quant"] = 1,
                        ["id"] = "1691774795",
                        ["itemLink"] = 2162,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
    },
}
