GS06DataSavedVariables =
{
    ["listingseu"] = 
    {
    },
    ["listingsna"] = 
    {
    },
    ["dataeu"] = 
    {
    },
    ["datana"] = 
    {
        [121344] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 50: Telvanni Shoulders",
                ["oldestTime"] = 1632944856,
                ["wasAltered"] = true,
                ["newestTime"] = 1632944856,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18285,
                        ["guild"] = 1,
                        ["buyer"] = 452,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632944856,
                        ["quant"] = 1,
                        ["id"] = "1689833813",
                        ["itemLink"] = 3788,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [64513] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/ava_siege_weapon_darkanchor_bluefiretrebuchet.dds",
                ["itemDesc"] = "Pact Cold Fire Trebuchet",
                ["oldestTime"] = 1633123086,
                ["wasAltered"] = true,
                ["newestTime"] = 1633123086,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1068,
                        ["wasKiosk"] = true,
                        ["seller"] = 734,
                        ["timestamp"] = 1633123086,
                        ["quant"] = 1,
                        ["id"] = "1691127937",
                        ["itemLink"] = 1457,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal miscellaneous siege",
            },
        },
        [176643] = 
        {
            ["1:0:4:38:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_bow.dds",
                ["itemDesc"] = "Companion's Bow",
                ["oldestTime"] = 1633193090,
                ["wasAltered"] = true,
                ["newestTime"] = 1633193090,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 399999,
                        ["guild"] = 1,
                        ["buyer"] = 1430,
                        ["wasKiosk"] = true,
                        ["seller"] = 1128,
                        ["timestamp"] = 1633193090,
                        ["quant"] = 1,
                        ["id"] = "1691725127",
                        ["itemLink"] = 2117,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic weapon bow two-handed aggressive",
            },
        },
        [101381] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_light_robe_d.dds",
                ["itemDesc"] = "Ysgramor's Robe",
                ["oldestTime"] = 1633114500,
                ["wasAltered"] = true,
                ["newestTime"] = 1633114500,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 340,
                        ["guild"] = 1,
                        ["buyer"] = 1013,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633114500,
                        ["quant"] = 1,
                        ["id"] = "1691069381",
                        ["itemLink"] = 1379,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set ysgramor's birthright chest well-fitted",
            },
        },
        [123654] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_light_legs_a.dds",
                ["itemDesc"] = "Knight Slayer Breeches",
                ["oldestTime"] = 1633218423,
                ["wasAltered"] = true,
                ["newestTime"] = 1633218423,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1600,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1633218423,
                        ["quant"] = 1,
                        ["id"] = "1691995021",
                        ["itemLink"] = 2327,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set knight slayer legs invigorating",
            },
        },
        [171783] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Markarth Floor, Large Oval",
                ["oldestTime"] = 1633062093,
                ["wasAltered"] = true,
                ["newestTime"] = 1633062093,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 43,
                        ["timestamp"] = 1633062093,
                        ["quant"] = 1,
                        ["id"] = "1690726241",
                        ["itemLink"] = 1033,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [45320] = 
        {
            ["50:16:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_bow_d.dds",
                ["itemDesc"] = "Ruby Ash Bow",
                ["oldestTime"] = 1632826494,
                ["wasAltered"] = true,
                ["newestTime"] = 1633152665,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 186,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633083994,
                        ["quant"] = 1,
                        ["id"] = "1690854369",
                        ["itemLink"] = 1145,
                    },
                    [2] = 
                    {
                        ["price"] = 228,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633084001,
                        ["quant"] = 1,
                        ["id"] = "1690854437",
                        ["itemLink"] = 1151,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 328,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633126105,
                        ["quant"] = 1,
                        ["id"] = "1691150143",
                        ["itemLink"] = 1486,
                    },
                    [4] = 
                    {
                        ["price"] = 275,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633131397,
                        ["quant"] = 1,
                        ["id"] = "1691201497",
                        ["itemLink"] = 1151,
                    },
                    [5] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633131399,
                        ["quant"] = 1,
                        ["id"] = "1691201515",
                        ["itemLink"] = 1520,
                    },
                    [6] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633135856,
                        ["quant"] = 1,
                        ["id"] = "1691251929",
                        ["itemLink"] = 1564,
                    },
                    [7] = 
                    {
                        ["price"] = 228,
                        ["guild"] = 1,
                        ["buyer"] = 1268,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633152665,
                        ["quant"] = 1,
                        ["id"] = "1691413979",
                        ["itemLink"] = 1520,
                    },
                    [8] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1632826494,
                        ["quant"] = 1,
                        ["id"] = "1688971989",
                        ["itemLink"] = 3051,
                    },
                    [9] = 
                    {
                        ["price"] = 285,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632826501,
                        ["quant"] = 1,
                        ["id"] = "1688972113",
                        ["itemLink"] = 1564,
                    },
                    [10] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 1004,
                        ["timestamp"] = 1632842517,
                        ["quant"] = 1,
                        ["id"] = "1689079077",
                        ["itemLink"] = 1520,
                    },
                    [11] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632842517,
                        ["quant"] = 1,
                        ["id"] = "1689079081",
                        ["itemLink"] = 1145,
                    },
                    [12] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2223,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632852525,
                        ["quant"] = 1,
                        ["id"] = "1689163173",
                        ["itemLink"] = 3254,
                    },
                    [13] = 
                    {
                        ["price"] = 280,
                        ["guild"] = 1,
                        ["buyer"] = 2408,
                        ["wasKiosk"] = true,
                        ["seller"] = 240,
                        ["timestamp"] = 1632889282,
                        ["quant"] = 1,
                        ["id"] = "1689487563",
                        ["itemLink"] = 1151,
                    },
                    [14] = 
                    {
                        ["price"] = 290,
                        ["guild"] = 1,
                        ["buyer"] = 2408,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632889282,
                        ["quant"] = 1,
                        ["id"] = "1689487565",
                        ["itemLink"] = 3534,
                    },
                    [15] = 
                    {
                        ["price"] = 267,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956378,
                        ["quant"] = 1,
                        ["id"] = "1689931235",
                        ["itemLink"] = 1145,
                    },
                    [16] = 
                    {
                        ["price"] = 267,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956378,
                        ["quant"] = 1,
                        ["id"] = "1689931253",
                        ["itemLink"] = 1145,
                    },
                    [17] = 
                    {
                        ["price"] = 267,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956379,
                        ["quant"] = 1,
                        ["id"] = "1689931263",
                        ["itemLink"] = 3879,
                    },
                    [18] = 
                    {
                        ["price"] = 267,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956379,
                        ["quant"] = 1,
                        ["id"] = "1689931269",
                        ["itemLink"] = 1145,
                    },
                    [19] = 
                    {
                        ["price"] = 275,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632956382,
                        ["quant"] = 1,
                        ["id"] = "1689931327",
                        ["itemLink"] = 3880,
                    },
                    [20] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632956384,
                        ["quant"] = 1,
                        ["id"] = "1689931371",
                        ["itemLink"] = 1486,
                    },
                },
                ["totalCount"] = 20,
                ["itemAdderText"] = "cp160 white normal weapon bow two-handed intricate",
            },
            ["50:15:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_bow_d.dds",
                ["itemDesc"] = "Ruby Ash Bow",
                ["oldestTime"] = 1632820778,
                ["wasAltered"] = true,
                ["newestTime"] = 1633135857,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633131401,
                        ["quant"] = 1,
                        ["id"] = "1691201529",
                        ["itemLink"] = 1521,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633131402,
                        ["quant"] = 1,
                        ["id"] = "1691201551",
                        ["itemLink"] = 1522,
                    },
                    [3] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633135857,
                        ["quant"] = 1,
                        ["id"] = "1691251935",
                        ["itemLink"] = 1565,
                    },
                    [4] = 
                    {
                        ["price"] = 217,
                        ["guild"] = 1,
                        ["buyer"] = 850,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1632820778,
                        ["quant"] = 1,
                        ["id"] = "1688947539",
                        ["itemLink"] = 1522,
                    },
                    [5] = 
                    {
                        ["price"] = 222,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1632826470,
                        ["quant"] = 1,
                        ["id"] = "1688971693",
                        ["itemLink"] = 3042,
                    },
                    [6] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632826488,
                        ["quant"] = 1,
                        ["id"] = "1688971907",
                        ["itemLink"] = 3050,
                    },
                    [7] = 
                    {
                        ["price"] = 420,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 1786,
                        ["timestamp"] = 1632843150,
                        ["quant"] = 1,
                        ["id"] = "1689085065",
                        ["itemLink"] = 3167,
                    },
                    [8] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632843154,
                        ["quant"] = 1,
                        ["id"] = "1689085079",
                        ["itemLink"] = 3167,
                    },
                    [9] = 
                    {
                        ["price"] = 259,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956376,
                        ["quant"] = 1,
                        ["id"] = "1689931207",
                        ["itemLink"] = 3050,
                    },
                    [10] = 
                    {
                        ["price"] = 275,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632956382,
                        ["quant"] = 1,
                        ["id"] = "1689931337",
                        ["itemLink"] = 3881,
                    },
                    [11] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632956400,
                        ["quant"] = 1,
                        ["id"] = "1689931581",
                        ["itemLink"] = 3891,
                    },
                },
                ["totalCount"] = 11,
                ["itemAdderText"] = "cp150 white normal weapon bow two-handed intricate",
            },
        },
        [126474] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_vrd_lsb_telfloorlamp004.dds",
                ["itemDesc"] = "Telvanni Arched Light, Organic Azure",
                ["oldestTime"] = 1632895714,
                ["wasAltered"] = true,
                ["newestTime"] = 1632895714,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19000,
                        ["guild"] = 1,
                        ["buyer"] = 2432,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632895714,
                        ["quant"] = 1,
                        ["id"] = "1689533445",
                        ["itemLink"] = 3564,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [171787] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting2.dds",
                ["itemDesc"] = "Praxis: Markarth Post, Stone Wall",
                ["oldestTime"] = 1632914188,
                ["wasAltered"] = true,
                ["newestTime"] = 1632914188,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632914188,
                        ["quant"] = 1,
                        ["id"] = "1689618545",
                        ["itemLink"] = 3635,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [167180] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 92: Ancestral Akaviri Gloves",
                ["oldestTime"] = 1632940099,
                ["wasAltered"] = true,
                ["newestTime"] = 1633184358,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 160000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 1082,
                        ["timestamp"] = 1633184358,
                        ["quant"] = 1,
                        ["id"] = "1691623799",
                        ["itemLink"] = 1972,
                    },
                    [2] = 
                    {
                        ["price"] = 320000,
                        ["guild"] = 1,
                        ["buyer"] = 2542,
                        ["wasKiosk"] = true,
                        ["seller"] = 315,
                        ["timestamp"] = 1632940099,
                        ["quant"] = 1,
                        ["id"] = "1689795081",
                        ["itemLink"] = 1972,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [43534] = 
        {
            ["50:16:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_2hsword_d.dds",
                ["itemDesc"] = "Rubedite Greatsword of Flame",
                ["oldestTime"] = 1632950117,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950117,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1632950117,
                        ["quant"] = 1,
                        ["id"] = "1689875071",
                        ["itemLink"] = 3812,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon sword two-handed",
            },
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_2hsword_d.dds",
                ["itemDesc"] = "Rubedite Greatsword",
                ["oldestTime"] = 1632826454,
                ["wasAltered"] = true,
                ["newestTime"] = 1633313860,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 177,
                        ["guild"] = 1,
                        ["buyer"] = 66,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633313860,
                        ["quant"] = 1,
                        ["id"] = "1692889103",
                        ["itemLink"] = 50,
                    },
                    [2] = 
                    {
                        ["price"] = 153,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632826454,
                        ["quant"] = 1,
                        ["id"] = "1688971637",
                        ["itemLink"] = 3033,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 white normal weapon sword two-handed",
            },
        },
        [77585] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_poisonmaking_reagent_butterfly_wing.dds",
                ["itemDesc"] = "Butterfly Wing",
                ["oldestTime"] = 1632981456,
                ["wasAltered"] = true,
                ["newestTime"] = 1633234032,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 29990,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1632981456,
                        ["quant"] = 200,
                        ["id"] = "1690138931",
                        ["itemLink"] = 284,
                    },
                    [2] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1632981457,
                        ["quant"] = 200,
                        ["id"] = "1690138953",
                        ["itemLink"] = 284,
                    },
                    [3] = 
                    {
                        ["price"] = 16200,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1632981458,
                        ["quant"] = 100,
                        ["id"] = "1690138977",
                        ["itemLink"] = 284,
                    },
                    [4] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 432,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633042851,
                        ["quant"] = 10,
                        ["id"] = "1690536683",
                        ["itemLink"] = 284,
                    },
                    [5] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1719,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633234032,
                        ["quant"] = 15,
                        ["id"] = "1692154205",
                        ["itemLink"] = 284,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [114962] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 45: Mazzatun Shields",
                ["oldestTime"] = 1632962918,
                ["wasAltered"] = true,
                ["newestTime"] = 1632962918,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13983,
                        ["guild"] = 1,
                        ["buyer"] = 2645,
                        ["wasKiosk"] = true,
                        ["seller"] = 1161,
                        ["timestamp"] = 1632962918,
                        ["quant"] = 1,
                        ["id"] = "1689985179",
                        ["itemLink"] = 3937,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45331] = 
        {
            ["1:0:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_staff_a.dds",
                ["itemDesc"] = "Maple Lightning Staff",
                ["oldestTime"] = 1632955140,
                ["wasAltered"] = true,
                ["newestTime"] = 1632956367,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 80,
                        ["guild"] = 1,
                        ["buyer"] = 2607,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632955140,
                        ["quant"] = 1,
                        ["id"] = "1689919567",
                        ["itemLink"] = 3862,
                    },
                    [2] = 
                    {
                        ["price"] = 120,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632956367,
                        ["quant"] = 1,
                        ["id"] = "1689931039",
                        ["itemLink"] = 3870,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal weapon lightning staff two-handed intricate",
            },
            ["50:15:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Lightning Staff",
                ["oldestTime"] = 1632843156,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305605,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009394,
                        ["quant"] = 1,
                        ["id"] = "1690285773",
                        ["itemLink"] = 507,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009396,
                        ["quant"] = 1,
                        ["id"] = "1690285793",
                        ["itemLink"] = 507,
                    },
                    [3] = 
                    {
                        ["price"] = 176,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633028889,
                        ["quant"] = 1,
                        ["id"] = "1690436667",
                        ["itemLink"] = 507,
                    },
                    [4] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633028899,
                        ["quant"] = 1,
                        ["id"] = "1690436715",
                        ["itemLink"] = 507,
                    },
                    [5] = 
                    {
                        ["price"] = 152,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633305605,
                        ["quant"] = 1,
                        ["id"] = "1692796431",
                        ["itemLink"] = 2930,
                    },
                    [6] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632843156,
                        ["quant"] = 1,
                        ["id"] = "1689085091",
                        ["itemLink"] = 3171,
                    },
                    [7] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2408,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632889283,
                        ["quant"] = 1,
                        ["id"] = "1689487577",
                        ["itemLink"] = 507,
                    },
                    [8] = 
                    {
                        ["price"] = 160,
                        ["guild"] = 1,
                        ["buyer"] = 2202,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1632913797,
                        ["quant"] = 1,
                        ["id"] = "1689616147",
                        ["itemLink"] = 507,
                    },
                    [9] = 
                    {
                        ["price"] = 266,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956377,
                        ["quant"] = 1,
                        ["id"] = "1689931229",
                        ["itemLink"] = 3878,
                    },
                    [10] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956394,
                        ["quant"] = 1,
                        ["id"] = "1689931515",
                        ["itemLink"] = 507,
                    },
                    [11] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956398,
                        ["quant"] = 1,
                        ["id"] = "1689931559",
                        ["itemLink"] = 3889,
                    },
                    [12] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956399,
                        ["quant"] = 1,
                        ["id"] = "1689931571",
                        ["itemLink"] = 3890,
                    },
                    [13] = 
                    {
                        ["price"] = 420,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1786,
                        ["timestamp"] = 1632956401,
                        ["quant"] = 1,
                        ["id"] = "1689931593",
                        ["itemLink"] = 3878,
                    },
                    [14] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632956401,
                        ["quant"] = 1,
                        ["id"] = "1689931601",
                        ["itemLink"] = 2930,
                    },
                },
                ["totalCount"] = 14,
                ["itemAdderText"] = "cp150 white normal weapon lightning staff two-handed intricate",
            },
            ["50:16:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Lightning Staff",
                ["oldestTime"] = 1632826485,
                ["wasAltered"] = true,
                ["newestTime"] = 1633268062,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 322,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009381,
                        ["quant"] = 1,
                        ["id"] = "1690285585",
                        ["itemLink"] = 493,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633009388,
                        ["quant"] = 1,
                        ["id"] = "1690285667",
                        ["itemLink"] = 500,
                    },
                    [3] = 
                    {
                        ["price"] = 199,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1633028894,
                        ["quant"] = 1,
                        ["id"] = "1690436693",
                        ["itemLink"] = 697,
                    },
                    [4] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 560,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633030307,
                        ["quant"] = 1,
                        ["id"] = "1690445905",
                        ["itemLink"] = 500,
                    },
                    [5] = 
                    {
                        ["price"] = 228,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 896,
                        ["timestamp"] = 1633083999,
                        ["quant"] = 1,
                        ["id"] = "1690854415",
                        ["itemLink"] = 493,
                    },
                    [6] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633084016,
                        ["quant"] = 1,
                        ["id"] = "1690854537",
                        ["itemLink"] = 1161,
                    },
                    [7] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633084019,
                        ["quant"] = 1,
                        ["id"] = "1690854549",
                        ["itemLink"] = 1164,
                    },
                    [8] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 539,
                        ["timestamp"] = 1633084021,
                        ["quant"] = 1,
                        ["id"] = "1690854559",
                        ["itemLink"] = 1165,
                    },
                    [9] = 
                    {
                        ["price"] = 175,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633131445,
                        ["quant"] = 1,
                        ["id"] = "1691202077",
                        ["itemLink"] = 1165,
                    },
                    [10] = 
                    {
                        ["price"] = 185,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633131447,
                        ["quant"] = 1,
                        ["id"] = "1691202091",
                        ["itemLink"] = 1524,
                    },
                    [11] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633131459,
                        ["quant"] = 1,
                        ["id"] = "1691202235",
                        ["itemLink"] = 1161,
                    },
                    [12] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633131460,
                        ["quant"] = 1,
                        ["id"] = "1691202249",
                        ["itemLink"] = 1161,
                    },
                    [13] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633131460,
                        ["quant"] = 1,
                        ["id"] = "1691202267",
                        ["itemLink"] = 697,
                    },
                    [14] = 
                    {
                        ["price"] = 160,
                        ["guild"] = 1,
                        ["buyer"] = 1001,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633268062,
                        ["quant"] = 1,
                        ["id"] = "1692385887",
                        ["itemLink"] = 500,
                    },
                    [15] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632826485,
                        ["quant"] = 1,
                        ["id"] = "1688971869",
                        ["itemLink"] = 493,
                    },
                    [16] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 527,
                        ["timestamp"] = 1632826497,
                        ["quant"] = 1,
                        ["id"] = "1688972037",
                        ["itemLink"] = 500,
                    },
                    [17] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2133,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632830258,
                        ["quant"] = 1,
                        ["id"] = "1688999839",
                        ["itemLink"] = 1524,
                    },
                    [18] = 
                    {
                        ["price"] = 420,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 1786,
                        ["timestamp"] = 1632843151,
                        ["quant"] = 1,
                        ["id"] = "1689085069",
                        ["itemLink"] = 3168,
                    },
                    [19] = 
                    {
                        ["price"] = 243,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956375,
                        ["quant"] = 1,
                        ["id"] = "1689931183",
                        ["itemLink"] = 493,
                    },
                    [20] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956387,
                        ["quant"] = 1,
                        ["id"] = "1689931415",
                        ["itemLink"] = 493,
                    },
                    [21] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956391,
                        ["quant"] = 1,
                        ["id"] = "1689931471",
                        ["itemLink"] = 3885,
                    },
                    [22] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956392,
                        ["quant"] = 1,
                        ["id"] = "1689931487",
                        ["itemLink"] = 1161,
                    },
                },
                ["totalCount"] = 22,
                ["itemAdderText"] = "cp160 white normal weapon lightning staff two-handed intricate",
            },
        },
        [147732] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 75: Sunspire Belts",
                ["oldestTime"] = 1632869211,
                ["wasAltered"] = true,
                ["newestTime"] = 1633111516,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3999,
                        ["guild"] = 1,
                        ["buyer"] = 418,
                        ["wasKiosk"] = true,
                        ["seller"] = 417,
                        ["timestamp"] = 1633005390,
                        ["quant"] = 1,
                        ["id"] = "1690261999",
                        ["itemLink"] = 426,
                    },
                    [2] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 985,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633111516,
                        ["quant"] = 1,
                        ["id"] = "1691048229",
                        ["itemLink"] = 426,
                    },
                    [3] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 2282,
                        ["wasKiosk"] = true,
                        ["seller"] = 2186,
                        ["timestamp"] = 1632869211,
                        ["quant"] = 1,
                        ["id"] = "1689297261",
                        ["itemLink"] = 426,
                    },
                    [4] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 2226,
                        ["wasKiosk"] = true,
                        ["seller"] = 712,
                        ["timestamp"] = 1632887070,
                        ["quant"] = 1,
                        ["id"] = "1689471373",
                        ["itemLink"] = 426,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [147735] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 75: Sunspire Chests",
                ["oldestTime"] = 1632834719,
                ["wasAltered"] = true,
                ["newestTime"] = 1632834719,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20039,
                        ["guild"] = 1,
                        ["buyer"] = 1448,
                        ["wasKiosk"] = true,
                        ["seller"] = 54,
                        ["timestamp"] = 1632834719,
                        ["quant"] = 1,
                        ["id"] = "1689025327",
                        ["itemLink"] = 3098,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45338] = 
        {
            ["50:16:1:10:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_2hsword_d.dds",
                ["itemDesc"] = "Rubedite Greatsword",
                ["oldestTime"] = 1632950121,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950121,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 864,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 527,
                        ["timestamp"] = 1632950121,
                        ["quant"] = 1,
                        ["id"] = "1689875133",
                        ["itemLink"] = 3818,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal weapon sword two-handed ornate",
            },
        },
        [81179] = 
        {
            ["50:14:2:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Senche's Necklace",
                ["oldestTime"] = 1632793704,
                ["wasAltered"] = true,
                ["newestTime"] = 1632793704,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 2,
                        ["buyer"] = 131,
                        ["wasKiosk"] = false,
                        ["seller"] = 132,
                        ["timestamp"] = 1632793704,
                        ["quant"] = 1,
                        ["id"] = "1688754527",
                        ["itemLink"] = 128,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp140 green fine jewelry apparel set senche's bite neck robust",
            },
        },
        [117788] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_fur_varchair004.dds",
                ["itemDesc"] = "Redguard Chair, Starry",
                ["oldestTime"] = 1632938705,
                ["wasAltered"] = true,
                ["newestTime"] = 1632938705,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 36250,
                        ["guild"] = 1,
                        ["buyer"] = 71,
                        ["wasKiosk"] = false,
                        ["seller"] = 236,
                        ["timestamp"] = 1632938705,
                        ["quant"] = 2,
                        ["id"] = "1689785485",
                        ["itemLink"] = 3755,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [176415] = 
        {
            ["1:0:2:46:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_shoulders_heavy.dds",
                ["itemDesc"] = "Companion's Pauldrons",
                ["oldestTime"] = 1633150109,
                ["wasAltered"] = true,
                ["newestTime"] = 1633150109,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1258,
                        ["wasKiosk"] = true,
                        ["seller"] = 50,
                        ["timestamp"] = 1633150109,
                        ["quant"] = 1,
                        ["id"] = "1691392147",
                        ["itemLink"] = 1721,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine heavy apparel shoulders shattering",
            },
        },
        [86562] = 
        {
            ["50:3:2:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of the Storm Knight",
                ["oldestTime"] = 1632793706,
                ["wasAltered"] = true,
                ["newestTime"] = 1632793706,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 2,
                        ["buyer"] = 131,
                        ["wasKiosk"] = false,
                        ["seller"] = 132,
                        ["timestamp"] = 1632793706,
                        ["quant"] = 1,
                        ["id"] = "1688754553",
                        ["itemLink"] = 131,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp30 green fine jewelry apparel set storm knight's plate neck healthy",
            },
            ["50:2:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of the Storm Knight",
                ["oldestTime"] = 1632793707,
                ["wasAltered"] = true,
                ["newestTime"] = 1632793707,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 2,
                        ["buyer"] = 131,
                        ["wasKiosk"] = false,
                        ["seller"] = 132,
                        ["timestamp"] = 1632793707,
                        ["quant"] = 1,
                        ["id"] = "1688754575",
                        ["itemLink"] = 133,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp20 blue superior jewelry apparel set storm knight's plate neck healthy",
            },
        },
        [156196] = 
        {
            ["50:16:3:31:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "New Moon Acolyte's Amulet",
                ["oldestTime"] = 1633140787,
                ["wasAltered"] = true,
                ["newestTime"] = 1633234759,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 57499,
                        ["guild"] = 1,
                        ["buyer"] = 1185,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633140787,
                        ["quant"] = 1,
                        ["id"] = "1691299489",
                        ["itemLink"] = 1601,
                    },
                    [2] = 
                    {
                        ["price"] = 57499,
                        ["guild"] = 1,
                        ["buyer"] = 1725,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633234759,
                        ["quant"] = 1,
                        ["id"] = "1692159439",
                        ["itemLink"] = 1601,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set new moon acolyte neck bloodthirsty",
            },
        },
        [172325] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_hvy_legs_a.dds",
                ["itemDesc"] = "Bog Raider's Greaves",
                ["oldestTime"] = 1632856339,
                ["wasAltered"] = true,
                ["newestTime"] = 1632856339,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1632856339,
                        ["quant"] = 1,
                        ["id"] = "1689200687",
                        ["itemLink"] = 3273,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set bog raider legs divines",
            },
        },
        [156204] = 
        {
            ["50:16:3:33:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "New Moon Acolyte's Amulet",
                ["oldestTime"] = 1633115844,
                ["wasAltered"] = true,
                ["newestTime"] = 1633115844,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1021,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633115844,
                        ["quant"] = 1,
                        ["id"] = "1691077489",
                        ["itemLink"] = 1397,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set new moon acolyte neck infused",
            },
        },
        [175918] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Counter, Corner",
                ["oldestTime"] = 1632867260,
                ["wasAltered"] = true,
                ["newestTime"] = 1632867274,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 2274,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1632867260,
                        ["quant"] = 1,
                        ["id"] = "1689283049",
                        ["itemLink"] = 3361,
                    },
                    [2] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 2274,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1632867274,
                        ["quant"] = 1,
                        ["id"] = "1689283127",
                        ["itemLink"] = 3361,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [46127] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_ingot_calcinium.dds",
                ["itemDesc"] = "Calcinium Ingot",
                ["oldestTime"] = 1632865516,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865516,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 990,
                        ["guild"] = 1,
                        ["buyer"] = 2265,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632865516,
                        ["quant"] = 66,
                        ["id"] = "1689268771",
                        ["itemLink"] = 3337,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [172080] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_2hhammer_a.dds",
                ["itemDesc"] = "Maul of Frostbite",
                ["oldestTime"] = 1633182308,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182308,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 840,
                        ["guild"] = 1,
                        ["buyer"] = 1377,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633182308,
                        ["quant"] = 1,
                        ["id"] = "1691606499",
                        ["itemLink"] = 1943,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set frostbite mace two-handed decisive",
            },
        },
        [135474] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_staff_c.dds",
                ["itemDesc"] = "Gryphon's Inferno Staff",
                ["oldestTime"] = 1633197841,
                ["wasAltered"] = true,
                ["newestTime"] = 1633197841,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1465,
                        ["wasKiosk"] = true,
                        ["seller"] = 697,
                        ["timestamp"] = 1633197841,
                        ["quant"] = 1,
                        ["id"] = "1691767755",
                        ["itemLink"] = 2153,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set gryphon's ferocity flame staff two-handed decisive",
            },
        },
        [139317] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_inc_rugrectangular002.dds",
                ["itemDesc"] = "Alinor Carpet, Vibrant",
                ["oldestTime"] = 1633303206,
                ["wasAltered"] = true,
                ["newestTime"] = 1633303206,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9845,
                        ["guild"] = 1,
                        ["buyer"] = 2052,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1633303206,
                        ["quant"] = 1,
                        ["id"] = "1692772465",
                        ["itemLink"] = 2921,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings parlor",
            },
        },
        [167993] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_wayward_guardian.dds",
                ["itemDesc"] = "Hawk Skull",
                ["oldestTime"] = 1633252452,
                ["wasAltered"] = true,
                ["newestTime"] = 1633252452,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 399,
                        ["guild"] = 1,
                        ["buyer"] = 1823,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633252452,
                        ["quant"] = 1,
                        ["id"] = "1692288627",
                        ["itemLink"] = 2608,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [151614] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Northern Elsweyr Treasure Map II",
                ["oldestTime"] = 1633149350,
                ["wasAltered"] = true,
                ["newestTime"] = 1633149350,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1250,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633149350,
                        ["quant"] = 1,
                        ["id"] = "1691385323",
                        ["itemLink"] = 1707,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [101183] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_heavy_waist_d.dds",
                ["itemDesc"] = "Girdle of Soulshine",
                ["oldestTime"] = 1633262755,
                ["wasAltered"] = true,
                ["newestTime"] = 1633262755,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7700,
                        ["guild"] = 1,
                        ["buyer"] = 790,
                        ["wasKiosk"] = true,
                        ["seller"] = 442,
                        ["timestamp"] = 1633262755,
                        ["quant"] = 1,
                        ["id"] = "1692340797",
                        ["itemLink"] = 2632,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set soulshine waist divines",
            },
        },
        [166978] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 90: Thorn Legion Daggers",
                ["oldestTime"] = 1633020135,
                ["wasAltered"] = true,
                ["newestTime"] = 1633020135,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 42000,
                        ["guild"] = 1,
                        ["buyer"] = 504,
                        ["wasKiosk"] = true,
                        ["seller"] = 505,
                        ["timestamp"] = 1633020135,
                        ["quant"] = 1,
                        ["id"] = "1690366583",
                        ["itemLink"] = 577,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [175940] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Leyawiin Carpet, Misty Octad",
                ["oldestTime"] = 1632879102,
                ["wasAltered"] = true,
                ["newestTime"] = 1633272478,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 333,
                        ["wasKiosk"] = false,
                        ["seller"] = 182,
                        ["timestamp"] = 1633035648,
                        ["quant"] = 1,
                        ["id"] = "1690480229",
                        ["itemLink"] = 764,
                    },
                    [2] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 655,
                        ["wasKiosk"] = false,
                        ["seller"] = 911,
                        ["timestamp"] = 1633091046,
                        ["quant"] = 1,
                        ["id"] = "1690894605",
                        ["itemLink"] = 764,
                    },
                    [3] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 655,
                        ["wasKiosk"] = false,
                        ["seller"] = 911,
                        ["timestamp"] = 1633091051,
                        ["quant"] = 1,
                        ["id"] = "1690894687",
                        ["itemLink"] = 764,
                    },
                    [4] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 1380,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633183064,
                        ["quant"] = 1,
                        ["id"] = "1691612721",
                        ["itemLink"] = 764,
                    },
                    [5] = 
                    {
                        ["price"] = 556,
                        ["guild"] = 1,
                        ["buyer"] = 31,
                        ["wasKiosk"] = false,
                        ["seller"] = 647,
                        ["timestamp"] = 1633200576,
                        ["quant"] = 1,
                        ["id"] = "1691795557",
                        ["itemLink"] = 764,
                    },
                    [6] = 
                    {
                        ["price"] = 490,
                        ["guild"] = 1,
                        ["buyer"] = 1643,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633272478,
                        ["quant"] = 1,
                        ["id"] = "1692431843",
                        ["itemLink"] = 764,
                    },
                    [7] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1208,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1632879102,
                        ["quant"] = 1,
                        ["id"] = "1689385549",
                        ["itemLink"] = 764,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [172101] = 
        {
            ["50:16:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_2hhammer_a.dds",
                ["itemDesc"] = "Maul of Frostbite",
                ["oldestTime"] = 1633240467,
                ["wasAltered"] = true,
                ["newestTime"] = 1633240467,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1772,
                        ["wasKiosk"] = true,
                        ["seller"] = 474,
                        ["timestamp"] = 1633240467,
                        ["quant"] = 1,
                        ["id"] = "1692201371",
                        ["itemLink"] = 2535,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set frostbite mace two-handed training",
            },
        },
        [153671] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_run_seplatformwide001.dds",
                ["itemDesc"] = "Elsweyr Platform, Ancient Rectangular",
                ["oldestTime"] = 1633117018,
                ["wasAltered"] = true,
                ["newestTime"] = 1633224515,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 69998,
                        ["guild"] = 1,
                        ["buyer"] = 1029,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633117018,
                        ["quant"] = 2,
                        ["id"] = "1691084785",
                        ["itemLink"] = 1411,
                    },
                    [2] = 
                    {
                        ["price"] = 69998,
                        ["guild"] = 1,
                        ["buyer"] = 1029,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633117019,
                        ["quant"] = 2,
                        ["id"] = "1691084789",
                        ["itemLink"] = 1411,
                    },
                    [3] = 
                    {
                        ["price"] = 69998,
                        ["guild"] = 1,
                        ["buyer"] = 1636,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633224515,
                        ["quant"] = 2,
                        ["id"] = "1692059261",
                        ["itemLink"] = 1411,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic furnishings structures",
            },
        },
        [95305] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_heavy_chest_a.dds",
                ["itemDesc"] = "Cuirass of the Fire",
                ["oldestTime"] = 1633052412,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052412,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 716,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633052412,
                        ["quant"] = 1,
                        ["id"] = "1690629717",
                        ["itemLink"] = 904,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set way of fire chest divines",
            },
        },
        [45898] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Deshaan Honeydew Hors D'Ouevre",
                ["oldestTime"] = 1633052896,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052926,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633052896,
                        ["quant"] = 1,
                        ["id"] = "1690634299",
                        ["itemLink"] = 924,
                    },
                    [2] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633052899,
                        ["quant"] = 1,
                        ["id"] = "1690634341",
                        ["itemLink"] = 924,
                    },
                    [3] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633052926,
                        ["quant"] = 1,
                        ["id"] = "1690634801",
                        ["itemLink"] = 924,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [181581] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting2.dds",
                ["itemDesc"] = "Praxis: Leyawiin Wall, Straight Garden",
                ["oldestTime"] = 1632935512,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309210,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 311,
                        ["timestamp"] = 1633060384,
                        ["quant"] = 1,
                        ["id"] = "1690713551",
                        ["itemLink"] = 1013,
                    },
                    [2] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 778,
                        ["wasKiosk"] = false,
                        ["seller"] = 930,
                        ["timestamp"] = 1633309210,
                        ["quant"] = 1,
                        ["id"] = "1692839215",
                        ["itemLink"] = 1013,
                    },
                    [3] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1632935512,
                        ["quant"] = 1,
                        ["id"] = "1689765871",
                        ["itemLink"] = 1013,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [166990] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 91: Hazardous Alchemy Axes",
                ["oldestTime"] = 1633118566,
                ["wasAltered"] = true,
                ["newestTime"] = 1633118566,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30192,
                        ["guild"] = 1,
                        ["buyer"] = 1038,
                        ["wasKiosk"] = true,
                        ["seller"] = 451,
                        ["timestamp"] = 1633118566,
                        ["quant"] = 1,
                        ["id"] = "1691095829",
                        ["itemLink"] = 1422,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [176463] = 
        {
            ["1:0:3:37:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_bow.dds",
                ["itemDesc"] = "Companion's Bow",
                ["oldestTime"] = 1632966903,
                ["wasAltered"] = true,
                ["newestTime"] = 1633138196,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2120,
                        ["guild"] = 1,
                        ["buyer"] = 434,
                        ["wasKiosk"] = true,
                        ["seller"] = 1167,
                        ["timestamp"] = 1633138196,
                        ["quant"] = 1,
                        ["id"] = "1691274251",
                        ["itemLink"] = 1584,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2661,
                        ["wasKiosk"] = true,
                        ["seller"] = 177,
                        ["timestamp"] = 1632966903,
                        ["quant"] = 1,
                        ["id"] = "1690023211",
                        ["itemLink"] = 1584,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior weapon bow two-handed shattering",
            },
        },
        [144465] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Soldier of Anguish Ring",
                ["oldestTime"] = 1633163922,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163922,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1633163922,
                        ["quant"] = 1,
                        ["id"] = "1691490393",
                        ["itemLink"] = 1820,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set soldier of anguish ring robust",
            },
        },
        [76884] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 34: Assassins League Daggers",
                ["oldestTime"] = 1632872414,
                ["wasAltered"] = true,
                ["newestTime"] = 1633229006,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1673,
                        ["wasKiosk"] = true,
                        ["seller"] = 514,
                        ["timestamp"] = 1633229006,
                        ["quant"] = 1,
                        ["id"] = "1692106943",
                        ["itemLink"] = 2429,
                    },
                    [2] = 
                    {
                        ["price"] = 3200,
                        ["guild"] = 1,
                        ["buyer"] = 2301,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632872414,
                        ["quant"] = 1,
                        ["id"] = "1689318219",
                        ["itemLink"] = 2429,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [43605] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Stormhaven Treasure Map V",
                ["oldestTime"] = 1633182507,
                ["wasAltered"] = true,
                ["newestTime"] = 1633202874,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 279,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182507,
                        ["quant"] = 1,
                        ["id"] = "1691608075",
                        ["itemLink"] = 1947,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1504,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633202874,
                        ["quant"] = 1,
                        ["id"] = "1691820803",
                        ["itemLink"] = 1947,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [171351] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_inc_markmirror001.dds",
                ["itemDesc"] = "Dwarven Mirror, Polished",
                ["oldestTime"] = 1633188668,
                ["wasAltered"] = true,
                ["newestTime"] = 1633188668,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 41232,
                        ["guild"] = 1,
                        ["buyer"] = 507,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1633188668,
                        ["quant"] = 1,
                        ["id"] = "1691674207",
                        ["itemLink"] = 2087,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings suite",
            },
        },
        [117852] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_inc_glassbottle002.dds",
                ["itemDesc"] = "Redguard Bottle, Stained Glass",
                ["oldestTime"] = 1632824821,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294744,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9098,
                        ["guild"] = 1,
                        ["buyer"] = 2011,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1633294744,
                        ["quant"] = 1,
                        ["id"] = "1692687081",
                        ["itemLink"] = 2873,
                    },
                    [2] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 2114,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632824821,
                        ["quant"] = 1,
                        ["id"] = "1688963275",
                        ["itemLink"] = 2873,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings hearth",
            },
        },
        [131422] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_fug_chlightstalk008.dds",
                ["itemDesc"] = "Flower Patch, Glowstalks",
                ["oldestTime"] = 1633152462,
                ["wasAltered"] = true,
                ["newestTime"] = 1633152462,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1243,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633152462,
                        ["quant"] = 1,
                        ["id"] = "1691413095",
                        ["itemLink"] = 1737,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [4448] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_leather_base_fur_r2.dds",
                ["itemDesc"] = "Hide Scraps",
                ["oldestTime"] = 1632961564,
                ["wasAltered"] = true,
                ["newestTime"] = 1632983106,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983099,
                        ["quant"] = 200,
                        ["id"] = "1690148267",
                        ["itemLink"] = 298,
                    },
                    [2] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983099,
                        ["quant"] = 200,
                        ["id"] = "1690148269",
                        ["itemLink"] = 298,
                    },
                    [3] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983102,
                        ["quant"] = 200,
                        ["id"] = "1690148275",
                        ["itemLink"] = 298,
                    },
                    [4] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983103,
                        ["quant"] = 200,
                        ["id"] = "1690148279",
                        ["itemLink"] = 298,
                    },
                    [5] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983104,
                        ["quant"] = 200,
                        ["id"] = "1690148281",
                        ["itemLink"] = 298,
                    },
                    [6] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632983106,
                        ["quant"] = 200,
                        ["id"] = "1690148291",
                        ["itemLink"] = 298,
                    },
                    [7] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961564,
                        ["quant"] = 200,
                        ["id"] = "1689971649",
                        ["itemLink"] = 298,
                    },
                    [8] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961565,
                        ["quant"] = 200,
                        ["id"] = "1689971657",
                        ["itemLink"] = 298,
                    },
                    [9] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961565,
                        ["quant"] = 200,
                        ["id"] = "1689971663",
                        ["itemLink"] = 298,
                    },
                    [10] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961566,
                        ["quant"] = 200,
                        ["id"] = "1689971671",
                        ["itemLink"] = 298,
                    },
                    [11] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961567,
                        ["quant"] = 200,
                        ["id"] = "1689971681",
                        ["itemLink"] = 298,
                    },
                    [12] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2627,
                        ["wasKiosk"] = true,
                        ["seller"] = 294,
                        ["timestamp"] = 1632961567,
                        ["quant"] = 200,
                        ["id"] = "1689971689",
                        ["itemLink"] = 298,
                    },
                },
                ["totalCount"] = 12,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [101219] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_heavy_hands_d.dds",
                ["itemDesc"] = "Gauntlets of Soulshine",
                ["oldestTime"] = 1633235199,
                ["wasAltered"] = true,
                ["newestTime"] = 1633235199,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 440,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 52,
                        ["timestamp"] = 1633235199,
                        ["quant"] = 1,
                        ["id"] = "1692162267",
                        ["itemLink"] = 2481,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set soulshine hands reinforced",
            },
        },
        [45157] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Restoration Staff of Flame",
                ["oldestTime"] = 1633180222,
                ["wasAltered"] = true,
                ["newestTime"] = 1633180222,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 420,
                        ["guild"] = 1,
                        ["buyer"] = 1363,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1633180222,
                        ["quant"] = 1,
                        ["id"] = "1691586817",
                        ["itemLink"] = 1925,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon healing staff two-handed infused",
            },
        },
        [82026] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 42: Hollowjack Bows",
                ["oldestTime"] = 1633207979,
                ["wasAltered"] = true,
                ["newestTime"] = 1633314393,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7100,
                        ["guild"] = 1,
                        ["buyer"] = 68,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1633314393,
                        ["quant"] = 1,
                        ["id"] = "1692894409",
                        ["itemLink"] = 53,
                    },
                    [2] = 
                    {
                        ["price"] = 13900,
                        ["guild"] = 1,
                        ["buyer"] = 1539,
                        ["wasKiosk"] = true,
                        ["seller"] = 611,
                        ["timestamp"] = 1633207979,
                        ["quant"] = 1,
                        ["id"] = "1691881875",
                        ["itemLink"] = 53,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [43627] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Auridon Treasure Map III",
                ["oldestTime"] = 1633182509,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182509,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182509,
                        ["quant"] = 1,
                        ["id"] = "1691608101",
                        ["itemLink"] = 1949,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [82031] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 42: Hollowjack Legs",
                ["oldestTime"] = 1633207974,
                ["wasAltered"] = true,
                ["newestTime"] = 1633207974,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 26800,
                        ["guild"] = 1,
                        ["buyer"] = 1539,
                        ["wasKiosk"] = true,
                        ["seller"] = 611,
                        ["timestamp"] = 1633207974,
                        ["quant"] = 1,
                        ["id"] = "1691881863",
                        ["itemLink"] = 2259,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [77170] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ooth_medium_feet_a.dds",
                ["itemDesc"] = "Boots of Flanking",
                ["oldestTime"] = 1633287854,
                ["wasAltered"] = true,
                ["newestTime"] = 1633287854,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1821,
                        ["wasKiosk"] = true,
                        ["seller"] = 547,
                        ["timestamp"] = 1633287854,
                        ["quant"] = 1,
                        ["id"] = "1692603243",
                        ["itemLink"] = 2765,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set flanking strategist feet impenetrable",
            },
        },
        [126836] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing3.dds",
                ["itemDesc"] = "Diagram: Daedric Bench, Ashen",
                ["oldestTime"] = 1633148853,
                ["wasAltered"] = true,
                ["newestTime"] = 1633148854,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30,
                        ["guild"] = 1,
                        ["buyer"] = 1249,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1633148853,
                        ["quant"] = 1,
                        ["id"] = "1691381375",
                        ["itemLink"] = 1699,
                    },
                    [2] = 
                    {
                        ["price"] = 40,
                        ["guild"] = 1,
                        ["buyer"] = 1249,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633148854,
                        ["quant"] = 1,
                        ["id"] = "1691381379",
                        ["itemLink"] = 1699,
                    },
                    [3] = 
                    {
                        ["price"] = 52,
                        ["guild"] = 1,
                        ["buyer"] = 1249,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1633148854,
                        ["quant"] = 1,
                        ["id"] = "1691381383",
                        ["itemLink"] = 1699,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [93304] = 
        {
            ["50:16:5:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_bow_a.dds",
                ["itemDesc"] = "Bow of the Hawk's Eye",
                ["oldestTime"] = 1632868135,
                ["wasAltered"] = true,
                ["newestTime"] = 1632868135,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 95000,
                        ["guild"] = 1,
                        ["buyer"] = 1987,
                        ["wasKiosk"] = true,
                        ["seller"] = 1786,
                        ["timestamp"] = 1632868135,
                        ["quant"] = 1,
                        ["id"] = "1689288787",
                        ["itemLink"] = 3367,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary weapon set hawk's eye bow two-handed decisive",
            },
        },
        [101243] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_heavy_waist_d.dds",
                ["itemDesc"] = "Girdle of Soulshine",
                ["oldestTime"] = 1632836271,
                ["wasAltered"] = true,
                ["newestTime"] = 1632836271,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2213,
                        ["guild"] = 1,
                        ["buyer"] = 2160,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1632836271,
                        ["quant"] = 1,
                        ["id"] = "1689036175",
                        ["itemLink"] = 3111,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set soulshine waist impenetrable",
            },
        },
        [68220] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Port Hunding Pinot Noir",
                ["oldestTime"] = 1633151695,
                ["wasAltered"] = true,
                ["newestTime"] = 1633151695,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 118,
                        ["guild"] = 1,
                        ["buyer"] = 839,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633151695,
                        ["quant"] = 1,
                        ["id"] = "1691405593",
                        ["itemLink"] = 1733,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [172157] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_feet_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Boots",
                ["oldestTime"] = 1633147543,
                ["wasAltered"] = true,
                ["newestTime"] = 1633229807,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 954,
                        ["guild"] = 1,
                        ["buyer"] = 1240,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1633147543,
                        ["quant"] = 1,
                        ["id"] = "1691370235",
                        ["itemLink"] = 1676,
                    },
                    [2] = 
                    {
                        ["price"] = 850,
                        ["guild"] = 1,
                        ["buyer"] = 1685,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633229807,
                        ["quant"] = 1,
                        ["id"] = "1692113381",
                        ["itemLink"] = 1676,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior medium apparel set deadlands assassin feet divines",
            },
        },
        [68223] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Wide-Eye Double Rye",
                ["oldestTime"] = 1633314479,
                ["wasAltered"] = true,
                ["newestTime"] = 1633314479,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 80,
                        ["guild"] = 1,
                        ["buyer"] = 76,
                        ["wasKiosk"] = false,
                        ["seller"] = 77,
                        ["timestamp"] = 1633314479,
                        ["quant"] = 1,
                        ["id"] = "1692896221",
                        ["itemLink"] = 57,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [56961] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Blacklight Oxen Meatballs",
                ["oldestTime"] = 1633052859,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052859,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633052859,
                        ["quant"] = 1,
                        ["id"] = "1690633843",
                        ["itemLink"] = 921,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [172162] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_waist_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Belt",
                ["oldestTime"] = 1633270097,
                ["wasAltered"] = true,
                ["newestTime"] = 1633270097,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1872,
                        ["wasKiosk"] = true,
                        ["seller"] = 1417,
                        ["timestamp"] = 1633270097,
                        ["quant"] = 1,
                        ["id"] = "1692405745",
                        ["itemLink"] = 2664,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set deadlands assassin waist divines",
            },
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_waist_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Belt",
                ["oldestTime"] = 1633278136,
                ["wasAltered"] = true,
                ["newestTime"] = 1633278136,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1914,
                        ["wasKiosk"] = true,
                        ["seller"] = 531,
                        ["timestamp"] = 1633278136,
                        ["quant"] = 1,
                        ["id"] = "1692496257",
                        ["itemLink"] = 2717,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set deadlands assassin waist divines",
            },
        },
        [177027] = 
        {
            ["1:0:3:50:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_shoulders_heavy.dds",
                ["itemDesc"] = "Companion's Pauldrons",
                ["oldestTime"] = 1632902235,
                ["wasAltered"] = true,
                ["newestTime"] = 1633295522,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 69999,
                        ["guild"] = 1,
                        ["buyer"] = 336,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1632988251,
                        ["quant"] = 1,
                        ["id"] = "1690175929",
                        ["itemLink"] = 341,
                    },
                    [2] = 
                    {
                        ["price"] = 69999,
                        ["guild"] = 1,
                        ["buyer"] = 2001,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633293827,
                        ["quant"] = 1,
                        ["id"] = "1692673871",
                        ["itemLink"] = 341,
                    },
                    [3] = 
                    {
                        ["price"] = 69999,
                        ["guild"] = 1,
                        ["buyer"] = 2019,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633295522,
                        ["quant"] = 1,
                        ["id"] = "1692696479",
                        ["itemLink"] = 341,
                    },
                    [4] = 
                    {
                        ["price"] = 69999,
                        ["guild"] = 1,
                        ["buyer"] = 249,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1632902235,
                        ["quant"] = 1,
                        ["id"] = "1689570029",
                        ["itemLink"] = 341,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior heavy apparel shoulders bolstered",
            },
        },
        [171908] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 101: Ivory Brigade Staves",
                ["oldestTime"] = 1632972029,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242087,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 67,
                        ["wasKiosk"] = false,
                        ["seller"] = 43,
                        ["timestamp"] = 1632972029,
                        ["quant"] = 1,
                        ["id"] = "1690076715",
                        ["itemLink"] = 198,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 517,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1633021875,
                        ["quant"] = 1,
                        ["id"] = "1690382791",
                        ["itemLink"] = 198,
                    },
                    [3] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1037,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1633118163,
                        ["quant"] = 1,
                        ["id"] = "1691092735",
                        ["itemLink"] = 198,
                    },
                    [4] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 418,
                        ["wasKiosk"] = true,
                        ["seller"] = 351,
                        ["timestamp"] = 1633128038,
                        ["quant"] = 1,
                        ["id"] = "1691167669",
                        ["itemLink"] = 198,
                    },
                    [5] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 151,
                        ["wasKiosk"] = false,
                        ["seller"] = 1450,
                        ["timestamp"] = 1633203433,
                        ["quant"] = 1,
                        ["id"] = "1691828113",
                        ["itemLink"] = 198,
                    },
                    [6] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1654,
                        ["wasKiosk"] = true,
                        ["seller"] = 711,
                        ["timestamp"] = 1633226605,
                        ["quant"] = 1,
                        ["id"] = "1692081205",
                        ["itemLink"] = 198,
                    },
                    [7] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1782,
                        ["wasKiosk"] = true,
                        ["seller"] = 256,
                        ["timestamp"] = 1633242087,
                        ["quant"] = 1,
                        ["id"] = "1692212137",
                        ["itemLink"] = 198,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [115845] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Wood Elf Urn, Scratched",
                ["oldestTime"] = 1633260587,
                ["wasAltered"] = true,
                ["newestTime"] = 1633260587,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 727,
                        ["guild"] = 1,
                        ["buyer"] = 1837,
                        ["wasKiosk"] = true,
                        ["seller"] = 528,
                        ["timestamp"] = 1633260587,
                        ["quant"] = 1,
                        ["id"] = "1692328467",
                        ["itemLink"] = 2618,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [68231] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Orcrest Agony Pale Ale",
                ["oldestTime"] = 1633216786,
                ["wasAltered"] = true,
                ["newestTime"] = 1633216786,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3050,
                        ["guild"] = 1,
                        ["buyer"] = 1592,
                        ["wasKiosk"] = true,
                        ["seller"] = 92,
                        ["timestamp"] = 1633216786,
                        ["quant"] = 1,
                        ["id"] = "1691976497",
                        ["itemLink"] = 2322,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [27272] = 
        {
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Aldmion's Amulet",
                ["oldestTime"] = 1633163910,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163910,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1633163910,
                        ["quant"] = 1,
                        ["id"] = "1691490311",
                        ["itemLink"] = 1802,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel neck healthy",
            },
        },
        [87690] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/event_halloween_2016_iron_cup_celery.dds",
                ["itemDesc"] = "Witchmother's Party Punch",
                ["oldestTime"] = 1632935020,
                ["wasAltered"] = true,
                ["newestTime"] = 1632935020,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1455,
                        ["guild"] = 1,
                        ["buyer"] = 626,
                        ["wasKiosk"] = false,
                        ["seller"] = 158,
                        ["timestamp"] = 1632935020,
                        ["quant"] = 97,
                        ["id"] = "1689760767",
                        ["itemLink"] = 3726,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable drink",
            },
        },
        [118925] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing4.dds",
                ["itemDesc"] = "Diagram: High Elf Trunk, Jeweled",
                ["oldestTime"] = 1633216487,
                ["wasAltered"] = true,
                ["newestTime"] = 1633216487,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 1589,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633216487,
                        ["quant"] = 1,
                        ["id"] = "1691973321",
                        ["itemLink"] = 2320,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [176014] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning3.dds",
                ["itemDesc"] = "Design: Leyawiin Gravy Boat, Silver",
                ["oldestTime"] = 1632865534,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865534,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1632865534,
                        ["quant"] = 1,
                        ["id"] = "1689268873",
                        ["itemLink"] = 3343,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [150672] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_water_plant_nirnroot_crimson.dds",
                ["itemDesc"] = "Crimson Nirnroot",
                ["oldestTime"] = 1632876351,
                ["wasAltered"] = true,
                ["newestTime"] = 1632876351,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 81400,
                        ["guild"] = 1,
                        ["buyer"] = 151,
                        ["wasKiosk"] = false,
                        ["seller"] = 9,
                        ["timestamp"] = 1632876351,
                        ["quant"] = 200,
                        ["id"] = "1689355137",
                        ["itemLink"] = 3425,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [172177] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_feet_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Boots",
                ["oldestTime"] = 1633114502,
                ["wasAltered"] = true,
                ["newestTime"] = 1633114502,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1013,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633114502,
                        ["quant"] = 1,
                        ["id"] = "1691069395",
                        ["itemLink"] = 1380,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set deadlands assassin feet well-fitted",
            },
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_feet_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Boots",
                ["oldestTime"] = 1633277151,
                ["wasAltered"] = true,
                ["newestTime"] = 1633277151,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1907,
                        ["wasKiosk"] = true,
                        ["seller"] = 1417,
                        ["timestamp"] = 1633277151,
                        ["quant"] = 1,
                        ["id"] = "1692487753",
                        ["itemLink"] = 2707,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set deadlands assassin feet well-fitted",
            },
        },
        [57619] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 20: Yokudan Swords",
                ["oldestTime"] = 1632967714,
                ["wasAltered"] = true,
                ["newestTime"] = 1632967714,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12500,
                        ["guild"] = 1,
                        ["buyer"] = 2670,
                        ["wasKiosk"] = true,
                        ["seller"] = 696,
                        ["timestamp"] = 1632967714,
                        ["quant"] = 1,
                        ["id"] = "1690031103",
                        ["itemLink"] = 3976,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [149139] = 
        {
            ["50:16:2:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_heavy_waist_a.dds",
                ["itemDesc"] = "Undertaker's Girdle",
                ["oldestTime"] = 1633114520,
                ["wasAltered"] = true,
                ["newestTime"] = 1633114520,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 1013,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1633114520,
                        ["quant"] = 1,
                        ["id"] = "1691069517",
                        ["itemLink"] = 1387,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set call of the undertaker waist reinforced",
            },
        },
        [180528] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_light_hands_a.dds",
                ["itemDesc"] = "Gloves of Dark Convergence",
                ["oldestTime"] = 1633150227,
                ["wasAltered"] = true,
                ["newestTime"] = 1633150227,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7888,
                        ["guild"] = 1,
                        ["buyer"] = 1259,
                        ["wasKiosk"] = true,
                        ["seller"] = 48,
                        ["timestamp"] = 1633150227,
                        ["quant"] = 1,
                        ["id"] = "1691393077",
                        ["itemLink"] = 1722,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set dark convergence hands impenetrable",
            },
        },
        [161429] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_heavy_chest_d.dds",
                ["itemDesc"] = "Stuhn's Cuirass",
                ["oldestTime"] = 1633288204,
                ["wasAltered"] = true,
                ["newestTime"] = 1633288204,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 1968,
                        ["wasKiosk"] = true,
                        ["seller"] = 819,
                        ["timestamp"] = 1633288204,
                        ["quant"] = 1,
                        ["id"] = "1692606739",
                        ["itemLink"] = 2767,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set stuhn's favor chest impenetrable",
            },
        },
        [172182] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_waist_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Belt",
                ["oldestTime"] = 1633023012,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023012,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 355,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633023012,
                        ["quant"] = 1,
                        ["id"] = "1690390707",
                        ["itemLink"] = 635,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set deadlands assassin waist well-fitted",
            },
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_waist_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Belt",
                ["oldestTime"] = 1633277146,
                ["wasAltered"] = true,
                ["newestTime"] = 1633277146,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1907,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633277146,
                        ["quant"] = 1,
                        ["id"] = "1692487711",
                        ["itemLink"] = 2705,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set deadlands assassin waist well-fitted",
            },
        },
        [167368] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Solitude Platform, Square Wooden",
                ["oldestTime"] = 1632958342,
                ["wasAltered"] = true,
                ["newestTime"] = 1632958342,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1472,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632958342,
                        ["quant"] = 1,
                        ["id"] = "1689946445",
                        ["itemLink"] = 3910,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45208] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_light_feet_d.dds",
                ["itemDesc"] = "Ancestor Silk Shoes of Stamina",
                ["oldestTime"] = 1633022967,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022970,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633022967,
                        ["quant"] = 1,
                        ["id"] = "1690390323",
                        ["itemLink"] = 607,
                    },
                    [2] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633022968,
                        ["quant"] = 1,
                        ["id"] = "1690390327",
                        ["itemLink"] = 608,
                    },
                    [3] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633022970,
                        ["quant"] = 1,
                        ["id"] = "1690390335",
                        ["itemLink"] = 610,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 green fine light apparel feet infused",
            },
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_light_feet_d.dds",
                ["itemDesc"] = "Ancestor Silk Shoes of Stamina",
                ["oldestTime"] = 1632936819,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022983,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633022983,
                        ["quant"] = 1,
                        ["id"] = "1690390467",
                        ["itemLink"] = 623,
                    },
                    [2] = 
                    {
                        ["price"] = 225,
                        ["guild"] = 1,
                        ["buyer"] = 226,
                        ["wasKiosk"] = false,
                        ["seller"] = 526,
                        ["timestamp"] = 1632936819,
                        ["quant"] = 1,
                        ["id"] = "1689773975",
                        ["itemLink"] = 3741,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior light apparel feet infused",
            },
        },
        [23121] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_wood_base_beech_r3.dds",
                ["itemDesc"] = "Sanded Beech",
                ["oldestTime"] = 1632769469,
                ["wasAltered"] = true,
                ["newestTime"] = 1632987699,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 2,
                        ["buyer"] = 124,
                        ["wasKiosk"] = false,
                        ["seller"] = 125,
                        ["timestamp"] = 1632769469,
                        ["quant"] = 100,
                        ["id"] = "1688524855",
                        ["itemLink"] = 117,
                    },
                    [2] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 148,
                        ["timestamp"] = 1632987699,
                        ["quant"] = 200,
                        ["id"] = "1690172809",
                        ["itemLink"] = 117,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [77210] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ooth_medium_feet_a.dds",
                ["itemDesc"] = "Boots of Flanking",
                ["oldestTime"] = 1633114512,
                ["wasAltered"] = true,
                ["newestTime"] = 1633114512,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 1013,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1633114512,
                        ["quant"] = 1,
                        ["id"] = "1691069449",
                        ["itemLink"] = 1383,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set flanking strategist feet sturdy",
            },
        },
        [176283] = 
        {
            ["1:0:2:36:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_bow.dds",
                ["itemDesc"] = "Companion's Bow",
                ["oldestTime"] = 1633044264,
                ["wasAltered"] = true,
                ["newestTime"] = 1633044264,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 88,
                        ["guild"] = 1,
                        ["buyer"] = 661,
                        ["wasKiosk"] = true,
                        ["seller"] = 663,
                        ["timestamp"] = 1633044264,
                        ["quant"] = 1,
                        ["id"] = "1690549557",
                        ["itemLink"] = 844,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine weapon bow two-handed focused",
            },
        },
        [43539] = 
        {
            ["50:14:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_heavy_hands_d.dds",
                ["itemDesc"] = "Voidsteel Gauntlets",
                ["oldestTime"] = 1632948292,
                ["wasAltered"] = true,
                ["newestTime"] = 1632948292,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 84,
                        ["guild"] = 1,
                        ["buyer"] = 2575,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1632948292,
                        ["quant"] = 1,
                        ["id"] = "1689859797",
                        ["itemLink"] = 3798,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp140 white normal heavy apparel hands",
            },
        },
        [172445] = 
        {
            ["50:16:4:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_hvy_legs_a.dds",
                ["itemDesc"] = "Bog Raider's Greaves",
                ["oldestTime"] = 1633233305,
                ["wasAltered"] = true,
                ["newestTime"] = 1633244649,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 430,
                        ["guild"] = 1,
                        ["buyer"] = 1713,
                        ["wasKiosk"] = true,
                        ["seller"] = 237,
                        ["timestamp"] = 1633233305,
                        ["quant"] = 1,
                        ["id"] = "1692147757",
                        ["itemLink"] = 2454,
                    },
                    [2] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 1791,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1633244649,
                        ["quant"] = 1,
                        ["id"] = "1692231061",
                        ["itemLink"] = 2454,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set bog raider legs training",
            },
        },
        [69333] = 
        {
            ["50:16:4:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_1haxe_d.dds",
                ["itemDesc"] = "Axe of Agility",
                ["oldestTime"] = 1632945754,
                ["wasAltered"] = true,
                ["newestTime"] = 1632945754,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 408,
                        ["wasKiosk"] = false,
                        ["seller"] = 142,
                        ["timestamp"] = 1632945754,
                        ["quant"] = 1,
                        ["id"] = "1689840401",
                        ["itemLink"] = 3789,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set agility axe one-handed powered",
            },
        },
        [54513] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Platinum Necklace of Reduce Feat Cost",
                ["oldestTime"] = 1633163907,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163907,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 722,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1633163907,
                        ["quant"] = 1,
                        ["id"] = "1691490291",
                        ["itemLink"] = 1798,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel neck arcane",
            },
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Platinum Necklace of Reduce Spell Cost",
                ["oldestTime"] = 1633163939,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163939,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 6,
                        ["timestamp"] = 1633163939,
                        ["quant"] = 1,
                        ["id"] = "1691490509",
                        ["itemLink"] = 1829,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel neck arcane",
            },
        },
        [176544] = 
        {
            ["1:0:2:47:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_chest_robe.dds",
                ["itemDesc"] = "Companion's Robe",
                ["oldestTime"] = 1633075314,
                ["wasAltered"] = true,
                ["newestTime"] = 1633075314,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 330,
                        ["guild"] = 1,
                        ["buyer"] = 864,
                        ["wasKiosk"] = true,
                        ["seller"] = 1,
                        ["timestamp"] = 1633075314,
                        ["quant"] = 1,
                        ["id"] = "1690812675",
                        ["itemLink"] = 1108,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine light apparel chest aggressive",
            },
        },
        [175777] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Old Orsinium Shield",
                ["oldestTime"] = 1632780928,
                ["wasAltered"] = true,
                ["newestTime"] = 1633106502,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 2,
                        ["buyer"] = 127,
                        ["wasKiosk"] = false,
                        ["seller"] = 130,
                        ["timestamp"] = 1632780928,
                        ["quant"] = 1,
                        ["id"] = "1688621141",
                        ["itemLink"] = 126,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 969,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633106502,
                        ["quant"] = 1,
                        ["id"] = "1691012151",
                        ["itemLink"] = 126,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [180427] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Dark Convergence",
                ["oldestTime"] = 1632846891,
                ["wasAltered"] = true,
                ["newestTime"] = 1633062374,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 797,
                        ["wasKiosk"] = true,
                        ["seller"] = 238,
                        ["timestamp"] = 1633062373,
                        ["quant"] = 1,
                        ["id"] = "1690728535",
                        ["itemLink"] = 1035,
                    },
                    [2] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 797,
                        ["wasKiosk"] = true,
                        ["seller"] = 238,
                        ["timestamp"] = 1633062374,
                        ["quant"] = 1,
                        ["id"] = "1690728549",
                        ["itemLink"] = 1035,
                    },
                    [3] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2200,
                        ["wasKiosk"] = true,
                        ["seller"] = 531,
                        ["timestamp"] = 1632846891,
                        ["quant"] = 1,
                        ["id"] = "1689117837",
                        ["itemLink"] = 3203,
                    },
                    [4] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 2322,
                        ["wasKiosk"] = true,
                        ["seller"] = 301,
                        ["timestamp"] = 1632875147,
                        ["quant"] = 1,
                        ["id"] = "1689342839",
                        ["itemLink"] = 3203,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set dark convergence ring arcane",
            },
            ["50:16:5:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Dark Convergence",
                ["oldestTime"] = 1633080711,
                ["wasAltered"] = true,
                ["newestTime"] = 1633080721,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600000,
                        ["guild"] = 1,
                        ["buyer"] = 883,
                        ["wasKiosk"] = true,
                        ["seller"] = 28,
                        ["timestamp"] = 1633080711,
                        ["quant"] = 1,
                        ["id"] = "1690838375",
                        ["itemLink"] = 1126,
                    },
                    [2] = 
                    {
                        ["price"] = 600000,
                        ["guild"] = 1,
                        ["buyer"] = 883,
                        ["wasKiosk"] = true,
                        ["seller"] = 28,
                        ["timestamp"] = 1633080721,
                        ["quant"] = 1,
                        ["id"] = "1690838391",
                        ["itemLink"] = 1126,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 gold legendary jewelry apparel set dark convergence ring arcane",
            },
        },
        [68253] = 
        {
            ["50:15:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_dessert_002.dds",
                ["itemDesc"] = "Longfin Pasty with Melon Sauce",
                ["oldestTime"] = 1632914873,
                ["wasAltered"] = true,
                ["newestTime"] = 1632914876,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 2473,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1632914873,
                        ["quant"] = 100,
                        ["id"] = "1689622641",
                        ["itemLink"] = 3639,
                    },
                    [2] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 2473,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632914875,
                        ["quant"] = 50,
                        ["id"] = "1689622651",
                        ["itemLink"] = 3639,
                    },
                    [3] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 2473,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632914876,
                        ["quant"] = 50,
                        ["id"] = "1689622657",
                        ["itemLink"] = 3639,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp150 purple epic consumable food",
            },
        },
        [69540] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 21: Ancient Orc Staves",
                ["oldestTime"] = 1633107988,
                ["wasAltered"] = true,
                ["newestTime"] = 1633274497,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 973,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633107988,
                        ["quant"] = 1,
                        ["id"] = "1691021999",
                        ["itemLink"] = 1306,
                    },
                    [2] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 1288,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633157047,
                        ["quant"] = 1,
                        ["id"] = "1691447797",
                        ["itemLink"] = 1306,
                    },
                    [3] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 570,
                        ["wasKiosk"] = true,
                        ["seller"] = 981,
                        ["timestamp"] = 1633274497,
                        ["quant"] = 1,
                        ["id"] = "1692457213",
                        ["itemLink"] = 1306,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [135384] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_medium_shoulders_a.dds",
                ["itemDesc"] = "Gryphon's Arm Cops",
                ["oldestTime"] = 1632912484,
                ["wasAltered"] = true,
                ["newestTime"] = 1632912484,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1645,
                        ["guild"] = 1,
                        ["buyer"] = 2468,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1632912484,
                        ["quant"] = 1,
                        ["id"] = "1689610383",
                        ["itemLink"] = 3622,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set gryphon's ferocity shoulders divines",
            },
        },
        [49126] = 
        {
            ["10:0:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_medium_feet_a.dds",
                ["itemDesc"] = "Boots of the Night Mother",
                ["oldestTime"] = 1632911083,
                ["wasAltered"] = true,
                ["newestTime"] = 1632911083,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2463,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632911083,
                        ["quant"] = 1,
                        ["id"] = "1689604523",
                        ["itemLink"] = 3611,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr10 blue superior medium apparel set night mother's gaze feet training",
            },
        },
        [140455] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 63: Dremora Shields",
                ["oldestTime"] = 1632848425,
                ["wasAltered"] = true,
                ["newestTime"] = 1632941253,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2206,
                        ["wasKiosk"] = true,
                        ["seller"] = 1285,
                        ["timestamp"] = 1632848425,
                        ["quant"] = 1,
                        ["id"] = "1689131413",
                        ["itemLink"] = 3225,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2547,
                        ["wasKiosk"] = true,
                        ["seller"] = 1285,
                        ["timestamp"] = 1632941253,
                        ["quant"] = 1,
                        ["id"] = "1689804055",
                        ["itemLink"] = 3225,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [151976] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Elsweyr Plate, Rough",
                ["oldestTime"] = 1633117331,
                ["wasAltered"] = true,
                ["newestTime"] = 1633117331,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 70,
                        ["guild"] = 1,
                        ["buyer"] = 1030,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1633117331,
                        ["quant"] = 1,
                        ["id"] = "1691087039",
                        ["itemLink"] = 1412,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [43649] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Reaper's March Treasure Map I",
                ["oldestTime"] = 1632899955,
                ["wasAltered"] = true,
                ["newestTime"] = 1632899955,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 499,
                        ["guild"] = 1,
                        ["buyer"] = 2443,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1632899955,
                        ["quant"] = 1,
                        ["id"] = "1689558659",
                        ["itemLink"] = 3572,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [160664] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_blackreachexlgt_feet.dds",
                ["itemDesc"] = "Shoes of Winter's Respite",
                ["oldestTime"] = 1632890892,
                ["wasAltered"] = true,
                ["newestTime"] = 1632890892,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2159,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1632890892,
                        ["quant"] = 1,
                        ["id"] = "1689499523",
                        ["itemLink"] = 3538,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set winter's respite feet divines",
            },
        },
        [43691] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Stros M'Kai Treasure Map I",
                ["oldestTime"] = 1633149348,
                ["wasAltered"] = true,
                ["newestTime"] = 1633149348,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1250,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633149348,
                        ["quant"] = 1,
                        ["id"] = "1691385293",
                        ["itemLink"] = 1706,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [45664] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Pork and Bitter Melon",
                ["oldestTime"] = 1632887305,
                ["wasAltered"] = true,
                ["newestTime"] = 1632887305,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2398,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632887305,
                        ["quant"] = 1,
                        ["id"] = "1689472991",
                        ["itemLink"] = 3524,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [119197] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Redguard Mat, Sunset",
                ["oldestTime"] = 1632857091,
                ["wasAltered"] = true,
                ["newestTime"] = 1632857091,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 2240,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632857091,
                        ["quant"] = 1,
                        ["id"] = "1689206649",
                        ["itemLink"] = 3278,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [69294] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_1haxe_d.dds",
                ["itemDesc"] = "Axe of Agility",
                ["oldestTime"] = 1633211147,
                ["wasAltered"] = true,
                ["newestTime"] = 1633211147,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1399,
                        ["guild"] = 1,
                        ["buyer"] = 797,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633211147,
                        ["quant"] = 1,
                        ["id"] = "1691916951",
                        ["itemLink"] = 2279,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set agility axe one-handed sharpened",
            },
        },
        [133039] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Unfathomable Darkness",
                ["oldestTime"] = 1632865192,
                ["wasAltered"] = true,
                ["newestTime"] = 1633157001,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 213,
                        ["wasKiosk"] = true,
                        ["seller"] = 92,
                        ["timestamp"] = 1632975498,
                        ["quant"] = 1,
                        ["id"] = "1690099103",
                        ["itemLink"] = 223,
                    },
                    [2] = 
                    {
                        ["price"] = 4100,
                        ["guild"] = 1,
                        ["buyer"] = 306,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633106376,
                        ["quant"] = 1,
                        ["id"] = "1691011595",
                        ["itemLink"] = 223,
                    },
                    [3] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1044,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633119067,
                        ["quant"] = 1,
                        ["id"] = "1691098473",
                        ["itemLink"] = 223,
                    },
                    [4] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1287,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633156999,
                        ["quant"] = 1,
                        ["id"] = "1691447297",
                        ["itemLink"] = 223,
                    },
                    [5] = 
                    {
                        ["price"] = 7313,
                        ["guild"] = 1,
                        ["buyer"] = 1287,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633157001,
                        ["quant"] = 1,
                        ["id"] = "1691447321",
                        ["itemLink"] = 223,
                    },
                    [6] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 2255,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632865192,
                        ["quant"] = 1,
                        ["id"] = "1689266013",
                        ["itemLink"] = 223,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set unfathomable darkness ring robust",
            },
        },
        [176724] = 
        {
            ["1:0:3:48:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_chest_robe.dds",
                ["itemDesc"] = "Companion's Robe",
                ["oldestTime"] = 1632874441,
                ["wasAltered"] = true,
                ["newestTime"] = 1632874441,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13333,
                        ["guild"] = 1,
                        ["buyer"] = 2316,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1632874441,
                        ["quant"] = 1,
                        ["id"] = "1689335297",
                        ["itemLink"] = 3403,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior light apparel chest soothing",
            },
        },
        [139645] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Alinor Tapestry, Royal Gryphons",
                ["oldestTime"] = 1632865546,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865546,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632865546,
                        ["quant"] = 1,
                        ["id"] = "1689268973",
                        ["itemLink"] = 3349,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [119106] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Orcish Tapestry, Axe",
                ["oldestTime"] = 1632865539,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865539,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632865539,
                        ["quant"] = 1,
                        ["id"] = "1689268919",
                        ["itemLink"] = 3346,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [176307] = 
        {
            ["1:0:3:45:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_shoulders_heavy.dds",
                ["itemDesc"] = "Companion's Pauldrons",
                ["oldestTime"] = 1633194344,
                ["wasAltered"] = true,
                ["newestTime"] = 1633194344,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 1441,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1633194344,
                        ["quant"] = 1,
                        ["id"] = "1691737247",
                        ["itemLink"] = 2129,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior heavy apparel shoulders focused",
            },
        },
        [175568] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Ja'zennji Siir Boots",
                ["oldestTime"] = 1632861853,
                ["wasAltered"] = true,
                ["newestTime"] = 1632861853,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 575,
                        ["guild"] = 1,
                        ["buyer"] = 2249,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1632861853,
                        ["quant"] = 1,
                        ["id"] = "1689243487",
                        ["itemLink"] = 3313,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [175570] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Ja'zennji Siir Belt",
                ["oldestTime"] = 1632861849,
                ["wasAltered"] = true,
                ["newestTime"] = 1632861849,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2249,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632861849,
                        ["quant"] = 1,
                        ["id"] = "1689243455",
                        ["itemLink"] = 3312,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [79374] = 
        {
            ["50:16:4:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_2hsword_c.dds",
                ["itemDesc"] = "Briarheart Greatsword",
                ["oldestTime"] = 1632858663,
                ["wasAltered"] = true,
                ["newestTime"] = 1632858663,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 1613,
                        ["wasKiosk"] = true,
                        ["seller"] = 171,
                        ["timestamp"] = 1632858663,
                        ["quant"] = 1,
                        ["id"] = "1689220225",
                        ["itemLink"] = 3294,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set briarheart sword two-handed decisive",
            },
        },
        [46007] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Bitter Tea",
                ["oldestTime"] = 1632874519,
                ["wasAltered"] = true,
                ["newestTime"] = 1632874519,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 27,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 711,
                        ["timestamp"] = 1632874519,
                        ["quant"] = 1,
                        ["id"] = "1689336279",
                        ["itemLink"] = 3404,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [151915] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_uni_con_keylrg001.dds",
                ["itemDesc"] = "Daedric Key, Coldharbour",
                ["oldestTime"] = 1632851095,
                ["wasAltered"] = true,
                ["newestTime"] = 1632851095,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 175,
                        ["wasKiosk"] = false,
                        ["seller"] = 669,
                        ["timestamp"] = 1632851095,
                        ["quant"] = 1,
                        ["id"] = "1689152547",
                        ["itemLink"] = 3236,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings parlor",
            },
        },
        [69305] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_staff_d.dds",
                ["itemDesc"] = "Restoration Staff of Agility",
                ["oldestTime"] = 1633043764,
                ["wasAltered"] = true,
                ["newestTime"] = 1633043764,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633043764,
                        ["quant"] = 1,
                        ["id"] = "1690544085",
                        ["itemLink"] = 839,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set agility healing staff two-handed sharpened",
            },
        },
        [33254] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_heavy_armor_sp_names_001.dds",
                ["itemDesc"] = "Nickel",
                ["oldestTime"] = 1632850800,
                ["wasAltered"] = true,
                ["newestTime"] = 1632851905,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8990,
                        ["guild"] = 1,
                        ["buyer"] = 2215,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1632850800,
                        ["quant"] = 200,
                        ["id"] = "1689151251",
                        ["itemLink"] = 3232,
                    },
                    [2] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 2215,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632851905,
                        ["quant"] = 200,
                        ["id"] = "1689157827",
                        ["itemLink"] = 3232,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [71733] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 27: Ebonheart Pact Staves",
                ["oldestTime"] = 1632846350,
                ["wasAltered"] = true,
                ["newestTime"] = 1632846350,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2199,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1632846350,
                        ["quant"] = 1,
                        ["id"] = "1689113251",
                        ["itemLink"] = 3197,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [180486] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_light_hands_a.dds",
                ["itemDesc"] = "Gloves of Dark Convergence",
                ["oldestTime"] = 1633231996,
                ["wasAltered"] = true,
                ["newestTime"] = 1633231996,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1701,
                        ["wasKiosk"] = true,
                        ["seller"] = 42,
                        ["timestamp"] = 1633231996,
                        ["quant"] = 1,
                        ["id"] = "1692134933",
                        ["itemLink"] = 2445,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set dark convergence hands well-fitted",
            },
        },
        [30141] = 
        {
            ["50:15:1:9:983040"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/consumable_potion_013_type_005.dds",
                ["itemDesc"] = "Essence of Spell Critical",
                ["oldestTime"] = 1633293215,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293215,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 23400,
                        ["guild"] = 1,
                        ["buyer"] = 1998,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1633293215,
                        ["quant"] = 104,
                        ["id"] = "1692665911",
                        ["itemLink"] = 2851,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 white normal consumable potion",
            },
        },
        [124666] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/fragment_pet_sentry_chasis.dds",
                ["itemDesc"] = "Dwarven Theodolite Chassis",
                ["oldestTime"] = 1632835092,
                ["wasAltered"] = true,
                ["newestTime"] = 1632835092,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 366,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1632835092,
                        ["quant"] = 1,
                        ["id"] = "1689028073",
                        ["itemLink"] = 3099,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [57023] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Colovian Amber Ale",
                ["oldestTime"] = 1632923725,
                ["wasAltered"] = true,
                ["newestTime"] = 1632923725,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632923725,
                        ["quant"] = 1,
                        ["id"] = "1689677423",
                        ["itemLink"] = 3673,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [115392] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_nor_inc_tapestry002.dds",
                ["itemDesc"] = "Nord Tapestry, Dragon",
                ["oldestTime"] = 1633282358,
                ["wasAltered"] = true,
                ["newestTime"] = 1633282358,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6238,
                        ["guild"] = 1,
                        ["buyer"] = 1938,
                        ["wasKiosk"] = true,
                        ["seller"] = 99,
                        ["timestamp"] = 1633282358,
                        ["quant"] = 1,
                        ["id"] = "1692539639",
                        ["itemLink"] = 2741,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings parlor",
            },
        },
        [117847] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_fur_sofapillowcylinder001.dds",
                ["itemDesc"] = "Redguard Pillow Roll, Desert Flame",
                ["oldestTime"] = 1633304083,
                ["wasAltered"] = true,
                ["newestTime"] = 1633304083,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20522,
                        ["guild"] = 1,
                        ["buyer"] = 744,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1633304083,
                        ["quant"] = 2,
                        ["id"] = "1692780709",
                        ["itemLink"] = 2922,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings suite",
            },
        },
        [171970] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_waist_a.dds",
                ["itemDesc"] = "Sash of Frostbite",
                ["oldestTime"] = 1633182298,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182298,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 775,
                        ["guild"] = 1,
                        ["buyer"] = 1377,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633182298,
                        ["quant"] = 1,
                        ["id"] = "1691606461",
                        ["itemLink"] = 1942,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite waist infused",
            },
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_waist_a.dds",
                ["itemDesc"] = "Sash of Frostbite",
                ["oldestTime"] = 1633045829,
                ["wasAltered"] = true,
                ["newestTime"] = 1633045829,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 674,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633045829,
                        ["quant"] = 1,
                        ["id"] = "1690564839",
                        ["itemLink"] = 856,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set frostbite waist infused",
            },
        },
        [45872] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_increasebashdamage.dds",
                ["itemDesc"] = "Superb Glyph of Bashing",
                ["oldestTime"] = 1633298996,
                ["wasAltered"] = true,
                ["newestTime"] = 1633298996,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633298996,
                        ["quant"] = 1,
                        ["id"] = "1692731207",
                        ["itemLink"] = 2906,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 green fine miscellaneous jewelry glyph",
            },
        },
        [176324] = 
        {
            ["1:0:3:36:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_lightningstaff.dds",
                ["itemDesc"] = "Companion's Lightning Staff",
                ["oldestTime"] = 1633154755,
                ["wasAltered"] = true,
                ["newestTime"] = 1633154755,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 380,
                        ["guild"] = 1,
                        ["buyer"] = 1275,
                        ["wasKiosk"] = true,
                        ["seller"] = 177,
                        ["timestamp"] = 1633154755,
                        ["quant"] = 1,
                        ["id"] = "1691429375",
                        ["itemLink"] = 1742,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior weapon lightning staff two-handed focused",
            },
        },
        [139216] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_fur_bedsimple001.dds",
                ["itemDesc"] = "Alinor Bed, Polished Single",
                ["oldestTime"] = 1633294693,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294693,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 2012,
                        ["wasKiosk"] = true,
                        ["seller"] = 323,
                        ["timestamp"] = 1633294693,
                        ["quant"] = 2,
                        ["id"] = "1692686293",
                        ["itemLink"] = 2868,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings suite",
            },
        },
        [176033] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing3.dds",
                ["itemDesc"] = "Diagram: Deadlands Brazier, Bladed",
                ["oldestTime"] = 1633289477,
                ["wasAltered"] = true,
                ["newestTime"] = 1633289477,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4750,
                        ["guild"] = 1,
                        ["buyer"] = 202,
                        ["wasKiosk"] = false,
                        ["seller"] = 48,
                        ["timestamp"] = 1633289477,
                        ["quant"] = 1,
                        ["id"] = "1692621193",
                        ["itemLink"] = 2777,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [30151] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_mushroom_emetic_russula_r1.dds",
                ["itemDesc"] = "Emetic Russula",
                ["oldestTime"] = 1632912833,
                ["wasAltered"] = true,
                ["newestTime"] = 1633282743,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1941,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1633282743,
                        ["quant"] = 45,
                        ["id"] = "1692544375",
                        ["itemLink"] = 2746,
                    },
                    [2] = 
                    {
                        ["price"] = 32600,
                        ["guild"] = 1,
                        ["buyer"] = 2470,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1632912833,
                        ["quant"] = 200,
                        ["id"] = "1689611503",
                        ["itemLink"] = 2746,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [30152] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_mushroom_violet_coprinus_r1.dds",
                ["itemDesc"] = "Violet Coprinus",
                ["oldestTime"] = 1632829461,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292662,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10542,
                        ["guild"] = 1,
                        ["buyer"] = 825,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633066531,
                        ["quant"] = 21,
                        ["id"] = "1690759085",
                        ["itemLink"] = 1068,
                    },
                    [2] = 
                    {
                        ["price"] = 120200,
                        ["guild"] = 1,
                        ["buyer"] = 1002,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633128300,
                        ["quant"] = 200,
                        ["id"] = "1691169369",
                        ["itemLink"] = 1068,
                    },
                    [3] = 
                    {
                        ["price"] = 122000,
                        ["guild"] = 1,
                        ["buyer"] = 1396,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633186324,
                        ["quant"] = 200,
                        ["id"] = "1691643857",
                        ["itemLink"] = 1068,
                    },
                    [4] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1789,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633244451,
                        ["quant"] = 3,
                        ["id"] = "1692229119",
                        ["itemLink"] = 1068,
                    },
                    [5] = 
                    {
                        ["price"] = 69999,
                        ["guild"] = 1,
                        ["buyer"] = 1993,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633292662,
                        ["quant"] = 100,
                        ["id"] = "1692660023",
                        ["itemLink"] = 1068,
                    },
                    [6] = 
                    {
                        ["price"] = 16250,
                        ["guild"] = 1,
                        ["buyer"] = 2128,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632829461,
                        ["quant"] = 25,
                        ["id"] = "1688995639",
                        ["itemLink"] = 1068,
                    },
                    [7] = 
                    {
                        ["price"] = 5522,
                        ["guild"] = 1,
                        ["buyer"] = 2151,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632835228,
                        ["quant"] = 11,
                        ["id"] = "1689028831",
                        ["itemLink"] = 1068,
                    },
                    [8] = 
                    {
                        ["price"] = 123600,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 9,
                        ["timestamp"] = 1632844598,
                        ["quant"] = 200,
                        ["id"] = "1689095911",
                        ["itemLink"] = 1068,
                    },
                    [9] = 
                    {
                        ["price"] = 2008,
                        ["guild"] = 1,
                        ["buyer"] = 2611,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632955596,
                        ["quant"] = 4,
                        ["id"] = "1689923817",
                        ["itemLink"] = 1068,
                    },
                },
                ["totalCount"] = 9,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [165611] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_fur_vampirearmoire002.dds",
                ["itemDesc"] = "Vampiric Cabinet, Ornate",
                ["oldestTime"] = 1632839475,
                ["wasAltered"] = true,
                ["newestTime"] = 1633253677,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 1825,
                        ["wasKiosk"] = true,
                        ["seller"] = 6,
                        ["timestamp"] = 1633253677,
                        ["quant"] = 1,
                        ["id"] = "1692294885",
                        ["itemLink"] = 2611,
                    },
                    [2] = 
                    {
                        ["price"] = 29500,
                        ["guild"] = 1,
                        ["buyer"] = 2171,
                        ["wasKiosk"] = true,
                        ["seller"] = 6,
                        ["timestamp"] = 1632839475,
                        ["quant"] = 1,
                        ["id"] = "1689056927",
                        ["itemLink"] = 2611,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings hearth",
            },
        },
        [176002] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_jewelry_3.dds",
                ["itemDesc"] = "Sketch: Leyawiin Hand Mirror, Lacquered",
                ["oldestTime"] = 1632862526,
                ["wasAltered"] = true,
                ["newestTime"] = 1633147947,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 171,
                        ["timestamp"] = 1633060364,
                        ["quant"] = 1,
                        ["id"] = "1690713393",
                        ["itemLink"] = 1009,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 630,
                        ["wasKiosk"] = true,
                        ["seller"] = 48,
                        ["timestamp"] = 1633147947,
                        ["quant"] = 1,
                        ["id"] = "1691373449",
                        ["itemLink"] = 1009,
                    },
                    [3] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2251,
                        ["wasKiosk"] = true,
                        ["seller"] = 100,
                        ["timestamp"] = 1632862526,
                        ["quant"] = 1,
                        ["id"] = "1689248363",
                        ["itemLink"] = 1009,
                    },
                    [4] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 2046,
                        ["wasKiosk"] = true,
                        ["seller"] = 100,
                        ["timestamp"] = 1632964849,
                        ["quant"] = 1,
                        ["id"] = "1690005159",
                        ["itemLink"] = 1009,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [156619] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 81: New Moon Priest Shields",
                ["oldestTime"] = 1632992058,
                ["wasAltered"] = true,
                ["newestTime"] = 1633216011,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1995,
                        ["guild"] = 1,
                        ["buyer"] = 359,
                        ["wasKiosk"] = true,
                        ["seller"] = 322,
                        ["timestamp"] = 1632992058,
                        ["quant"] = 1,
                        ["id"] = "1690196521",
                        ["itemLink"] = 359,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 327,
                        ["wasKiosk"] = false,
                        ["seller"] = 971,
                        ["timestamp"] = 1633216011,
                        ["quant"] = 1,
                        ["id"] = "1691968673",
                        ["itemLink"] = 359,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45062] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ashlanderv_heavy_hands_a.dds",
                ["itemDesc"] = "Rubedite Gauntlets of Health",
                ["oldestTime"] = 1632976080,
                ["wasAltered"] = true,
                ["newestTime"] = 1632976080,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 90,
                        ["guild"] = 1,
                        ["buyer"] = 221,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632976080,
                        ["quant"] = 1,
                        ["id"] = "1690103375",
                        ["itemLink"] = 236,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel hands impenetrable",
            },
        },
        [172237] = 
        {
            ["50:16:2:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_feet_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Boots",
                ["oldestTime"] = 1632851021,
                ["wasAltered"] = true,
                ["newestTime"] = 1633225777,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1645,
                        ["wasKiosk"] = true,
                        ["seller"] = 1417,
                        ["timestamp"] = 1633225777,
                        ["quant"] = 1,
                        ["id"] = "1692072027",
                        ["itemLink"] = 2391,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2217,
                        ["wasKiosk"] = true,
                        ["seller"] = 530,
                        ["timestamp"] = 1632851021,
                        ["quant"] = 1,
                        ["id"] = "1689152123",
                        ["itemLink"] = 2391,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine medium apparel set deadlands assassin feet invigorating",
            },
        },
        [114894] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_furniture_base_decorative_wax.dds",
                ["itemDesc"] = "Decorative Wax",
                ["oldestTime"] = 1632520208,
                ["wasAltered"] = true,
                ["newestTime"] = 1633315826,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3331,
                        ["guild"] = 1,
                        ["buyer"] = 74,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633314508,
                        ["quant"] = 5,
                        ["id"] = "1692896609",
                        ["itemLink"] = 60,
                    },
                    [2] = 
                    {
                        ["price"] = 143200,
                        ["guild"] = 1,
                        ["buyer"] = 76,
                        ["wasKiosk"] = false,
                        ["seller"] = 9,
                        ["timestamp"] = 1633315826,
                        ["quant"] = 200,
                        ["id"] = "1692913071",
                        ["itemLink"] = 60,
                    },
                    [3] = 
                    {
                        ["price"] = 11500,
                        ["guild"] = 2,
                        ["buyer"] = 114,
                        ["wasKiosk"] = false,
                        ["seller"] = 118,
                        ["timestamp"] = 1632520208,
                        ["quant"] = 20,
                        ["id"] = "1686355179",
                        ["itemLink"] = 60,
                    },
                    [4] = 
                    {
                        ["price"] = 7351,
                        ["guild"] = 1,
                        ["buyer"] = 73,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1632989397,
                        ["quant"] = 11,
                        ["id"] = "1690183167",
                        ["itemLink"] = 60,
                    },
                    [5] = 
                    {
                        ["price"] = 19000,
                        ["guild"] = 1,
                        ["buyer"] = 592,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633035115,
                        ["quant"] = 27,
                        ["id"] = "1690476717",
                        ["itemLink"] = 60,
                    },
                    [6] = 
                    {
                        ["price"] = 150000,
                        ["guild"] = 1,
                        ["buyer"] = 592,
                        ["wasKiosk"] = true,
                        ["seller"] = 593,
                        ["timestamp"] = 1633035122,
                        ["quant"] = 200,
                        ["id"] = "1690476825",
                        ["itemLink"] = 60,
                    },
                    [7] = 
                    {
                        ["price"] = 765,
                        ["guild"] = 1,
                        ["buyer"] = 657,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633043465,
                        ["quant"] = 1,
                        ["id"] = "1690541443",
                        ["itemLink"] = 60,
                    },
                    [8] = 
                    {
                        ["price"] = 765,
                        ["guild"] = 1,
                        ["buyer"] = 657,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633043465,
                        ["quant"] = 1,
                        ["id"] = "1690541447",
                        ["itemLink"] = 60,
                    },
                    [9] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 708,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633052054,
                        ["quant"] = 10,
                        ["id"] = "1690626561",
                        ["itemLink"] = 60,
                    },
                    [10] = 
                    {
                        ["price"] = 75300,
                        ["guild"] = 1,
                        ["buyer"] = 779,
                        ["wasKiosk"] = true,
                        ["seller"] = 334,
                        ["timestamp"] = 1633058782,
                        ["quant"] = 100,
                        ["id"] = "1690698477",
                        ["itemLink"] = 60,
                    },
                    [11] = 
                    {
                        ["price"] = 18900,
                        ["guild"] = 1,
                        ["buyer"] = 779,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633058785,
                        ["quant"] = 27,
                        ["id"] = "1690698527",
                        ["itemLink"] = 60,
                    },
                    [12] = 
                    {
                        ["price"] = 4626,
                        ["guild"] = 1,
                        ["buyer"] = 779,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633058787,
                        ["quant"] = 7,
                        ["id"] = "1690698551",
                        ["itemLink"] = 60,
                    },
                    [13] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 779,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633058793,
                        ["quant"] = 1,
                        ["id"] = "1690698615",
                        ["itemLink"] = 60,
                    },
                    [14] = 
                    {
                        ["price"] = 25160,
                        ["guild"] = 1,
                        ["buyer"] = 1202,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633142551,
                        ["quant"] = 34,
                        ["id"] = "1691320653",
                        ["itemLink"] = 60,
                    },
                    [15] = 
                    {
                        ["price"] = 5984,
                        ["guild"] = 1,
                        ["buyer"] = 507,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633162073,
                        ["quant"] = 9,
                        ["id"] = "1691476691",
                        ["itemLink"] = 60,
                    },
                    [16] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 1315,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633164279,
                        ["quant"] = 50,
                        ["id"] = "1691492165",
                        ["itemLink"] = 60,
                    },
                    [17] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 1315,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633164279,
                        ["quant"] = 50,
                        ["id"] = "1691492169",
                        ["itemLink"] = 60,
                    },
                    [18] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 1315,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633164280,
                        ["quant"] = 50,
                        ["id"] = "1691492175",
                        ["itemLink"] = 60,
                    },
                    [19] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 1315,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633164281,
                        ["quant"] = 50,
                        ["id"] = "1691492179",
                        ["itemLink"] = 60,
                    },
                    [20] = 
                    {
                        ["price"] = 3302,
                        ["guild"] = 1,
                        ["buyer"] = 1670,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633228687,
                        ["quant"] = 5,
                        ["id"] = "1692104121",
                        ["itemLink"] = 60,
                    },
                    [21] = 
                    {
                        ["price"] = 56000,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 95,
                        ["timestamp"] = 1633231787,
                        ["quant"] = 80,
                        ["id"] = "1692133193",
                        ["itemLink"] = 60,
                    },
                    [22] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 1768,
                        ["wasKiosk"] = true,
                        ["seller"] = 911,
                        ["timestamp"] = 1633240258,
                        ["quant"] = 100,
                        ["id"] = "1692199267",
                        ["itemLink"] = 60,
                    },
                    [23] = 
                    {
                        ["price"] = 180000,
                        ["guild"] = 1,
                        ["buyer"] = 1796,
                        ["wasKiosk"] = true,
                        ["seller"] = 41,
                        ["timestamp"] = 1633245428,
                        ["quant"] = 200,
                        ["id"] = "1692236629",
                        ["itemLink"] = 60,
                    },
                    [24] = 
                    {
                        ["price"] = 200000,
                        ["guild"] = 1,
                        ["buyer"] = 1796,
                        ["wasKiosk"] = true,
                        ["seller"] = 255,
                        ["timestamp"] = 1633245436,
                        ["quant"] = 200,
                        ["id"] = "1692236705",
                        ["itemLink"] = 60,
                    },
                    [25] = 
                    {
                        ["price"] = 200000,
                        ["guild"] = 1,
                        ["buyer"] = 1796,
                        ["wasKiosk"] = true,
                        ["seller"] = 255,
                        ["timestamp"] = 1633245458,
                        ["quant"] = 200,
                        ["id"] = "1692236939",
                        ["itemLink"] = 60,
                    },
                    [26] = 
                    {
                        ["price"] = 5180,
                        ["guild"] = 1,
                        ["buyer"] = 428,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633292387,
                        ["quant"] = 7,
                        ["id"] = "1692656139",
                        ["itemLink"] = 60,
                    },
                    [27] = 
                    {
                        ["price"] = 6050,
                        ["guild"] = 1,
                        ["buyer"] = 204,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632818466,
                        ["quant"] = 9,
                        ["id"] = "1688937505",
                        ["itemLink"] = 60,
                    },
                    [28] = 
                    {
                        ["price"] = 7645,
                        ["guild"] = 1,
                        ["buyer"] = 428,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1632828087,
                        ["quant"] = 11,
                        ["id"] = "1688983665",
                        ["itemLink"] = 60,
                    },
                    [29] = 
                    {
                        ["price"] = 20445,
                        ["guild"] = 1,
                        ["buyer"] = 428,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632828092,
                        ["quant"] = 29,
                        ["id"] = "1688983737",
                        ["itemLink"] = 60,
                    },
                    [30] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 2198,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1632846246,
                        ["quant"] = 8,
                        ["id"] = "1689112587",
                        ["itemLink"] = 60,
                    },
                    [31] = 
                    {
                        ["price"] = 3986,
                        ["guild"] = 1,
                        ["buyer"] = 2271,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632866670,
                        ["quant"] = 6,
                        ["id"] = "1689279249",
                        ["itemLink"] = 60,
                    },
                    [32] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 2292,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632871527,
                        ["quant"] = 10,
                        ["id"] = "1689312979",
                        ["itemLink"] = 60,
                    },
                    [33] = 
                    {
                        ["price"] = 11100,
                        ["guild"] = 1,
                        ["buyer"] = 2093,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1632966102,
                        ["quant"] = 15,
                        ["id"] = "1690016291",
                        ["itemLink"] = 60,
                    },
                    [34] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 2093,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1632966103,
                        ["quant"] = 16,
                        ["id"] = "1690016301",
                        ["itemLink"] = 60,
                    },
                },
                ["totalCount"] = 34,
                ["itemAdderText"] = "rr01 white normal materials furnishing",
            },
        },
        [116175] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Nord Chair, Braced",
                ["oldestTime"] = 1633240438,
                ["wasAltered"] = true,
                ["newestTime"] = 1633240438,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4700,
                        ["guild"] = 1,
                        ["buyer"] = 1772,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633240438,
                        ["quant"] = 1,
                        ["id"] = "1692201143",
                        ["itemLink"] = 2532,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [151760] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_inc_tapestry003.dds",
                ["itemDesc"] = "Elsweyr Tapestry, Verdant Blossom",
                ["oldestTime"] = 1632879589,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238217,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6200,
                        ["guild"] = 1,
                        ["buyer"] = 1745,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633238217,
                        ["quant"] = 1,
                        ["id"] = "1692186981",
                        ["itemLink"] = 2509,
                    },
                    [2] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2349,
                        ["wasKiosk"] = true,
                        ["seller"] = 6,
                        ["timestamp"] = 1632879589,
                        ["quant"] = 1,
                        ["id"] = "1689392315",
                        ["itemLink"] = 2509,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior furnishings parlor",
            },
        },
        [180904] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_heavy_legs_a.dds",
                ["itemDesc"] = "Hrothgar's Greaves",
                ["oldestTime"] = 1633186485,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186485,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3471,
                        ["guild"] = 1,
                        ["buyer"] = 464,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633186485,
                        ["quant"] = 1,
                        ["id"] = "1691646821",
                        ["itemLink"] = 2073,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set hrothgar's chill legs sturdy",
            },
        },
        [30162] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_forester_potion_sp_names_002.dds",
                ["itemDesc"] = "Dragonthorn",
                ["oldestTime"] = 1632830248,
                ["wasAltered"] = true,
                ["newestTime"] = 1633308474,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3366,
                        ["guild"] = 1,
                        ["buyer"] = 278,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632981539,
                        ["quant"] = 34,
                        ["id"] = "1690139465",
                        ["itemLink"] = 288,
                    },
                    [2] = 
                    {
                        ["price"] = 9500,
                        ["guild"] = 1,
                        ["buyer"] = 919,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1633090588,
                        ["quant"] = 100,
                        ["id"] = "1690892051",
                        ["itemLink"] = 288,
                    },
                    [3] = 
                    {
                        ["price"] = 19740,
                        ["guild"] = 1,
                        ["buyer"] = 976,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633109121,
                        ["quant"] = 200,
                        ["id"] = "1691029947",
                        ["itemLink"] = 288,
                    },
                    [4] = 
                    {
                        ["price"] = 4240,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633154447,
                        ["quant"] = 53,
                        ["id"] = "1691427257",
                        ["itemLink"] = 288,
                    },
                    [5] = 
                    {
                        ["price"] = 386,
                        ["guild"] = 1,
                        ["buyer"] = 1350,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633175160,
                        ["quant"] = 4,
                        ["id"] = "1691547597",
                        ["itemLink"] = 288,
                    },
                    [6] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 2077,
                        ["wasKiosk"] = true,
                        ["seller"] = 327,
                        ["timestamp"] = 1633308473,
                        ["quant"] = 200,
                        ["id"] = "1692828277",
                        ["itemLink"] = 288,
                    },
                    [7] = 
                    {
                        ["price"] = 21000,
                        ["guild"] = 1,
                        ["buyer"] = 2077,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1633308474,
                        ["quant"] = 200,
                        ["id"] = "1692828287",
                        ["itemLink"] = 288,
                    },
                    [8] = 
                    {
                        ["price"] = 10028,
                        ["guild"] = 1,
                        ["buyer"] = 2132,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1632830248,
                        ["quant"] = 100,
                        ["id"] = "1688999719",
                        ["itemLink"] = 288,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [176595] = 
        {
            ["1:0:3:47:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_shoulders_heavy.dds",
                ["itemDesc"] = "Companion's Pauldrons",
                ["oldestTime"] = 1632974303,
                ["wasAltered"] = true,
                ["newestTime"] = 1632974303,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 203,
                        ["wasKiosk"] = true,
                        ["seller"] = 8,
                        ["timestamp"] = 1632974303,
                        ["quant"] = 1,
                        ["id"] = "1690091787",
                        ["itemLink"] = 215,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior heavy apparel shoulders aggressive",
            },
        },
        [96980] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_medium_feet_a.dds",
                ["itemDesc"] = "Boots of the Night Mother",
                ["oldestTime"] = 1632973989,
                ["wasAltered"] = true,
                ["newestTime"] = 1632973989,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 198,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1632973989,
                        ["quant"] = 1,
                        ["id"] = "1690090067",
                        ["itemLink"] = 208,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set night mother's embrace feet divines",
            },
        },
        [171477] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/container_sealed_polymorph_001.dds",
                ["itemDesc"] = "Runebox: Slag Town Diver",
                ["oldestTime"] = 1632836137,
                ["wasAltered"] = true,
                ["newestTime"] = 1633189285,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1410,
                        ["wasKiosk"] = true,
                        ["seller"] = 1411,
                        ["timestamp"] = 1633189285,
                        ["quant"] = 1,
                        ["id"] = "1691681001",
                        ["itemLink"] = 2091,
                    },
                    [2] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 2157,
                        ["wasKiosk"] = true,
                        ["seller"] = 1411,
                        ["timestamp"] = 1632836137,
                        ["quant"] = 1,
                        ["id"] = "1689034877",
                        ["itemLink"] = 2091,
                    },
                    [3] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 2418,
                        ["wasKiosk"] = true,
                        ["seller"] = 1411,
                        ["timestamp"] = 1632892244,
                        ["quant"] = 1,
                        ["id"] = "1689510553",
                        ["itemLink"] = 2091,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 gold legendary consumable container",
            },
        },
        [172345] = 
        {
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_hvy_legs_a.dds",
                ["itemDesc"] = "Bog Raider's Greaves",
                ["oldestTime"] = 1633277710,
                ["wasAltered"] = true,
                ["newestTime"] = 1633277710,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 1897,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633277710,
                        ["quant"] = 1,
                        ["id"] = "1692492793",
                        ["itemLink"] = 2710,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set bog raider legs well-fitted",
            },
        },
        [26583] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_magickaregen.dds",
                ["itemDesc"] = "Superb Glyph of Magicka Recovery",
                ["oldestTime"] = 1633297969,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297969,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 227,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633297969,
                        ["quant"] = 1,
                        ["id"] = "1692720489",
                        ["itemLink"] = 2899,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 green fine miscellaneous jewelry glyph",
            },
            ["48:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_magickaregen.dds",
                ["itemDesc"] = "Strong Glyph of Magicka Recovery",
                ["oldestTime"] = 1633251488,
                ["wasAltered"] = true,
                ["newestTime"] = 1633251489,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1633251488,
                        ["quant"] = 1,
                        ["id"] = "1692280633",
                        ["itemLink"] = 2601,
                    },
                    [2] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1633251489,
                        ["quant"] = 1,
                        ["id"] = "1692280637",
                        ["itemLink"] = 2601,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr48 purple epic miscellaneous jewelry glyph",
            },
            ["50:16:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_magickaregen.dds",
                ["itemDesc"] = "Truly Superb Glyph of Magicka Recovery",
                ["oldestTime"] = 1633251492,
                ["wasAltered"] = true,
                ["newestTime"] = 1633251492,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 92,
                        ["timestamp"] = 1633251492,
                        ["quant"] = 1,
                        ["id"] = "1692280657",
                        ["itemLink"] = 2605,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic miscellaneous jewelry glyph",
            },
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_magickaregen.dds",
                ["itemDesc"] = "Truly Superb Glyph of Magicka Recovery",
                ["oldestTime"] = 1633122318,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305181,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6300,
                        ["guild"] = 1,
                        ["buyer"] = 158,
                        ["wasKiosk"] = false,
                        ["seller"] = 173,
                        ["timestamp"] = 1633122318,
                        ["quant"] = 1,
                        ["id"] = "1691121707",
                        ["itemLink"] = 1446,
                    },
                    [2] = 
                    {
                        ["price"] = 6300,
                        ["guild"] = 1,
                        ["buyer"] = 1137,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633135052,
                        ["quant"] = 1,
                        ["id"] = "1691242299",
                        ["itemLink"] = 1446,
                    },
                    [3] = 
                    {
                        ["price"] = 6200,
                        ["guild"] = 1,
                        ["buyer"] = 1916,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633278693,
                        ["quant"] = 1,
                        ["id"] = "1692502265",
                        ["itemLink"] = 1446,
                    },
                    [4] = 
                    {
                        ["price"] = 6200,
                        ["guild"] = 1,
                        ["buyer"] = 1948,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633284408,
                        ["quant"] = 1,
                        ["id"] = "1692559679",
                        ["itemLink"] = 1446,
                    },
                    [5] = 
                    {
                        ["price"] = 6100,
                        ["guild"] = 1,
                        ["buyer"] = 2063,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633305181,
                        ["quant"] = 1,
                        ["id"] = "1692791747",
                        ["itemLink"] = 1446,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous jewelry glyph",
            },
        },
        [130008] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 51: Hlaalu Swords",
                ["oldestTime"] = 1632951354,
                ["wasAltered"] = true,
                ["newestTime"] = 1633164793,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 1214,
                        ["timestamp"] = 1633164793,
                        ["quant"] = 1,
                        ["id"] = "1691495031",
                        ["itemLink"] = 1832,
                    },
                    [2] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 2590,
                        ["wasKiosk"] = true,
                        ["seller"] = 624,
                        ["timestamp"] = 1632951354,
                        ["quant"] = 1,
                        ["id"] = "1689885639",
                        ["itemLink"] = 1832,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [43661] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Deshaan Treasure Map I",
                ["oldestTime"] = 1632858420,
                ["wasAltered"] = true,
                ["newestTime"] = 1633131976,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1117,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1633131976,
                        ["quant"] = 1,
                        ["id"] = "1691207885",
                        ["itemLink"] = 1541,
                    },
                    [2] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 733,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1632858420,
                        ["quant"] = 1,
                        ["id"] = "1689218619",
                        ["itemLink"] = 1541,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [129776] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_heavy_feet_a.dds",
                ["itemDesc"] = "Sabatons of the Pariah",
                ["oldestTime"] = 1633113185,
                ["wasAltered"] = true,
                ["newestTime"] = 1633213734,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 998,
                        ["wasKiosk"] = true,
                        ["seller"] = 100,
                        ["timestamp"] = 1633113185,
                        ["quant"] = 1,
                        ["id"] = "1691059391",
                        ["itemLink"] = 1361,
                    },
                    [2] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1564,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633213734,
                        ["quant"] = 1,
                        ["id"] = "1691947077",
                        ["itemLink"] = 1361,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set mark of the pariah feet impenetrable",
            },
        },
        [102107] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_draugr_medium_feet_a.dds",
                ["itemDesc"] = "Stygian Boots",
                ["oldestTime"] = 1633283658,
                ["wasAltered"] = true,
                ["newestTime"] = 1633283658,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 1946,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633283658,
                        ["quant"] = 1,
                        ["id"] = "1692552719",
                        ["itemLink"] = 2750,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set stygian feet divines",
            },
        },
        [156636] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 80: Shield of Senchal Legs",
                ["oldestTime"] = 1633009110,
                ["wasAltered"] = true,
                ["newestTime"] = 1633009110,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 17900,
                        ["guild"] = 1,
                        ["buyer"] = 439,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633009110,
                        ["quant"] = 1,
                        ["id"] = "1690283415",
                        ["itemLink"] = 451,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [26589] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_staminaregen.dds",
                ["itemDesc"] = "Superb Glyph of Stamina Recovery",
                ["oldestTime"] = 1633186106,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186106,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 105,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633186106,
                        ["quant"] = 1,
                        ["id"] = "1691641889",
                        ["itemLink"] = 2069,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 green fine miscellaneous jewelry glyph",
            },
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_staminaregen.dds",
                ["itemDesc"] = "Truly Superb Glyph of Stamina Recovery",
                ["oldestTime"] = 1632826778,
                ["wasAltered"] = true,
                ["newestTime"] = 1633284404,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6200,
                        ["guild"] = 1,
                        ["buyer"] = 209,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633187493,
                        ["quant"] = 1,
                        ["id"] = "1691657205",
                        ["itemLink"] = 2081,
                    },
                    [2] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 1453,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633195836,
                        ["quant"] = 1,
                        ["id"] = "1691749235",
                        ["itemLink"] = 2081,
                    },
                    [3] = 
                    {
                        ["price"] = 6300,
                        ["guild"] = 1,
                        ["buyer"] = 1742,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633237467,
                        ["quant"] = 1,
                        ["id"] = "1692180629",
                        ["itemLink"] = 2081,
                    },
                    [4] = 
                    {
                        ["price"] = 6300,
                        ["guild"] = 1,
                        ["buyer"] = 1948,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633284404,
                        ["quant"] = 1,
                        ["id"] = "1692559627",
                        ["itemLink"] = 2081,
                    },
                    [5] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 2121,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632826778,
                        ["quant"] = 1,
                        ["id"] = "1688973813",
                        ["itemLink"] = 2081,
                    },
                    [6] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 2121,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632826779,
                        ["quant"] = 1,
                        ["id"] = "1688973817",
                        ["itemLink"] = 2081,
                    },
                    [7] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 2121,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632826780,
                        ["quant"] = 1,
                        ["id"] = "1688973831",
                        ["itemLink"] = 2081,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous jewelry glyph",
            },
        },
        [139540] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Alinor Bed, Polished Full",
                ["oldestTime"] = 1633056369,
                ["wasAltered"] = true,
                ["newestTime"] = 1633056369,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 149999,
                        ["guild"] = 1,
                        ["buyer"] = 747,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1633056369,
                        ["quant"] = 1,
                        ["id"] = "1690668897",
                        ["itemLink"] = 956,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [176607] = 
        {
            ["1:0:3:38:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_bow.dds",
                ["itemDesc"] = "Companion's Bow",
                ["oldestTime"] = 1633294640,
                ["wasAltered"] = true,
                ["newestTime"] = 1633314687,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 85,
                        ["wasKiosk"] = true,
                        ["seller"] = 86,
                        ["timestamp"] = 1633314687,
                        ["quant"] = 1,
                        ["id"] = "1692898591",
                        ["itemLink"] = 63,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2010,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633294640,
                        ["quant"] = 1,
                        ["id"] = "1692685575",
                        ["itemLink"] = 63,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior weapon bow two-handed aggressive",
            },
        },
        [45162] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_2hhammer_d.dds",
                ["itemDesc"] = "Rubedite Maul of Frost",
                ["oldestTime"] = 1633240316,
                ["wasAltered"] = true,
                ["newestTime"] = 1633240316,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1771,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633240316,
                        ["quant"] = 1,
                        ["id"] = "1692199963",
                        ["itemLink"] = 2528,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon mace two-handed defending",
            },
            ["50:16:1:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_2hhammer_d.dds",
                ["itemDesc"] = "Rubedite Maul",
                ["oldestTime"] = 1632918538,
                ["wasAltered"] = true,
                ["newestTime"] = 1632918538,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 228,
                        ["guild"] = 1,
                        ["buyer"] = 274,
                        ["wasKiosk"] = false,
                        ["seller"] = 240,
                        ["timestamp"] = 1632918538,
                        ["quant"] = 1,
                        ["id"] = "1689643177",
                        ["itemLink"] = 3643,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal weapon mace two-handed defending",
            },
        },
        [172257] = 
        {
            ["50:16:2:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_feet_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Boots",
                ["oldestTime"] = 1633187613,
                ["wasAltered"] = true,
                ["newestTime"] = 1633187613,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1403,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633187613,
                        ["quant"] = 1,
                        ["id"] = "1691658937",
                        ["itemLink"] = 2082,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set deadlands assassin feet sturdy",
            },
        },
        [56055] = 
        {
            ["1:0:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_medium_hands_a.dds",
                ["itemDesc"] = "Rawhide Bracers",
                ["oldestTime"] = 1633125831,
                ["wasAltered"] = true,
                ["newestTime"] = 1633250943,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1083,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633125831,
                        ["quant"] = 1,
                        ["id"] = "1691148607",
                        ["itemLink"] = 1480,
                    },
                    [2] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1231,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633146300,
                        ["quant"] = 1,
                        ["id"] = "1691359547",
                        ["itemLink"] = 1480,
                    },
                    [3] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1819,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633250943,
                        ["quant"] = 1,
                        ["id"] = "1692277065",
                        ["itemLink"] = 1480,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal medium apparel hands nirnhoned",
            },
        },
        [130002] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 51: Hlaalu Helmets",
                ["oldestTime"] = 1633150015,
                ["wasAltered"] = true,
                ["newestTime"] = 1633150015,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 1254,
                        ["wasKiosk"] = true,
                        ["seller"] = 1214,
                        ["timestamp"] = 1633150015,
                        ["quant"] = 1,
                        ["id"] = "1691391185",
                        ["itemLink"] = 1714,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [176612] = 
        {
            ["1:0:3:38:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_lightningstaff.dds",
                ["itemDesc"] = "Companion's Lightning Staff",
                ["oldestTime"] = 1633075414,
                ["wasAltered"] = true,
                ["newestTime"] = 1633075414,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 864,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633075414,
                        ["quant"] = 1,
                        ["id"] = "1690812891",
                        ["itemLink"] = 1110,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior weapon lightning staff two-handed aggressive",
            },
        },
        [180591] = 
        {
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_light_hands_a.dds",
                ["itemDesc"] = "Gloves of Dark Convergence",
                ["oldestTime"] = 1633233583,
                ["wasAltered"] = true,
                ["newestTime"] = 1633233583,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1528,
                        ["wasKiosk"] = true,
                        ["seller"] = 42,
                        ["timestamp"] = 1633233583,
                        ["quant"] = 1,
                        ["id"] = "1692150355",
                        ["itemLink"] = 2458,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set dark convergence hands training",
            },
        },
        [165606] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_fur_vampiremirrorwall001.dds",
                ["itemDesc"] = "Vampiric Wall Mirror",
                ["oldestTime"] = 1632841033,
                ["wasAltered"] = true,
                ["newestTime"] = 1632841033,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40174,
                        ["guild"] = 1,
                        ["buyer"] = 2171,
                        ["wasKiosk"] = true,
                        ["seller"] = 712,
                        ["timestamp"] = 1632841033,
                        ["quant"] = 2,
                        ["id"] = "1689067361",
                        ["itemLink"] = 3150,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings suite",
            },
        },
        [126960] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Dres Divider, Chains",
                ["oldestTime"] = 1633227776,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227776,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 521,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633227776,
                        ["quant"] = 1,
                        ["id"] = "1692093583",
                        ["itemLink"] = 2416,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [127038] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Indoril Runner, Sotha Sil",
                ["oldestTime"] = 1633227098,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227098,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 1657,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633227098,
                        ["quant"] = 1,
                        ["id"] = "1692086167",
                        ["itemLink"] = 2403,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [97001] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_medium_feet_a.dds",
                ["itemDesc"] = "Boots of the Night Mother",
                ["oldestTime"] = 1632965878,
                ["wasAltered"] = true,
                ["newestTime"] = 1632965878,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1632965878,
                        ["quant"] = 1,
                        ["id"] = "1690014163",
                        ["itemLink"] = 3956,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set night mother's embrace feet impenetrable",
            },
        },
        [102147] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_draugr_medium_feet_a.dds",
                ["itemDesc"] = "Stygian Boots",
                ["oldestTime"] = 1633214720,
                ["wasAltered"] = true,
                ["newestTime"] = 1633214720,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15090,
                        ["guild"] = 1,
                        ["buyer"] = 1577,
                        ["wasKiosk"] = true,
                        ["seller"] = 1494,
                        ["timestamp"] = 1633214720,
                        ["quant"] = 1,
                        ["id"] = "1691956179",
                        ["itemLink"] = 2301,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set stygian feet reinforced",
            },
        },
        [49131] = 
        {
            ["10:0:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_medium_waist_a.dds",
                ["itemDesc"] = "Belt of the Night Mother",
                ["oldestTime"] = 1632911086,
                ["wasAltered"] = true,
                ["newestTime"] = 1633232056,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 8,
                        ["wasKiosk"] = false,
                        ["seller"] = 426,
                        ["timestamp"] = 1633021964,
                        ["quant"] = 1,
                        ["id"] = "1690383607",
                        ["itemLink"] = 590,
                    },
                    [2] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1703,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633232056,
                        ["quant"] = 1,
                        ["id"] = "1692135555",
                        ["itemLink"] = 590,
                    },
                    [3] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2463,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632911086,
                        ["quant"] = 1,
                        ["id"] = "1689604535",
                        ["itemLink"] = 590,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr10 blue superior medium apparel set night mother's gaze waist training",
            },
        },
        [172012] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_waist_a.dds",
                ["itemDesc"] = "Sash of Frostbite",
                ["oldestTime"] = 1633182287,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182303,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1377,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633182287,
                        ["quant"] = 1,
                        ["id"] = "1691606411",
                        ["itemLink"] = 1938,
                    },
                    [2] = 
                    {
                        ["price"] = 775,
                        ["guild"] = 1,
                        ["buyer"] = 1377,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633182303,
                        ["quant"] = 1,
                        ["id"] = "1691606477",
                        ["itemLink"] = 1938,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior light apparel set frostbite waist well-fitted",
            },
        },
        [101360] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_light_robe_d.dds",
                ["itemDesc"] = "Ysgramor's Robe",
                ["oldestTime"] = 1632984326,
                ["wasAltered"] = true,
                ["newestTime"] = 1632984326,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 307,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1632984326,
                        ["quant"] = 1,
                        ["id"] = "1690155683",
                        ["itemLink"] = 310,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set ysgramor's birthright chest divines",
            },
        },
        [175999] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting2.dds",
                ["itemDesc"] = "Praxis: Leyawiin Vase, Table",
                ["oldestTime"] = 1633200580,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200580,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 31,
                        ["wasKiosk"] = false,
                        ["seller"] = 1108,
                        ["timestamp"] = 1633200580,
                        ["quant"] = 1,
                        ["id"] = "1691795597",
                        ["itemLink"] = 2188,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [132591] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 57: Ebonshadow Maces",
                ["oldestTime"] = 1632970195,
                ["wasAltered"] = true,
                ["newestTime"] = 1633213489,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 160,
                        ["wasKiosk"] = true,
                        ["seller"] = 161,
                        ["timestamp"] = 1632970195,
                        ["quant"] = 1,
                        ["id"] = "1690058857",
                        ["itemLink"] = 173,
                    },
                    [2] = 
                    {
                        ["price"] = 4400,
                        ["guild"] = 1,
                        ["buyer"] = 1566,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633213489,
                        ["quant"] = 1,
                        ["id"] = "1691944943",
                        ["itemLink"] = 173,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [54512] = 
        {
            ["50:16:1:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Platinum Necklace",
                ["oldestTime"] = 1633186066,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186066,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633186066,
                        ["quant"] = 1,
                        ["id"] = "1691641443",
                        ["itemLink"] = 2068,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal jewelry apparel neck healthy",
            },
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Platinum Necklace of Reduce Spell Cost",
                ["oldestTime"] = 1632935543,
                ["wasAltered"] = true,
                ["newestTime"] = 1633042155,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 499,
                        ["guild"] = 1,
                        ["buyer"] = 646,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633042155,
                        ["quant"] = 1,
                        ["id"] = "1690529799",
                        ["itemLink"] = 811,
                    },
                    [2] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1003,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1632935543,
                        ["quant"] = 1,
                        ["id"] = "1689766045",
                        ["itemLink"] = 3731,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel neck healthy",
            },
        },
        [160497] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 84: Blackreach Vanguard Bows",
                ["oldestTime"] = 1632970169,
                ["wasAltered"] = true,
                ["newestTime"] = 1632970169,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 160,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1632970169,
                        ["quant"] = 1,
                        ["id"] = "1690058523",
                        ["itemLink"] = 168,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [54514] = 
        {
            ["50:16:1:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Platinum Necklace",
                ["oldestTime"] = 1632829375,
                ["wasAltered"] = true,
                ["newestTime"] = 1632829375,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632829375,
                        ["quant"] = 1,
                        ["id"] = "1688994967",
                        ["itemLink"] = 3063,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal jewelry apparel neck robust",
            },
            ["50:16:2:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Platinum Necklace of Reduce Feat Cost",
                ["oldestTime"] = 1632875815,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186064,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 540,
                        ["guild"] = 1,
                        ["buyer"] = 1115,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1633131781,
                        ["quant"] = 1,
                        ["id"] = "1691206709",
                        ["itemLink"] = 1536,
                    },
                    [2] = 
                    {
                        ["price"] = 540,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1633186058,
                        ["quant"] = 1,
                        ["id"] = "1691641341",
                        ["itemLink"] = 2067,
                    },
                    [3] = 
                    {
                        ["price"] = 730,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633186064,
                        ["quant"] = 1,
                        ["id"] = "1691641407",
                        ["itemLink"] = 2067,
                    },
                    [4] = 
                    {
                        ["price"] = 605,
                        ["guild"] = 1,
                        ["buyer"] = 2325,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1632875815,
                        ["quant"] = 1,
                        ["id"] = "1689350253",
                        ["itemLink"] = 3420,
                    },
                    [5] = 
                    {
                        ["price"] = 605,
                        ["guild"] = 1,
                        ["buyer"] = 2325,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1632875820,
                        ["quant"] = 1,
                        ["id"] = "1689350297",
                        ["itemLink"] = 1536,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "cp160 green fine jewelry apparel neck robust",
            },
        },
        [43732] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Wrothgar Treasure Map VI",
                ["oldestTime"] = 1633182526,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182526,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 389,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182526,
                        ["quant"] = 1,
                        ["id"] = "1691608269",
                        ["itemLink"] = 1959,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [45535] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Ten Ogres Tonic",
                ["oldestTime"] = 1633122936,
                ["wasAltered"] = true,
                ["newestTime"] = 1633122936,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1066,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633122936,
                        ["quant"] = 1,
                        ["id"] = "1691126855",
                        ["itemLink"] = 1453,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [97013] = 
        {
            ["8:0:2:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_medium_waist_a.dds",
                ["itemDesc"] = "Belt of the Night Mother",
                ["oldestTime"] = 1632922805,
                ["wasAltered"] = true,
                ["newestTime"] = 1632922805,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 662,
                        ["timestamp"] = 1632922805,
                        ["quant"] = 1,
                        ["id"] = "1689672077",
                        ["itemLink"] = 3668,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr08 green fine medium apparel set night mother's embrace waist invigorating",
            },
        },
        [45046] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_medium_shoulders_d.dds",
                ["itemDesc"] = "Rubedo Leather Arm Cops of Health",
                ["oldestTime"] = 1632953380,
                ["wasAltered"] = true,
                ["newestTime"] = 1632953380,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 2602,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632953380,
                        ["quant"] = 1,
                        ["id"] = "1689904569",
                        ["itemLink"] = 3854,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel shoulders sturdy",
            },
        },
        [45303] = 
        {
            ["38:0:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_2hsword_d.dds",
                ["itemDesc"] = "Dwarven Greatsword",
                ["oldestTime"] = 1633084670,
                ["wasAltered"] = true,
                ["newestTime"] = 1633084670,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 144,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633084670,
                        ["quant"] = 1,
                        ["id"] = "1690857167",
                        ["itemLink"] = 1198,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr38 white normal weapon sword two-handed intricate",
            },
            ["1:0:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_2hsword_a.dds",
                ["itemDesc"] = "Iron Greatsword",
                ["oldestTime"] = 1632871312,
                ["wasAltered"] = true,
                ["newestTime"] = 1632871312,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 90,
                        ["guild"] = 1,
                        ["buyer"] = 2293,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632871312,
                        ["quant"] = 1,
                        ["id"] = "1689312033",
                        ["itemLink"] = 3389,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal weapon sword two-handed intricate",
            },
            ["50:15:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_2hsword_d.dds",
                ["itemDesc"] = "Rubedite Greatsword",
                ["oldestTime"] = 1632885675,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185932,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633009377,
                        ["quant"] = 1,
                        ["id"] = "1690285553",
                        ["itemLink"] = 489,
                    },
                    [2] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633009379,
                        ["quant"] = 1,
                        ["id"] = "1690285567",
                        ["itemLink"] = 491,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009393,
                        ["quant"] = 1,
                        ["id"] = "1690285767",
                        ["itemLink"] = 506,
                    },
                    [4] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633084674,
                        ["quant"] = 1,
                        ["id"] = "1690857249",
                        ["itemLink"] = 491,
                    },
                    [5] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633185929,
                        ["quant"] = 1,
                        ["id"] = "1691639959",
                        ["itemLink"] = 491,
                    },
                    [6] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633185932,
                        ["quant"] = 1,
                        ["id"] = "1691640011",
                        ["itemLink"] = 491,
                    },
                    [7] = 
                    {
                        ["price"] = 222,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1632885675,
                        ["quant"] = 1,
                        ["id"] = "1689459733",
                        ["itemLink"] = 489,
                    },
                    [8] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2482,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632919846,
                        ["quant"] = 1,
                        ["id"] = "1689650617",
                        ["itemLink"] = 3646,
                    },
                    [9] = 
                    {
                        ["price"] = 207,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632950113,
                        ["quant"] = 1,
                        ["id"] = "1689875029",
                        ["itemLink"] = 506,
                    },
                    [10] = 
                    {
                        ["price"] = 261,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632950113,
                        ["quant"] = 1,
                        ["id"] = "1689875031",
                        ["itemLink"] = 3808,
                    },
                    [11] = 
                    {
                        ["price"] = 268,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632950114,
                        ["quant"] = 1,
                        ["id"] = "1689875037",
                        ["itemLink"] = 491,
                    },
                    [12] = 
                    {
                        ["price"] = 190,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632956368,
                        ["quant"] = 1,
                        ["id"] = "1689931063",
                        ["itemLink"] = 3871,
                    },
                    [13] = 
                    {
                        ["price"] = 310,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1632956386,
                        ["quant"] = 1,
                        ["id"] = "1689931391",
                        ["itemLink"] = 506,
                    },
                },
                ["totalCount"] = 13,
                ["itemAdderText"] = "cp150 white normal weapon sword two-handed intricate",
            },
            ["50:16:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_2hsword_d.dds",
                ["itemDesc"] = "Rubedite Greatsword",
                ["oldestTime"] = 1632838953,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309704,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 228,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633009377,
                        ["quant"] = 1,
                        ["id"] = "1690285549",
                        ["itemLink"] = 488,
                    },
                    [2] = 
                    {
                        ["price"] = 328,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633009382,
                        ["quant"] = 1,
                        ["id"] = "1690285603",
                        ["itemLink"] = 488,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633084018,
                        ["quant"] = 1,
                        ["id"] = "1690854547",
                        ["itemLink"] = 1163,
                    },
                    [4] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633129387,
                        ["quant"] = 1,
                        ["id"] = "1691180037",
                        ["itemLink"] = 1500,
                    },
                    [5] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633185925,
                        ["quant"] = 1,
                        ["id"] = "1691639873",
                        ["itemLink"] = 2015,
                    },
                    [6] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633185925,
                        ["quant"] = 1,
                        ["id"] = "1691639891",
                        ["itemLink"] = 1500,
                    },
                    [7] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633185930,
                        ["quant"] = 1,
                        ["id"] = "1691639975",
                        ["itemLink"] = 2019,
                    },
                    [8] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1633185931,
                        ["quant"] = 1,
                        ["id"] = "1691639993",
                        ["itemLink"] = 2020,
                    },
                    [9] = 
                    {
                        ["price"] = 135,
                        ["guild"] = 1,
                        ["buyer"] = 1001,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633268058,
                        ["quant"] = 1,
                        ["id"] = "1692385861",
                        ["itemLink"] = 2020,
                    },
                    [10] = 
                    {
                        ["price"] = 228,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633309704,
                        ["quant"] = 1,
                        ["id"] = "1692845951",
                        ["itemLink"] = 488,
                    },
                    [11] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1365,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632838953,
                        ["quant"] = 1,
                        ["id"] = "1689053959",
                        ["itemLink"] = 488,
                    },
                    [12] = 
                    {
                        ["price"] = 984,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1632865276,
                        ["quant"] = 1,
                        ["id"] = "1689266489",
                        ["itemLink"] = 488,
                    },
                    [13] = 
                    {
                        ["price"] = 273,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 240,
                        ["timestamp"] = 1632885676,
                        ["quant"] = 1,
                        ["id"] = "1689459741",
                        ["itemLink"] = 2020,
                    },
                    [14] = 
                    {
                        ["price"] = 273,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 240,
                        ["timestamp"] = 1632885677,
                        ["quant"] = 1,
                        ["id"] = "1689459749",
                        ["itemLink"] = 3515,
                    },
                    [15] = 
                    {
                        ["price"] = 299,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632950116,
                        ["quant"] = 1,
                        ["id"] = "1689875059",
                        ["itemLink"] = 3811,
                    },
                    [16] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 2646,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1632963253,
                        ["quant"] = 1,
                        ["id"] = "1689988383",
                        ["itemLink"] = 3515,
                    },
                    [17] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 2646,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1632963254,
                        ["quant"] = 1,
                        ["id"] = "1689988387",
                        ["itemLink"] = 3939,
                    },
                },
                ["totalCount"] = 17,
                ["itemAdderText"] = "cp160 white normal weapon sword two-handed intricate",
            },
        },
        [172242] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_waist_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Belt",
                ["oldestTime"] = 1633114507,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310169,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1013,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633114507,
                        ["quant"] = 1,
                        ["id"] = "1691069409",
                        ["itemLink"] = 1381,
                    },
                    [2] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 63,
                        ["wasKiosk"] = false,
                        ["seller"] = 354,
                        ["timestamp"] = 1633310169,
                        ["quant"] = 1,
                        ["id"] = "1692850911",
                        ["itemLink"] = 1381,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior medium apparel set deadlands assassin waist invigorating",
            },
        },
        [85451] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Salvation",
                ["oldestTime"] = 1633163923,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163923,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1999,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633163923,
                        ["quant"] = 1,
                        ["id"] = "1691490399",
                        ["itemLink"] = 1821,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set salvation ring robust",
            },
            ["50:16:2:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Salvation",
                ["oldestTime"] = 1633211069,
                ["wasAltered"] = true,
                ["newestTime"] = 1633211069,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2499,
                        ["guild"] = 1,
                        ["buyer"] = 1553,
                        ["wasKiosk"] = true,
                        ["seller"] = 305,
                        ["timestamp"] = 1633211069,
                        ["quant"] = 1,
                        ["id"] = "1691916243",
                        ["itemLink"] = 2277,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set salvation ring robust",
            },
        },
        [64506] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_daedric_skin.dds",
                ["itemDesc"] = "Rubedo Leather",
                ["oldestTime"] = 1632935009,
                ["wasAltered"] = true,
                ["newestTime"] = 1633223130,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4800,
                        ["guild"] = 1,
                        ["buyer"] = 303,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632983814,
                        ["quant"] = 200,
                        ["id"] = "1690152761",
                        ["itemLink"] = 306,
                    },
                    [2] = 
                    {
                        ["price"] = 4800,
                        ["guild"] = 1,
                        ["buyer"] = 303,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632983816,
                        ["quant"] = 200,
                        ["id"] = "1690152767",
                        ["itemLink"] = 306,
                    },
                    [3] = 
                    {
                        ["price"] = 4800,
                        ["guild"] = 1,
                        ["buyer"] = 303,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632983817,
                        ["quant"] = 200,
                        ["id"] = "1690152771",
                        ["itemLink"] = 306,
                    },
                    [4] = 
                    {
                        ["price"] = 3800,
                        ["guild"] = 1,
                        ["buyer"] = 833,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633068683,
                        ["quant"] = 200,
                        ["id"] = "1690771125",
                        ["itemLink"] = 306,
                    },
                    [5] = 
                    {
                        ["price"] = 3800,
                        ["guild"] = 1,
                        ["buyer"] = 833,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633068685,
                        ["quant"] = 200,
                        ["id"] = "1690771133",
                        ["itemLink"] = 306,
                    },
                    [6] = 
                    {
                        ["price"] = 3800,
                        ["guild"] = 1,
                        ["buyer"] = 465,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633095342,
                        ["quant"] = 200,
                        ["id"] = "1690922373",
                        ["itemLink"] = 306,
                    },
                    [7] = 
                    {
                        ["price"] = 3800,
                        ["guild"] = 1,
                        ["buyer"] = 689,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633140957,
                        ["quant"] = 200,
                        ["id"] = "1691300837",
                        ["itemLink"] = 306,
                    },
                    [8] = 
                    {
                        ["price"] = 3800,
                        ["guild"] = 1,
                        ["buyer"] = 907,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633160426,
                        ["quant"] = 200,
                        ["id"] = "1691466879",
                        ["itemLink"] = 306,
                    },
                    [9] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1478,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633199577,
                        ["quant"] = 200,
                        ["id"] = "1691784975",
                        ["itemLink"] = 306,
                    },
                    [10] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1478,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633199578,
                        ["quant"] = 200,
                        ["id"] = "1691784985",
                        ["itemLink"] = 306,
                    },
                    [11] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1478,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633199580,
                        ["quant"] = 200,
                        ["id"] = "1691785003",
                        ["itemLink"] = 306,
                    },
                    [12] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1549,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633209459,
                        ["quant"] = 200,
                        ["id"] = "1691899557",
                        ["itemLink"] = 306,
                    },
                    [13] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1549,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633209461,
                        ["quant"] = 200,
                        ["id"] = "1691899607",
                        ["itemLink"] = 306,
                    },
                    [14] = 
                    {
                        ["price"] = 4192,
                        ["guild"] = 1,
                        ["buyer"] = 1626,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633223121,
                        ["quant"] = 200,
                        ["id"] = "1692045127",
                        ["itemLink"] = 306,
                    },
                    [15] = 
                    {
                        ["price"] = 4192,
                        ["guild"] = 1,
                        ["buyer"] = 1626,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633223130,
                        ["quant"] = 200,
                        ["id"] = "1692045165",
                        ["itemLink"] = 306,
                    },
                    [16] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 626,
                        ["wasKiosk"] = false,
                        ["seller"] = 266,
                        ["timestamp"] = 1632935009,
                        ["quant"] = 200,
                        ["id"] = "1689760671",
                        ["itemLink"] = 306,
                    },
                    [17] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 626,
                        ["wasKiosk"] = false,
                        ["seller"] = 266,
                        ["timestamp"] = 1632935011,
                        ["quant"] = 200,
                        ["id"] = "1689760685",
                        ["itemLink"] = 306,
                    },
                },
                ["totalCount"] = 17,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [139515] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Alinor Post, Tall Fence",
                ["oldestTime"] = 1633310847,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310847,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 2091,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633310847,
                        ["quant"] = 1,
                        ["id"] = "1692858107",
                        ["itemLink"] = 2996,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [117787] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_fur_varchair001.dds",
                ["itemDesc"] = "Redguard Armchair, Starry",
                ["oldestTime"] = 1633061449,
                ["wasAltered"] = true,
                ["newestTime"] = 1633271764,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 21000,
                        ["guild"] = 1,
                        ["buyer"] = 792,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633061449,
                        ["quant"] = 1,
                        ["id"] = "1690721347",
                        ["itemLink"] = 1025,
                    },
                    [2] = 
                    {
                        ["price"] = 21000,
                        ["guild"] = 1,
                        ["buyer"] = 962,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633271764,
                        ["quant"] = 1,
                        ["id"] = "1692423395",
                        ["itemLink"] = 1025,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [130301] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_tre_ded_vrdburntsapling002.dds",
                ["itemDesc"] = "Saplings, Burnt Sparse",
                ["oldestTime"] = 1633151236,
                ["wasAltered"] = true,
                ["newestTime"] = 1633214887,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 200,
                        ["wasKiosk"] = true,
                        ["seller"] = 61,
                        ["timestamp"] = 1633151236,
                        ["quant"] = 1,
                        ["id"] = "1691401717",
                        ["itemLink"] = 1725,
                    },
                    [2] = 
                    {
                        ["price"] = 66,
                        ["guild"] = 1,
                        ["buyer"] = 1581,
                        ["wasKiosk"] = true,
                        ["seller"] = 99,
                        ["timestamp"] = 1633214887,
                        ["quant"] = 1,
                        ["id"] = "1691958131",
                        ["itemLink"] = 1725,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine furnishings conservatory",
            },
        },
        [121342] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 50: Telvanni Maces",
                ["oldestTime"] = 1633209849,
                ["wasAltered"] = true,
                ["newestTime"] = 1633209849,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 421,
                        ["wasKiosk"] = true,
                        ["seller"] = 1214,
                        ["timestamp"] = 1633209849,
                        ["quant"] = 1,
                        ["id"] = "1691903507",
                        ["itemLink"] = 2271,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [172282] = 
        {
            ["50:16:2:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_waist_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Belt",
                ["oldestTime"] = 1633146897,
                ["wasAltered"] = true,
                ["newestTime"] = 1633146897,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 1237,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1633146897,
                        ["quant"] = 1,
                        ["id"] = "1691364829",
                        ["itemLink"] = 1656,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set deadlands assassin waist training",
            },
        },
    },
}
