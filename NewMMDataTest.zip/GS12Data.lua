GS12DataSavedVariables =
{
    ["listingseu"] = 
    {
    },
    ["listingsna"] = 
    {
    },
    ["dataeu"] = 
    {
    },
    ["datana"] = 
    {
        [145409] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_arg_exc_mrkbondingchimes005.dds",
                ["itemDesc"] = "Murkmire Bonding Chimes, Simple",
                ["oldestTime"] = 1633201036,
                ["wasAltered"] = true,
                ["newestTime"] = 1633201036,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 1492,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633201036,
                        ["quant"] = 1,
                        ["id"] = "1691800901",
                        ["itemLink"] = 2209,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings courtyard",
            },
        },
        [64516] = 
        {
            ["50:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/ava_siege_weapon_darkanchor_bluefireballista.dds",
                ["itemDesc"] = "Pact Cold Fire Ballista",
                ["oldestTime"] = 1633123088,
                ["wasAltered"] = true,
                ["newestTime"] = 1633123088,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1068,
                        ["wasKiosk"] = true,
                        ["seller"] = 734,
                        ["timestamp"] = 1633123088,
                        ["quant"] = 1,
                        ["id"] = "1691127947",
                        ["itemLink"] = 1458,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr50 white normal miscellaneous siege",
            },
        },
        [134919] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_vrd_inc_telalchemyprops002.dds",
                ["itemDesc"] = "Alchemical Apparatus, Master",
                ["oldestTime"] = 1633113063,
                ["wasAltered"] = true,
                ["newestTime"] = 1633113063,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 31024,
                        ["guild"] = 1,
                        ["buyer"] = 1000,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1633113063,
                        ["quant"] = 1,
                        ["id"] = "1691058673",
                        ["itemLink"] = 1360,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings workshop",
            },
        },
        [176137] = 
        {
            ["1:0:2:35:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_axe.dds",
                ["itemDesc"] = "Companion's Axe",
                ["oldestTime"] = 1633271508,
                ["wasAltered"] = true,
                ["newestTime"] = 1633271508,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 92,
                        ["guild"] = 1,
                        ["buyer"] = 1882,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1633271508,
                        ["quant"] = 1,
                        ["id"] = "1692420973",
                        ["itemLink"] = 2674,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine weapon axe one-handed prolific",
            },
        },
        [124682] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 48: Ashlander Boots",
                ["oldestTime"] = 1632877954,
                ["wasAltered"] = true,
                ["newestTime"] = 1632877954,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 828,
                        ["wasKiosk"] = true,
                        ["seller"] = 533,
                        ["timestamp"] = 1632877954,
                        ["quant"] = 1,
                        ["id"] = "1689371871",
                        ["itemLink"] = 3438,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45325] = 
        {
            ["50:16:1:19:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_medium_legs_d.dds",
                ["itemDesc"] = "Rubedo Leather Guards",
                ["oldestTime"] = 1633023019,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023034,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 494,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1633023019,
                        ["quant"] = 1,
                        ["id"] = "1690390817",
                        ["itemLink"] = 643,
                    },
                    [2] = 
                    {
                        ["price"] = 648,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 527,
                        ["timestamp"] = 1633023034,
                        ["quant"] = 1,
                        ["id"] = "1690390931",
                        ["itemLink"] = 658,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 white normal medium apparel legs ornate",
            },
        },
        [120846] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bre_csb_ship001_ropewheel001.dds",
                ["itemDesc"] = "Dock Rope Wheel",
                ["oldestTime"] = 1632824792,
                ["wasAltered"] = true,
                ["newestTime"] = 1632824792,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6186,
                        ["guild"] = 1,
                        ["buyer"] = 2114,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1632824792,
                        ["quant"] = 1,
                        ["id"] = "1688963125",
                        ["itemLink"] = 3018,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings workshop",
            },
        },
        [100623] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_medium_feet_d.dds",
                ["itemDesc"] = "Spriggan's Boots",
                ["oldestTime"] = 1633131238,
                ["wasAltered"] = true,
                ["newestTime"] = 1633131238,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1109,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633131238,
                        ["quant"] = 1,
                        ["id"] = "1691199881",
                        ["itemLink"] = 1515,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set spriggan's thorns feet divines",
            },
        },
        [134419] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_cwc_str_planetariumsealmage001.dds",
                ["itemDesc"] = "Clockwork Calibration Guide, The Mage",
                ["oldestTime"] = 1632879968,
                ["wasAltered"] = true,
                ["newestTime"] = 1632879968,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 90000,
                        ["guild"] = 1,
                        ["buyer"] = 2331,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632879968,
                        ["quant"] = 1,
                        ["id"] = "1689396463",
                        ["itemLink"] = 3455,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings structures",
            },
        },
        [100628] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_medium_waist_d.dds",
                ["itemDesc"] = "Spriggan's Belt",
                ["oldestTime"] = 1633115899,
                ["wasAltered"] = true,
                ["newestTime"] = 1633115899,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3300,
                        ["guild"] = 1,
                        ["buyer"] = 1022,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633115899,
                        ["quant"] = 1,
                        ["id"] = "1691077843",
                        ["itemLink"] = 1399,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set spriggan's thorns waist divines",
            },
        },
        [134680] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_uni_inc_jesterjewelrybox001.dds",
                ["itemDesc"] = "Jester's Coffer",
                ["oldestTime"] = 1633173957,
                ["wasAltered"] = true,
                ["newestTime"] = 1633173957,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 899,
                        ["wasKiosk"] = true,
                        ["seller"] = 61,
                        ["timestamp"] = 1633173957,
                        ["quant"] = 2,
                        ["id"] = "1691541209",
                        ["itemLink"] = 1894,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings gallery",
            },
        },
        [93721] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Cyrodiil's Ward",
                ["oldestTime"] = 1632839077,
                ["wasAltered"] = true,
                ["newestTime"] = 1632839077,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 281,
                        ["timestamp"] = 1632839077,
                        ["quant"] = 1,
                        ["id"] = "1689055015",
                        ["itemLink"] = 3123,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set ward of cyrodiil ring robust",
            },
        },
        [121371] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Wood Elf Hearth, Forest",
                ["oldestTime"] = 1633205013,
                ["wasAltered"] = true,
                ["newestTime"] = 1633205013,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 1520,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633205013,
                        ["quant"] = 1,
                        ["id"] = "1691842477",
                        ["itemLink"] = 2241,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [43548] = 
        {
            ["50:16:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_light_waist_d.dds",
                ["itemDesc"] = "Ancestor Silk Sash of Health",
                ["oldestTime"] = 1633022966,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022966,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 290,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 527,
                        ["timestamp"] = 1633022966,
                        ["quant"] = 1,
                        ["id"] = "1690390321",
                        ["itemLink"] = 606,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel waist",
            },
        },
        [45853] = 
        {
            ["16:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_002.dds",
                ["itemDesc"] = "Rekuta",
                ["oldestTime"] = 1632827163,
                ["wasAltered"] = true,
                ["newestTime"] = 1633177955,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 375,
                        ["guild"] = 1,
                        ["buyer"] = 680,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633046382,
                        ["quant"] = 5,
                        ["id"] = "1690569907",
                        ["itemLink"] = 866,
                    },
                    [2] = 
                    {
                        ["price"] = 14385,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633049442,
                        ["quant"] = 150,
                        ["id"] = "1690598917",
                        ["itemLink"] = 866,
                    },
                    [3] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 897,
                        ["wasKiosk"] = true,
                        ["seller"] = 442,
                        ["timestamp"] = 1633177955,
                        ["quant"] = 50,
                        ["id"] = "1691570053",
                        ["itemLink"] = 866,
                    },
                    [4] = 
                    {
                        ["price"] = 3329,
                        ["guild"] = 1,
                        ["buyer"] = 2122,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1632827163,
                        ["quant"] = 34,
                        ["id"] = "1688976881",
                        ["itemLink"] = 866,
                    },
                    [5] = 
                    {
                        ["price"] = 475,
                        ["guild"] = 1,
                        ["buyer"] = 2122,
                        ["wasKiosk"] = false,
                        ["seller"] = 1781,
                        ["timestamp"] = 1632827163,
                        ["quant"] = 5,
                        ["id"] = "1688976889",
                        ["itemLink"] = 866,
                    },
                    [6] = 
                    {
                        ["price"] = 475,
                        ["guild"] = 1,
                        ["buyer"] = 2122,
                        ["wasKiosk"] = false,
                        ["seller"] = 1781,
                        ["timestamp"] = 1632827164,
                        ["quant"] = 5,
                        ["id"] = "1688976897",
                        ["itemLink"] = 866,
                    },
                    [7] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 2673,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632968647,
                        ["quant"] = 100,
                        ["id"] = "1690042773",
                        ["itemLink"] = 866,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr16 purple epic materials aspect runestone",
            },
        },
        [71200] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_light_armor_standard_f_005.dds",
                ["itemDesc"] = "Raw Ancestor Silk",
                ["oldestTime"] = 1632845825,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311747,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24098,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633311747,
                        ["quant"] = 200,
                        ["id"] = "1692867091",
                        ["itemLink"] = 13,
                    },
                    [2] = 
                    {
                        ["price"] = 23863,
                        ["guild"] = 1,
                        ["buyer"] = 297,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632983345,
                        ["quant"] = 200,
                        ["id"] = "1690149949",
                        ["itemLink"] = 13,
                    },
                    [3] = 
                    {
                        ["price"] = 24236,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632986535,
                        ["quant"] = 200,
                        ["id"] = "1690167455",
                        ["itemLink"] = 13,
                    },
                    [4] = 
                    {
                        ["price"] = 24236,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632986536,
                        ["quant"] = 200,
                        ["id"] = "1690167461",
                        ["itemLink"] = 13,
                    },
                    [5] = 
                    {
                        ["price"] = 24400,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1632986537,
                        ["quant"] = 200,
                        ["id"] = "1690167463",
                        ["itemLink"] = 13,
                    },
                    [6] = 
                    {
                        ["price"] = 24400,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1632986538,
                        ["quant"] = 200,
                        ["id"] = "1690167467",
                        ["itemLink"] = 13,
                    },
                    [7] = 
                    {
                        ["price"] = 17825,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633018859,
                        ["quant"] = 155,
                        ["id"] = "1690356787",
                        ["itemLink"] = 13,
                    },
                    [8] = 
                    {
                        ["price"] = 23746,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633018860,
                        ["quant"] = 200,
                        ["id"] = "1690356791",
                        ["itemLink"] = 13,
                    },
                    [9] = 
                    {
                        ["price"] = 23746,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633018860,
                        ["quant"] = 200,
                        ["id"] = "1690356797",
                        ["itemLink"] = 13,
                    },
                    [10] = 
                    {
                        ["price"] = 24800,
                        ["guild"] = 1,
                        ["buyer"] = 578,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633033298,
                        ["quant"] = 200,
                        ["id"] = "1690465755",
                        ["itemLink"] = 13,
                    },
                    [11] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 578,
                        ["wasKiosk"] = true,
                        ["seller"] = 244,
                        ["timestamp"] = 1633033300,
                        ["quant"] = 200,
                        ["id"] = "1690465757",
                        ["itemLink"] = 13,
                    },
                    [12] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 578,
                        ["wasKiosk"] = true,
                        ["seller"] = 244,
                        ["timestamp"] = 1633033302,
                        ["quant"] = 200,
                        ["id"] = "1690465759",
                        ["itemLink"] = 13,
                    },
                    [13] = 
                    {
                        ["price"] = 26400,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633035224,
                        ["quant"] = 200,
                        ["id"] = "1690477679",
                        ["itemLink"] = 13,
                    },
                    [14] = 
                    {
                        ["price"] = 26400,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633035224,
                        ["quant"] = 200,
                        ["id"] = "1690477687",
                        ["itemLink"] = 13,
                    },
                    [15] = 
                    {
                        ["price"] = 17825,
                        ["guild"] = 1,
                        ["buyer"] = 121,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633049144,
                        ["quant"] = 155,
                        ["id"] = "1690596485",
                        ["itemLink"] = 13,
                    },
                    [16] = 
                    {
                        ["price"] = 23000,
                        ["guild"] = 1,
                        ["buyer"] = 121,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633049145,
                        ["quant"] = 200,
                        ["id"] = "1690596491",
                        ["itemLink"] = 13,
                    },
                    [17] = 
                    {
                        ["price"] = 16675,
                        ["guild"] = 1,
                        ["buyer"] = 121,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633049145,
                        ["quant"] = 145,
                        ["id"] = "1690596499",
                        ["itemLink"] = 13,
                    },
                    [18] = 
                    {
                        ["price"] = 24240,
                        ["guild"] = 1,
                        ["buyer"] = 730,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633053947,
                        ["quant"] = 200,
                        ["id"] = "1690645139",
                        ["itemLink"] = 13,
                    },
                    [19] = 
                    {
                        ["price"] = 24240,
                        ["guild"] = 1,
                        ["buyer"] = 730,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633053949,
                        ["quant"] = 200,
                        ["id"] = "1690645151",
                        ["itemLink"] = 13,
                    },
                    [20] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 922,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633092927,
                        ["quant"] = 200,
                        ["id"] = "1690906641",
                        ["itemLink"] = 13,
                    },
                    [21] = 
                    {
                        ["price"] = 24224,
                        ["guild"] = 1,
                        ["buyer"] = 922,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633092936,
                        ["quant"] = 200,
                        ["id"] = "1690906789",
                        ["itemLink"] = 13,
                    },
                    [22] = 
                    {
                        ["price"] = 24224,
                        ["guild"] = 1,
                        ["buyer"] = 922,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633092936,
                        ["quant"] = 200,
                        ["id"] = "1690906795",
                        ["itemLink"] = 13,
                    },
                    [23] = 
                    {
                        ["price"] = 26400,
                        ["guild"] = 1,
                        ["buyer"] = 922,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633092938,
                        ["quant"] = 200,
                        ["id"] = "1690906813",
                        ["itemLink"] = 13,
                    },
                    [24] = 
                    {
                        ["price"] = 26400,
                        ["guild"] = 1,
                        ["buyer"] = 922,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633092938,
                        ["quant"] = 200,
                        ["id"] = "1690906819",
                        ["itemLink"] = 13,
                    },
                    [25] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 922,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633092939,
                        ["quant"] = 200,
                        ["id"] = "1690906827",
                        ["itemLink"] = 13,
                    },
                    [26] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 922,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633092939,
                        ["quant"] = 200,
                        ["id"] = "1690906833",
                        ["itemLink"] = 13,
                    },
                    [27] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 922,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633092940,
                        ["quant"] = 200,
                        ["id"] = "1690906837",
                        ["itemLink"] = 13,
                    },
                    [28] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 922,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633092940,
                        ["quant"] = 200,
                        ["id"] = "1690906843",
                        ["itemLink"] = 13,
                    },
                    [29] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 922,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633092941,
                        ["quant"] = 200,
                        ["id"] = "1690906845",
                        ["itemLink"] = 13,
                    },
                    [30] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 922,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633092944,
                        ["quant"] = 200,
                        ["id"] = "1690906869",
                        ["itemLink"] = 13,
                    },
                    [31] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 922,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633092944,
                        ["quant"] = 200,
                        ["id"] = "1690906873",
                        ["itemLink"] = 13,
                    },
                    [32] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 922,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633092945,
                        ["quant"] = 200,
                        ["id"] = "1690906875",
                        ["itemLink"] = 13,
                    },
                    [33] = 
                    {
                        ["price"] = 23982,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633105271,
                        ["quant"] = 200,
                        ["id"] = "1691004005",
                        ["itemLink"] = 13,
                    },
                    [34] = 
                    {
                        ["price"] = 23982,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633105272,
                        ["quant"] = 200,
                        ["id"] = "1691004013",
                        ["itemLink"] = 13,
                    },
                    [35] = 
                    {
                        ["price"] = 23000,
                        ["guild"] = 1,
                        ["buyer"] = 979,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633109429,
                        ["quant"] = 200,
                        ["id"] = "1691031933",
                        ["itemLink"] = 13,
                    },
                    [36] = 
                    {
                        ["price"] = 23000,
                        ["guild"] = 1,
                        ["buyer"] = 979,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633109430,
                        ["quant"] = 200,
                        ["id"] = "1691031945",
                        ["itemLink"] = 13,
                    },
                    [37] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 979,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1633109431,
                        ["quant"] = 200,
                        ["id"] = "1691031949",
                        ["itemLink"] = 13,
                    },
                    [38] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 979,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1633109435,
                        ["quant"] = 200,
                        ["id"] = "1691031999",
                        ["itemLink"] = 13,
                    },
                    [39] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 144,
                        ["timestamp"] = 1633114431,
                        ["quant"] = 200,
                        ["id"] = "1691069007",
                        ["itemLink"] = 13,
                    },
                    [40] = 
                    {
                        ["price"] = 12900,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 732,
                        ["timestamp"] = 1633114432,
                        ["quant"] = 86,
                        ["id"] = "1691069017",
                        ["itemLink"] = 13,
                    },
                    [41] = 
                    {
                        ["price"] = 23000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1633148070,
                        ["quant"] = 200,
                        ["id"] = "1691374309",
                        ["itemLink"] = 13,
                    },
                    [42] = 
                    {
                        ["price"] = 23000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1633148073,
                        ["quant"] = 200,
                        ["id"] = "1691374329",
                        ["itemLink"] = 13,
                    },
                    [43] = 
                    {
                        ["price"] = 23000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1633148076,
                        ["quant"] = 200,
                        ["id"] = "1691374357",
                        ["itemLink"] = 13,
                    },
                    [44] = 
                    {
                        ["price"] = 23000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1633148078,
                        ["quant"] = 200,
                        ["id"] = "1691374389",
                        ["itemLink"] = 13,
                    },
                    [45] = 
                    {
                        ["price"] = 23750,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633154259,
                        ["quant"] = 200,
                        ["id"] = "1691425881",
                        ["itemLink"] = 13,
                    },
                    [46] = 
                    {
                        ["price"] = 23750,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633154260,
                        ["quant"] = 200,
                        ["id"] = "1691425883",
                        ["itemLink"] = 13,
                    },
                    [47] = 
                    {
                        ["price"] = 23750,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633154261,
                        ["quant"] = 200,
                        ["id"] = "1691425885",
                        ["itemLink"] = 13,
                    },
                    [48] = 
                    {
                        ["price"] = 23750,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633154262,
                        ["quant"] = 200,
                        ["id"] = "1691425891",
                        ["itemLink"] = 13,
                    },
                    [49] = 
                    {
                        ["price"] = 24170,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633154464,
                        ["quant"] = 200,
                        ["id"] = "1691427439",
                        ["itemLink"] = 13,
                    },
                    [50] = 
                    {
                        ["price"] = 24046,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633154476,
                        ["quant"] = 200,
                        ["id"] = "1691427563",
                        ["itemLink"] = 13,
                    },
                    [51] = 
                    {
                        ["price"] = 24046,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633154477,
                        ["quant"] = 200,
                        ["id"] = "1691427575",
                        ["itemLink"] = 13,
                    },
                    [52] = 
                    {
                        ["price"] = 24046,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633154477,
                        ["quant"] = 200,
                        ["id"] = "1691427579",
                        ["itemLink"] = 13,
                    },
                    [53] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 1011,
                        ["timestamp"] = 1633154483,
                        ["quant"] = 200,
                        ["id"] = "1691427641",
                        ["itemLink"] = 13,
                    },
                    [54] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 1011,
                        ["timestamp"] = 1633154484,
                        ["quant"] = 200,
                        ["id"] = "1691427657",
                        ["itemLink"] = 13,
                    },
                    [55] = 
                    {
                        ["price"] = 24284,
                        ["guild"] = 1,
                        ["buyer"] = 1364,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633180201,
                        ["quant"] = 200,
                        ["id"] = "1691586701",
                        ["itemLink"] = 13,
                    },
                    [56] = 
                    {
                        ["price"] = 24284,
                        ["guild"] = 1,
                        ["buyer"] = 1364,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633180204,
                        ["quant"] = 200,
                        ["id"] = "1691586717",
                        ["itemLink"] = 13,
                    },
                    [57] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 224,
                        ["wasKiosk"] = false,
                        ["seller"] = 222,
                        ["timestamp"] = 1633190399,
                        ["quant"] = 200,
                        ["id"] = "1691692367",
                        ["itemLink"] = 13,
                    },
                    [58] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 224,
                        ["wasKiosk"] = false,
                        ["seller"] = 222,
                        ["timestamp"] = 1633190401,
                        ["quant"] = 200,
                        ["id"] = "1691692385",
                        ["itemLink"] = 13,
                    },
                    [59] = 
                    {
                        ["price"] = 24200,
                        ["guild"] = 1,
                        ["buyer"] = 224,
                        ["wasKiosk"] = false,
                        ["seller"] = 626,
                        ["timestamp"] = 1633190402,
                        ["quant"] = 200,
                        ["id"] = "1691692405",
                        ["itemLink"] = 13,
                    },
                    [60] = 
                    {
                        ["price"] = 23974,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633232196,
                        ["quant"] = 200,
                        ["id"] = "1692137129",
                        ["itemLink"] = 13,
                    },
                    [61] = 
                    {
                        ["price"] = 23974,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633232197,
                        ["quant"] = 200,
                        ["id"] = "1692137139",
                        ["itemLink"] = 13,
                    },
                    [62] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633232198,
                        ["quant"] = 200,
                        ["id"] = "1692137145",
                        ["itemLink"] = 13,
                    },
                    [63] = 
                    {
                        ["price"] = 24230,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633232199,
                        ["quant"] = 200,
                        ["id"] = "1692137155",
                        ["itemLink"] = 13,
                    },
                    [64] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633232201,
                        ["quant"] = 200,
                        ["id"] = "1692137167",
                        ["itemLink"] = 13,
                    },
                    [65] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633232202,
                        ["quant"] = 200,
                        ["id"] = "1692137171",
                        ["itemLink"] = 13,
                    },
                    [66] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633232203,
                        ["quant"] = 200,
                        ["id"] = "1692137177",
                        ["itemLink"] = 13,
                    },
                    [67] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633232204,
                        ["quant"] = 200,
                        ["id"] = "1692137181",
                        ["itemLink"] = 13,
                    },
                    [68] = 
                    {
                        ["price"] = 26400,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633232205,
                        ["quant"] = 200,
                        ["id"] = "1692137187",
                        ["itemLink"] = 13,
                    },
                    [69] = 
                    {
                        ["price"] = 26400,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633232206,
                        ["quant"] = 200,
                        ["id"] = "1692137189",
                        ["itemLink"] = 13,
                    },
                    [70] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633232206,
                        ["quant"] = 200,
                        ["id"] = "1692137201",
                        ["itemLink"] = 13,
                    },
                    [71] = 
                    {
                        ["price"] = 23942,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633288876,
                        ["quant"] = 200,
                        ["id"] = "1692613945",
                        ["itemLink"] = 13,
                    },
                    [72] = 
                    {
                        ["price"] = 25600,
                        ["guild"] = 1,
                        ["buyer"] = 2035,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633298885,
                        ["quant"] = 200,
                        ["id"] = "1692730083",
                        ["itemLink"] = 13,
                    },
                    [73] = 
                    {
                        ["price"] = 26400,
                        ["guild"] = 1,
                        ["buyer"] = 2035,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633298888,
                        ["quant"] = 200,
                        ["id"] = "1692730093",
                        ["itemLink"] = 13,
                    },
                    [74] = 
                    {
                        ["price"] = 26400,
                        ["guild"] = 1,
                        ["buyer"] = 2035,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633298890,
                        ["quant"] = 200,
                        ["id"] = "1692730101",
                        ["itemLink"] = 13,
                    },
                    [75] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 2035,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633298893,
                        ["quant"] = 200,
                        ["id"] = "1692730117",
                        ["itemLink"] = 13,
                    },
                    [76] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 2035,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633298896,
                        ["quant"] = 200,
                        ["id"] = "1692730123",
                        ["itemLink"] = 13,
                    },
                    [77] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 2035,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633298899,
                        ["quant"] = 200,
                        ["id"] = "1692730137",
                        ["itemLink"] = 13,
                    },
                    [78] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 2035,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633298902,
                        ["quant"] = 200,
                        ["id"] = "1692730145",
                        ["itemLink"] = 13,
                    },
                    [79] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 2035,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633298904,
                        ["quant"] = 200,
                        ["id"] = "1692730153",
                        ["itemLink"] = 13,
                    },
                    [80] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 2035,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633298907,
                        ["quant"] = 200,
                        ["id"] = "1692730159",
                        ["itemLink"] = 13,
                    },
                    [81] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 2035,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633298911,
                        ["quant"] = 200,
                        ["id"] = "1692730175",
                        ["itemLink"] = 13,
                    },
                    [82] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 2035,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633298914,
                        ["quant"] = 200,
                        ["id"] = "1692730187",
                        ["itemLink"] = 13,
                    },
                    [83] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 2035,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633298916,
                        ["quant"] = 200,
                        ["id"] = "1692730209",
                        ["itemLink"] = 13,
                    },
                    [84] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 2035,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633298919,
                        ["quant"] = 200,
                        ["id"] = "1692730225",
                        ["itemLink"] = 13,
                    },
                    [85] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 2035,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633298922,
                        ["quant"] = 200,
                        ["id"] = "1692730275",
                        ["itemLink"] = 13,
                    },
                    [86] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 2035,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633298926,
                        ["quant"] = 200,
                        ["id"] = "1692730331",
                        ["itemLink"] = 13,
                    },
                    [87] = 
                    {
                        ["price"] = 23964,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632845825,
                        ["quant"] = 200,
                        ["id"] = "1689108251",
                        ["itemLink"] = 13,
                    },
                    [88] = 
                    {
                        ["price"] = 23964,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632845825,
                        ["quant"] = 200,
                        ["id"] = "1689108263",
                        ["itemLink"] = 13,
                    },
                    [89] = 
                    {
                        ["price"] = 23964,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632845826,
                        ["quant"] = 200,
                        ["id"] = "1689108281",
                        ["itemLink"] = 13,
                    },
                    [90] = 
                    {
                        ["price"] = 23954,
                        ["guild"] = 1,
                        ["buyer"] = 2277,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632867768,
                        ["quant"] = 200,
                        ["id"] = "1689286065",
                        ["itemLink"] = 13,
                    },
                    [91] = 
                    {
                        ["price"] = 23954,
                        ["guild"] = 1,
                        ["buyer"] = 2277,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632867773,
                        ["quant"] = 200,
                        ["id"] = "1689286103",
                        ["itemLink"] = 13,
                    },
                    [92] = 
                    {
                        ["price"] = 24020,
                        ["guild"] = 1,
                        ["buyer"] = 2422,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632892453,
                        ["quant"] = 200,
                        ["id"] = "1689512193",
                        ["itemLink"] = 13,
                    },
                    [93] = 
                    {
                        ["price"] = 24020,
                        ["guild"] = 1,
                        ["buyer"] = 2422,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632892454,
                        ["quant"] = 200,
                        ["id"] = "1689512205",
                        ["itemLink"] = 13,
                    },
                    [94] = 
                    {
                        ["price"] = 24228,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632897742,
                        ["quant"] = 200,
                        ["id"] = "1689547265",
                        ["itemLink"] = 13,
                    },
                    [95] = 
                    {
                        ["price"] = 24228,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632897742,
                        ["quant"] = 200,
                        ["id"] = "1689547269",
                        ["itemLink"] = 13,
                    },
                    [96] = 
                    {
                        ["price"] = 24228,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632897743,
                        ["quant"] = 200,
                        ["id"] = "1689547271",
                        ["itemLink"] = 13,
                    },
                    [97] = 
                    {
                        ["price"] = 24228,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632897744,
                        ["quant"] = 200,
                        ["id"] = "1689547277",
                        ["itemLink"] = 13,
                    },
                    [98] = 
                    {
                        ["price"] = 24228,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632897745,
                        ["quant"] = 200,
                        ["id"] = "1689547279",
                        ["itemLink"] = 13,
                    },
                    [99] = 
                    {
                        ["price"] = 24228,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632897745,
                        ["quant"] = 200,
                        ["id"] = "1689547283",
                        ["itemLink"] = 13,
                    },
                    [100] = 
                    {
                        ["price"] = 24800,
                        ["guild"] = 1,
                        ["buyer"] = 2484,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632920534,
                        ["quant"] = 200,
                        ["id"] = "1689654631",
                        ["itemLink"] = 13,
                    },
                    [101] = 
                    {
                        ["price"] = 23874,
                        ["guild"] = 1,
                        ["buyer"] = 121,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632932729,
                        ["quant"] = 200,
                        ["id"] = "1689742359",
                        ["itemLink"] = 13,
                    },
                    [102] = 
                    {
                        ["price"] = 23874,
                        ["guild"] = 1,
                        ["buyer"] = 121,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632932729,
                        ["quant"] = 200,
                        ["id"] = "1689742363",
                        ["itemLink"] = 13,
                    },
                    [103] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 101,
                        ["wasKiosk"] = true,
                        ["seller"] = 267,
                        ["timestamp"] = 1632956333,
                        ["quant"] = 200,
                        ["id"] = "1689930661",
                        ["itemLink"] = 13,
                    },
                    [104] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 101,
                        ["wasKiosk"] = true,
                        ["seller"] = 267,
                        ["timestamp"] = 1632956335,
                        ["quant"] = 200,
                        ["id"] = "1689930671",
                        ["itemLink"] = 13,
                    },
                },
                ["totalCount"] = 104,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [43553] = 
        {
            ["50:16:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_medium_legs_a.dds",
                ["itemDesc"] = "Rubedo Leather Guards of Magicka",
                ["oldestTime"] = 1633023018,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023018,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 455,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1633023018,
                        ["quant"] = 1,
                        ["id"] = "1690390803",
                        ["itemLink"] = 642,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel legs",
            },
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_medium_legs_d.dds",
                ["itemDesc"] = "Rubedo Leather Guards",
                ["oldestTime"] = 1632847685,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023001,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 136,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633023001,
                        ["quant"] = 1,
                        ["id"] = "1690390573",
                        ["itemLink"] = 625,
                    },
                    [2] = 
                    {
                        ["price"] = 123,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1632847685,
                        ["quant"] = 1,
                        ["id"] = "1689125489",
                        ["itemLink"] = 3206,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 white normal medium apparel legs",
            },
        },
        [97320] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_legs_d.dds",
                ["itemDesc"] = "Breeches of a Mother's Sorrow",
                ["oldestTime"] = 1633054412,
                ["wasAltered"] = true,
                ["newestTime"] = 1633217183,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9913,
                        ["guild"] = 1,
                        ["buyer"] = 613,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633054412,
                        ["quant"] = 1,
                        ["id"] = "1690649257",
                        ["itemLink"] = 939,
                    },
                    [2] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1595,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633217183,
                        ["quant"] = 1,
                        ["id"] = "1691981957",
                        ["itemLink"] = 939,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic light apparel set mother's sorrow legs impenetrable",
            },
        },
        [176425] = 
        {
            ["1:0:2:37:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_axe.dds",
                ["itemDesc"] = "Companion's Axe",
                ["oldestTime"] = 1632936586,
                ["wasAltered"] = true,
                ["newestTime"] = 1632936586,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24,
                        ["guild"] = 1,
                        ["buyer"] = 2528,
                        ["wasKiosk"] = true,
                        ["seller"] = 1033,
                        ["timestamp"] = 1632936586,
                        ["quant"] = 1,
                        ["id"] = "1689772347",
                        ["itemLink"] = 3736,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine weapon axe one-handed shattering",
            },
        },
        [45098] = 
        {
            ["50:16:2:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_heavy_head_d.dds",
                ["itemDesc"] = "Rubedite Helm of Magicka",
                ["oldestTime"] = 1632857730,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950130,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1632857730,
                        ["quant"] = 1,
                        ["id"] = "1689211527",
                        ["itemLink"] = 3282,
                    },
                    [2] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1632950130,
                        ["quant"] = 1,
                        ["id"] = "1689875243",
                        ["itemLink"] = 3822,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine heavy apparel head reinforced",
            },
        },
        [16427] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_book_001.dds",
                ["itemDesc"] = "Crafting Motif 6: Redguard Style",
                ["oldestTime"] = 1632820719,
                ["wasAltered"] = true,
                ["newestTime"] = 1633248691,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 484,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1633017925,
                        ["quant"] = 1,
                        ["id"] = "1690348907",
                        ["itemLink"] = 561,
                    },
                    [2] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 640,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633041778,
                        ["quant"] = 1,
                        ["id"] = "1690527079",
                        ["itemLink"] = 561,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 940,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633196375,
                        ["quant"] = 1,
                        ["id"] = "1691753215",
                        ["itemLink"] = 561,
                    },
                    [4] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1807,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633248691,
                        ["quant"] = 1,
                        ["id"] = "1692261909",
                        ["itemLink"] = 561,
                    },
                    [5] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 2103,
                        ["wasKiosk"] = true,
                        ["seller"] = 71,
                        ["timestamp"] = 1632820719,
                        ["quant"] = 1,
                        ["id"] = "1688947279",
                        ["itemLink"] = 561,
                    },
                    [6] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2103,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1632820745,
                        ["quant"] = 1,
                        ["id"] = "1688947435",
                        ["itemLink"] = 561,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 blue superior consumable motif",
            },
        },
        [45612] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Silver Lotusberry Tea",
                ["oldestTime"] = 1632913352,
                ["wasAltered"] = true,
                ["newestTime"] = 1632913352,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1361,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632913352,
                        ["quant"] = 1,
                        ["id"] = "1689614129",
                        ["itemLink"] = 3630,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [95533] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_light_head_a.dds",
                ["itemDesc"] = "Hat of Martial Knowledge",
                ["oldestTime"] = 1633022979,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022979,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1633022979,
                        ["quant"] = 1,
                        ["id"] = "1690390441",
                        ["itemLink"] = 619,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set way of martial knowledge head reinforced",
            },
        },
        [45614] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Herbflower Tea",
                ["oldestTime"] = 1632865549,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865549,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 69,
                        ["guild"] = 1,
                        ["buyer"] = 2194,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1632865549,
                        ["quant"] = 1,
                        ["id"] = "1689268995",
                        ["itemLink"] = 3350,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45360] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_medium_legs_d.dds",
                ["itemDesc"] = "Rubedo Leather Guards",
                ["oldestTime"] = 1632839967,
                ["wasAltered"] = true,
                ["newestTime"] = 1633315864,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 213,
                        ["guild"] = 1,
                        ["buyer"] = 106,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633315864,
                        ["quant"] = 1,
                        ["id"] = "1692913353",
                        ["itemLink"] = 79,
                    },
                    [2] = 
                    {
                        ["price"] = 225,
                        ["guild"] = 1,
                        ["buyer"] = 780,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1633059429,
                        ["quant"] = 1,
                        ["id"] = "1690704695",
                        ["itemLink"] = 1003,
                    },
                    [3] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 539,
                        ["timestamp"] = 1633084114,
                        ["quant"] = 1,
                        ["id"] = "1690855097",
                        ["itemLink"] = 1192,
                    },
                    [4] = 
                    {
                        ["price"] = 170,
                        ["guild"] = 1,
                        ["buyer"] = 1055,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633121630,
                        ["quant"] = 1,
                        ["id"] = "1691116693",
                        ["itemLink"] = 1003,
                    },
                    [5] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1150,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633136225,
                        ["quant"] = 1,
                        ["id"] = "1691255437",
                        ["itemLink"] = 1570,
                    },
                    [6] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633186001,
                        ["quant"] = 1,
                        ["id"] = "1691640655",
                        ["itemLink"] = 2053,
                    },
                    [7] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 527,
                        ["timestamp"] = 1632839967,
                        ["quant"] = 1,
                        ["id"] = "1689060213",
                        ["itemLink"] = 3141,
                    },
                    [8] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632840313,
                        ["quant"] = 1,
                        ["id"] = "1689062301",
                        ["itemLink"] = 3148,
                    },
                    [9] = 
                    {
                        ["price"] = 199,
                        ["guild"] = 1,
                        ["buyer"] = 2202,
                        ["wasKiosk"] = true,
                        ["seller"] = 283,
                        ["timestamp"] = 1632913792,
                        ["quant"] = 1,
                        ["id"] = "1689616133",
                        ["itemLink"] = 2053,
                    },
                    [10] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 105,
                        ["timestamp"] = 1632922804,
                        ["quant"] = 1,
                        ["id"] = "1689672073",
                        ["itemLink"] = 3667,
                    },
                    [11] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632956411,
                        ["quant"] = 1,
                        ["id"] = "1689931715",
                        ["itemLink"] = 3148,
                    },
                },
                ["totalCount"] = 11,
                ["itemAdderText"] = "cp160 white normal medium apparel legs intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_medium_legs_d.dds",
                ["itemDesc"] = "Rubedo Leather Guards",
                ["oldestTime"] = 1633084688,
                ["wasAltered"] = true,
                ["newestTime"] = 1633315863,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 175,
                        ["guild"] = 1,
                        ["buyer"] = 106,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633315863,
                        ["quant"] = 1,
                        ["id"] = "1692913345",
                        ["itemLink"] = 78,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633084688,
                        ["quant"] = 1,
                        ["id"] = "1690857417",
                        ["itemLink"] = 1213,
                    },
                    [3] = 
                    {
                        ["price"] = 165,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633146936,
                        ["quant"] = 1,
                        ["id"] = "1691365339",
                        ["itemLink"] = 1668,
                    },
                    [4] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633186016,
                        ["quant"] = 1,
                        ["id"] = "1691640791",
                        ["itemLink"] = 1668,
                    },
                    [5] = 
                    {
                        ["price"] = 155,
                        ["guild"] = 1,
                        ["buyer"] = 1734,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633236158,
                        ["quant"] = 1,
                        ["id"] = "1692168661",
                        ["itemLink"] = 2490,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "cp150 white normal medium apparel legs intricate",
            },
        },
        [46130] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_ingot_voidstone.dds",
                ["itemDesc"] = "Voidstone Ingot",
                ["oldestTime"] = 1632999910,
                ["wasAltered"] = true,
                ["newestTime"] = 1632999910,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3657,
                        ["guild"] = 1,
                        ["buyer"] = 393,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1632999910,
                        ["quant"] = 200,
                        ["id"] = "1690234353",
                        ["itemLink"] = 396,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [160563] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 86: Sea Giant Bows",
                ["oldestTime"] = 1633138665,
                ["wasAltered"] = true,
                ["newestTime"] = 1633138665,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19500,
                        ["guild"] = 1,
                        ["buyer"] = 1171,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633138665,
                        ["quant"] = 1,
                        ["id"] = "1691278857",
                        ["itemLink"] = 1589,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [172084] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_staff_a.dds",
                ["itemDesc"] = "Inferno Staff of Frostbite",
                ["oldestTime"] = 1633239313,
                ["wasAltered"] = true,
                ["newestTime"] = 1633239313,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2990,
                        ["guild"] = 1,
                        ["buyer"] = 1759,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633239313,
                        ["quant"] = 1,
                        ["id"] = "1692193251",
                        ["itemLink"] = 2520,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set frostbite flame staff two-handed decisive",
            },
        },
        [46134] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_cloth_void.dds",
                ["itemDesc"] = "Void Cloth",
                ["oldestTime"] = 1632982614,
                ["wasAltered"] = true,
                ["newestTime"] = 1632982614,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 287,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632982614,
                        ["quant"] = 200,
                        ["id"] = "1690145851",
                        ["itemLink"] = 294,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [142647] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_elderarg_2haxe_a.dds",
                ["itemDesc"] = "Bright-Throat's Boast Battle Axe",
                ["oldestTime"] = 1633099383,
                ["wasAltered"] = true,
                ["newestTime"] = 1633099383,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12995,
                        ["guild"] = 1,
                        ["buyer"] = 718,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1633099383,
                        ["quant"] = 1,
                        ["id"] = "1690952861",
                        ["itemLink"] = 1277,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set bright-throat's boast axe two-handed precise",
            },
        },
        [160568] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 86: Sea Giant Legs",
                ["oldestTime"] = 1632950249,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950249,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 2586,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1632950249,
                        ["quant"] = 1,
                        ["id"] = "1689876229",
                        ["itemLink"] = 3837,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [171833] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_vrd_exc_statuestdelyn001.dds",
                ["itemDesc"] = "Dark Elf Statue, St. Delyn",
                ["oldestTime"] = 1632879954,
                ["wasAltered"] = true,
                ["newestTime"] = 1632879954,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 58717,
                        ["guild"] = 1,
                        ["buyer"] = 2331,
                        ["wasKiosk"] = true,
                        ["seller"] = 1816,
                        ["timestamp"] = 1632879954,
                        ["quant"] = 1,
                        ["id"] = "1689396291",
                        ["itemLink"] = 3453,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings courtyard",
            },
        },
        [127042] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Indoril Runner, Vivec",
                ["oldestTime"] = 1633132561,
                ["wasAltered"] = true,
                ["newestTime"] = 1633132561,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 59950,
                        ["guild"] = 1,
                        ["buyer"] = 1120,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633132561,
                        ["quant"] = 1,
                        ["id"] = "1691214019",
                        ["itemLink"] = 1543,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [74563] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 33: Thieves Guild Helmets",
                ["oldestTime"] = 1632949753,
                ["wasAltered"] = true,
                ["newestTime"] = 1633151343,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5999,
                        ["guild"] = 1,
                        ["buyer"] = 1264,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633151343,
                        ["quant"] = 1,
                        ["id"] = "1691402981",
                        ["itemLink"] = 1727,
                    },
                    [2] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 2582,
                        ["wasKiosk"] = true,
                        ["seller"] = 159,
                        ["timestamp"] = 1632949753,
                        ["quant"] = 1,
                        ["id"] = "1689872479",
                        ["itemLink"] = 1727,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [69189] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_2hsword_a.dds",
                ["itemDesc"] = "Greatsword of Willpower",
                ["oldestTime"] = 1633292065,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292065,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 944,
                        ["timestamp"] = 1633292065,
                        ["quant"] = 1,
                        ["id"] = "1692652381",
                        ["itemLink"] = 2808,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set willpower sword two-handed sharpened",
            },
        },
        [134982] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_alchemy5.dds",
                ["itemDesc"] = "Formula: Alchemical Apparatus, Master",
                ["oldestTime"] = 1633278972,
                ["wasAltered"] = true,
                ["newestTime"] = 1633278972,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 90000,
                        ["guild"] = 1,
                        ["buyer"] = 1918,
                        ["wasKiosk"] = true,
                        ["seller"] = 528,
                        ["timestamp"] = 1633278972,
                        ["quant"] = 1,
                        ["id"] = "1692504787",
                        ["itemLink"] = 2726,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable recipe",
            },
        },
        [161096] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_grayhost_staff_a.dds",
                ["itemDesc"] = "Inferno Staff of Eternal Vigor",
                ["oldestTime"] = 1633053851,
                ["wasAltered"] = true,
                ["newestTime"] = 1633053851,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 728,
                        ["wasKiosk"] = true,
                        ["seller"] = 729,
                        ["timestamp"] = 1633053851,
                        ["quant"] = 1,
                        ["id"] = "1690643955",
                        ["itemLink"] = 935,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set eternal vigor flame staff two-handed sharpened",
            },
        },
        [74569] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 33: Thieves Guild Swords",
                ["oldestTime"] = 1633184207,
                ["wasAltered"] = true,
                ["newestTime"] = 1633184207,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 374,
                        ["timestamp"] = 1633184207,
                        ["quant"] = 1,
                        ["id"] = "1691622823",
                        ["itemLink"] = 1969,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [172106] = 
        {
            ["50:16:4:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_staff_a.dds",
                ["itemDesc"] = "Ice Staff of Frostbite",
                ["oldestTime"] = 1633296855,
                ["wasAltered"] = true,
                ["newestTime"] = 1633296855,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 2023,
                        ["wasKiosk"] = true,
                        ["seller"] = 155,
                        ["timestamp"] = 1633296855,
                        ["quant"] = 1,
                        ["id"] = "1692709285",
                        ["itemLink"] = 2885,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set frostbite staff two-handed training",
            },
        },
        [45643] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Stuffed Venison Haunch",
                ["oldestTime"] = 1633131952,
                ["wasAltered"] = true,
                ["newestTime"] = 1633131952,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1999,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633131952,
                        ["quant"] = 1,
                        ["id"] = "1691207659",
                        ["itemLink"] = 1538,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [180556] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_1hhammer_a.dds",
                ["itemDesc"] = "Mace of Dark Convergence",
                ["oldestTime"] = 1633176733,
                ["wasAltered"] = true,
                ["newestTime"] = 1633176733,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 1357,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1633176733,
                        ["quant"] = 1,
                        ["id"] = "1691560979",
                        ["itemLink"] = 1904,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set dark convergence mace one-handed decisive",
            },
        },
        [176461] = 
        {
            ["1:0:3:37:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_axe.dds",
                ["itemDesc"] = "Companion's Axe",
                ["oldestTime"] = 1633189399,
                ["wasAltered"] = true,
                ["newestTime"] = 1633189399,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 245,
                        ["guild"] = 1,
                        ["buyer"] = 1412,
                        ["wasKiosk"] = true,
                        ["seller"] = 442,
                        ["timestamp"] = 1633189399,
                        ["quant"] = 1,
                        ["id"] = "1691682581",
                        ["itemLink"] = 2093,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior weapon axe one-handed shattering",
            },
        },
        [175950] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Nightstand, Sturdy",
                ["oldestTime"] = 1632882183,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291869,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1393,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633185735,
                        ["quant"] = 1,
                        ["id"] = "1691637471",
                        ["itemLink"] = 1992,
                    },
                    [2] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 90,
                        ["wasKiosk"] = false,
                        ["seller"] = 550,
                        ["timestamp"] = 1633291869,
                        ["quant"] = 1,
                        ["id"] = "1692650309",
                        ["itemLink"] = 1992,
                    },
                    [3] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 2365,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1632882183,
                        ["quant"] = 1,
                        ["id"] = "1689420331",
                        ["itemLink"] = 1992,
                    },
                    [4] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2618,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632957866,
                        ["quant"] = 1,
                        ["id"] = "1689942121",
                        ["itemLink"] = 1992,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [181585] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Leyawiin Platform, Narrow Steps",
                ["oldestTime"] = 1633291954,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291954,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 90,
                        ["wasKiosk"] = false,
                        ["seller"] = 62,
                        ["timestamp"] = 1633291954,
                        ["quant"] = 1,
                        ["id"] = "1692651297",
                        ["itemLink"] = 2802,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [97362] = 
        {
            ["50:16:4:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_legs_d.dds",
                ["itemDesc"] = "Breeches of a Mother's Sorrow",
                ["oldestTime"] = 1633053381,
                ["wasAltered"] = true,
                ["newestTime"] = 1633053381,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8813,
                        ["guild"] = 1,
                        ["buyer"] = 725,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633053381,
                        ["quant"] = 1,
                        ["id"] = "1690639569",
                        ["itemLink"] = 932,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set mother's sorrow legs sturdy",
            },
        },
        [54868] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_book_001.dds",
                ["itemDesc"] = "Crafting Motif 10: Imperial Style",
                ["oldestTime"] = 1632851500,
                ["wasAltered"] = true,
                ["newestTime"] = 1632851500,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 2219,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1632851500,
                        ["quant"] = 1,
                        ["id"] = "1689154965",
                        ["itemLink"] = 3244,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable motif",
            },
        },
        [120663] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_tre_dec_auridonsapling004.dds",
                ["itemDesc"] = "Sapling, Healthy Forest",
                ["oldestTime"] = 1632970781,
                ["wasAltered"] = true,
                ["newestTime"] = 1632970781,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 174,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1632970781,
                        ["quant"] = 1,
                        ["id"] = "1690064065",
                        ["itemLink"] = 187,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal furnishings conservatory",
            },
        },
        [68440] = 
        {
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_trinimac_light_feet_a.dds",
                ["itemDesc"] = "Shoes of Trinimac's Valor",
                ["oldestTime"] = 1632977379,
                ["wasAltered"] = true,
                ["newestTime"] = 1632977379,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 231,
                        ["wasKiosk"] = true,
                        ["seller"] = 237,
                        ["timestamp"] = 1632977379,
                        ["quant"] = 1,
                        ["id"] = "1690113851",
                        ["itemLink"] = 243,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set trinimac's valor feet infused",
            },
        },
        [127065] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Hlaalu Vase, Gilded",
                ["oldestTime"] = 1633235943,
                ["wasAltered"] = true,
                ["newestTime"] = 1633235943,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 48000,
                        ["guild"] = 1,
                        ["buyer"] = 1733,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633235943,
                        ["quant"] = 1,
                        ["id"] = "1692167515",
                        ["itemLink"] = 2488,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [86107] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_medium_waist_a.dds",
                ["itemDesc"] = "Werewolf Hide Belt",
                ["oldestTime"] = 1633023039,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023039,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1633023039,
                        ["quant"] = 1,
                        ["id"] = "1690390975",
                        ["itemLink"] = 663,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set hide of the werewolf waist impenetrable",
            },
        },
        [161116] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_grayhost_staff_a.dds",
                ["itemDesc"] = "Inferno Staff of Eternal Vigor",
                ["oldestTime"] = 1632830328,
                ["wasAltered"] = true,
                ["newestTime"] = 1632830328,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 2134,
                        ["wasKiosk"] = true,
                        ["seller"] = 474,
                        ["timestamp"] = 1632830328,
                        ["quant"] = 1,
                        ["id"] = "1689000405",
                        ["itemLink"] = 3076,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set eternal vigor flame staff two-handed charged",
            },
        },
        [45917] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Gilane Garlicky Greens",
                ["oldestTime"] = 1633261617,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261617,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633261617,
                        ["quant"] = 1,
                        ["id"] = "1692334425",
                        ["itemLink"] = 2622,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [69215] = 
        {
            ["50:16:4:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_2hsword_d.dds",
                ["itemDesc"] = "Greatsword of Willpower",
                ["oldestTime"] = 1633165453,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165453,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1321,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633165453,
                        ["quant"] = 1,
                        ["id"] = "1691498301",
                        ["itemLink"] = 1838,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set willpower sword two-handed decisive",
            },
        },
        [126051] = 
        {
            ["50:16:5:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redoran_staff_a.dds",
                ["itemDesc"] = "Revus's Spare Staff of the War Maiden",
                ["oldestTime"] = 1633092703,
                ["wasAltered"] = true,
                ["newestTime"] = 1633092703,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 326613,
                        ["guild"] = 1,
                        ["buyer"] = 921,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633092703,
                        ["quant"] = 1,
                        ["id"] = "1690905397",
                        ["itemLink"] = 1246,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary weapon set war maiden lightning staff two-handed precise",
            },
        },
        [68197] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Tenmar Millet-Carrot Couscous",
                ["oldestTime"] = 1633094970,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305794,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20,
                        ["guild"] = 1,
                        ["buyer"] = 924,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633094970,
                        ["quant"] = 1,
                        ["id"] = "1690919037",
                        ["itemLink"] = 1256,
                    },
                    [2] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1345,
                        ["wasKiosk"] = true,
                        ["seller"] = 351,
                        ["timestamp"] = 1633172345,
                        ["quant"] = 1,
                        ["id"] = "1691532097",
                        ["itemLink"] = 1256,
                    },
                    [3] = 
                    {
                        ["price"] = 20,
                        ["guild"] = 1,
                        ["buyer"] = 1488,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633200466,
                        ["quant"] = 1,
                        ["id"] = "1691794573",
                        ["itemLink"] = 1256,
                    },
                    [4] = 
                    {
                        ["price"] = 27,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 78,
                        ["timestamp"] = 1633305794,
                        ["quant"] = 1,
                        ["id"] = "1692798279",
                        ["itemLink"] = 1256,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [147304] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Prophet's Robe",
                ["oldestTime"] = 1633172719,
                ["wasAltered"] = true,
                ["newestTime"] = 1633172719,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1346,
                        ["wasKiosk"] = true,
                        ["seller"] = 155,
                        ["timestamp"] = 1633172719,
                        ["quant"] = 1,
                        ["id"] = "1691534567",
                        ["itemLink"] = 1890,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [97129] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_shield_d.dds",
                ["itemDesc"] = "Plague Doctor's Shield",
                ["oldestTime"] = 1633067726,
                ["wasAltered"] = true,
                ["newestTime"] = 1633067726,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 765,
                        ["wasKiosk"] = false,
                        ["seller"] = 360,
                        ["timestamp"] = 1633067726,
                        ["quant"] = 1,
                        ["id"] = "1690765797",
                        ["itemLink"] = 1076,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic apparel weapon set plague doctor shield off hand impenetrable",
            },
        },
        [139628] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Alinor Potted Plant, Perpetual Bloom",
                ["oldestTime"] = 1632933268,
                ["wasAltered"] = true,
                ["newestTime"] = 1632933268,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 229999,
                        ["guild"] = 1,
                        ["buyer"] = 2523,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1632933268,
                        ["quant"] = 1,
                        ["id"] = "1689745939",
                        ["itemLink"] = 3721,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [135278] = 
        {
            ["50:16:2:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nocturnal_heavy_feet_a.dds",
                ["itemDesc"] = "Gloom-Graced Sabatons",
                ["oldestTime"] = 1632976082,
                ["wasAltered"] = true,
                ["newestTime"] = 1632976082,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 221,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1632976082,
                        ["quant"] = 1,
                        ["id"] = "1690103393",
                        ["itemLink"] = 237,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set grace of gloom feet invigorating",
            },
        },
        [123247] = 
        {
            ["50:16:4:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_heavy_waist_a.dds",
                ["itemDesc"] = "Vanguard's Challenge Girdle",
                ["oldestTime"] = 1633291922,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291922,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 365,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633291922,
                        ["quant"] = 1,
                        ["id"] = "1692651047",
                        ["itemLink"] = 2794,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set vanguard's challenge waist reinforced",
            },
        },
        [42864] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_fishing_perch.dds",
                ["itemDesc"] = "Silverside Perch",
                ["oldestTime"] = 1632884661,
                ["wasAltered"] = true,
                ["newestTime"] = 1633024181,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19800,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 218,
                        ["timestamp"] = 1633024181,
                        ["quant"] = 36,
                        ["id"] = "1690399485",
                        ["itemLink"] = 673,
                    },
                    [2] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 218,
                        ["timestamp"] = 1632884661,
                        ["quant"] = 20,
                        ["id"] = "1689447957",
                        ["itemLink"] = 673,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal consumable fish",
            },
        },
        [171890] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 103: Black Fin Legion Shoulders",
                ["oldestTime"] = 1632874426,
                ["wasAltered"] = true,
                ["newestTime"] = 1633021646,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 83000,
                        ["guild"] = 1,
                        ["buyer"] = 281,
                        ["wasKiosk"] = false,
                        ["seller"] = 274,
                        ["timestamp"] = 1633021646,
                        ["quant"] = 1,
                        ["id"] = "1690380453",
                        ["itemLink"] = 586,
                    },
                    [2] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 2318,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1632874426,
                        ["quant"] = 1,
                        ["id"] = "1689335135",
                        ["itemLink"] = 586,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [166772] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning3.dds",
                ["itemDesc"] = "Design: Vampiric Goblet, Fluted",
                ["oldestTime"] = 1633151535,
                ["wasAltered"] = true,
                ["newestTime"] = 1633151535,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1999,
                        ["guild"] = 1,
                        ["buyer"] = 1265,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633151535,
                        ["quant"] = 1,
                        ["id"] = "1691404745",
                        ["itemLink"] = 1729,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [176757] = 
        {
            ["1:0:3:39:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_restostaff.dds",
                ["itemDesc"] = "Companion's Restoration Staff",
                ["oldestTime"] = 1633290360,
                ["wasAltered"] = true,
                ["newestTime"] = 1633290360,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4100,
                        ["guild"] = 1,
                        ["buyer"] = 1981,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633290360,
                        ["quant"] = 1,
                        ["id"] = "1692631907",
                        ["itemLink"] = 2782,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior weapon healing staff two-handed soothing",
            },
        },
        [171894] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/style_item_blackfin.dds",
                ["itemDesc"] = "Marsh Nettle Sprig",
                ["oldestTime"] = 1632839173,
                ["wasAltered"] = true,
                ["newestTime"] = 1633280930,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 580,
                        ["guild"] = 1,
                        ["buyer"] = 207,
                        ["wasKiosk"] = false,
                        ["seller"] = 502,
                        ["timestamp"] = 1633040717,
                        ["quant"] = 1,
                        ["id"] = "1690518437",
                        ["itemLink"] = 798,
                    },
                    [2] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 387,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633179776,
                        ["quant"] = 13,
                        ["id"] = "1691583937",
                        ["itemLink"] = 798,
                    },
                    [3] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1380,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633183093,
                        ["quant"] = 1,
                        ["id"] = "1691613075",
                        ["itemLink"] = 798,
                    },
                    [4] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1380,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633183096,
                        ["quant"] = 1,
                        ["id"] = "1691613115",
                        ["itemLink"] = 798,
                    },
                    [5] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1823,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633252465,
                        ["quant"] = 1,
                        ["id"] = "1692288651",
                        ["itemLink"] = 798,
                    },
                    [6] = 
                    {
                        ["price"] = 990,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633280930,
                        ["quant"] = 2,
                        ["id"] = "1692524149",
                        ["itemLink"] = 798,
                    },
                    [7] = 
                    {
                        ["price"] = 690,
                        ["guild"] = 1,
                        ["buyer"] = 207,
                        ["wasKiosk"] = false,
                        ["seller"] = 333,
                        ["timestamp"] = 1632839173,
                        ["quant"] = 1,
                        ["id"] = "1689055713",
                        ["itemLink"] = 798,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [147320] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Sai Sahan's Bracers",
                ["oldestTime"] = 1632986582,
                ["wasAltered"] = true,
                ["newestTime"] = 1633194726,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 995,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 322,
                        ["timestamp"] = 1632986582,
                        ["quant"] = 3,
                        ["id"] = "1690167577",
                        ["itemLink"] = 327,
                    },
                    [2] = 
                    {
                        ["price"] = 332,
                        ["guild"] = 1,
                        ["buyer"] = 1445,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633194726,
                        ["quant"] = 1,
                        ["id"] = "1691740237",
                        ["itemLink"] = 327,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [68217] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Fredas Night Infusion",
                ["oldestTime"] = 1632854509,
                ["wasAltered"] = true,
                ["newestTime"] = 1632854509,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15,
                        ["guild"] = 1,
                        ["buyer"] = 2231,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632854509,
                        ["quant"] = 1,
                        ["id"] = "1689180601",
                        ["itemLink"] = 3262,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [147322] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Sai Sahan's Greatsword",
                ["oldestTime"] = 1633274182,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293805,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1334,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633274182,
                        ["quant"] = 1,
                        ["id"] = "1692453105",
                        ["itemLink"] = 2693,
                    },
                    [2] = 
                    {
                        ["price"] = 850,
                        ["guild"] = 1,
                        ["buyer"] = 2002,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1633293805,
                        ["quant"] = 1,
                        ["id"] = "1692673589",
                        ["itemLink"] = 2693,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [123004] = 
        {
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_hlaalu_medium_waist_a.dds",
                ["itemDesc"] = "Defiler's Belt",
                ["oldestTime"] = 1633193397,
                ["wasAltered"] = true,
                ["newestTime"] = 1633193397,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2213,
                        ["guild"] = 1,
                        ["buyer"] = 1435,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633193397,
                        ["quant"] = 1,
                        ["id"] = "1691728581",
                        ["itemLink"] = 2123,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set defiler waist infused",
            },
        },
        [127101] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing4.dds",
                ["itemDesc"] = "Diagram: Velothi Brazier, Temple",
                ["oldestTime"] = 1633135643,
                ["wasAltered"] = true,
                ["newestTime"] = 1633135643,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 219950,
                        ["guild"] = 1,
                        ["buyer"] = 1142,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633135643,
                        ["quant"] = 1,
                        ["id"] = "1691249537",
                        ["itemLink"] = 1560,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [71552] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 22: Trinimac Belts",
                ["oldestTime"] = 1632941324,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292049,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1477,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633199471,
                        ["quant"] = 1,
                        ["id"] = "1691783719",
                        ["itemLink"] = 2176,
                    },
                    [2] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 1987,
                        ["wasKiosk"] = true,
                        ["seller"] = 981,
                        ["timestamp"] = 1633292049,
                        ["quant"] = 1,
                        ["id"] = "1692652183",
                        ["itemLink"] = 2176,
                    },
                    [3] = 
                    {
                        ["price"] = 11500,
                        ["guild"] = 1,
                        ["buyer"] = 1872,
                        ["wasKiosk"] = true,
                        ["seller"] = 8,
                        ["timestamp"] = 1632941324,
                        ["quant"] = 1,
                        ["id"] = "1689804545",
                        ["itemLink"] = 2176,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [171906] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 101: Ivory Brigade Shields",
                ["oldestTime"] = 1633216041,
                ["wasAltered"] = true,
                ["newestTime"] = 1633240345,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 327,
                        ["wasKiosk"] = false,
                        ["seller"] = 108,
                        ["timestamp"] = 1633216041,
                        ["quant"] = 1,
                        ["id"] = "1691968959",
                        ["itemLink"] = 2317,
                    },
                    [2] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1654,
                        ["wasKiosk"] = true,
                        ["seller"] = 1082,
                        ["timestamp"] = 1633226622,
                        ["quant"] = 1,
                        ["id"] = "1692081367",
                        ["itemLink"] = 2317,
                    },
                    [3] = 
                    {
                        ["price"] = 9900,
                        ["guild"] = 1,
                        ["buyer"] = 1770,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633240345,
                        ["quant"] = 1,
                        ["id"] = "1692200161",
                        ["itemLink"] = 2317,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [71555] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 22: Trinimac Chests",
                ["oldestTime"] = 1632841261,
                ["wasAltered"] = true,
                ["newestTime"] = 1633246217,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 828,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1633066760,
                        ["quant"] = 1,
                        ["id"] = "1690760341",
                        ["itemLink"] = 1070,
                    },
                    [2] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1801,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633246217,
                        ["quant"] = 1,
                        ["id"] = "1692243991",
                        ["itemLink"] = 1070,
                    },
                    [3] = 
                    {
                        ["price"] = 49000,
                        ["guild"] = 1,
                        ["buyer"] = 2182,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632841261,
                        ["quant"] = 1,
                        ["id"] = "1689069275",
                        ["itemLink"] = 1070,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45956] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Crispy Cheddar Chicken",
                ["oldestTime"] = 1633127133,
                ["wasAltered"] = true,
                ["newestTime"] = 1633127133,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 76,
                        ["guild"] = 1,
                        ["buyer"] = 1090,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633127133,
                        ["quant"] = 1,
                        ["id"] = "1691159713",
                        ["itemLink"] = 1491,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [119429] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning3.dds",
                ["itemDesc"] = "Design: Ham, Display",
                ["oldestTime"] = 1633199014,
                ["wasAltered"] = true,
                ["newestTime"] = 1633199014,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2600,
                        ["guild"] = 1,
                        ["buyer"] = 1474,
                        ["wasKiosk"] = true,
                        ["seller"] = 252,
                        ["timestamp"] = 1633199014,
                        ["quant"] = 1,
                        ["id"] = "1691779343",
                        ["itemLink"] = 2172,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [180614] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_shield_a.dds",
                ["itemDesc"] = "Plaguebreak Shield",
                ["oldestTime"] = 1632836258,
                ["wasAltered"] = true,
                ["newestTime"] = 1632836258,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1790,
                        ["guild"] = 1,
                        ["buyer"] = 2160,
                        ["wasKiosk"] = true,
                        ["seller"] = 1112,
                        ["timestamp"] = 1632836258,
                        ["quant"] = 1,
                        ["id"] = "1689035939",
                        ["itemLink"] = 3108,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior apparel weapon set plaguebreak shield off hand infused",
            },
        },
        [171917] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 102: Sul-Xan Chests",
                ["oldestTime"] = 1633008442,
                ["wasAltered"] = true,
                ["newestTime"] = 1633204780,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400000,
                        ["guild"] = 1,
                        ["buyer"] = 437,
                        ["wasKiosk"] = true,
                        ["seller"] = 438,
                        ["timestamp"] = 1633008442,
                        ["quant"] = 1,
                        ["id"] = "1690279499",
                        ["itemLink"] = 447,
                    },
                    [2] = 
                    {
                        ["price"] = 375000,
                        ["guild"] = 1,
                        ["buyer"] = 950,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633101578,
                        ["quant"] = 1,
                        ["id"] = "1690969333",
                        ["itemLink"] = 447,
                    },
                    [3] = 
                    {
                        ["price"] = 250000,
                        ["guild"] = 1,
                        ["buyer"] = 1517,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633204780,
                        ["quant"] = 1,
                        ["id"] = "1691840413",
                        ["itemLink"] = 447,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [150671] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/item_u24_dragonstears.dds",
                ["itemDesc"] = "Dragon Rheum",
                ["oldestTime"] = 1632871859,
                ["wasAltered"] = true,
                ["newestTime"] = 1633194076,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 106500,
                        ["guild"] = 1,
                        ["buyer"] = 1104,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633130883,
                        ["quant"] = 30,
                        ["id"] = "1691194695",
                        ["itemLink"] = 1512,
                    },
                    [2] = 
                    {
                        ["price"] = 74000,
                        ["guild"] = 1,
                        ["buyer"] = 1224,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633144960,
                        ["quant"] = 20,
                        ["id"] = "1691346831",
                        ["itemLink"] = 1512,
                    },
                    [3] = 
                    {
                        ["price"] = 37920,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 9,
                        ["timestamp"] = 1633194076,
                        ["quant"] = 10,
                        ["id"] = "1691735693",
                        ["itemLink"] = 1512,
                    },
                    [4] = 
                    {
                        ["price"] = 37500,
                        ["guild"] = 1,
                        ["buyer"] = 151,
                        ["wasKiosk"] = false,
                        ["seller"] = 107,
                        ["timestamp"] = 1632871859,
                        ["quant"] = 10,
                        ["id"] = "1689315033",
                        ["itemLink"] = 1512,
                    },
                    [5] = 
                    {
                        ["price"] = 37500,
                        ["guild"] = 1,
                        ["buyer"] = 151,
                        ["wasKiosk"] = false,
                        ["seller"] = 107,
                        ["timestamp"] = 1632873991,
                        ["quant"] = 10,
                        ["id"] = "1689331145",
                        ["itemLink"] = 1512,
                    },
                    [6] = 
                    {
                        ["price"] = 19250,
                        ["guild"] = 1,
                        ["buyer"] = 151,
                        ["wasKiosk"] = false,
                        ["seller"] = 9,
                        ["timestamp"] = 1632873993,
                        ["quant"] = 5,
                        ["id"] = "1689331163",
                        ["itemLink"] = 1512,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [120831] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_cav_min_crystalformations_009.dds",
                ["itemDesc"] = "Blue Crystal Cluster",
                ["oldestTime"] = 1632966525,
                ["wasAltered"] = true,
                ["newestTime"] = 1632966525,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 2662,
                        ["wasKiosk"] = true,
                        ["seller"] = 283,
                        ["timestamp"] = 1632966525,
                        ["quant"] = 5,
                        ["id"] = "1690019867",
                        ["itemLink"] = 3968,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [45039] = 
        {
            ["50:16:2:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_light_waist_d.dds",
                ["itemDesc"] = "Ancestor Silk Sash of Health",
                ["oldestTime"] = 1632962690,
                ["wasAltered"] = true,
                ["newestTime"] = 1632962690,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 425,
                        ["guild"] = 1,
                        ["buyer"] = 2643,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1632962690,
                        ["quant"] = 1,
                        ["id"] = "1689981845",
                        ["itemLink"] = 3935,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel waist sturdy",
            },
        },
        [149097] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_heavy_legs_a.dds",
                ["itemDesc"] = "Undertaker's Greaves",
                ["oldestTime"] = 1632957835,
                ["wasAltered"] = true,
                ["newestTime"] = 1632957835,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1700,
                        ["guild"] = 1,
                        ["buyer"] = 2617,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1632957835,
                        ["quant"] = 1,
                        ["id"] = "1689941875",
                        ["itemLink"] = 3905,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set call of the undertaker legs divines",
            },
        },
        [176020] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Plates, Stack",
                ["oldestTime"] = 1633060368,
                ["wasAltered"] = true,
                ["newestTime"] = 1633060368,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22850,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 226,
                        ["timestamp"] = 1633060368,
                        ["quant"] = 1,
                        ["id"] = "1690713425",
                        ["itemLink"] = 1011,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [159472] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Style Page: Jephrine Paladin Helm",
                ["oldestTime"] = 1632953417,
                ["wasAltered"] = true,
                ["newestTime"] = 1632953417,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2603,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632953417,
                        ["quant"] = 1,
                        ["id"] = "1689905021",
                        ["itemLink"] = 3858,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [115868] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning3.dds",
                ["itemDesc"] = "Design: Wood Elf Cauldron, Ceramic",
                ["oldestTime"] = 1632952368,
                ["wasAltered"] = true,
                ["newestTime"] = 1632952368,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1223,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632952368,
                        ["quant"] = 1,
                        ["id"] = "1689895243",
                        ["itemLink"] = 3848,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [23219] = 
        {
            ["1:0:1:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_jewelry_base_diamond_r3.dds",
                ["itemDesc"] = "Diamond",
                ["oldestTime"] = 1632861538,
                ["wasAltered"] = true,
                ["newestTime"] = 1632861538,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632861538,
                        ["quant"] = 200,
                        ["id"] = "1689241399",
                        ["itemLink"] = 3300,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials armor trait impenetrable",
            },
        },
        [23173] = 
        {
            ["1:0:1:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_accessory_sp_names_001.dds",
                ["itemDesc"] = "Sapphire",
                ["oldestTime"] = 1633188147,
                ["wasAltered"] = true,
                ["newestTime"] = 1633188147,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1404,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633188147,
                        ["quant"] = 50,
                        ["id"] = "1691667087",
                        ["itemLink"] = 2084,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials armor trait divines",
            },
        },
        [99993] = 
        {
            ["50:16:2:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_heavy_chest_a.dds",
                ["itemDesc"] = "Thunderbug's Cuirass",
                ["oldestTime"] = 1632984124,
                ["wasAltered"] = true,
                ["newestTime"] = 1632984124,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2499,
                        ["guild"] = 1,
                        ["buyer"] = 304,
                        ["wasKiosk"] = true,
                        ["seller"] = 305,
                        ["timestamp"] = 1632984124,
                        ["quant"] = 1,
                        ["id"] = "1690154837",
                        ["itemLink"] = 307,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set thunderbug's carapace chest training",
            },
        },
        [54170] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_ores_lazurite.dds",
                ["itemDesc"] = "Honing Stone",
                ["oldestTime"] = 1632848318,
                ["wasAltered"] = true,
                ["newestTime"] = 1633219265,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2600,
                        ["guild"] = 1,
                        ["buyer"] = 387,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633179778,
                        ["quant"] = 200,
                        ["id"] = "1691583941",
                        ["itemLink"] = 1921,
                    },
                    [2] = 
                    {
                        ["price"] = 398,
                        ["guild"] = 1,
                        ["buyer"] = 1605,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1633219264,
                        ["quant"] = 20,
                        ["id"] = "1692005195",
                        ["itemLink"] = 1921,
                    },
                    [3] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1605,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1633219265,
                        ["quant"] = 200,
                        ["id"] = "1692005203",
                        ["itemLink"] = 1921,
                    },
                    [4] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 1781,
                        ["timestamp"] = 1632848318,
                        ["quant"] = 7,
                        ["id"] = "1689130751",
                        ["itemLink"] = 1921,
                    },
                    [5] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 1781,
                        ["timestamp"] = 1632848319,
                        ["quant"] = 7,
                        ["id"] = "1689130757",
                        ["itemLink"] = 1921,
                    },
                    [6] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 1781,
                        ["timestamp"] = 1632848321,
                        ["quant"] = 7,
                        ["id"] = "1689130769",
                        ["itemLink"] = 1921,
                    },
                    [7] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 1781,
                        ["timestamp"] = 1632848322,
                        ["quant"] = 7,
                        ["id"] = "1689130783",
                        ["itemLink"] = 1921,
                    },
                    [8] = 
                    {
                        ["price"] = 398,
                        ["guild"] = 1,
                        ["buyer"] = 2614,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1632956234,
                        ["quant"] = 20,
                        ["id"] = "1689929815",
                        ["itemLink"] = 1921,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "rr01 green fine materials temper",
            },
        },
        [180635] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_medium_chest_a.dds",
                ["itemDesc"] = "Plaguebreak Jack",
                ["oldestTime"] = 1633312829,
                ["wasAltered"] = true,
                ["newestTime"] = 1633312829,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2323,
                        ["guild"] = 1,
                        ["buyer"] = 39,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633312829,
                        ["quant"] = 1,
                        ["id"] = "1692878807",
                        ["itemLink"] = 30,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set plaguebreak chest divines",
            },
        },
        [54172] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_forester_potion_vendor_001.dds",
                ["itemDesc"] = "Grain Solvent",
                ["oldestTime"] = 1632819683,
                ["wasAltered"] = true,
                ["newestTime"] = 1633263195,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 436,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633118364,
                        ["quant"] = 4,
                        ["id"] = "1691094143",
                        ["itemLink"] = 1421,
                    },
                    [2] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 436,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633118366,
                        ["quant"] = 4,
                        ["id"] = "1691094165",
                        ["itemLink"] = 1421,
                    },
                    [3] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 436,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633118367,
                        ["quant"] = 4,
                        ["id"] = "1691094185",
                        ["itemLink"] = 1421,
                    },
                    [4] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 436,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633118368,
                        ["quant"] = 4,
                        ["id"] = "1691094193",
                        ["itemLink"] = 1421,
                    },
                    [5] = 
                    {
                        ["price"] = 8060,
                        ["guild"] = 1,
                        ["buyer"] = 1069,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633123194,
                        ["quant"] = 13,
                        ["id"] = "1691128903",
                        ["itemLink"] = 1421,
                    },
                    [6] = 
                    {
                        ["price"] = 27300,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 199,
                        ["timestamp"] = 1633165277,
                        ["quant"] = 42,
                        ["id"] = "1691497251",
                        ["itemLink"] = 1421,
                    },
                    [7] = 
                    {
                        ["price"] = 13200,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 276,
                        ["timestamp"] = 1633165277,
                        ["quant"] = 20,
                        ["id"] = "1691497253",
                        ["itemLink"] = 1421,
                    },
                    [8] = 
                    {
                        ["price"] = 55920,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 402,
                        ["timestamp"] = 1633165277,
                        ["quant"] = 80,
                        ["id"] = "1691497255",
                        ["itemLink"] = 1421,
                    },
                    [9] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 46,
                        ["timestamp"] = 1633165278,
                        ["quant"] = 50,
                        ["id"] = "1691497257",
                        ["itemLink"] = 1421,
                    },
                    [10] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 1717,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633233744,
                        ["quant"] = 20,
                        ["id"] = "1692152135",
                        ["itemLink"] = 1421,
                    },
                    [11] = 
                    {
                        ["price"] = 540,
                        ["guild"] = 1,
                        ["buyer"] = 1844,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633263195,
                        ["quant"] = 1,
                        ["id"] = "1692343789",
                        ["itemLink"] = 1421,
                    },
                    [12] = 
                    {
                        ["price"] = 41472,
                        ["guild"] = 1,
                        ["buyer"] = 285,
                        ["wasKiosk"] = false,
                        ["seller"] = 944,
                        ["timestamp"] = 1632819683,
                        ["quant"] = 64,
                        ["id"] = "1688942019",
                        ["itemLink"] = 1421,
                    },
                    [13] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 2102,
                        ["wasKiosk"] = true,
                        ["seller"] = 1781,
                        ["timestamp"] = 1632820351,
                        ["quant"] = 2,
                        ["id"] = "1688945667",
                        ["itemLink"] = 1421,
                    },
                    [14] = 
                    {
                        ["price"] = 195000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 1318,
                        ["timestamp"] = 1632848307,
                        ["quant"] = 200,
                        ["id"] = "1689130641",
                        ["itemLink"] = 1421,
                    },
                    [15] = 
                    {
                        ["price"] = 139800,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 402,
                        ["timestamp"] = 1632848309,
                        ["quant"] = 200,
                        ["id"] = "1689130661",
                        ["itemLink"] = 1421,
                    },
                    [16] = 
                    {
                        ["price"] = 131569,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1632848311,
                        ["quant"] = 200,
                        ["id"] = "1689130691",
                        ["itemLink"] = 1421,
                    },
                    [17] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632848323,
                        ["quant"] = 50,
                        ["id"] = "1689130797",
                        ["itemLink"] = 1421,
                    },
                    [18] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 224,
                        ["timestamp"] = 1632848326,
                        ["quant"] = 10,
                        ["id"] = "1689130817",
                        ["itemLink"] = 1421,
                    },
                    [19] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 2422,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1632892408,
                        ["quant"] = 10,
                        ["id"] = "1689511993",
                        ["itemLink"] = 1421,
                    },
                    [20] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 2422,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1632892409,
                        ["quant"] = 10,
                        ["id"] = "1689511997",
                        ["itemLink"] = 1421,
                    },
                    [21] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 2422,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1632892409,
                        ["quant"] = 10,
                        ["id"] = "1689512003",
                        ["itemLink"] = 1421,
                    },
                    [22] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 2422,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1632892410,
                        ["quant"] = 10,
                        ["id"] = "1689512007",
                        ["itemLink"] = 1421,
                    },
                    [23] = 
                    {
                        ["price"] = 5315,
                        ["guild"] = 1,
                        ["buyer"] = 2519,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1632931454,
                        ["quant"] = 8,
                        ["id"] = "1689732255",
                        ["itemLink"] = 1421,
                    },
                    [24] = 
                    {
                        ["price"] = 5315,
                        ["guild"] = 1,
                        ["buyer"] = 2519,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1632931456,
                        ["quant"] = 8,
                        ["id"] = "1689732277",
                        ["itemLink"] = 1421,
                    },
                },
                ["totalCount"] = 24,
                ["itemAdderText"] = "rr01 purple epic materials temper",
            },
        },
        [54173] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_tempering_alloy.dds",
                ["itemDesc"] = "Tempering Alloy",
                ["oldestTime"] = 1632819744,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311924,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 91000,
                        ["guild"] = 1,
                        ["buyer"] = 29,
                        ["wasKiosk"] = true,
                        ["seller"] = 31,
                        ["timestamp"] = 1633311924,
                        ["quant"] = 10,
                        ["id"] = "1692868851",
                        ["itemLink"] = 21,
                    },
                    [2] = 
                    {
                        ["price"] = 35200,
                        ["guild"] = 1,
                        ["buyer"] = 346,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632990045,
                        ["quant"] = 4,
                        ["id"] = "1690187347",
                        ["itemLink"] = 21,
                    },
                    [3] = 
                    {
                        ["price"] = 35200,
                        ["guild"] = 1,
                        ["buyer"] = 368,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632993546,
                        ["quant"] = 4,
                        ["id"] = "1690203369",
                        ["itemLink"] = 21,
                    },
                    [4] = 
                    {
                        ["price"] = 35200,
                        ["guild"] = 1,
                        ["buyer"] = 368,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632993549,
                        ["quant"] = 4,
                        ["id"] = "1690203377",
                        ["itemLink"] = 21,
                    },
                    [5] = 
                    {
                        ["price"] = 35200,
                        ["guild"] = 1,
                        ["buyer"] = 368,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632993552,
                        ["quant"] = 4,
                        ["id"] = "1690203397",
                        ["itemLink"] = 21,
                    },
                    [6] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 210,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633010330,
                        ["quant"] = 3,
                        ["id"] = "1690292581",
                        ["itemLink"] = 21,
                    },
                    [7] = 
                    {
                        ["price"] = 8950,
                        ["guild"] = 1,
                        ["buyer"] = 740,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633054649,
                        ["quant"] = 1,
                        ["id"] = "1690651335",
                        ["itemLink"] = 21,
                    },
                    [8] = 
                    {
                        ["price"] = 8950,
                        ["guild"] = 1,
                        ["buyer"] = 740,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633054649,
                        ["quant"] = 1,
                        ["id"] = "1690651341",
                        ["itemLink"] = 21,
                    },
                    [9] = 
                    {
                        ["price"] = 8950,
                        ["guild"] = 1,
                        ["buyer"] = 740,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633054650,
                        ["quant"] = 1,
                        ["id"] = "1690651349",
                        ["itemLink"] = 21,
                    },
                    [10] = 
                    {
                        ["price"] = 8950,
                        ["guild"] = 1,
                        ["buyer"] = 740,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633054651,
                        ["quant"] = 1,
                        ["id"] = "1690651353",
                        ["itemLink"] = 21,
                    },
                    [11] = 
                    {
                        ["price"] = 8950,
                        ["guild"] = 1,
                        ["buyer"] = 740,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633054651,
                        ["quant"] = 1,
                        ["id"] = "1690651355",
                        ["itemLink"] = 21,
                    },
                    [12] = 
                    {
                        ["price"] = 8950,
                        ["guild"] = 1,
                        ["buyer"] = 740,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633054652,
                        ["quant"] = 1,
                        ["id"] = "1690651361",
                        ["itemLink"] = 21,
                    },
                    [13] = 
                    {
                        ["price"] = 8950,
                        ["guild"] = 1,
                        ["buyer"] = 740,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633054652,
                        ["quant"] = 1,
                        ["id"] = "1690651365",
                        ["itemLink"] = 21,
                    },
                    [14] = 
                    {
                        ["price"] = 8950,
                        ["guild"] = 1,
                        ["buyer"] = 740,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633054652,
                        ["quant"] = 1,
                        ["id"] = "1690651367",
                        ["itemLink"] = 21,
                    },
                    [15] = 
                    {
                        ["price"] = 8950,
                        ["guild"] = 1,
                        ["buyer"] = 740,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633054653,
                        ["quant"] = 1,
                        ["id"] = "1690651373",
                        ["itemLink"] = 21,
                    },
                    [16] = 
                    {
                        ["price"] = 8950,
                        ["guild"] = 1,
                        ["buyer"] = 740,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633054653,
                        ["quant"] = 1,
                        ["id"] = "1690651377",
                        ["itemLink"] = 21,
                    },
                    [17] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633057002,
                        ["quant"] = 1,
                        ["id"] = "1690678661",
                        ["itemLink"] = 21,
                    },
                    [18] = 
                    {
                        ["price"] = 36800,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633057002,
                        ["quant"] = 4,
                        ["id"] = "1690678677",
                        ["itemLink"] = 21,
                    },
                    [19] = 
                    {
                        ["price"] = 27600,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 763,
                        ["timestamp"] = 1633057003,
                        ["quant"] = 3,
                        ["id"] = "1690678691",
                        ["itemLink"] = 21,
                    },
                    [20] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633073858,
                        ["quant"] = 1,
                        ["id"] = "1690803755",
                        ["itemLink"] = 21,
                    },
                    [21] = 
                    {
                        ["price"] = 93500,
                        ["guild"] = 1,
                        ["buyer"] = 875,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1633082423,
                        ["quant"] = 10,
                        ["id"] = "1690846277",
                        ["itemLink"] = 21,
                    },
                    [22] = 
                    {
                        ["price"] = 18713,
                        ["guild"] = 1,
                        ["buyer"] = 875,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633082424,
                        ["quant"] = 2,
                        ["id"] = "1690846281",
                        ["itemLink"] = 21,
                    },
                    [23] = 
                    {
                        ["price"] = 28170,
                        ["guild"] = 1,
                        ["buyer"] = 875,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633082427,
                        ["quant"] = 3,
                        ["id"] = "1690846289",
                        ["itemLink"] = 21,
                    },
                    [24] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 943,
                        ["wasKiosk"] = true,
                        ["seller"] = 944,
                        ["timestamp"] = 1633100237,
                        ["quant"] = 1,
                        ["id"] = "1690959123",
                        ["itemLink"] = 21,
                    },
                    [25] = 
                    {
                        ["price"] = 37600,
                        ["guild"] = 1,
                        ["buyer"] = 943,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633100238,
                        ["quant"] = 4,
                        ["id"] = "1690959137",
                        ["itemLink"] = 21,
                    },
                    [26] = 
                    {
                        ["price"] = 18200,
                        ["guild"] = 1,
                        ["buyer"] = 1087,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633126495,
                        ["quant"] = 2,
                        ["id"] = "1691153993",
                        ["itemLink"] = 21,
                    },
                    [27] = 
                    {
                        ["price"] = 18200,
                        ["guild"] = 1,
                        ["buyer"] = 1087,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633126496,
                        ["quant"] = 2,
                        ["id"] = "1691153997",
                        ["itemLink"] = 21,
                    },
                    [28] = 
                    {
                        ["price"] = 18200,
                        ["guild"] = 1,
                        ["buyer"] = 1087,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633126496,
                        ["quant"] = 2,
                        ["id"] = "1691153999",
                        ["itemLink"] = 21,
                    },
                    [29] = 
                    {
                        ["price"] = 18200,
                        ["guild"] = 1,
                        ["buyer"] = 1087,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633126496,
                        ["quant"] = 2,
                        ["id"] = "1691154005",
                        ["itemLink"] = 21,
                    },
                    [30] = 
                    {
                        ["price"] = 18200,
                        ["guild"] = 1,
                        ["buyer"] = 1087,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633126497,
                        ["quant"] = 2,
                        ["id"] = "1691154007",
                        ["itemLink"] = 21,
                    },
                    [31] = 
                    {
                        ["price"] = 18665,
                        ["guild"] = 1,
                        ["buyer"] = 1087,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633126497,
                        ["quant"] = 2,
                        ["id"] = "1691154011",
                        ["itemLink"] = 21,
                    },
                    [32] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 1087,
                        ["wasKiosk"] = true,
                        ["seller"] = 590,
                        ["timestamp"] = 1633126498,
                        ["quant"] = 2,
                        ["id"] = "1691154019",
                        ["itemLink"] = 21,
                    },
                    [33] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 1087,
                        ["wasKiosk"] = true,
                        ["seller"] = 590,
                        ["timestamp"] = 1633126498,
                        ["quant"] = 2,
                        ["id"] = "1691154031",
                        ["itemLink"] = 21,
                    },
                    [34] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 1087,
                        ["wasKiosk"] = true,
                        ["seller"] = 590,
                        ["timestamp"] = 1633126499,
                        ["quant"] = 2,
                        ["id"] = "1691154033",
                        ["itemLink"] = 21,
                    },
                    [35] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 1087,
                        ["wasKiosk"] = true,
                        ["seller"] = 590,
                        ["timestamp"] = 1633126500,
                        ["quant"] = 2,
                        ["id"] = "1691154041",
                        ["itemLink"] = 21,
                    },
                    [36] = 
                    {
                        ["price"] = 532000,
                        ["guild"] = 1,
                        ["buyer"] = 1087,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633126503,
                        ["quant"] = 56,
                        ["id"] = "1691154057",
                        ["itemLink"] = 21,
                    },
                    [37] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633144646,
                        ["quant"] = 2,
                        ["id"] = "1691343997",
                        ["itemLink"] = 21,
                    },
                    [38] = 
                    {
                        ["price"] = 89990,
                        ["guild"] = 1,
                        ["buyer"] = 1233,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1633147311,
                        ["quant"] = 10,
                        ["id"] = "1691368525",
                        ["itemLink"] = 21,
                    },
                    [39] = 
                    {
                        ["price"] = 90000,
                        ["guild"] = 1,
                        ["buyer"] = 1233,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633147312,
                        ["quant"] = 10,
                        ["id"] = "1691368531",
                        ["itemLink"] = 21,
                    },
                    [40] = 
                    {
                        ["price"] = 90000,
                        ["guild"] = 1,
                        ["buyer"] = 1233,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633147312,
                        ["quant"] = 10,
                        ["id"] = "1691368533",
                        ["itemLink"] = 21,
                    },
                    [41] = 
                    {
                        ["price"] = 92000,
                        ["guild"] = 1,
                        ["buyer"] = 1233,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633147314,
                        ["quant"] = 10,
                        ["id"] = "1691368541",
                        ["itemLink"] = 21,
                    },
                    [42] = 
                    {
                        ["price"] = 8398,
                        ["guild"] = 1,
                        ["buyer"] = 26,
                        ["wasKiosk"] = false,
                        ["seller"] = 95,
                        ["timestamp"] = 1633153397,
                        ["quant"] = 1,
                        ["id"] = "1691418909",
                        ["itemLink"] = 21,
                    },
                    [43] = 
                    {
                        ["price"] = 33592,
                        ["guild"] = 1,
                        ["buyer"] = 26,
                        ["wasKiosk"] = false,
                        ["seller"] = 95,
                        ["timestamp"] = 1633153397,
                        ["quant"] = 4,
                        ["id"] = "1691418915",
                        ["itemLink"] = 21,
                    },
                    [44] = 
                    {
                        ["price"] = 33592,
                        ["guild"] = 1,
                        ["buyer"] = 26,
                        ["wasKiosk"] = false,
                        ["seller"] = 95,
                        ["timestamp"] = 1633153402,
                        ["quant"] = 4,
                        ["id"] = "1691418933",
                        ["itemLink"] = 21,
                    },
                    [45] = 
                    {
                        ["price"] = 8398,
                        ["guild"] = 1,
                        ["buyer"] = 26,
                        ["wasKiosk"] = false,
                        ["seller"] = 95,
                        ["timestamp"] = 1633153404,
                        ["quant"] = 1,
                        ["id"] = "1691418941",
                        ["itemLink"] = 21,
                    },
                    [46] = 
                    {
                        ["price"] = 8398,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633163427,
                        ["quant"] = 1,
                        ["id"] = "1691488107",
                        ["itemLink"] = 21,
                    },
                    [47] = 
                    {
                        ["price"] = 92000,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633163452,
                        ["quant"] = 10,
                        ["id"] = "1691488341",
                        ["itemLink"] = 21,
                    },
                    [48] = 
                    {
                        ["price"] = 9100,
                        ["guild"] = 1,
                        ["buyer"] = 1365,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1633180532,
                        ["quant"] = 1,
                        ["id"] = "1691588775",
                        ["itemLink"] = 21,
                    },
                    [49] = 
                    {
                        ["price"] = 9100,
                        ["guild"] = 1,
                        ["buyer"] = 1365,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1633180535,
                        ["quant"] = 1,
                        ["id"] = "1691588785",
                        ["itemLink"] = 21,
                    },
                    [50] = 
                    {
                        ["price"] = 9100,
                        ["guild"] = 1,
                        ["buyer"] = 1399,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1633186706,
                        ["quant"] = 1,
                        ["id"] = "1691649261",
                        ["itemLink"] = 21,
                    },
                    [51] = 
                    {
                        ["price"] = 75200,
                        ["guild"] = 1,
                        ["buyer"] = 1530,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633206413,
                        ["quant"] = 8,
                        ["id"] = "1691860551",
                        ["itemLink"] = 21,
                    },
                    [52] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 1458,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633227302,
                        ["quant"] = 8,
                        ["id"] = "1692088255",
                        ["itemLink"] = 21,
                    },
                    [53] = 
                    {
                        ["price"] = 72000,
                        ["guild"] = 1,
                        ["buyer"] = 1458,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633227304,
                        ["quant"] = 8,
                        ["id"] = "1692088277",
                        ["itemLink"] = 21,
                    },
                    [54] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 1399,
                        ["wasKiosk"] = true,
                        ["seller"] = 763,
                        ["timestamp"] = 1633229368,
                        ["quant"] = 3,
                        ["id"] = "1692109809",
                        ["itemLink"] = 21,
                    },
                    [55] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1399,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633229369,
                        ["quant"] = 1,
                        ["id"] = "1692109813",
                        ["itemLink"] = 21,
                    },
                    [56] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1399,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633229369,
                        ["quant"] = 1,
                        ["id"] = "1692109819",
                        ["itemLink"] = 21,
                    },
                    [57] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1399,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633229370,
                        ["quant"] = 1,
                        ["id"] = "1692109841",
                        ["itemLink"] = 21,
                    },
                    [58] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1399,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633229371,
                        ["quant"] = 1,
                        ["id"] = "1692109847",
                        ["itemLink"] = 21,
                    },
                    [59] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1399,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633229372,
                        ["quant"] = 1,
                        ["id"] = "1692109855",
                        ["itemLink"] = 21,
                    },
                    [60] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1399,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633229372,
                        ["quant"] = 1,
                        ["id"] = "1692109863",
                        ["itemLink"] = 21,
                    },
                    [61] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1399,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1633229373,
                        ["quant"] = 1,
                        ["id"] = "1692109871",
                        ["itemLink"] = 21,
                    },
                    [62] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1399,
                        ["wasKiosk"] = true,
                        ["seller"] = 944,
                        ["timestamp"] = 1633229374,
                        ["quant"] = 1,
                        ["id"] = "1692109877",
                        ["itemLink"] = 21,
                    },
                    [63] = 
                    {
                        ["price"] = 1900000,
                        ["guild"] = 1,
                        ["buyer"] = 1026,
                        ["wasKiosk"] = true,
                        ["seller"] = 82,
                        ["timestamp"] = 1633231364,
                        ["quant"] = 200,
                        ["id"] = "1692127483",
                        ["itemLink"] = 21,
                    },
                    [64] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1729,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633235604,
                        ["quant"] = 1,
                        ["id"] = "1692165155",
                        ["itemLink"] = 21,
                    },
                    [65] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1729,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633235606,
                        ["quant"] = 1,
                        ["id"] = "1692165163",
                        ["itemLink"] = 21,
                    },
                    [66] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1729,
                        ["wasKiosk"] = true,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633235611,
                        ["quant"] = 1,
                        ["id"] = "1692165185",
                        ["itemLink"] = 21,
                    },
                    [67] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 344,
                        ["wasKiosk"] = false,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633238010,
                        ["quant"] = 1,
                        ["id"] = "1692185699",
                        ["itemLink"] = 21,
                    },
                    [68] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 344,
                        ["wasKiosk"] = false,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633238012,
                        ["quant"] = 1,
                        ["id"] = "1692185709",
                        ["itemLink"] = 21,
                    },
                    [69] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 344,
                        ["wasKiosk"] = false,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633238014,
                        ["quant"] = 1,
                        ["id"] = "1692185723",
                        ["itemLink"] = 21,
                    },
                    [70] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 344,
                        ["wasKiosk"] = false,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633238016,
                        ["quant"] = 1,
                        ["id"] = "1692185745",
                        ["itemLink"] = 21,
                    },
                    [71] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 344,
                        ["wasKiosk"] = false,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633238019,
                        ["quant"] = 1,
                        ["id"] = "1692185789",
                        ["itemLink"] = 21,
                    },
                    [72] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 344,
                        ["wasKiosk"] = false,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633238019,
                        ["quant"] = 1,
                        ["id"] = "1692185801",
                        ["itemLink"] = 21,
                    },
                    [73] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 344,
                        ["wasKiosk"] = false,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633238021,
                        ["quant"] = 1,
                        ["id"] = "1692185831",
                        ["itemLink"] = 21,
                    },
                    [74] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 344,
                        ["wasKiosk"] = false,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633238024,
                        ["quant"] = 1,
                        ["id"] = "1692185883",
                        ["itemLink"] = 21,
                    },
                    [75] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 344,
                        ["wasKiosk"] = false,
                        ["seller"] = 1730,
                        ["timestamp"] = 1633238027,
                        ["quant"] = 1,
                        ["id"] = "1692185911",
                        ["itemLink"] = 21,
                    },
                    [76] = 
                    {
                        ["price"] = 16796,
                        ["guild"] = 1,
                        ["buyer"] = 1751,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633238438,
                        ["quant"] = 2,
                        ["id"] = "1692188375",
                        ["itemLink"] = 21,
                    },
                    [77] = 
                    {
                        ["price"] = 684000,
                        ["guild"] = 1,
                        ["buyer"] = 408,
                        ["wasKiosk"] = false,
                        ["seller"] = 151,
                        ["timestamp"] = 1633244746,
                        ["quant"] = 72,
                        ["id"] = "1692231941",
                        ["itemLink"] = 21,
                    },
                    [78] = 
                    {
                        ["price"] = 500000,
                        ["guild"] = 1,
                        ["buyer"] = 408,
                        ["wasKiosk"] = false,
                        ["seller"] = 722,
                        ["timestamp"] = 1633244771,
                        ["quant"] = 50,
                        ["id"] = "1692232121",
                        ["itemLink"] = 21,
                    },
                    [79] = 
                    {
                        ["price"] = 500000,
                        ["guild"] = 1,
                        ["buyer"] = 408,
                        ["wasKiosk"] = false,
                        ["seller"] = 722,
                        ["timestamp"] = 1633244773,
                        ["quant"] = 50,
                        ["id"] = "1692232125",
                        ["itemLink"] = 21,
                    },
                    [80] = 
                    {
                        ["price"] = 500000,
                        ["guild"] = 1,
                        ["buyer"] = 408,
                        ["wasKiosk"] = false,
                        ["seller"] = 722,
                        ["timestamp"] = 1633244774,
                        ["quant"] = 50,
                        ["id"] = "1692232133",
                        ["itemLink"] = 21,
                    },
                    [81] = 
                    {
                        ["price"] = 500000,
                        ["guild"] = 1,
                        ["buyer"] = 408,
                        ["wasKiosk"] = false,
                        ["seller"] = 722,
                        ["timestamp"] = 1633244775,
                        ["quant"] = 50,
                        ["id"] = "1692232153",
                        ["itemLink"] = 21,
                    },
                    [82] = 
                    {
                        ["price"] = 91000,
                        ["guild"] = 1,
                        ["buyer"] = 1795,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633245117,
                        ["quant"] = 10,
                        ["id"] = "1692234291",
                        ["itemLink"] = 21,
                    },
                    [83] = 
                    {
                        ["price"] = 91000,
                        ["guild"] = 1,
                        ["buyer"] = 1795,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633245118,
                        ["quant"] = 10,
                        ["id"] = "1692234299",
                        ["itemLink"] = 21,
                    },
                    [84] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 1795,
                        ["wasKiosk"] = true,
                        ["seller"] = 33,
                        ["timestamp"] = 1633245120,
                        ["quant"] = 3,
                        ["id"] = "1692234307",
                        ["itemLink"] = 21,
                    },
                    [85] = 
                    {
                        ["price"] = 74999,
                        ["guild"] = 1,
                        ["buyer"] = 1795,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633245121,
                        ["quant"] = 8,
                        ["id"] = "1692234325",
                        ["itemLink"] = 21,
                    },
                    [86] = 
                    {
                        ["price"] = 8398,
                        ["guild"] = 1,
                        ["buyer"] = 1795,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633245123,
                        ["quant"] = 1,
                        ["id"] = "1692234339",
                        ["itemLink"] = 21,
                    },
                    [87] = 
                    {
                        ["price"] = 74999,
                        ["guild"] = 1,
                        ["buyer"] = 1795,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633245124,
                        ["quant"] = 8,
                        ["id"] = "1692234347",
                        ["itemLink"] = 21,
                    },
                    [88] = 
                    {
                        ["price"] = 28200,
                        ["guild"] = 1,
                        ["buyer"] = 1795,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633245126,
                        ["quant"] = 3,
                        ["id"] = "1692234361",
                        ["itemLink"] = 21,
                    },
                    [89] = 
                    {
                        ["price"] = 75200,
                        ["guild"] = 1,
                        ["buyer"] = 1795,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633245127,
                        ["quant"] = 8,
                        ["id"] = "1692234375",
                        ["itemLink"] = 21,
                    },
                    [90] = 
                    {
                        ["price"] = 47000,
                        ["guild"] = 1,
                        ["buyer"] = 1795,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633245129,
                        ["quant"] = 5,
                        ["id"] = "1692234385",
                        ["itemLink"] = 21,
                    },
                    [91] = 
                    {
                        ["price"] = 37799,
                        ["guild"] = 1,
                        ["buyer"] = 1795,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633245131,
                        ["quant"] = 4,
                        ["id"] = "1692234393",
                        ["itemLink"] = 21,
                    },
                    [92] = 
                    {
                        ["price"] = 37799,
                        ["guild"] = 1,
                        ["buyer"] = 1795,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633245133,
                        ["quant"] = 4,
                        ["id"] = "1692234411",
                        ["itemLink"] = 21,
                    },
                    [93] = 
                    {
                        ["price"] = 19000,
                        ["guild"] = 1,
                        ["buyer"] = 1795,
                        ["wasKiosk"] = true,
                        ["seller"] = 1480,
                        ["timestamp"] = 1633245134,
                        ["quant"] = 2,
                        ["id"] = "1692234419",
                        ["itemLink"] = 21,
                    },
                    [94] = 
                    {
                        ["price"] = 76000,
                        ["guild"] = 1,
                        ["buyer"] = 1795,
                        ["wasKiosk"] = true,
                        ["seller"] = 603,
                        ["timestamp"] = 1633245136,
                        ["quant"] = 8,
                        ["id"] = "1692234433",
                        ["itemLink"] = 21,
                    },
                    [95] = 
                    {
                        ["price"] = 76000,
                        ["guild"] = 1,
                        ["buyer"] = 1795,
                        ["wasKiosk"] = true,
                        ["seller"] = 603,
                        ["timestamp"] = 1633245137,
                        ["quant"] = 8,
                        ["id"] = "1692234439",
                        ["itemLink"] = 21,
                    },
                    [96] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633280951,
                        ["quant"] = 1,
                        ["id"] = "1692524393",
                        ["itemLink"] = 21,
                    },
                    [97] = 
                    {
                        ["price"] = 36000,
                        ["guild"] = 1,
                        ["buyer"] = 1965,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633293009,
                        ["quant"] = 4,
                        ["id"] = "1692662945",
                        ["itemLink"] = 21,
                    },
                    [98] = 
                    {
                        ["price"] = 8398,
                        ["guild"] = 1,
                        ["buyer"] = 2069,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633306209,
                        ["quant"] = 1,
                        ["id"] = "1692801637",
                        ["itemLink"] = 21,
                    },
                    [99] = 
                    {
                        ["price"] = 8398,
                        ["guild"] = 1,
                        ["buyer"] = 2069,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633306210,
                        ["quant"] = 1,
                        ["id"] = "1692801641",
                        ["itemLink"] = 21,
                    },
                    [100] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 2099,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1632819744,
                        ["quant"] = 2,
                        ["id"] = "1688942143",
                        ["itemLink"] = 21,
                    },
                    [101] = 
                    {
                        ["price"] = 17318,
                        ["guild"] = 1,
                        ["buyer"] = 819,
                        ["wasKiosk"] = false,
                        ["seller"] = 331,
                        ["timestamp"] = 1632823588,
                        ["quant"] = 2,
                        ["id"] = "1688958941",
                        ["itemLink"] = 21,
                    },
                    [102] = 
                    {
                        ["price"] = 843750,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 1318,
                        ["timestamp"] = 1632848292,
                        ["quant"] = 75,
                        ["id"] = "1689130523",
                        ["itemLink"] = 21,
                    },
                    [103] = 
                    {
                        ["price"] = 105000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632848298,
                        ["quant"] = 10,
                        ["id"] = "1689130581",
                        ["itemLink"] = 21,
                    },
                    [104] = 
                    {
                        ["price"] = 105000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632848299,
                        ["quant"] = 10,
                        ["id"] = "1689130593",
                        ["itemLink"] = 21,
                    },
                    [105] = 
                    {
                        ["price"] = 200000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 513,
                        ["timestamp"] = 1632848301,
                        ["quant"] = 20,
                        ["id"] = "1689130611",
                        ["itemLink"] = 21,
                    },
                    [106] = 
                    {
                        ["price"] = 140000,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 33,
                        ["timestamp"] = 1632853299,
                        ["quant"] = 15,
                        ["id"] = "1689169787",
                        ["itemLink"] = 21,
                    },
                    [107] = 
                    {
                        ["price"] = 75992,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 615,
                        ["timestamp"] = 1632862006,
                        ["quant"] = 8,
                        ["id"] = "1689244459",
                        ["itemLink"] = 21,
                    },
                    [108] = 
                    {
                        ["price"] = 227976,
                        ["guild"] = 1,
                        ["buyer"] = 2254,
                        ["wasKiosk"] = true,
                        ["seller"] = 615,
                        ["timestamp"] = 1632863826,
                        ["quant"] = 24,
                        ["id"] = "1689257241",
                        ["itemLink"] = 21,
                    },
                    [109] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 2342,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1632878707,
                        ["quant"] = 8,
                        ["id"] = "1689380191",
                        ["itemLink"] = 21,
                    },
                    [110] = 
                    {
                        ["price"] = 47500,
                        ["guild"] = 1,
                        ["buyer"] = 2351,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632880039,
                        ["quant"] = 5,
                        ["id"] = "1689397127",
                        ["itemLink"] = 21,
                    },
                    [111] = 
                    {
                        ["price"] = 9500,
                        ["guild"] = 1,
                        ["buyer"] = 2358,
                        ["wasKiosk"] = true,
                        ["seller"] = 763,
                        ["timestamp"] = 1632881342,
                        ["quant"] = 1,
                        ["id"] = "1689410063",
                        ["itemLink"] = 21,
                    },
                    [112] = 
                    {
                        ["price"] = 35408,
                        ["guild"] = 1,
                        ["buyer"] = 2403,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632887795,
                        ["quant"] = 4,
                        ["id"] = "1689477551",
                        ["itemLink"] = 21,
                    },
                    [113] = 
                    {
                        ["price"] = 35408,
                        ["guild"] = 1,
                        ["buyer"] = 2403,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632887797,
                        ["quant"] = 4,
                        ["id"] = "1689477565",
                        ["itemLink"] = 21,
                    },
                    [114] = 
                    {
                        ["price"] = 35408,
                        ["guild"] = 1,
                        ["buyer"] = 2403,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632887801,
                        ["quant"] = 4,
                        ["id"] = "1689477611",
                        ["itemLink"] = 21,
                    },
                    [115] = 
                    {
                        ["price"] = 89070,
                        ["guild"] = 1,
                        ["buyer"] = 963,
                        ["wasKiosk"] = true,
                        ["seller"] = 1535,
                        ["timestamp"] = 1632921146,
                        ["quant"] = 10,
                        ["id"] = "1689658353",
                        ["itemLink"] = 21,
                    },
                    [116] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 2515,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1632930623,
                        ["quant"] = 1,
                        ["id"] = "1689726737",
                        ["itemLink"] = 21,
                    },
                    [117] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 2515,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1632930625,
                        ["quant"] = 1,
                        ["id"] = "1689726747",
                        ["itemLink"] = 21,
                    },
                    [118] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 2515,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1632930626,
                        ["quant"] = 1,
                        ["id"] = "1689726751",
                        ["itemLink"] = 21,
                    },
                    [119] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 2515,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1632930628,
                        ["quant"] = 1,
                        ["id"] = "1689726755",
                        ["itemLink"] = 21,
                    },
                    [120] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 2515,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1632930630,
                        ["quant"] = 1,
                        ["id"] = "1689726765",
                        ["itemLink"] = 21,
                    },
                    [121] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 2515,
                        ["wasKiosk"] = true,
                        ["seller"] = 775,
                        ["timestamp"] = 1632930632,
                        ["quant"] = 1,
                        ["id"] = "1689726777",
                        ["itemLink"] = 21,
                    },
                    [122] = 
                    {
                        ["price"] = 18800,
                        ["guild"] = 1,
                        ["buyer"] = 1916,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1632931288,
                        ["quant"] = 2,
                        ["id"] = "1689731037",
                        ["itemLink"] = 21,
                    },
                    [123] = 
                    {
                        ["price"] = 75999,
                        ["guild"] = 1,
                        ["buyer"] = 1916,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632931291,
                        ["quant"] = 8,
                        ["id"] = "1689731045",
                        ["itemLink"] = 21,
                    },
                    [124] = 
                    {
                        ["price"] = 18780,
                        ["guild"] = 1,
                        ["buyer"] = 1916,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632931292,
                        ["quant"] = 2,
                        ["id"] = "1689731051",
                        ["itemLink"] = 21,
                    },
                    [125] = 
                    {
                        ["price"] = 152000,
                        ["guild"] = 1,
                        ["buyer"] = 1916,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632931304,
                        ["quant"] = 16,
                        ["id"] = "1689731121",
                        ["itemLink"] = 21,
                    },
                    [126] = 
                    {
                        ["price"] = 38000,
                        ["guild"] = 1,
                        ["buyer"] = 1916,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1632931317,
                        ["quant"] = 4,
                        ["id"] = "1689731197",
                        ["itemLink"] = 21,
                    },
                    [127] = 
                    {
                        ["price"] = 38000,
                        ["guild"] = 1,
                        ["buyer"] = 1916,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632931320,
                        ["quant"] = 4,
                        ["id"] = "1689731205",
                        ["itemLink"] = 21,
                    },
                    [128] = 
                    {
                        ["price"] = 38219,
                        ["guild"] = 1,
                        ["buyer"] = 1916,
                        ["wasKiosk"] = true,
                        ["seller"] = 228,
                        ["timestamp"] = 1632931332,
                        ["quant"] = 4,
                        ["id"] = "1689731221",
                        ["itemLink"] = 21,
                    },
                    [129] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 2536,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1632938866,
                        ["quant"] = 8,
                        ["id"] = "1689786905",
                        ["itemLink"] = 21,
                    },
                    [130] = 
                    {
                        ["price"] = 36000,
                        ["guild"] = 1,
                        ["buyer"] = 2604,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1632954715,
                        ["quant"] = 4,
                        ["id"] = "1689916405",
                        ["itemLink"] = 21,
                    },
                    [131] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 2652,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632964354,
                        ["quant"] = 2,
                        ["id"] = "1689998877",
                        ["itemLink"] = 21,
                    },
                    [132] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 2652,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632964355,
                        ["quant"] = 2,
                        ["id"] = "1689998887",
                        ["itemLink"] = 21,
                    },
                    [133] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 2652,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632964356,
                        ["quant"] = 2,
                        ["id"] = "1689998897",
                        ["itemLink"] = 21,
                    },
                    [134] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 2652,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632964356,
                        ["quant"] = 2,
                        ["id"] = "1689998903",
                        ["itemLink"] = 21,
                    },
                    [135] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 2652,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632964357,
                        ["quant"] = 2,
                        ["id"] = "1689998919",
                        ["itemLink"] = 21,
                    },
                    [136] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 2652,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632964358,
                        ["quant"] = 1,
                        ["id"] = "1689998935",
                        ["itemLink"] = 21,
                    },
                    [137] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 2652,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632964359,
                        ["quant"] = 2,
                        ["id"] = "1689998955",
                        ["itemLink"] = 21,
                    },
                    [138] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 945,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1632968194,
                        ["quant"] = 8,
                        ["id"] = "1690037365",
                        ["itemLink"] = 21,
                    },
                },
                ["totalCount"] = 138,
                ["itemAdderText"] = "rr01 gold legendary materials temper",
            },
        },
        [141839] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_rok_sum_hircinealtar001.dds",
                ["itemDesc"] = "Sacrificial Altar, Hircine",
                ["oldestTime"] = 1632883634,
                ["wasAltered"] = true,
                ["newestTime"] = 1632883634,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 31332,
                        ["guild"] = 1,
                        ["buyer"] = 2373,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1632883634,
                        ["quant"] = 1,
                        ["id"] = "1689434975",
                        ["itemLink"] = 3485,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings undercroft",
            },
        },
        [96159] = 
        {
            ["50:16:4:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_1haxe_d.dds",
                ["itemDesc"] = "Axe of the Trainee",
                ["oldestTime"] = 1633211003,
                ["wasAltered"] = true,
                ["newestTime"] = 1633211003,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 1552,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1633211003,
                        ["quant"] = 1,
                        ["id"] = "1691915841",
                        ["itemLink"] = 2276,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set armor of the trainee axe one-handed training",
            },
        },
        [84896] = 
        {
            ["50:16:2:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Red Mountain",
                ["oldestTime"] = 1632862711,
                ["wasAltered"] = true,
                ["newestTime"] = 1632862711,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 451,
                        ["wasKiosk"] = false,
                        ["seller"] = 535,
                        ["timestamp"] = 1632862711,
                        ["quant"] = 1,
                        ["id"] = "1689249537",
                        ["itemLink"] = 3318,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set shadow of the red mountain ring robust",
            },
        },
        [79478] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_trinimac_2hsword_a.dds",
                ["itemDesc"] = "Greatsword of Trinimac's Valor",
                ["oldestTime"] = 1633088086,
                ["wasAltered"] = true,
                ["newestTime"] = 1633088086,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 477,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1633088086,
                        ["quant"] = 1,
                        ["id"] = "1690876565",
                        ["itemLink"] = 1232,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set trinimac's valor sword two-handed decisive",
            },
        },
        [69538] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 21: Ancient Orc Shields",
                ["oldestTime"] = 1633059531,
                ["wasAltered"] = true,
                ["newestTime"] = 1633059531,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19000,
                        ["guild"] = 1,
                        ["buyer"] = 782,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1633059531,
                        ["quant"] = 1,
                        ["id"] = "1690705977",
                        ["itemLink"] = 1005,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [43570] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_shockresist.dds",
                ["itemDesc"] = "Superb Glyph of Shock Resist",
                ["oldestTime"] = 1632826388,
                ["wasAltered"] = true,
                ["newestTime"] = 1633148035,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 110,
                        ["guild"] = 1,
                        ["buyer"] = 1244,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633148035,
                        ["quant"] = 1,
                        ["id"] = "1691374079",
                        ["itemLink"] = 1682,
                    },
                    [2] = 
                    {
                        ["price"] = 227,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632826388,
                        ["quant"] = 1,
                        ["id"] = "1688971345",
                        ["itemLink"] = 1682,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp150 green fine miscellaneous jewelry glyph",
            },
        },
        [175780] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Old Orsinium Maul",
                ["oldestTime"] = 1632780925,
                ["wasAltered"] = true,
                ["newestTime"] = 1632780925,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 2,
                        ["buyer"] = 127,
                        ["wasKiosk"] = false,
                        ["seller"] = 130,
                        ["timestamp"] = 1632780925,
                        ["quant"] = 1,
                        ["id"] = "1688621107",
                        ["itemLink"] = 125,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [117157] = 
        {
            ["50:16:5:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_staff_a.dds",
                ["itemDesc"] = "Inferno Staff of the Powerful Assault",
                ["oldestTime"] = 1633223721,
                ["wasAltered"] = true,
                ["newestTime"] = 1633223721,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450000,
                        ["guild"] = 1,
                        ["buyer"] = 1629,
                        ["wasKiosk"] = true,
                        ["seller"] = 1061,
                        ["timestamp"] = 1633223721,
                        ["quant"] = 1,
                        ["id"] = "1692051073",
                        ["itemLink"] = 2367,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary weapon set powerful assault flame staff two-handed defending",
            },
        },
        [156557] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 76: Dragonguard Belts",
                ["oldestTime"] = 1632911078,
                ["wasAltered"] = true,
                ["newestTime"] = 1632911078,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 2462,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1632911078,
                        ["quant"] = 1,
                        ["id"] = "1689604497",
                        ["itemLink"] = 3608,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45991] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Old Clear-Eye Whiskey",
                ["oldestTime"] = 1632913089,
                ["wasAltered"] = true,
                ["newestTime"] = 1633076119,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45,
                        ["guild"] = 2,
                        ["buyer"] = 137,
                        ["wasKiosk"] = false,
                        ["seller"] = 123,
                        ["timestamp"] = 1633076119,
                        ["quant"] = 1,
                        ["id"] = "1690817571",
                        ["itemLink"] = 148,
                    },
                    [2] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 2471,
                        ["wasKiosk"] = true,
                        ["seller"] = 442,
                        ["timestamp"] = 1632913089,
                        ["quant"] = 1,
                        ["id"] = "1689612633",
                        ["itemLink"] = 148,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [160600] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 89: Ancestral High Elf Gloves",
                ["oldestTime"] = 1633143395,
                ["wasAltered"] = true,
                ["newestTime"] = 1633241119,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4300,
                        ["guild"] = 1,
                        ["buyer"] = 1213,
                        ["wasKiosk"] = true,
                        ["seller"] = 1214,
                        ["timestamp"] = 1633143395,
                        ["quant"] = 1,
                        ["id"] = "1691330377",
                        ["itemLink"] = 1630,
                    },
                    [2] = 
                    {
                        ["price"] = 5650,
                        ["guild"] = 1,
                        ["buyer"] = 1778,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633241119,
                        ["quant"] = 1,
                        ["id"] = "1692205503",
                        ["itemLink"] = 1630,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [132756] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_apostle_staff_a.dds",
                ["itemDesc"] = "Livewire Inferno Staff",
                ["oldestTime"] = 1632889145,
                ["wasAltered"] = true,
                ["newestTime"] = 1632889145,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2407,
                        ["wasKiosk"] = true,
                        ["seller"] = 547,
                        ["timestamp"] = 1632889145,
                        ["quant"] = 1,
                        ["id"] = "1689486807",
                        ["itemLink"] = 3530,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set livewire flame staff two-handed sharpened",
            },
        },
        [140458] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 63: Dremora Swords",
                ["oldestTime"] = 1632940235,
                ["wasAltered"] = true,
                ["newestTime"] = 1632940235,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 28800,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 611,
                        ["timestamp"] = 1632940235,
                        ["quant"] = 1,
                        ["id"] = "1689796473",
                        ["itemLink"] = 3767,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [134306] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_tre_fan_clkcypress004.dds",
                ["itemDesc"] = "Fabricant Tree, Gnarled Cypress",
                ["oldestTime"] = 1632882428,
                ["wasAltered"] = true,
                ["newestTime"] = 1632882428,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14980,
                        ["guild"] = 1,
                        ["buyer"] = 2366,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1632882428,
                        ["quant"] = 2,
                        ["id"] = "1689422951",
                        ["itemLink"] = 3477,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings conservatory",
            },
        },
        [126124] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_dae_inc_ashstatueurn001.dds",
                ["itemDesc"] = "Daedric Urn, Ashen",
                ["oldestTime"] = 1633314450,
                ["wasAltered"] = true,
                ["newestTime"] = 1633314450,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5400,
                        ["guild"] = 1,
                        ["buyer"] = 72,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633314450,
                        ["quant"] = 1,
                        ["id"] = "1692895539",
                        ["itemLink"] = 55,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings undercroft",
            },
        },
        [134476] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_alchemy2.dds",
                ["itemDesc"] = "Formula: Fabricant Tree, Gnarled Cypress",
                ["oldestTime"] = 1632882253,
                ["wasAltered"] = true,
                ["newestTime"] = 1632882253,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24995,
                        ["guild"] = 1,
                        ["buyer"] = 2365,
                        ["wasKiosk"] = true,
                        ["seller"] = 322,
                        ["timestamp"] = 1632882253,
                        ["quant"] = 1,
                        ["id"] = "1689421047",
                        ["itemLink"] = 3476,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [27052] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_gin_002.dds",
                ["itemDesc"] = "Ginger",
                ["oldestTime"] = 1633305854,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305854,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633305854,
                        ["quant"] = 200,
                        ["id"] = "1692798979",
                        ["itemLink"] = 2941,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [115865] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning3.dds",
                ["itemDesc"] = "Design: Wood Elf Barrel, Ceramic",
                ["oldestTime"] = 1632880413,
                ["wasAltered"] = true,
                ["newestTime"] = 1632880413,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1999,
                        ["guild"] = 1,
                        ["buyer"] = 1217,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1632880413,
                        ["quant"] = 1,
                        ["id"] = "1689401293",
                        ["itemLink"] = 3460,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [133040] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of Unfathomable Darkness",
                ["oldestTime"] = 1633274205,
                ["wasAltered"] = true,
                ["newestTime"] = 1633274205,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5400,
                        ["guild"] = 1,
                        ["buyer"] = 1895,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633274205,
                        ["quant"] = 1,
                        ["id"] = "1692453429",
                        ["itemLink"] = 2695,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set unfathomable darkness neck robust",
            },
        },
        [156657] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_coh_inc_hanginglantern000.dds",
                ["itemDesc"] = "Azure Plasm Cage, Hanging",
                ["oldestTime"] = 1632879988,
                ["wasAltered"] = true,
                ["newestTime"] = 1632879988,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 205000,
                        ["guild"] = 1,
                        ["buyer"] = 2331,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1632879988,
                        ["quant"] = 1,
                        ["id"] = "1689396769",
                        ["itemLink"] = 3456,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings lighting",
            },
        },
        [166834] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Solitude Trough, Empty",
                ["oldestTime"] = 1633040328,
                ["wasAltered"] = true,
                ["newestTime"] = 1633040328,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 623,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633040328,
                        ["quant"] = 1,
                        ["id"] = "1690515735",
                        ["itemLink"] = 795,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [123059] = 
        {
            ["50:16:4:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_hlaalu_medium_feet_a.dds",
                ["itemDesc"] = "Defiler's Boots",
                ["oldestTime"] = 1633219171,
                ["wasAltered"] = true,
                ["newestTime"] = 1633219171,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 1604,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1633219171,
                        ["quant"] = 1,
                        ["id"] = "1692004007",
                        ["itemLink"] = 2335,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set defiler feet reinforced",
            },
        },
        [95970] = 
        {
            ["50:16:4:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_1haxe_d.dds",
                ["itemDesc"] = "Axe of the Trainee",
                ["oldestTime"] = 1632879453,
                ["wasAltered"] = true,
                ["newestTime"] = 1632879453,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 2347,
                        ["wasKiosk"] = true,
                        ["seller"] = 1004,
                        ["timestamp"] = 1632879453,
                        ["quant"] = 1,
                        ["id"] = "1689390729",
                        ["itemLink"] = 3443,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set armor of the trainee axe one-handed training",
            },
        },
        [147708] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 73: Anequina Maces",
                ["oldestTime"] = 1632877867,
                ["wasAltered"] = true,
                ["newestTime"] = 1632877867,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3100,
                        ["guild"] = 1,
                        ["buyer"] = 2340,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632877867,
                        ["quant"] = 1,
                        ["id"] = "1689371233",
                        ["itemLink"] = 3437,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [57010] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Kwama Egg Omelet",
                ["oldestTime"] = 1632865569,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865569,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2194,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1632865569,
                        ["quant"] = 1,
                        ["id"] = "1689269123",
                        ["itemLink"] = 3356,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [175566] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Ja'zennji Siir Skirt",
                ["oldestTime"] = 1632861844,
                ["wasAltered"] = true,
                ["newestTime"] = 1632861844,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2249,
                        ["wasKiosk"] = true,
                        ["seller"] = 86,
                        ["timestamp"] = 1632861844,
                        ["quant"] = 1,
                        ["id"] = "1689243409",
                        ["itemLink"] = 3311,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [129720] = 
        {
            ["50:16:2:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_staff_c.dds",
                ["itemDesc"] = "Briarheart Lightning Staff",
                ["oldestTime"] = 1633218403,
                ["wasAltered"] = true,
                ["newestTime"] = 1633218403,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2600,
                        ["guild"] = 1,
                        ["buyer"] = 1599,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633218403,
                        ["quant"] = 1,
                        ["id"] = "1691994811",
                        ["itemLink"] = 2326,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set briarheart lightning staff two-handed sharpened",
            },
        },
        [140473] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 65: Huntsman Shields",
                ["oldestTime"] = 1632850286,
                ["wasAltered"] = true,
                ["newestTime"] = 1632850286,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 26784,
                        ["guild"] = 1,
                        ["buyer"] = 2214,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1632850286,
                        ["quant"] = 1,
                        ["id"] = "1689146733",
                        ["itemLink"] = 3231,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [151994] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Elsweyr Spice Display, Turmeric Yellow",
                ["oldestTime"] = 1633158048,
                ["wasAltered"] = true,
                ["newestTime"] = 1633158048,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1293,
                        ["wasKiosk"] = true,
                        ["seller"] = 1108,
                        ["timestamp"] = 1633158048,
                        ["quant"] = 1,
                        ["id"] = "1691454613",
                        ["itemLink"] = 1779,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [120763] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/event_jester_fancystonewarejug.dds",
                ["itemDesc"] = "Dubious Camoran Throne",
                ["oldestTime"] = 1632949648,
                ["wasAltered"] = true,
                ["newestTime"] = 1632949650,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 21194,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 402,
                        ["timestamp"] = 1632949648,
                        ["quant"] = 85,
                        ["id"] = "1689871615",
                        ["itemLink"] = 3806,
                    },
                    [2] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1632949650,
                        ["quant"] = 50,
                        ["id"] = "1689871625",
                        ["itemLink"] = 3806,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable drink",
            },
        },
        [43675] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Eastmarch Treasure Map III",
                ["oldestTime"] = 1632858416,
                ["wasAltered"] = true,
                ["newestTime"] = 1632858416,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 733,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1632858416,
                        ["quant"] = 1,
                        ["id"] = "1689218565",
                        ["itemLink"] = 3292,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [132797] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_apostle_staff_a.dds",
                ["itemDesc"] = "Livewire Ice Staff",
                ["oldestTime"] = 1633076612,
                ["wasAltered"] = true,
                ["newestTime"] = 1633076612,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 871,
                        ["wasKiosk"] = true,
                        ["seller"] = 872,
                        ["timestamp"] = 1633076612,
                        ["quant"] = 1,
                        ["id"] = "1690820001",
                        ["itemLink"] = 1116,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set livewire frost staff two-handed decisive",
            },
        },
        [167614] = 
        {
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nighthollowreg_lgt_legs_a.dds",
                ["itemDesc"] = "Breeches of the Voidcaller",
                ["oldestTime"] = 1632823495,
                ["wasAltered"] = true,
                ["newestTime"] = 1632823495,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 890,
                        ["guild"] = 1,
                        ["buyer"] = 2111,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1632823495,
                        ["quant"] = 1,
                        ["id"] = "1688958575",
                        ["itemLink"] = 3016,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set voidcaller legs infused",
            },
        },
        [116430] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_orc_fur_wtgcabinettall001.dds",
                ["itemDesc"] = "Orcish Hutch, Engraved",
                ["oldestTime"] = 1633174084,
                ["wasAltered"] = true,
                ["newestTime"] = 1633174084,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 17256,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1633174084,
                        ["quant"] = 1,
                        ["id"] = "1691541793",
                        ["itemLink"] = 1896,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings hearth",
            },
        },
        [126580] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_fug_lightstalk001.dds",
                ["itemDesc"] = "Vvardenfell Glowstalk, Towering",
                ["oldestTime"] = 1632851183,
                ["wasAltered"] = true,
                ["newestTime"] = 1632851183,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 175,
                        ["wasKiosk"] = false,
                        ["seller"] = 669,
                        ["timestamp"] = 1632851183,
                        ["quant"] = 2,
                        ["id"] = "1689153063",
                        ["itemLink"] = 3241,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [147393] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_medium_chest_a.dds",
                ["itemDesc"] = "Deadly Jack",
                ["oldestTime"] = 1633017330,
                ["wasAltered"] = true,
                ["newestTime"] = 1633017330,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 483,
                        ["wasKiosk"] = true,
                        ["seller"] = 356,
                        ["timestamp"] = 1633017330,
                        ["quant"] = 1,
                        ["id"] = "1690343675",
                        ["itemLink"] = 550,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set deadly strike chest impenetrable",
            },
        },
        [132162] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_vrd_inc_housinghlabath002.dds",
                ["itemDesc"] = "Hlaalu Bath Tub, Masterwork",
                ["oldestTime"] = 1633034009,
                ["wasAltered"] = true,
                ["newestTime"] = 1633143481,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 29000,
                        ["guild"] = 1,
                        ["buyer"] = 585,
                        ["wasKiosk"] = true,
                        ["seller"] = 569,
                        ["timestamp"] = 1633034009,
                        ["quant"] = 1,
                        ["id"] = "1690470297",
                        ["itemLink"] = 755,
                    },
                    [2] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 1216,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633143481,
                        ["quant"] = 1,
                        ["id"] = "1691331273",
                        ["itemLink"] = 755,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary furnishings suite",
            },
        },
        [140483] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 66: Silver Dawn Chests",
                ["oldestTime"] = 1633193926,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261771,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 73950,
                        ["guild"] = 1,
                        ["buyer"] = 1437,
                        ["wasKiosk"] = true,
                        ["seller"] = 1438,
                        ["timestamp"] = 1633193926,
                        ["quant"] = 1,
                        ["id"] = "1691734121",
                        ["itemLink"] = 2126,
                    },
                    [2] = 
                    {
                        ["price"] = 73950,
                        ["guild"] = 1,
                        ["buyer"] = 1327,
                        ["wasKiosk"] = true,
                        ["seller"] = 1438,
                        ["timestamp"] = 1633261771,
                        ["quant"] = 1,
                        ["id"] = "1692335893",
                        ["itemLink"] = 2126,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [117147] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_medium_shoulders_a.dds",
                ["itemDesc"] = "Arm Cops of the Powerful Assault",
                ["oldestTime"] = 1632836874,
                ["wasAltered"] = true,
                ["newestTime"] = 1632837393,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 2161,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1632836874,
                        ["quant"] = 1,
                        ["id"] = "1689041739",
                        ["itemLink"] = 3112,
                    },
                    [2] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 2162,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1632837393,
                        ["quant"] = 1,
                        ["id"] = "1689044529",
                        ["itemLink"] = 3112,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic medium apparel set powerful assault shoulders well-fitted",
            },
        },
        [125808] = 
        {
            ["50:16:4:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_staff_a.dds",
                ["itemDesc"] = "Impregnable Armor Inferno Staff",
                ["oldestTime"] = 1632830336,
                ["wasAltered"] = true,
                ["newestTime"] = 1632830336,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2134,
                        ["wasKiosk"] = true,
                        ["seller"] = 531,
                        ["timestamp"] = 1632830336,
                        ["quant"] = 1,
                        ["id"] = "1689000495",
                        ["itemLink"] = 3081,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set impregnable armor flame staff two-handed defending",
            },
        },
        [156616] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 81: New Moon Priest Helmets",
                ["oldestTime"] = 1632970174,
                ["wasAltered"] = true,
                ["newestTime"] = 1633240501,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 160,
                        ["wasKiosk"] = true,
                        ["seller"] = 161,
                        ["timestamp"] = 1632970174,
                        ["quant"] = 1,
                        ["id"] = "1690058585",
                        ["itemLink"] = 169,
                    },
                    [2] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 355,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633240501,
                        ["quant"] = 1,
                        ["id"] = "1692201671",
                        ["itemLink"] = 169,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [144283] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Battlefield Acrobat Ring",
                ["oldestTime"] = 1632830280,
                ["wasAltered"] = true,
                ["newestTime"] = 1632830280,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2134,
                        ["wasKiosk"] = true,
                        ["seller"] = 506,
                        ["timestamp"] = 1632830280,
                        ["quant"] = 1,
                        ["id"] = "1689000135",
                        ["itemLink"] = 3068,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set battlefield acrobat ring robust",
            },
        },
        [57032] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Sour Gin Fizz",
                ["oldestTime"] = 1633112655,
                ["wasAltered"] = true,
                ["newestTime"] = 1633122935,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 122,
                        ["guild"] = 1,
                        ["buyer"] = 997,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633112655,
                        ["quant"] = 1,
                        ["id"] = "1691056607",
                        ["itemLink"] = 1358,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1066,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633122935,
                        ["quant"] = 1,
                        ["id"] = "1691126851",
                        ["itemLink"] = 1358,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [86780] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_feet_d.dds",
                ["itemDesc"] = "Shoes of Necropotence",
                ["oldestTime"] = 1633190558,
                ["wasAltered"] = true,
                ["newestTime"] = 1633190558,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 450,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633190558,
                        ["quant"] = 1,
                        ["id"] = "1691693913",
                        ["itemLink"] = 2100,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set necropotence feet divines",
            },
        },
        [82011] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 41: Celestial Chests",
                ["oldestTime"] = 1633052174,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052174,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15039,
                        ["guild"] = 1,
                        ["buyer"] = 242,
                        ["wasKiosk"] = false,
                        ["seller"] = 54,
                        ["timestamp"] = 1633052174,
                        ["quant"] = 1,
                        ["id"] = "1690627841",
                        ["itemLink"] = 900,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [43723] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Craglorn Treasure Map III",
                ["oldestTime"] = 1633149344,
                ["wasAltered"] = true,
                ["newestTime"] = 1633149344,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1250,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633149344,
                        ["quant"] = 1,
                        ["id"] = "1691385243",
                        ["itemLink"] = 1704,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [123084] = 
        {
            ["50:16:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_hlaalu_medium_waist_a.dds",
                ["itemDesc"] = "Defiler's Belt",
                ["oldestTime"] = 1633203246,
                ["wasAltered"] = true,
                ["newestTime"] = 1633203246,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1087,
                        ["guild"] = 1,
                        ["buyer"] = 1210,
                        ["wasKiosk"] = true,
                        ["seller"] = 528,
                        ["timestamp"] = 1633203246,
                        ["quant"] = 1,
                        ["id"] = "1691825731",
                        ["itemLink"] = 2229,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set defiler waist impenetrable",
            },
        },
        [132557] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_cwc_inc_scrollplate001.dds",
                ["itemDesc"] = "Crafting Motif 56: Apostle Helmets",
                ["oldestTime"] = 1633203257,
                ["wasAltered"] = true,
                ["newestTime"] = 1633222623,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 624,
                        ["timestamp"] = 1633203257,
                        ["quant"] = 1,
                        ["id"] = "1691825915",
                        ["itemLink"] = 2230,
                    },
                    [2] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 1621,
                        ["wasKiosk"] = true,
                        ["seller"] = 624,
                        ["timestamp"] = 1633222623,
                        ["quant"] = 1,
                        ["id"] = "1692038787",
                        ["itemLink"] = 2230,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [137934] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 62: Sapiarch Swords",
                ["oldestTime"] = 1633062272,
                ["wasAltered"] = true,
                ["newestTime"] = 1633246400,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6999,
                        ["guild"] = 1,
                        ["buyer"] = 796,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633062272,
                        ["quant"] = 1,
                        ["id"] = "1690727467",
                        ["itemLink"] = 1034,
                    },
                    [2] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1463,
                        ["wasKiosk"] = true,
                        ["seller"] = 1720,
                        ["timestamp"] = 1633246400,
                        ["quant"] = 1,
                        ["id"] = "1692244951",
                        ["itemLink"] = 1034,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [46031] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Shimmerene Tonic",
                ["oldestTime"] = 1632881776,
                ["wasAltered"] = true,
                ["newestTime"] = 1632881776,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 377,
                        ["guild"] = 1,
                        ["buyer"] = 2362,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1632881776,
                        ["quant"] = 1,
                        ["id"] = "1689415191",
                        ["itemLink"] = 3471,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [118992] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: High Elf End Table, Sturdy",
                ["oldestTime"] = 1632842282,
                ["wasAltered"] = true,
                ["newestTime"] = 1632842282,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2184,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1632842282,
                        ["quant"] = 1,
                        ["id"] = "1689075645",
                        ["itemLink"] = 3161,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [175948] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Table, Sturdy Grand",
                ["oldestTime"] = 1633292307,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292307,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633292307,
                        ["quant"] = 1,
                        ["id"] = "1692655115",
                        ["itemLink"] = 2820,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [127098] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Telvanni Lantern, Organic Azure",
                ["oldestTime"] = 1633292289,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292289,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 199950,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633292289,
                        ["quant"] = 1,
                        ["id"] = "1692654931",
                        ["itemLink"] = 2818,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [71681] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 28: Ra Gada Legs",
                ["oldestTime"] = 1633143161,
                ["wasAltered"] = true,
                ["newestTime"] = 1633219219,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3245,
                        ["guild"] = 1,
                        ["buyer"] = 1210,
                        ["wasKiosk"] = true,
                        ["seller"] = 765,
                        ["timestamp"] = 1633143161,
                        ["quant"] = 1,
                        ["id"] = "1691327107",
                        ["itemLink"] = 1627,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 160,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633219219,
                        ["quant"] = 1,
                        ["id"] = "1692004597",
                        ["itemLink"] = 1627,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [156628] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 80: Shield of Senchal Axes",
                ["oldestTime"] = 1632947153,
                ["wasAltered"] = true,
                ["newestTime"] = 1632947153,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13155,
                        ["guild"] = 1,
                        ["buyer"] = 2570,
                        ["wasKiosk"] = true,
                        ["seller"] = 2571,
                        ["timestamp"] = 1632947153,
                        ["quant"] = 1,
                        ["id"] = "1689851779",
                        ["itemLink"] = 3794,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [97910] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_head_a.dds",
                ["itemDesc"] = "Helmet of Night Terror",
                ["oldestTime"] = 1633280865,
                ["wasAltered"] = true,
                ["newestTime"] = 1633280865,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4150,
                        ["guild"] = 1,
                        ["buyer"] = 1929,
                        ["wasKiosk"] = true,
                        ["seller"] = 1494,
                        ["timestamp"] = 1633280865,
                        ["quant"] = 1,
                        ["id"] = "1692523675",
                        ["itemLink"] = 2734,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set night terror head sturdy",
            },
        },
        [176649] = 
        {
            ["1:0:4:38:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_restostaff.dds",
                ["itemDesc"] = "Companion's Restoration Staff",
                ["oldestTime"] = 1633022787,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022787,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 523,
                        ["wasKiosk"] = true,
                        ["seller"] = 353,
                        ["timestamp"] = 1633022787,
                        ["quant"] = 1,
                        ["id"] = "1690389003",
                        ["itemLink"] = 596,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic weapon healing staff two-handed aggressive",
            },
        },
        [160783] = 
        {
            ["50:16:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_blackreachex_bow.dds",
                ["itemDesc"] = "Bow of Winter's Respite",
                ["oldestTime"] = 1633131395,
                ["wasAltered"] = true,
                ["newestTime"] = 1633131395,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 720,
                        ["guild"] = 1,
                        ["buyer"] = 1111,
                        ["wasKiosk"] = true,
                        ["seller"] = 1112,
                        ["timestamp"] = 1633131395,
                        ["quant"] = 1,
                        ["id"] = "1691201477",
                        ["itemLink"] = 1518,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set winter's respite bow two-handed training",
            },
        },
        [114959] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 45: Mazzatun Helmets",
                ["oldestTime"] = 1633015497,
                ["wasAltered"] = true,
                ["newestTime"] = 1633015497,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 468,
                        ["wasKiosk"] = true,
                        ["seller"] = 386,
                        ["timestamp"] = 1633015497,
                        ["quant"] = 1,
                        ["id"] = "1690329213",
                        ["itemLink"] = 536,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [140505] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 67: Welkynar Legs",
                ["oldestTime"] = 1633146899,
                ["wasAltered"] = true,
                ["newestTime"] = 1633226566,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 704,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633146899,
                        ["quant"] = 1,
                        ["id"] = "1691364849",
                        ["itemLink"] = 1657,
                    },
                    [2] = 
                    {
                        ["price"] = 32500,
                        ["guild"] = 1,
                        ["buyer"] = 1653,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1633226566,
                        ["quant"] = 1,
                        ["id"] = "1692080785",
                        ["itemLink"] = 1657,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [98522] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_staff_d.dds",
                ["itemDesc"] = "Restoration Staff of the Vampire's Cloak",
                ["oldestTime"] = 1633095253,
                ["wasAltered"] = true,
                ["newestTime"] = 1633095253,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 926,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633095253,
                        ["quant"] = 1,
                        ["id"] = "1690921273",
                        ["itemLink"] = 1261,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set vampire cloak healing staff two-handed infused",
            },
        },
        [126939] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Redoran Armchair, Sanded",
                ["oldestTime"] = 1633208273,
                ["wasAltered"] = true,
                ["newestTime"] = 1633208273,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 34000,
                        ["guild"] = 1,
                        ["buyer"] = 903,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633208273,
                        ["quant"] = 1,
                        ["id"] = "1691886129",
                        ["itemLink"] = 2262,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [147676] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 71: Coldsnap Maces",
                ["oldestTime"] = 1633306117,
                ["wasAltered"] = true,
                ["newestTime"] = 1633306117,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 67,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633306117,
                        ["quant"] = 1,
                        ["id"] = "1692801027",
                        ["itemLink"] = 2943,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [175876] = 
        {
            ["1:0:3:34:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_restostaff.dds",
                ["itemDesc"] = "Companion's Restoration Staff",
                ["oldestTime"] = 1633247778,
                ["wasAltered"] = true,
                ["newestTime"] = 1633247778,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 850,
                        ["guild"] = 1,
                        ["buyer"] = 1806,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1633247778,
                        ["quant"] = 1,
                        ["id"] = "1692256295",
                        ["itemLink"] = 2585,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior weapon healing staff two-handed quickened",
            },
        },
        [46051] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Arenthian Brandy",
                ["oldestTime"] = 1632923722,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242700,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 348,
                        ["wasKiosk"] = false,
                        ["seller"] = 435,
                        ["timestamp"] = 1633242700,
                        ["quant"] = 1,
                        ["id"] = "1692215385",
                        ["itemLink"] = 2552,
                    },
                    [2] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1632923722,
                        ["quant"] = 1,
                        ["id"] = "1689677405",
                        ["itemLink"] = 2552,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [156622] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 81: New Moon Priest Swords",
                ["oldestTime"] = 1633050180,
                ["wasAltered"] = true,
                ["newestTime"] = 1633214055,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 698,
                        ["wasKiosk"] = true,
                        ["seller"] = 374,
                        ["timestamp"] = 1633050180,
                        ["quant"] = 1,
                        ["id"] = "1690607055",
                        ["itemLink"] = 887,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 971,
                        ["timestamp"] = 1633125564,
                        ["quant"] = 1,
                        ["id"] = "1691147181",
                        ["itemLink"] = 887,
                    },
                    [3] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1571,
                        ["wasKiosk"] = true,
                        ["seller"] = 61,
                        ["timestamp"] = 1633214055,
                        ["quant"] = 1,
                        ["id"] = "1691950185",
                        ["itemLink"] = 887,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [115628] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bos_fur_rack002.dds",
                ["itemDesc"] = "Wood Elf Rack, Dried Meat",
                ["oldestTime"] = 1633225648,
                ["wasAltered"] = true,
                ["newestTime"] = 1633225648,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 1644,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633225648,
                        ["quant"] = 1,
                        ["id"] = "1692071229",
                        ["itemLink"] = 2387,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings hearth",
            },
        },
        [54241] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Comberry Bourbon",
                ["oldestTime"] = 1633265412,
                ["wasAltered"] = true,
                ["newestTime"] = 1633267915,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 1361,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633265412,
                        ["quant"] = 1,
                        ["id"] = "1692363649",
                        ["itemLink"] = 2637,
                    },
                    [2] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 1864,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633267915,
                        ["quant"] = 1,
                        ["id"] = "1692383895",
                        ["itemLink"] = 2637,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [92386] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_medium_waist_d.dds",
                ["itemDesc"] = "Belt of the Twin Sisters",
                ["oldestTime"] = 1633200749,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200749,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 499,
                        ["guild"] = 1,
                        ["buyer"] = 1491,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633200749,
                        ["quant"] = 1,
                        ["id"] = "1691797243",
                        ["itemLink"] = 2197,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set twin sisters waist invigorating",
            },
        },
        [33251] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_metals_molybdenum.dds",
                ["itemDesc"] = "Molybdenum",
                ["oldestTime"] = 1633199699,
                ["wasAltered"] = true,
                ["newestTime"] = 1633199699,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1483,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633199699,
                        ["quant"] = 200,
                        ["id"] = "1691786371",
                        ["itemLink"] = 2182,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [177037] = 
        {
            ["1:0:3:41:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_axe.dds",
                ["itemDesc"] = "Companion's Axe",
                ["oldestTime"] = 1633224629,
                ["wasAltered"] = true,
                ["newestTime"] = 1633224629,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 475,
                        ["guild"] = 1,
                        ["buyer"] = 1637,
                        ["wasKiosk"] = true,
                        ["seller"] = 1033,
                        ["timestamp"] = 1633224629,
                        ["quant"] = 1,
                        ["id"] = "1692060227",
                        ["itemLink"] = 2372,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior weapon axe one-handed bolstered",
            },
        },
        [165595] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_fur_vampirebenchlong001.dds",
                ["itemDesc"] = "Vampiric Pew, Ornate",
                ["oldestTime"] = 1633223809,
                ["wasAltered"] = true,
                ["newestTime"] = 1633223811,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 58000,
                        ["guild"] = 1,
                        ["buyer"] = 1630,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633223809,
                        ["quant"] = 1,
                        ["id"] = "1692052387",
                        ["itemLink"] = 2368,
                    },
                    [2] = 
                    {
                        ["price"] = 58000,
                        ["guild"] = 1,
                        ["buyer"] = 1630,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633223811,
                        ["quant"] = 1,
                        ["id"] = "1692052431",
                        ["itemLink"] = 2368,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [132545] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 54: Bloodforge Shoulders",
                ["oldestTime"] = 1633196354,
                ["wasAltered"] = true,
                ["newestTime"] = 1633196354,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 1436,
                        ["wasKiosk"] = true,
                        ["seller"] = 1455,
                        ["timestamp"] = 1633196354,
                        ["quant"] = 1,
                        ["id"] = "1691752901",
                        ["itemLink"] = 2148,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [125913] = 
        {
            ["50:16:4:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_staff_a.dds",
                ["itemDesc"] = "Impregnable Armor Inferno Staff",
                ["oldestTime"] = 1633200782,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200782,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1491,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633200782,
                        ["quant"] = 1,
                        ["id"] = "1691797525",
                        ["itemLink"] = 2205,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set impregnable armor flame staff two-handed decisive",
            },
        },
        [57576] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 15: Dwemer Bows",
                ["oldestTime"] = 1632928617,
                ["wasAltered"] = true,
                ["newestTime"] = 1633219207,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 160,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633219207,
                        ["quant"] = 1,
                        ["id"] = "1692004457",
                        ["itemLink"] = 2336,
                    },
                    [2] = 
                    {
                        ["price"] = 1913,
                        ["guild"] = 1,
                        ["buyer"] = 359,
                        ["wasKiosk"] = true,
                        ["seller"] = 547,
                        ["timestamp"] = 1632928617,
                        ["quant"] = 1,
                        ["id"] = "1689711095",
                        ["itemLink"] = 2336,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [97257] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_legs_d.dds",
                ["itemDesc"] = "Breeches of a Mother's Sorrow",
                ["oldestTime"] = 1633297280,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297280,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 95000,
                        ["guild"] = 1,
                        ["buyer"] = 1997,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633297280,
                        ["quant"] = 1,
                        ["id"] = "1692713405",
                        ["itemLink"] = 2888,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set mother's sorrow legs divines",
            },
        },
        [45546] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Rosy Island Ale",
                ["oldestTime"] = 1633311188,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311188,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1,
                        ["wasKiosk"] = false,
                        ["seller"] = 379,
                        ["timestamp"] = 1633311188,
                        ["quant"] = 1,
                        ["id"] = "1692862281",
                        ["itemLink"] = 3002,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [117227] = 
        {
            ["50:16:4:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_medium_shoulders_a.dds",
                ["itemDesc"] = "Arm Cops of the Powerful Assault",
                ["oldestTime"] = 1632830304,
                ["wasAltered"] = true,
                ["newestTime"] = 1632830304,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 2134,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1632830304,
                        ["quant"] = 1,
                        ["id"] = "1689000325",
                        ["itemLink"] = 3069,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set powerful assault shoulders sturdy",
            },
        },
        [45332] = 
        {
            ["1:0:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_a.dds",
                ["itemDesc"] = "Maple Restoration Staff",
                ["oldestTime"] = 1633131469,
                ["wasAltered"] = true,
                ["newestTime"] = 1633131470,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 95,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633131469,
                        ["quant"] = 1,
                        ["id"] = "1691202343",
                        ["itemLink"] = 1532,
                    },
                    [2] = 
                    {
                        ["price"] = 95,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633131470,
                        ["quant"] = 1,
                        ["id"] = "1691202351",
                        ["itemLink"] = 1532,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal weapon healing staff two-handed intricate",
            },
            ["50:16:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Restoration Staff",
                ["oldestTime"] = 1632826487,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305625,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009389,
                        ["quant"] = 1,
                        ["id"] = "1690285697",
                        ["itemLink"] = 503,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009390,
                        ["quant"] = 1,
                        ["id"] = "1690285709",
                        ["itemLink"] = 503,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009393,
                        ["quant"] = 1,
                        ["id"] = "1690285757",
                        ["itemLink"] = 503,
                    },
                    [4] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009395,
                        ["quant"] = 1,
                        ["id"] = "1690285781",
                        ["itemLink"] = 508,
                    },
                    [5] = 
                    {
                        ["price"] = 186,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633028891,
                        ["quant"] = 1,
                        ["id"] = "1690436679",
                        ["itemLink"] = 695,
                    },
                    [6] = 
                    {
                        ["price"] = 280,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633028896,
                        ["quant"] = 1,
                        ["id"] = "1690436695",
                        ["itemLink"] = 503,
                    },
                    [7] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633084003,
                        ["quant"] = 1,
                        ["id"] = "1690854455",
                        ["itemLink"] = 503,
                    },
                    [8] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633084005,
                        ["quant"] = 1,
                        ["id"] = "1690854467",
                        ["itemLink"] = 1153,
                    },
                    [9] = 
                    {
                        ["price"] = 283,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633131470,
                        ["quant"] = 1,
                        ["id"] = "1691202353",
                        ["itemLink"] = 503,
                    },
                    [10] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633131471,
                        ["quant"] = 1,
                        ["id"] = "1691202357",
                        ["itemLink"] = 1533,
                    },
                    [11] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633305625,
                        ["quant"] = 1,
                        ["id"] = "1692796603",
                        ["itemLink"] = 503,
                    },
                    [12] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632826487,
                        ["quant"] = 1,
                        ["id"] = "1688971889",
                        ["itemLink"] = 3049,
                    },
                    [13] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1632826495,
                        ["quant"] = 1,
                        ["id"] = "1688972015",
                        ["itemLink"] = 508,
                    },
                    [14] = 
                    {
                        ["price"] = 328,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632842525,
                        ["quant"] = 1,
                        ["id"] = "1689079149",
                        ["itemLink"] = 3162,
                    },
                    [15] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632843153,
                        ["quant"] = 1,
                        ["id"] = "1689085077",
                        ["itemLink"] = 695,
                    },
                    [16] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632843155,
                        ["quant"] = 1,
                        ["id"] = "1689085087",
                        ["itemLink"] = 3170,
                    },
                    [17] = 
                    {
                        ["price"] = 211,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1632956371,
                        ["quant"] = 1,
                        ["id"] = "1689931121",
                        ["itemLink"] = 503,
                    },
                    [18] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956388,
                        ["quant"] = 1,
                        ["id"] = "1689931433",
                        ["itemLink"] = 1533,
                    },
                    [19] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956389,
                        ["quant"] = 1,
                        ["id"] = "1689931449",
                        ["itemLink"] = 3884,
                    },
                    [20] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956390,
                        ["quant"] = 1,
                        ["id"] = "1689931463",
                        ["itemLink"] = 503,
                    },
                    [21] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956394,
                        ["quant"] = 1,
                        ["id"] = "1689931511",
                        ["itemLink"] = 1533,
                    },
                    [22] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956395,
                        ["quant"] = 1,
                        ["id"] = "1689931525",
                        ["itemLink"] = 3887,
                    },
                    [23] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956395,
                        ["quant"] = 1,
                        ["id"] = "1689931529",
                        ["itemLink"] = 503,
                    },
                    [24] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956397,
                        ["quant"] = 1,
                        ["id"] = "1689931541",
                        ["itemLink"] = 3888,
                    },
                    [25] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956398,
                        ["quant"] = 1,
                        ["id"] = "1689931553",
                        ["itemLink"] = 3884,
                    },
                },
                ["totalCount"] = 25,
                ["itemAdderText"] = "cp160 white normal weapon healing staff two-handed intricate",
            },
            ["50:15:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Restoration Staff",
                ["oldestTime"] = 1632826462,
                ["wasAltered"] = true,
                ["newestTime"] = 1633268060,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009388,
                        ["quant"] = 1,
                        ["id"] = "1690285677",
                        ["itemLink"] = 501,
                    },
                    [2] = 
                    {
                        ["price"] = 152,
                        ["guild"] = 1,
                        ["buyer"] = 1001,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633268060,
                        ["quant"] = 1,
                        ["id"] = "1692385871",
                        ["itemLink"] = 501,
                    },
                    [3] = 
                    {
                        ["price"] = 199,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632826462,
                        ["quant"] = 1,
                        ["id"] = "1688971663",
                        ["itemLink"] = 3038,
                    },
                    [4] = 
                    {
                        ["price"] = 235,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1632826478,
                        ["quant"] = 1,
                        ["id"] = "1688971783",
                        ["itemLink"] = 501,
                    },
                    [5] = 
                    {
                        ["price"] = 214,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956372,
                        ["quant"] = 1,
                        ["id"] = "1689931137",
                        ["itemLink"] = 3875,
                    },
                    [6] = 
                    {
                        ["price"] = 214,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956373,
                        ["quant"] = 1,
                        ["id"] = "1689931149",
                        ["itemLink"] = 501,
                    },
                    [7] = 
                    {
                        ["price"] = 214,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956373,
                        ["quant"] = 1,
                        ["id"] = "1689931157",
                        ["itemLink"] = 3875,
                    },
                    [8] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956388,
                        ["quant"] = 1,
                        ["id"] = "1689931421",
                        ["itemLink"] = 3038,
                    },
                    [9] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956391,
                        ["quant"] = 1,
                        ["id"] = "1689931481",
                        ["itemLink"] = 3886,
                    },
                    [10] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956392,
                        ["quant"] = 1,
                        ["id"] = "1689931493",
                        ["itemLink"] = 501,
                    },
                    [11] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956393,
                        ["quant"] = 1,
                        ["id"] = "1689931505",
                        ["itemLink"] = 501,
                    },
                    [12] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956396,
                        ["quant"] = 1,
                        ["id"] = "1689931535",
                        ["itemLink"] = 501,
                    },
                    [13] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956397,
                        ["quant"] = 1,
                        ["id"] = "1689931549",
                        ["itemLink"] = 501,
                    },
                    [14] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632956399,
                        ["quant"] = 1,
                        ["id"] = "1689931565",
                        ["itemLink"] = 501,
                    },
                },
                ["totalCount"] = 14,
                ["itemAdderText"] = "cp150 white normal weapon healing staff two-handed intricate",
            },
        },
        [57581] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 15: Dwemer Legs",
                ["oldestTime"] = 1633058036,
                ["wasAltered"] = true,
                ["newestTime"] = 1633058036,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1550,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 435,
                        ["timestamp"] = 1633058036,
                        ["quant"] = 1,
                        ["id"] = "1690690493",
                        ["itemLink"] = 979,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [95470] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_light_head_a.dds",
                ["itemDesc"] = "Hat of Martial Knowledge",
                ["oldestTime"] = 1633114516,
                ["wasAltered"] = true,
                ["newestTime"] = 1633114516,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1013,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1633114516,
                        ["quant"] = 1,
                        ["id"] = "1691069495",
                        ["itemLink"] = 1385,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set way of martial knowledge head infused",
            },
        },
        [116207] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Nord Banner, Knotwork",
                ["oldestTime"] = 1633234971,
                ["wasAltered"] = true,
                ["newestTime"] = 1633234971,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633234971,
                        ["quant"] = 1,
                        ["id"] = "1692160563",
                        ["itemLink"] = 2475,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [56048] = 
        {
            ["1:0:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_light_head_b.dds",
                ["itemDesc"] = "Homespun Hat",
                ["oldestTime"] = 1632897053,
                ["wasAltered"] = true,
                ["newestTime"] = 1633296083,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 309,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1632984538,
                        ["quant"] = 1,
                        ["id"] = "1690157499",
                        ["itemLink"] = 312,
                    },
                    [2] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 1391,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633185521,
                        ["quant"] = 1,
                        ["id"] = "1691635563",
                        ["itemLink"] = 312,
                    },
                    [3] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1079,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633296083,
                        ["quant"] = 1,
                        ["id"] = "1692701539",
                        ["itemLink"] = 312,
                    },
                    [4] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 2437,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1632897053,
                        ["quant"] = 1,
                        ["id"] = "1689542211",
                        ["itemLink"] = 312,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 white normal light apparel head nirnhoned",
            },
        },
        [33265] = 
        {
            ["50:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/soulgem_006_empty.dds",
                ["itemDesc"] = "Soul Gem (Empty)",
                ["oldestTime"] = 1632855158,
                ["wasAltered"] = true,
                ["newestTime"] = 1632855158,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 2233,
                        ["wasKiosk"] = true,
                        ["seller"] = 374,
                        ["timestamp"] = 1632855158,
                        ["quant"] = 200,
                        ["id"] = "1689185279",
                        ["itemLink"] = 3264,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr50 white normal miscellaneous soul gem",
            },
        },
        [115186] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bre_fur_chest001.dds",
                ["itemDesc"] = "Breton Chest, Knotwork",
                ["oldestTime"] = 1633165796,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165796,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10124,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1633165796,
                        ["quant"] = 1,
                        ["id"] = "1691499637",
                        ["itemLink"] = 1841,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings suite",
            },
        },
        [181579] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting2.dds",
                ["itemDesc"] = "Praxis: Leyawiin Platform, Wide Steps",
                ["oldestTime"] = 1632948939,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309202,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3009,
                        ["guild"] = 1,
                        ["buyer"] = 333,
                        ["wasKiosk"] = false,
                        ["seller"] = 79,
                        ["timestamp"] = 1633035657,
                        ["quant"] = 1,
                        ["id"] = "1690480301",
                        ["itemLink"] = 767,
                    },
                    [2] = 
                    {
                        ["price"] = 8850,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 226,
                        ["timestamp"] = 1633060394,
                        ["quant"] = 1,
                        ["id"] = "1690713619",
                        ["itemLink"] = 767,
                    },
                    [3] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1515,
                        ["wasKiosk"] = true,
                        ["seller"] = 981,
                        ["timestamp"] = 1633204490,
                        ["quant"] = 1,
                        ["id"] = "1691838009",
                        ["itemLink"] = 767,
                    },
                    [4] = 
                    {
                        ["price"] = 7300,
                        ["guild"] = 1,
                        ["buyer"] = 778,
                        ["wasKiosk"] = false,
                        ["seller"] = 1128,
                        ["timestamp"] = 1633309202,
                        ["quant"] = 1,
                        ["id"] = "1692839133",
                        ["itemLink"] = 767,
                    },
                    [5] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2333,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632948939,
                        ["quant"] = 1,
                        ["id"] = "1689865083",
                        ["itemLink"] = 767,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [123124] = 
        {
            ["50:16:2:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_hlaalu_medium_waist_a.dds",
                ["itemDesc"] = "Defiler's Belt",
                ["oldestTime"] = 1633177867,
                ["wasAltered"] = true,
                ["newestTime"] = 1633177867,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 499,
                        ["guild"] = 1,
                        ["buyer"] = 1359,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633177867,
                        ["quant"] = 1,
                        ["id"] = "1691569021",
                        ["itemLink"] = 1907,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set defiler waist sturdy",
            },
        },
        [45045] = 
        {
            ["50:16:1:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_medium_legs_d.dds",
                ["itemDesc"] = "Rubedo Leather Guards",
                ["oldestTime"] = 1632922803,
                ["wasAltered"] = true,
                ["newestTime"] = 1632922803,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 240,
                        ["timestamp"] = 1632922803,
                        ["quant"] = 1,
                        ["id"] = "1689672065",
                        ["itemLink"] = 3665,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal medium apparel legs sturdy",
            },
        },
        [171888] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 103: Black Fin Legion Maces",
                ["oldestTime"] = 1633148023,
                ["wasAltered"] = true,
                ["newestTime"] = 1633276028,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633148023,
                        ["quant"] = 1,
                        ["id"] = "1691374033",
                        ["itemLink"] = 1681,
                    },
                    [2] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 550,
                        ["wasKiosk"] = false,
                        ["seller"] = 1450,
                        ["timestamp"] = 1633276028,
                        ["quant"] = 1,
                        ["id"] = "1692476271",
                        ["itemLink"] = 1681,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [33271] = 
        {
            ["50:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/soulgem_006_filled.dds",
                ["itemDesc"] = "Soul Gem",
                ["oldestTime"] = 1633080324,
                ["wasAltered"] = true,
                ["newestTime"] = 1633080324,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 881,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1633080324,
                        ["quant"] = 200,
                        ["id"] = "1690836777",
                        ["itemLink"] = 1125,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr50 green fine miscellaneous soul gem",
            },
        },
        [79352] = 
        {
            ["50:16:4:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_bow_c.dds",
                ["itemDesc"] = "Briarheart Bow",
                ["oldestTime"] = 1632891705,
                ["wasAltered"] = true,
                ["newestTime"] = 1632891705,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7777,
                        ["guild"] = 1,
                        ["buyer"] = 2414,
                        ["wasKiosk"] = true,
                        ["seller"] = 315,
                        ["timestamp"] = 1632891705,
                        ["quant"] = 1,
                        ["id"] = "1689505687",
                        ["itemLink"] = 3541,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set briarheart bow two-handed infused",
            },
        },
        [82008] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 41: Celestial Belts",
                ["oldestTime"] = 1632969957,
                ["wasAltered"] = true,
                ["newestTime"] = 1632969957,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7434,
                        ["guild"] = 1,
                        ["buyer"] = 149,
                        ["wasKiosk"] = false,
                        ["seller"] = 159,
                        ["timestamp"] = 1632969957,
                        ["quant"] = 1,
                        ["id"] = "1690056143",
                        ["itemLink"] = 166,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [26586] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_jewelry_poisonresist.dds",
                ["itemDesc"] = "Superb Glyph of Poison Resist",
                ["oldestTime"] = 1632826389,
                ["wasAltered"] = true,
                ["newestTime"] = 1633251476,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 197,
                        ["guild"] = 1,
                        ["buyer"] = 398,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633001135,
                        ["quant"] = 1,
                        ["id"] = "1690240043",
                        ["itemLink"] = 407,
                    },
                    [2] = 
                    {
                        ["price"] = 77,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 78,
                        ["timestamp"] = 1633251476,
                        ["quant"] = 1,
                        ["id"] = "1692280571",
                        ["itemLink"] = 407,
                    },
                    [3] = 
                    {
                        ["price"] = 227,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632826389,
                        ["quant"] = 1,
                        ["id"] = "1688971359",
                        ["itemLink"] = 407,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp150 green fine miscellaneous jewelry glyph",
            },
        },
        [100683] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_medium_feet_d.dds",
                ["itemDesc"] = "Spriggan's Boots",
                ["oldestTime"] = 1633140363,
                ["wasAltered"] = true,
                ["newestTime"] = 1633140363,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8750,
                        ["guild"] = 1,
                        ["buyer"] = 1182,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1633140363,
                        ["quant"] = 1,
                        ["id"] = "1691294587",
                        ["itemLink"] = 1596,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set spriggan's thorns feet impenetrable",
            },
        },
        [71676] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 28: Ra Gada Bows",
                ["oldestTime"] = 1632872876,
                ["wasAltered"] = true,
                ["newestTime"] = 1633230720,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 698,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633050185,
                        ["quant"] = 1,
                        ["id"] = "1690607105",
                        ["itemLink"] = 888,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 709,
                        ["timestamp"] = 1633058153,
                        ["quant"] = 1,
                        ["id"] = "1690691649",
                        ["itemLink"] = 888,
                    },
                    [3] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 709,
                        ["timestamp"] = 1633058156,
                        ["quant"] = 1,
                        ["id"] = "1690691685",
                        ["itemLink"] = 888,
                    },
                    [4] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 911,
                        ["timestamp"] = 1633125303,
                        ["quant"] = 1,
                        ["id"] = "1691145161",
                        ["itemLink"] = 888,
                    },
                    [5] = 
                    {
                        ["price"] = 2435,
                        ["guild"] = 1,
                        ["buyer"] = 1607,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633219933,
                        ["quant"] = 1,
                        ["id"] = "1692011473",
                        ["itemLink"] = 888,
                    },
                    [6] = 
                    {
                        ["price"] = 4904,
                        ["guild"] = 1,
                        ["buyer"] = 1687,
                        ["wasKiosk"] = true,
                        ["seller"] = 765,
                        ["timestamp"] = 1633230720,
                        ["quant"] = 1,
                        ["id"] = "1692121711",
                        ["itemLink"] = 888,
                    },
                    [7] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2306,
                        ["wasKiosk"] = true,
                        ["seller"] = 261,
                        ["timestamp"] = 1632872876,
                        ["quant"] = 1,
                        ["id"] = "1689322237",
                        ["itemLink"] = 888,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [167986] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 97: Wayward Guardian Legs",
                ["oldestTime"] = 1632950247,
                ["wasAltered"] = true,
                ["newestTime"] = 1633133242,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 1124,
                        ["wasKiosk"] = true,
                        ["seller"] = 894,
                        ["timestamp"] = 1633133242,
                        ["quant"] = 1,
                        ["id"] = "1691222445",
                        ["itemLink"] = 1545,
                    },
                    [2] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 2586,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1632950247,
                        ["quant"] = 1,
                        ["id"] = "1689876211",
                        ["itemLink"] = 1545,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [42870] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_critter_vertebrate_guts.dds",
                ["itemDesc"] = "Guts, Lake Bait",
                ["oldestTime"] = 1632995795,
                ["wasAltered"] = true,
                ["newestTime"] = 1633212879,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3456,
                        ["guild"] = 1,
                        ["buyer"] = 382,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1632995795,
                        ["quant"] = 179,
                        ["id"] = "1690213137",
                        ["itemLink"] = 381,
                    },
                    [2] = 
                    {
                        ["price"] = 6100,
                        ["guild"] = 1,
                        ["buyer"] = 1023,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633212879,
                        ["quant"] = 200,
                        ["id"] = "1691939375",
                        ["itemLink"] = 381,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal miscellaneous lure",
            },
        },
        [180735] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_medium_chest_a.dds",
                ["itemDesc"] = "Plaguebreak Jack",
                ["oldestTime"] = 1632935101,
                ["wasAltered"] = true,
                ["newestTime"] = 1632935101,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2190,
                        ["guild"] = 1,
                        ["buyer"] = 626,
                        ["wasKiosk"] = false,
                        ["seller"] = 1112,
                        ["timestamp"] = 1632935101,
                        ["quant"] = 1,
                        ["id"] = "1689761411",
                        ["itemLink"] = 3727,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set plaguebreak chest sturdy",
            },
        },
    },
}
