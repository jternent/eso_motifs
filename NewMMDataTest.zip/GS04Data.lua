GS04DataSavedVariables =
{
    ["listingseu"] = 
    {
    },
    ["listingsna"] = 
    {
    },
    ["dataeu"] = 
    {
    },
    ["datana"] = 
    {
        [34305] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_pumpkin.dds",
                ["itemDesc"] = "Pumpkin",
                ["oldestTime"] = 1633138567,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305854,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5381,
                        ["guild"] = 1,
                        ["buyer"] = 1170,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633138567,
                        ["quant"] = 200,
                        ["id"] = "1691278161",
                        ["itemLink"] = 1588,
                    },
                    [2] = 
                    {
                        ["price"] = 670,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633305854,
                        ["quant"] = 50,
                        ["id"] = "1692798983",
                        ["itemLink"] = 1588,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [123141] = 
        {
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_hlaalu_medium_head_a.dds",
                ["itemDesc"] = "Defiler's Helmet",
                ["oldestTime"] = 1632831099,
                ["wasAltered"] = true,
                ["newestTime"] = 1632831099,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 2137,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1632831099,
                        ["quant"] = 1,
                        ["id"] = "1689005115",
                        ["itemLink"] = 3086,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set defiler head training",
            },
        },
        [119563] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_blacksmithing.dds",
                ["itemDesc"] = "Sealed Blacksmithing Writ",
                ["oldestTime"] = 1632825521,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311212,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4125,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1633311212,
                        ["quant"] = 1,
                        ["id"] = "1692862583",
                        ["itemLink"] = 2,
                    },
                    [2] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1632975719,
                        ["quant"] = 1,
                        ["id"] = "1690100427",
                        ["itemLink"] = 226,
                    },
                    [3] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1632975719,
                        ["quant"] = 1,
                        ["id"] = "1690100431",
                        ["itemLink"] = 227,
                    },
                    [4] = 
                    {
                        ["price"] = 2995,
                        ["guild"] = 1,
                        ["buyer"] = 387,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1632998459,
                        ["quant"] = 1,
                        ["id"] = "1690224509",
                        ["itemLink"] = 388,
                    },
                    [5] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 901,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633086261,
                        ["quant"] = 1,
                        ["id"] = "1690865033",
                        ["itemLink"] = 1219,
                    },
                    [6] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633111848,
                        ["quant"] = 1,
                        ["id"] = "1691050731",
                        ["itemLink"] = 1329,
                    },
                    [7] = 
                    {
                        ["price"] = 2645,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633111852,
                        ["quant"] = 1,
                        ["id"] = "1691050797",
                        ["itemLink"] = 1338,
                    },
                    [8] = 
                    {
                        ["price"] = 2198,
                        ["guild"] = 1,
                        ["buyer"] = 15,
                        ["wasKiosk"] = false,
                        ["seller"] = 399,
                        ["timestamp"] = 1633142685,
                        ["quant"] = 1,
                        ["id"] = "1691322137",
                        ["itemLink"] = 1624,
                    },
                    [9] = 
                    {
                        ["price"] = 2850,
                        ["guild"] = 1,
                        ["buyer"] = 1252,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1633149787,
                        ["quant"] = 1,
                        ["id"] = "1691388935",
                        ["itemLink"] = 1711,
                    },
                    [10] = 
                    {
                        ["price"] = 2600,
                        ["guild"] = 1,
                        ["buyer"] = 1252,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633156649,
                        ["quant"] = 1,
                        ["id"] = "1691443317",
                        ["itemLink"] = 1748,
                    },
                    [11] = 
                    {
                        ["price"] = 4170,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 279,
                        ["timestamp"] = 1633184322,
                        ["quant"] = 1,
                        ["id"] = "1691623629",
                        ["itemLink"] = 1971,
                    },
                    [12] = 
                    {
                        ["price"] = 3200,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633195434,
                        ["quant"] = 1,
                        ["id"] = "1691746095",
                        ["itemLink"] = 2138,
                    },
                    [13] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633198605,
                        ["quant"] = 1,
                        ["id"] = "1691775435",
                        ["itemLink"] = 2164,
                    },
                    [14] = 
                    {
                        ["price"] = 3600,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633198619,
                        ["quant"] = 1,
                        ["id"] = "1691775563",
                        ["itemLink"] = 2166,
                    },
                    [15] = 
                    {
                        ["price"] = 3850,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633198624,
                        ["quant"] = 1,
                        ["id"] = "1691775607",
                        ["itemLink"] = 2167,
                    },
                    [16] = 
                    {
                        ["price"] = 2300,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 515,
                        ["timestamp"] = 1633234700,
                        ["quant"] = 1,
                        ["id"] = "1692158861",
                        ["itemLink"] = 2468,
                    },
                    [17] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 866,
                        ["wasKiosk"] = true,
                        ["seller"] = 622,
                        ["timestamp"] = 1633302008,
                        ["quant"] = 1,
                        ["id"] = "1692762129",
                        ["itemLink"] = 2919,
                    },
                    [18] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1252,
                        ["wasKiosk"] = true,
                        ["seller"] = 100,
                        ["timestamp"] = 1632825521,
                        ["quant"] = 1,
                        ["id"] = "1688966307",
                        ["itemLink"] = 3021,
                    },
                    [19] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 201,
                        ["timestamp"] = 1632894561,
                        ["quant"] = 1,
                        ["id"] = "1689527143",
                        ["itemLink"] = 3552,
                    },
                    [20] = 
                    {
                        ["price"] = 1850,
                        ["guild"] = 1,
                        ["buyer"] = 2630,
                        ["wasKiosk"] = true,
                        ["seller"] = 533,
                        ["timestamp"] = 1632961508,
                        ["quant"] = 1,
                        ["id"] = "1689971249",
                        ["itemLink"] = 3923,
                    },
                },
                ["totalCount"] = 20,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [181516] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_str_leycellarendcap001.dds",
                ["itemDesc"] = "Leyawiin Alcove, Castle",
                ["oldestTime"] = 1633167943,
                ["wasAltered"] = true,
                ["newestTime"] = 1633167943,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633167943,
                        ["quant"] = 1,
                        ["id"] = "1691510121",
                        ["itemLink"] = 1872,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings structures",
            },
        },
        [77581] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_poisonmaking_reagent_torchbug_thorax.dds",
                ["itemDesc"] = "Torchbug Thorax",
                ["oldestTime"] = 1632925253,
                ["wasAltered"] = true,
                ["newestTime"] = 1633283817,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 383,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632996395,
                        ["quant"] = 20,
                        ["id"] = "1690215775",
                        ["itemLink"] = 382,
                    },
                    [2] = 
                    {
                        ["price"] = 110000,
                        ["guild"] = 1,
                        ["buyer"] = 900,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633085762,
                        ["quant"] = 200,
                        ["id"] = "1690861949",
                        ["itemLink"] = 382,
                    },
                    [3] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 900,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633085765,
                        ["quant"] = 2,
                        ["id"] = "1690861955",
                        ["itemLink"] = 382,
                    },
                    [4] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 900,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633085766,
                        ["quant"] = 2,
                        ["id"] = "1690861961",
                        ["itemLink"] = 382,
                    },
                    [5] = 
                    {
                        ["price"] = 130400,
                        ["guild"] = 1,
                        ["buyer"] = 1093,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633127356,
                        ["quant"] = 200,
                        ["id"] = "1691161989",
                        ["itemLink"] = 382,
                    },
                    [6] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 1941,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633283817,
                        ["quant"] = 20,
                        ["id"] = "1692554173",
                        ["itemLink"] = 382,
                    },
                    [7] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1448,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632925253,
                        ["quant"] = 10,
                        ["id"] = "1689688505",
                        ["itemLink"] = 382,
                    },
                    [8] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 1384,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1632959543,
                        ["quant"] = 100,
                        ["id"] = "1689956911",
                        ["itemLink"] = 382,
                    },
                    [9] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 1384,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1632959565,
                        ["quant"] = 100,
                        ["id"] = "1689957001",
                        ["itemLink"] = 382,
                    },
                    [10] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 1384,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1632959566,
                        ["quant"] = 100,
                        ["id"] = "1689957015",
                        ["itemLink"] = 382,
                    },
                    [11] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 1384,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1632959566,
                        ["quant"] = 100,
                        ["id"] = "1689957025",
                        ["itemLink"] = 382,
                    },
                    [12] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 1384,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1632959567,
                        ["quant"] = 100,
                        ["id"] = "1689957031",
                        ["itemLink"] = 382,
                    },
                },
                ["totalCount"] = 12,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [177169] = 
        {
            ["1:0:3:51:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_helm_heavy.dds",
                ["itemDesc"] = "Companion's Helm",
                ["oldestTime"] = 1633061462,
                ["wasAltered"] = true,
                ["newestTime"] = 1633061462,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 793,
                        ["wasKiosk"] = true,
                        ["seller"] = 8,
                        ["timestamp"] = 1633061462,
                        ["quant"] = 1,
                        ["id"] = "1690721397",
                        ["itemLink"] = 1026,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior heavy apparel head vigorous",
            },
        },
        [45843] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_008.dds",
                ["itemDesc"] = "Okori",
                ["oldestTime"] = 1632844971,
                ["wasAltered"] = true,
                ["newestTime"] = 1633281978,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 374,
                        ["guild"] = 1,
                        ["buyer"] = 250,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632978533,
                        ["quant"] = 9,
                        ["id"] = "1690122447",
                        ["itemLink"] = 253,
                    },
                    [2] = 
                    {
                        ["price"] = 41,
                        ["guild"] = 1,
                        ["buyer"] = 1047,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633119672,
                        ["quant"] = 1,
                        ["id"] = "1691103097",
                        ["itemLink"] = 253,
                    },
                    [3] = 
                    {
                        ["price"] = 287,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1633281978,
                        ["quant"] = 7,
                        ["id"] = "1692536821",
                        ["itemLink"] = 253,
                    },
                    [4] = 
                    {
                        ["price"] = 539,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1632844971,
                        ["quant"] = 13,
                        ["id"] = "1689099643",
                        ["itemLink"] = 253,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 white normal materials essence runestone",
            },
        },
        [167446] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_arkthzand_heavy_feet_a.dds",
                ["itemDesc"] = "Sabatons of the Radiant Bastion",
                ["oldestTime"] = 1632868151,
                ["wasAltered"] = true,
                ["newestTime"] = 1632868151,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1448,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1632868151,
                        ["quant"] = 1,
                        ["id"] = "1689288917",
                        ["itemLink"] = 3370,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set radiant bastion feet infused",
            },
        },
        [177176] = 
        {
            ["1:0:3:60:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_necklace.dds",
                ["itemDesc"] = "Companion's Necklace",
                ["oldestTime"] = 1633218790,
                ["wasAltered"] = true,
                ["newestTime"] = 1633270947,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1602,
                        ["wasKiosk"] = true,
                        ["seller"] = 43,
                        ["timestamp"] = 1633218790,
                        ["quant"] = 1,
                        ["id"] = "1691998605",
                        ["itemLink"] = 2334,
                    },
                    [2] = 
                    {
                        ["price"] = 12500,
                        ["guild"] = 1,
                        ["buyer"] = 1879,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1633270947,
                        ["quant"] = 1,
                        ["id"] = "1692415821",
                        ["itemLink"] = 2334,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior jewelry apparel neck vigorous",
            },
        },
        [794] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_medium_armor_standard_f_001.dds",
                ["itemDesc"] = "Rawhide",
                ["oldestTime"] = 1632714073,
                ["wasAltered"] = true,
                ["newestTime"] = 1633228962,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 850,
                        ["guild"] = 2,
                        ["buyer"] = 129,
                        ["wasKiosk"] = false,
                        ["seller"] = 125,
                        ["timestamp"] = 1632714073,
                        ["quant"] = 200,
                        ["id"] = "1688085757",
                        ["itemLink"] = 105,
                    },
                    [2] = 
                    {
                        ["price"] = 850,
                        ["guild"] = 2,
                        ["buyer"] = 124,
                        ["wasKiosk"] = false,
                        ["seller"] = 125,
                        ["timestamp"] = 1632769450,
                        ["quant"] = 200,
                        ["id"] = "1688524701",
                        ["itemLink"] = 105,
                    },
                    [3] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1672,
                        ["wasKiosk"] = true,
                        ["seller"] = 803,
                        ["timestamp"] = 1633228962,
                        ["quant"] = 100,
                        ["id"] = "1692106453",
                        ["itemLink"] = 105,
                    },
                    [4] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 426,
                        ["wasKiosk"] = false,
                        ["seller"] = 47,
                        ["timestamp"] = 1632864774,
                        ["quant"] = 200,
                        ["id"] = "1689263987",
                        ["itemLink"] = 105,
                    },
                    [5] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 426,
                        ["wasKiosk"] = false,
                        ["seller"] = 47,
                        ["timestamp"] = 1632864776,
                        ["quant"] = 200,
                        ["id"] = "1689264005",
                        ["itemLink"] = 105,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [175899] = 
        {
            ["1:0:4:52:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_necklace.dds",
                ["itemDesc"] = "Companion's Necklace",
                ["oldestTime"] = 1633198330,
                ["wasAltered"] = true,
                ["newestTime"] = 1633198330,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 377777,
                        ["guild"] = 1,
                        ["buyer"] = 1473,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633198330,
                        ["quant"] = 1,
                        ["id"] = "1691772077",
                        ["itemLink"] = 2160,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic jewelry apparel neck quickened",
            },
        },
        [176413] = 
        {
            ["1:0:2:46:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_helm_heavy.dds",
                ["itemDesc"] = "Companion's Helm",
                ["oldestTime"] = 1633264818,
                ["wasAltered"] = true,
                ["newestTime"] = 1633264818,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2222,
                        ["guild"] = 1,
                        ["buyer"] = 1851,
                        ["wasKiosk"] = true,
                        ["seller"] = 494,
                        ["timestamp"] = 1633264818,
                        ["quant"] = 1,
                        ["id"] = "1692357251",
                        ["itemLink"] = 2636,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine heavy apparel head shattering",
            },
        },
        [176158] = 
        {
            ["1:0:3:44:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_pants_medium.dds",
                ["itemDesc"] = "Companion's Guards",
                ["oldestTime"] = 1633064488,
                ["wasAltered"] = true,
                ["newestTime"] = 1633064488,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 812,
                        ["wasKiosk"] = true,
                        ["seller"] = 177,
                        ["timestamp"] = 1633064488,
                        ["quant"] = 1,
                        ["id"] = "1690744407",
                        ["itemLink"] = 1052,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior medium apparel legs prolific",
            },
        },
        [10272] = 
        {
            ["50:16:2:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_2haxe_d.dds",
                ["itemDesc"] = "Pactbreaker",
                ["oldestTime"] = 1633125844,
                ["wasAltered"] = true,
                ["newestTime"] = 1633125844,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1105,
                        ["guild"] = 1,
                        ["buyer"] = 1084,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1633125844,
                        ["quant"] = 1,
                        ["id"] = "1691148655",
                        ["itemLink"] = 1483,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set pact axe two-handed sharpened",
            },
        },
        [802] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_forester_weapon_component_004.dds",
                ["itemDesc"] = "Rough Maple",
                ["oldestTime"] = 1633214371,
                ["wasAltered"] = true,
                ["newestTime"] = 1633296146,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1575,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633214371,
                        ["quant"] = 200,
                        ["id"] = "1691953327",
                        ["itemLink"] = 2298,
                    },
                    [2] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 1805,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633247643,
                        ["quant"] = 98,
                        ["id"] = "1692255539",
                        ["itemLink"] = 2298,
                    },
                    [3] = 
                    {
                        ["price"] = 4095,
                        ["guild"] = 1,
                        ["buyer"] = 1575,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633296146,
                        ["quant"] = 117,
                        ["id"] = "1692702177",
                        ["itemLink"] = 2298,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [45348] = 
        {
            ["1:0:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ashlanderv_light_feet_a.dds",
                ["itemDesc"] = "Homespun Shoes",
                ["oldestTime"] = 1633059420,
                ["wasAltered"] = true,
                ["newestTime"] = 1633084684,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 180,
                        ["guild"] = 1,
                        ["buyer"] = 780,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633059420,
                        ["quant"] = 1,
                        ["id"] = "1690704579",
                        ["itemLink"] = 994,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084684,
                        ["quant"] = 1,
                        ["id"] = "1690857371",
                        ["itemLink"] = 994,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal light apparel feet intricate",
            },
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_light_feet_d.dds",
                ["itemDesc"] = "Ancestor Silk Shoes",
                ["oldestTime"] = 1632841095,
                ["wasAltered"] = true,
                ["newestTime"] = 1633121631,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633009346,
                        ["quant"] = 1,
                        ["id"] = "1690285215",
                        ["itemLink"] = 459,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009368,
                        ["quant"] = 1,
                        ["id"] = "1690285467",
                        ["itemLink"] = 459,
                    },
                    [3] = 
                    {
                        ["price"] = 180,
                        ["guild"] = 1,
                        ["buyer"] = 1055,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633121631,
                        ["quant"] = 1,
                        ["id"] = "1691116711",
                        ["itemLink"] = 1440,
                    },
                    [4] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1632841095,
                        ["quant"] = 1,
                        ["id"] = "1689067929",
                        ["itemLink"] = 3151,
                    },
                    [5] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2501,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632930586,
                        ["quant"] = 1,
                        ["id"] = "1689726373",
                        ["itemLink"] = 3703,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "cp160 white normal light apparel feet intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_feet_d.dds",
                ["itemDesc"] = "Ancestor Silk Shoes",
                ["oldestTime"] = 1633084679,
                ["wasAltered"] = true,
                ["newestTime"] = 1633084681,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633084679,
                        ["quant"] = 1,
                        ["id"] = "1690857317",
                        ["itemLink"] = 1203,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084681,
                        ["quant"] = 1,
                        ["id"] = "1690857339",
                        ["itemLink"] = 1206,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp150 white normal light apparel feet intricate",
            },
        },
        [115750] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Argonian Canopy, Reed",
                ["oldestTime"] = 1633150046,
                ["wasAltered"] = true,
                ["newestTime"] = 1633150046,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1255,
                        ["wasKiosk"] = true,
                        ["seller"] = 1108,
                        ["timestamp"] = 1633150046,
                        ["quant"] = 1,
                        ["id"] = "1691391421",
                        ["itemLink"] = 1715,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [172071] = 
        {
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_head_a.dds",
                ["itemDesc"] = "Hat of Frostbite",
                ["oldestTime"] = 1633046711,
                ["wasAltered"] = true,
                ["newestTime"] = 1633046711,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 681,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1633046711,
                        ["quant"] = 1,
                        ["id"] = "1690572945",
                        ["itemLink"] = 867,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set frostbite head invigorating",
            },
        },
        [176168] = 
        {
            ["1:0:3:53:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_necklace.dds",
                ["itemDesc"] = "Companion's Necklace",
                ["oldestTime"] = 1632882989,
                ["wasAltered"] = true,
                ["newestTime"] = 1632882989,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 2370,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1632882989,
                        ["quant"] = 1,
                        ["id"] = "1689427789",
                        ["itemLink"] = 3482,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior jewelry apparel neck prolific",
            },
        },
        [160553] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 85: Greymoor Shields",
                ["oldestTime"] = 1633199479,
                ["wasAltered"] = true,
                ["newestTime"] = 1633199479,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1477,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633199479,
                        ["quant"] = 1,
                        ["id"] = "1691783817",
                        ["itemLink"] = 2178,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [16426] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_book_001.dds",
                ["itemDesc"] = "Crafting Motif 8: Orc Style",
                ["oldestTime"] = 1632820723,
                ["wasAltered"] = true,
                ["newestTime"] = 1633304363,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 484,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1633017922,
                        ["quant"] = 1,
                        ["id"] = "1690348881",
                        ["itemLink"] = 560,
                    },
                    [2] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2056,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1633304363,
                        ["quant"] = 1,
                        ["id"] = "1692783575",
                        ["itemLink"] = 560,
                    },
                    [3] = 
                    {
                        ["price"] = 221,
                        ["guild"] = 1,
                        ["buyer"] = 2103,
                        ["wasKiosk"] = true,
                        ["seller"] = 711,
                        ["timestamp"] = 1632820723,
                        ["quant"] = 1,
                        ["id"] = "1688947323",
                        ["itemLink"] = 560,
                    },
                    [4] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2304,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1632872694,
                        ["quant"] = 1,
                        ["id"] = "1689320603",
                        ["itemLink"] = 560,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior consumable motif",
            },
        },
        [175917] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Wall Shelf, Carved",
                ["oldestTime"] = 1632865533,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865533,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1632865533,
                        ["quant"] = 1,
                        ["id"] = "1689268871",
                        ["itemLink"] = 3342,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [74543] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 32: Abah's Watch Bows",
                ["oldestTime"] = 1632865374,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865374,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24923,
                        ["guild"] = 1,
                        ["buyer"] = 2263,
                        ["wasKiosk"] = true,
                        ["seller"] = 402,
                        ["timestamp"] = 1632865374,
                        ["quant"] = 1,
                        ["id"] = "1689267419",
                        ["itemLink"] = 3335,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [123699] = 
        {
            ["50:16:4:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_light_waist_a.dds",
                ["itemDesc"] = "Knight Slayer Sash",
                ["oldestTime"] = 1633021973,
                ["wasAltered"] = true,
                ["newestTime"] = 1633021973,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 8,
                        ["wasKiosk"] = false,
                        ["seller"] = 237,
                        ["timestamp"] = 1633021973,
                        ["quant"] = 1,
                        ["id"] = "1690383693",
                        ["itemLink"] = 591,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set knight slayer waist training",
            },
        },
        [45622] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Blacklight Ginger Mazte",
                ["oldestTime"] = 1633115940,
                ["wasAltered"] = true,
                ["newestTime"] = 1633115940,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1024,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633115940,
                        ["quant"] = 1,
                        ["id"] = "1691078105",
                        ["itemLink"] = 1401,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [175671] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_inc_leykitchenfoodgravy001.dds",
                ["itemDesc"] = "Leyawiin Mug, Milk",
                ["oldestTime"] = 1633113869,
                ["wasAltered"] = true,
                ["newestTime"] = 1633113869,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45999,
                        ["guild"] = 1,
                        ["buyer"] = 1005,
                        ["wasKiosk"] = true,
                        ["seller"] = 290,
                        ["timestamp"] = 1633113869,
                        ["quant"] = 2,
                        ["id"] = "1691064633",
                        ["itemLink"] = 1373,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings hearth",
            },
        },
        [175673] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_inc_leykitchenhicup002.dds",
                ["itemDesc"] = "Leyawiin Kylix, Silver",
                ["oldestTime"] = 1633113837,
                ["wasAltered"] = true,
                ["newestTime"] = 1633113837,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9600,
                        ["guild"] = 1,
                        ["buyer"] = 1005,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633113837,
                        ["quant"] = 1,
                        ["id"] = "1691064387",
                        ["itemLink"] = 1368,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings hearth",
            },
        },
        [176698] = 
        {
            ["1:0:2:48:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_pants_medium.dds",
                ["itemDesc"] = "Companion's Guards",
                ["oldestTime"] = 1633222377,
                ["wasAltered"] = true,
                ["newestTime"] = 1633222377,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 1620,
                        ["wasKiosk"] = true,
                        ["seller"] = 50,
                        ["timestamp"] = 1633222377,
                        ["quant"] = 1,
                        ["id"] = "1692036113",
                        ["itemLink"] = 2358,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine medium apparel legs soothing",
            },
        },
        [172092] = 
        {
            ["50:16:2:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_head_a.dds",
                ["itemDesc"] = "Hat of Frostbite",
                ["oldestTime"] = 1633089998,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182275,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 916,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1633089998,
                        ["quant"] = 1,
                        ["id"] = "1690888549",
                        ["itemLink"] = 1237,
                    },
                    [2] = 
                    {
                        ["price"] = 255,
                        ["guild"] = 1,
                        ["buyer"] = 1377,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633182275,
                        ["quant"] = 1,
                        ["id"] = "1691606321",
                        ["itemLink"] = 1237,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite head sturdy",
            },
        },
        [75071] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_staff_a.dds",
                ["itemDesc"] = "Inferno Staff of the Night Mother",
                ["oldestTime"] = 1633002534,
                ["wasAltered"] = true,
                ["newestTime"] = 1633002534,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 410,
                        ["wasKiosk"] = true,
                        ["seller"] = 237,
                        ["timestamp"] = 1633002534,
                        ["quant"] = 1,
                        ["id"] = "1690246697",
                        ["itemLink"] = 417,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set night mother's embrace flame staff two-handed infused",
            },
            ["50:16:2:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_staff_a.dds",
                ["itemDesc"] = "Inferno Staff of the Night Mother",
                ["oldestTime"] = 1632868213,
                ["wasAltered"] = true,
                ["newestTime"] = 1632868213,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2340,
                        ["guild"] = 1,
                        ["buyer"] = 2278,
                        ["wasKiosk"] = true,
                        ["seller"] = 605,
                        ["timestamp"] = 1632868213,
                        ["quant"] = 1,
                        ["id"] = "1689289325",
                        ["itemLink"] = 3371,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set night mother's embrace flame staff two-handed infused",
            },
        },
        [74560] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 33: Thieves Guild Chests",
                ["oldestTime"] = 1632967540,
                ["wasAltered"] = true,
                ["newestTime"] = 1632967540,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 2668,
                        ["wasKiosk"] = true,
                        ["seller"] = 159,
                        ["timestamp"] = 1632967540,
                        ["quant"] = 1,
                        ["id"] = "1690029629",
                        ["itemLink"] = 3974,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [118337] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_gen_exc_fish001.dds",
                ["itemDesc"] = "Fish, Trout",
                ["oldestTime"] = 1633106157,
                ["wasAltered"] = true,
                ["newestTime"] = 1633106193,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1050,
                        ["guild"] = 1,
                        ["buyer"] = 960,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633106157,
                        ["quant"] = 3,
                        ["id"] = "1691010325",
                        ["itemLink"] = 1298,
                    },
                    [2] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 960,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633106193,
                        ["quant"] = 9,
                        ["id"] = "1691010557",
                        ["itemLink"] = 1298,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings hearth",
            },
        },
        [119362] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Common Basket, Tall",
                ["oldestTime"] = 1632818908,
                ["wasAltered"] = true,
                ["newestTime"] = 1632818908,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 148,
                        ["guild"] = 1,
                        ["buyer"] = 1142,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1632818908,
                        ["quant"] = 1,
                        ["id"] = "1688938821",
                        ["itemLink"] = 3007,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [176708] = 
        {
            ["1:0:2:57:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_necklace.dds",
                ["itemDesc"] = "Companion's Necklace",
                ["oldestTime"] = 1633147734,
                ["wasAltered"] = true,
                ["newestTime"] = 1633147734,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3665,
                        ["guild"] = 1,
                        ["buyer"] = 1241,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1633147734,
                        ["quant"] = 1,
                        ["id"] = "1691372095",
                        ["itemLink"] = 1678,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine jewelry apparel neck soothing",
            },
        },
        [181576] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Wall, Wooden Half",
                ["oldestTime"] = 1633141728,
                ["wasAltered"] = true,
                ["newestTime"] = 1633141728,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1190,
                        ["wasKiosk"] = true,
                        ["seller"] = 911,
                        ["timestamp"] = 1633141728,
                        ["quant"] = 1,
                        ["id"] = "1691310061",
                        ["itemLink"] = 1615,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [79433] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_shield_a.dds",
                ["itemDesc"] = "Shield of the Pariah",
                ["oldestTime"] = 1632986496,
                ["wasAltered"] = true,
                ["newestTime"] = 1632986496,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1150,
                        ["guild"] = 1,
                        ["buyer"] = 319,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1632986496,
                        ["quant"] = 1,
                        ["id"] = "1690167345",
                        ["itemLink"] = 325,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior apparel weapon set mark of the pariah shield off hand divines",
            },
        },
        [79434] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_shield_a.dds",
                ["itemDesc"] = "Shield of the Pariah",
                ["oldestTime"] = 1633237967,
                ["wasAltered"] = true,
                ["newestTime"] = 1633237967,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 695,
                        ["timestamp"] = 1633237967,
                        ["quant"] = 1,
                        ["id"] = "1692185411",
                        ["itemLink"] = 2501,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior apparel weapon set mark of the pariah shield off hand infused",
            },
        },
        [139083] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_sum_salicornia010.dds",
                ["itemDesc"] = "Plants, Glasswort Patch",
                ["oldestTime"] = 1633034589,
                ["wasAltered"] = true,
                ["newestTime"] = 1633034589,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 587,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633034589,
                        ["quant"] = 1,
                        ["id"] = "1690473669",
                        ["itemLink"] = 757,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings conservatory",
            },
        },
        [45135] = 
        {
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_heavy_shoulders_d.dds",
                ["itemDesc"] = "Rubedite Pauldron of Health",
                ["oldestTime"] = 1633185954,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185954,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 144,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633185954,
                        ["quant"] = 1,
                        ["id"] = "1691640289",
                        ["itemLink"] = 2030,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel shoulders well-fitted",
            },
        },
        [172113] = 
        {
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_head_a.dds",
                ["itemDesc"] = "Hat of Frostbite",
                ["oldestTime"] = 1633182292,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182292,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1377,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633182292,
                        ["quant"] = 1,
                        ["id"] = "1691606431",
                        ["itemLink"] = 1940,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set frostbite head training",
            },
            ["50:16:2:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_head_a.dds",
                ["itemDesc"] = "Hat of Frostbite",
                ["oldestTime"] = 1633018555,
                ["wasAltered"] = true,
                ["newestTime"] = 1633018555,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 498,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633018555,
                        ["quant"] = 1,
                        ["id"] = "1690354755",
                        ["itemLink"] = 570,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite head training",
            },
        },
        [176210] = 
        {
            ["1:0:4:35:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_mace.dds",
                ["itemDesc"] = "Companion's Mace",
                ["oldestTime"] = 1633142147,
                ["wasAltered"] = true,
                ["newestTime"] = 1633142147,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 149,
                        ["wasKiosk"] = false,
                        ["seller"] = 530,
                        ["timestamp"] = 1633142147,
                        ["quant"] = 1,
                        ["id"] = "1691314613",
                        ["itemLink"] = 1620,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic weapon mace one-handed prolific",
            },
        },
        [142419] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Dead-Water's Guile Necklace",
                ["oldestTime"] = 1632835701,
                ["wasAltered"] = true,
                ["newestTime"] = 1632835701,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 2154,
                        ["wasKiosk"] = true,
                        ["seller"] = 2155,
                        ["timestamp"] = 1632835701,
                        ["quant"] = 1,
                        ["id"] = "1689032327",
                        ["itemLink"] = 3101,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set dead-water's guile neck robust",
            },
        },
        [51541] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_medium_chest_d.dds",
                ["itemDesc"] = "Jack of Hunding's Rage",
                ["oldestTime"] = 1633221010,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310411,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1613,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633221010,
                        ["quant"] = 1,
                        ["id"] = "1692021569",
                        ["itemLink"] = 2350,
                    },
                    [2] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2090,
                        ["wasKiosk"] = true,
                        ["seller"] = 65,
                        ["timestamp"] = 1633310411,
                        ["quant"] = 1,
                        ["id"] = "1692853837",
                        ["itemLink"] = 2993,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic medium apparel set hunding's rage chest divines",
            },
        },
        [71766] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_runecrafter_plug_component_005.dds",
                ["itemDesc"] = "Azure Plasm",
                ["oldestTime"] = 1633121512,
                ["wasAltered"] = true,
                ["newestTime"] = 1633121512,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1054,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633121512,
                        ["quant"] = 21,
                        ["id"] = "1691115519",
                        ["itemLink"] = 1439,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [99159] = 
        {
            ["50:16:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_heavy_chest_d.dds",
                ["itemDesc"] = "Cuirass of the Hatchling's Shell",
                ["oldestTime"] = 1633021994,
                ["wasAltered"] = true,
                ["newestTime"] = 1633021994,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 8,
                        ["wasKiosk"] = false,
                        ["seller"] = 348,
                        ["timestamp"] = 1633021994,
                        ["quant"] = 1,
                        ["id"] = "1690383899",
                        ["itemLink"] = 592,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set hatchling's shell chest impenetrable",
            },
        },
        [23130] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_light_armor_standard_f_004.dds",
                ["itemDesc"] = "Raw Spidersilk",
                ["oldestTime"] = 1632986531,
                ["wasAltered"] = true,
                ["newestTime"] = 1632986534,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632986531,
                        ["quant"] = 200,
                        ["id"] = "1690167449",
                        ["itemLink"] = 326,
                    },
                    [2] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632986532,
                        ["quant"] = 200,
                        ["id"] = "1690167451",
                        ["itemLink"] = 326,
                    },
                    [3] = 
                    {
                        ["price"] = 21000,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632986534,
                        ["quant"] = 175,
                        ["id"] = "1690167453",
                        ["itemLink"] = 326,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [158300] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 83: Pyre Watch Legs",
                ["oldestTime"] = 1633267506,
                ["wasAltered"] = true,
                ["newestTime"] = 1633267506,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200000,
                        ["guild"] = 1,
                        ["buyer"] = 1862,
                        ["wasKiosk"] = true,
                        ["seller"] = 712,
                        ["timestamp"] = 1633267506,
                        ["quant"] = 1,
                        ["id"] = "1692379181",
                        ["itemLink"] = 2643,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [82014] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 41: Celestial Helmets",
                ["oldestTime"] = 1632969979,
                ["wasAltered"] = true,
                ["newestTime"] = 1632969979,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 149,
                        ["wasKiosk"] = false,
                        ["seller"] = 97,
                        ["timestamp"] = 1632969979,
                        ["quant"] = 1,
                        ["id"] = "1690056287",
                        ["itemLink"] = 167,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [167264] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_stonehuskfragment.dds",
                ["itemDesc"] = "Rune-Carved Bone Fragment",
                ["oldestTime"] = 1633144703,
                ["wasAltered"] = true,
                ["newestTime"] = 1633144703,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 43471,
                        ["guild"] = 1,
                        ["buyer"] = 366,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633144703,
                        ["quant"] = 29,
                        ["id"] = "1691344395",
                        ["itemLink"] = 1647,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [176737] = 
        {
            ["1:0:3:48:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_helm_heavy.dds",
                ["itemDesc"] = "Companion's Helm",
                ["oldestTime"] = 1633193581,
                ["wasAltered"] = true,
                ["newestTime"] = 1633193581,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 32,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1633193581,
                        ["quant"] = 1,
                        ["id"] = "1691730209",
                        ["itemLink"] = 2124,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior heavy apparel head soothing",
            },
        },
        [165730] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_fur_housingbookshelffancyfilled003.dds",
                ["itemDesc"] = "Solitude Bookcase, Backless Filled",
                ["oldestTime"] = 1633297838,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297838,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 49063,
                        ["guild"] = 1,
                        ["buyer"] = 2029,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1633297838,
                        ["quant"] = 2,
                        ["id"] = "1692719279",
                        ["itemLink"] = 2892,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings library",
            },
        },
        [75363] = 
        {
            ["50:5:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_potion_base_oil_4_r1.dds",
                ["itemDesc"] = "Tarblack",
                ["oldestTime"] = 1632949086,
                ["wasAltered"] = true,
                ["newestTime"] = 1632949086,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 2579,
                        ["wasKiosk"] = true,
                        ["seller"] = 803,
                        ["timestamp"] = 1632949086,
                        ["quant"] = 40,
                        ["id"] = "1689866651",
                        ["itemLink"] = 3804,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp50 white normal materials poison solvent",
            },
        },
        [76900] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 38: Draugr Daggers",
                ["oldestTime"] = 1633083861,
                ["wasAltered"] = true,
                ["newestTime"] = 1633083861,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 893,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633083861,
                        ["quant"] = 1,
                        ["id"] = "1690853449",
                        ["itemLink"] = 1142,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [175973] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing3.dds",
                ["itemDesc"] = "Diagram: Leyawiin Brazier, Iron",
                ["oldestTime"] = 1632843660,
                ["wasAltered"] = true,
                ["newestTime"] = 1633276416,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 709,
                        ["timestamp"] = 1633060366,
                        ["quant"] = 1,
                        ["id"] = "1690713405",
                        ["itemLink"] = 1010,
                    },
                    [2] = 
                    {
                        ["price"] = 18900,
                        ["guild"] = 1,
                        ["buyer"] = 1398,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633276416,
                        ["quant"] = 1,
                        ["id"] = "1692479741",
                        ["itemLink"] = 1010,
                    },
                    [3] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 2191,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632843660,
                        ["quant"] = 1,
                        ["id"] = "1689088939",
                        ["itemLink"] = 1010,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [160870] = 
        {
            ["50:16:4:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_grayhost_bow_a.dds",
                ["itemDesc"] = "Venomous Bow",
                ["oldestTime"] = 1632951577,
                ["wasAltered"] = true,
                ["newestTime"] = 1632951577,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 39995,
                        ["guild"] = 1,
                        ["buyer"] = 2592,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1632951577,
                        ["quant"] = 1,
                        ["id"] = "1689888249",
                        ["itemLink"] = 3844,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set venomous smite bow two-handed precise",
            },
        },
        [171879] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 103: Black Fin Legion Axes",
                ["oldestTime"] = 1633115951,
                ["wasAltered"] = true,
                ["newestTime"] = 1633115951,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1024,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1633115951,
                        ["quant"] = 1,
                        ["id"] = "1691078289",
                        ["itemLink"] = 1402,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [180587] = 
        {
            ["50:16:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_staff_a.dds",
                ["itemDesc"] = "Restoration Staff of Dark Convergence",
                ["oldestTime"] = 1633267848,
                ["wasAltered"] = true,
                ["newestTime"] = 1633267848,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2222,
                        ["guild"] = 1,
                        ["buyer"] = 1865,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633267848,
                        ["quant"] = 1,
                        ["id"] = "1692383309",
                        ["itemLink"] = 2644,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set dark convergence healing staff two-handed training",
            },
        },
        [142700] = 
        {
            ["50:16:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_elderarg_light_feet_a.dds",
                ["itemDesc"] = "Bright-Throat's Boast Shoes",
                ["oldestTime"] = 1633039469,
                ["wasAltered"] = true,
                ["newestTime"] = 1633039469,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 620,
                        ["wasKiosk"] = true,
                        ["seller"] = 252,
                        ["timestamp"] = 1633039469,
                        ["quant"] = 1,
                        ["id"] = "1690510103",
                        ["itemLink"] = 783,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set bright-throat's boast feet impenetrable",
            },
        },
        [68206] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Late Hearthfire Vegetable Tart",
                ["oldestTime"] = 1632913056,
                ["wasAltered"] = true,
                ["newestTime"] = 1633157998,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1293,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1633157992,
                        ["quant"] = 2,
                        ["id"] = "1691453989",
                        ["itemLink"] = 1774,
                    },
                    [2] = 
                    {
                        ["price"] = 99,
                        ["guild"] = 1,
                        ["buyer"] = 1293,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633157998,
                        ["quant"] = 1,
                        ["id"] = "1691454011",
                        ["itemLink"] = 1774,
                    },
                    [3] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 2471,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632913056,
                        ["quant"] = 1,
                        ["id"] = "1689612461",
                        ["itemLink"] = 1774,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [155249] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dragonguard_shield_a.dds",
                ["itemDesc"] = "Dragonguard Elite's Shield",
                ["oldestTime"] = 1632912391,
                ["wasAltered"] = true,
                ["newestTime"] = 1632912391,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 2467,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632912391,
                        ["quant"] = 1,
                        ["id"] = "1689610097",
                        ["itemLink"] = 3620,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior apparel weapon set dragonguard elite shield off hand divines",
            },
        },
        [160627] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Winter's Respite",
                ["oldestTime"] = 1632908781,
                ["wasAltered"] = true,
                ["newestTime"] = 1632908781,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 1959,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1632908781,
                        ["quant"] = 1,
                        ["id"] = "1689597957",
                        ["itemLink"] = 3596,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set winter's respite ring arcane",
            },
            ["50:16:2:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Winter's Respite",
                ["oldestTime"] = 1632918870,
                ["wasAltered"] = true,
                ["newestTime"] = 1632918870,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2480,
                        ["wasKiosk"] = true,
                        ["seller"] = 445,
                        ["timestamp"] = 1632918870,
                        ["quant"] = 1,
                        ["id"] = "1689645537",
                        ["itemLink"] = 3644,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set winter's respite ring arcane",
            },
        },
        [171380] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_fur_markbookshelfhousing001.dds",
                ["itemDesc"] = "Dwarven Bookcase, Granite Filled",
                ["oldestTime"] = 1633045230,
                ["wasAltered"] = true,
                ["newestTime"] = 1633045230,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 77716,
                        ["guild"] = 1,
                        ["buyer"] = 668,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1633045230,
                        ["quant"] = 2,
                        ["id"] = "1690558467",
                        ["itemLink"] = 851,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings library",
            },
        },
        [116086] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_2.dds",
                ["itemDesc"] = "Pattern: Khajiit Drapes, Tattered",
                ["oldestTime"] = 1633158042,
                ["wasAltered"] = true,
                ["newestTime"] = 1633158057,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 60,
                        ["guild"] = 1,
                        ["buyer"] = 1293,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633158042,
                        ["quant"] = 1,
                        ["id"] = "1691454517",
                        ["itemLink"] = 1777,
                    },
                    [2] = 
                    {
                        ["price"] = 155,
                        ["guild"] = 1,
                        ["buyer"] = 1293,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1633158057,
                        ["quant"] = 1,
                        ["id"] = "1691454683",
                        ["itemLink"] = 1777,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [42872] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_fishing_torchbug.dds",
                ["itemDesc"] = "Insect Parts, River Bait",
                ["oldestTime"] = 1632861491,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310880,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 446,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633009589,
                        ["quant"] = 200,
                        ["id"] = "1690287327",
                        ["itemLink"] = 511,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 720,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633052839,
                        ["quant"] = 200,
                        ["id"] = "1690633627",
                        ["itemLink"] = 511,
                    },
                    [3] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1757,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633239279,
                        ["quant"] = 59,
                        ["id"] = "1692192997",
                        ["itemLink"] = 511,
                    },
                    [4] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1841,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633262410,
                        ["quant"] = 47,
                        ["id"] = "1692339413",
                        ["itemLink"] = 511,
                    },
                    [5] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2073,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633307677,
                        ["quant"] = 200,
                        ["id"] = "1692819741",
                        ["itemLink"] = 511,
                    },
                    [6] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 751,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633310880,
                        ["quant"] = 200,
                        ["id"] = "1692858609",
                        ["itemLink"] = 511,
                    },
                    [7] = 
                    {
                        ["price"] = 2600,
                        ["guild"] = 1,
                        ["buyer"] = 2246,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1632861491,
                        ["quant"] = 200,
                        ["id"] = "1689241113",
                        ["itemLink"] = 511,
                    },
                    [8] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1442,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1632948797,
                        ["quant"] = 200,
                        ["id"] = "1689863961",
                        ["itemLink"] = 511,
                    },
                    [9] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1442,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1632948798,
                        ["quant"] = 200,
                        ["id"] = "1689863979",
                        ["itemLink"] = 511,
                    },
                    [10] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1442,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1632948801,
                        ["quant"] = 200,
                        ["id"] = "1689864021",
                        ["itemLink"] = 511,
                    },
                },
                ["totalCount"] = 10,
                ["itemAdderText"] = "rr01 white normal miscellaneous lure",
            },
        },
        [73849] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 30: Morag Tong Shields",
                ["oldestTime"] = 1633195666,
                ["wasAltered"] = true,
                ["newestTime"] = 1633195666,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 242,
                        ["wasKiosk"] = false,
                        ["seller"] = 276,
                        ["timestamp"] = 1633195666,
                        ["quant"] = 1,
                        ["id"] = "1691748009",
                        ["itemLink"] = 2143,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [180861] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_heavy_feet_a.dds",
                ["itemDesc"] = "Hrothgar's Sabatons",
                ["oldestTime"] = 1633313128,
                ["wasAltered"] = true,
                ["newestTime"] = 1633313128,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12121,
                        ["guild"] = 1,
                        ["buyer"] = 47,
                        ["wasKiosk"] = false,
                        ["seller"] = 48,
                        ["timestamp"] = 1633313128,
                        ["quant"] = 1,
                        ["id"] = "1692881381",
                        ["itemLink"] = 34,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set hrothgar's chill feet impenetrable",
            },
        },
        [96383] = 
        {
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of the Trainee",
                ["oldestTime"] = 1632879449,
                ["wasAltered"] = true,
                ["newestTime"] = 1632879449,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5245,
                        ["guild"] = 1,
                        ["buyer"] = 2347,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1632879449,
                        ["quant"] = 1,
                        ["id"] = "1689390691",
                        ["itemLink"] = 3442,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set armor of the trainee neck healthy",
            },
        },
        [119680] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_blacksmithing.dds",
                ["itemDesc"] = "Sealed Blacksmithing Writ",
                ["oldestTime"] = 1632870216,
                ["wasAltered"] = true,
                ["newestTime"] = 1633285581,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3995,
                        ["guild"] = 1,
                        ["buyer"] = 210,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1632975368,
                        ["quant"] = 1,
                        ["id"] = "1690098403",
                        ["itemLink"] = 220,
                    },
                    [2] = 
                    {
                        ["price"] = 3900,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1633032677,
                        ["quant"] = 1,
                        ["id"] = "1690462281",
                        ["itemLink"] = 743,
                    },
                    [3] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 43,
                        ["timestamp"] = 1633032725,
                        ["quant"] = 1,
                        ["id"] = "1690462441",
                        ["itemLink"] = 746,
                    },
                    [4] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1633032734,
                        ["quant"] = 1,
                        ["id"] = "1690462481",
                        ["itemLink"] = 747,
                    },
                    [5] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 201,
                        ["timestamp"] = 1633057828,
                        ["quant"] = 1,
                        ["id"] = "1690688705",
                        ["itemLink"] = 973,
                    },
                    [6] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 1466,
                        ["wasKiosk"] = true,
                        ["seller"] = 1077,
                        ["timestamp"] = 1633197890,
                        ["quant"] = 1,
                        ["id"] = "1691768167",
                        ["itemLink"] = 2155,
                    },
                    [7] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633198595,
                        ["quant"] = 1,
                        ["id"] = "1691775323",
                        ["itemLink"] = 2163,
                    },
                    [8] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 155,
                        ["timestamp"] = 1633233514,
                        ["quant"] = 1,
                        ["id"] = "1692149555",
                        ["itemLink"] = 2457,
                    },
                    [9] = 
                    {
                        ["price"] = 3001,
                        ["guild"] = 1,
                        ["buyer"] = 1951,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633285581,
                        ["quant"] = 1,
                        ["id"] = "1692572399",
                        ["itemLink"] = 2753,
                    },
                    [10] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 201,
                        ["timestamp"] = 1632870216,
                        ["quant"] = 1,
                        ["id"] = "1689304967",
                        ["itemLink"] = 3384,
                    },
                    [11] = 
                    {
                        ["price"] = 3900,
                        ["guild"] = 1,
                        ["buyer"] = 2461,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632910805,
                        ["quant"] = 1,
                        ["id"] = "1689603735",
                        ["itemLink"] = 3602,
                    },
                    [12] = 
                    {
                        ["price"] = 3900,
                        ["guild"] = 1,
                        ["buyer"] = 2461,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632910807,
                        ["quant"] = 1,
                        ["id"] = "1689603741",
                        ["itemLink"] = 3603,
                    },
                    [13] = 
                    {
                        ["price"] = 3900,
                        ["guild"] = 1,
                        ["buyer"] = 2461,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632910809,
                        ["quant"] = 1,
                        ["id"] = "1689603749",
                        ["itemLink"] = 3604,
                    },
                    [14] = 
                    {
                        ["price"] = 14500,
                        ["guild"] = 1,
                        ["buyer"] = 2466,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632912297,
                        ["quant"] = 1,
                        ["id"] = "1689609649",
                        ["itemLink"] = 3616,
                    },
                },
                ["totalCount"] = 14,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [172161] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_shoulders_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Arm Cops",
                ["oldestTime"] = 1633137088,
                ["wasAltered"] = true,
                ["newestTime"] = 1633137088,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 716,
                        ["wasKiosk"] = true,
                        ["seller"] = 281,
                        ["timestamp"] = 1633137088,
                        ["quant"] = 1,
                        ["id"] = "1691263227",
                        ["itemLink"] = 1578,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set deadlands assassin shoulders divines",
            },
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_shoulders_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Arm Cops",
                ["oldestTime"] = 1633249283,
                ["wasAltered"] = true,
                ["newestTime"] = 1633249283,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1809,
                        ["wasKiosk"] = true,
                        ["seller"] = 1417,
                        ["timestamp"] = 1633249283,
                        ["quant"] = 1,
                        ["id"] = "1692265087",
                        ["itemLink"] = 2588,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set deadlands assassin shoulders divines",
            },
        },
        [176770] = 
        {
            ["1:0:4:48:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_pants_medium.dds",
                ["itemDesc"] = "Companion's Guards",
                ["oldestTime"] = 1633002087,
                ["wasAltered"] = true,
                ["newestTime"] = 1633002087,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 80000,
                        ["guild"] = 1,
                        ["buyer"] = 409,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633002087,
                        ["quant"] = 1,
                        ["id"] = "1690244057",
                        ["itemLink"] = 416,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic medium apparel legs soothing",
            },
        },
        [176456] = 
        {
            ["1:0:3:55:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_necklace.dds",
                ["itemDesc"] = "Companion's Necklace",
                ["oldestTime"] = 1632966531,
                ["wasAltered"] = true,
                ["newestTime"] = 1632966531,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 2661,
                        ["wasKiosk"] = true,
                        ["seller"] = 981,
                        ["timestamp"] = 1632966531,
                        ["quant"] = 1,
                        ["id"] = "1690019909",
                        ["itemLink"] = 3969,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior jewelry apparel neck shattering",
            },
        },
        [77419] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_darkbrotherhoodv2_shield_a.dds",
                ["itemDesc"] = "Sithis' Shield",
                ["oldestTime"] = 1633291942,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291942,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 107,
                        ["timestamp"] = 1633291942,
                        ["quant"] = 1,
                        ["id"] = "1692651187",
                        ["itemLink"] = 2798,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior apparel weapon set sithis' touch shield off hand invigorating",
            },
        },
        [71558] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 22: Trinimac Helmets",
                ["oldestTime"] = 1633199481,
                ["wasAltered"] = true,
                ["newestTime"] = 1633199481,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 1477,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633199481,
                        ["quant"] = 1,
                        ["id"] = "1691783875",
                        ["itemLink"] = 2179,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [139655] = 
        {
            ["1:0:4:28:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Exemplary Swift Ring",
                ["oldestTime"] = 1632879193,
                ["wasAltered"] = true,
                ["newestTime"] = 1633215041,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 433,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633007951,
                        ["quant"] = 1,
                        ["id"] = "1690276573",
                        ["itemLink"] = 439,
                    },
                    [2] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1173,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633139292,
                        ["quant"] = 1,
                        ["id"] = "1691284281",
                        ["itemLink"] = 439,
                    },
                    [3] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 1583,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1633215041,
                        ["quant"] = 1,
                        ["id"] = "1691958947",
                        ["itemLink"] = 439,
                    },
                    [4] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2346,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1632879193,
                        ["quant"] = 1,
                        ["id"] = "1689387067",
                        ["itemLink"] = 439,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 purple epic jewelry apparel ring swift",
            },
        },
        [177032] = 
        {
            ["1:0:3:59:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_necklace.dds",
                ["itemDesc"] = "Companion's Necklace",
                ["oldestTime"] = 1633292858,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292858,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1994,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633292858,
                        ["quant"] = 1,
                        ["id"] = "1692661665",
                        ["itemLink"] = 2849,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior jewelry apparel neck bolstered",
            },
        },
        [73865] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 31: Skinchanger Shields",
                ["oldestTime"] = 1632927143,
                ["wasAltered"] = true,
                ["newestTime"] = 1632927143,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4063,
                        ["guild"] = 1,
                        ["buyer"] = 2505,
                        ["wasKiosk"] = true,
                        ["seller"] = 547,
                        ["timestamp"] = 1632927143,
                        ["quant"] = 1,
                        ["id"] = "1689701581",
                        ["itemLink"] = 3690,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [139658] = 
        {
            ["1:0:4:30:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Exemplary Triune Necklace",
                ["oldestTime"] = 1632985171,
                ["wasAltered"] = true,
                ["newestTime"] = 1632985171,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 314,
                        ["wasKiosk"] = true,
                        ["seller"] = 315,
                        ["timestamp"] = 1632985171,
                        ["quant"] = 1,
                        ["id"] = "1690160929",
                        ["itemLink"] = 319,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic jewelry apparel neck triune",
            },
        },
        [172171] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_staff_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Inferno Staff",
                ["oldestTime"] = 1633233921,
                ["wasAltered"] = true,
                ["newestTime"] = 1633233921,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1823,
                        ["guild"] = 1,
                        ["buyer"] = 1370,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1633233921,
                        ["quant"] = 1,
                        ["id"] = "1692153447",
                        ["itemLink"] = 2459,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set deadlands assassin flame staff two-handed precise",
            },
        },
        [172172] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_staff_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Ice Staff",
                ["oldestTime"] = 1633136825,
                ["wasAltered"] = true,
                ["newestTime"] = 1633233895,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2100,
                        ["guild"] = 1,
                        ["buyer"] = 1158,
                        ["wasKiosk"] = true,
                        ["seller"] = 281,
                        ["timestamp"] = 1633136825,
                        ["quant"] = 1,
                        ["id"] = "1691260761",
                        ["itemLink"] = 1573,
                    },
                    [2] = 
                    {
                        ["price"] = 1240,
                        ["guild"] = 1,
                        ["buyer"] = 1370,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633233895,
                        ["quant"] = 1,
                        ["id"] = "1692153289",
                        ["itemLink"] = 1573,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior weapon set deadlands assassin frost staff two-handed precise",
            },
        },
        [176996] = 
        {
            ["1:0:2:59:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_necklace.dds",
                ["itemDesc"] = "Companion's Necklace",
                ["oldestTime"] = 1632956144,
                ["wasAltered"] = true,
                ["newestTime"] = 1632956144,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6702,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 1161,
                        ["timestamp"] = 1632956144,
                        ["quant"] = 1,
                        ["id"] = "1689928903",
                        ["itemLink"] = 3869,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine jewelry apparel neck bolstered",
            },
        },
        [171742] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Imperial Champion Dagger",
                ["oldestTime"] = 1632953410,
                ["wasAltered"] = true,
                ["newestTime"] = 1632953410,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 255,
                        ["guild"] = 1,
                        ["buyer"] = 2603,
                        ["wasKiosk"] = true,
                        ["seller"] = 329,
                        ["timestamp"] = 1632953410,
                        ["quant"] = 1,
                        ["id"] = "1689904839",
                        ["itemLink"] = 3855,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [139663] = 
        {
            ["1:0:4:31:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Exemplary Bloodthirsty Necklace",
                ["oldestTime"] = 1632964372,
                ["wasAltered"] = true,
                ["newestTime"] = 1633295737,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 629,
                        ["wasKiosk"] = true,
                        ["seller"] = 514,
                        ["timestamp"] = 1633040802,
                        ["quant"] = 1,
                        ["id"] = "1690519485",
                        ["itemLink"] = 800,
                    },
                    [2] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1647,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633225818,
                        ["quant"] = 1,
                        ["id"] = "1692072439",
                        ["itemLink"] = 800,
                    },
                    [3] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1693,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633231001,
                        ["quant"] = 1,
                        ["id"] = "1692124277",
                        ["itemLink"] = 800,
                    },
                    [4] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1976,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1633289557,
                        ["quant"] = 1,
                        ["id"] = "1692622489",
                        ["itemLink"] = 800,
                    },
                    [5] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 1685,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633295737,
                        ["quant"] = 1,
                        ["id"] = "1692697821",
                        ["itemLink"] = 800,
                    },
                    [6] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 2653,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632964372,
                        ["quant"] = 1,
                        ["id"] = "1689999105",
                        ["itemLink"] = 800,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 purple epic jewelry apparel neck bloodthirsty",
            },
        },
        [118928] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: High Elf Desk, Regal Winged",
                ["oldestTime"] = 1633235955,
                ["wasAltered"] = true,
                ["newestTime"] = 1633235955,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1733,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633235955,
                        ["quant"] = 1,
                        ["id"] = "1692167697",
                        ["itemLink"] = 2489,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [170129] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Style Page: Thurvokun Shoulder",
                ["oldestTime"] = 1632488512,
                ["wasAltered"] = true,
                ["newestTime"] = 1633277455,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 92000,
                        ["guild"] = 2,
                        ["buyer"] = 111,
                        ["wasKiosk"] = false,
                        ["seller"] = 113,
                        ["timestamp"] = 1632488512,
                        ["quant"] = 1,
                        ["id"] = "1686092845",
                        ["itemLink"] = 85,
                    },
                    [2] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 1911,
                        ["wasKiosk"] = true,
                        ["seller"] = 417,
                        ["timestamp"] = 1633277455,
                        ["quant"] = 1,
                        ["id"] = "1692490241",
                        ["itemLink"] = 85,
                    },
                    [3] = 
                    {
                        ["price"] = 150000,
                        ["guild"] = 1,
                        ["buyer"] = 2286,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1632870019,
                        ["quant"] = 1,
                        ["id"] = "1689303233",
                        ["itemLink"] = 85,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [130027] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 79: Refabricated Axes",
                ["oldestTime"] = 1632950241,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950241,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14200,
                        ["guild"] = 1,
                        ["buyer"] = 2586,
                        ["wasKiosk"] = true,
                        ["seller"] = 1498,
                        ["timestamp"] = 1632950241,
                        ["quant"] = 1,
                        ["id"] = "1689876137",
                        ["itemLink"] = 3835,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [172947] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_medium_chest_d.dds",
                ["itemDesc"] = "Heartland Conqueror's Jack",
                ["oldestTime"] = 1633157721,
                ["wasAltered"] = true,
                ["newestTime"] = 1633157721,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9997,
                        ["guild"] = 1,
                        ["buyer"] = 1292,
                        ["wasKiosk"] = true,
                        ["seller"] = 220,
                        ["timestamp"] = 1633157721,
                        ["quant"] = 1,
                        ["id"] = "1691452803",
                        ["itemLink"] = 1771,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set heartland conqueror chest divines",
            },
        },
        [119444] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning3.dds",
                ["itemDesc"] = "Design: Candle, Group",
                ["oldestTime"] = 1632865553,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865553,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 2194,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632865553,
                        ["quant"] = 1,
                        ["id"] = "1689269019",
                        ["itemLink"] = 3353,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [172181] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_shoulders_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Arm Cops",
                ["oldestTime"] = 1633277148,
                ["wasAltered"] = true,
                ["newestTime"] = 1633277148,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1907,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633277148,
                        ["quant"] = 1,
                        ["id"] = "1692487723",
                        ["itemLink"] = 2706,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set deadlands assassin shoulders well-fitted",
            },
        },
        [82020] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 41: Celestial Swords",
                ["oldestTime"] = 1632942087,
                ["wasAltered"] = true,
                ["newestTime"] = 1632942087,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11111,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 159,
                        ["timestamp"] = 1632942087,
                        ["quant"] = 1,
                        ["id"] = "1689810483",
                        ["itemLink"] = 3776,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [71063] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Orzorga's Smoked Bear Haunch",
                ["oldestTime"] = 1633100228,
                ["wasAltered"] = true,
                ["newestTime"] = 1633100228,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 85000,
                        ["guild"] = 1,
                        ["buyer"] = 942,
                        ["wasKiosk"] = true,
                        ["seller"] = 493,
                        ["timestamp"] = 1633100228,
                        ["quant"] = 1,
                        ["id"] = "1690959085",
                        ["itemLink"] = 1279,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable recipe",
            },
        },
        [172442] = 
        {
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_hvy_feet_a.dds",
                ["itemDesc"] = "Bog Raider's Sabatons",
                ["oldestTime"] = 1632940825,
                ["wasAltered"] = true,
                ["newestTime"] = 1632940825,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1001,
                        ["wasKiosk"] = true,
                        ["seller"] = 530,
                        ["timestamp"] = 1632940825,
                        ["quant"] = 1,
                        ["id"] = "1689800233",
                        ["itemLink"] = 3770,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set bog raider feet training",
            },
        },
        [45209] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_light_hands_d.dds",
                ["itemDesc"] = "Ancestor Silk Gloves of Magicka",
                ["oldestTime"] = 1632847691,
                ["wasAltered"] = true,
                ["newestTime"] = 1632976103,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 221,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1632976103,
                        ["quant"] = 1,
                        ["id"] = "1690103457",
                        ["itemLink"] = 238,
                    },
                    [2] = 
                    {
                        ["price"] = 177,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632847691,
                        ["quant"] = 1,
                        ["id"] = "1689125551",
                        ["itemLink"] = 3215,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine light apparel hands infused",
            },
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_light_hands_d.dds",
                ["itemDesc"] = "Ancestor Silk Gloves of Health",
                ["oldestTime"] = 1632857768,
                ["wasAltered"] = true,
                ["newestTime"] = 1632857768,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1632857768,
                        ["quant"] = 1,
                        ["id"] = "1689212107",
                        ["itemLink"] = 3286,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel hands infused",
            },
        },
        [161434] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_shoulders_d.dds",
                ["itemDesc"] = "Stuhn's Pauldrons",
                ["oldestTime"] = 1632866120,
                ["wasAltered"] = true,
                ["newestTime"] = 1632930937,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 2269,
                        ["wasKiosk"] = true,
                        ["seller"] = 819,
                        ["timestamp"] = 1632866120,
                        ["quant"] = 1,
                        ["id"] = "1689274159",
                        ["itemLink"] = 3360,
                    },
                    [2] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 2517,
                        ["wasKiosk"] = true,
                        ["seller"] = 819,
                        ["timestamp"] = 1632930937,
                        ["quant"] = 1,
                        ["id"] = "1689728871",
                        ["itemLink"] = 3360,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set stuhn's favor shoulders impenetrable",
            },
        },
        [99905] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_2hsword_c.dds",
                ["itemDesc"] = "Thunderbug's Greatsword",
                ["oldestTime"] = 1632936862,
                ["wasAltered"] = true,
                ["newestTime"] = 1632936862,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14999,
                        ["guild"] = 1,
                        ["buyer"] = 2530,
                        ["wasKiosk"] = true,
                        ["seller"] = 305,
                        ["timestamp"] = 1632936862,
                        ["quant"] = 1,
                        ["id"] = "1689774131",
                        ["itemLink"] = 3750,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set thunderbug's carapace sword two-handed defending",
            },
        },
        [156828] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Style Page: Opal Troll King Battle Axe",
                ["oldestTime"] = 1633167249,
                ["wasAltered"] = true,
                ["newestTime"] = 1633167249,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300000,
                        ["guild"] = 1,
                        ["buyer"] = 1320,
                        ["wasKiosk"] = true,
                        ["seller"] = 1328,
                        ["timestamp"] = 1633167249,
                        ["quant"] = 1,
                        ["id"] = "1691505715",
                        ["itemLink"] = 1868,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [180901] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_heavy_feet_a.dds",
                ["itemDesc"] = "Hrothgar's Sabatons",
                ["oldestTime"] = 1632935104,
                ["wasAltered"] = true,
                ["newestTime"] = 1632935104,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 626,
                        ["wasKiosk"] = false,
                        ["seller"] = 761,
                        ["timestamp"] = 1632935104,
                        ["quant"] = 1,
                        ["id"] = "1689761431",
                        ["itemLink"] = 3728,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set hrothgar's chill feet sturdy",
            },
        },
        [57060] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Necrom Nights Mazte",
                ["oldestTime"] = 1632923729,
                ["wasAltered"] = true,
                ["newestTime"] = 1632923729,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632923729,
                        ["quant"] = 1,
                        ["id"] = "1689677447",
                        ["itemLink"] = 3675,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [172191] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_staff_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Inferno Staff",
                ["oldestTime"] = 1633200491,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261549,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1479,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1633200491,
                        ["quant"] = 1,
                        ["id"] = "1691794777",
                        ["itemLink"] = 2187,
                    },
                    [2] = 
                    {
                        ["price"] = 2770,
                        ["guild"] = 1,
                        ["buyer"] = 1840,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1633261549,
                        ["quant"] = 1,
                        ["id"] = "1692334213",
                        ["itemLink"] = 2187,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior weapon set deadlands assassin flame staff two-handed defending",
            },
        },
        [172192] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_staff_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Ice Staff",
                ["oldestTime"] = 1633240467,
                ["wasAltered"] = true,
                ["newestTime"] = 1633240467,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 720,
                        ["guild"] = 1,
                        ["buyer"] = 1772,
                        ["wasKiosk"] = true,
                        ["seller"] = 1112,
                        ["timestamp"] = 1633240467,
                        ["quant"] = 1,
                        ["id"] = "1692201367",
                        ["itemLink"] = 2534,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set deadlands assassin frost staff two-handed defending",
            },
        },
        [140449] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 63: Dremora Chests",
                ["oldestTime"] = 1632887154,
                ["wasAltered"] = true,
                ["newestTime"] = 1633272317,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 49900,
                        ["guild"] = 1,
                        ["buyer"] = 1886,
                        ["wasKiosk"] = true,
                        ["seller"] = 611,
                        ["timestamp"] = 1633272317,
                        ["quant"] = 1,
                        ["id"] = "1692429811",
                        ["itemLink"] = 2679,
                    },
                    [2] = 
                    {
                        ["price"] = 48800,
                        ["guild"] = 1,
                        ["buyer"] = 2393,
                        ["wasKiosk"] = true,
                        ["seller"] = 611,
                        ["timestamp"] = 1632887154,
                        ["quant"] = 1,
                        ["id"] = "1689471939",
                        ["itemLink"] = 2679,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [137922] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 62: Sapiarch Belts",
                ["oldestTime"] = 1632919887,
                ["wasAltered"] = true,
                ["newestTime"] = 1632919887,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8539,
                        ["guild"] = 1,
                        ["buyer"] = 862,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1632919887,
                        ["quant"] = 1,
                        ["id"] = "1689650895",
                        ["itemLink"] = 3648,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [56980] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Potato-Stuffed Roast Pheasant",
                ["oldestTime"] = 1632913061,
                ["wasAltered"] = true,
                ["newestTime"] = 1632913061,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 2471,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1632913061,
                        ["quant"] = 1,
                        ["id"] = "1689612479",
                        ["itemLink"] = 3626,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [134766] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 58: Fang Lair Shields",
                ["oldestTime"] = 1633310884,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310884,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 2091,
                        ["wasKiosk"] = true,
                        ["seller"] = 261,
                        ["timestamp"] = 1633310884,
                        ["quant"] = 1,
                        ["id"] = "1692858691",
                        ["itemLink"] = 2999,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [82085] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 39: Minotaur Swords",
                ["oldestTime"] = 1632891913,
                ["wasAltered"] = true,
                ["newestTime"] = 1632891913,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 55771,
                        ["guild"] = 1,
                        ["buyer"] = 2417,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1632891913,
                        ["quant"] = 1,
                        ["id"] = "1689507629",
                        ["itemLink"] = 3545,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [71564] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 22: Trinimac Swords",
                ["oldestTime"] = 1633121399,
                ["wasAltered"] = true,
                ["newestTime"] = 1633133950,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 511,
                        ["wasKiosk"] = true,
                        ["seller"] = 981,
                        ["timestamp"] = 1633121399,
                        ["quant"] = 1,
                        ["id"] = "1691114805",
                        ["itemLink"] = 1437,
                    },
                    [2] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1127,
                        ["wasKiosk"] = true,
                        ["seller"] = 911,
                        ["timestamp"] = 1633133950,
                        ["quant"] = 1,
                        ["id"] = "1691230433",
                        ["itemLink"] = 1437,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [134497] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing3.dds",
                ["itemDesc"] = "Diagram: Clockwork Vent, Octagonal Fan",
                ["oldestTime"] = 1632891517,
                ["wasAltered"] = true,
                ["newestTime"] = 1632891517,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 2413,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632891517,
                        ["quant"] = 1,
                        ["id"] = "1689503697",
                        ["itemLink"] = 3540,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [137925] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 62: Sapiarch Chests",
                ["oldestTime"] = 1632885244,
                ["wasAltered"] = true,
                ["newestTime"] = 1632885244,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20680,
                        ["guild"] = 1,
                        ["buyer"] = 2387,
                        ["wasKiosk"] = true,
                        ["seller"] = 2186,
                        ["timestamp"] = 1632885244,
                        ["quant"] = 1,
                        ["id"] = "1689455711",
                        ["itemLink"] = 3502,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [117828] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_str_varinthicounterstraight002.dds",
                ["itemDesc"] = "Redguard Counter, Grill",
                ["oldestTime"] = 1632895737,
                ["wasAltered"] = true,
                ["newestTime"] = 1633062640,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 799,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633062640,
                        ["quant"] = 1,
                        ["id"] = "1690730119",
                        ["itemLink"] = 1036,
                    },
                    [2] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 2432,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632895737,
                        ["quant"] = 1,
                        ["id"] = "1689533647",
                        ["itemLink"] = 1036,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [33194] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_gems_daedra_skull.dds",
                ["itemDesc"] = "Bone",
                ["oldestTime"] = 1632818393,
                ["wasAltered"] = true,
                ["newestTime"] = 1633243135,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3420,
                        ["guild"] = 1,
                        ["buyer"] = 845,
                        ["wasKiosk"] = false,
                        ["seller"] = 199,
                        ["timestamp"] = 1633243135,
                        ["quant"] = 171,
                        ["id"] = "1692219967",
                        ["itemLink"] = 2558,
                    },
                    [2] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 204,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1632818393,
                        ["quant"] = 200,
                        ["id"] = "1688937311",
                        ["itemLink"] = 2558,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [142763] = 
        {
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_elderarg_light_feet_a.dds",
                ["itemDesc"] = "Bright-Throat's Boast Shoes",
                ["oldestTime"] = 1633191131,
                ["wasAltered"] = true,
                ["newestTime"] = 1633191131,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1420,
                        ["wasKiosk"] = true,
                        ["seller"] = 237,
                        ["timestamp"] = 1633191131,
                        ["quant"] = 1,
                        ["id"] = "1691701807",
                        ["itemLink"] = 2109,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set bright-throat's boast feet training",
            },
        },
        [156639] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 80: Shield of Senchal Shoulders",
                ["oldestTime"] = 1632896874,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227257,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1659,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1633227257,
                        ["quant"] = 1,
                        ["id"] = "1692087737",
                        ["itemLink"] = 2404,
                    },
                    [2] = 
                    {
                        ["price"] = 18900,
                        ["guild"] = 1,
                        ["buyer"] = 2436,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632896874,
                        ["quant"] = 1,
                        ["id"] = "1689541561",
                        ["itemLink"] = 2404,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [176557] = 
        {
            ["1:0:2:47:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_helm_heavy.dds",
                ["itemDesc"] = "Companion's Helm",
                ["oldestTime"] = 1633150102,
                ["wasAltered"] = true,
                ["newestTime"] = 1633150102,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1258,
                        ["wasKiosk"] = true,
                        ["seller"] = 1108,
                        ["timestamp"] = 1633150102,
                        ["quant"] = 1,
                        ["id"] = "1691392079",
                        ["itemLink"] = 1720,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine heavy apparel head aggressive",
            },
        },
        [100673] = 
        {
            ["50:16:5:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_2hhammer_d.dds",
                ["itemDesc"] = "Spriggan's Maul",
                ["oldestTime"] = 1632872111,
                ["wasAltered"] = true,
                ["newestTime"] = 1632951290,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 899999,
                        ["guild"] = 1,
                        ["buyer"] = 2297,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1632872111,
                        ["quant"] = 1,
                        ["id"] = "1689316281",
                        ["itemLink"] = 3391,
                    },
                    [2] = 
                    {
                        ["price"] = 969420,
                        ["guild"] = 1,
                        ["buyer"] = 2415,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1632951290,
                        ["quant"] = 1,
                        ["id"] = "1689884585",
                        ["itemLink"] = 3391,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 gold legendary weapon set spriggan's thorns mace two-handed sharpened",
            },
        },
        [172029] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_head_a.dds",
                ["itemDesc"] = "Hat of Frostbite",
                ["oldestTime"] = 1633182278,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182278,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1377,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633182278,
                        ["quant"] = 1,
                        ["id"] = "1691606357",
                        ["itemLink"] = 1934,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set frostbite head reinforced",
            },
            ["50:16:2:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_head_a.dds",
                ["itemDesc"] = "Hat of Frostbite",
                ["oldestTime"] = 1633136884,
                ["wasAltered"] = true,
                ["newestTime"] = 1633136884,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1159,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633136884,
                        ["quant"] = 1,
                        ["id"] = "1691261353",
                        ["itemLink"] = 1574,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite head reinforced",
            },
        },
        [176010] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning3.dds",
                ["itemDesc"] = "Design: Leyawiin Bowl, Lobster Stew",
                ["oldestTime"] = 1632857134,
                ["wasAltered"] = true,
                ["newestTime"] = 1632857134,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 32850,
                        ["guild"] = 1,
                        ["buyer"] = 2240,
                        ["wasKiosk"] = true,
                        ["seller"] = 505,
                        ["timestamp"] = 1632857134,
                        ["quant"] = 1,
                        ["id"] = "1689207069",
                        ["itemLink"] = 3279,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [123825] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_light_shirt_a.dds",
                ["itemDesc"] = "Wizard's Riposte Jerkin",
                ["oldestTime"] = 1633215042,
                ["wasAltered"] = true,
                ["newestTime"] = 1633215042,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1582,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633215042,
                        ["quant"] = 1,
                        ["id"] = "1691958951",
                        ["itemLink"] = 2309,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set wizard's riposte chest impenetrable",
            },
        },
        [117786] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_fur_varbookcasecombined004.dds",
                ["itemDesc"] = "Redguard Bookcase, Full",
                ["oldestTime"] = 1632855812,
                ["wasAltered"] = true,
                ["newestTime"] = 1632855812,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 789,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632855812,
                        ["quant"] = 1,
                        ["id"] = "1689197131",
                        ["itemLink"] = 3266,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings library",
            },
        },
        [56035] = 
        {
            ["1:0:1:26:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_staff_a.dds",
                ["itemDesc"] = "Maple Ice Staff",
                ["oldestTime"] = 1632959229,
                ["wasAltered"] = true,
                ["newestTime"] = 1633304495,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 2061,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633304495,
                        ["quant"] = 1,
                        ["id"] = "1692785305",
                        ["itemLink"] = 2926,
                    },
                    [2] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 2624,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1632959229,
                        ["quant"] = 1,
                        ["id"] = "1689954209",
                        ["itemLink"] = 3917,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal weapon frost staff two-handed nirnhoned",
            },
        },
        [176629] = 
        {
            ["1:0:4:47:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_helm_heavy.dds",
                ["itemDesc"] = "Companion's Helm",
                ["oldestTime"] = 1633136913,
                ["wasAltered"] = true,
                ["newestTime"] = 1633136913,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 894,
                        ["timestamp"] = 1633136913,
                        ["quant"] = 1,
                        ["id"] = "1691261671",
                        ["itemLink"] = 1576,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic heavy apparel head aggressive",
            },
        },
        [180881] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_heavy_feet_a.dds",
                ["itemDesc"] = "Hrothgar's Sabatons",
                ["oldestTime"] = 1632836262,
                ["wasAltered"] = true,
                ["newestTime"] = 1632836262,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2160,
                        ["wasKiosk"] = true,
                        ["seller"] = 761,
                        ["timestamp"] = 1632836262,
                        ["quant"] = 1,
                        ["id"] = "1689036021",
                        ["itemLink"] = 3109,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set hrothgar's chill feet invigorating",
            },
        },
        [93357] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Morag Tong",
                ["oldestTime"] = 1632831761,
                ["wasAltered"] = true,
                ["newestTime"] = 1632831761,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 2139,
                        ["wasKiosk"] = true,
                        ["seller"] = 569,
                        ["timestamp"] = 1632831761,
                        ["quant"] = 1,
                        ["id"] = "1689009717",
                        ["itemLink"] = 3088,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set the morag tong ring robust",
            },
        },
        [75191] = 
        {
            ["50:16:4:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_staff_a.dds",
                ["itemDesc"] = "Inferno Staff of the Night Mother",
                ["oldestTime"] = 1633111631,
                ["wasAltered"] = true,
                ["newestTime"] = 1633111631,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 330,
                        ["wasKiosk"] = false,
                        ["seller"] = 987,
                        ["timestamp"] = 1633111631,
                        ["quant"] = 1,
                        ["id"] = "1691049049",
                        ["itemLink"] = 1328,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set night mother's embrace flame staff two-handed defending",
            },
        },
        [176312] = 
        {
            ["1:0:3:54:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_necklace.dds",
                ["itemDesc"] = "Companion's Necklace",
                ["oldestTime"] = 1633064738,
                ["wasAltered"] = true,
                ["newestTime"] = 1633064738,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8700,
                        ["guild"] = 1,
                        ["buyer"] = 812,
                        ["wasKiosk"] = true,
                        ["seller"] = 816,
                        ["timestamp"] = 1633064738,
                        ["quant"] = 1,
                        ["id"] = "1690746051",
                        ["itemLink"] = 1056,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior jewelry apparel neck focused",
            },
        },
        [121529] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_blacksmithing.dds",
                ["itemDesc"] = "Sealed Blacksmithing Writ",
                ["oldestTime"] = 1632910591,
                ["wasAltered"] = true,
                ["newestTime"] = 1633111849,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 543,
                        ["wasKiosk"] = true,
                        ["seller"] = 155,
                        ["timestamp"] = 1633026498,
                        ["quant"] = 1,
                        ["id"] = "1690417859",
                        ["itemLink"] = 680,
                    },
                    [2] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633111849,
                        ["quant"] = 1,
                        ["id"] = "1691050747",
                        ["itemLink"] = 1332,
                    },
                    [3] = 
                    {
                        ["price"] = 38284,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1632910591,
                        ["quant"] = 1,
                        ["id"] = "1689602927",
                        ["itemLink"] = 3600,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 gold legendary consumable master writ",
            },
        },
        [180545] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_staff_a.dds",
                ["itemDesc"] = "Restoration Staff of Dark Convergence",
                ["oldestTime"] = 1632830332,
                ["wasAltered"] = true,
                ["newestTime"] = 1632830332,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2134,
                        ["wasKiosk"] = true,
                        ["seller"] = 761,
                        ["timestamp"] = 1632830332,
                        ["quant"] = 1,
                        ["id"] = "1689000455",
                        ["itemLink"] = 3079,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set dark convergence healing staff two-handed charged",
            },
        },
        [28603] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_veg_005.dds",
                ["itemDesc"] = "Tomato",
                ["oldestTime"] = 1633305831,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305831,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1633305831,
                        ["quant"] = 100,
                        ["id"] = "1692798721",
                        ["itemLink"] = 2937,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [28604] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_cabbage.dds",
                ["itemDesc"] = "Greens",
                ["oldestTime"] = 1633042314,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305856,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2600,
                        ["guild"] = 1,
                        ["buyer"] = 648,
                        ["wasKiosk"] = true,
                        ["seller"] = 649,
                        ["timestamp"] = 1633042314,
                        ["quant"] = 200,
                        ["id"] = "1690531141",
                        ["itemLink"] = 824,
                    },
                    [2] = 
                    {
                        ["price"] = 6211,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633305856,
                        ["quant"] = 200,
                        ["id"] = "1692799015",
                        ["itemLink"] = 824,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [172221] = 
        {
            ["50:16:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_shoulders_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Arm Cops",
                ["oldestTime"] = 1633126036,
                ["wasAltered"] = true,
                ["newestTime"] = 1633161784,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1085,
                        ["wasKiosk"] = true,
                        ["seller"] = 281,
                        ["timestamp"] = 1633126036,
                        ["quant"] = 1,
                        ["id"] = "1691149775",
                        ["itemLink"] = 1485,
                    },
                    [2] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1311,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1633161784,
                        ["quant"] = 1,
                        ["id"] = "1691475181",
                        ["itemLink"] = 1485,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine medium apparel set deadlands assassin shoulders impenetrable",
            },
        },
        [171966] = 
        {
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_head_a.dds",
                ["itemDesc"] = "Hat of Frostbite",
                ["oldestTime"] = 1633215987,
                ["wasAltered"] = true,
                ["newestTime"] = 1633215987,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 415,
                        ["guild"] = 1,
                        ["buyer"] = 327,
                        ["wasKiosk"] = false,
                        ["seller"] = 502,
                        ["timestamp"] = 1633215987,
                        ["quant"] = 1,
                        ["id"] = "1691968271",
                        ["itemLink"] = 2311,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set frostbite head infused",
            },
        },
        [125887] = 
        {
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_heavy_legs_a.dds",
                ["itemDesc"] = "Impregnable Armor Greaves",
                ["oldestTime"] = 1632908921,
                ["wasAltered"] = true,
                ["newestTime"] = 1632908921,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2459,
                        ["wasKiosk"] = true,
                        ["seller"] = 529,
                        ["timestamp"] = 1632908921,
                        ["quant"] = 1,
                        ["id"] = "1689598611",
                        ["itemLink"] = 3597,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set impregnable armor legs invigorating",
            },
        },
        [64704] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/notes_004.dds",
                ["itemDesc"] = "Recipe: Psijic Ambrosia, Fragment II",
                ["oldestTime"] = 1632850228,
                ["wasAltered"] = true,
                ["newestTime"] = 1632850228,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 7,
                        ["wasKiosk"] = false,
                        ["seller"] = 108,
                        ["timestamp"] = 1632850228,
                        ["quant"] = 1,
                        ["id"] = "1689146291",
                        ["itemLink"] = 3230,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [99099] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_heavy_chest_d.dds",
                ["itemDesc"] = "Cuirass of the Hatchling's Shell",
                ["oldestTime"] = 1633295456,
                ["wasAltered"] = true,
                ["newestTime"] = 1633295456,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2018,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1633295456,
                        ["quant"] = 1,
                        ["id"] = "1692695017",
                        ["itemLink"] = 2881,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set hatchling's shell chest divines",
            },
        },
        [156610] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 81: New Moon Priest Belts",
                ["oldestTime"] = 1632879069,
                ["wasAltered"] = true,
                ["newestTime"] = 1633050168,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 698,
                        ["wasKiosk"] = true,
                        ["seller"] = 374,
                        ["timestamp"] = 1633050168,
                        ["quant"] = 1,
                        ["id"] = "1690606977",
                        ["itemLink"] = 886,
                    },
                    [2] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1208,
                        ["wasKiosk"] = true,
                        ["seller"] = 374,
                        ["timestamp"] = 1632879069,
                        ["quant"] = 1,
                        ["id"] = "1689385067",
                        ["itemLink"] = 886,
                    },
                    [3] = 
                    {
                        ["price"] = 1550,
                        ["guild"] = 1,
                        ["buyer"] = 359,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1632928604,
                        ["quant"] = 1,
                        ["id"] = "1689710949",
                        ["itemLink"] = 886,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [160707] = 
        {
            ["50:16:4:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_blackreachexlgt_hands.dds",
                ["itemDesc"] = "Gloves of Winter's Respite",
                ["oldestTime"] = 1632865203,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865203,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 2259,
                        ["wasKiosk"] = true,
                        ["seller"] = 281,
                        ["timestamp"] = 1632865203,
                        ["quant"] = 1,
                        ["id"] = "1689266063",
                        ["itemLink"] = 3327,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set winter's respite hands reinforced",
            },
        },
        [171920] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 102: Sul-Xan Helmets",
                ["oldestTime"] = 1633292567,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292567,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 114999,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633292567,
                        ["quant"] = 1,
                        ["id"] = "1692658329",
                        ["itemLink"] = 2842,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [156613] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 81: New Moon Priest Chests",
                ["oldestTime"] = 1633008892,
                ["wasAltered"] = true,
                ["newestTime"] = 1633212425,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3995,
                        ["guild"] = 1,
                        ["buyer"] = 430,
                        ["wasKiosk"] = true,
                        ["seller"] = 322,
                        ["timestamp"] = 1633008892,
                        ["quant"] = 1,
                        ["id"] = "1690282153",
                        ["itemLink"] = 449,
                    },
                    [2] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1559,
                        ["wasKiosk"] = true,
                        ["seller"] = 61,
                        ["timestamp"] = 1633212425,
                        ["quant"] = 1,
                        ["id"] = "1691934817",
                        ["itemLink"] = 449,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [116166] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Nord Cart, Cargo",
                ["oldestTime"] = 1633240435,
                ["wasAltered"] = true,
                ["newestTime"] = 1633240435,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 1772,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633240435,
                        ["quant"] = 1,
                        ["id"] = "1692201097",
                        ["itemLink"] = 2529,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [123847] = 
        {
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_light_shoulders_a.dds",
                ["itemDesc"] = "Wizard's Riposte Epaulets",
                ["oldestTime"] = 1633226388,
                ["wasAltered"] = true,
                ["newestTime"] = 1633226388,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 1013,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633226388,
                        ["quant"] = 1,
                        ["id"] = "1692078725",
                        ["itemLink"] = 2399,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set wizard's riposte shoulders invigorating",
            },
        },
        [126925] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Redoran Bed, Canopy",
                ["oldestTime"] = 1633292374,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292374,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 58000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633292374,
                        ["quant"] = 1,
                        ["id"] = "1692655953",
                        ["itemLink"] = 2825,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [100553] = 
        {
            ["50:16:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_staff_d.dds",
                ["itemDesc"] = "Vampire Lord's Inferno Staff",
                ["oldestTime"] = 1633125838,
                ["wasAltered"] = true,
                ["newestTime"] = 1633125838,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 899,
                        ["guild"] = 1,
                        ["buyer"] = 1084,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633125838,
                        ["quant"] = 1,
                        ["id"] = "1691148627",
                        ["itemLink"] = 1482,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set vampire lord flame staff two-handed training",
            },
        },
        [96202] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of the Trainee",
                ["oldestTime"] = 1632957205,
                ["wasAltered"] = true,
                ["newestTime"] = 1632957205,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4477,
                        ["guild"] = 1,
                        ["buyer"] = 2285,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1632957205,
                        ["quant"] = 1,
                        ["id"] = "1689937121",
                        ["itemLink"] = 3904,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set armor of the trainee neck robust",
            },
        },
        [43544] = 
        {
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_light_feet_d.dds",
                ["itemDesc"] = "Ancestor Silk Shoes",
                ["oldestTime"] = 1633268070,
                ["wasAltered"] = true,
                ["newestTime"] = 1633268070,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 90,
                        ["guild"] = 1,
                        ["buyer"] = 1001,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633268070,
                        ["quant"] = 1,
                        ["id"] = "1692385911",
                        ["itemLink"] = 2651,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal light apparel feet",
            },
        },
        [116173] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Nord Bench, Plank",
                ["oldestTime"] = 1633288338,
                ["wasAltered"] = true,
                ["newestTime"] = 1633288338,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1971,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633288338,
                        ["quant"] = 1,
                        ["id"] = "1692608129",
                        ["itemLink"] = 2769,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [114893] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_furniture_base_alchemical_resin.dds",
                ["itemDesc"] = "Alchemical Resin",
                ["oldestTime"] = 1632844499,
                ["wasAltered"] = true,
                ["newestTime"] = 1633316276,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5600,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 9,
                        ["timestamp"] = 1633043908,
                        ["quant"] = 200,
                        ["id"] = "1690545591",
                        ["itemLink"] = 842,
                    },
                    [2] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 48,
                        ["wasKiosk"] = false,
                        ["seller"] = 166,
                        ["timestamp"] = 1633273375,
                        ["quant"] = 200,
                        ["id"] = "1692441941",
                        ["itemLink"] = 842,
                    },
                    [3] = 
                    {
                        ["price"] = 5200,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 327,
                        ["timestamp"] = 1633281851,
                        ["quant"] = 200,
                        ["id"] = "1692535713",
                        ["itemLink"] = 842,
                    },
                    [4] = 
                    {
                        ["price"] = 5200,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 327,
                        ["timestamp"] = 1633281852,
                        ["quant"] = 200,
                        ["id"] = "1692535727",
                        ["itemLink"] = 842,
                    },
                    [5] = 
                    {
                        ["price"] = 19800,
                        ["guild"] = 1,
                        ["buyer"] = 2093,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1633316274,
                        ["quant"] = 200,
                        ["id"] = "1692917947",
                        ["itemLink"] = 842,
                    },
                    [6] = 
                    {
                        ["price"] = 19800,
                        ["guild"] = 1,
                        ["buyer"] = 2093,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1633316276,
                        ["quant"] = 200,
                        ["id"] = "1692917967",
                        ["itemLink"] = 842,
                    },
                    [7] = 
                    {
                        ["price"] = 3995,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 322,
                        ["timestamp"] = 1632844499,
                        ["quant"] = 200,
                        ["id"] = "1689095107",
                        ["itemLink"] = 842,
                    },
                    [8] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 9,
                        ["timestamp"] = 1632844499,
                        ["quant"] = 200,
                        ["id"] = "1689095121",
                        ["itemLink"] = 842,
                    },
                    [9] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 515,
                        ["timestamp"] = 1632938412,
                        ["quant"] = 200,
                        ["id"] = "1689784219",
                        ["itemLink"] = 842,
                    },
                    [10] = 
                    {
                        ["price"] = 4200,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 288,
                        ["timestamp"] = 1632938413,
                        ["quant"] = 200,
                        ["id"] = "1689784225",
                        ["itemLink"] = 842,
                    },
                },
                ["totalCount"] = 10,
                ["itemAdderText"] = "rr01 white normal materials furnishing",
            },
        },
        [172241] = 
        {
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_shoulders_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Arm Cops",
                ["oldestTime"] = 1633278113,
                ["wasAltered"] = true,
                ["newestTime"] = 1633278113,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1470,
                        ["guild"] = 1,
                        ["buyer"] = 1914,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633278113,
                        ["quant"] = 1,
                        ["id"] = "1692496029",
                        ["itemLink"] = 2716,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set deadlands assassin shoulders invigorating",
            },
        },
        [126049] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_staff_c.dds",
                ["itemDesc"] = "Dark Staff of the War Maiden",
                ["oldestTime"] = 1632941495,
                ["wasAltered"] = true,
                ["newestTime"] = 1632941495,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 2550,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1632941495,
                        ["quant"] = 1,
                        ["id"] = "1689805681",
                        ["itemLink"] = 3774,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set war maiden flame staff two-handed infused",
            },
            ["50:16:5:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_staff_c.dds",
                ["itemDesc"] = "Dark Staff of the War Maiden",
                ["oldestTime"] = 1633270370,
                ["wasAltered"] = true,
                ["newestTime"] = 1633270370,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 199913,
                        ["guild"] = 1,
                        ["buyer"] = 1874,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633270370,
                        ["quant"] = 1,
                        ["id"] = "1692408035",
                        ["itemLink"] = 2665,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary weapon set war maiden flame staff two-handed infused",
            },
        },
        [45264] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_1hhammer_d.dds",
                ["itemDesc"] = "Rubedite Mace of Flame",
                ["oldestTime"] = 1633185896,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185896,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633185896,
                        ["quant"] = 1,
                        ["id"] = "1691639481",
                        ["itemLink"] = 1999,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon mace one-handed decisive",
            },
        },
        [130001] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 51: Hlaalu Gloves",
                ["oldestTime"] = 1633143399,
                ["wasAltered"] = true,
                ["newestTime"] = 1633143399,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1213,
                        ["wasKiosk"] = true,
                        ["seller"] = 1214,
                        ["timestamp"] = 1633143399,
                        ["quant"] = 1,
                        ["id"] = "1691330425",
                        ["itemLink"] = 1632,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [120530] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_bsh_malabaltorfernclusterred003.dds",
                ["itemDesc"] = "Fern Fronds, Sunburnt",
                ["oldestTime"] = 1633273342,
                ["wasAltered"] = true,
                ["newestTime"] = 1633273342,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 120,
                        ["guild"] = 1,
                        ["buyer"] = 48,
                        ["wasKiosk"] = false,
                        ["seller"] = 73,
                        ["timestamp"] = 1633273342,
                        ["quant"] = 1,
                        ["id"] = "1692441253",
                        ["itemLink"] = 2684,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal furnishings conservatory",
            },
        },
        [175827] = 
        {
            ["1:0:2:52:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_necklace.dds",
                ["itemDesc"] = "Companion's Necklace",
                ["oldestTime"] = 1633291158,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291158,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1597,
                        ["wasKiosk"] = true,
                        ["seller"] = 155,
                        ["timestamp"] = 1633291158,
                        ["quant"] = 1,
                        ["id"] = "1692640269",
                        ["itemLink"] = 2791,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine jewelry apparel neck quickened",
            },
        },
        [99284] = 
        {
            ["23:0:2:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Sword-Singer's Necklace",
                ["oldestTime"] = 1633088786,
                ["wasAltered"] = true,
                ["newestTime"] = 1633088786,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 775,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633088786,
                        ["quant"] = 1,
                        ["id"] = "1690882193",
                        ["itemLink"] = 1236,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr23 green fine jewelry apparel set sword-singer neck robust",
            },
            ["25:0:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Sword-Singer's Necklace",
                ["oldestTime"] = 1633113813,
                ["wasAltered"] = true,
                ["newestTime"] = 1633113813,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 990,
                        ["guild"] = 1,
                        ["buyer"] = 1003,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633113813,
                        ["quant"] = 1,
                        ["id"] = "1691064299",
                        ["itemLink"] = 1367,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr25 blue superior jewelry apparel set sword-singer neck robust",
            },
            ["22:0:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Sword-Singer's Necklace",
                ["oldestTime"] = 1632929483,
                ["wasAltered"] = true,
                ["newestTime"] = 1632929483,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 875,
                        ["guild"] = 1,
                        ["buyer"] = 966,
                        ["wasKiosk"] = false,
                        ["seller"] = 739,
                        ["timestamp"] = 1632929483,
                        ["quant"] = 1,
                        ["id"] = "1689718099",
                        ["itemLink"] = 3697,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr22 blue superior jewelry apparel set sword-singer neck robust",
            },
        },
        [159448] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bre_cem_housingsculpture001.dds",
                ["itemDesc"] = "Breton Statue, Arkay",
                ["oldestTime"] = 1633244716,
                ["wasAltered"] = true,
                ["newestTime"] = 1633244718,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 1793,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633244716,
                        ["quant"] = 1,
                        ["id"] = "1692231685",
                        ["itemLink"] = 2577,
                    },
                    [2] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 1793,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633244718,
                        ["quant"] = 1,
                        ["id"] = "1692231715",
                        ["itemLink"] = 2577,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings courtyard",
            },
        },
        [177025] = 
        {
            ["1:0:3:50:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_helm_heavy.dds",
                ["itemDesc"] = "Companion's Helm",
                ["oldestTime"] = 1632902231,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293815,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 69999,
                        ["guild"] = 1,
                        ["buyer"] = 564,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633031233,
                        ["quant"] = 1,
                        ["id"] = "1690452629",
                        ["itemLink"] = 717,
                    },
                    [2] = 
                    {
                        ["price"] = 69999,
                        ["guild"] = 1,
                        ["buyer"] = 1204,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633142415,
                        ["quant"] = 1,
                        ["id"] = "1691318657",
                        ["itemLink"] = 717,
                    },
                    [3] = 
                    {
                        ["price"] = 69999,
                        ["guild"] = 1,
                        ["buyer"] = 2001,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633293815,
                        ["quant"] = 1,
                        ["id"] = "1692673753",
                        ["itemLink"] = 717,
                    },
                    [4] = 
                    {
                        ["price"] = 54000,
                        ["guild"] = 1,
                        ["buyer"] = 249,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632902231,
                        ["quant"] = 1,
                        ["id"] = "1689570017",
                        ["itemLink"] = 717,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 blue superior heavy apparel head bolstered",
            },
        },
        [119396] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing2.dds",
                ["itemDesc"] = "Diagram: Common Lantern, Hanging",
                ["oldestTime"] = 1633242870,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242870,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 320,
                        ["guild"] = 1,
                        ["buyer"] = 1331,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633242870,
                        ["quant"] = 1,
                        ["id"] = "1692217549",
                        ["itemLink"] = 2555,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [96984] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_medium_shoulders_a.dds",
                ["itemDesc"] = "Arm Cops of the Night Mother",
                ["oldestTime"] = 1633053415,
                ["wasAltered"] = true,
                ["newestTime"] = 1633053415,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 726,
                        ["wasKiosk"] = true,
                        ["seller"] = 237,
                        ["timestamp"] = 1633053415,
                        ["quant"] = 1,
                        ["id"] = "1690639755",
                        ["itemLink"] = 933,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set night mother's embrace shoulders divines",
            },
        },
        [120445] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_tre_eve_juniper001.dds",
                ["itemDesc"] = "Tree, Sturdy Juniper",
                ["oldestTime"] = 1633238262,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238262,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1745,
                        ["wasKiosk"] = true,
                        ["seller"] = 1747,
                        ["timestamp"] = 1633238262,
                        ["quant"] = 2,
                        ["id"] = "1692187381",
                        ["itemLink"] = 2512,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal furnishings conservatory",
            },
        },
        [43738] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Vvardenfell Treasure Map II",
                ["oldestTime"] = 1633011626,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310224,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 454,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633011626,
                        ["quant"] = 1,
                        ["id"] = "1690301335",
                        ["itemLink"] = 515,
                    },
                    [2] = 
                    {
                        ["price"] = 289,
                        ["guild"] = 1,
                        ["buyer"] = 1333,
                        ["wasKiosk"] = true,
                        ["seller"] = 164,
                        ["timestamp"] = 1633169184,
                        ["quant"] = 1,
                        ["id"] = "1691515303",
                        ["itemLink"] = 515,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 626,
                        ["timestamp"] = 1633310224,
                        ["quant"] = 1,
                        ["id"] = "1692851235",
                        ["itemLink"] = 515,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [33755] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_bananas.dds",
                ["itemDesc"] = "Bananas",
                ["oldestTime"] = 1632894034,
                ["wasAltered"] = true,
                ["newestTime"] = 1632894034,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3600,
                        ["guild"] = 1,
                        ["buyer"] = 2427,
                        ["wasKiosk"] = true,
                        ["seller"] = 649,
                        ["timestamp"] = 1632894034,
                        ["quant"] = 200,
                        ["id"] = "1689524397",
                        ["itemLink"] = 3550,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [120673] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_bsh_auridonhedge003.dds",
                ["itemDesc"] = "Hedge, Large Horseshoe",
                ["oldestTime"] = 1633238187,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238187,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8400,
                        ["guild"] = 1,
                        ["buyer"] = 1745,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1633238187,
                        ["quant"] = 3,
                        ["id"] = "1692186675",
                        ["itemLink"] = 2506,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings conservatory",
            },
        },
        [139485] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Alinor Pew, Polished",
                ["oldestTime"] = 1633045914,
                ["wasAltered"] = true,
                ["newestTime"] = 1633045914,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 676,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633045914,
                        ["quant"] = 1,
                        ["id"] = "1690565815",
                        ["itemLink"] = 864,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [126430] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_vrd_fur_teltableorganic002.dds",
                ["itemDesc"] = "Telvanni Table, Organic Grand",
                ["oldestTime"] = 1632860429,
                ["wasAltered"] = true,
                ["newestTime"] = 1633218323,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 1598,
                        ["wasKiosk"] = true,
                        ["seller"] = 99,
                        ["timestamp"] = 1633218323,
                        ["quant"] = 1,
                        ["id"] = "1691994273",
                        ["itemLink"] = 2325,
                    },
                    [2] = 
                    {
                        ["price"] = 22105,
                        ["guild"] = 1,
                        ["buyer"] = 25,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1632860429,
                        ["quant"] = 1,
                        ["id"] = "1689233895",
                        ["itemLink"] = 2325,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [96991] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_medium_shoulders_a.dds",
                ["itemDesc"] = "Arm Cops of the Night Mother",
                ["oldestTime"] = 1633023045,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023045,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633023045,
                        ["quant"] = 1,
                        ["id"] = "1690391021",
                        ["itemLink"] = 668,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set night mother's embrace shoulders well-fitted",
            },
        },
        [46048] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Comely Wench Whiskey",
                ["oldestTime"] = 1632877191,
                ["wasAltered"] = true,
                ["newestTime"] = 1632877191,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 2333,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1632877191,
                        ["quant"] = 1,
                        ["id"] = "1689363367",
                        ["itemLink"] = 3429,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [102171] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_draugr_medium_shoulders_a.dds",
                ["itemDesc"] = "Stygian Arm Cops",
                ["oldestTime"] = 1633175639,
                ["wasAltered"] = true,
                ["newestTime"] = 1633270807,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 1352,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633175639,
                        ["quant"] = 1,
                        ["id"] = "1691551965",
                        ["itemLink"] = 1899,
                    },
                    [2] = 
                    {
                        ["price"] = 75000,
                        ["guild"] = 1,
                        ["buyer"] = 1878,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633270807,
                        ["quant"] = 1,
                        ["id"] = "1692413957",
                        ["itemLink"] = 1899,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic medium apparel set stygian shoulders impenetrable",
            },
        },
        [56034] = 
        {
            ["1:0:1:26:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_staff_a.dds",
                ["itemDesc"] = "Maple Inferno Staff",
                ["oldestTime"] = 1632870399,
                ["wasAltered"] = true,
                ["newestTime"] = 1633006477,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 50,
                        ["wasKiosk"] = false,
                        ["seller"] = 207,
                        ["timestamp"] = 1633006477,
                        ["quant"] = 1,
                        ["id"] = "1690267869",
                        ["itemLink"] = 431,
                    },
                    [2] = 
                    {
                        ["price"] = 34500,
                        ["guild"] = 1,
                        ["buyer"] = 2288,
                        ["wasKiosk"] = true,
                        ["seller"] = 569,
                        ["timestamp"] = 1632870399,
                        ["quant"] = 1,
                        ["id"] = "1689305945",
                        ["itemLink"] = 431,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal weapon flame staff two-handed nirnhoned",
            },
        },
        [130019] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 52: Redoran Legs",
                ["oldestTime"] = 1633143435,
                ["wasAltered"] = true,
                ["newestTime"] = 1633143435,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15999,
                        ["guild"] = 1,
                        ["buyer"] = 1213,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633143435,
                        ["quant"] = 1,
                        ["id"] = "1691330939",
                        ["itemLink"] = 1638,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [23268] = 
        {
            ["50:5:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_potion_base_water_4_r1.dds",
                ["itemDesc"] = "Cloud Mist",
                ["oldestTime"] = 1633194409,
                ["wasAltered"] = true,
                ["newestTime"] = 1633194409,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3600,
                        ["guild"] = 1,
                        ["buyer"] = 803,
                        ["wasKiosk"] = false,
                        ["seller"] = 199,
                        ["timestamp"] = 1633194409,
                        ["quant"] = 12,
                        ["id"] = "1691737693",
                        ["itemLink"] = 2132,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp50 white normal materials potion solvent",
            },
        },
        [172261] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_shoulders_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Arm Cops",
                ["oldestTime"] = 1633047252,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310173,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 684,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633047252,
                        ["quant"] = 1,
                        ["id"] = "1690577895",
                        ["itemLink"] = 870,
                    },
                    [2] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 63,
                        ["wasKiosk"] = false,
                        ["seller"] = 739,
                        ["timestamp"] = 1633310173,
                        ["quant"] = 1,
                        ["id"] = "1692850947",
                        ["itemLink"] = 870,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior medium apparel set deadlands assassin shoulders sturdy",
            },
        },
        [115942] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Breton Cupboard, Knotwork",
                ["oldestTime"] = 1633040324,
                ["wasAltered"] = true,
                ["newestTime"] = 1633040324,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 623,
                        ["wasKiosk"] = true,
                        ["seller"] = 625,
                        ["timestamp"] = 1633040324,
                        ["quant"] = 1,
                        ["id"] = "1690515711",
                        ["itemLink"] = 792,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [126845] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_alchemy2.dds",
                ["itemDesc"] = "Formula: Indoril Lightpost, Stone",
                ["oldestTime"] = 1633142925,
                ["wasAltered"] = true,
                ["newestTime"] = 1633142925,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1208,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633142925,
                        ["quant"] = 1,
                        ["id"] = "1691324183",
                        ["itemLink"] = 1625,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [172008] = 
        {
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_head_a.dds",
                ["itemDesc"] = "Hat of Frostbite",
                ["oldestTime"] = 1633215988,
                ["wasAltered"] = true,
                ["newestTime"] = 1633215988,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 327,
                        ["wasKiosk"] = false,
                        ["seller"] = 52,
                        ["timestamp"] = 1633215988,
                        ["quant"] = 1,
                        ["id"] = "1691968285",
                        ["itemLink"] = 2312,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite head well-fitted",
            },
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_head_a.dds",
                ["itemDesc"] = "Hat of Frostbite",
                ["oldestTime"] = 1633136885,
                ["wasAltered"] = true,
                ["newestTime"] = 1633136885,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 1159,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633136885,
                        ["quant"] = 1,
                        ["id"] = "1691261375",
                        ["itemLink"] = 1575,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set frostbite head well-fitted",
            },
        },
        [159441] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_fur_housingbedhigh001.dds",
                ["itemDesc"] = "Elsweyr Bed, Senche-Raht",
                ["oldestTime"] = 1633166696,
                ["wasAltered"] = true,
                ["newestTime"] = 1633166696,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 1327,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633166696,
                        ["quant"] = 1,
                        ["id"] = "1691503559",
                        ["itemLink"] = 1866,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings suite",
            },
        },
        [49130] = 
        {
            ["10:0:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_medium_shoulders_a.dds",
                ["itemDesc"] = "Arm Cops of the Night Mother",
                ["oldestTime"] = 1632911091,
                ["wasAltered"] = true,
                ["newestTime"] = 1633090248,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 917,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633090248,
                        ["quant"] = 1,
                        ["id"] = "1690889583",
                        ["itemLink"] = 1239,
                    },
                    [2] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2463,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632911091,
                        ["quant"] = 1,
                        ["id"] = "1689604573",
                        ["itemLink"] = 1239,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr10 blue superior medium apparel set night mother's gaze shoulders training",
            },
        },
        [147691] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 72: Meridian Legs",
                ["oldestTime"] = 1633016315,
                ["wasAltered"] = true,
                ["newestTime"] = 1633016315,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 471,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633016315,
                        ["quant"] = 1,
                        ["id"] = "1690335817",
                        ["itemLink"] = 541,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [176600] = 
        {
            ["1:0:3:56:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_necklace.dds",
                ["itemDesc"] = "Companion's Necklace",
                ["oldestTime"] = 1633213920,
                ["wasAltered"] = true,
                ["newestTime"] = 1633213920,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 1569,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633213920,
                        ["quant"] = 1,
                        ["id"] = "1691948533",
                        ["itemLink"] = 2292,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior jewelry apparel neck aggressive",
            },
        },
        [135149] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/jewelrycrafting_booster_refined_zircon.dds",
                ["itemDesc"] = "Zircon Plating",
                ["oldestTime"] = 1632830420,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311752,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 69000,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 22,
                        ["timestamp"] = 1633311752,
                        ["quant"] = 1,
                        ["id"] = "1692867111",
                        ["itemLink"] = 14,
                    },
                    [2] = 
                    {
                        ["price"] = 68000,
                        ["guild"] = 1,
                        ["buyer"] = 578,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633033345,
                        ["quant"] = 1,
                        ["id"] = "1690465917",
                        ["itemLink"] = 14,
                    },
                    [3] = 
                    {
                        ["price"] = 69999,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 56,
                        ["timestamp"] = 1633131429,
                        ["quant"] = 1,
                        ["id"] = "1691201855",
                        ["itemLink"] = 14,
                    },
                    [4] = 
                    {
                        ["price"] = 69999,
                        ["guild"] = 1,
                        ["buyer"] = 1253,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633149811,
                        ["quant"] = 1,
                        ["id"] = "1691389139",
                        ["itemLink"] = 14,
                    },
                    [5] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 1253,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633149811,
                        ["quant"] = 1,
                        ["id"] = "1691389151",
                        ["itemLink"] = 14,
                    },
                    [6] = 
                    {
                        ["price"] = 71500,
                        ["guild"] = 1,
                        ["buyer"] = 1308,
                        ["wasKiosk"] = true,
                        ["seller"] = 232,
                        ["timestamp"] = 1633161140,
                        ["quant"] = 1,
                        ["id"] = "1691472371",
                        ["itemLink"] = 14,
                    },
                    [7] = 
                    {
                        ["price"] = 71500,
                        ["guild"] = 1,
                        ["buyer"] = 1308,
                        ["wasKiosk"] = true,
                        ["seller"] = 232,
                        ["timestamp"] = 1633161141,
                        ["quant"] = 1,
                        ["id"] = "1691472383",
                        ["itemLink"] = 14,
                    },
                    [8] = 
                    {
                        ["price"] = 71998,
                        ["guild"] = 1,
                        ["buyer"] = 1308,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633161144,
                        ["quant"] = 1,
                        ["id"] = "1691472401",
                        ["itemLink"] = 14,
                    },
                    [9] = 
                    {
                        ["price"] = 65000,
                        ["guild"] = 1,
                        ["buyer"] = 1436,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633193875,
                        ["quant"] = 1,
                        ["id"] = "1691733287",
                        ["itemLink"] = 14,
                    },
                    [10] = 
                    {
                        ["price"] = 70999,
                        ["guild"] = 1,
                        ["buyer"] = 494,
                        ["wasKiosk"] = false,
                        ["seller"] = 1510,
                        ["timestamp"] = 1633203615,
                        ["quant"] = 1,
                        ["id"] = "1691829457",
                        ["itemLink"] = 14,
                    },
                    [11] = 
                    {
                        ["price"] = 71000,
                        ["guild"] = 1,
                        ["buyer"] = 494,
                        ["wasKiosk"] = false,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633203619,
                        ["quant"] = 1,
                        ["id"] = "1691829487",
                        ["itemLink"] = 14,
                    },
                    [12] = 
                    {
                        ["price"] = 71000,
                        ["guild"] = 1,
                        ["buyer"] = 511,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633203770,
                        ["quant"] = 1,
                        ["id"] = "1691830765",
                        ["itemLink"] = 14,
                    },
                    [13] = 
                    {
                        ["price"] = 72499,
                        ["guild"] = 1,
                        ["buyer"] = 1538,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633207871,
                        ["quant"] = 1,
                        ["id"] = "1691880889",
                        ["itemLink"] = 14,
                    },
                    [14] = 
                    {
                        ["price"] = 72499,
                        ["guild"] = 1,
                        ["buyer"] = 1538,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633207874,
                        ["quant"] = 1,
                        ["id"] = "1691880919",
                        ["itemLink"] = 14,
                    },
                    [15] = 
                    {
                        ["price"] = 72500,
                        ["guild"] = 1,
                        ["buyer"] = 1538,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1633207876,
                        ["quant"] = 1,
                        ["id"] = "1691880945",
                        ["itemLink"] = 14,
                    },
                    [16] = 
                    {
                        ["price"] = 72500,
                        ["guild"] = 1,
                        ["buyer"] = 1538,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1633207877,
                        ["quant"] = 1,
                        ["id"] = "1691880979",
                        ["itemLink"] = 14,
                    },
                    [17] = 
                    {
                        ["price"] = 72500,
                        ["guild"] = 1,
                        ["buyer"] = 1538,
                        ["wasKiosk"] = true,
                        ["seller"] = 146,
                        ["timestamp"] = 1633207879,
                        ["quant"] = 1,
                        ["id"] = "1691881013",
                        ["itemLink"] = 14,
                    },
                    [18] = 
                    {
                        ["price"] = 72500,
                        ["guild"] = 1,
                        ["buyer"] = 1538,
                        ["wasKiosk"] = true,
                        ["seller"] = 146,
                        ["timestamp"] = 1633207880,
                        ["quant"] = 1,
                        ["id"] = "1691881051",
                        ["itemLink"] = 14,
                    },
                    [19] = 
                    {
                        ["price"] = 72500,
                        ["guild"] = 1,
                        ["buyer"] = 1538,
                        ["wasKiosk"] = true,
                        ["seller"] = 146,
                        ["timestamp"] = 1633207884,
                        ["quant"] = 1,
                        ["id"] = "1691881103",
                        ["itemLink"] = 14,
                    },
                    [20] = 
                    {
                        ["price"] = 72500,
                        ["guild"] = 1,
                        ["buyer"] = 1538,
                        ["wasKiosk"] = true,
                        ["seller"] = 146,
                        ["timestamp"] = 1633207888,
                        ["quant"] = 1,
                        ["id"] = "1691881147",
                        ["itemLink"] = 14,
                    },
                    [21] = 
                    {
                        ["price"] = 72500,
                        ["guild"] = 1,
                        ["buyer"] = 1545,
                        ["wasKiosk"] = true,
                        ["seller"] = 1546,
                        ["timestamp"] = 1633209300,
                        ["quant"] = 1,
                        ["id"] = "1691898173",
                        ["itemLink"] = 14,
                    },
                    [22] = 
                    {
                        ["price"] = 72500,
                        ["guild"] = 1,
                        ["buyer"] = 1545,
                        ["wasKiosk"] = true,
                        ["seller"] = 1546,
                        ["timestamp"] = 1633209302,
                        ["quant"] = 1,
                        ["id"] = "1691898181",
                        ["itemLink"] = 14,
                    },
                    [23] = 
                    {
                        ["price"] = 72999,
                        ["guild"] = 1,
                        ["buyer"] = 1545,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633209303,
                        ["quant"] = 1,
                        ["id"] = "1691898191",
                        ["itemLink"] = 14,
                    },
                    [24] = 
                    {
                        ["price"] = 72999,
                        ["guild"] = 1,
                        ["buyer"] = 1545,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633209305,
                        ["quant"] = 1,
                        ["id"] = "1691898211",
                        ["itemLink"] = 14,
                    },
                    [25] = 
                    {
                        ["price"] = 71000,
                        ["guild"] = 1,
                        ["buyer"] = 1021,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633254232,
                        ["quant"] = 1,
                        ["id"] = "1692297553",
                        ["itemLink"] = 14,
                    },
                    [26] = 
                    {
                        ["price"] = 71998,
                        ["guild"] = 1,
                        ["buyer"] = 1021,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633254233,
                        ["quant"] = 1,
                        ["id"] = "1692297557",
                        ["itemLink"] = 14,
                    },
                    [27] = 
                    {
                        ["price"] = 72000,
                        ["guild"] = 1,
                        ["buyer"] = 1021,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633254235,
                        ["quant"] = 1,
                        ["id"] = "1692297565",
                        ["itemLink"] = 14,
                    },
                    [28] = 
                    {
                        ["price"] = 72000,
                        ["guild"] = 1,
                        ["buyer"] = 1021,
                        ["wasKiosk"] = true,
                        ["seller"] = 845,
                        ["timestamp"] = 1633254265,
                        ["quant"] = 1,
                        ["id"] = "1692297783",
                        ["itemLink"] = 14,
                    },
                    [29] = 
                    {
                        ["price"] = 72999,
                        ["guild"] = 1,
                        ["buyer"] = 1021,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633254266,
                        ["quant"] = 1,
                        ["id"] = "1692297787",
                        ["itemLink"] = 14,
                    },
                    [30] = 
                    {
                        ["price"] = 73000,
                        ["guild"] = 1,
                        ["buyer"] = 1021,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633254267,
                        ["quant"] = 1,
                        ["id"] = "1692297799",
                        ["itemLink"] = 14,
                    },
                    [31] = 
                    {
                        ["price"] = 73072,
                        ["guild"] = 1,
                        ["buyer"] = 1021,
                        ["wasKiosk"] = true,
                        ["seller"] = 649,
                        ["timestamp"] = 1633254290,
                        ["quant"] = 1,
                        ["id"] = "1692297899",
                        ["itemLink"] = 14,
                    },
                    [32] = 
                    {
                        ["price"] = 73942,
                        ["guild"] = 1,
                        ["buyer"] = 1021,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1633254296,
                        ["quant"] = 1,
                        ["id"] = "1692297911",
                        ["itemLink"] = 14,
                    },
                    [33] = 
                    {
                        ["price"] = 216000,
                        ["guild"] = 1,
                        ["buyer"] = 1952,
                        ["wasKiosk"] = true,
                        ["seller"] = 563,
                        ["timestamp"] = 1633285643,
                        ["quant"] = 3,
                        ["id"] = "1692572831",
                        ["itemLink"] = 14,
                    },
                    [34] = 
                    {
                        ["price"] = 71998,
                        ["guild"] = 1,
                        ["buyer"] = 2132,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1632830420,
                        ["quant"] = 1,
                        ["id"] = "1689000797",
                        ["itemLink"] = 14,
                    },
                    [35] = 
                    {
                        ["price"] = 72078,
                        ["guild"] = 1,
                        ["buyer"] = 2132,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632830421,
                        ["quant"] = 1,
                        ["id"] = "1689000809",
                        ["itemLink"] = 14,
                    },
                    [36] = 
                    {
                        ["price"] = 72078,
                        ["guild"] = 1,
                        ["buyer"] = 2132,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632830422,
                        ["quant"] = 1,
                        ["id"] = "1689000813",
                        ["itemLink"] = 14,
                    },
                    [37] = 
                    {
                        ["price"] = 73000,
                        ["guild"] = 1,
                        ["buyer"] = 1497,
                        ["wasKiosk"] = false,
                        ["seller"] = 1450,
                        ["timestamp"] = 1632838471,
                        ["quant"] = 1,
                        ["id"] = "1689050777",
                        ["itemLink"] = 14,
                    },
                    [38] = 
                    {
                        ["price"] = 73000,
                        ["guild"] = 1,
                        ["buyer"] = 1497,
                        ["wasKiosk"] = false,
                        ["seller"] = 1450,
                        ["timestamp"] = 1632838472,
                        ["quant"] = 1,
                        ["id"] = "1689050789",
                        ["itemLink"] = 14,
                    },
                    [39] = 
                    {
                        ["price"] = 73999,
                        ["guild"] = 1,
                        ["buyer"] = 1497,
                        ["wasKiosk"] = false,
                        ["seller"] = 90,
                        ["timestamp"] = 1632838475,
                        ["quant"] = 1,
                        ["id"] = "1689050811",
                        ["itemLink"] = 14,
                    },
                    [40] = 
                    {
                        ["price"] = 73999,
                        ["guild"] = 1,
                        ["buyer"] = 1497,
                        ["wasKiosk"] = false,
                        ["seller"] = 90,
                        ["timestamp"] = 1632838481,
                        ["quant"] = 1,
                        ["id"] = "1689050859",
                        ["itemLink"] = 14,
                    },
                    [41] = 
                    {
                        ["price"] = 73999,
                        ["guild"] = 1,
                        ["buyer"] = 1497,
                        ["wasKiosk"] = false,
                        ["seller"] = 56,
                        ["timestamp"] = 1632838482,
                        ["quant"] = 1,
                        ["id"] = "1689050865",
                        ["itemLink"] = 14,
                    },
                    [42] = 
                    {
                        ["price"] = 67000,
                        ["guild"] = 1,
                        ["buyer"] = 2234,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1632855411,
                        ["quant"] = 1,
                        ["id"] = "1689187141",
                        ["itemLink"] = 14,
                    },
                    [43] = 
                    {
                        ["price"] = 835000,
                        ["guild"] = 1,
                        ["buyer"] = 1204,
                        ["wasKiosk"] = true,
                        ["seller"] = 1318,
                        ["timestamp"] = 1632878106,
                        ["quant"] = 10,
                        ["id"] = "1689373033",
                        ["itemLink"] = 14,
                    },
                    [44] = 
                    {
                        ["price"] = 65000,
                        ["guild"] = 1,
                        ["buyer"] = 1354,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632963572,
                        ["quant"] = 1,
                        ["id"] = "1689991893",
                        ["itemLink"] = 14,
                    },
                    [45] = 
                    {
                        ["price"] = 65000,
                        ["guild"] = 1,
                        ["buyer"] = 1354,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632963573,
                        ["quant"] = 1,
                        ["id"] = "1689991895",
                        ["itemLink"] = 14,
                    },
                    [46] = 
                    {
                        ["price"] = 65000,
                        ["guild"] = 1,
                        ["buyer"] = 1354,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632963574,
                        ["quant"] = 1,
                        ["id"] = "1689991897",
                        ["itemLink"] = 14,
                    },
                    [47] = 
                    {
                        ["price"] = 65000,
                        ["guild"] = 1,
                        ["buyer"] = 1354,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632963575,
                        ["quant"] = 1,
                        ["id"] = "1689991899",
                        ["itemLink"] = 14,
                    },
                    [48] = 
                    {
                        ["price"] = 65000,
                        ["guild"] = 1,
                        ["buyer"] = 1354,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632963575,
                        ["quant"] = 1,
                        ["id"] = "1689991901",
                        ["itemLink"] = 14,
                    },
                },
                ["totalCount"] = 48,
                ["itemAdderText"] = "rr01 purple epic materials plating",
            },
        },
        [171758] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_inc_markruglargesquare001.dds",
                ["itemDesc"] = "Markarth Floor, Large Square",
                ["oldestTime"] = 1633146473,
                ["wasAltered"] = true,
                ["newestTime"] = 1633146473,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 28500,
                        ["guild"] = 1,
                        ["buyer"] = 1232,
                        ["wasKiosk"] = true,
                        ["seller"] = 569,
                        ["timestamp"] = 1633146473,
                        ["quant"] = 1,
                        ["id"] = "1691360679",
                        ["itemLink"] = 1653,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings structures",
            },
        },
        [180461] = 
        {
            ["50:16:3:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_staff_a.dds",
                ["itemDesc"] = "Restoration Staff of Dark Convergence",
                ["oldestTime"] = 1633206333,
                ["wasAltered"] = true,
                ["newestTime"] = 1633206333,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3333,
                        ["guild"] = 1,
                        ["buyer"] = 1528,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633206333,
                        ["quant"] = 1,
                        ["id"] = "1691859231",
                        ["itemLink"] = 2253,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set dark convergence healing staff two-handed powered",
            },
        },
        [121328] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 47: Buoyant Armiger Shoulders",
                ["oldestTime"] = 1633294392,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294392,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 2008,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633294392,
                        ["quant"] = 1,
                        ["id"] = "1692682163",
                        ["itemLink"] = 2864,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [176881] = 
        {
            ["1:0:3:49:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_helm_heavy.dds",
                ["itemDesc"] = "Companion's Helm",
                ["oldestTime"] = 1633068643,
                ["wasAltered"] = true,
                ["newestTime"] = 1633068643,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 2,
                        ["buyer"] = 133,
                        ["wasKiosk"] = false,
                        ["seller"] = 136,
                        ["timestamp"] = 1633068643,
                        ["quant"] = 1,
                        ["id"] = "1690770869",
                        ["itemLink"] = 147,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior heavy apparel head augmented",
            },
        },
        [68221] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Dragontail Blended Whisky",
                ["oldestTime"] = 1633130304,
                ["wasAltered"] = true,
                ["newestTime"] = 1633130304,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 87,
                        ["guild"] = 1,
                        ["buyer"] = 1102,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633130304,
                        ["quant"] = 1,
                        ["id"] = "1691189267",
                        ["itemLink"] = 1509,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [121527] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_blacksmithing.dds",
                ["itemDesc"] = "Sealed Blacksmithing Writ",
                ["oldestTime"] = 1632894602,
                ["wasAltered"] = true,
                ["newestTime"] = 1633205100,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 21800,
                        ["guild"] = 1,
                        ["buyer"] = 352,
                        ["wasKiosk"] = true,
                        ["seller"] = 353,
                        ["timestamp"] = 1632990386,
                        ["quant"] = 1,
                        ["id"] = "1690189149",
                        ["itemLink"] = 352,
                    },
                    [2] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633111848,
                        ["quant"] = 1,
                        ["id"] = "1691050735",
                        ["itemLink"] = 1330,
                    },
                    [3] = 
                    {
                        ["price"] = 23000,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633111850,
                        ["quant"] = 1,
                        ["id"] = "1691050765",
                        ["itemLink"] = 1334,
                    },
                    [4] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1081,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633125260,
                        ["quant"] = 1,
                        ["id"] = "1691144645",
                        ["itemLink"] = 1468,
                    },
                    [5] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 1520,
                        ["wasKiosk"] = true,
                        ["seller"] = 802,
                        ["timestamp"] = 1633205100,
                        ["quant"] = 1,
                        ["id"] = "1691843459",
                        ["itemLink"] = 2246,
                    },
                    [6] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 533,
                        ["timestamp"] = 1632894602,
                        ["quant"] = 1,
                        ["id"] = "1689527331",
                        ["itemLink"] = 3554,
                    },
                    [7] = 
                    {
                        ["price"] = 38150,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 990,
                        ["timestamp"] = 1632894693,
                        ["quant"] = 1,
                        ["id"] = "1689527853",
                        ["itemLink"] = 3556,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr01 gold legendary consumable master writ",
            },
        },
        [97012] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_medium_shoulders_a.dds",
                ["itemDesc"] = "Arm Cops of the Night Mother",
                ["oldestTime"] = 1632936837,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023014,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633023014,
                        ["quant"] = 1,
                        ["id"] = "1690390733",
                        ["itemLink"] = 637,
                    },
                    [2] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 226,
                        ["wasKiosk"] = false,
                        ["seller"] = 354,
                        ["timestamp"] = 1632936837,
                        ["quant"] = 1,
                        ["id"] = "1689774037",
                        ["itemLink"] = 637,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior medium apparel set night mother's embrace shoulders invigorating",
            },
        },
        [57845] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 17: Xivkyn Shields",
                ["oldestTime"] = 1632941313,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022537,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8131,
                        ["guild"] = 1,
                        ["buyer"] = 519,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633022537,
                        ["quant"] = 1,
                        ["id"] = "1690386891",
                        ["itemLink"] = 593,
                    },
                    [2] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1872,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1632941313,
                        ["quant"] = 1,
                        ["id"] = "1689804491",
                        ["itemLink"] = 593,
                    },
                    [3] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 1872,
                        ["wasKiosk"] = true,
                        ["seller"] = 533,
                        ["timestamp"] = 1632941319,
                        ["quant"] = 1,
                        ["id"] = "1689804523",
                        ["itemLink"] = 593,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [100212] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Fiord's Necklace",
                ["oldestTime"] = 1633163912,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163913,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633163912,
                        ["quant"] = 1,
                        ["id"] = "1691490325",
                        ["itemLink"] = 1808,
                    },
                    [2] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633163913,
                        ["quant"] = 1,
                        ["id"] = "1691490329",
                        ["itemLink"] = 1808,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set fiord's legacy neck robust",
            },
        },
        [135157] = 
        {
            ["1:0:1:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/jewelrycrafting_trait_refined_zinc.dds",
                ["itemDesc"] = "Zinc",
                ["oldestTime"] = 1633158259,
                ["wasAltered"] = true,
                ["newestTime"] = 1633158262,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 780,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633158259,
                        ["quant"] = 10,
                        ["id"] = "1691455839",
                        ["itemLink"] = 1782,
                    },
                    [2] = 
                    {
                        ["price"] = 780,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633158260,
                        ["quant"] = 10,
                        ["id"] = "1691455851",
                        ["itemLink"] = 1782,
                    },
                    [3] = 
                    {
                        ["price"] = 780,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633158261,
                        ["quant"] = 10,
                        ["id"] = "1691455863",
                        ["itemLink"] = 1782,
                    },
                    [4] = 
                    {
                        ["price"] = 780,
                        ["guild"] = 1,
                        ["buyer"] = 1284,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633158262,
                        ["quant"] = 10,
                        ["id"] = "1691455871",
                        ["itemLink"] = 1782,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 white normal materials jewelry trait robust",
            },
        },
        [176888] = 
        {
            ["1:0:3:58:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_necklace.dds",
                ["itemDesc"] = "Companion's Necklace",
                ["oldestTime"] = 1633061566,
                ["wasAltered"] = true,
                ["newestTime"] = 1633061566,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 793,
                        ["wasKiosk"] = true,
                        ["seller"] = 43,
                        ["timestamp"] = 1633061566,
                        ["quant"] = 1,
                        ["id"] = "1690721777",
                        ["itemLink"] = 1028,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior jewelry apparel neck augmented",
            },
        },
        [160505] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 84: Blackreach Vanguard Shoulders",
                ["oldestTime"] = 1632880993,
                ["wasAltered"] = true,
                ["newestTime"] = 1632880993,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 2356,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1632880993,
                        ["quant"] = 1,
                        ["id"] = "1689406457",
                        ["itemLink"] = 3464,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [161105] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_greyhosthvy_legs_a.dds",
                ["itemDesc"] = "Greaves of Eternal Vigor",
                ["oldestTime"] = 1633121648,
                ["wasAltered"] = true,
                ["newestTime"] = 1633121648,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3999,
                        ["guild"] = 1,
                        ["buyer"] = 1056,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633121648,
                        ["quant"] = 1,
                        ["id"] = "1691116947",
                        ["itemLink"] = 1443,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set eternal vigor legs impenetrable",
            },
        },
        [97019] = 
        {
            ["9:0:2:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_medium_shoulders_a.dds",
                ["itemDesc"] = "Arm Cops of the Night Mother",
                ["oldestTime"] = 1632857779,
                ["wasAltered"] = true,
                ["newestTime"] = 1632885793,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1632857779,
                        ["quant"] = 1,
                        ["id"] = "1689212175",
                        ["itemLink"] = 3287,
                    },
                    [2] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 970,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1632885793,
                        ["quant"] = 1,
                        ["id"] = "1689460771",
                        ["itemLink"] = 3287,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr09 green fine medium apparel set night mother's embrace shoulders sturdy",
            },
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_medium_shoulders_a.dds",
                ["itemDesc"] = "Arm Cops of the Night Mother",
                ["oldestTime"] = 1632847693,
                ["wasAltered"] = true,
                ["newestTime"] = 1632847693,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1632847693,
                        ["quant"] = 1,
                        ["id"] = "1689125579",
                        ["itemLink"] = 3217,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set night mother's embrace shoulders sturdy",
            },
        },
        [176636] = 
        {
            ["1:0:4:56:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_necklace.dds",
                ["itemDesc"] = "Companion's Necklace",
                ["oldestTime"] = 1633176324,
                ["wasAltered"] = true,
                ["newestTime"] = 1633176324,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 549995,
                        ["guild"] = 1,
                        ["buyer"] = 1354,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1633176324,
                        ["quant"] = 1,
                        ["id"] = "1691557269",
                        ["itemLink"] = 1900,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic jewelry apparel neck aggressive",
            },
        },
        [134909] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_fug_smlundeadmushroom005.dds",
                ["itemDesc"] = "Mushrooms, Puspocket Group",
                ["oldestTime"] = 1633033028,
                ["wasAltered"] = true,
                ["newestTime"] = 1633033028,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3092,
                        ["guild"] = 1,
                        ["buyer"] = 575,
                        ["wasKiosk"] = true,
                        ["seller"] = 493,
                        ["timestamp"] = 1633033028,
                        ["quant"] = 2,
                        ["id"] = "1690463929",
                        ["itemLink"] = 748,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings conservatory",
            },
        },
        [156637] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 80: Shield of Senchal Maces",
                ["oldestTime"] = 1633052124,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052124,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10500,
                        ["guild"] = 1,
                        ["buyer"] = 242,
                        ["wasKiosk"] = false,
                        ["seller"] = 711,
                        ["timestamp"] = 1633052124,
                        ["quant"] = 1,
                        ["id"] = "1690627233",
                        ["itemLink"] = 897,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [135146] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_platinum_refined.dds",
                ["itemDesc"] = "Platinum Ounce",
                ["oldestTime"] = 1632841474,
                ["wasAltered"] = true,
                ["newestTime"] = 1633271518,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 167,
                        ["wasKiosk"] = true,
                        ["seller"] = 168,
                        ["timestamp"] = 1632970417,
                        ["quant"] = 200,
                        ["id"] = "1690060495",
                        ["itemLink"] = 180,
                    },
                    [2] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 167,
                        ["wasKiosk"] = true,
                        ["seller"] = 168,
                        ["timestamp"] = 1632970417,
                        ["quant"] = 200,
                        ["id"] = "1690060505",
                        ["itemLink"] = 180,
                    },
                    [3] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 167,
                        ["wasKiosk"] = true,
                        ["seller"] = 168,
                        ["timestamp"] = 1632970418,
                        ["quant"] = 200,
                        ["id"] = "1690060513",
                        ["itemLink"] = 180,
                    },
                    [4] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 167,
                        ["wasKiosk"] = true,
                        ["seller"] = 168,
                        ["timestamp"] = 1632970419,
                        ["quant"] = 200,
                        ["id"] = "1690060525",
                        ["itemLink"] = 180,
                    },
                    [5] = 
                    {
                        ["price"] = 8099,
                        ["guild"] = 1,
                        ["buyer"] = 372,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1632994283,
                        ["quant"] = 200,
                        ["id"] = "1690206981",
                        ["itemLink"] = 180,
                    },
                    [6] = 
                    {
                        ["price"] = 8099,
                        ["guild"] = 1,
                        ["buyer"] = 374,
                        ["wasKiosk"] = false,
                        ["seller"] = 279,
                        ["timestamp"] = 1633000159,
                        ["quant"] = 200,
                        ["id"] = "1690235655",
                        ["itemLink"] = 180,
                    },
                    [7] = 
                    {
                        ["price"] = 8099,
                        ["guild"] = 1,
                        ["buyer"] = 374,
                        ["wasKiosk"] = false,
                        ["seller"] = 279,
                        ["timestamp"] = 1633000159,
                        ["quant"] = 200,
                        ["id"] = "1690235659",
                        ["itemLink"] = 180,
                    },
                    [8] = 
                    {
                        ["price"] = 8099,
                        ["guild"] = 1,
                        ["buyer"] = 374,
                        ["wasKiosk"] = false,
                        ["seller"] = 279,
                        ["timestamp"] = 1633000160,
                        ["quant"] = 200,
                        ["id"] = "1690235665",
                        ["itemLink"] = 180,
                    },
                    [9] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 465,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633014575,
                        ["quant"] = 200,
                        ["id"] = "1690321779",
                        ["itemLink"] = 180,
                    },
                    [10] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633035652,
                        ["quant"] = 200,
                        ["id"] = "1690480265",
                        ["itemLink"] = 180,
                    },
                    [11] = 
                    {
                        ["price"] = 7440,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633035653,
                        ["quant"] = 186,
                        ["id"] = "1690480279",
                        ["itemLink"] = 180,
                    },
                    [12] = 
                    {
                        ["price"] = 6800,
                        ["guild"] = 1,
                        ["buyer"] = 746,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633055152,
                        ["quant"] = 200,
                        ["id"] = "1690655661",
                        ["itemLink"] = 180,
                    },
                    [13] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 746,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633055154,
                        ["quant"] = 200,
                        ["id"] = "1690655695",
                        ["itemLink"] = 180,
                    },
                    [14] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 746,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633055155,
                        ["quant"] = 200,
                        ["id"] = "1690655721",
                        ["itemLink"] = 180,
                    },
                    [15] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 746,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633055156,
                        ["quant"] = 200,
                        ["id"] = "1690655729",
                        ["itemLink"] = 180,
                    },
                    [16] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 746,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633055157,
                        ["quant"] = 200,
                        ["id"] = "1690655745",
                        ["itemLink"] = 180,
                    },
                    [17] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 746,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633055158,
                        ["quant"] = 200,
                        ["id"] = "1690655753",
                        ["itemLink"] = 180,
                    },
                    [18] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 746,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633055165,
                        ["quant"] = 200,
                        ["id"] = "1690655823",
                        ["itemLink"] = 180,
                    },
                    [19] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 746,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633055165,
                        ["quant"] = 200,
                        ["id"] = "1690655831",
                        ["itemLink"] = 180,
                    },
                    [20] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 746,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633055166,
                        ["quant"] = 200,
                        ["id"] = "1690655833",
                        ["itemLink"] = 180,
                    },
                    [21] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 746,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633055166,
                        ["quant"] = 200,
                        ["id"] = "1690655837",
                        ["itemLink"] = 180,
                    },
                    [22] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 746,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633055167,
                        ["quant"] = 200,
                        ["id"] = "1690655845",
                        ["itemLink"] = 180,
                    },
                    [23] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 910,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633088113,
                        ["quant"] = 200,
                        ["id"] = "1690876735",
                        ["itemLink"] = 180,
                    },
                    [24] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 910,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633088114,
                        ["quant"] = 200,
                        ["id"] = "1690876741",
                        ["itemLink"] = 180,
                    },
                    [25] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 910,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633088115,
                        ["quant"] = 200,
                        ["id"] = "1690876751",
                        ["itemLink"] = 180,
                    },
                    [26] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 910,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633088115,
                        ["quant"] = 200,
                        ["id"] = "1690876759",
                        ["itemLink"] = 180,
                    },
                    [27] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 915,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633089337,
                        ["quant"] = 200,
                        ["id"] = "1690885385",
                        ["itemLink"] = 180,
                    },
                    [28] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 915,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633089338,
                        ["quant"] = 200,
                        ["id"] = "1690885397",
                        ["itemLink"] = 180,
                    },
                    [29] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 915,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633089341,
                        ["quant"] = 200,
                        ["id"] = "1690885409",
                        ["itemLink"] = 180,
                    },
                    [30] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 953,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633102000,
                        ["quant"] = 200,
                        ["id"] = "1690972763",
                        ["itemLink"] = 180,
                    },
                    [31] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 953,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633102001,
                        ["quant"] = 200,
                        ["id"] = "1690972765",
                        ["itemLink"] = 180,
                    },
                    [32] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 953,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633102002,
                        ["quant"] = 200,
                        ["id"] = "1690972769",
                        ["itemLink"] = 180,
                    },
                    [33] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 953,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633102002,
                        ["quant"] = 200,
                        ["id"] = "1690972771",
                        ["itemLink"] = 180,
                    },
                    [34] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 953,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633102003,
                        ["quant"] = 200,
                        ["id"] = "1690972777",
                        ["itemLink"] = 180,
                    },
                    [35] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 953,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633102004,
                        ["quant"] = 200,
                        ["id"] = "1690972781",
                        ["itemLink"] = 180,
                    },
                    [36] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 953,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633102006,
                        ["quant"] = 200,
                        ["id"] = "1690972791",
                        ["itemLink"] = 180,
                    },
                    [37] = 
                    {
                        ["price"] = 7900,
                        ["guild"] = 1,
                        ["buyer"] = 1253,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633149834,
                        ["quant"] = 200,
                        ["id"] = "1691389329",
                        ["itemLink"] = 180,
                    },
                    [38] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1631,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633223822,
                        ["quant"] = 200,
                        ["id"] = "1692052713",
                        ["itemLink"] = 180,
                    },
                    [39] = 
                    {
                        ["price"] = 8099,
                        ["guild"] = 1,
                        ["buyer"] = 1690,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633230324,
                        ["quant"] = 200,
                        ["id"] = "1692117869",
                        ["itemLink"] = 180,
                    },
                    [40] = 
                    {
                        ["price"] = 8099,
                        ["guild"] = 1,
                        ["buyer"] = 1690,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633230325,
                        ["quant"] = 200,
                        ["id"] = "1692117877",
                        ["itemLink"] = 180,
                    },
                    [41] = 
                    {
                        ["price"] = 8099,
                        ["guild"] = 1,
                        ["buyer"] = 1690,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633230326,
                        ["quant"] = 200,
                        ["id"] = "1692117885",
                        ["itemLink"] = 180,
                    },
                    [42] = 
                    {
                        ["price"] = 8099,
                        ["guild"] = 1,
                        ["buyer"] = 1690,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633230327,
                        ["quant"] = 200,
                        ["id"] = "1692117897",
                        ["itemLink"] = 180,
                    },
                    [43] = 
                    {
                        ["price"] = 8138,
                        ["guild"] = 1,
                        ["buyer"] = 1690,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633230328,
                        ["quant"] = 200,
                        ["id"] = "1692117917",
                        ["itemLink"] = 180,
                    },
                    [44] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1766,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633240191,
                        ["quant"] = 200,
                        ["id"] = "1692198529",
                        ["itemLink"] = 180,
                    },
                    [45] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1766,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633240192,
                        ["quant"] = 200,
                        ["id"] = "1692198543",
                        ["itemLink"] = 180,
                    },
                    [46] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1766,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633240194,
                        ["quant"] = 200,
                        ["id"] = "1692198567",
                        ["itemLink"] = 180,
                    },
                    [47] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1766,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633240195,
                        ["quant"] = 200,
                        ["id"] = "1692198583",
                        ["itemLink"] = 180,
                    },
                    [48] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1766,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633240196,
                        ["quant"] = 200,
                        ["id"] = "1692198607",
                        ["itemLink"] = 180,
                    },
                    [49] = 
                    {
                        ["price"] = 8099,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633271514,
                        ["quant"] = 200,
                        ["id"] = "1692421023",
                        ["itemLink"] = 180,
                    },
                    [50] = 
                    {
                        ["price"] = 8099,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633271515,
                        ["quant"] = 200,
                        ["id"] = "1692421027",
                        ["itemLink"] = 180,
                    },
                    [51] = 
                    {
                        ["price"] = 8099,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633271515,
                        ["quant"] = 200,
                        ["id"] = "1692421039",
                        ["itemLink"] = 180,
                    },
                    [52] = 
                    {
                        ["price"] = 8099,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633271516,
                        ["quant"] = 200,
                        ["id"] = "1692421051",
                        ["itemLink"] = 180,
                    },
                    [53] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1633271517,
                        ["quant"] = 200,
                        ["id"] = "1692421059",
                        ["itemLink"] = 180,
                    },
                    [54] = 
                    {
                        ["price"] = 8600,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1633271518,
                        ["quant"] = 200,
                        ["id"] = "1692421065",
                        ["itemLink"] = 180,
                    },
                    [55] = 
                    {
                        ["price"] = 9200,
                        ["guild"] = 1,
                        ["buyer"] = 1880,
                        ["wasKiosk"] = true,
                        ["seller"] = 803,
                        ["timestamp"] = 1633271518,
                        ["quant"] = 200,
                        ["id"] = "1692421077",
                        ["itemLink"] = 180,
                    },
                    [56] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 2183,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1632841474,
                        ["quant"] = 200,
                        ["id"] = "1689071235",
                        ["itemLink"] = 180,
                    },
                    [57] = 
                    {
                        ["price"] = 7242,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 1145,
                        ["timestamp"] = 1632892801,
                        ["quant"] = 200,
                        ["id"] = "1689514651",
                        ["itemLink"] = 180,
                    },
                    [58] = 
                    {
                        ["price"] = 7242,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 1145,
                        ["timestamp"] = 1632892802,
                        ["quant"] = 200,
                        ["id"] = "1689514657",
                        ["itemLink"] = 180,
                    },
                    [59] = 
                    {
                        ["price"] = 7242,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 1145,
                        ["timestamp"] = 1632892802,
                        ["quant"] = 200,
                        ["id"] = "1689514661",
                        ["itemLink"] = 180,
                    },
                    [60] = 
                    {
                        ["price"] = 7242,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 1145,
                        ["timestamp"] = 1632892803,
                        ["quant"] = 200,
                        ["id"] = "1689514669",
                        ["itemLink"] = 180,
                    },
                    [61] = 
                    {
                        ["price"] = 7242,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 1145,
                        ["timestamp"] = 1632892803,
                        ["quant"] = 200,
                        ["id"] = "1689514677",
                        ["itemLink"] = 180,
                    },
                    [62] = 
                    {
                        ["price"] = 7242,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 1145,
                        ["timestamp"] = 1632892804,
                        ["quant"] = 200,
                        ["id"] = "1689514683",
                        ["itemLink"] = 180,
                    },
                    [63] = 
                    {
                        ["price"] = 7242,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 1145,
                        ["timestamp"] = 1632892804,
                        ["quant"] = 200,
                        ["id"] = "1689514689",
                        ["itemLink"] = 180,
                    },
                    [64] = 
                    {
                        ["price"] = 7242,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 1145,
                        ["timestamp"] = 1632892805,
                        ["quant"] = 200,
                        ["id"] = "1689514693",
                        ["itemLink"] = 180,
                    },
                    [65] = 
                    {
                        ["price"] = 7242,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 1145,
                        ["timestamp"] = 1632892805,
                        ["quant"] = 200,
                        ["id"] = "1689514699",
                        ["itemLink"] = 180,
                    },
                    [66] = 
                    {
                        ["price"] = 7200,
                        ["guild"] = 1,
                        ["buyer"] = 2464,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632911791,
                        ["quant"] = 200,
                        ["id"] = "1689607675",
                        ["itemLink"] = 180,
                    },
                    [67] = 
                    {
                        ["price"] = 7200,
                        ["guild"] = 1,
                        ["buyer"] = 2464,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632911793,
                        ["quant"] = 200,
                        ["id"] = "1689607681",
                        ["itemLink"] = 180,
                    },
                    [68] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 2464,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1632911800,
                        ["quant"] = 200,
                        ["id"] = "1689607697",
                        ["itemLink"] = 180,
                    },
                    [69] = 
                    {
                        ["price"] = 7900,
                        ["guild"] = 1,
                        ["buyer"] = 2506,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632927316,
                        ["quant"] = 200,
                        ["id"] = "1689702799",
                        ["itemLink"] = 180,
                    },
                    [70] = 
                    {
                        ["price"] = 7900,
                        ["guild"] = 1,
                        ["buyer"] = 2506,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632927317,
                        ["quant"] = 200,
                        ["id"] = "1689702803",
                        ["itemLink"] = 180,
                    },
                    [71] = 
                    {
                        ["price"] = 7900,
                        ["guild"] = 1,
                        ["buyer"] = 2506,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632927318,
                        ["quant"] = 200,
                        ["id"] = "1689702807",
                        ["itemLink"] = 180,
                    },
                    [72] = 
                    {
                        ["price"] = 7900,
                        ["guild"] = 1,
                        ["buyer"] = 2506,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632927320,
                        ["quant"] = 200,
                        ["id"] = "1689702811",
                        ["itemLink"] = 180,
                    },
                    [73] = 
                    {
                        ["price"] = 7900,
                        ["guild"] = 1,
                        ["buyer"] = 2506,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632927321,
                        ["quant"] = 200,
                        ["id"] = "1689702821",
                        ["itemLink"] = 180,
                    },
                    [74] = 
                    {
                        ["price"] = 7900,
                        ["guild"] = 1,
                        ["buyer"] = 2506,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632927322,
                        ["quant"] = 200,
                        ["id"] = "1689702825",
                        ["itemLink"] = 180,
                    },
                    [75] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 2572,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632947255,
                        ["quant"] = 200,
                        ["id"] = "1689852971",
                        ["itemLink"] = 180,
                    },
                    [76] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 2572,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632947263,
                        ["quant"] = 200,
                        ["id"] = "1689853063",
                        ["itemLink"] = 180,
                    },
                    [77] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 156,
                        ["wasKiosk"] = false,
                        ["seller"] = 35,
                        ["timestamp"] = 1632950292,
                        ["quant"] = 200,
                        ["id"] = "1689876705",
                        ["itemLink"] = 180,
                    },
                    [78] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 2595,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1632952420,
                        ["quant"] = 100,
                        ["id"] = "1689896001",
                        ["itemLink"] = 180,
                    },
                    [79] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2595,
                        ["wasKiosk"] = true,
                        ["seller"] = 168,
                        ["timestamp"] = 1632952421,
                        ["quant"] = 200,
                        ["id"] = "1689896029",
                        ["itemLink"] = 180,
                    },
                    [80] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2595,
                        ["wasKiosk"] = true,
                        ["seller"] = 168,
                        ["timestamp"] = 1632952422,
                        ["quant"] = 200,
                        ["id"] = "1689896051",
                        ["itemLink"] = 180,
                    },
                    [81] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2595,
                        ["wasKiosk"] = true,
                        ["seller"] = 168,
                        ["timestamp"] = 1632952424,
                        ["quant"] = 200,
                        ["id"] = "1689896081",
                        ["itemLink"] = 180,
                    },
                },
                ["totalCount"] = 81,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
    },
}
