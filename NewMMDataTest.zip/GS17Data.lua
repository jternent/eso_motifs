GS17DataSavedVariables =
{
    ["posteditemsna"] = 
    {
    },
    ["cancelleditemsna"] = 
    {
    },
    ["cancelleditemseu"] = 
    {
    },
    ["namefiltereu"] = 
    {
    },
    ["pricingdataeu"] = 
    {
        ["pricingdataall"] = 
        {
        },
    },
    ["purchaseeu"] = 
    {
    },
    ["purchasena"] = 
    {
    },
    ["pricingdatana"] = 
    {
        ["pricingdataall"] = 
        {
        },
    },
    ["visitedNATraders"] = 
    {
    },
    ["posteditemseu"] = 
    {
    },
    ["namefilterna"] = 
    {
    },
    ["visitedEUTraders"] = 
    {
    },
}
