GS14DataSavedVariables =
{
    ["listingseu"] = 
    {
    },
    ["listingsna"] = 
    {
    },
    ["dataeu"] = 
    {
    },
    ["datana"] = 
    {
        [7680] = 
        {
            ["50:16:2:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_1haxe_d.dds",
                ["itemDesc"] = "Frostwind Axe",
                ["oldestTime"] = 1633273217,
                ["wasAltered"] = true,
                ["newestTime"] = 1633273217,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 484,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1633273217,
                        ["quant"] = 1,
                        ["id"] = "1692439895",
                        ["itemLink"] = 2683,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set fiord's legacy axe one-handed charged",
            },
        },
        [180481] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_staff_a.dds",
                ["itemDesc"] = "Lightning Staff of Dark Convergence",
                ["oldestTime"] = 1633313767,
                ["wasAltered"] = true,
                ["newestTime"] = 1633313767,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3333,
                        ["guild"] = 1,
                        ["buyer"] = 64,
                        ["wasKiosk"] = true,
                        ["seller"] = 19,
                        ["timestamp"] = 1633313767,
                        ["quant"] = 1,
                        ["id"] = "1692888457",
                        ["itemLink"] = 45,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set dark convergence lightning staff two-handed precise",
            },
        },
        [149253] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_pellitine_staff_a.dds",
                ["itemDesc"] = "Crafty Alfiq's Restoration Staff",
                ["oldestTime"] = 1633043554,
                ["wasAltered"] = true,
                ["newestTime"] = 1633043554,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 659,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1633043554,
                        ["quant"] = 1,
                        ["id"] = "1690541971",
                        ["itemLink"] = 837,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set crafty alfiq healing staff two-handed infused",
            },
        },
        [57607] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 20: Yokudan Belts",
                ["oldestTime"] = 1632873840,
                ["wasAltered"] = true,
                ["newestTime"] = 1632970665,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10500,
                        ["guild"] = 1,
                        ["buyer"] = 149,
                        ["wasKiosk"] = false,
                        ["seller"] = 35,
                        ["timestamp"] = 1632970665,
                        ["quant"] = 1,
                        ["id"] = "1690062979",
                        ["itemLink"] = 183,
                    },
                    [2] = 
                    {
                        ["price"] = 15162,
                        ["guild"] = 1,
                        ["buyer"] = 2313,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1632873840,
                        ["quant"] = 1,
                        ["id"] = "1689329195",
                        ["itemLink"] = 183,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [133128] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nocturnal_bow_a.dds",
                ["itemDesc"] = "Bow of Unfathomable Darkness",
                ["oldestTime"] = 1633202455,
                ["wasAltered"] = true,
                ["newestTime"] = 1633202455,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1501,
                        ["wasKiosk"] = true,
                        ["seller"] = 161,
                        ["timestamp"] = 1633202455,
                        ["quant"] = 1,
                        ["id"] = "1691816151",
                        ["itemLink"] = 2219,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set unfathomable darkness bow two-handed sharpened",
            },
        },
        [177161] = 
        {
            ["1:0:3:51:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_gloves_light.dds",
                ["itemDesc"] = "Companion's Gloves",
                ["oldestTime"] = 1633136721,
                ["wasAltered"] = true,
                ["newestTime"] = 1633136721,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50,
                        ["guild"] = 1,
                        ["buyer"] = 1156,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633136721,
                        ["quant"] = 1,
                        ["id"] = "1691260045",
                        ["itemLink"] = 1572,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior light apparel hands vigorous",
            },
        },
        [96010] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Trainee",
                ["oldestTime"] = 1632983522,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163918,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 298,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632983522,
                        ["quant"] = 1,
                        ["id"] = "1690150965",
                        ["itemLink"] = 303,
                    },
                    [2] = 
                    {
                        ["price"] = 1550,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 92,
                        ["timestamp"] = 1633163918,
                        ["quant"] = 1,
                        ["id"] = "1691490361",
                        ["itemLink"] = 1816,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set armor of the trainee ring arcane",
            },
        },
        [130059] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_hlaalu_r2.dds",
                ["itemDesc"] = "Refined Bonemold Resin",
                ["oldestTime"] = 1632954579,
                ["wasAltered"] = true,
                ["newestTime"] = 1633231764,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633231764,
                        ["quant"] = 1,
                        ["id"] = "1692133113",
                        ["itemLink"] = 2443,
                    },
                    [2] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 643,
                        ["wasKiosk"] = false,
                        ["seller"] = 966,
                        ["timestamp"] = 1632954579,
                        ["quant"] = 2,
                        ["id"] = "1689915103",
                        ["itemLink"] = 2443,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [167948] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 95: Nighthollow Chests",
                ["oldestTime"] = 1633118569,
                ["wasAltered"] = true,
                ["newestTime"] = 1633118569,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 1038,
                        ["wasKiosk"] = true,
                        ["seller"] = 505,
                        ["timestamp"] = 1633118569,
                        ["quant"] = 1,
                        ["id"] = "1691095851",
                        ["itemLink"] = 1424,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [100622] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_medium_chest_d.dds",
                ["itemDesc"] = "Spriggan's Jack",
                ["oldestTime"] = 1633131225,
                ["wasAltered"] = true,
                ["newestTime"] = 1633131225,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 1109,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633131225,
                        ["quant"] = 1,
                        ["id"] = "1691199681",
                        ["itemLink"] = 1514,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set spriggan's thorns chest divines",
            },
        },
        [125969] = 
        {
            ["50:16:4:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_medium_feet_a.dds",
                ["itemDesc"] = "Impregnable Armor Boots",
                ["oldestTime"] = 1633021925,
                ["wasAltered"] = true,
                ["newestTime"] = 1633021925,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 8,
                        ["wasKiosk"] = false,
                        ["seller"] = 506,
                        ["timestamp"] = 1633021925,
                        ["quant"] = 1,
                        ["id"] = "1690383249",
                        ["itemLink"] = 588,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set impregnable armor feet training",
            },
        },
        [34324] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_carrots.dds",
                ["itemDesc"] = "Carrots",
                ["oldestTime"] = 1633042301,
                ["wasAltered"] = true,
                ["newestTime"] = 1633042301,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 648,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633042301,
                        ["quant"] = 200,
                        ["id"] = "1690531063",
                        ["itemLink"] = 821,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [45336] = 
        {
            ["50:16:1:10:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_2haxe_d.dds",
                ["itemDesc"] = "Rubedite Battle Axe",
                ["oldestTime"] = 1633185934,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185936,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 564,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 528,
                        ["timestamp"] = 1633185934,
                        ["quant"] = 1,
                        ["id"] = "1691640037",
                        ["itemLink"] = 2022,
                    },
                    [2] = 
                    {
                        ["price"] = 564,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 528,
                        ["timestamp"] = 1633185936,
                        ["quant"] = 1,
                        ["id"] = "1691640071",
                        ["itemLink"] = 2023,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 white normal weapon axe two-handed ornate",
            },
        },
        [181529] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_waf_housingleywallmedgate001.dds",
                ["itemDesc"] = "Leyawiin Archway, Garden",
                ["oldestTime"] = 1633284631,
                ["wasAltered"] = true,
                ["newestTime"] = 1633284632,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 27712,
                        ["guild"] = 1,
                        ["buyer"] = 1949,
                        ["wasKiosk"] = true,
                        ["seller"] = 312,
                        ["timestamp"] = 1633284631,
                        ["quant"] = 1,
                        ["id"] = "1692562875",
                        ["itemLink"] = 2751,
                    },
                    [2] = 
                    {
                        ["price"] = 27712,
                        ["guild"] = 1,
                        ["buyer"] = 1949,
                        ["wasKiosk"] = true,
                        ["seller"] = 312,
                        ["timestamp"] = 1633284632,
                        ["quant"] = 1,
                        ["id"] = "1692562877",
                        ["itemLink"] = 2751,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior furnishings structures",
            },
        },
        [147738] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 75: Sunspire Helmets",
                ["oldestTime"] = 1632876027,
                ["wasAltered"] = true,
                ["newestTime"] = 1633313393,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15039,
                        ["guild"] = 1,
                        ["buyer"] = 53,
                        ["wasKiosk"] = true,
                        ["seller"] = 54,
                        ["timestamp"] = 1633313393,
                        ["quant"] = 1,
                        ["id"] = "1692883941",
                        ["itemLink"] = 38,
                    },
                    [2] = 
                    {
                        ["price"] = 3999,
                        ["guild"] = 1,
                        ["buyer"] = 25,
                        ["wasKiosk"] = true,
                        ["seller"] = 417,
                        ["timestamp"] = 1633008238,
                        ["quant"] = 3,
                        ["id"] = "1690277809",
                        ["itemLink"] = 38,
                    },
                    [3] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 2328,
                        ["wasKiosk"] = true,
                        ["seller"] = 712,
                        ["timestamp"] = 1632876027,
                        ["quant"] = 1,
                        ["id"] = "1689352201",
                        ["itemLink"] = 38,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [149531] = 
        {
            ["50:16:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_medium_shoulder_a.dds",
                ["itemDesc"] = "Darloc Brae's Arm Cops",
                ["oldestTime"] = 1633121398,
                ["wasAltered"] = true,
                ["newestTime"] = 1633121398,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1700,
                        ["guild"] = 1,
                        ["buyer"] = 1053,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633121398,
                        ["quant"] = 1,
                        ["id"] = "1691114793",
                        ["itemLink"] = 1436,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set vesture of darloc brae shoulders impenetrable",
            },
        },
        [45340] = 
        {
            ["1:0:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ashlanderv_heavy_chest_a.dds",
                ["itemDesc"] = "Iron Cuirass",
                ["oldestTime"] = 1633072302,
                ["wasAltered"] = true,
                ["newestTime"] = 1633072302,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 140,
                        ["guild"] = 1,
                        ["buyer"] = 850,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633072302,
                        ["quant"] = 1,
                        ["id"] = "1690793397",
                        ["itemLink"] = 1096,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal heavy apparel chest intricate",
            },
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_heavy_chest_d.dds",
                ["itemDesc"] = "Rubedite Cuirass",
                ["oldestTime"] = 1632889278,
                ["wasAltered"] = true,
                ["newestTime"] = 1633244683,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 180,
                        ["guild"] = 1,
                        ["buyer"] = 850,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633072303,
                        ["quant"] = 1,
                        ["id"] = "1690793415",
                        ["itemLink"] = 1097,
                    },
                    [2] = 
                    {
                        ["price"] = 284,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633084075,
                        ["quant"] = 1,
                        ["id"] = "1690854875",
                        ["itemLink"] = 1174,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633084102,
                        ["quant"] = 1,
                        ["id"] = "1690855025",
                        ["itemLink"] = 1185,
                    },
                    [4] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1055,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633121632,
                        ["quant"] = 1,
                        ["id"] = "1691116737",
                        ["itemLink"] = 1185,
                    },
                    [5] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633185986,
                        ["quant"] = 1,
                        ["id"] = "1691640571",
                        ["itemLink"] = 1097,
                    },
                    [6] = 
                    {
                        ["price"] = 330,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 1004,
                        ["timestamp"] = 1633244683,
                        ["quant"] = 1,
                        ["id"] = "1692231387",
                        ["itemLink"] = 1185,
                    },
                    [7] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2408,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1632889278,
                        ["quant"] = 1,
                        ["id"] = "1689487539",
                        ["itemLink"] = 3531,
                    },
                    [8] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2431,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632895316,
                        ["quant"] = 1,
                        ["id"] = "1689531181",
                        ["itemLink"] = 3558,
                    },
                    [9] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2660,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632966355,
                        ["quant"] = 1,
                        ["id"] = "1690018453",
                        ["itemLink"] = 3965,
                    },
                },
                ["totalCount"] = 9,
                ["itemAdderText"] = "cp160 white normal heavy apparel chest intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_heavy_chest_d.dds",
                ["itemDesc"] = "Rubedite Cuirass",
                ["oldestTime"] = 1632885624,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186020,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009365,
                        ["quant"] = 1,
                        ["id"] = "1690285435",
                        ["itemLink"] = 479,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084687,
                        ["quant"] = 1,
                        ["id"] = "1690857401",
                        ["itemLink"] = 1212,
                    },
                    [3] = 
                    {
                        ["price"] = 320,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633186003,
                        ["quant"] = 1,
                        ["id"] = "1691640661",
                        ["itemLink"] = 2054,
                    },
                    [4] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633186020,
                        ["quant"] = 1,
                        ["id"] = "1691640863",
                        ["itemLink"] = 2062,
                    },
                    [5] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632885624,
                        ["quant"] = 1,
                        ["id"] = "1689459325",
                        ["itemLink"] = 3506,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "cp150 white normal heavy apparel chest intricate",
            },
        },
        [147744] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 75: Sunspire Swords",
                ["oldestTime"] = 1633004181,
                ["wasAltered"] = true,
                ["newestTime"] = 1633004181,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3999,
                        ["guild"] = 1,
                        ["buyer"] = 416,
                        ["wasKiosk"] = true,
                        ["seller"] = 417,
                        ["timestamp"] = 1633004181,
                        ["quant"] = 2,
                        ["id"] = "1690255015",
                        ["itemLink"] = 424,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [156195] = 
        {
            ["50:16:3:31:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "New Moon Acolyte's Ring",
                ["oldestTime"] = 1632849197,
                ["wasAltered"] = true,
                ["newestTime"] = 1633115885,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 57499,
                        ["guild"] = 1,
                        ["buyer"] = 1021,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633115885,
                        ["quant"] = 1,
                        ["id"] = "1691077731",
                        ["itemLink"] = 1398,
                    },
                    [2] = 
                    {
                        ["price"] = 57499,
                        ["guild"] = 1,
                        ["buyer"] = 2209,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632849197,
                        ["quant"] = 1,
                        ["id"] = "1689137783",
                        ["itemLink"] = 1398,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set new moon acolyte ring bloodthirsty",
            },
        },
        [180776] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_staff_a.dds",
                ["itemDesc"] = "Hrothgar's Ice Staff",
                ["oldestTime"] = 1633052765,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112142,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3333,
                        ["guild"] = 1,
                        ["buyer"] = 718,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633052765,
                        ["quant"] = 1,
                        ["id"] = "1690632835",
                        ["itemLink"] = 912,
                    },
                    [2] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 991,
                        ["wasKiosk"] = true,
                        ["seller"] = 510,
                        ["timestamp"] = 1633112142,
                        ["quant"] = 1,
                        ["id"] = "1691053367",
                        ["itemLink"] = 912,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior weapon set hrothgar's chill frost staff two-handed infused",
            },
        },
        [167721] = 
        {
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nighthollowreg_lgt_shoulders_a.dds",
                ["itemDesc"] = "Epaulets of the Voidcaller",
                ["oldestTime"] = 1633082831,
                ["wasAltered"] = true,
                ["newestTime"] = 1633082831,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 887,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633082831,
                        ["quant"] = 1,
                        ["id"] = "1690849391",
                        ["itemLink"] = 1137,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set voidcaller shoulders invigorating",
            },
        },
        [45354] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_light_waist_d.dds",
                ["itemDesc"] = "Ancestor Silk Sash",
                ["oldestTime"] = 1632841094,
                ["wasAltered"] = true,
                ["newestTime"] = 1633236162,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633084072,
                        ["quant"] = 1,
                        ["id"] = "1690854843",
                        ["itemLink"] = 1171,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084093,
                        ["quant"] = 1,
                        ["id"] = "1690854991",
                        ["itemLink"] = 1180,
                    },
                    [3] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 539,
                        ["timestamp"] = 1633084111,
                        ["quant"] = 1,
                        ["id"] = "1690855077",
                        ["itemLink"] = 1189,
                    },
                    [4] = 
                    {
                        ["price"] = 180,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633146941,
                        ["quant"] = 1,
                        ["id"] = "1691365415",
                        ["itemLink"] = 1674,
                    },
                    [5] = 
                    {
                        ["price"] = 198,
                        ["guild"] = 1,
                        ["buyer"] = 1734,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1633236162,
                        ["quant"] = 1,
                        ["id"] = "1692168719",
                        ["itemLink"] = 2492,
                    },
                    [6] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632841094,
                        ["quant"] = 1,
                        ["id"] = "1689067921",
                        ["itemLink"] = 2492,
                    },
                    [7] = 
                    {
                        ["price"] = 158,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632841098,
                        ["quant"] = 1,
                        ["id"] = "1689067967",
                        ["itemLink"] = 1180,
                    },
                    [8] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632843185,
                        ["quant"] = 1,
                        ["id"] = "1689085279",
                        ["itemLink"] = 3178,
                    },
                    [9] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632843190,
                        ["quant"] = 1,
                        ["id"] = "1689085325",
                        ["itemLink"] = 3179,
                    },
                    [10] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632843201,
                        ["quant"] = 1,
                        ["id"] = "1689085371",
                        ["itemLink"] = 2492,
                    },
                    [11] = 
                    {
                        ["price"] = 198,
                        ["guild"] = 1,
                        ["buyer"] = 2319,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1632874549,
                        ["quant"] = 1,
                        ["id"] = "1689336601",
                        ["itemLink"] = 3407,
                    },
                    [12] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1004,
                        ["timestamp"] = 1632956415,
                        ["quant"] = 1,
                        ["id"] = "1689931781",
                        ["itemLink"] = 2492,
                    },
                },
                ["totalCount"] = 12,
                ["itemAdderText"] = "cp160 white normal light apparel waist intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_waist_d.dds",
                ["itemDesc"] = "Ancestor Silk Sash",
                ["oldestTime"] = 1632913790,
                ["wasAltered"] = true,
                ["newestTime"] = 1632913790,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 194,
                        ["guild"] = 1,
                        ["buyer"] = 2202,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632913790,
                        ["quant"] = 1,
                        ["id"] = "1689616121",
                        ["itemLink"] = 3632,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 white normal light apparel waist intricate",
            },
            ["1:0:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_light_waist_a.dds",
                ["itemDesc"] = "Homespun Sash",
                ["oldestTime"] = 1633022925,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022925,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 110,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633022925,
                        ["quant"] = 1,
                        ["id"] = "1690390205",
                        ["itemLink"] = 597,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal light apparel waist intricate",
            },
            ["50:14:2:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_light_waist_d.dds",
                ["itemDesc"] = "Shadowspun Sash",
                ["oldestTime"] = 1633236175,
                ["wasAltered"] = true,
                ["newestTime"] = 1633236175,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1734,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633236175,
                        ["quant"] = 1,
                        ["id"] = "1692168849",
                        ["itemLink"] = 2495,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp140 green fine light apparel waist intricate",
            },
        },
        [156715] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Southern Elsweyr Treasure Map II",
                ["oldestTime"] = 1633149346,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310236,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1250,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633149346,
                        ["quant"] = 1,
                        ["id"] = "1691385279",
                        ["itemLink"] = 1705,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1250,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633149355,
                        ["quant"] = 1,
                        ["id"] = "1691385403",
                        ["itemLink"] = 1705,
                    },
                    [3] = 
                    {
                        ["price"] = 379,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182519,
                        ["quant"] = 1,
                        ["id"] = "1691608207",
                        ["itemLink"] = 1705,
                    },
                    [4] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633310235,
                        ["quant"] = 1,
                        ["id"] = "1692851347",
                        ["itemLink"] = 1705,
                    },
                    [5] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633310236,
                        ["quant"] = 1,
                        ["id"] = "1692851351",
                        ["itemLink"] = 1705,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [166701] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_cartographers_coat.dds",
                ["itemDesc"] = "Cartographer's Vest",
                ["oldestTime"] = 1632897637,
                ["wasAltered"] = true,
                ["newestTime"] = 1632897637,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 69999,
                        ["guild"] = 1,
                        ["buyer"] = 2439,
                        ["wasKiosk"] = true,
                        ["seller"] = 290,
                        ["timestamp"] = 1632897637,
                        ["quant"] = 1,
                        ["id"] = "1689546863",
                        ["itemLink"] = 3567,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [151854] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_els_zebraplantcluster001.dds",
                ["itemDesc"] = "Cactus, Banded Lunar Multihued Trio",
                ["oldestTime"] = 1632869569,
                ["wasAltered"] = true,
                ["newestTime"] = 1632869569,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 2283,
                        ["wasKiosk"] = true,
                        ["seller"] = 569,
                        ["timestamp"] = 1632869569,
                        ["quant"] = 1,
                        ["id"] = "1689300215",
                        ["itemLink"] = 3380,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings conservatory",
            },
        },
        [172336] = 
        {
            ["50:16:2:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_staff_a.dds",
                ["itemDesc"] = "Bog Raider's Inferno Staff",
                ["oldestTime"] = 1633313159,
                ["wasAltered"] = true,
                ["newestTime"] = 1633313159,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 49,
                        ["wasKiosk"] = true,
                        ["seller"] = 50,
                        ["timestamp"] = 1633313159,
                        ["quant"] = 1,
                        ["id"] = "1692881681",
                        ["itemLink"] = 35,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set bog raider flame staff two-handed precise",
            },
        },
        [135221] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nocturnal_heavy_legs_a.dds",
                ["itemDesc"] = "Gloom-Graced Greaves",
                ["oldestTime"] = 1632886506,
                ["wasAltered"] = true,
                ["newestTime"] = 1632886506,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1750,
                        ["guild"] = 1,
                        ["buyer"] = 2395,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632886506,
                        ["quant"] = 1,
                        ["id"] = "1689466715",
                        ["itemLink"] = 3522,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set grace of gloom legs well-fitted",
            },
        },
        [69432] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/notes_004.dds",
                ["itemDesc"] = "Glass Style Motif Fragment",
                ["oldestTime"] = 1633203200,
                ["wasAltered"] = true,
                ["newestTime"] = 1633203200,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9600,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 802,
                        ["timestamp"] = 1633203200,
                        ["quant"] = 32,
                        ["id"] = "1691824907",
                        ["itemLink"] = 2226,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [180795] = 
        {
            ["50:16:3:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_staff_a.dds",
                ["itemDesc"] = "Hrothgar's Inferno Staff",
                ["oldestTime"] = 1633112457,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112457,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 991,
                        ["wasKiosk"] = true,
                        ["seller"] = 510,
                        ["timestamp"] = 1633112457,
                        ["quant"] = 1,
                        ["id"] = "1691055363",
                        ["itemLink"] = 1352,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set hrothgar's chill flame staff two-handed powered",
            },
        },
        [175932] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Leyawiin Bed, Sturdy Single",
                ["oldestTime"] = 1632867268,
                ["wasAltered"] = true,
                ["newestTime"] = 1632867268,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 2274,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1632867268,
                        ["quant"] = 1,
                        ["id"] = "1689283087",
                        ["itemLink"] = 3362,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [71742] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_daggerfall_covenant.dds",
                ["itemDesc"] = "Lion Fang",
                ["oldestTime"] = 1632861555,
                ["wasAltered"] = true,
                ["newestTime"] = 1632861555,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1632861555,
                        ["quant"] = 1,
                        ["id"] = "1689241483",
                        ["itemLink"] = 3302,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [97091] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_feet_d.dds",
                ["itemDesc"] = "Plague Doctor's Sabatons",
                ["oldestTime"] = 1633228142,
                ["wasAltered"] = true,
                ["newestTime"] = 1633228142,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 1026,
                        ["wasKiosk"] = true,
                        ["seller"] = 697,
                        ["timestamp"] = 1633228142,
                        ["quant"] = 1,
                        ["id"] = "1692098487",
                        ["itemLink"] = 2421,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set plague doctor feet well-fitted",
            },
        },
        [118340] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_gen_exc_stockade001.dds",
                ["itemDesc"] = "Stockade",
                ["oldestTime"] = 1633141882,
                ["wasAltered"] = true,
                ["newestTime"] = 1633141883,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 31888,
                        ["guild"] = 1,
                        ["buyer"] = 1194,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1633141882,
                        ["quant"] = 2,
                        ["id"] = "1691311769",
                        ["itemLink"] = 1616,
                    },
                    [2] = 
                    {
                        ["price"] = 31888,
                        ["guild"] = 1,
                        ["buyer"] = 1194,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1633141883,
                        ["quant"] = 2,
                        ["id"] = "1691311783",
                        ["itemLink"] = 1616,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings undercroft",
            },
        },
        [45893] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Carrot Cheesecake",
                ["oldestTime"] = 1633261596,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261596,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633261596,
                        ["quant"] = 1,
                        ["id"] = "1692334381",
                        ["itemLink"] = 2620,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [176455] = 
        {
            ["1:0:3:55:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_ring.dds",
                ["itemDesc"] = "Companion's Ring",
                ["oldestTime"] = 1632966720,
                ["wasAltered"] = true,
                ["newestTime"] = 1633218781,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3999,
                        ["guild"] = 1,
                        ["buyer"] = 1602,
                        ["wasKiosk"] = true,
                        ["seller"] = 451,
                        ["timestamp"] = 1633218781,
                        ["quant"] = 1,
                        ["id"] = "1691998515",
                        ["itemLink"] = 2333,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2661,
                        ["wasKiosk"] = true,
                        ["seller"] = 100,
                        ["timestamp"] = 1632966720,
                        ["quant"] = 1,
                        ["id"] = "1690021181",
                        ["itemLink"] = 2333,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior jewelry apparel ring shattering",
            },
        },
        [181577] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Wall, Wainscoted",
                ["oldestTime"] = 1633109564,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291971,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 44000,
                        ["guild"] = 1,
                        ["buyer"] = 980,
                        ["wasKiosk"] = true,
                        ["seller"] = 981,
                        ["timestamp"] = 1633109564,
                        ["quant"] = 1,
                        ["id"] = "1691032951",
                        ["itemLink"] = 1320,
                    },
                    [2] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 90,
                        ["wasKiosk"] = false,
                        ["seller"] = 62,
                        ["timestamp"] = 1633291971,
                        ["quant"] = 1,
                        ["id"] = "1692651439",
                        ["itemLink"] = 1320,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [100682] = 
        {
            ["50:16:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_medium_chest_d.dds",
                ["itemDesc"] = "Spriggan's Jack",
                ["oldestTime"] = 1633207239,
                ["wasAltered"] = true,
                ["newestTime"] = 1633207239,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 1534,
                        ["wasKiosk"] = true,
                        ["seller"] = 1535,
                        ["timestamp"] = 1633207239,
                        ["quant"] = 1,
                        ["id"] = "1691870651",
                        ["itemLink"] = 2257,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set spriggan's thorns chest impenetrable",
            },
        },
        [23118] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_wood_base_hickory_r1.dds",
                ["itemDesc"] = "Rough Hickory",
                ["oldestTime"] = 1632983121,
                ["wasAltered"] = true,
                ["newestTime"] = 1633247644,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3150,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632983121,
                        ["quant"] = 105,
                        ["id"] = "1690148373",
                        ["itemLink"] = 300,
                    },
                    [2] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632983122,
                        ["quant"] = 200,
                        ["id"] = "1690148375",
                        ["itemLink"] = 300,
                    },
                    [3] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632983122,
                        ["quant"] = 200,
                        ["id"] = "1690148381",
                        ["itemLink"] = 300,
                    },
                    [4] = 
                    {
                        ["price"] = 2300,
                        ["guild"] = 1,
                        ["buyer"] = 1805,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633247644,
                        ["quant"] = 118,
                        ["id"] = "1692255543",
                        ["itemLink"] = 300,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [127055] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Telvanni Table Runner, Bordered Azure",
                ["oldestTime"] = 1632876562,
                ["wasAltered"] = true,
                ["newestTime"] = 1632876562,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 39000,
                        ["guild"] = 1,
                        ["buyer"] = 144,
                        ["wasKiosk"] = false,
                        ["seller"] = 508,
                        ["timestamp"] = 1632876562,
                        ["quant"] = 1,
                        ["id"] = "1689357559",
                        ["itemLink"] = 3428,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [161107] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_greyhosthvy_belt_a.dds",
                ["itemDesc"] = "Girdle of Eternal Vigor",
                ["oldestTime"] = 1633180918,
                ["wasAltered"] = true,
                ["newestTime"] = 1633180918,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9999,
                        ["guild"] = 1,
                        ["buyer"] = 1368,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633180918,
                        ["quant"] = 1,
                        ["id"] = "1691591827",
                        ["itemLink"] = 1928,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set eternal vigor waist impenetrable",
            },
        },
        [97364] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_shoulders_d.dds",
                ["itemDesc"] = "Epaulets of a Mother's Sorrow",
                ["oldestTime"] = 1632846976,
                ["wasAltered"] = true,
                ["newestTime"] = 1632846976,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 849,
                        ["guild"] = 1,
                        ["buyer"] = 2202,
                        ["wasKiosk"] = true,
                        ["seller"] = 600,
                        ["timestamp"] = 1632846976,
                        ["quant"] = 1,
                        ["id"] = "1689118411",
                        ["itemLink"] = 3204,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set mother's sorrow shoulders sturdy",
            },
        },
        [127061] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Indoril Tapestry, Vivec",
                ["oldestTime"] = 1633234204,
                ["wasAltered"] = true,
                ["newestTime"] = 1633234204,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1720,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633234204,
                        ["quant"] = 1,
                        ["id"] = "1692155411",
                        ["itemLink"] = 2463,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [139608] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Alinor Wall Shrine, Marble",
                ["oldestTime"] = 1632973395,
                ["wasAltered"] = true,
                ["newestTime"] = 1632973395,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 193,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632973395,
                        ["quant"] = 1,
                        ["id"] = "1690085917",
                        ["itemLink"] = 204,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [126041] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_moragtong_1haxe_a.dds",
                ["itemDesc"] = "Veya's Axe of the Defiler",
                ["oldestTime"] = 1633042326,
                ["wasAltered"] = true,
                ["newestTime"] = 1633042326,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 650,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1633042326,
                        ["quant"] = 1,
                        ["id"] = "1690531229",
                        ["itemLink"] = 828,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set defiler axe one-handed infused",
            },
        },
        [160858] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_greyhostmed_hands_a.dds",
                ["itemDesc"] = "Venomous Bracers",
                ["oldestTime"] = 1633160045,
                ["wasAltered"] = true,
                ["newestTime"] = 1633160045,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1890,
                        ["guild"] = 1,
                        ["buyer"] = 1292,
                        ["wasKiosk"] = true,
                        ["seller"] = 1112,
                        ["timestamp"] = 1633160045,
                        ["quant"] = 1,
                        ["id"] = "1691464937",
                        ["itemLink"] = 1787,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set venomous smite hands divines",
            },
        },
        [134491] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing2.dds",
                ["itemDesc"] = "Diagram: Clockwork Crate, Large Closed",
                ["oldestTime"] = 1633109405,
                ["wasAltered"] = true,
                ["newestTime"] = 1633109405,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 979,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633109405,
                        ["quant"] = 1,
                        ["id"] = "1691031763",
                        ["itemLink"] = 1316,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [153693] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_tre_fan_treehenge_tree001.dds",
                ["itemDesc"] = "Tree, Treehenge Green Lady",
                ["oldestTime"] = 1633301838,
                ["wasAltered"] = true,
                ["newestTime"] = 1633301838,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99998,
                        ["guild"] = 1,
                        ["buyer"] = 2049,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633301838,
                        ["quant"] = 1,
                        ["id"] = "1692759459",
                        ["itemLink"] = 2917,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings conservatory",
            },
        },
        [45150] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_medium_legs_d.dds",
                ["itemDesc"] = "Rubedo Leather Guards of Magicka",
                ["oldestTime"] = 1632847696,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023020,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633023009,
                        ["quant"] = 1,
                        ["id"] = "1690390673",
                        ["itemLink"] = 632,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633023020,
                        ["quant"] = 1,
                        ["id"] = "1690390829",
                        ["itemLink"] = 644,
                    },
                    [3] = 
                    {
                        ["price"] = 247,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632847696,
                        ["quant"] = 1,
                        ["id"] = "1689125609",
                        ["itemLink"] = 3221,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 blue superior medium apparel legs well-fitted",
            },
        },
        [116065] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Dark Elf End Table, Angled",
                ["oldestTime"] = 1633040327,
                ["wasAltered"] = true,
                ["newestTime"] = 1633307968,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1145,
                        ["guild"] = 1,
                        ["buyer"] = 623,
                        ["wasKiosk"] = true,
                        ["seller"] = 626,
                        ["timestamp"] = 1633040327,
                        ["quant"] = 1,
                        ["id"] = "1690515729",
                        ["itemLink"] = 794,
                    },
                    [2] = 
                    {
                        ["price"] = 725,
                        ["guild"] = 1,
                        ["buyer"] = 2076,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633307968,
                        ["quant"] = 1,
                        ["id"] = "1692822497",
                        ["itemLink"] = 794,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [68196] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Bravil's Best Beet Risotto",
                ["oldestTime"] = 1633094857,
                ["wasAltered"] = true,
                ["newestTime"] = 1633094857,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20,
                        ["guild"] = 1,
                        ["buyer"] = 924,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633094857,
                        ["quant"] = 1,
                        ["id"] = "1690918167",
                        ["itemLink"] = 1255,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [145510] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Murkmire Treasure Map I",
                ["oldestTime"] = 1633182505,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182505,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 259,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182505,
                        ["quant"] = 1,
                        ["id"] = "1691608053",
                        ["itemLink"] = 1945,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [176743] = 
        {
            ["1:0:3:57:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_ring.dds",
                ["itemDesc"] = "Companion's Ring",
                ["oldestTime"] = 1632956944,
                ["wasAltered"] = true,
                ["newestTime"] = 1632956944,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13836,
                        ["guild"] = 1,
                        ["buyer"] = 2250,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1632956944,
                        ["quant"] = 1,
                        ["id"] = "1689935423",
                        ["itemLink"] = 3903,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior jewelry apparel ring soothing",
            },
        },
        [171882] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 103: Black Fin Legion Bows",
                ["oldestTime"] = 1633021612,
                ["wasAltered"] = true,
                ["newestTime"] = 1633276025,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 281,
                        ["wasKiosk"] = false,
                        ["seller"] = 513,
                        ["timestamp"] = 1633021612,
                        ["quant"] = 1,
                        ["id"] = "1690380077",
                        ["itemLink"] = 583,
                    },
                    [2] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 1643,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1633225526,
                        ["quant"] = 1,
                        ["id"] = "1692069679",
                        ["itemLink"] = 583,
                    },
                    [3] = 
                    {
                        ["price"] = 37000,
                        ["guild"] = 1,
                        ["buyer"] = 550,
                        ["wasKiosk"] = false,
                        ["seller"] = 1450,
                        ["timestamp"] = 1633276025,
                        ["quant"] = 1,
                        ["id"] = "1692476249",
                        ["itemLink"] = 583,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [97131] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_feet_d.dds",
                ["itemDesc"] = "Plague Doctor's Sabatons",
                ["oldestTime"] = 1633035424,
                ["wasAltered"] = true,
                ["newestTime"] = 1633035424,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 596,
                        ["wasKiosk"] = true,
                        ["seller"] = 597,
                        ["timestamp"] = 1633035424,
                        ["quant"] = 1,
                        ["id"] = "1690478697",
                        ["itemLink"] = 762,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set plague doctor feet impenetrable",
            },
        },
        [147310] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Lyris Titanborn's Pauldrons",
                ["oldestTime"] = 1633171154,
                ["wasAltered"] = true,
                ["newestTime"] = 1633171154,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1339,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1633171154,
                        ["quant"] = 1,
                        ["id"] = "1691526581",
                        ["itemLink"] = 1882,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [160623] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 88: Ancestral Orc Staves",
                ["oldestTime"] = 1633158291,
                ["wasAltered"] = true,
                ["newestTime"] = 1633313531,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6999,
                        ["guild"] = 1,
                        ["buyer"] = 55,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633313531,
                        ["quant"] = 1,
                        ["id"] = "1692885965",
                        ["itemLink"] = 39,
                    },
                    [2] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1294,
                        ["wasKiosk"] = true,
                        ["seller"] = 1214,
                        ["timestamp"] = 1633158291,
                        ["quant"] = 1,
                        ["id"] = "1691456189",
                        ["itemLink"] = 39,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [134768] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 58: Fang Lair Staves",
                ["oldestTime"] = 1632879387,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052183,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16240,
                        ["guild"] = 1,
                        ["buyer"] = 242,
                        ["wasKiosk"] = false,
                        ["seller"] = 712,
                        ["timestamp"] = 1633052183,
                        ["quant"] = 1,
                        ["id"] = "1690627937",
                        ["itemLink"] = 901,
                    },
                    [2] = 
                    {
                        ["price"] = 15600,
                        ["guild"] = 1,
                        ["buyer"] = 1080,
                        ["wasKiosk"] = true,
                        ["seller"] = 712,
                        ["timestamp"] = 1632879387,
                        ["quant"] = 1,
                        ["id"] = "1689389965",
                        ["itemLink"] = 901,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [142193] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 68: Honor Guard Gloves",
                ["oldestTime"] = 1633118568,
                ["wasAltered"] = true,
                ["newestTime"] = 1633143432,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 42000,
                        ["guild"] = 1,
                        ["buyer"] = 1038,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1633118568,
                        ["quant"] = 1,
                        ["id"] = "1691095839",
                        ["itemLink"] = 1423,
                    },
                    [2] = 
                    {
                        ["price"] = 15525,
                        ["guild"] = 1,
                        ["buyer"] = 1213,
                        ["wasKiosk"] = true,
                        ["seller"] = 1215,
                        ["timestamp"] = 1633143432,
                        ["quant"] = 1,
                        ["id"] = "1691330895",
                        ["itemLink"] = 1423,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [133235] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nocturnal_medium_feet_a.dds",
                ["itemDesc"] = "Cleft Striders",
                ["oldestTime"] = 1633023040,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023040,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633023040,
                        ["quant"] = 1,
                        ["id"] = "1690390983",
                        ["itemLink"] = 664,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set unfathomable darkness feet well-fitted",
            },
        },
        [167541] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_arkthzand_staff_a.dds",
                ["itemDesc"] = "Ice Staff of the Radiant Bastion",
                ["oldestTime"] = 1632868148,
                ["wasAltered"] = true,
                ["newestTime"] = 1632868148,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1448,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1632868148,
                        ["quant"] = 1,
                        ["id"] = "1689288887",
                        ["itemLink"] = 3369,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set radiant bastion frost staff two-handed charged",
            },
        },
        [132344] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing3.dds",
                ["itemDesc"] = "Diagram: Ayleid Brazier, Welkynd Holder",
                ["oldestTime"] = 1632964864,
                ["wasAltered"] = true,
                ["newestTime"] = 1632964864,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25520,
                        ["guild"] = 1,
                        ["buyer"] = 2046,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1632964864,
                        ["quant"] = 1,
                        ["id"] = "1690005337",
                        ["itemLink"] = 3951,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [180855] = 
        {
            ["50:16:5:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_staff_a.dds",
                ["itemDesc"] = "Hrothgar's Inferno Staff",
                ["oldestTime"] = 1632923992,
                ["wasAltered"] = true,
                ["newestTime"] = 1632923992,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 269420,
                        ["guild"] = 1,
                        ["buyer"] = 2493,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1632923992,
                        ["quant"] = 1,
                        ["id"] = "1689679251",
                        ["itemLink"] = 3678,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary weapon set hrothgar's chill flame staff two-handed sharpened",
            },
        },
        [117717] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_fur_nightstand001.dds",
                ["itemDesc"] = "Redguard Nightstand, Florid",
                ["oldestTime"] = 1632955049,
                ["wasAltered"] = true,
                ["newestTime"] = 1632955049,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24102,
                        ["guild"] = 1,
                        ["buyer"] = 6,
                        ["wasKiosk"] = false,
                        ["seller"] = 236,
                        ["timestamp"] = 1632955049,
                        ["quant"] = 2,
                        ["id"] = "1689918813",
                        ["itemLink"] = 3861,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings suite",
            },
        },
        [176887] = 
        {
            ["1:0:3:58:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_ring.dds",
                ["itemDesc"] = "Companion's Ring",
                ["oldestTime"] = 1632953855,
                ["wasAltered"] = true,
                ["newestTime"] = 1632953856,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2300,
                        ["guild"] = 1,
                        ["buyer"] = 2603,
                        ["wasKiosk"] = true,
                        ["seller"] = 177,
                        ["timestamp"] = 1632953855,
                        ["quant"] = 1,
                        ["id"] = "1689908827",
                        ["itemLink"] = 3860,
                    },
                    [2] = 
                    {
                        ["price"] = 2600,
                        ["guild"] = 1,
                        ["buyer"] = 2603,
                        ["wasKiosk"] = true,
                        ["seller"] = 695,
                        ["timestamp"] = 1632953856,
                        ["quant"] = 1,
                        ["id"] = "1689908835",
                        ["itemLink"] = 3860,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior jewelry apparel ring augmented",
            },
        },
        [175994] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Leyawiin Pitcher, Elegant",
                ["oldestTime"] = 1633041666,
                ["wasAltered"] = true,
                ["newestTime"] = 1633041666,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400000,
                        ["guild"] = 1,
                        ["buyer"] = 638,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633041666,
                        ["quant"] = 1,
                        ["id"] = "1690525729",
                        ["itemLink"] = 806,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [125819] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_heavy_waist_a.dds",
                ["itemDesc"] = "Impregnable Armor Girdle",
                ["oldestTime"] = 1632908925,
                ["wasAltered"] = true,
                ["newestTime"] = 1632908925,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2299,
                        ["guild"] = 1,
                        ["buyer"] = 2459,
                        ["wasKiosk"] = true,
                        ["seller"] = 2140,
                        ["timestamp"] = 1632908925,
                        ["quant"] = 1,
                        ["id"] = "1689598625",
                        ["itemLink"] = 3598,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set impregnable armor waist reinforced",
            },
        },
        [79351] = 
        {
            ["50:16:4:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_dagger_c.dds",
                ["itemDesc"] = "Briarheart Dagger",
                ["oldestTime"] = 1632945992,
                ["wasAltered"] = true,
                ["newestTime"] = 1632945992,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 2565,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1632945992,
                        ["quant"] = 1,
                        ["id"] = "1689841827",
                        ["itemLink"] = 3790,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set briarheart dagger one-handed infused",
            },
        },
        [172377] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_staff_a.dds",
                ["itemDesc"] = "Bog Raider's Ice Staff",
                ["oldestTime"] = 1633290223,
                ["wasAltered"] = true,
                ["newestTime"] = 1633290223,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2352,
                        ["guild"] = 1,
                        ["buyer"] = 1979,
                        ["wasKiosk"] = true,
                        ["seller"] = 237,
                        ["timestamp"] = 1633290223,
                        ["quant"] = 1,
                        ["id"] = "1692629755",
                        ["itemLink"] = 2781,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set bog raider frost staff two-handed sharpened",
            },
        },
        [175596] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_fur_housingleybookcasetallfilled002.dds",
                ["itemDesc"] = "Leyawiin Bookcase, Narrow Filled",
                ["oldestTime"] = 1632938640,
                ["wasAltered"] = true,
                ["newestTime"] = 1632938643,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 29500,
                        ["guild"] = 1,
                        ["buyer"] = 2535,
                        ["wasKiosk"] = true,
                        ["seller"] = 312,
                        ["timestamp"] = 1632938640,
                        ["quant"] = 1,
                        ["id"] = "1689785255",
                        ["itemLink"] = 3754,
                    },
                    [2] = 
                    {
                        ["price"] = 29500,
                        ["guild"] = 1,
                        ["buyer"] = 2535,
                        ["wasKiosk"] = true,
                        ["seller"] = 312,
                        ["timestamp"] = 1632938641,
                        ["quant"] = 1,
                        ["id"] = "1689785259",
                        ["itemLink"] = 3754,
                    },
                    [3] = 
                    {
                        ["price"] = 29500,
                        ["guild"] = 1,
                        ["buyer"] = 2535,
                        ["wasKiosk"] = true,
                        ["seller"] = 312,
                        ["timestamp"] = 1632938641,
                        ["quant"] = 1,
                        ["id"] = "1689785265",
                        ["itemLink"] = 3754,
                    },
                    [4] = 
                    {
                        ["price"] = 29500,
                        ["guild"] = 1,
                        ["buyer"] = 2535,
                        ["wasKiosk"] = true,
                        ["seller"] = 312,
                        ["timestamp"] = 1632938642,
                        ["quant"] = 1,
                        ["id"] = "1689785267",
                        ["itemLink"] = 3754,
                    },
                    [5] = 
                    {
                        ["price"] = 29500,
                        ["guild"] = 1,
                        ["buyer"] = 2535,
                        ["wasKiosk"] = true,
                        ["seller"] = 312,
                        ["timestamp"] = 1632938643,
                        ["quant"] = 1,
                        ["id"] = "1689785269",
                        ["itemLink"] = 3754,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 purple epic furnishings library",
            },
        },
        [172159] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_head_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Helmet",
                ["oldestTime"] = 1633313189,
                ["wasAltered"] = true,
                ["newestTime"] = 1633313189,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 770,
                        ["guild"] = 1,
                        ["buyer"] = 49,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633313189,
                        ["quant"] = 1,
                        ["id"] = "1692881885",
                        ["itemLink"] = 37,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set deadlands assassin head divines",
            },
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_head_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Helmet",
                ["oldestTime"] = 1632965507,
                ["wasAltered"] = true,
                ["newestTime"] = 1632965507,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4400,
                        ["guild"] = 1,
                        ["buyer"] = 1583,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632965507,
                        ["quant"] = 1,
                        ["id"] = "1690011483",
                        ["itemLink"] = 3953,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set deadlands assassin head divines",
            },
        },
        [172416] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_staff_a.dds",
                ["itemDesc"] = "Bog Raider's Inferno Staff",
                ["oldestTime"] = 1633203231,
                ["wasAltered"] = true,
                ["newestTime"] = 1633203231,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 1508,
                        ["wasKiosk"] = true,
                        ["seller"] = 50,
                        ["timestamp"] = 1633203231,
                        ["quant"] = 1,
                        ["id"] = "1691825369",
                        ["itemLink"] = 2228,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set bog raider flame staff two-handed decisive",
            },
        },
        [119681] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_woodworking.dds",
                ["itemDesc"] = "Sealed Woodworking Writ",
                ["oldestTime"] = 1632894535,
                ["wasAltered"] = true,
                ["newestTime"] = 1633283314,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 599,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1633032636,
                        ["quant"] = 1,
                        ["id"] = "1690462119",
                        ["itemLink"] = 737,
                    },
                    [2] = 
                    {
                        ["price"] = 956,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633032639,
                        ["quant"] = 1,
                        ["id"] = "1690462155",
                        ["itemLink"] = 738,
                    },
                    [3] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633032658,
                        ["quant"] = 1,
                        ["id"] = "1690462241",
                        ["itemLink"] = 740,
                    },
                    [4] = 
                    {
                        ["price"] = 956,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 502,
                        ["timestamp"] = 1633057840,
                        ["quant"] = 1,
                        ["id"] = "1690688803",
                        ["itemLink"] = 975,
                    },
                    [5] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 353,
                        ["timestamp"] = 1633057863,
                        ["quant"] = 1,
                        ["id"] = "1690689003",
                        ["itemLink"] = 976,
                    },
                    [6] = 
                    {
                        ["price"] = 2700,
                        ["guild"] = 1,
                        ["buyer"] = 866,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633076180,
                        ["quant"] = 1,
                        ["id"] = "1690817815",
                        ["itemLink"] = 1111,
                    },
                    [7] = 
                    {
                        ["price"] = 2250,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633111850,
                        ["quant"] = 1,
                        ["id"] = "1691050769",
                        ["itemLink"] = 1335,
                    },
                    [8] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 1002,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633113661,
                        ["quant"] = 1,
                        ["id"] = "1691062735",
                        ["itemLink"] = 1364,
                    },
                    [9] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 148,
                        ["timestamp"] = 1633125255,
                        ["quant"] = 1,
                        ["id"] = "1691144613",
                        ["itemLink"] = 1467,
                    },
                    [10] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 502,
                        ["timestamp"] = 1633125635,
                        ["quant"] = 1,
                        ["id"] = "1691147401",
                        ["itemLink"] = 1477,
                    },
                    [11] = 
                    {
                        ["price"] = 1699,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 246,
                        ["timestamp"] = 1633184288,
                        ["quant"] = 1,
                        ["id"] = "1691623389",
                        ["itemLink"] = 1970,
                    },
                    [12] = 
                    {
                        ["price"] = 2450,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 778,
                        ["timestamp"] = 1633184480,
                        ["quant"] = 1,
                        ["id"] = "1691624585",
                        ["itemLink"] = 1980,
                    },
                    [13] = 
                    {
                        ["price"] = 1750,
                        ["guild"] = 1,
                        ["buyer"] = 1405,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633188290,
                        ["quant"] = 1,
                        ["id"] = "1691669499",
                        ["itemLink"] = 2085,
                    },
                    [14] = 
                    {
                        ["price"] = 8400,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633190095,
                        ["quant"] = 1,
                        ["id"] = "1691688567",
                        ["itemLink"] = 2098,
                    },
                    [15] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633195433,
                        ["quant"] = 1,
                        ["id"] = "1691746087",
                        ["itemLink"] = 2135,
                    },
                    [16] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633195433,
                        ["quant"] = 1,
                        ["id"] = "1691746089",
                        ["itemLink"] = 2136,
                    },
                    [17] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1520,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633205105,
                        ["quant"] = 1,
                        ["id"] = "1691843503",
                        ["itemLink"] = 2247,
                    },
                    [18] = 
                    {
                        ["price"] = 1320,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 327,
                        ["timestamp"] = 1633234713,
                        ["quant"] = 1,
                        ["id"] = "1692158987",
                        ["itemLink"] = 2469,
                    },
                    [19] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1002,
                        ["wasKiosk"] = true,
                        ["seller"] = 54,
                        ["timestamp"] = 1633277736,
                        ["quant"] = 1,
                        ["id"] = "1692492957",
                        ["itemLink"] = 2714,
                    },
                    [20] = 
                    {
                        ["price"] = 2800,
                        ["guild"] = 1,
                        ["buyer"] = 413,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633283314,
                        ["quant"] = 1,
                        ["id"] = "1692549737",
                        ["itemLink"] = 2748,
                    },
                    [21] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 171,
                        ["timestamp"] = 1632894535,
                        ["quant"] = 1,
                        ["id"] = "1689527005",
                        ["itemLink"] = 3551,
                    },
                    [22] = 
                    {
                        ["price"] = 3750,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 332,
                        ["timestamp"] = 1632894617,
                        ["quant"] = 1,
                        ["id"] = "1689527459",
                        ["itemLink"] = 3555,
                    },
                },
                ["totalCount"] = 22,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [119682] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_woodworking.dds",
                ["itemDesc"] = "Sealed Woodworking Writ",
                ["oldestTime"] = 1632845861,
                ["wasAltered"] = true,
                ["newestTime"] = 1633195433,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1999,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633032648,
                        ["quant"] = 1,
                        ["id"] = "1690462199",
                        ["itemLink"] = 739,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1002,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633113661,
                        ["quant"] = 1,
                        ["id"] = "1691062727",
                        ["itemLink"] = 1363,
                    },
                    [3] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633195433,
                        ["quant"] = 1,
                        ["id"] = "1691746093",
                        ["itemLink"] = 2137,
                    },
                    [4] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1632845861,
                        ["quant"] = 1,
                        ["id"] = "1689108823",
                        ["itemLink"] = 3195,
                    },
                    [5] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 108,
                        ["timestamp"] = 1632870216,
                        ["quant"] = 1,
                        ["id"] = "1689304965",
                        ["itemLink"] = 3383,
                    },
                    [6] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 1002,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1632934982,
                        ["quant"] = 1,
                        ["id"] = "1689760407",
                        ["itemLink"] = 3724,
                    },
                    [7] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 930,
                        ["timestamp"] = 1632960178,
                        ["quant"] = 1,
                        ["id"] = "1689961271",
                        ["itemLink"] = 3920,
                    },
                    [8] = 
                    {
                        ["price"] = 2567,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 1509,
                        ["timestamp"] = 1632960189,
                        ["quant"] = 1,
                        ["id"] = "1689961325",
                        ["itemLink"] = 3921,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [89987] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Imperial Wrath",
                ["oldestTime"] = 1633242234,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242234,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 1783,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633242234,
                        ["quant"] = 1,
                        ["id"] = "1692212773",
                        ["itemLink"] = 2541,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set wrath of the imperium ring arcane",
            },
        },
        [139652] = 
        {
            ["1:0:4:30:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Exemplary Triune Ring",
                ["oldestTime"] = 1632872263,
                ["wasAltered"] = true,
                ["newestTime"] = 1632872263,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1729,
                        ["wasKiosk"] = true,
                        ["seller"] = 301,
                        ["timestamp"] = 1632872263,
                        ["quant"] = 1,
                        ["id"] = "1689317329",
                        ["itemLink"] = 3394,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic jewelry apparel ring triune",
            },
        },
        [96201] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Trainee",
                ["oldestTime"] = 1632935548,
                ["wasAltered"] = true,
                ["newestTime"] = 1632935548,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1003,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632935548,
                        ["quant"] = 1,
                        ["id"] = "1689766071",
                        ["itemLink"] = 3732,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set armor of the trainee ring robust",
            },
        },
        [808] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_ore_base_iron_r1.dds",
                ["itemDesc"] = "Iron Ore",
                ["oldestTime"] = 1632932718,
                ["wasAltered"] = true,
                ["newestTime"] = 1632932719,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 121,
                        ["wasKiosk"] = true,
                        ["seller"] = 966,
                        ["timestamp"] = 1632932718,
                        ["quant"] = 100,
                        ["id"] = "1689742181",
                        ["itemLink"] = 3718,
                    },
                    [2] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 121,
                        ["wasKiosk"] = true,
                        ["seller"] = 966,
                        ["timestamp"] = 1632932719,
                        ["quant"] = 100,
                        ["id"] = "1689742187",
                        ["itemLink"] = 3718,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [177031] = 
        {
            ["1:0:3:59:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_ring.dds",
                ["itemDesc"] = "Companion's Ring",
                ["oldestTime"] = 1633003718,
                ["wasAltered"] = true,
                ["newestTime"] = 1633003718,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 413,
                        ["wasKiosk"] = true,
                        ["seller"] = 205,
                        ["timestamp"] = 1633003718,
                        ["quant"] = 1,
                        ["id"] = "1690252761",
                        ["itemLink"] = 421,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior jewelry apparel ring bolstered",
            },
        },
        [79339] = 
        {
            ["50:16:4:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_dagger_c.dds",
                ["itemDesc"] = "Briarheart Dagger",
                ["oldestTime"] = 1632906449,
                ["wasAltered"] = true,
                ["newestTime"] = 1632906449,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150000,
                        ["guild"] = 1,
                        ["buyer"] = 375,
                        ["wasKiosk"] = true,
                        ["seller"] = 205,
                        ["timestamp"] = 1632906449,
                        ["quant"] = 1,
                        ["id"] = "1689588827",
                        ["itemLink"] = 3591,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set briarheart dagger one-handed precise",
            },
        },
        [139657] = 
        {
            ["1:0:4:31:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Exemplary Bloodthirsty Ring",
                ["oldestTime"] = 1632896434,
                ["wasAltered"] = true,
                ["newestTime"] = 1633188532,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 1407,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633188532,
                        ["quant"] = 1,
                        ["id"] = "1691671925",
                        ["itemLink"] = 2086,
                    },
                    [2] = 
                    {
                        ["price"] = 6850,
                        ["guild"] = 1,
                        ["buyer"] = 2435,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1632896434,
                        ["quant"] = 1,
                        ["id"] = "1689539075",
                        ["itemLink"] = 2086,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic jewelry apparel ring bloodthirsty",
            },
        },
        [97322] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_shoulders_d.dds",
                ["itemDesc"] = "Epaulets of a Mother's Sorrow",
                ["oldestTime"] = 1632884552,
                ["wasAltered"] = true,
                ["newestTime"] = 1632884552,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 2383,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1632884552,
                        ["quant"] = 1,
                        ["id"] = "1689446937",
                        ["itemLink"] = 3497,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set mother's sorrow shoulders impenetrable",
            },
        },
        [180875] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_staff_a.dds",
                ["itemDesc"] = "Hrothgar's Inferno Staff",
                ["oldestTime"] = 1633308506,
                ["wasAltered"] = true,
                ["newestTime"] = 1633308506,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7777,
                        ["guild"] = 1,
                        ["buyer"] = 2078,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633308506,
                        ["quant"] = 1,
                        ["id"] = "1692828765",
                        ["itemLink"] = 2959,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set hrothgar's chill flame staff two-handed charged",
            },
        },
        [180876] = 
        {
            ["50:16:4:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_staff_a.dds",
                ["itemDesc"] = "Hrothgar's Ice Staff",
                ["oldestTime"] = 1633112200,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112200,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 991,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633112200,
                        ["quant"] = 1,
                        ["id"] = "1691053893",
                        ["itemLink"] = 1343,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set hrothgar's chill frost staff two-handed charged",
            },
        },
        [43025] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_1hsword_d.dds",
                ["itemDesc"] = "Mabrigash Spectral Blade of Mother's Sorrow",
                ["oldestTime"] = 1632882069,
                ["wasAltered"] = true,
                ["newestTime"] = 1632882069,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 2202,
                        ["wasKiosk"] = true,
                        ["seller"] = 506,
                        ["timestamp"] = 1632882069,
                        ["quant"] = 1,
                        ["id"] = "1689418939",
                        ["itemLink"] = 3473,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set mother's sorrow sword one-handed defending",
            },
        },
        [150670] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_vile_coagula.dds",
                ["itemDesc"] = "Vile Coagulant",
                ["oldestTime"] = 1632871872,
                ["wasAltered"] = true,
                ["newestTime"] = 1633203155,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633203153,
                        ["quant"] = 10,
                        ["id"] = "1691824451",
                        ["itemLink"] = 2225,
                    },
                    [2] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633203153,
                        ["quant"] = 10,
                        ["id"] = "1691824463",
                        ["itemLink"] = 2225,
                    },
                    [3] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633203154,
                        ["quant"] = 10,
                        ["id"] = "1691824469",
                        ["itemLink"] = 2225,
                    },
                    [4] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633203154,
                        ["quant"] = 10,
                        ["id"] = "1691824473",
                        ["itemLink"] = 2225,
                    },
                    [5] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633203155,
                        ["quant"] = 10,
                        ["id"] = "1691824485",
                        ["itemLink"] = 2225,
                    },
                    [6] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 151,
                        ["wasKiosk"] = false,
                        ["seller"] = 31,
                        ["timestamp"] = 1632871872,
                        ["quant"] = 40,
                        ["id"] = "1689315109",
                        ["itemLink"] = 2225,
                    },
                    [7] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1066,
                        ["wasKiosk"] = true,
                        ["seller"] = 224,
                        ["timestamp"] = 1632945675,
                        ["quant"] = 50,
                        ["id"] = "1689840147",
                        ["itemLink"] = 2225,
                    },
                    [8] = 
                    {
                        ["price"] = 170000,
                        ["guild"] = 1,
                        ["buyer"] = 2649,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1632964012,
                        ["quant"] = 200,
                        ["id"] = "1689995547",
                        ["itemLink"] = 2225,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [119695] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_clothier.dds",
                ["itemDesc"] = "Sealed Clothier Writ",
                ["oldestTime"] = 1632912296,
                ["wasAltered"] = true,
                ["newestTime"] = 1633277723,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3995,
                        ["guild"] = 1,
                        ["buyer"] = 210,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1632975369,
                        ["quant"] = 1,
                        ["id"] = "1690098419",
                        ["itemLink"] = 221,
                    },
                    [2] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1632975720,
                        ["quant"] = 1,
                        ["id"] = "1690100445",
                        ["itemLink"] = 228,
                    },
                    [3] = 
                    {
                        ["price"] = 1050,
                        ["guild"] = 1,
                        ["buyer"] = 387,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1632998458,
                        ["quant"] = 1,
                        ["id"] = "1690224483",
                        ["itemLink"] = 385,
                    },
                    [4] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 387,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632998458,
                        ["quant"] = 1,
                        ["id"] = "1690224491",
                        ["itemLink"] = 386,
                    },
                    [5] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633032666,
                        ["quant"] = 1,
                        ["id"] = "1690462261",
                        ["itemLink"] = 741,
                    },
                    [6] = 
                    {
                        ["price"] = 2405,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633036276,
                        ["quant"] = 1,
                        ["id"] = "1690486365",
                        ["itemLink"] = 773,
                    },
                    [7] = 
                    {
                        ["price"] = 2100,
                        ["guild"] = 1,
                        ["buyer"] = 210,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633063792,
                        ["quant"] = 1,
                        ["id"] = "1690739129",
                        ["itemLink"] = 1043,
                    },
                    [8] = 
                    {
                        ["price"] = 2430,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633111851,
                        ["quant"] = 1,
                        ["id"] = "1691050777",
                        ["itemLink"] = 1336,
                    },
                    [9] = 
                    {
                        ["price"] = 2100,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633111851,
                        ["quant"] = 1,
                        ["id"] = "1691050783",
                        ["itemLink"] = 1337,
                    },
                    [10] = 
                    {
                        ["price"] = 2450,
                        ["guild"] = 1,
                        ["buyer"] = 1428,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633192415,
                        ["quant"] = 1,
                        ["id"] = "1691717241",
                        ["itemLink"] = 2115,
                    },
                    [11] = 
                    {
                        ["price"] = 2700,
                        ["guild"] = 1,
                        ["buyer"] = 1868,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633268307,
                        ["quant"] = 1,
                        ["id"] = "1692387805",
                        ["itemLink"] = 2657,
                    },
                    [12] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1913,
                        ["wasKiosk"] = true,
                        ["seller"] = 47,
                        ["timestamp"] = 1633277723,
                        ["quant"] = 1,
                        ["id"] = "1692492887",
                        ["itemLink"] = 2711,
                    },
                    [13] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2466,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632912296,
                        ["quant"] = 1,
                        ["id"] = "1689609635",
                        ["itemLink"] = 3615,
                    },
                    [14] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 387,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632916427,
                        ["quant"] = 1,
                        ["id"] = "1689633143",
                        ["itemLink"] = 3641,
                    },
                    [15] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2663,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1632966539,
                        ["quant"] = 1,
                        ["id"] = "1690019989",
                        ["itemLink"] = 3971,
                    },
                },
                ["totalCount"] = 15,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [120827] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_coh_inc_ironmaiden003.dds",
                ["itemDesc"] = "Iron Maiden, Chained",
                ["oldestTime"] = 1632879920,
                ["wasAltered"] = true,
                ["newestTime"] = 1632879920,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 44700,
                        ["guild"] = 1,
                        ["buyer"] = 2331,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1632879920,
                        ["quant"] = 1,
                        ["id"] = "1689395567",
                        ["itemLink"] = 3450,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings undercroft",
            },
        },
        [71569] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 23: Malacath Boots",
                ["oldestTime"] = 1632852118,
                ["wasAltered"] = true,
                ["newestTime"] = 1633254775,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8999,
                        ["guild"] = 1,
                        ["buyer"] = 160,
                        ["wasKiosk"] = true,
                        ["seller"] = 164,
                        ["timestamp"] = 1632970206,
                        ["quant"] = 1,
                        ["id"] = "1690058997",
                        ["itemLink"] = 175,
                    },
                    [2] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 1447,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633195504,
                        ["quant"] = 1,
                        ["id"] = "1691746701",
                        ["itemLink"] = 175,
                    },
                    [3] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1828,
                        ["wasKiosk"] = true,
                        ["seller"] = 1720,
                        ["timestamp"] = 1633254775,
                        ["quant"] = 1,
                        ["id"] = "1692300175",
                        ["itemLink"] = 175,
                    },
                    [4] = 
                    {
                        ["price"] = 8800,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1632852118,
                        ["quant"] = 1,
                        ["id"] = "1689160095",
                        ["itemLink"] = 175,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [130030] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 79: Refabricated Bows",
                ["oldestTime"] = 1632899767,
                ["wasAltered"] = true,
                ["newestTime"] = 1633264157,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 1847,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1633264157,
                        ["quant"] = 1,
                        ["id"] = "1692351811",
                        ["itemLink"] = 2635,
                    },
                    [2] = 
                    {
                        ["price"] = 19999,
                        ["guild"] = 1,
                        ["buyer"] = 2442,
                        ["wasKiosk"] = true,
                        ["seller"] = 277,
                        ["timestamp"] = 1632899767,
                        ["quant"] = 1,
                        ["id"] = "1689557641",
                        ["itemLink"] = 2635,
                    },
                    [3] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 2586,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1632950253,
                        ["quant"] = 1,
                        ["id"] = "1689876289",
                        ["itemLink"] = 2635,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [172179] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_head_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Helmet",
                ["oldestTime"] = 1633273633,
                ["wasAltered"] = true,
                ["newestTime"] = 1633273633,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1892,
                        ["wasKiosk"] = true,
                        ["seller"] = 1417,
                        ["timestamp"] = 1633273633,
                        ["quant"] = 1,
                        ["id"] = "1692445659",
                        ["itemLink"] = 2687,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set deadlands assassin head well-fitted",
            },
        },
        [171412] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_cwc_exc_vrdsentryswitch001.dds",
                ["itemDesc"] = "Clockwork Switch, Rotary",
                ["oldestTime"] = 1632985304,
                ["wasAltered"] = true,
                ["newestTime"] = 1633088860,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9599,
                        ["guild"] = 1,
                        ["buyer"] = 316,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1632985304,
                        ["quant"] = 1,
                        ["id"] = "1690161405",
                        ["itemLink"] = 320,
                    },
                    [2] = 
                    {
                        ["price"] = 9599,
                        ["guild"] = 1,
                        ["buyer"] = 316,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1632985305,
                        ["quant"] = 1,
                        ["id"] = "1690161407",
                        ["itemLink"] = 320,
                    },
                    [3] = 
                    {
                        ["price"] = 9599,
                        ["guild"] = 1,
                        ["buyer"] = 668,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633088859,
                        ["quant"] = 1,
                        ["id"] = "1690882603",
                        ["itemLink"] = 320,
                    },
                    [4] = 
                    {
                        ["price"] = 9599,
                        ["guild"] = 1,
                        ["buyer"] = 668,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633088860,
                        ["quant"] = 1,
                        ["id"] = "1690882617",
                        ["itemLink"] = 320,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 purple epic furnishings workshop",
            },
        },
        [172437] = 
        {
            ["50:16:4:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_staff_a.dds",
                ["itemDesc"] = "Bog Raider's Ice Staff",
                ["oldestTime"] = 1633249954,
                ["wasAltered"] = true,
                ["newestTime"] = 1633249954,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 1815,
                        ["wasKiosk"] = true,
                        ["seller"] = 1816,
                        ["timestamp"] = 1633249954,
                        ["quant"] = 1,
                        ["id"] = "1692270123",
                        ["itemLink"] = 2595,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set bog raider frost staff two-handed training",
            },
        },
        [149142] = 
        {
            ["50:16:3:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_sword_a.dds",
                ["itemDesc"] = "Undertaker's Sword",
                ["oldestTime"] = 1633277288,
                ["wasAltered"] = true,
                ["newestTime"] = 1633277288,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1910,
                        ["wasKiosk"] = true,
                        ["seller"] = 872,
                        ["timestamp"] = 1633277288,
                        ["quant"] = 1,
                        ["id"] = "1692489091",
                        ["itemLink"] = 2708,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set call of the undertaker sword one-handed sharpened",
            },
        },
        [116454] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_orc_inc_wtgtapestry001.dds",
                ["itemDesc"] = "Orcish Tapestry, Axe",
                ["oldestTime"] = 1632869434,
                ["wasAltered"] = true,
                ["newestTime"] = 1632869434,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 2283,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1632869434,
                        ["quant"] = 1,
                        ["id"] = "1689299315",
                        ["itemLink"] = 3378,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings parlor",
            },
        },
        [171887] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 103: Black Fin Legion Legs",
                ["oldestTime"] = 1632936296,
                ["wasAltered"] = true,
                ["newestTime"] = 1633268790,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 80000,
                        ["guild"] = 1,
                        ["buyer"] = 1189,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1633141672,
                        ["quant"] = 1,
                        ["id"] = "1691309515",
                        ["itemLink"] = 1614,
                    },
                    [2] = 
                    {
                        ["price"] = 42069,
                        ["guild"] = 1,
                        ["buyer"] = 1869,
                        ["wasKiosk"] = true,
                        ["seller"] = 521,
                        ["timestamp"] = 1633268790,
                        ["quant"] = 1,
                        ["id"] = "1692393095",
                        ["itemLink"] = 1614,
                    },
                    [3] = 
                    {
                        ["price"] = 119995,
                        ["guild"] = 1,
                        ["buyer"] = 2526,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1632936296,
                        ["quant"] = 1,
                        ["id"] = "1689770255",
                        ["itemLink"] = 1614,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [175984] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Leyawiin Clothesline, Pulleys",
                ["oldestTime"] = 1632862583,
                ["wasAltered"] = true,
                ["newestTime"] = 1632862583,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 2251,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632862583,
                        ["quant"] = 1,
                        ["id"] = "1689248795",
                        ["itemLink"] = 3317,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [82099] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 40: Order Hour Shoulders",
                ["oldestTime"] = 1632860466,
                ["wasAltered"] = true,
                ["newestTime"] = 1632860466,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 29999,
                        ["guild"] = 1,
                        ["buyer"] = 450,
                        ["wasKiosk"] = true,
                        ["seller"] = 163,
                        ["timestamp"] = 1632860466,
                        ["quant"] = 1,
                        ["id"] = "1689234217",
                        ["itemLink"] = 3296,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [172279] = 
        {
            ["50:16:2:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_head_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Helmet",
                ["oldestTime"] = 1633134589,
                ["wasAltered"] = true,
                ["newestTime"] = 1633134589,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1134,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633134589,
                        ["quant"] = 1,
                        ["id"] = "1691236645",
                        ["itemLink"] = 1554,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set deadlands assassin head training",
            },
        },
        [129996] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 51: Hlaalu Belts",
                ["oldestTime"] = 1633143401,
                ["wasAltered"] = true,
                ["newestTime"] = 1633143401,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1213,
                        ["wasKiosk"] = true,
                        ["seller"] = 1214,
                        ["timestamp"] = 1633143401,
                        ["quant"] = 1,
                        ["id"] = "1691330441",
                        ["itemLink"] = 1633,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [180478] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_bow_a.dds",
                ["itemDesc"] = "Bow of Dark Convergence",
                ["oldestTime"] = 1632830334,
                ["wasAltered"] = true,
                ["newestTime"] = 1632946846,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2134,
                        ["wasKiosk"] = true,
                        ["seller"] = 761,
                        ["timestamp"] = 1632830334,
                        ["quant"] = 1,
                        ["id"] = "1689000487",
                        ["itemLink"] = 3080,
                    },
                    [2] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 2568,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1632946846,
                        ["quant"] = 1,
                        ["id"] = "1689849383",
                        ["itemLink"] = 3792,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior weapon set dark convergence bow two-handed precise",
            },
        },
        [175774] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_str_leydetachableplantershousing002.dds",
                ["itemDesc"] = "Leyawiin Windowbox, Irises",
                ["oldestTime"] = 1632877432,
                ["wasAltered"] = true,
                ["newestTime"] = 1633272243,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6100,
                        ["guild"] = 1,
                        ["buyer"] = 621,
                        ["wasKiosk"] = true,
                        ["seller"] = 622,
                        ["timestamp"] = 1633039925,
                        ["quant"] = 1,
                        ["id"] = "1690512705",
                        ["itemLink"] = 784,
                    },
                    [2] = 
                    {
                        ["price"] = 6100,
                        ["guild"] = 1,
                        ["buyer"] = 621,
                        ["wasKiosk"] = true,
                        ["seller"] = 622,
                        ["timestamp"] = 1633039926,
                        ["quant"] = 1,
                        ["id"] = "1690512711",
                        ["itemLink"] = 784,
                    },
                    [3] = 
                    {
                        ["price"] = 6100,
                        ["guild"] = 1,
                        ["buyer"] = 621,
                        ["wasKiosk"] = true,
                        ["seller"] = 622,
                        ["timestamp"] = 1633039927,
                        ["quant"] = 1,
                        ["id"] = "1690512715",
                        ["itemLink"] = 784,
                    },
                    [4] = 
                    {
                        ["price"] = 6100,
                        ["guild"] = 1,
                        ["buyer"] = 621,
                        ["wasKiosk"] = true,
                        ["seller"] = 622,
                        ["timestamp"] = 1633039928,
                        ["quant"] = 1,
                        ["id"] = "1690512723",
                        ["itemLink"] = 784,
                    },
                    [5] = 
                    {
                        ["price"] = 6100,
                        ["guild"] = 1,
                        ["buyer"] = 788,
                        ["wasKiosk"] = true,
                        ["seller"] = 622,
                        ["timestamp"] = 1633060582,
                        ["quant"] = 1,
                        ["id"] = "1690715291",
                        ["itemLink"] = 784,
                    },
                    [6] = 
                    {
                        ["price"] = 6100,
                        ["guild"] = 1,
                        ["buyer"] = 788,
                        ["wasKiosk"] = true,
                        ["seller"] = 622,
                        ["timestamp"] = 1633060584,
                        ["quant"] = 1,
                        ["id"] = "1690715305",
                        ["itemLink"] = 784,
                    },
                    [7] = 
                    {
                        ["price"] = 6100,
                        ["guild"] = 1,
                        ["buyer"] = 1885,
                        ["wasKiosk"] = true,
                        ["seller"] = 622,
                        ["timestamp"] = 1633272243,
                        ["quant"] = 1,
                        ["id"] = "1692429103",
                        ["itemLink"] = 784,
                    },
                    [8] = 
                    {
                        ["price"] = 6100,
                        ["guild"] = 1,
                        ["buyer"] = 1995,
                        ["wasKiosk"] = true,
                        ["seller"] = 622,
                        ["timestamp"] = 1632877432,
                        ["quant"] = 1,
                        ["id"] = "1689366219",
                        ["itemLink"] = 784,
                    },
                    [9] = 
                    {
                        ["price"] = 6100,
                        ["guild"] = 1,
                        ["buyer"] = 1995,
                        ["wasKiosk"] = true,
                        ["seller"] = 622,
                        ["timestamp"] = 1632877716,
                        ["quant"] = 1,
                        ["id"] = "1689370219",
                        ["itemLink"] = 784,
                    },
                },
                ["totalCount"] = 9,
                ["itemAdderText"] = "rr01 blue superior furnishings conservatory",
            },
        },
        [139412] = 
        {
            ["1:0:1:28:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_outfitter_plug_component_002.dds",
                ["itemDesc"] = "Gilding Wax",
                ["oldestTime"] = 1632848264,
                ["wasAltered"] = true,
                ["newestTime"] = 1632848264,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 92745,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 2123,
                        ["timestamp"] = 1632848264,
                        ["quant"] = 3,
                        ["id"] = "1689130361",
                        ["itemLink"] = 3223,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials jewelry trait swift",
            },
        },
        [180896] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_staff_a.dds",
                ["itemDesc"] = "Hrothgar's Ice Staff",
                ["oldestTime"] = 1633154954,
                ["wasAltered"] = true,
                ["newestTime"] = 1633154954,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 1276,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633154954,
                        ["quant"] = 1,
                        ["id"] = "1691430993",
                        ["itemLink"] = 1743,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set hrothgar's chill frost staff two-handed decisive",
            },
        },
        [126849] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing2.dds",
                ["itemDesc"] = "Diagram: Dwarven Pipe Cap, Bolted",
                ["oldestTime"] = 1632842277,
                ["wasAltered"] = true,
                ["newestTime"] = 1632842277,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2184,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1632842277,
                        ["quant"] = 1,
                        ["id"] = "1689075601",
                        ["itemLink"] = 3160,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [125854] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_heavy_waist_a.dds",
                ["itemDesc"] = "Impregnable Armor Girdle",
                ["oldestTime"] = 1632841728,
                ["wasAltered"] = true,
                ["newestTime"] = 1632841728,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 2187,
                        ["wasKiosk"] = true,
                        ["seller"] = 192,
                        ["timestamp"] = 1632841728,
                        ["quant"] = 1,
                        ["id"] = "1689072659",
                        ["itemLink"] = 3157,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set impregnable armor waist impenetrable",
            },
        },
        [54179] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_wood_turpen.dds",
                ["itemDesc"] = "Turpen",
                ["oldestTime"] = 1632848429,
                ["wasAltered"] = true,
                ["newestTime"] = 1632848430,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7599,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 330,
                        ["timestamp"] = 1632848429,
                        ["quant"] = 200,
                        ["id"] = "1689131425",
                        ["itemLink"] = 3226,
                    },
                    [2] = 
                    {
                        ["price"] = 7600,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1632848430,
                        ["quant"] = 200,
                        ["id"] = "1689131429",
                        ["itemLink"] = 3226,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior materials resin",
            },
        },
        [45220] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_medium_legs_d.dds",
                ["itemDesc"] = "Rubedo Leather Guards of Stamina",
                ["oldestTime"] = 1633185956,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185956,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 174,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633185956,
                        ["quant"] = 1,
                        ["id"] = "1691640307",
                        ["itemLink"] = 2031,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel legs infused",
            },
        },
        [176549] = 
        {
            ["1:0:2:47:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_gloves_light.dds",
                ["itemDesc"] = "Companion's Gloves",
                ["oldestTime"] = 1633211403,
                ["wasAltered"] = true,
                ["newestTime"] = 1633211403,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1554,
                        ["wasKiosk"] = true,
                        ["seller"] = 33,
                        ["timestamp"] = 1633211403,
                        ["quant"] = 1,
                        ["id"] = "1691920473",
                        ["itemLink"] = 2282,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine light apparel hands aggressive",
            },
        },
        [176851] = 
        {
            ["1:0:2:58:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_ring.dds",
                ["itemDesc"] = "Companion's Ring",
                ["oldestTime"] = 1633316321,
                ["wasAltered"] = true,
                ["newestTime"] = 1633316321,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2095,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633316321,
                        ["quant"] = 1,
                        ["id"] = "1692918419",
                        ["itemLink"] = 3004,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine jewelry apparel ring augmented",
            },
        },
        [172199] = 
        {
            ["50:16:2:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_head_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Helmet",
                ["oldestTime"] = 1633048828,
                ["wasAltered"] = true,
                ["newestTime"] = 1633048828,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 180,
                        ["guild"] = 1,
                        ["buyer"] = 689,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633048828,
                        ["quant"] = 1,
                        ["id"] = "1690594061",
                        ["itemLink"] = 877,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set deadlands assassin head reinforced",
            },
        },
        [175862] = 
        {
            ["1:0:3:52:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_ring.dds",
                ["itemDesc"] = "Companion's Ring",
                ["oldestTime"] = 1632874416,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293716,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 21000,
                        ["guild"] = 1,
                        ["buyer"] = 2001,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633293716,
                        ["quant"] = 1,
                        ["id"] = "1692672401",
                        ["itemLink"] = 2858,
                    },
                    [2] = 
                    {
                        ["price"] = 41448,
                        ["guild"] = 1,
                        ["buyer"] = 2316,
                        ["wasKiosk"] = true,
                        ["seller"] = 2317,
                        ["timestamp"] = 1632874416,
                        ["quant"] = 1,
                        ["id"] = "1689335027",
                        ["itemLink"] = 2858,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior jewelry apparel ring quickened",
            },
        },
        [171801] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing5.dds",
                ["itemDesc"] = "Diagram: Dwarven Minecart, Ornate",
                ["oldestTime"] = 1633292401,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292401,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 133000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 625,
                        ["timestamp"] = 1633292401,
                        ["quant"] = 1,
                        ["id"] = "1692656333",
                        ["itemLink"] = 2828,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable recipe",
            },
        },
        [119244] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Redguard Bookcase, Piled",
                ["oldestTime"] = 1633292332,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292332,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 169000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633292332,
                        ["quant"] = 1,
                        ["id"] = "1692655401",
                        ["itemLink"] = 2821,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [175960] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_jewelry_4.dds",
                ["itemDesc"] = "Sketch: Leyawiin Jewelry Box, Gilded",
                ["oldestTime"] = 1633292223,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292223,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633292223,
                        ["quant"] = 1,
                        ["id"] = "1692654067",
                        ["itemLink"] = 2811,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [172296] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_staff_a.dds",
                ["itemDesc"] = "Bog Raider's Inferno Staff",
                ["oldestTime"] = 1633292060,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292060,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 379,
                        ["timestamp"] = 1633292060,
                        ["quant"] = 1,
                        ["id"] = "1692652315",
                        ["itemLink"] = 2806,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set bog raider flame staff two-handed infused",
            },
        },
        [172205] = 
        {
            ["50:16:3:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_1hsword_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Sword",
                ["oldestTime"] = 1632939808,
                ["wasAltered"] = true,
                ["newestTime"] = 1632939808,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1430,
                        ["wasKiosk"] = true,
                        ["seller"] = 691,
                        ["timestamp"] = 1632939808,
                        ["quant"] = 1,
                        ["id"] = "1689793771",
                        ["itemLink"] = 3763,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set deadlands assassin sword one-handed sharpened",
            },
        },
        [96174] = 
        {
            ["50:16:4:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_light_hands_d.dds",
                ["itemDesc"] = "Gloves of the Trainee",
                ["oldestTime"] = 1633150983,
                ["wasAltered"] = true,
                ["newestTime"] = 1633150983,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2250,
                        ["guild"] = 1,
                        ["buyer"] = 1261,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1633150983,
                        ["quant"] = 1,
                        ["id"] = "1691399145",
                        ["itemLink"] = 1723,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set armor of the trainee hands training",
            },
        },
        [172207] = 
        {
            ["50:16:2:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_2hhammer_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Maul",
                ["oldestTime"] = 1633034616,
                ["wasAltered"] = true,
                ["newestTime"] = 1633034616,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 589,
                        ["wasKiosk"] = true,
                        ["seller"] = 590,
                        ["timestamp"] = 1633034616,
                        ["quant"] = 1,
                        ["id"] = "1690473771",
                        ["itemLink"] = 759,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set deadlands assassin mace two-handed sharpened",
            },
        },
        [172219] = 
        {
            ["50:16:2:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_medium_head_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Helmet",
                ["oldestTime"] = 1633289398,
                ["wasAltered"] = true,
                ["newestTime"] = 1633289398,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1974,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633289398,
                        ["quant"] = 1,
                        ["id"] = "1692619629",
                        ["itemLink"] = 2771,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set deadlands assassin head impenetrable",
            },
        },
        [57610] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 20: Yokudan Chests",
                ["oldestTime"] = 1632970672,
                ["wasAltered"] = true,
                ["newestTime"] = 1632970672,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 23000,
                        ["guild"] = 1,
                        ["buyer"] = 149,
                        ["wasKiosk"] = false,
                        ["seller"] = 70,
                        ["timestamp"] = 1632970672,
                        ["quant"] = 1,
                        ["id"] = "1690063025",
                        ["itemLink"] = 184,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [171923] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 102: Sul-Xan Shields",
                ["oldestTime"] = 1632850263,
                ["wasAltered"] = true,
                ["newestTime"] = 1633276048,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 120000,
                        ["guild"] = 1,
                        ["buyer"] = 550,
                        ["wasKiosk"] = false,
                        ["seller"] = 360,
                        ["timestamp"] = 1633276048,
                        ["quant"] = 1,
                        ["id"] = "1692476363",
                        ["itemLink"] = 2700,
                    },
                    [2] = 
                    {
                        ["price"] = 165000,
                        ["guild"] = 1,
                        ["buyer"] = 7,
                        ["wasKiosk"] = false,
                        ["seller"] = 271,
                        ["timestamp"] = 1632850263,
                        ["quant"] = 1,
                        ["id"] = "1689146501",
                        ["itemLink"] = 2700,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [180915] = 
        {
            ["50:16:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_staff_a.dds",
                ["itemDesc"] = "Hrothgar's Inferno Staff",
                ["oldestTime"] = 1633052767,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052767,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9876,
                        ["guild"] = 1,
                        ["buyer"] = 718,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633052767,
                        ["quant"] = 1,
                        ["id"] = "1690632869",
                        ["itemLink"] = 914,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set hrothgar's chill flame staff two-handed training",
            },
        },
        [45703] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Ash-Hopper Dumplings on Scathecraw",
                ["oldestTime"] = 1633267911,
                ["wasAltered"] = true,
                ["newestTime"] = 1633306714,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 1864,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633267911,
                        ["quant"] = 1,
                        ["id"] = "1692383861",
                        ["itemLink"] = 2647,
                    },
                    [2] = 
                    {
                        ["price"] = 5400,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633306714,
                        ["quant"] = 1,
                        ["id"] = "1692806717",
                        ["itemLink"] = 2647,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [115637] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_kha_cmp_cookingpit002.dds",
                ["itemDesc"] = "Khajiit Firepit, Brick",
                ["oldestTime"] = 1632872942,
                ["wasAltered"] = true,
                ["newestTime"] = 1632872942,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8605,
                        ["guild"] = 1,
                        ["buyer"] = 1995,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1632872942,
                        ["quant"] = 1,
                        ["id"] = "1689322781",
                        ["itemLink"] = 3398,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings lighting",
            },
        },
        [68190] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Millet and Beef Stuffed Peppers",
                ["oldestTime"] = 1633261590,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261590,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 28,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 711,
                        ["timestamp"] = 1633261590,
                        ["quant"] = 1,
                        ["id"] = "1692334355",
                        ["itemLink"] = 2619,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [176311] = 
        {
            ["1:0:3:54:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_ring.dds",
                ["itemDesc"] = "Companion's Ring",
                ["oldestTime"] = 1633169513,
                ["wasAltered"] = true,
                ["newestTime"] = 1633169513,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1335,
                        ["wasKiosk"] = true,
                        ["seller"] = 353,
                        ["timestamp"] = 1633169513,
                        ["quant"] = 1,
                        ["id"] = "1691516203",
                        ["itemLink"] = 1880,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior jewelry apparel ring focused",
            },
        },
        [167352] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_nor_duc_totempiece004.dds",
                ["itemDesc"] = "Pelt, Fox",
                ["oldestTime"] = 1633106248,
                ["wasAltered"] = true,
                ["newestTime"] = 1633106254,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12998,
                        ["guild"] = 1,
                        ["buyer"] = 960,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633106248,
                        ["quant"] = 1,
                        ["id"] = "1691010801",
                        ["itemLink"] = 1299,
                    },
                    [2] = 
                    {
                        ["price"] = 12998,
                        ["guild"] = 1,
                        ["buyer"] = 960,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633106254,
                        ["quant"] = 1,
                        ["id"] = "1691010817",
                        ["itemLink"] = 1299,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior furnishings gallery",
            },
        },
        [76827] = 
        {
            ["50:15:1:9:138240"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_poison_001_red_005.dds",
                ["itemDesc"] = "Damage Health Poison IX",
                ["oldestTime"] = 1633233127,
                ["wasAltered"] = true,
                ["newestTime"] = 1633233127,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 827,
                        ["wasKiosk"] = false,
                        ["seller"] = 696,
                        ["timestamp"] = 1633233127,
                        ["quant"] = 250,
                        ["id"] = "1692145777",
                        ["itemLink"] = 2453,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 white normal consumable poison",
            },
        },
        [121530] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_woodworking.dds",
                ["itemDesc"] = "Sealed Woodworking Writ",
                ["oldestTime"] = 1632847498,
                ["wasAltered"] = true,
                ["newestTime"] = 1633234733,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18995,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1632975719,
                        ["quant"] = 1,
                        ["id"] = "1690100419",
                        ["itemLink"] = 225,
                    },
                    [2] = 
                    {
                        ["price"] = 4300,
                        ["guild"] = 1,
                        ["buyer"] = 450,
                        ["wasKiosk"] = true,
                        ["seller"] = 451,
                        ["timestamp"] = 1633011279,
                        ["quant"] = 1,
                        ["id"] = "1690299555",
                        ["itemLink"] = 514,
                    },
                    [3] = 
                    {
                        ["price"] = 43081,
                        ["guild"] = 1,
                        ["buyer"] = 520,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633022624,
                        ["quant"] = 1,
                        ["id"] = "1690387461",
                        ["itemLink"] = 595,
                    },
                    [4] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633111849,
                        ["quant"] = 1,
                        ["id"] = "1691050741",
                        ["itemLink"] = 1331,
                    },
                    [5] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1355,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633176407,
                        ["quant"] = 1,
                        ["id"] = "1691557755",
                        ["itemLink"] = 1902,
                    },
                    [6] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 957,
                        ["timestamp"] = 1633184466,
                        ["quant"] = 1,
                        ["id"] = "1691624501",
                        ["itemLink"] = 1979,
                    },
                    [7] = 
                    {
                        ["price"] = 16836,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633190091,
                        ["quant"] = 1,
                        ["id"] = "1691688491",
                        ["itemLink"] = 2097,
                    },
                    [8] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633234733,
                        ["quant"] = 1,
                        ["id"] = "1692159141",
                        ["itemLink"] = 2472,
                    },
                    [9] = 
                    {
                        ["price"] = 25400,
                        ["guild"] = 1,
                        ["buyer"] = 800,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632847498,
                        ["quant"] = 1,
                        ["id"] = "1689123757",
                        ["itemLink"] = 3205,
                    },
                    [10] = 
                    {
                        ["price"] = 11600,
                        ["guild"] = 1,
                        ["buyer"] = 2612,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1632955856,
                        ["quant"] = 1,
                        ["id"] = "1689926147",
                        ["itemLink"] = 3864,
                    },
                },
                ["totalCount"] = 10,
                ["itemAdderText"] = "rr01 gold legendary consumable master writ",
            },
        },
        [43707] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Cyrodiil Treasure Map V",
                ["oldestTime"] = 1633148097,
                ["wasAltered"] = true,
                ["newestTime"] = 1633148097,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 682,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633148097,
                        ["quant"] = 1,
                        ["id"] = "1691374571",
                        ["itemLink"] = 1693,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [121532] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_clothier.dds",
                ["itemDesc"] = "Sealed Clothier Writ",
                ["oldestTime"] = 1633016514,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186341,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2200,
                        ["guild"] = 1,
                        ["buyer"] = 472,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633016514,
                        ["quant"] = 1,
                        ["id"] = "1690337427",
                        ["itemLink"] = 542,
                    },
                    [2] = 
                    {
                        ["price"] = 7900,
                        ["guild"] = 1,
                        ["buyer"] = 218,
                        ["wasKiosk"] = false,
                        ["seller"] = 173,
                        ["timestamp"] = 1633134541,
                        ["quant"] = 1,
                        ["id"] = "1691236161",
                        ["itemLink"] = 1552,
                    },
                    [3] = 
                    {
                        ["price"] = 19000,
                        ["guild"] = 1,
                        ["buyer"] = 1396,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633186341,
                        ["quant"] = 1,
                        ["id"] = "1691643995",
                        ["itemLink"] = 2071,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 gold legendary consumable master writ",
            },
        },
        [121533] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_clothier.dds",
                ["itemDesc"] = "Sealed Clothier Writ",
                ["oldestTime"] = 1633134556,
                ["wasAltered"] = true,
                ["newestTime"] = 1633290668,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 218,
                        ["wasKiosk"] = false,
                        ["seller"] = 957,
                        ["timestamp"] = 1633134556,
                        ["quant"] = 1,
                        ["id"] = "1691236283",
                        ["itemLink"] = 1553,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 969,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633290668,
                        ["quant"] = 1,
                        ["id"] = "1692635119",
                        ["itemLink"] = 2783,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary consumable master writ",
            },
        },
        [175550] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Blackwood Treasure Map IV",
                ["oldestTime"] = 1633035679,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293474,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 46000,
                        ["guild"] = 1,
                        ["buyer"] = 397,
                        ["wasKiosk"] = false,
                        ["seller"] = 573,
                        ["timestamp"] = 1633035679,
                        ["quant"] = 1,
                        ["id"] = "1690480383",
                        ["itemLink"] = 770,
                    },
                    [2] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 709,
                        ["timestamp"] = 1633057624,
                        ["quant"] = 1,
                        ["id"] = "1690686907",
                        ["itemLink"] = 770,
                    },
                    [3] = 
                    {
                        ["price"] = 54990,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 333,
                        ["timestamp"] = 1633057662,
                        ["quant"] = 1,
                        ["id"] = "1690687237",
                        ["itemLink"] = 770,
                    },
                    [4] = 
                    {
                        ["price"] = 57205,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 109,
                        ["timestamp"] = 1633057665,
                        ["quant"] = 1,
                        ["id"] = "1690687247",
                        ["itemLink"] = 770,
                    },
                    [5] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 513,
                        ["timestamp"] = 1633057672,
                        ["quant"] = 1,
                        ["id"] = "1690687293",
                        ["itemLink"] = 770,
                    },
                    [6] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 734,
                        ["timestamp"] = 1633075825,
                        ["quant"] = 1,
                        ["id"] = "1690815843",
                        ["itemLink"] = 770,
                    },
                    [7] = 
                    {
                        ["price"] = 44444,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 93,
                        ["timestamp"] = 1633075828,
                        ["quant"] = 1,
                        ["id"] = "1690815855",
                        ["itemLink"] = 770,
                    },
                    [8] = 
                    {
                        ["price"] = 44444,
                        ["guild"] = 1,
                        ["buyer"] = 1217,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633143533,
                        ["quant"] = 1,
                        ["id"] = "1691331643",
                        ["itemLink"] = 770,
                    },
                    [9] = 
                    {
                        ["price"] = 49999,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 521,
                        ["timestamp"] = 1633146746,
                        ["quant"] = 1,
                        ["id"] = "1691363289",
                        ["itemLink"] = 770,
                    },
                    [10] = 
                    {
                        ["price"] = 49999,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 521,
                        ["timestamp"] = 1633146748,
                        ["quant"] = 1,
                        ["id"] = "1691363303",
                        ["itemLink"] = 770,
                    },
                    [11] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 153,
                        ["timestamp"] = 1633146749,
                        ["quant"] = 1,
                        ["id"] = "1691363323",
                        ["itemLink"] = 770,
                    },
                    [12] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 521,
                        ["timestamp"] = 1633156798,
                        ["quant"] = 1,
                        ["id"] = "1691444665",
                        ["itemLink"] = 770,
                    },
                    [13] = 
                    {
                        ["price"] = 41000,
                        ["guild"] = 1,
                        ["buyer"] = 332,
                        ["wasKiosk"] = false,
                        ["seller"] = 573,
                        ["timestamp"] = 1633211980,
                        ["quant"] = 1,
                        ["id"] = "1691928705",
                        ["itemLink"] = 770,
                    },
                    [14] = 
                    {
                        ["price"] = 41000,
                        ["guild"] = 1,
                        ["buyer"] = 332,
                        ["wasKiosk"] = false,
                        ["seller"] = 615,
                        ["timestamp"] = 1633211982,
                        ["quant"] = 1,
                        ["id"] = "1691928747",
                        ["itemLink"] = 770,
                    },
                    [15] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1465,
                        ["wasKiosk"] = true,
                        ["seller"] = 827,
                        ["timestamp"] = 1633217497,
                        ["quant"] = 1,
                        ["id"] = "1691985499",
                        ["itemLink"] = 770,
                    },
                    [16] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 75,
                        ["timestamp"] = 1633234411,
                        ["quant"] = 1,
                        ["id"] = "1692156989",
                        ["itemLink"] = 770,
                    },
                    [17] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633234412,
                        ["quant"] = 1,
                        ["id"] = "1692156995",
                        ["itemLink"] = 770,
                    },
                    [18] = 
                    {
                        ["price"] = 45960,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 152,
                        ["timestamp"] = 1633234415,
                        ["quant"] = 1,
                        ["id"] = "1692157019",
                        ["itemLink"] = 770,
                    },
                    [19] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633250696,
                        ["quant"] = 1,
                        ["id"] = "1692274973",
                        ["itemLink"] = 770,
                    },
                    [20] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 86,
                        ["timestamp"] = 1633250697,
                        ["quant"] = 1,
                        ["id"] = "1692274981",
                        ["itemLink"] = 770,
                    },
                    [21] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 153,
                        ["timestamp"] = 1633250700,
                        ["quant"] = 1,
                        ["id"] = "1692275013",
                        ["itemLink"] = 770,
                    },
                    [22] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 153,
                        ["timestamp"] = 1633250702,
                        ["quant"] = 1,
                        ["id"] = "1692275023",
                        ["itemLink"] = 770,
                    },
                    [23] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 845,
                        ["timestamp"] = 1633250704,
                        ["quant"] = 1,
                        ["id"] = "1692275051",
                        ["itemLink"] = 770,
                    },
                    [24] = 
                    {
                        ["price"] = 34500,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 491,
                        ["timestamp"] = 1633284043,
                        ["quant"] = 1,
                        ["id"] = "1692556121",
                        ["itemLink"] = 770,
                    },
                    [25] = 
                    {
                        ["price"] = 37000,
                        ["guild"] = 1,
                        ["buyer"] = 2000,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1633293468,
                        ["quant"] = 1,
                        ["id"] = "1692668819",
                        ["itemLink"] = 770,
                    },
                    [26] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 2000,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633293470,
                        ["quant"] = 1,
                        ["id"] = "1692668851",
                        ["itemLink"] = 770,
                    },
                    [27] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 2000,
                        ["wasKiosk"] = true,
                        ["seller"] = 552,
                        ["timestamp"] = 1633293472,
                        ["quant"] = 1,
                        ["id"] = "1692668897",
                        ["itemLink"] = 770,
                    },
                    [28] = 
                    {
                        ["price"] = 50500,
                        ["guild"] = 1,
                        ["buyer"] = 2000,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633293473,
                        ["quant"] = 1,
                        ["id"] = "1692668919",
                        ["itemLink"] = 770,
                    },
                    [29] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 2000,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633293474,
                        ["quant"] = 1,
                        ["id"] = "1692668933",
                        ["itemLink"] = 770,
                    },
                },
                ["totalCount"] = 29,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [98922] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_medium_shoulders_d.dds",
                ["itemDesc"] = "Swamp Raider's Arm Cops",
                ["oldestTime"] = 1632981830,
                ["wasAltered"] = true,
                ["newestTime"] = 1632981830,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 280,
                        ["wasKiosk"] = true,
                        ["seller"] = 281,
                        ["timestamp"] = 1632981830,
                        ["quant"] = 1,
                        ["id"] = "1690140895",
                        ["itemLink"] = 290,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set swamp raider shoulders divines",
            },
        },
        [175552] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Blackwood Treasure Map VI",
                ["oldestTime"] = 1632948554,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293472,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 54400,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 491,
                        ["timestamp"] = 1633057663,
                        ["quant"] = 1,
                        ["id"] = "1690687243",
                        ["itemLink"] = 971,
                    },
                    [2] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 315,
                        ["wasKiosk"] = false,
                        ["seller"] = 408,
                        ["timestamp"] = 1633057667,
                        ["quant"] = 1,
                        ["id"] = "1690687257",
                        ["itemLink"] = 971,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 845,
                        ["wasKiosk"] = false,
                        ["seller"] = 343,
                        ["timestamp"] = 1633071280,
                        ["quant"] = 1,
                        ["id"] = "1690786025",
                        ["itemLink"] = 971,
                    },
                    [4] = 
                    {
                        ["price"] = 48000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 845,
                        ["timestamp"] = 1633075826,
                        ["quant"] = 1,
                        ["id"] = "1690815849",
                        ["itemLink"] = 971,
                    },
                    [5] = 
                    {
                        ["price"] = 44444,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 93,
                        ["timestamp"] = 1633075827,
                        ["quant"] = 1,
                        ["id"] = "1690815853",
                        ["itemLink"] = 971,
                    },
                    [6] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1122,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633132902,
                        ["quant"] = 1,
                        ["id"] = "1691218287",
                        ["itemLink"] = 971,
                    },
                    [7] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 1234,
                        ["timestamp"] = 1633146745,
                        ["quant"] = 1,
                        ["id"] = "1691363285",
                        ["itemLink"] = 971,
                    },
                    [8] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633146748,
                        ["quant"] = 1,
                        ["id"] = "1691363307",
                        ["itemLink"] = 971,
                    },
                    [9] = 
                    {
                        ["price"] = 55000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 513,
                        ["timestamp"] = 1633146774,
                        ["quant"] = 1,
                        ["id"] = "1691363633",
                        ["itemLink"] = 971,
                    },
                    [10] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 332,
                        ["wasKiosk"] = false,
                        ["seller"] = 1128,
                        ["timestamp"] = 1633211935,
                        ["quant"] = 1,
                        ["id"] = "1691927923",
                        ["itemLink"] = 971,
                    },
                    [11] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 332,
                        ["wasKiosk"] = false,
                        ["seller"] = 930,
                        ["timestamp"] = 1633211975,
                        ["quant"] = 1,
                        ["id"] = "1691928615",
                        ["itemLink"] = 971,
                    },
                    [12] = 
                    {
                        ["price"] = 48000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 153,
                        ["timestamp"] = 1633234410,
                        ["quant"] = 1,
                        ["id"] = "1692156979",
                        ["itemLink"] = 971,
                    },
                    [13] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633250695,
                        ["quant"] = 1,
                        ["id"] = "1692274959",
                        ["itemLink"] = 971,
                    },
                    [14] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633250697,
                        ["quant"] = 1,
                        ["id"] = "1692274977",
                        ["itemLink"] = 971,
                    },
                    [15] = 
                    {
                        ["price"] = 47000,
                        ["guild"] = 1,
                        ["buyer"] = 2000,
                        ["wasKiosk"] = true,
                        ["seller"] = 50,
                        ["timestamp"] = 1633293471,
                        ["quant"] = 1,
                        ["id"] = "1692668867",
                        ["itemLink"] = 971,
                    },
                    [16] = 
                    {
                        ["price"] = 47000,
                        ["guild"] = 1,
                        ["buyer"] = 2000,
                        ["wasKiosk"] = true,
                        ["seller"] = 50,
                        ["timestamp"] = 1633293472,
                        ["quant"] = 1,
                        ["id"] = "1692668881",
                        ["itemLink"] = 971,
                    },
                    [17] = 
                    {
                        ["price"] = 61000,
                        ["guild"] = 1,
                        ["buyer"] = 2576,
                        ["wasKiosk"] = true,
                        ["seller"] = 377,
                        ["timestamp"] = 1632948554,
                        ["quant"] = 1,
                        ["id"] = "1689862217",
                        ["itemLink"] = 971,
                    },
                    [18] = 
                    {
                        ["price"] = 65789,
                        ["guild"] = 1,
                        ["buyer"] = 2598,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1632952730,
                        ["quant"] = 1,
                        ["id"] = "1689898601",
                        ["itemLink"] = 971,
                    },
                },
                ["totalCount"] = 18,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [172225] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_1hsword_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Sword",
                ["oldestTime"] = 1633135307,
                ["wasAltered"] = true,
                ["newestTime"] = 1633135307,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1140,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633135307,
                        ["quant"] = 1,
                        ["id"] = "1691245739",
                        ["itemLink"] = 1559,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set deadlands assassin sword one-handed charged",
            },
        },
        [77506] = 
        {
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_darkbrotherhoodv2_light_shirt_a.dds",
                ["itemDesc"] = "Sithis' Jerkin",
                ["oldestTime"] = 1633022973,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022973,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 425,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1633022973,
                        ["quant"] = 1,
                        ["id"] = "1690390361",
                        ["itemLink"] = 613,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set sithis' touch chest training",
            },
        },
        [172227] = 
        {
            ["50:16:4:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_2hhammer_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Maul",
                ["oldestTime"] = 1633199583,
                ["wasAltered"] = true,
                ["newestTime"] = 1633199583,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1479,
                        ["wasKiosk"] = true,
                        ["seller"] = 6,
                        ["timestamp"] = 1633199583,
                        ["quant"] = 1,
                        ["id"] = "1691785043",
                        ["itemLink"] = 2180,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set deadlands assassin mace two-handed charged",
            },
        },
        [141819] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_sum_caesalpinia002.dds",
                ["itemDesc"] = "Shrub, Blooming Sunbird",
                ["oldestTime"] = 1633238269,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238269,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1745,
                        ["wasKiosk"] = true,
                        ["seller"] = 1747,
                        ["timestamp"] = 1633238269,
                        ["quant"] = 2,
                        ["id"] = "1692187399",
                        ["itemLink"] = 2513,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings conservatory",
            },
        },
        [27059] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_malt_003.dds",
                ["itemDesc"] = "Bervez Juice",
                ["oldestTime"] = 1632867505,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305878,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 199,
                        ["wasKiosk"] = false,
                        ["seller"] = 166,
                        ["timestamp"] = 1633043335,
                        ["quant"] = 20,
                        ["id"] = "1690540555",
                        ["itemLink"] = 835,
                    },
                    [2] = 
                    {
                        ["price"] = 11113,
                        ["guild"] = 1,
                        ["buyer"] = 1400,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633196935,
                        ["quant"] = 100,
                        ["id"] = "1691757843",
                        ["itemLink"] = 835,
                    },
                    [3] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 73,
                        ["wasKiosk"] = false,
                        ["seller"] = 1,
                        ["timestamp"] = 1633219276,
                        ["quant"] = 100,
                        ["id"] = "1692005289",
                        ["itemLink"] = 835,
                    },
                    [4] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1896,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1633274516,
                        ["quant"] = 20,
                        ["id"] = "1692457399",
                        ["itemLink"] = 835,
                    },
                    [5] = 
                    {
                        ["price"] = 25400,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633305873,
                        ["quant"] = 200,
                        ["id"] = "1692799171",
                        ["itemLink"] = 835,
                    },
                    [6] = 
                    {
                        ["price"] = 25400,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633305874,
                        ["quant"] = 200,
                        ["id"] = "1692799179",
                        ["itemLink"] = 835,
                    },
                    [7] = 
                    {
                        ["price"] = 25400,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633305874,
                        ["quant"] = 200,
                        ["id"] = "1692799191",
                        ["itemLink"] = 835,
                    },
                    [8] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 6,
                        ["timestamp"] = 1633305878,
                        ["quant"] = 8,
                        ["id"] = "1692799201",
                        ["itemLink"] = 835,
                    },
                    [9] = 
                    {
                        ["price"] = 23995,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 322,
                        ["timestamp"] = 1632867505,
                        ["quant"] = 200,
                        ["id"] = "1689284179",
                        ["itemLink"] = 835,
                    },
                },
                ["totalCount"] = 9,
                ["itemAdderText"] = "rr01 purple epic materials ingredient",
            },
        },
        [151750] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_inc_rugmedium002.dds",
                ["itemDesc"] = "Elsweyr Carpet, Sandflowers",
                ["oldestTime"] = 1633252574,
                ["wasAltered"] = true,
                ["newestTime"] = 1633252574,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11445,
                        ["guild"] = 1,
                        ["buyer"] = 1824,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1633252574,
                        ["quant"] = 1,
                        ["id"] = "1692289419",
                        ["itemLink"] = 2609,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings parlor",
            },
        },
        [167367] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Solitude Foot Bridge, Wood-Planked",
                ["oldestTime"] = 1632930611,
                ["wasAltered"] = true,
                ["newestTime"] = 1633040334,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 623,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633040334,
                        ["quant"] = 1,
                        ["id"] = "1690515755",
                        ["itemLink"] = 797,
                    },
                    [2] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 2194,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632930611,
                        ["quant"] = 1,
                        ["id"] = "1689726641",
                        ["itemLink"] = 797,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [81310] = 
        {
            ["50:16:2:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_shield_a.dds",
                ["itemDesc"] = "Sandstone Guard of the Fire",
                ["oldestTime"] = 1633226386,
                ["wasAltered"] = true,
                ["newestTime"] = 1633226386,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1013,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633226386,
                        ["quant"] = 1,
                        ["id"] = "1692078685",
                        ["itemLink"] = 2398,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine apparel weapon set way of fire shield off hand sturdy",
            },
        },
        [176585] = 
        {
            ["1:0:3:47:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_gloves_light.dds",
                ["itemDesc"] = "Companion's Gloves",
                ["oldestTime"] = 1632853636,
                ["wasAltered"] = true,
                ["newestTime"] = 1632853636,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1999,
                        ["guild"] = 1,
                        ["buyer"] = 2227,
                        ["wasKiosk"] = true,
                        ["seller"] = 451,
                        ["timestamp"] = 1632853636,
                        ["quant"] = 1,
                        ["id"] = "1689172503",
                        ["itemLink"] = 3257,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior light apparel hands aggressive",
            },
        },
        [147658] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_metals_dwarven_scrap.dds",
                ["itemDesc"] = "Festive Noise Maker Parts",
                ["oldestTime"] = 1633165385,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165385,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5998,
                        ["guild"] = 1,
                        ["buyer"] = 1320,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633165385,
                        ["quant"] = 2,
                        ["id"] = "1691497911",
                        ["itemLink"] = 1836,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable trophy",
            },
        },
        [176599] = 
        {
            ["1:0:3:56:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_ring.dds",
                ["itemDesc"] = "Companion's Ring",
                ["oldestTime"] = 1633208533,
                ["wasAltered"] = true,
                ["newestTime"] = 1633208533,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1329,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633208533,
                        ["quant"] = 1,
                        ["id"] = "1691888353",
                        ["itemLink"] = 2264,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior jewelry apparel ring aggressive",
            },
        },
        [180428] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Amulet of Dark Convergence",
                ["oldestTime"] = 1633058809,
                ["wasAltered"] = true,
                ["newestTime"] = 1633080882,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 109000,
                        ["guild"] = 1,
                        ["buyer"] = 403,
                        ["wasKiosk"] = true,
                        ["seller"] = 28,
                        ["timestamp"] = 1633058809,
                        ["quant"] = 1,
                        ["id"] = "1690698799",
                        ["itemLink"] = 991,
                    },
                    [2] = 
                    {
                        ["price"] = 109000,
                        ["guild"] = 1,
                        ["buyer"] = 883,
                        ["wasKiosk"] = true,
                        ["seller"] = 28,
                        ["timestamp"] = 1633080882,
                        ["quant"] = 1,
                        ["id"] = "1690838945",
                        ["itemLink"] = 991,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set dark convergence neck arcane",
            },
        },
        [171469] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/monster_skeleton_arm_bone_001.dds",
                ["itemDesc"] = "Breton Terrier Mammoth Bone",
                ["oldestTime"] = 1633165383,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294630,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 1320,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633165383,
                        ["quant"] = 3,
                        ["id"] = "1691497893",
                        ["itemLink"] = 1834,
                    },
                    [2] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2009,
                        ["wasKiosk"] = true,
                        ["seller"] = 493,
                        ["timestamp"] = 1633294630,
                        ["quant"] = 1,
                        ["id"] = "1692685501",
                        ["itemLink"] = 1834,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [64718] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 19: Mercenary Boots",
                ["oldestTime"] = 1633311515,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311515,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 14,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633311515,
                        ["quant"] = 1,
                        ["id"] = "1692865269",
                        ["itemLink"] = 10,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [30159] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_flower_wormwood_r1.dds",
                ["itemDesc"] = "Wormwood",
                ["oldestTime"] = 1632830237,
                ["wasAltered"] = true,
                ["newestTime"] = 1633251978,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12500,
                        ["guild"] = 1,
                        ["buyer"] = 751,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1633055732,
                        ["quant"] = 100,
                        ["id"] = "1690661563",
                        ["itemLink"] = 949,
                    },
                    [2] = 
                    {
                        ["price"] = 12500,
                        ["guild"] = 1,
                        ["buyer"] = 89,
                        ["wasKiosk"] = true,
                        ["seller"] = 230,
                        ["timestamp"] = 1633151433,
                        ["quant"] = 100,
                        ["id"] = "1691403897",
                        ["itemLink"] = 949,
                    },
                    [3] = 
                    {
                        ["price"] = 720,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633154414,
                        ["quant"] = 8,
                        ["id"] = "1691427097",
                        ["itemLink"] = 949,
                    },
                    [4] = 
                    {
                        ["price"] = 5400,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633154450,
                        ["quant"] = 54,
                        ["id"] = "1691427291",
                        ["itemLink"] = 949,
                    },
                    [5] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 1350,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1633175166,
                        ["quant"] = 10,
                        ["id"] = "1691547681",
                        ["itemLink"] = 949,
                    },
                    [6] = 
                    {
                        ["price"] = 13600,
                        ["guild"] = 1,
                        ["buyer"] = 1464,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633197759,
                        ["quant"] = 100,
                        ["id"] = "1691766469",
                        ["itemLink"] = 949,
                    },
                    [7] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633251978,
                        ["quant"] = 8,
                        ["id"] = "1692285125",
                        ["itemLink"] = 949,
                    },
                    [8] = 
                    {
                        ["price"] = 12999,
                        ["guild"] = 1,
                        ["buyer"] = 2132,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1632830237,
                        ["quant"] = 100,
                        ["id"] = "1688999617",
                        ["itemLink"] = 949,
                    },
                    [9] = 
                    {
                        ["price"] = 6138,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632861614,
                        ["quant"] = 62,
                        ["id"] = "1689241863",
                        ["itemLink"] = 949,
                    },
                },
                ["totalCount"] = 9,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [156624] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/item_u25_aeonstoneshard.dds",
                ["itemDesc"] = "Aeonstone Shard",
                ["oldestTime"] = 1633211168,
                ["wasAltered"] = true,
                ["newestTime"] = 1633211168,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 508,
                        ["wasKiosk"] = false,
                        ["seller"] = 957,
                        ["timestamp"] = 1633211168,
                        ["quant"] = 20,
                        ["id"] = "1691917189",
                        ["itemLink"] = 2280,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [129999] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 51: Hlaalu Chests",
                ["oldestTime"] = 1633209251,
                ["wasAltered"] = true,
                ["newestTime"] = 1633209251,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1544,
                        ["wasKiosk"] = true,
                        ["seller"] = 1214,
                        ["timestamp"] = 1633209251,
                        ["quant"] = 1,
                        ["id"] = "1691897597",
                        ["itemLink"] = 2269,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [56969] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Elsweyr Fondue",
                ["oldestTime"] = 1633115935,
                ["wasAltered"] = true,
                ["newestTime"] = 1633203124,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1024,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633115935,
                        ["quant"] = 1,
                        ["id"] = "1691078077",
                        ["itemLink"] = 1400,
                    },
                    [2] = 
                    {
                        ["price"] = 1099,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633203124,
                        ["quant"] = 1,
                        ["id"] = "1691824209",
                        ["itemLink"] = 1400,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [99283] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Sword-Singer's Ring",
                ["oldestTime"] = 1633277731,
                ["wasAltered"] = true,
                ["newestTime"] = 1633277731,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1913,
                        ["wasKiosk"] = true,
                        ["seller"] = 655,
                        ["timestamp"] = 1633277731,
                        ["quant"] = 1,
                        ["id"] = "1692492921",
                        ["itemLink"] = 2712,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set sword-singer ring robust",
            },
        },
        [30164] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_flower_columbine_r1.dds",
                ["itemDesc"] = "Columbine",
                ["oldestTime"] = 1632878236,
                ["wasAltered"] = true,
                ["newestTime"] = 1633308481,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 147400,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1632981496,
                        ["quant"] = 200,
                        ["id"] = "1690139197",
                        ["itemLink"] = 287,
                    },
                    [2] = 
                    {
                        ["price"] = 74000,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1632981498,
                        ["quant"] = 100,
                        ["id"] = "1690139207",
                        ["itemLink"] = 287,
                    },
                    [3] = 
                    {
                        ["price"] = 74000,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1632981499,
                        ["quant"] = 100,
                        ["id"] = "1690139211",
                        ["itemLink"] = 287,
                    },
                    [4] = 
                    {
                        ["price"] = 74000,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1632981500,
                        ["quant"] = 100,
                        ["id"] = "1690139217",
                        ["itemLink"] = 287,
                    },
                    [5] = 
                    {
                        ["price"] = 79999,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 277,
                        ["timestamp"] = 1632981501,
                        ["quant"] = 100,
                        ["id"] = "1690139225",
                        ["itemLink"] = 287,
                    },
                    [6] = 
                    {
                        ["price"] = 3650,
                        ["guild"] = 1,
                        ["buyer"] = 422,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1633006530,
                        ["quant"] = 5,
                        ["id"] = "1690268199",
                        ["itemLink"] = 287,
                    },
                    [7] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1103,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633130420,
                        ["quant"] = 10,
                        ["id"] = "1691190381",
                        ["itemLink"] = 287,
                    },
                    [8] = 
                    {
                        ["price"] = 14413,
                        ["guild"] = 1,
                        ["buyer"] = 1103,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633130424,
                        ["quant"] = 20,
                        ["id"] = "1691190423",
                        ["itemLink"] = 287,
                    },
                    [9] = 
                    {
                        ["price"] = 14413,
                        ["guild"] = 1,
                        ["buyer"] = 1103,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633130424,
                        ["quant"] = 20,
                        ["id"] = "1691190435",
                        ["itemLink"] = 287,
                    },
                    [10] = 
                    {
                        ["price"] = 3615,
                        ["guild"] = 1,
                        ["buyer"] = 1103,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633130426,
                        ["quant"] = 5,
                        ["id"] = "1691190469",
                        ["itemLink"] = 287,
                    },
                    [11] = 
                    {
                        ["price"] = 4338,
                        ["guild"] = 1,
                        ["buyer"] = 1103,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633130427,
                        ["quant"] = 6,
                        ["id"] = "1691190487",
                        ["itemLink"] = 287,
                    },
                    [12] = 
                    {
                        ["price"] = 142000,
                        ["guild"] = 1,
                        ["buyer"] = 1106,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633131079,
                        ["quant"] = 200,
                        ["id"] = "1691197467",
                        ["itemLink"] = 287,
                    },
                    [13] = 
                    {
                        ["price"] = 18328,
                        ["guild"] = 1,
                        ["buyer"] = 1125,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633133406,
                        ["quant"] = 25,
                        ["id"] = "1691224151",
                        ["itemLink"] = 287,
                    },
                    [14] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1224,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633144945,
                        ["quant"] = 10,
                        ["id"] = "1691346757",
                        ["itemLink"] = 287,
                    },
                    [15] = 
                    {
                        ["price"] = 128000,
                        ["guild"] = 1,
                        ["buyer"] = 1242,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633147981,
                        ["quant"] = 200,
                        ["id"] = "1691373787",
                        ["itemLink"] = 287,
                    },
                    [16] = 
                    {
                        ["price"] = 64000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 95,
                        ["timestamp"] = 1633147997,
                        ["quant"] = 100,
                        ["id"] = "1691373855",
                        ["itemLink"] = 287,
                    },
                    [17] = 
                    {
                        ["price"] = 21780,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633154451,
                        ["quant"] = 33,
                        ["id"] = "1691427301",
                        ["itemLink"] = 287,
                    },
                    [18] = 
                    {
                        ["price"] = 21780,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633154452,
                        ["quant"] = 33,
                        ["id"] = "1691427315",
                        ["itemLink"] = 287,
                    },
                    [19] = 
                    {
                        ["price"] = 12800,
                        ["guild"] = 1,
                        ["buyer"] = 1511,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633203820,
                        ["quant"] = 20,
                        ["id"] = "1691831207",
                        ["itemLink"] = 287,
                    },
                    [20] = 
                    {
                        ["price"] = 12800,
                        ["guild"] = 1,
                        ["buyer"] = 1527,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633206308,
                        ["quant"] = 20,
                        ["id"] = "1691858847",
                        ["itemLink"] = 287,
                    },
                    [21] = 
                    {
                        ["price"] = 12800,
                        ["guild"] = 1,
                        ["buyer"] = 1527,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633206311,
                        ["quant"] = 20,
                        ["id"] = "1691858875",
                        ["itemLink"] = 287,
                    },
                    [22] = 
                    {
                        ["price"] = 12800,
                        ["guild"] = 1,
                        ["buyer"] = 1527,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633206318,
                        ["quant"] = 20,
                        ["id"] = "1691858951",
                        ["itemLink"] = 287,
                    },
                    [23] = 
                    {
                        ["price"] = 12800,
                        ["guild"] = 1,
                        ["buyer"] = 1527,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633206323,
                        ["quant"] = 20,
                        ["id"] = "1691859029",
                        ["itemLink"] = 287,
                    },
                    [24] = 
                    {
                        ["price"] = 14361,
                        ["guild"] = 1,
                        ["buyer"] = 1532,
                        ["wasKiosk"] = true,
                        ["seller"] = 711,
                        ["timestamp"] = 1633206900,
                        ["quant"] = 20,
                        ["id"] = "1691866859",
                        ["itemLink"] = 287,
                    },
                    [25] = 
                    {
                        ["price"] = 73000,
                        ["guild"] = 1,
                        ["buyer"] = 1532,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633206901,
                        ["quant"] = 100,
                        ["id"] = "1691866867",
                        ["itemLink"] = 287,
                    },
                    [26] = 
                    {
                        ["price"] = 3700,
                        ["guild"] = 1,
                        ["buyer"] = 750,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633227274,
                        ["quant"] = 6,
                        ["id"] = "1692087915",
                        ["itemLink"] = 287,
                    },
                    [27] = 
                    {
                        ["price"] = 9600,
                        ["guild"] = 1,
                        ["buyer"] = 750,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633227276,
                        ["quant"] = 15,
                        ["id"] = "1692087929",
                        ["itemLink"] = 287,
                    },
                    [28] = 
                    {
                        ["price"] = 150000,
                        ["guild"] = 1,
                        ["buyer"] = 1710,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633232956,
                        ["quant"] = 200,
                        ["id"] = "1692144507",
                        ["itemLink"] = 287,
                    },
                    [29] = 
                    {
                        ["price"] = 2400,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633234901,
                        ["quant"] = 4,
                        ["id"] = "1692160275",
                        ["itemLink"] = 287,
                    },
                    [30] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1867,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633267967,
                        ["quant"] = 2,
                        ["id"] = "1692384599",
                        ["itemLink"] = 287,
                    },
                    [31] = 
                    {
                        ["price"] = 79000,
                        ["guild"] = 1,
                        ["buyer"] = 2077,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633308481,
                        ["quant"] = 100,
                        ["id"] = "1692828343",
                        ["itemLink"] = 287,
                    },
                    [32] = 
                    {
                        ["price"] = 79000,
                        ["guild"] = 1,
                        ["buyer"] = 2077,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633308481,
                        ["quant"] = 100,
                        ["id"] = "1692828347",
                        ["itemLink"] = 287,
                    },
                    [33] = 
                    {
                        ["price"] = 72999,
                        ["guild"] = 1,
                        ["buyer"] = 2341,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1632878236,
                        ["quant"] = 100,
                        ["id"] = "1689374343",
                        ["itemLink"] = 287,
                    },
                    [34] = 
                    {
                        ["price"] = 14500,
                        ["guild"] = 1,
                        ["buyer"] = 2341,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632878237,
                        ["quant"] = 20,
                        ["id"] = "1689374371",
                        ["itemLink"] = 287,
                    },
                    [35] = 
                    {
                        ["price"] = 2892,
                        ["guild"] = 1,
                        ["buyer"] = 2341,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632878238,
                        ["quant"] = 4,
                        ["id"] = "1689374387",
                        ["itemLink"] = 287,
                    },
                    [36] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 2113,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632961659,
                        ["quant"] = 3,
                        ["id"] = "1689972201",
                        ["itemLink"] = 287,
                    },
                },
                ["totalCount"] = 36,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [166869] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Solitude Bookcase, Narrow Rustic Filled",
                ["oldestTime"] = 1633205019,
                ["wasAltered"] = true,
                ["newestTime"] = 1633205019,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 44000,
                        ["guild"] = 1,
                        ["buyer"] = 1520,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633205019,
                        ["quant"] = 1,
                        ["id"] = "1691842559",
                        ["itemLink"] = 2243,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [140502] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 67: Welkynar Daggers",
                ["oldestTime"] = 1633214386,
                ["wasAltered"] = true,
                ["newestTime"] = 1633214386,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1570,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633214386,
                        ["quant"] = 1,
                        ["id"] = "1691953561",
                        ["itemLink"] = 2299,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [180439] = 
        {
            ["50:16:4:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_staff_a.dds",
                ["itemDesc"] = "Lightning Staff of Dark Convergence",
                ["oldestTime"] = 1633052765,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052765,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5432,
                        ["guild"] = 1,
                        ["buyer"] = 718,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633052765,
                        ["quant"] = 1,
                        ["id"] = "1690632847",
                        ["itemLink"] = 913,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set dark convergence lightning staff two-handed infused",
            },
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_staff_a.dds",
                ["itemDesc"] = "Lightning Staff of Dark Convergence",
                ["oldestTime"] = 1632904654,
                ["wasAltered"] = true,
                ["newestTime"] = 1632904654,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 68750,
                        ["guild"] = 1,
                        ["buyer"] = 1259,
                        ["wasKiosk"] = true,
                        ["seller"] = 1438,
                        ["timestamp"] = 1632904654,
                        ["quant"] = 1,
                        ["id"] = "1689581061",
                        ["itemLink"] = 3582,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set dark convergence lightning staff two-handed infused",
            },
        },
        [119694] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_clothier.dds",
                ["itemDesc"] = "Sealed Clothier Writ",
                ["oldestTime"] = 1632841224,
                ["wasAltered"] = true,
                ["newestTime"] = 1633302426,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 248,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632978038,
                        ["quant"] = 1,
                        ["id"] = "1690118255",
                        ["itemLink"] = 248,
                    },
                    [2] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 387,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632998459,
                        ["quant"] = 1,
                        ["id"] = "1690224499",
                        ["itemLink"] = 387,
                    },
                    [3] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 210,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633063791,
                        ["quant"] = 1,
                        ["id"] = "1690739123",
                        ["itemLink"] = 1042,
                    },
                    [4] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 956,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633102889,
                        ["quant"] = 1,
                        ["id"] = "1690982761",
                        ["itemLink"] = 1289,
                    },
                    [5] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 930,
                        ["timestamp"] = 1633111850,
                        ["quant"] = 1,
                        ["id"] = "1691050755",
                        ["itemLink"] = 1333,
                    },
                    [6] = 
                    {
                        ["price"] = 2631,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633111855,
                        ["quant"] = 1,
                        ["id"] = "1691050833",
                        ["itemLink"] = 1339,
                    },
                    [7] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 332,
                        ["timestamp"] = 1633125269,
                        ["quant"] = 1,
                        ["id"] = "1691144729",
                        ["itemLink"] = 1469,
                    },
                    [8] = 
                    {
                        ["price"] = 2850,
                        ["guild"] = 1,
                        ["buyer"] = 1252,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1633149787,
                        ["quant"] = 1,
                        ["id"] = "1691388937",
                        ["itemLink"] = 1712,
                    },
                    [9] = 
                    {
                        ["price"] = 2929,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633190083,
                        ["quant"] = 1,
                        ["id"] = "1691688357",
                        ["itemLink"] = 2096,
                    },
                    [10] = 
                    {
                        ["price"] = 2100,
                        ["guild"] = 1,
                        ["buyer"] = 1428,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633192415,
                        ["quant"] = 1,
                        ["id"] = "1691717231",
                        ["itemLink"] = 2114,
                    },
                    [11] = 
                    {
                        ["price"] = 2450,
                        ["guild"] = 1,
                        ["buyer"] = 1428,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633192416,
                        ["quant"] = 1,
                        ["id"] = "1691717245",
                        ["itemLink"] = 2116,
                    },
                    [12] = 
                    {
                        ["price"] = 2800,
                        ["guild"] = 1,
                        ["buyer"] = 1466,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633197884,
                        ["quant"] = 1,
                        ["id"] = "1691768089",
                        ["itemLink"] = 2154,
                    },
                    [13] = 
                    {
                        ["price"] = 2911,
                        ["guild"] = 1,
                        ["buyer"] = 1951,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633285565,
                        ["quant"] = 1,
                        ["id"] = "1692572285",
                        ["itemLink"] = 2752,
                    },
                    [14] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 622,
                        ["timestamp"] = 1633302426,
                        ["quant"] = 1,
                        ["id"] = "1692765815",
                        ["itemLink"] = 2920,
                    },
                    [15] = 
                    {
                        ["price"] = 1945,
                        ["guild"] = 1,
                        ["buyer"] = 2155,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1632841224,
                        ["quant"] = 1,
                        ["id"] = "1689069029",
                        ["itemLink"] = 3154,
                    },
                    [16] = 
                    {
                        ["price"] = 1848,
                        ["guild"] = 1,
                        ["buyer"] = 2155,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1632841228,
                        ["quant"] = 1,
                        ["id"] = "1689069061",
                        ["itemLink"] = 3155,
                    },
                    [17] = 
                    {
                        ["price"] = 3200,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 201,
                        ["timestamp"] = 1632894583,
                        ["quant"] = 1,
                        ["id"] = "1689527183",
                        ["itemLink"] = 3553,
                    },
                    [18] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 2466,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632912299,
                        ["quant"] = 1,
                        ["id"] = "1689609661",
                        ["itemLink"] = 3617,
                    },
                    [19] = 
                    {
                        ["price"] = 2499,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1632925738,
                        ["quant"] = 1,
                        ["id"] = "1689692495",
                        ["itemLink"] = 3687,
                    },
                },
                ["totalCount"] = 19,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [129728] = 
        {
            ["50:16:4:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_dagger_c.dds",
                ["itemDesc"] = "Briarheart Dagger",
                ["oldestTime"] = 1633206058,
                ["wasAltered"] = true,
                ["newestTime"] = 1633206058,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 65000,
                        ["guild"] = 1,
                        ["buyer"] = 1526,
                        ["wasKiosk"] = true,
                        ["seller"] = 696,
                        ["timestamp"] = 1633206058,
                        ["quant"] = 1,
                        ["id"] = "1691855999",
                        ["itemLink"] = 2251,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set briarheart dagger one-handed charged",
            },
        },
        [120593] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_tre_trp_greenshdsaplings003.dds",
                ["itemDesc"] = "Saplings, Twin Highland",
                ["oldestTime"] = 1632851062,
                ["wasAltered"] = true,
                ["newestTime"] = 1632970778,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 174,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1632970778,
                        ["quant"] = 1,
                        ["id"] = "1690064053",
                        ["itemLink"] = 186,
                    },
                    [2] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 175,
                        ["wasKiosk"] = false,
                        ["seller"] = 73,
                        ["timestamp"] = 1632851062,
                        ["quant"] = 1,
                        ["id"] = "1689152357",
                        ["itemLink"] = 186,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal furnishings conservatory",
            },
        },
        [56027] = 
        {
            ["1:0:1:26:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_1hhammer_a.dds",
                ["itemDesc"] = "Iron Mace",
                ["oldestTime"] = 1633097030,
                ["wasAltered"] = true,
                ["newestTime"] = 1633097030,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 902,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633097030,
                        ["quant"] = 1,
                        ["id"] = "1690936455",
                        ["itemLink"] = 1267,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal weapon mace one-handed nirnhoned",
            },
        },
        [46013] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Winter Rose Tea",
                ["oldestTime"] = 1633140922,
                ["wasAltered"] = true,
                ["newestTime"] = 1633140922,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 54,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633140922,
                        ["quant"] = 1,
                        ["id"] = "1691300601",
                        ["itemLink"] = 1604,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [167275] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 94: Ancestral Reach Chests",
                ["oldestTime"] = 1632854044,
                ["wasAltered"] = true,
                ["newestTime"] = 1633198090,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350000,
                        ["guild"] = 1,
                        ["buyer"] = 1471,
                        ["wasKiosk"] = true,
                        ["seller"] = 315,
                        ["timestamp"] = 1633198090,
                        ["quant"] = 1,
                        ["id"] = "1691770117",
                        ["itemLink"] = 2158,
                    },
                    [2] = 
                    {
                        ["price"] = 300000,
                        ["guild"] = 1,
                        ["buyer"] = 2229,
                        ["wasKiosk"] = true,
                        ["seller"] = 315,
                        ["timestamp"] = 1632854044,
                        ["quant"] = 1,
                        ["id"] = "1689175875",
                        ["itemLink"] = 2158,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [172247] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_2hhammer_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Maul",
                ["oldestTime"] = 1633186390,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186390,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2213,
                        ["guild"] = 1,
                        ["buyer"] = 1397,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633186390,
                        ["quant"] = 1,
                        ["id"] = "1691644905",
                        ["itemLink"] = 2072,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set deadlands assassin mace two-handed decisive",
            },
        },
        [149471] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_medium_shoulder_a.dds",
                ["itemDesc"] = "Darloc Brae's Arm Cops",
                ["oldestTime"] = 1632863666,
                ["wasAltered"] = true,
                ["newestTime"] = 1632863666,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100000,
                        ["guild"] = 1,
                        ["buyer"] = 2254,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1632863666,
                        ["quant"] = 1,
                        ["id"] = "1689256477",
                        ["itemLink"] = 3321,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set vesture of darloc brae shoulders divines",
            },
        },
        [43647] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Malabal Tor Treasure Map V",
                ["oldestTime"] = 1633182516,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182516,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 369,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182516,
                        ["quant"] = 1,
                        ["id"] = "1691608181",
                        ["itemLink"] = 1954,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [803] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_forester_weapon_component_006.dds",
                ["itemDesc"] = "Sanded Maple",
                ["oldestTime"] = 1632987691,
                ["wasAltered"] = true,
                ["newestTime"] = 1633134537,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 323,
                        ["wasKiosk"] = false,
                        ["seller"] = 331,
                        ["timestamp"] = 1632987691,
                        ["quant"] = 200,
                        ["id"] = "1690172785",
                        ["itemLink"] = 335,
                    },
                    [2] = 
                    {
                        ["price"] = 1368,
                        ["guild"] = 1,
                        ["buyer"] = 1132,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633134537,
                        ["quant"] = 200,
                        ["id"] = "1691236099",
                        ["itemLink"] = 335,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [156203] = 
        {
            ["50:16:3:33:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "New Moon Acolyte's Ring",
                ["oldestTime"] = 1633115823,
                ["wasAltered"] = true,
                ["newestTime"] = 1633115823,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1021,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633115823,
                        ["quant"] = 1,
                        ["id"] = "1691077355",
                        ["itemLink"] = 1396,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set new moon acolyte ring infused",
            },
        },
        [121531] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_woodworking.dds",
                ["itemDesc"] = "Sealed Woodworking Writ",
                ["oldestTime"] = 1632924316,
                ["wasAltered"] = true,
                ["newestTime"] = 1633275701,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20592,
                        ["guild"] = 1,
                        ["buyer"] = 538,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633024678,
                        ["quant"] = 1,
                        ["id"] = "1690403997",
                        ["itemLink"] = 676,
                    },
                    [2] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1355,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633176404,
                        ["quant"] = 1,
                        ["id"] = "1691557753",
                        ["itemLink"] = 1901,
                    },
                    [3] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 957,
                        ["timestamp"] = 1633184460,
                        ["quant"] = 1,
                        ["id"] = "1691624469",
                        ["itemLink"] = 1978,
                    },
                    [4] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633234723,
                        ["quant"] = 1,
                        ["id"] = "1692159091",
                        ["itemLink"] = 2470,
                    },
                    [5] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1449,
                        ["wasKiosk"] = true,
                        ["seller"] = 583,
                        ["timestamp"] = 1633275701,
                        ["quant"] = 1,
                        ["id"] = "1692472139",
                        ["itemLink"] = 2699,
                    },
                    [6] = 
                    {
                        ["price"] = 17000,
                        ["guild"] = 1,
                        ["buyer"] = 2495,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632924316,
                        ["quant"] = 1,
                        ["id"] = "1689681805",
                        ["itemLink"] = 3681,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 gold legendary consumable master writ",
            },
        },
        [117736] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_inc_rugsmall009.dds",
                ["itemDesc"] = "Redguard Mat, Sunset",
                ["oldestTime"] = 1633095783,
                ["wasAltered"] = true,
                ["newestTime"] = 1633095783,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2700,
                        ["guild"] = 1,
                        ["buyer"] = 927,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633095783,
                        ["quant"] = 1,
                        ["id"] = "1690925143",
                        ["itemLink"] = 1263,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings parlor",
            },
        },
        [120755] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_aqa_kelp_pile003.dds",
                ["itemDesc"] = "Kelp, Lush Pile",
                ["oldestTime"] = 1632981286,
                ["wasAltered"] = true,
                ["newestTime"] = 1632981286,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40,
                        ["guild"] = 1,
                        ["buyer"] = 268,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1632981286,
                        ["quant"] = 1,
                        ["id"] = "1690138023",
                        ["itemLink"] = 274,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings conservatory",
            },
        },
        [132582] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 57: Ebonshadow Axes",
                ["oldestTime"] = 1632852244,
                ["wasAltered"] = true,
                ["newestTime"] = 1632852244,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 161,
                        ["timestamp"] = 1632852244,
                        ["quant"] = 1,
                        ["id"] = "1689160799",
                        ["itemLink"] = 3252,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [119015] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Orcish Bench, Cabled",
                ["oldestTime"] = 1633140927,
                ["wasAltered"] = true,
                ["newestTime"] = 1633140927,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 70,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633140927,
                        ["quant"] = 1,
                        ["id"] = "1691300657",
                        ["itemLink"] = 1607,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [49128] = 
        {
            ["10:0:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_medium_head_b.dds",
                ["itemDesc"] = "Helmet of the Night Mother",
                ["oldestTime"] = 1632911081,
                ["wasAltered"] = true,
                ["newestTime"] = 1633308838,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 8,
                        ["wasKiosk"] = false,
                        ["seller"] = 426,
                        ["timestamp"] = 1633021940,
                        ["quant"] = 1,
                        ["id"] = "1690383373",
                        ["itemLink"] = 589,
                    },
                    [2] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2081,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633308838,
                        ["quant"] = 1,
                        ["id"] = "1692833429",
                        ["itemLink"] = 2964,
                    },
                    [3] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2463,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632911081,
                        ["quant"] = 1,
                        ["id"] = "1689604513",
                        ["itemLink"] = 589,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr10 blue superior medium apparel set night mother's gaze head training",
            },
        },
        [72888] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_heavy_head_a.dds",
                ["itemDesc"] = "Helm of Bahraha's Curse",
                ["oldestTime"] = 1633031508,
                ["wasAltered"] = true,
                ["newestTime"] = 1633031508,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 565,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1633031508,
                        ["quant"] = 1,
                        ["id"] = "1690454237",
                        ["itemLink"] = 720,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set bahraha's curse head divines",
            },
        },
        [57578] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 15: Dwemer Daggers",
                ["oldestTime"] = 1632941494,
                ["wasAltered"] = true,
                ["newestTime"] = 1633039112,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 619,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633039112,
                        ["quant"] = 1,
                        ["id"] = "1690507437",
                        ["itemLink"] = 782,
                    },
                    [2] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 2551,
                        ["wasKiosk"] = true,
                        ["seller"] = 1747,
                        ["timestamp"] = 1632941494,
                        ["quant"] = 1,
                        ["id"] = "1689805675",
                        ["itemLink"] = 782,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [97259] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_shoulders_d.dds",
                ["itemDesc"] = "Epaulets of a Mother's Sorrow",
                ["oldestTime"] = 1633112443,
                ["wasAltered"] = true,
                ["newestTime"] = 1633205312,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 995,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633112443,
                        ["quant"] = 1,
                        ["id"] = "1691055273",
                        ["itemLink"] = 1349,
                    },
                    [2] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 1522,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633205312,
                        ["quant"] = 1,
                        ["id"] = "1691845885",
                        ["itemLink"] = 1349,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic light apparel set mother's sorrow shoulders divines",
            },
        },
        [45036] = 
        {
            ["50:16:2:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_light_legs_d.dds",
                ["itemDesc"] = "Ancestor Silk Breeches of Health",
                ["oldestTime"] = 1632856608,
                ["wasAltered"] = true,
                ["newestTime"] = 1633126536,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1088,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633126536,
                        ["quant"] = 1,
                        ["id"] = "1691154347",
                        ["itemLink"] = 1490,
                    },
                    [2] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 1088,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1632856608,
                        ["quant"] = 1,
                        ["id"] = "1689202577",
                        ["itemLink"] = 3274,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine light apparel legs sturdy",
            },
        },
        [75067] = 
        {
            ["50:16:4:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_2hhammer_a.dds",
                ["itemDesc"] = "Maul of the Night Mother",
                ["oldestTime"] = 1633014395,
                ["wasAltered"] = true,
                ["newestTime"] = 1633014395,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 464,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633014395,
                        ["quant"] = 1,
                        ["id"] = "1690319245",
                        ["itemLink"] = 530,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set night mother's embrace mace two-handed infused",
            },
        },
        [2542] = 
        {
            ["50:5:2:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Carved Bone Medallion",
                ["oldestTime"] = 1632793707,
                ["wasAltered"] = true,
                ["newestTime"] = 1632793707,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 2,
                        ["buyer"] = 131,
                        ["wasKiosk"] = false,
                        ["seller"] = 132,
                        ["timestamp"] = 1632793707,
                        ["quant"] = 1,
                        ["id"] = "1688754569",
                        ["itemLink"] = 132,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp50 green fine jewelry apparel set night terror neck healthy",
            },
        },
        [49135] = 
        {
            ["10:0:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_1hsword_a.dds",
                ["itemDesc"] = "Sword of the Night Mother",
                ["oldestTime"] = 1632917502,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291837,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 425,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633006819,
                        ["quant"] = 1,
                        ["id"] = "1690269943",
                        ["itemLink"] = 436,
                    },
                    [2] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1858,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633266910,
                        ["quant"] = 1,
                        ["id"] = "1692374503",
                        ["itemLink"] = 2640,
                    },
                    [3] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1986,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633291837,
                        ["quant"] = 1,
                        ["id"] = "1692649697",
                        ["itemLink"] = 2640,
                    },
                    [4] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632917502,
                        ["quant"] = 1,
                        ["id"] = "1689638337",
                        ["itemLink"] = 436,
                    },
                    [5] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 2481,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1632919550,
                        ["quant"] = 1,
                        ["id"] = "1689649143",
                        ["itemLink"] = 436,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr10 blue superior weapon set night mother's gaze sword one-handed training",
            },
        },
        [167313] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_waf_solwallmediumstraight002.dds",
                ["itemDesc"] = "Solitude Wall, Stone",
                ["oldestTime"] = 1633044598,
                ["wasAltered"] = true,
                ["newestTime"] = 1633197964,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 664,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1633044598,
                        ["quant"] = 2,
                        ["id"] = "1690552705",
                        ["itemLink"] = 845,
                    },
                    [2] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1468,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1633197960,
                        ["quant"] = 2,
                        ["id"] = "1691769127",
                        ["itemLink"] = 845,
                    },
                    [3] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1468,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1633197962,
                        ["quant"] = 2,
                        ["id"] = "1691769153",
                        ["itemLink"] = 845,
                    },
                    [4] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1468,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1633197964,
                        ["quant"] = 2,
                        ["id"] = "1691769177",
                        ["itemLink"] = 845,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 green fine furnishings structures",
            },
        },
        [49137] = 
        {
            ["10:0:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_2hhammer_a.dds",
                ["itemDesc"] = "Maul of the Night Mother",
                ["oldestTime"] = 1633057328,
                ["wasAltered"] = true,
                ["newestTime"] = 1633057328,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 766,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633057328,
                        ["quant"] = 1,
                        ["id"] = "1690682975",
                        ["itemLink"] = 965,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr10 blue superior weapon set night mother's gaze mace two-handed training",
            },
        },
        [124658] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/container_sealed_polymorph_001.dds",
                ["itemDesc"] = "Runebox: Dwarven Theodolite Pet",
                ["oldestTime"] = 1633000024,
                ["wasAltered"] = true,
                ["newestTime"] = 1633191370,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 92500,
                        ["guild"] = 1,
                        ["buyer"] = 394,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633000024,
                        ["quant"] = 1,
                        ["id"] = "1690235043",
                        ["itemLink"] = 397,
                    },
                    [2] = 
                    {
                        ["price"] = 71000,
                        ["guild"] = 1,
                        ["buyer"] = 1424,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633191370,
                        ["quant"] = 1,
                        ["id"] = "1691705491",
                        ["itemLink"] = 397,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary consumable container",
            },
        },
        [177139] = 
        {
            ["1:0:2:60:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_ring.dds",
                ["itemDesc"] = "Companion's Ring",
                ["oldestTime"] = 1633224700,
                ["wasAltered"] = true,
                ["newestTime"] = 1633224705,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 375,
                        ["guild"] = 1,
                        ["buyer"] = 1637,
                        ["wasKiosk"] = true,
                        ["seller"] = 269,
                        ["timestamp"] = 1633224700,
                        ["quant"] = 1,
                        ["id"] = "1692061001",
                        ["itemLink"] = 2373,
                    },
                    [2] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1637,
                        ["wasKiosk"] = true,
                        ["seller"] = 17,
                        ["timestamp"] = 1633224705,
                        ["quant"] = 1,
                        ["id"] = "1692061061",
                        ["itemLink"] = 2373,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine jewelry apparel ring vigorous",
            },
        },
        [56052] = 
        {
            ["1:0:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_light_waist_a.dds",
                ["itemDesc"] = "Homespun Sash",
                ["oldestTime"] = 1632868042,
                ["wasAltered"] = true,
                ["newestTime"] = 1633228599,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 309,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1632984618,
                        ["quant"] = 1,
                        ["id"] = "1690157831",
                        ["itemLink"] = 313,
                    },
                    [2] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 902,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633096961,
                        ["quant"] = 1,
                        ["id"] = "1690936217",
                        ["itemLink"] = 313,
                    },
                    [3] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 93,
                        ["wasKiosk"] = false,
                        ["seller"] = 207,
                        ["timestamp"] = 1633159584,
                        ["quant"] = 1,
                        ["id"] = "1691462671",
                        ["itemLink"] = 313,
                    },
                    [4] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 1669,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633228599,
                        ["quant"] = 1,
                        ["id"] = "1692103111",
                        ["itemLink"] = 313,
                    },
                    [5] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1093,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1632868042,
                        ["quant"] = 1,
                        ["id"] = "1689288005",
                        ["itemLink"] = 313,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 white normal light apparel waist nirnhoned",
            },
        },
        [45301] = 
        {
            ["50:16:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_2haxe_d.dds",
                ["itemDesc"] = "Rubedite Battle Axe",
                ["oldestTime"] = 1632897952,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309707,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633009384,
                        ["quant"] = 1,
                        ["id"] = "1690285619",
                        ["itemLink"] = 496,
                    },
                    [2] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633009385,
                        ["quant"] = 1,
                        ["id"] = "1690285625",
                        ["itemLink"] = 497,
                    },
                    [3] = 
                    {
                        ["price"] = 160,
                        ["guild"] = 1,
                        ["buyer"] = 842,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633071021,
                        ["quant"] = 1,
                        ["id"] = "1690783833",
                        ["itemLink"] = 1087,
                    },
                    [4] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633083996,
                        ["quant"] = 1,
                        ["id"] = "1690854387",
                        ["itemLink"] = 1147,
                    },
                    [5] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633084017,
                        ["quant"] = 1,
                        ["id"] = "1690854545",
                        ["itemLink"] = 1162,
                    },
                    [6] = 
                    {
                        ["price"] = 195,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633146947,
                        ["quant"] = 1,
                        ["id"] = "1691365519",
                        ["itemLink"] = 1087,
                    },
                    [7] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633185927,
                        ["quant"] = 1,
                        ["id"] = "1691639919",
                        ["itemLink"] = 2017,
                    },
                    [8] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633185928,
                        ["quant"] = 1,
                        ["id"] = "1691639937",
                        ["itemLink"] = 2018,
                    },
                    [9] = 
                    {
                        ["price"] = 230,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 109,
                        ["timestamp"] = 1633309705,
                        ["quant"] = 1,
                        ["id"] = "1692845955",
                        ["itemLink"] = 497,
                    },
                    [10] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633309707,
                        ["quant"] = 1,
                        ["id"] = "1692845973",
                        ["itemLink"] = 2983,
                    },
                    [11] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2424,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632897952,
                        ["quant"] = 1,
                        ["id"] = "1689548083",
                        ["itemLink"] = 2017,
                    },
                },
                ["totalCount"] = 11,
                ["itemAdderText"] = "cp160 white normal weapon axe two-handed intricate",
            },
            ["50:15:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_2haxe_d.dds",
                ["itemDesc"] = "Rubedite Battle Axe",
                ["oldestTime"] = 1632956369,
                ["wasAltered"] = true,
                ["newestTime"] = 1633009389,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009389,
                        ["quant"] = 1,
                        ["id"] = "1690285685",
                        ["itemLink"] = 502,
                    },
                    [2] = 
                    {
                        ["price"] = 190,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632956369,
                        ["quant"] = 1,
                        ["id"] = "1689931073",
                        ["itemLink"] = 3872,
                    },
                    [3] = 
                    {
                        ["price"] = 265,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632956377,
                        ["quant"] = 1,
                        ["id"] = "1689931219",
                        ["itemLink"] = 3877,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp150 white normal weapon axe two-handed intricate",
            },
        },
        [147702] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 73: Anequina Bows",
                ["oldestTime"] = 1633125327,
                ["wasAltered"] = true,
                ["newestTime"] = 1633125327,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 911,
                        ["timestamp"] = 1633125327,
                        ["quant"] = 1,
                        ["id"] = "1691145297",
                        ["itemLink"] = 1470,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [57847] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 17: Xivkyn Staves",
                ["oldestTime"] = 1633052198,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052198,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19000,
                        ["guild"] = 1,
                        ["buyer"] = 242,
                        ["wasKiosk"] = false,
                        ["seller"] = 713,
                        ["timestamp"] = 1633052198,
                        ["quant"] = 1,
                        ["id"] = "1690628123",
                        ["itemLink"] = 902,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45304] = 
        {
            ["50:16:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_dagger_d.dds",
                ["itemDesc"] = "Rubedite Dagger",
                ["oldestTime"] = 1632843158,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309695,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633009387,
                        ["quant"] = 1,
                        ["id"] = "1690285659",
                        ["itemLink"] = 499,
                    },
                    [2] = 
                    {
                        ["price"] = 275,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633084005,
                        ["quant"] = 1,
                        ["id"] = "1690854471",
                        ["itemLink"] = 1154,
                    },
                    [3] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633185901,
                        ["quant"] = 1,
                        ["id"] = "1691639571",
                        ["itemLink"] = 2002,
                    },
                    [4] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633185901,
                        ["quant"] = 1,
                        ["id"] = "1691639589",
                        ["itemLink"] = 2003,
                    },
                    [5] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633185902,
                        ["quant"] = 1,
                        ["id"] = "1691639615",
                        ["itemLink"] = 1154,
                    },
                    [6] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633309694,
                        ["quant"] = 1,
                        ["id"] = "1692845825",
                        ["itemLink"] = 2977,
                    },
                    [7] = 
                    {
                        ["price"] = 265,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633309695,
                        ["quant"] = 1,
                        ["id"] = "1692845837",
                        ["itemLink"] = 2002,
                    },
                    [8] = 
                    {
                        ["price"] = 984,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1632843158,
                        ["quant"] = 1,
                        ["id"] = "1689085095",
                        ["itemLink"] = 499,
                    },
                    [9] = 
                    {
                        ["price"] = 315,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632885683,
                        ["quant"] = 1,
                        ["id"] = "1689459789",
                        ["itemLink"] = 3518,
                    },
                    [10] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2591,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632951466,
                        ["quant"] = 1,
                        ["id"] = "1689887031",
                        ["itemLink"] = 2003,
                    },
                },
                ["totalCount"] = 10,
                ["itemAdderText"] = "cp160 white normal weapon dagger one-handed intricate",
            },
            ["50:15:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_dagger_d.dds",
                ["itemDesc"] = "Rubedite Dagger",
                ["oldestTime"] = 1632865271,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185897,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009391,
                        ["quant"] = 1,
                        ["id"] = "1690285729",
                        ["itemLink"] = 505,
                    },
                    [2] = 
                    {
                        ["price"] = 138,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 539,
                        ["timestamp"] = 1633028881,
                        ["quant"] = 1,
                        ["id"] = "1690436645",
                        ["itemLink"] = 505,
                    },
                    [3] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633185895,
                        ["quant"] = 1,
                        ["id"] = "1691639463",
                        ["itemLink"] = 1998,
                    },
                    [4] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633185897,
                        ["quant"] = 1,
                        ["id"] = "1691639503",
                        ["itemLink"] = 1998,
                    },
                    [5] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632865271,
                        ["quant"] = 1,
                        ["id"] = "1689266421",
                        ["itemLink"] = 3329,
                    },
                    [6] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1632885682,
                        ["quant"] = 1,
                        ["id"] = "1689459783",
                        ["itemLink"] = 1998,
                    },
                    [7] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2424,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632892810,
                        ["quant"] = 1,
                        ["id"] = "1689514737",
                        ["itemLink"] = 3547,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "cp150 white normal weapon dagger one-handed intricate",
            },
        },
        [118265] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_inc_varpuzzlepaintings001.dds",
                ["itemDesc"] = "Painting of Winter, Bolted",
                ["oldestTime"] = 1633238148,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238148,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 1745,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1633238148,
                        ["quant"] = 1,
                        ["id"] = "1692186515",
                        ["itemLink"] = 2503,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings gallery",
            },
        },
        [28666] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_cloth_stems.dds",
                ["itemDesc"] = "Seaweed",
                ["oldestTime"] = 1633042297,
                ["wasAltered"] = true,
                ["newestTime"] = 1633042297,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 648,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1633042297,
                        ["quant"] = 200,
                        ["id"] = "1690531029",
                        ["itemLink"] = 819,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [147707] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 73: Anequina Legs",
                ["oldestTime"] = 1632939816,
                ["wasAltered"] = true,
                ["newestTime"] = 1633216082,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 911,
                        ["timestamp"] = 1633125340,
                        ["quant"] = 1,
                        ["id"] = "1691145427",
                        ["itemLink"] = 1471,
                    },
                    [2] = 
                    {
                        ["price"] = 2250,
                        ["guild"] = 1,
                        ["buyer"] = 1571,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633214023,
                        ["quant"] = 1,
                        ["id"] = "1691949819",
                        ["itemLink"] = 1471,
                    },
                    [3] = 
                    {
                        ["price"] = 2250,
                        ["guild"] = 1,
                        ["buyer"] = 1587,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633216082,
                        ["quant"] = 1,
                        ["id"] = "1691969477",
                        ["itemLink"] = 1471,
                    },
                    [4] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1872,
                        ["wasKiosk"] = true,
                        ["seller"] = 31,
                        ["timestamp"] = 1632939816,
                        ["quant"] = 1,
                        ["id"] = "1689793829",
                        ["itemLink"] = 1471,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [176729] = 
        {
            ["1:0:3:48:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_gloves_light.dds",
                ["itemDesc"] = "Companion's Gloves",
                ["oldestTime"] = 1632979711,
                ["wasAltered"] = true,
                ["newestTime"] = 1633295343,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 249,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1632979711,
                        ["quant"] = 1,
                        ["id"] = "1690129655",
                        ["itemLink"] = 262,
                    },
                    [2] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 807,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633064133,
                        ["quant"] = 1,
                        ["id"] = "1690741201",
                        ["itemLink"] = 262,
                    },
                    [3] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 2017,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633295343,
                        ["quant"] = 1,
                        ["id"] = "1692693687",
                        ["itemLink"] = 262,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior light apparel hands soothing",
            },
        },
        [176563] = 
        {
            ["1:0:2:56:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_ring.dds",
                ["itemDesc"] = "Companion's Ring",
                ["oldestTime"] = 1633075333,
                ["wasAltered"] = true,
                ["newestTime"] = 1633131154,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2480,
                        ["guild"] = 1,
                        ["buyer"] = 864,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1633075333,
                        ["quant"] = 1,
                        ["id"] = "1690812713",
                        ["itemLink"] = 1109,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 864,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633075337,
                        ["quant"] = 1,
                        ["id"] = "1690812721",
                        ["itemLink"] = 1109,
                    },
                    [3] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1107,
                        ["wasKiosk"] = true,
                        ["seller"] = 1108,
                        ["timestamp"] = 1633131154,
                        ["quant"] = 1,
                        ["id"] = "1691198835",
                        ["itemLink"] = 1109,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine jewelry apparel ring aggressive",
            },
        },
        [71678] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 28: Ra Gada Daggers",
                ["oldestTime"] = 1632520249,
                ["wasAltered"] = true,
                ["newestTime"] = 1633241257,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 2,
                        ["buyer"] = 114,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1632520249,
                        ["quant"] = 1,
                        ["id"] = "1686355543",
                        ["itemLink"] = 95,
                    },
                    [2] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 430,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633008882,
                        ["quant"] = 1,
                        ["id"] = "1690282087",
                        ["itemLink"] = 95,
                    },
                    [3] = 
                    {
                        ["price"] = 4068,
                        ["guild"] = 1,
                        ["buyer"] = 1607,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633219937,
                        ["quant"] = 1,
                        ["id"] = "1692011533",
                        ["itemLink"] = 95,
                    },
                    [4] = 
                    {
                        ["price"] = 3800,
                        ["guild"] = 1,
                        ["buyer"] = 1602,
                        ["wasKiosk"] = true,
                        ["seller"] = 1720,
                        ["timestamp"] = 1633241257,
                        ["quant"] = 1,
                        ["id"] = "1692206443",
                        ["itemLink"] = 95,
                    },
                    [5] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2284,
                        ["wasKiosk"] = true,
                        ["seller"] = 261,
                        ["timestamp"] = 1632869993,
                        ["quant"] = 1,
                        ["id"] = "1689303041",
                        ["itemLink"] = 95,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [97279] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_shirt_d.dds",
                ["itemDesc"] = "Jerkin of a Mother's Sorrow",
                ["oldestTime"] = 1633244581,
                ["wasAltered"] = true,
                ["newestTime"] = 1633244581,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1790,
                        ["wasKiosk"] = true,
                        ["seller"] = 94,
                        ["timestamp"] = 1633244581,
                        ["quant"] = 1,
                        ["id"] = "1692230525",
                        ["itemLink"] = 2563,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set mother's sorrow chest well-fitted",
            },
        },
    },
}
