GS07DataSavedVariables =
{
    ["listingseu"] = 
    {
    },
    ["listingsna"] = 
    {
    },
    ["dataeu"] = 
    {
    },
    ["datana"] = 
    {
        [69376] = 
        {
            ["50:16:4:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_2hhammer_c.dds",
                ["itemDesc"] = "Maul of Agility",
                ["oldestTime"] = 1633304390,
                ["wasAltered"] = true,
                ["newestTime"] = 1633304390,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 246,
                        ["guild"] = 1,
                        ["buyer"] = 2057,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633304390,
                        ["quant"] = 1,
                        ["id"] = "1692783921",
                        ["itemLink"] = 2924,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set agility mace two-handed training",
            },
        },
        [176897] = 
        {
            ["1:0:3:49:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_shield.dds",
                ["itemDesc"] = "Companion's Shield",
                ["oldestTime"] = 1633193291,
                ["wasAltered"] = true,
                ["newestTime"] = 1633193291,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 32,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1633193291,
                        ["quant"] = 1,
                        ["id"] = "1691727207",
                        ["itemLink"] = 2122,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior apparel weapon shield off hand augmented",
            },
        },
        [46082] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Rude Awakening",
                ["oldestTime"] = 1633130366,
                ["wasAltered"] = true,
                ["newestTime"] = 1633130366,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1102,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633130366,
                        ["quant"] = 1,
                        ["id"] = "1691189709",
                        ["itemLink"] = 1511,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [71685] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 28: Ra Gada Staves",
                ["oldestTime"] = 1633125588,
                ["wasAltered"] = true,
                ["newestTime"] = 1633125588,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 971,
                        ["timestamp"] = 1633125588,
                        ["quant"] = 1,
                        ["id"] = "1691147249",
                        ["itemLink"] = 1476,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [175622] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_fur_leychair001.dds",
                ["itemDesc"] = "Leyawiin Armchair, Cushioned",
                ["oldestTime"] = 1633140475,
                ["wasAltered"] = true,
                ["newestTime"] = 1633201646,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 192000,
                        ["guild"] = 1,
                        ["buyer"] = 1183,
                        ["wasKiosk"] = true,
                        ["seller"] = 513,
                        ["timestamp"] = 1633140475,
                        ["quant"] = 4,
                        ["id"] = "1691295623",
                        ["itemLink"] = 1600,
                    },
                    [2] = 
                    {
                        ["price"] = 192000,
                        ["guild"] = 1,
                        ["buyer"] = 1499,
                        ["wasKiosk"] = true,
                        ["seller"] = 513,
                        ["timestamp"] = 1633201643,
                        ["quant"] = 4,
                        ["id"] = "1691807335",
                        ["itemLink"] = 1600,
                    },
                    [3] = 
                    {
                        ["price"] = 192000,
                        ["guild"] = 1,
                        ["buyer"] = 1499,
                        ["wasKiosk"] = true,
                        ["seller"] = 513,
                        ["timestamp"] = 1633201646,
                        ["quant"] = 4,
                        ["id"] = "1691807353",
                        ["itemLink"] = 1600,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [167432] = 
        {
            ["50:16:4:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_arkthzand_1haxe_a.dds",
                ["itemDesc"] = "Axe of the Radiant Bastion",
                ["oldestTime"] = 1632948594,
                ["wasAltered"] = true,
                ["newestTime"] = 1632948594,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 2578,
                        ["wasKiosk"] = true,
                        ["seller"] = 155,
                        ["timestamp"] = 1632948594,
                        ["quant"] = 1,
                        ["id"] = "1689862479",
                        ["itemLink"] = 3801,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set radiant bastion axe one-handed infused",
            },
        },
        [119818] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_alchemy.dds",
                ["itemDesc"] = "Sealed Alchemy Writ",
                ["oldestTime"] = 1632864542,
                ["wasAltered"] = true,
                ["newestTime"] = 1633307856,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1065,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633122701,
                        ["quant"] = 1,
                        ["id"] = "1691125191",
                        ["itemLink"] = 1449,
                    },
                    [2] = 
                    {
                        ["price"] = 8600,
                        ["guild"] = 1,
                        ["buyer"] = 2075,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633307856,
                        ["quant"] = 1,
                        ["id"] = "1692821581",
                        ["itemLink"] = 2953,
                    },
                    [3] = 
                    {
                        ["price"] = 19995,
                        ["guild"] = 1,
                        ["buyer"] = 2256,
                        ["wasKiosk"] = true,
                        ["seller"] = 975,
                        ["timestamp"] = 1632864542,
                        ["quant"] = 1,
                        ["id"] = "1689262189",
                        ["itemLink"] = 1449,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [177163] = 
        {
            ["1:0:3:51:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_chest_medium.dds",
                ["itemDesc"] = "Companion's Jack",
                ["oldestTime"] = 1633142041,
                ["wasAltered"] = true,
                ["newestTime"] = 1633142041,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1197,
                        ["wasKiosk"] = true,
                        ["seller"] = 1108,
                        ["timestamp"] = 1633142041,
                        ["quant"] = 1,
                        ["id"] = "1691313295",
                        ["itemLink"] = 1618,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior medium apparel chest vigorous",
            },
        },
        [119820] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_alchemy.dds",
                ["itemDesc"] = "Sealed Alchemy Writ",
                ["oldestTime"] = 1633198648,
                ["wasAltered"] = true,
                ["newestTime"] = 1633307860,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633198648,
                        ["quant"] = 1,
                        ["id"] = "1691775869",
                        ["itemLink"] = 2170,
                    },
                    [2] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 2075,
                        ["wasKiosk"] = true,
                        ["seller"] = 451,
                        ["timestamp"] = 1633307860,
                        ["quant"] = 1,
                        ["id"] = "1692821611",
                        ["itemLink"] = 2956,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [166926] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing2.dds",
                ["itemDesc"] = "Diagram: Solitude Frying Pan, Wood Handle",
                ["oldestTime"] = 1633107455,
                ["wasAltered"] = true,
                ["newestTime"] = 1633107455,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 972,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633107455,
                        ["quant"] = 1,
                        ["id"] = "1691018115",
                        ["itemLink"] = 1303,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [100624] = 
        {
            ["50:16:5:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_medium_hands_d.dds",
                ["itemDesc"] = "Spriggan's Bracers",
                ["oldestTime"] = 1633040762,
                ["wasAltered"] = true,
                ["newestTime"] = 1633040762,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 217713,
                        ["guild"] = 1,
                        ["buyer"] = 627,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633040762,
                        ["quant"] = 1,
                        ["id"] = "1690519101",
                        ["itemLink"] = 799,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary medium apparel set spriggan's thorns hands divines",
            },
        },
        [175634] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_lsb_leylightpostb002.dds",
                ["itemDesc"] = "Leyawiin Lamppost, Floral Gilded",
                ["oldestTime"] = 1633294588,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294589,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 397,
                        ["wasKiosk"] = false,
                        ["seller"] = 513,
                        ["timestamp"] = 1633294588,
                        ["quant"] = 1,
                        ["id"] = "1692684875",
                        ["itemLink"] = 2866,
                    },
                    [2] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 397,
                        ["wasKiosk"] = false,
                        ["seller"] = 513,
                        ["timestamp"] = 1633294589,
                        ["quant"] = 1,
                        ["id"] = "1692684893",
                        ["itemLink"] = 2866,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [149524] = 
        {
            ["50:16:2:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_staff_a.dds",
                ["itemDesc"] = "Darloc Brae's Restoration Staff",
                ["oldestTime"] = 1633043209,
                ["wasAltered"] = true,
                ["newestTime"] = 1633043209,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 547,
                        ["timestamp"] = 1633043209,
                        ["quant"] = 1,
                        ["id"] = "1690539807",
                        ["itemLink"] = 833,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set vesture of darloc brae healing staff two-handed sharpened",
            },
        },
        [124693] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 48: Ashlander Swords",
                ["oldestTime"] = 1632852093,
                ["wasAltered"] = true,
                ["newestTime"] = 1632852093,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7700,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1632852093,
                        ["quant"] = 1,
                        ["id"] = "1689159977",
                        ["itemLink"] = 3247,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [147734] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 75: Sunspire Bows",
                ["oldestTime"] = 1633063890,
                ["wasAltered"] = true,
                ["newestTime"] = 1633063890,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4461,
                        ["guild"] = 1,
                        ["buyer"] = 806,
                        ["wasKiosk"] = true,
                        ["seller"] = 765,
                        ["timestamp"] = 1633063890,
                        ["quant"] = 1,
                        ["id"] = "1690739655",
                        ["itemLink"] = 1045,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [71705] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 26: Daggerfall Covenant Axes",
                ["oldestTime"] = 1633202771,
                ["wasAltered"] = true,
                ["newestTime"] = 1633202771,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1503,
                        ["wasKiosk"] = true,
                        ["seller"] = 351,
                        ["timestamp"] = 1633202771,
                        ["quant"] = 1,
                        ["id"] = "1691819469",
                        ["itemLink"] = 2220,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [171807] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_jewelry_5.dds",
                ["itemDesc"] = "Sketch: Dwarven Crystal Sconce, Mirror",
                ["oldestTime"] = 1632938928,
                ["wasAltered"] = true,
                ["newestTime"] = 1632938928,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 113000,
                        ["guild"] = 1,
                        ["buyer"] = 1142,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632938928,
                        ["quant"] = 1,
                        ["id"] = "1689787291",
                        ["itemLink"] = 3756,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable recipe",
            },
        },
        [127011] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Dres Cup, Mazte",
                ["oldestTime"] = 1633168985,
                ["wasAltered"] = true,
                ["newestTime"] = 1633168985,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1262,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1633168985,
                        ["quant"] = 1,
                        ["id"] = "1691514169",
                        ["itemLink"] = 1876,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [43556] = 
        {
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_shield_d.dds",
                ["itemDesc"] = "Ruby Ash Shield",
                ["oldestTime"] = 1632847686,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185953,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 138,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633185953,
                        ["quant"] = 1,
                        ["id"] = "1691640267",
                        ["itemLink"] = 2029,
                    },
                    [2] = 
                    {
                        ["price"] = 141,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1632847686,
                        ["quant"] = 1,
                        ["id"] = "1689125503",
                        ["itemLink"] = 3207,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 white normal apparel weapon shield off hand",
            },
        },
        [114981] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 44: Silken Ring Swords",
                ["oldestTime"] = 1633221371,
                ["wasAltered"] = true,
                ["newestTime"] = 1633221371,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 1617,
                        ["wasKiosk"] = true,
                        ["seller"] = 1455,
                        ["timestamp"] = 1633221371,
                        ["quant"] = 1,
                        ["id"] = "1692025979",
                        ["itemLink"] = 2354,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [116007] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing4.dds",
                ["itemDesc"] = "Diagram: Breton Streetlight, Full",
                ["oldestTime"] = 1633235909,
                ["wasAltered"] = true,
                ["newestTime"] = 1633235909,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1733,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633235909,
                        ["quant"] = 1,
                        ["id"] = "1692167073",
                        ["itemLink"] = 2487,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [16425] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_book_001.dds",
                ["itemDesc"] = "Crafting Motif 5: Breton Style",
                ["oldestTime"] = 1632820724,
                ["wasAltered"] = true,
                ["newestTime"] = 1633248689,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 484,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1633017931,
                        ["quant"] = 1,
                        ["id"] = "1690348971",
                        ["itemLink"] = 563,
                    },
                    [2] = 
                    {
                        ["price"] = 76,
                        ["guild"] = 1,
                        ["buyer"] = 866,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633079137,
                        ["quant"] = 1,
                        ["id"] = "1690832537",
                        ["itemLink"] = 563,
                    },
                    [3] = 
                    {
                        ["price"] = 76,
                        ["guild"] = 1,
                        ["buyer"] = 1807,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633248689,
                        ["quant"] = 1,
                        ["id"] = "1692261905",
                        ["itemLink"] = 563,
                    },
                    [4] = 
                    {
                        ["price"] = 225,
                        ["guild"] = 1,
                        ["buyer"] = 2103,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1632820724,
                        ["quant"] = 1,
                        ["id"] = "1688947347",
                        ["itemLink"] = 563,
                    },
                    [5] = 
                    {
                        ["price"] = 70,
                        ["guild"] = 1,
                        ["buyer"] = 2524,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632934320,
                        ["quant"] = 1,
                        ["id"] = "1689754647",
                        ["itemLink"] = 563,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 blue superior consumable motif",
            },
        },
        [137771] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of the Seducer",
                ["oldestTime"] = 1633017061,
                ["wasAltered"] = true,
                ["newestTime"] = 1633245300,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 44999,
                        ["guild"] = 1,
                        ["buyer"] = 482,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633017061,
                        ["quant"] = 1,
                        ["id"] = "1690342167",
                        ["itemLink"] = 549,
                    },
                    [2] = 
                    {
                        ["price"] = 44999,
                        ["guild"] = 1,
                        ["buyer"] = 1031,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633117406,
                        ["quant"] = 1,
                        ["id"] = "1691087745",
                        ["itemLink"] = 549,
                    },
                    [3] = 
                    {
                        ["price"] = 44999,
                        ["guild"] = 1,
                        ["buyer"] = 1101,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633130112,
                        ["quant"] = 1,
                        ["id"] = "1691187505",
                        ["itemLink"] = 549,
                    },
                    [4] = 
                    {
                        ["price"] = 44999,
                        ["guild"] = 1,
                        ["buyer"] = 1502,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633202654,
                        ["quant"] = 1,
                        ["id"] = "1691818237",
                        ["itemLink"] = 549,
                    },
                    [5] = 
                    {
                        ["price"] = 44999,
                        ["guild"] = 1,
                        ["buyer"] = 1797,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633245300,
                        ["quant"] = 1,
                        ["id"] = "1692235251",
                        ["itemLink"] = 549,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set armor of the seducer neck arcane",
            },
        },
        [86063] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_medium_hands_a.dds",
                ["itemDesc"] = "Werewolf Hide Bracers",
                ["oldestTime"] = 1633023035,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023035,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633023035,
                        ["quant"] = 1,
                        ["id"] = "1690390937",
                        ["itemLink"] = 659,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set hide of the werewolf hands well-fitted",
            },
        },
        [175665] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_inc_leyplantpot003.dds",
                ["itemDesc"] = "Leyawiin Pot, Waves",
                ["oldestTime"] = 1633113850,
                ["wasAltered"] = true,
                ["newestTime"] = 1633113850,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1005,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633113850,
                        ["quant"] = 1,
                        ["id"] = "1691064445",
                        ["itemLink"] = 1369,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings hearth",
            },
        },
        [180530] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_light_legs_a.dds",
                ["itemDesc"] = "Breeches of Dark Convergence",
                ["oldestTime"] = 1633201345,
                ["wasAltered"] = true,
                ["newestTime"] = 1633201345,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 1494,
                        ["wasKiosk"] = false,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633201345,
                        ["quant"] = 1,
                        ["id"] = "1691804089",
                        ["itemLink"] = 2211,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set dark convergence legs impenetrable",
            },
        },
        [153651] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_waf_wallscitymediumportcullisgate001.dds",
                ["itemDesc"] = "Elsweyr Gate, Masterwork",
                ["oldestTime"] = 1632879869,
                ["wasAltered"] = true,
                ["newestTime"] = 1632879869,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 27500,
                        ["guild"] = 1,
                        ["buyer"] = 2331,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1632879869,
                        ["quant"] = 1,
                        ["id"] = "1689395049",
                        ["itemLink"] = 3448,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings structures",
            },
        },
        [151863] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_str_altwindmill001.dds",
                ["itemDesc"] = "Alinor Windmill, Decorative",
                ["oldestTime"] = 1633055515,
                ["wasAltered"] = true,
                ["newestTime"] = 1633203202,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300000,
                        ["guild"] = 1,
                        ["buyer"] = 747,
                        ["wasKiosk"] = true,
                        ["seller"] = 748,
                        ["timestamp"] = 1633055515,
                        ["quant"] = 1,
                        ["id"] = "1690659853",
                        ["itemLink"] = 946,
                    },
                    [2] = 
                    {
                        ["price"] = 300000,
                        ["guild"] = 1,
                        ["buyer"] = 747,
                        ["wasKiosk"] = true,
                        ["seller"] = 748,
                        ["timestamp"] = 1633055517,
                        ["quant"] = 1,
                        ["id"] = "1690659867",
                        ["itemLink"] = 946,
                    },
                    [3] = 
                    {
                        ["price"] = 324999,
                        ["guild"] = 1,
                        ["buyer"] = 1506,
                        ["wasKiosk"] = true,
                        ["seller"] = 951,
                        ["timestamp"] = 1633203202,
                        ["quant"] = 1,
                        ["id"] = "1691824919",
                        ["itemLink"] = 946,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 gold legendary furnishings structures",
            },
        },
        [132666] = 
        {
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Livewire Ring",
                ["oldestTime"] = 1633218671,
                ["wasAltered"] = true,
                ["newestTime"] = 1633218671,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633218671,
                        ["quant"] = 1,
                        ["id"] = "1691997417",
                        ["itemLink"] = 2331,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set livewire ring healthy",
            },
        },
        [116027] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Dark Elf Streetpost, Banner",
                ["oldestTime"] = 1633158059,
                ["wasAltered"] = true,
                ["newestTime"] = 1633158061,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 160,
                        ["guild"] = 1,
                        ["buyer"] = 1293,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1633158059,
                        ["quant"] = 1,
                        ["id"] = "1691454693",
                        ["itemLink"] = 1781,
                    },
                    [2] = 
                    {
                        ["price"] = 175,
                        ["guild"] = 1,
                        ["buyer"] = 1293,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633158061,
                        ["quant"] = 1,
                        ["id"] = "1691454707",
                        ["itemLink"] = 1781,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [160572] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 86: Sea Giant Staves",
                ["oldestTime"] = 1633138728,
                ["wasAltered"] = true,
                ["newestTime"] = 1633138728,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 1171,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633138728,
                        ["quant"] = 1,
                        ["id"] = "1691279345",
                        ["itemLink"] = 1590,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [156480] = 
        {
            ["20:0:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_medium_chest_b.dds",
                ["itemDesc"] = "New Moon Acolyte's Jack",
                ["oldestTime"] = 1633293703,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293703,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 266,
                        ["timestamp"] = 1633293703,
                        ["quant"] = 1,
                        ["id"] = "1692672163",
                        ["itemLink"] = 2856,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr20 blue superior medium apparel set new moon acolyte chest training",
            },
        },
        [160577] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 87: Ancestral Nord Axes",
                ["oldestTime"] = 1632825788,
                ["wasAltered"] = true,
                ["newestTime"] = 1632825788,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2106,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632825788,
                        ["quant"] = 1,
                        ["id"] = "1688968161",
                        ["itemLink"] = 3025,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [171330] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/container_sealed_polymorph_001.dds",
                ["itemDesc"] = "Runebox: Snowball Buddy",
                ["oldestTime"] = 1633149986,
                ["wasAltered"] = true,
                ["newestTime"] = 1633149986,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 845,
                        ["wasKiosk"] = false,
                        ["seller"] = 739,
                        ["timestamp"] = 1633149986,
                        ["quant"] = 1,
                        ["id"] = "1691390957",
                        ["itemLink"] = 1713,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable container",
            },
        },
        [149059] = 
        {
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Undertaker's Amulet",
                ["oldestTime"] = 1633166408,
                ["wasAltered"] = true,
                ["newestTime"] = 1633166408,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5100,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633166408,
                        ["quant"] = 1,
                        ["id"] = "1691502643",
                        ["itemLink"] = 1862,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set call of the undertaker neck healthy",
            },
        },
        [45894] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Rabbit Pasty",
                ["oldestTime"] = 1632966607,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261623,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633261623,
                        ["quant"] = 1,
                        ["id"] = "1692334449",
                        ["itemLink"] = 2623,
                    },
                    [2] = 
                    {
                        ["price"] = 75,
                        ["guild"] = 1,
                        ["buyer"] = 2664,
                        ["wasKiosk"] = true,
                        ["seller"] = 1786,
                        ["timestamp"] = 1632966607,
                        ["quant"] = 1,
                        ["id"] = "1690020341",
                        ["itemLink"] = 2623,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [71239] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_leather_ambergris.dds",
                ["itemDesc"] = "Rubedo Hide Scraps",
                ["oldestTime"] = 1632840994,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294553,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1633001205,
                        ["quant"] = 200,
                        ["id"] = "1690240301",
                        ["itemLink"] = 409,
                    },
                    [2] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1633001205,
                        ["quant"] = 200,
                        ["id"] = "1690240303",
                        ["itemLink"] = 409,
                    },
                    [3] = 
                    {
                        ["price"] = 2430,
                        ["guild"] = 1,
                        ["buyer"] = 617,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1633038590,
                        ["quant"] = 18,
                        ["id"] = "1690502823",
                        ["itemLink"] = 409,
                    },
                    [4] = 
                    {
                        ["price"] = 28499,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633049360,
                        ["quant"] = 200,
                        ["id"] = "1690598545",
                        ["itemLink"] = 409,
                    },
                    [5] = 
                    {
                        ["price"] = 25800,
                        ["guild"] = 1,
                        ["buyer"] = 853,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633073459,
                        ["quant"] = 200,
                        ["id"] = "1690800453",
                        ["itemLink"] = 409,
                    },
                    [6] = 
                    {
                        ["price"] = 25800,
                        ["guild"] = 1,
                        ["buyer"] = 853,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633073463,
                        ["quant"] = 200,
                        ["id"] = "1690800459",
                        ["itemLink"] = 409,
                    },
                    [7] = 
                    {
                        ["price"] = 25800,
                        ["guild"] = 1,
                        ["buyer"] = 853,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633076021,
                        ["quant"] = 200,
                        ["id"] = "1690817063",
                        ["itemLink"] = 409,
                    },
                    [8] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 144,
                        ["timestamp"] = 1633114455,
                        ["quant"] = 200,
                        ["id"] = "1691069171",
                        ["itemLink"] = 409,
                    },
                    [9] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1633154390,
                        ["quant"] = 200,
                        ["id"] = "1691426907",
                        ["itemLink"] = 409,
                    },
                    [10] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 1704,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1633232200,
                        ["quant"] = 200,
                        ["id"] = "1692137165",
                        ["itemLink"] = 409,
                    },
                    [11] = 
                    {
                        ["price"] = 25800,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633294545,
                        ["quant"] = 200,
                        ["id"] = "1692684297",
                        ["itemLink"] = 409,
                    },
                    [12] = 
                    {
                        ["price"] = 25800,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1633294546,
                        ["quant"] = 200,
                        ["id"] = "1692684315",
                        ["itemLink"] = 409,
                    },
                    [13] = 
                    {
                        ["price"] = 25880,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633294548,
                        ["quant"] = 200,
                        ["id"] = "1692684335",
                        ["itemLink"] = 409,
                    },
                    [14] = 
                    {
                        ["price"] = 28499,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633294550,
                        ["quant"] = 200,
                        ["id"] = "1692684355",
                        ["itemLink"] = 409,
                    },
                    [15] = 
                    {
                        ["price"] = 28499,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633294553,
                        ["quant"] = 200,
                        ["id"] = "1692684401",
                        ["itemLink"] = 409,
                    },
                    [16] = 
                    {
                        ["price"] = 25800,
                        ["guild"] = 1,
                        ["buyer"] = 2181,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632840994,
                        ["quant"] = 200,
                        ["id"] = "1689066857",
                        ["itemLink"] = 409,
                    },
                    [17] = 
                    {
                        ["price"] = 25800,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632861650,
                        ["quant"] = 200,
                        ["id"] = "1689242061",
                        ["itemLink"] = 409,
                    },
                    [18] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1632884704,
                        ["quant"] = 200,
                        ["id"] = "1689448531",
                        ["itemLink"] = 409,
                    },
                    [19] = 
                    {
                        ["price"] = 24109,
                        ["guild"] = 1,
                        ["buyer"] = 8,
                        ["wasKiosk"] = false,
                        ["seller"] = 21,
                        ["timestamp"] = 1632892026,
                        ["quant"] = 200,
                        ["id"] = "1689508503",
                        ["itemLink"] = 409,
                    },
                    [20] = 
                    {
                        ["price"] = 25800,
                        ["guild"] = 1,
                        ["buyer"] = 2484,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632920538,
                        ["quant"] = 200,
                        ["id"] = "1689654635",
                        ["itemLink"] = 409,
                    },
                    [21] = 
                    {
                        ["price"] = 25800,
                        ["guild"] = 1,
                        ["buyer"] = 2484,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632920539,
                        ["quant"] = 200,
                        ["id"] = "1689654637",
                        ["itemLink"] = 409,
                    },
                    [22] = 
                    {
                        ["price"] = 25800,
                        ["guild"] = 1,
                        ["buyer"] = 2484,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632920540,
                        ["quant"] = 200,
                        ["id"] = "1689654641",
                        ["itemLink"] = 409,
                    },
                    [23] = 
                    {
                        ["price"] = 24258,
                        ["guild"] = 1,
                        ["buyer"] = 143,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632944403,
                        ["quant"] = 200,
                        ["id"] = "1689830825",
                        ["itemLink"] = 409,
                    },
                    [24] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 267,
                        ["timestamp"] = 1632960143,
                        ["quant"] = 200,
                        ["id"] = "1689961167",
                        ["itemLink"] = 409,
                    },
                },
                ["totalCount"] = 24,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [45640] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Beef Stew",
                ["oldestTime"] = 1633076218,
                ["wasAltered"] = true,
                ["newestTime"] = 1633076218,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 70,
                        ["guild"] = 1,
                        ["buyer"] = 867,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633076218,
                        ["quant"] = 1,
                        ["id"] = "1690817893",
                        ["itemLink"] = 1112,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [123722] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Wizard's Riposte Necklace",
                ["oldestTime"] = 1633163917,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163917,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 1077,
                        ["timestamp"] = 1633163917,
                        ["quant"] = 1,
                        ["id"] = "1691490353",
                        ["itemLink"] = 1813,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set wizard's riposte neck arcane",
            },
        },
        [171340] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_lsb_markreachchandelier002.dds",
                ["itemDesc"] = "Reachmen Chandelier, Shaded",
                ["oldestTime"] = 1633201375,
                ["wasAltered"] = true,
                ["newestTime"] = 1633201375,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 1495,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633201375,
                        ["quant"] = 1,
                        ["id"] = "1691804349",
                        ["itemLink"] = 2212,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings lighting",
            },
        },
        [115278] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_dun_fur_wallshelf001.dds",
                ["itemDesc"] = "Dark Elf Shelf, Wall",
                ["oldestTime"] = 1633238141,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238141,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1745,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1633238141,
                        ["quant"] = 1,
                        ["id"] = "1692186487",
                        ["itemLink"] = 2502,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings library",
            },
        },
        [44879] = 
        {
            ["50:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_crate_001.dds",
                ["itemDesc"] = "Grand Repair Kit",
                ["oldestTime"] = 1632994702,
                ["wasAltered"] = true,
                ["newestTime"] = 1633139416,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9500,
                        ["guild"] = 1,
                        ["buyer"] = 373,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632994702,
                        ["quant"] = 80,
                        ["id"] = "1690209047",
                        ["itemLink"] = 368,
                    },
                    [2] = 
                    {
                        ["price"] = 24200,
                        ["guild"] = 1,
                        ["buyer"] = 373,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1632994703,
                        ["quant"] = 200,
                        ["id"] = "1690209051",
                        ["itemLink"] = 368,
                    },
                    [3] = 
                    {
                        ["price"] = 24200,
                        ["guild"] = 1,
                        ["buyer"] = 373,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1632994703,
                        ["quant"] = 200,
                        ["id"] = "1690209057",
                        ["itemLink"] = 368,
                    },
                    [4] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 373,
                        ["wasKiosk"] = true,
                        ["seller"] = 374,
                        ["timestamp"] = 1632994704,
                        ["quant"] = 200,
                        ["id"] = "1690209065",
                        ["itemLink"] = 368,
                    },
                    [5] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 373,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632994705,
                        ["quant"] = 200,
                        ["id"] = "1690209069",
                        ["itemLink"] = 368,
                    },
                    [6] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 373,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1632994708,
                        ["quant"] = 4,
                        ["id"] = "1690209089",
                        ["itemLink"] = 368,
                    },
                    [7] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 478,
                        ["wasKiosk"] = true,
                        ["seller"] = 479,
                        ["timestamp"] = 1633016717,
                        ["quant"] = 200,
                        ["id"] = "1690339205",
                        ["itemLink"] = 368,
                    },
                    [8] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 478,
                        ["wasKiosk"] = true,
                        ["seller"] = 479,
                        ["timestamp"] = 1633016719,
                        ["quant"] = 200,
                        ["id"] = "1690339209",
                        ["itemLink"] = 368,
                    },
                    [9] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 211,
                        ["wasKiosk"] = false,
                        ["seller"] = 9,
                        ["timestamp"] = 1633069284,
                        ["quant"] = 200,
                        ["id"] = "1690773737",
                        ["itemLink"] = 368,
                    },
                    [10] = 
                    {
                        ["price"] = 21000,
                        ["guild"] = 1,
                        ["buyer"] = 1174,
                        ["wasKiosk"] = true,
                        ["seller"] = 624,
                        ["timestamp"] = 1633139416,
                        ["quant"] = 200,
                        ["id"] = "1691285111",
                        ["itemLink"] = 368,
                    },
                },
                ["totalCount"] = 10,
                ["itemAdderText"] = "rr50 green fine consumable tool",
            },
        },
        [116049] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Dark Elf Carpet, Mossy",
                ["oldestTime"] = 1632939382,
                ["wasAltered"] = true,
                ["newestTime"] = 1632939382,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1066,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1632939382,
                        ["quant"] = 1,
                        ["id"] = "1689789863",
                        ["itemLink"] = 3758,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [180818] = 
        {
            ["50:16:4:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_staff_a.dds",
                ["itemDesc"] = "Hrothgar's Restoration Staff",
                ["oldestTime"] = 1633056980,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112425,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 760,
                        ["wasKiosk"] = true,
                        ["seller"] = 761,
                        ["timestamp"] = 1633056980,
                        ["quant"] = 1,
                        ["id"] = "1690678313",
                        ["itemLink"] = 960,
                    },
                    [2] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 991,
                        ["wasKiosk"] = true,
                        ["seller"] = 761,
                        ["timestamp"] = 1633112425,
                        ["quant"] = 1,
                        ["id"] = "1691055105",
                        ["itemLink"] = 960,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic weapon set hrothgar's chill healing staff two-handed precise",
            },
        },
        [153683] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_els_zamiapalm006.dds",
                ["itemDesc"] = "Plant Cluster, Zahmia",
                ["oldestTime"] = 1633238271,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238271,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 1745,
                        ["wasKiosk"] = true,
                        ["seller"] = 1747,
                        ["timestamp"] = 1633238271,
                        ["quant"] = 3,
                        ["id"] = "1692187409",
                        ["itemLink"] = 2514,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings conservatory",
            },
        },
        [23125] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_cloth_base_cotton_r2.dds",
                ["itemDesc"] = "Cotton",
                ["oldestTime"] = 1632769474,
                ["wasAltered"] = true,
                ["newestTime"] = 1632769474,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 2,
                        ["buyer"] = 124,
                        ["wasKiosk"] = false,
                        ["seller"] = 125,
                        ["timestamp"] = 1632769474,
                        ["quant"] = 100,
                        ["id"] = "1688524891",
                        ["itemLink"] = 119,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [118358] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_exc_varharborfishes004.dds",
                ["itemDesc"] = "Fish, Medium",
                ["oldestTime"] = 1633124169,
                ["wasAltered"] = true,
                ["newestTime"] = 1633124169,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 123,
                        ["guild"] = 1,
                        ["buyer"] = 1071,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633124169,
                        ["quant"] = 1,
                        ["id"] = "1691136163",
                        ["itemLink"] = 1460,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings hearth",
            },
        },
        [175959] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Leyawiin Bench, Formal Wide",
                ["oldestTime"] = 1632964851,
                ["wasAltered"] = true,
                ["newestTime"] = 1632964851,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 2046,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632964851,
                        ["quant"] = 1,
                        ["id"] = "1690005193",
                        ["itemLink"] = 3948,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [61016] = 
        {
            ["50:16:4:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_akaviri_2hsword_c.dds",
                ["itemDesc"] = "Prismatic Greatblade",
                ["oldestTime"] = 1632982668,
                ["wasAltered"] = true,
                ["newestTime"] = 1632982668,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7485,
                        ["guild"] = 1,
                        ["buyer"] = 291,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1632982668,
                        ["quant"] = 1,
                        ["id"] = "1690146049",
                        ["itemLink"] = 295,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set orgnum's scales sword two-handed precise",
            },
        },
        [172122] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Amulet",
                ["oldestTime"] = 1633185045,
                ["wasAltered"] = true,
                ["newestTime"] = 1633302455,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 1389,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633185045,
                        ["quant"] = 1,
                        ["id"] = "1691629479",
                        ["itemLink"] = 1984,
                    },
                    [2] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 1389,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633185046,
                        ["quant"] = 1,
                        ["id"] = "1691629487",
                        ["itemLink"] = 1984,
                    },
                    [3] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633218689,
                        ["quant"] = 1,
                        ["id"] = "1691997631",
                        ["itemLink"] = 1984,
                    },
                    [4] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633218691,
                        ["quant"] = 1,
                        ["id"] = "1691997651",
                        ["itemLink"] = 1984,
                    },
                    [5] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2051,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633302453,
                        ["quant"] = 1,
                        ["id"] = "1692766101",
                        ["itemLink"] = 1984,
                    },
                    [6] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 2051,
                        ["wasKiosk"] = true,
                        ["seller"] = 1011,
                        ["timestamp"] = 1633302455,
                        ["quant"] = 1,
                        ["id"] = "1692766131",
                        ["itemLink"] = 1984,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set deadlands assassin neck robust",
            },
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Deadlands Assassin's Amulet",
                ["oldestTime"] = 1632877768,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297178,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1332,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633243563,
                        ["quant"] = 1,
                        ["id"] = "1692222241",
                        ["itemLink"] = 2561,
                    },
                    [2] = 
                    {
                        ["price"] = 3300,
                        ["guild"] = 1,
                        ["buyer"] = 2026,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633297178,
                        ["quant"] = 1,
                        ["id"] = "1692712499",
                        ["itemLink"] = 2561,
                    },
                    [3] = 
                    {
                        ["price"] = 10355,
                        ["guild"] = 1,
                        ["buyer"] = 2339,
                        ["wasKiosk"] = true,
                        ["seller"] = 494,
                        ["timestamp"] = 1632877768,
                        ["quant"] = 1,
                        ["id"] = "1689370641",
                        ["itemLink"] = 2561,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set deadlands assassin neck robust",
            },
        },
        [167003] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 91: Hazardous Alchemy Swords",
                ["oldestTime"] = 1633114044,
                ["wasAltered"] = true,
                ["newestTime"] = 1633114044,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 39999,
                        ["guild"] = 1,
                        ["buyer"] = 1008,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1633114044,
                        ["quant"] = 1,
                        ["id"] = "1691066001",
                        ["itemLink"] = 1374,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [180572] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_light_legs_a.dds",
                ["itemDesc"] = "Breeches of Dark Convergence",
                ["oldestTime"] = 1633001731,
                ["wasAltered"] = true,
                ["newestTime"] = 1633001731,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5150,
                        ["guild"] = 1,
                        ["buyer"] = 407,
                        ["wasKiosk"] = true,
                        ["seller"] = 408,
                        ["timestamp"] = 1633001731,
                        ["quant"] = 1,
                        ["id"] = "1690242199",
                        ["itemLink"] = 415,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set dark convergence legs sturdy",
            },
        },
        [68189] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Garlic-and-Pepper Venison Steak",
                ["oldestTime"] = 1633094979,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305799,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 125,
                        ["guild"] = 1,
                        ["buyer"] = 924,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1633094979,
                        ["quant"] = 1,
                        ["id"] = "1690919105",
                        ["itemLink"] = 1258,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 924,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1633094981,
                        ["quant"] = 1,
                        ["id"] = "1690919119",
                        ["itemLink"] = 1258,
                    },
                    [3] = 
                    {
                        ["price"] = 79,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633305799,
                        ["quant"] = 1,
                        ["id"] = "1692798345",
                        ["itemLink"] = 1258,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [117087] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of the Powerful Assault",
                ["oldestTime"] = 1632835244,
                ["wasAltered"] = true,
                ["newestTime"] = 1633067884,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 765,
                        ["wasKiosk"] = false,
                        ["seller"] = 832,
                        ["timestamp"] = 1633067884,
                        ["quant"] = 1,
                        ["id"] = "1690766589",
                        ["itemLink"] = 1077,
                    },
                    [2] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 2152,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1632835244,
                        ["quant"] = 1,
                        ["id"] = "1689028873",
                        ["itemLink"] = 1077,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set powerful assault ring robust",
            },
        },
        [149090] = 
        {
            ["50:16:3:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_anequina_staff_a.dds",
                ["itemDesc"] = "Undertaker's Lightning Staff",
                ["oldestTime"] = 1632843683,
                ["wasAltered"] = true,
                ["newestTime"] = 1632843683,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1632843683,
                        ["quant"] = 1,
                        ["id"] = "1689089159",
                        ["itemLink"] = 3185,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set call of the undertaker lightning staff two-handed powered",
            },
        },
        [167523] = 
        {
            ["50:16:3:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_arkthzand_staff_a.dds",
                ["itemDesc"] = "Restoration Staff of the Radiant Bastion",
                ["oldestTime"] = 1632868146,
                ["wasAltered"] = true,
                ["newestTime"] = 1632868146,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1448,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1632868146,
                        ["quant"] = 1,
                        ["id"] = "1689288869",
                        ["itemLink"] = 3368,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set radiant bastion healing staff two-handed sharpened",
            },
        },
        [165732] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_fur_housingbookshelffancyfilled004.dds",
                ["itemDesc"] = "Solitude Bookcase, Narrow Open Filled",
                ["oldestTime"] = 1633297839,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297839,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 49920,
                        ["guild"] = 1,
                        ["buyer"] = 2029,
                        ["wasKiosk"] = true,
                        ["seller"] = 643,
                        ["timestamp"] = 1633297839,
                        ["quant"] = 2,
                        ["id"] = "1692719307",
                        ["itemLink"] = 2893,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings library",
            },
        },
        [76901] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 38: Draugr Gloves",
                ["oldestTime"] = 1632952471,
                ["wasAltered"] = true,
                ["newestTime"] = 1633314475,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 74,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633314475,
                        ["quant"] = 1,
                        ["id"] = "1692896111",
                        ["itemLink"] = 56,
                    },
                    [2] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 430,
                        ["wasKiosk"] = true,
                        ["seller"] = 94,
                        ["timestamp"] = 1633008888,
                        ["quant"] = 1,
                        ["id"] = "1690282125",
                        ["itemLink"] = 56,
                    },
                    [3] = 
                    {
                        ["price"] = 3237,
                        ["guild"] = 1,
                        ["buyer"] = 2596,
                        ["wasKiosk"] = true,
                        ["seller"] = 159,
                        ["timestamp"] = 1632952471,
                        ["quant"] = 1,
                        ["id"] = "1689896515",
                        ["itemLink"] = 56,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [145512] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Murkmire Treasure Map II",
                ["oldestTime"] = 1633310233,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310233,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633310233,
                        ["quant"] = 1,
                        ["id"] = "1692851305",
                        ["itemLink"] = 2988,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [68201] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Sticky Pork and Radish Noodles",
                ["oldestTime"] = 1633229361,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305810,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50,
                        ["guild"] = 1,
                        ["buyer"] = 1679,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633229361,
                        ["quant"] = 1,
                        ["id"] = "1692109747",
                        ["itemLink"] = 2433,
                    },
                    [2] = 
                    {
                        ["price"] = 898,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633305810,
                        ["quant"] = 1,
                        ["id"] = "1692798423",
                        ["itemLink"] = 2433,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [126571] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_dae_lsb_lantern001.dds",
                ["itemDesc"] = "Daedric Chandelier, Spiked",
                ["oldestTime"] = 1632851114,
                ["wasAltered"] = true,
                ["newestTime"] = 1632851119,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 175,
                        ["wasKiosk"] = false,
                        ["seller"] = 669,
                        ["timestamp"] = 1632851114,
                        ["quant"] = 1,
                        ["id"] = "1689152703",
                        ["itemLink"] = 3237,
                    },
                    [2] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 175,
                        ["wasKiosk"] = false,
                        ["seller"] = 669,
                        ["timestamp"] = 1632851119,
                        ["quant"] = 1,
                        ["id"] = "1689152757",
                        ["itemLink"] = 3237,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [123501] = 
        {
            ["50:16:4:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_staff_a.dds",
                ["itemDesc"] = "Coward's Gear Restoration Staff",
                ["oldestTime"] = 1633200772,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200772,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1491,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1633200772,
                        ["quant"] = 1,
                        ["id"] = "1691797475",
                        ["itemLink"] = 2202,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set coward's gear healing staff two-handed training",
            },
        },
        [86638] = 
        {
            ["50:16:3:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_heavy_hands_d.dds",
                ["itemDesc"] = "Gauntlets of the Storm Knight",
                ["oldestTime"] = 1633200746,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200746,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 390,
                        ["guild"] = 1,
                        ["buyer"] = 1491,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633200746,
                        ["quant"] = 1,
                        ["id"] = "1691797221",
                        ["itemLink"] = 2196,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set storm knight's plate hands reinforced",
            },
        },
        [42863] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_fishing_perch.dds",
                ["itemDesc"] = "Spadetail",
                ["oldestTime"] = 1632904244,
                ["wasAltered"] = true,
                ["newestTime"] = 1633283503,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 255,
                        ["wasKiosk"] = false,
                        ["seller"] = 218,
                        ["timestamp"] = 1633024183,
                        ["quant"] = 20,
                        ["id"] = "1690399519",
                        ["itemLink"] = 674,
                    },
                    [2] = 
                    {
                        ["price"] = 1642,
                        ["guild"] = 1,
                        ["buyer"] = 1945,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1633283501,
                        ["quant"] = 3,
                        ["id"] = "1692551415",
                        ["itemLink"] = 674,
                    },
                    [3] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 1945,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633283503,
                        ["quant"] = 20,
                        ["id"] = "1692551433",
                        ["itemLink"] = 674,
                    },
                    [4] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 218,
                        ["timestamp"] = 1632904244,
                        ["quant"] = 20,
                        ["id"] = "1689579609",
                        ["itemLink"] = 674,
                    },
                    [5] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 261,
                        ["wasKiosk"] = false,
                        ["seller"] = 218,
                        ["timestamp"] = 1632904245,
                        ["quant"] = 20,
                        ["id"] = "1689579611",
                        ["itemLink"] = 674,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 white normal consumable fish",
            },
        },
        [118896] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_aqa_sanddollar001.dds",
                ["itemDesc"] = "Seashell, Sandcake",
                ["oldestTime"] = 1633239366,
                ["wasAltered"] = true,
                ["newestTime"] = 1633239366,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1760,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1633239366,
                        ["quant"] = 1,
                        ["id"] = "1692193503",
                        ["itemLink"] = 2522,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings conservatory",
            },
        },
        [56945] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Summerset Rainbow Pie",
                ["oldestTime"] = 1633155623,
                ["wasAltered"] = true,
                ["newestTime"] = 1633155623,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2900,
                        ["guild"] = 1,
                        ["buyer"] = 1281,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633155623,
                        ["quant"] = 1,
                        ["id"] = "1691436455",
                        ["itemLink"] = 1746,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [45939] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Pumpkin Puree",
                ["oldestTime"] = 1632970422,
                ["wasAltered"] = true,
                ["newestTime"] = 1633306718,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20,
                        ["guild"] = 1,
                        ["buyer"] = 169,
                        ["wasKiosk"] = true,
                        ["seller"] = 170,
                        ["timestamp"] = 1632970422,
                        ["quant"] = 1,
                        ["id"] = "1690060551",
                        ["itemLink"] = 181,
                    },
                    [2] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633306718,
                        ["quant"] = 1,
                        ["id"] = "1692806759",
                        ["itemLink"] = 181,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [43636] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Grahtwood Treasure Map VI",
                ["oldestTime"] = 1632961997,
                ["wasAltered"] = true,
                ["newestTime"] = 1633182506,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 279,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182506,
                        ["quant"] = 1,
                        ["id"] = "1691608065",
                        ["itemLink"] = 1946,
                    },
                    [2] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2639,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1632961997,
                        ["quant"] = 1,
                        ["id"] = "1689975155",
                        ["itemLink"] = 1946,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [56949] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Kragenmoor Pickled Pumpkin",
                ["oldestTime"] = 1633185112,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185112,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 120,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1633185112,
                        ["quant"] = 1,
                        ["id"] = "1691630107",
                        ["itemLink"] = 1986,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [43648] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Malabal Tor Treasure Map VI",
                ["oldestTime"] = 1633310234,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310234,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633310234,
                        ["quant"] = 1,
                        ["id"] = "1692851329",
                        ["itemLink"] = 2989,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [49140] = 
        {
            ["10:0:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_soulshriven_bow_a.dds",
                ["itemDesc"] = "Bow of the Night Mother",
                ["oldestTime"] = 1633249617,
                ["wasAltered"] = true,
                ["newestTime"] = 1633249617,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 1812,
                        ["wasKiosk"] = true,
                        ["seller"] = 426,
                        ["timestamp"] = 1633249617,
                        ["quant"] = 1,
                        ["id"] = "1692267745",
                        ["itemLink"] = 2591,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr10 blue superior weapon set night mother's gaze bow two-handed training",
            },
        },
        [178452] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Nibenese Court Wizard Robe",
                ["oldestTime"] = 1632952523,
                ["wasAltered"] = true,
                ["newestTime"] = 1632952523,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 2597,
                        ["wasKiosk"] = true,
                        ["seller"] = 1899,
                        ["timestamp"] = 1632952523,
                        ["quant"] = 1,
                        ["id"] = "1689897051",
                        ["itemLink"] = 3852,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [171898] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 101: Ivory Brigade Boots",
                ["oldestTime"] = 1633195358,
                ["wasAltered"] = true,
                ["newestTime"] = 1633313747,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 61,
                        ["wasKiosk"] = false,
                        ["seller"] = 62,
                        ["timestamp"] = 1633313747,
                        ["quant"] = 1,
                        ["id"] = "1692888365",
                        ["itemLink"] = 43,
                    },
                    [2] = 
                    {
                        ["price"] = 8100,
                        ["guild"] = 1,
                        ["buyer"] = 1446,
                        ["wasKiosk"] = true,
                        ["seller"] = 1128,
                        ["timestamp"] = 1633195358,
                        ["quant"] = 1,
                        ["id"] = "1691745403",
                        ["itemLink"] = 43,
                    },
                    [3] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 151,
                        ["wasKiosk"] = false,
                        ["seller"] = 144,
                        ["timestamp"] = 1633203443,
                        ["quant"] = 1,
                        ["id"] = "1691828257",
                        ["itemLink"] = 43,
                    },
                    [4] = 
                    {
                        ["price"] = 8900,
                        ["guild"] = 1,
                        ["buyer"] = 1770,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633240312,
                        ["quant"] = 1,
                        ["id"] = "1692199919",
                        ["itemLink"] = 43,
                    },
                    [5] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 550,
                        ["wasKiosk"] = false,
                        ["seller"] = 33,
                        ["timestamp"] = 1633275985,
                        ["quant"] = 1,
                        ["id"] = "1692475833",
                        ["itemLink"] = 43,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [151675] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_exc_merchantcontainer004.dds",
                ["itemDesc"] = "Elsweyr Stall Counter, Triple",
                ["oldestTime"] = 1633142175,
                ["wasAltered"] = true,
                ["newestTime"] = 1633142175,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 1198,
                        ["wasKiosk"] = true,
                        ["seller"] = 17,
                        ["timestamp"] = 1633142175,
                        ["quant"] = 1,
                        ["id"] = "1691314943",
                        ["itemLink"] = 1621,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [68486] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_trinimac_light_head_a.dds",
                ["itemDesc"] = "Hat of Trinimac's Valor",
                ["oldestTime"] = 1632950999,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950999,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1400,
                        ["guild"] = 1,
                        ["buyer"] = 631,
                        ["wasKiosk"] = true,
                        ["seller"] = 534,
                        ["timestamp"] = 1632950999,
                        ["quant"] = 1,
                        ["id"] = "1689881661",
                        ["itemLink"] = 3841,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set trinimac's valor head divines",
            },
        },
        [145533] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_elderargonian_r2.dds",
                ["itemDesc"] = "Hackwing Plumage",
                ["oldestTime"] = 1633205141,
                ["wasAltered"] = true,
                ["newestTime"] = 1633205141,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 29265,
                        ["guild"] = 1,
                        ["buyer"] = 1520,
                        ["wasKiosk"] = true,
                        ["seller"] = 402,
                        ["timestamp"] = 1633205141,
                        ["quant"] = 8,
                        ["id"] = "1691843807",
                        ["itemLink"] = 2248,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [153726] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Elsweyr Platform, Ancient Rectangular",
                ["oldestTime"] = 1633056413,
                ["wasAltered"] = true,
                ["newestTime"] = 1633056413,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2499999,
                        ["guild"] = 1,
                        ["buyer"] = 747,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633056413,
                        ["quant"] = 1,
                        ["id"] = "1690669935",
                        ["itemLink"] = 957,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [126591] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_fan_forestcoralplant002.dds",
                ["itemDesc"] = "Vvardenfell Coral Plant, Young",
                ["oldestTime"] = 1632851078,
                ["wasAltered"] = true,
                ["newestTime"] = 1632851078,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6555,
                        ["guild"] = 1,
                        ["buyer"] = 175,
                        ["wasKiosk"] = false,
                        ["seller"] = 333,
                        ["timestamp"] = 1632851078,
                        ["quant"] = 1,
                        ["id"] = "1689152429",
                        ["itemLink"] = 3234,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings conservatory",
            },
        },
        [45184] = 
        {
            ["50:16:2:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_medium_head_d.dds",
                ["itemDesc"] = "Rubedo Leather Helmet of Stamina",
                ["oldestTime"] = 1633246672,
                ["wasAltered"] = true,
                ["newestTime"] = 1633246672,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 245,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633246672,
                        ["quant"] = 1,
                        ["id"] = "1692246845",
                        ["itemLink"] = 2580,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel head training",
            },
        },
        [147329] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Abnur Tharn's Gloves",
                ["oldestTime"] = 1632981372,
                ["wasAltered"] = true,
                ["newestTime"] = 1633196010,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 268,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632981372,
                        ["quant"] = 1,
                        ["id"] = "1690138519",
                        ["itemLink"] = 279,
                    },
                    [2] = 
                    {
                        ["price"] = 425,
                        ["guild"] = 1,
                        ["buyer"] = 1454,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1633196010,
                        ["quant"] = 1,
                        ["id"] = "1691750491",
                        ["itemLink"] = 279,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [86761] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_head_d.dds",
                ["itemDesc"] = "Hat of Necropotence",
                ["oldestTime"] = 1632931034,
                ["wasAltered"] = true,
                ["newestTime"] = 1632931034,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2518,
                        ["wasKiosk"] = true,
                        ["seller"] = 177,
                        ["timestamp"] = 1632931034,
                        ["quant"] = 1,
                        ["id"] = "1689729357",
                        ["itemLink"] = 3714,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set necropotence head infused",
            },
        },
        [161430] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_heavy_feet_d.dds",
                ["itemDesc"] = "Stuhn's Sabatons",
                ["oldestTime"] = 1632930913,
                ["wasAltered"] = true,
                ["newestTime"] = 1632930913,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 2517,
                        ["wasKiosk"] = true,
                        ["seller"] = 819,
                        ["timestamp"] = 1632930913,
                        ["quant"] = 1,
                        ["id"] = "1689728675",
                        ["itemLink"] = 3709,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set stuhn's favor feet impenetrable",
            },
        },
        [176004] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning2.dds",
                ["itemDesc"] = "Design: Leyawiin Teacup, Full",
                ["oldestTime"] = 1633129714,
                ["wasAltered"] = true,
                ["newestTime"] = 1633272466,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 2,
                        ["buyer"] = 139,
                        ["wasKiosk"] = false,
                        ["seller"] = 117,
                        ["timestamp"] = 1633206188,
                        ["quant"] = 1,
                        ["id"] = "1691857563",
                        ["itemLink"] = 158,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1099,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633129714,
                        ["quant"] = 1,
                        ["id"] = "1691182989",
                        ["itemLink"] = 158,
                    },
                    [3] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 1362,
                        ["wasKiosk"] = true,
                        ["seller"] = 911,
                        ["timestamp"] = 1633179477,
                        ["quant"] = 1,
                        ["id"] = "1691582767",
                        ["itemLink"] = 158,
                    },
                    [4] = 
                    {
                        ["price"] = 340,
                        ["guild"] = 1,
                        ["buyer"] = 1643,
                        ["wasKiosk"] = true,
                        ["seller"] = 911,
                        ["timestamp"] = 1633272466,
                        ["quant"] = 1,
                        ["id"] = "1692431769",
                        ["itemLink"] = 158,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [171563] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 100: True-Sworn Shoulders",
                ["oldestTime"] = 1632925340,
                ["wasAltered"] = true,
                ["newestTime"] = 1632925340,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 2498,
                        ["wasKiosk"] = true,
                        ["seller"] = 712,
                        ["timestamp"] = 1632925340,
                        ["quant"] = 1,
                        ["id"] = "1689688969",
                        ["itemLink"] = 3684,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [98182] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_medium_hands_d.dds",
                ["itemDesc"] = "Bracers of the Ranger",
                ["oldestTime"] = 1633099352,
                ["wasAltered"] = true,
                ["newestTime"] = 1633099352,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1150,
                        ["guild"] = 1,
                        ["buyer"] = 940,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633099352,
                        ["quant"] = 1,
                        ["id"] = "1690952241",
                        ["itemLink"] = 1275,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set ranger's gait hands divines",
            },
        },
        [46055] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Bitter Ritual Tea",
                ["oldestTime"] = 1632923721,
                ["wasAltered"] = true,
                ["newestTime"] = 1632923721,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632923721,
                        ["quant"] = 1,
                        ["id"] = "1689677397",
                        ["itemLink"] = 3671,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [160648] = 
        {
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_blackreachexlgt_shoulders.dds",
                ["itemDesc"] = "Epaulets of Winter's Respite",
                ["oldestTime"] = 1633232507,
                ["wasAltered"] = true,
                ["newestTime"] = 1633232507,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4600,
                        ["guild"] = 1,
                        ["buyer"] = 1706,
                        ["wasKiosk"] = true,
                        ["seller"] = 281,
                        ["timestamp"] = 1633232507,
                        ["quant"] = 1,
                        ["id"] = "1692140279",
                        ["itemLink"] = 2449,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set winter's respite shoulders infused",
            },
        },
        [144752] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_2haxe_a.dds",
                ["itemDesc"] = "Steadfast Hero Battle Axe",
                ["oldestTime"] = 1632912429,
                ["wasAltered"] = true,
                ["newestTime"] = 1632912429,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2467,
                        ["wasKiosk"] = true,
                        ["seller"] = 529,
                        ["timestamp"] = 1632912429,
                        ["quant"] = 1,
                        ["id"] = "1689610255",
                        ["itemLink"] = 3621,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set steadfast hero axe two-handed charged",
            },
        },
        [68211] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Kragenmoor Zinger Mazte",
                ["oldestTime"] = 1633261632,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261632,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633261632,
                        ["quant"] = 1,
                        ["id"] = "1692334547",
                        ["itemLink"] = 2626,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [56971] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Savory Banana Cornbread",
                ["oldestTime"] = 1633052895,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052895,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633052895,
                        ["quant"] = 1,
                        ["id"] = "1690634279",
                        ["itemLink"] = 923,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [100246] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_medium_chest_d.dds",
                ["itemDesc"] = "Fiord's Jack",
                ["oldestTime"] = 1632890735,
                ["wasAltered"] = true,
                ["newestTime"] = 1632890735,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2411,
                        ["wasKiosk"] = true,
                        ["seller"] = 697,
                        ["timestamp"] = 1632890735,
                        ["quant"] = 1,
                        ["id"] = "1689497947",
                        ["itemLink"] = 3537,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set fiord's legacy chest divines",
            },
        },
        [132555] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_cwc_inc_scrollplate001.dds",
                ["itemDesc"] = "Crafting Motif 56: Apostle Daggers",
                ["oldestTime"] = 1632883704,
                ["wasAltered"] = true,
                ["newestTime"] = 1632883704,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 719,
                        ["wasKiosk"] = true,
                        ["seller"] = 547,
                        ["timestamp"] = 1632883704,
                        ["quant"] = 1,
                        ["id"] = "1689435671",
                        ["itemLink"] = 3489,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [119470] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning3.dds",
                ["itemDesc"] = "Design: Cured Meat Chunk",
                ["oldestTime"] = 1632882788,
                ["wasAltered"] = true,
                ["newestTime"] = 1632882788,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1173,
                        ["guild"] = 1,
                        ["buyer"] = 2369,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1632882788,
                        ["quant"] = 1,
                        ["id"] = "1689426269",
                        ["itemLink"] = 3480,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [102203] = 
        {
            ["50:16:2:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_draugr_staff_a.dds",
                ["itemDesc"] = "Stygian Lightning Staff",
                ["oldestTime"] = 1632882696,
                ["wasAltered"] = true,
                ["newestTime"] = 1632882696,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 999,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1632882696,
                        ["quant"] = 1,
                        ["id"] = "1689425211",
                        ["itemLink"] = 3479,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set stygian lightning staff two-handed decisive",
            },
        },
        [119696] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_alchemy.dds",
                ["itemDesc"] = "Sealed Alchemy Writ",
                ["oldestTime"] = 1632974035,
                ["wasAltered"] = true,
                ["newestTime"] = 1632974035,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 200,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1632974035,
                        ["quant"] = 1,
                        ["id"] = "1690090393",
                        ["itemLink"] = 213,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [145486] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_arg_str_dbhdoor001.dds",
                ["itemDesc"] = "Door, Sweet Mother",
                ["oldestTime"] = 1632879927,
                ["wasAltered"] = true,
                ["newestTime"] = 1632879927,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 2331,
                        ["wasKiosk"] = true,
                        ["seller"] = 669,
                        ["timestamp"] = 1632879927,
                        ["quant"] = 1,
                        ["id"] = "1689395759",
                        ["itemLink"] = 3451,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary furnishings structures",
            },
        },
        [119698] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_alchemy.dds",
                ["itemDesc"] = "Sealed Alchemy Writ",
                ["oldestTime"] = 1632974028,
                ["wasAltered"] = true,
                ["newestTime"] = 1633307858,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 200,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632974028,
                        ["quant"] = 1,
                        ["id"] = "1690090335",
                        ["itemLink"] = 210,
                    },
                    [2] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 200,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632974032,
                        ["quant"] = 1,
                        ["id"] = "1690090355",
                        ["itemLink"] = 212,
                    },
                    [3] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2075,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633307853,
                        ["quant"] = 1,
                        ["id"] = "1692821557",
                        ["itemLink"] = 2952,
                    },
                    [4] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 2075,
                        ["wasKiosk"] = true,
                        ["seller"] = 47,
                        ["timestamp"] = 1633307857,
                        ["quant"] = 1,
                        ["id"] = "1692821595",
                        ["itemLink"] = 2954,
                    },
                    [5] = 
                    {
                        ["price"] = 9538,
                        ["guild"] = 1,
                        ["buyer"] = 2075,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633307858,
                        ["quant"] = 1,
                        ["id"] = "1692821597",
                        ["itemLink"] = 2954,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [87699] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/disastrously_bloody_mara.dds",
                ["itemDesc"] = "Purifying Bloody Mara",
                ["oldestTime"] = 1632865490,
                ["wasAltered"] = true,
                ["newestTime"] = 1633135766,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 23000,
                        ["guild"] = 1,
                        ["buyer"] = 1144,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1633135766,
                        ["quant"] = 100,
                        ["id"] = "1691251253",
                        ["itemLink"] = 1561,
                    },
                    [2] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 2264,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1632865490,
                        ["quant"] = 15,
                        ["id"] = "1689268661",
                        ["itemLink"] = 1561,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary consumable drink",
            },
        },
        [119700] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_alchemy.dds",
                ["itemDesc"] = "Sealed Alchemy Writ",
                ["oldestTime"] = 1632864541,
                ["wasAltered"] = true,
                ["newestTime"] = 1633108765,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 974,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633108765,
                        ["quant"] = 1,
                        ["id"] = "1691027489",
                        ["itemLink"] = 1308,
                    },
                    [2] = 
                    {
                        ["price"] = 19995,
                        ["guild"] = 1,
                        ["buyer"] = 2256,
                        ["wasKiosk"] = true,
                        ["seller"] = 975,
                        ["timestamp"] = 1632864541,
                        ["quant"] = 1,
                        ["id"] = "1689262177",
                        ["itemLink"] = 3325,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [139413] = 
        {
            ["1:0:1:29:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_metals_tin.dds",
                ["itemDesc"] = "Dibellium",
                ["oldestTime"] = 1632827180,
                ["wasAltered"] = true,
                ["newestTime"] = 1633255853,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9300,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 732,
                        ["timestamp"] = 1633068268,
                        ["quant"] = 3,
                        ["id"] = "1690768805",
                        ["itemLink"] = 1078,
                    },
                    [2] = 
                    {
                        ["price"] = 3251,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633068269,
                        ["quant"] = 1,
                        ["id"] = "1690768807",
                        ["itemLink"] = 1078,
                    },
                    [3] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633154982,
                        ["quant"] = 1,
                        ["id"] = "1691431341",
                        ["itemLink"] = 1078,
                    },
                    [4] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1830,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633255853,
                        ["quant"] = 1,
                        ["id"] = "1692307201",
                        ["itemLink"] = 1078,
                    },
                    [5] = 
                    {
                        ["price"] = 11193,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 2123,
                        ["timestamp"] = 1632827180,
                        ["quant"] = 3,
                        ["id"] = "1688977031",
                        ["itemLink"] = 1078,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 white normal materials jewelry trait harmony",
            },
        },
        [43670] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Shadowfen Treasure Map IV",
                ["oldestTime"] = 1633047200,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294847,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 682,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633047200,
                        ["quant"] = 1,
                        ["id"] = "1690577403",
                        ["itemLink"] = 868,
                    },
                    [2] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 175,
                        ["wasKiosk"] = false,
                        ["seller"] = 202,
                        ["timestamp"] = 1633294847,
                        ["quant"] = 1,
                        ["id"] = "1692688913",
                        ["itemLink"] = 868,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [180887] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_1haxe_a.dds",
                ["itemDesc"] = "Hrothgar's Axe",
                ["oldestTime"] = 1633112444,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112444,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 991,
                        ["wasKiosk"] = true,
                        ["seller"] = 13,
                        ["timestamp"] = 1633112444,
                        ["quant"] = 1,
                        ["id"] = "1691055283",
                        ["itemLink"] = 1350,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set hrothgar's chill axe one-handed decisive",
            },
        },
        [119704] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_alchemy.dds",
                ["itemDesc"] = "Sealed Alchemy Writ",
                ["oldestTime"] = 1632864540,
                ["wasAltered"] = true,
                ["newestTime"] = 1633307859,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 2,
                        ["buyer"] = 139,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1633205962,
                        ["quant"] = 1,
                        ["id"] = "1691854371",
                        ["itemLink"] = 156,
                    },
                    [2] = 
                    {
                        ["price"] = 9850,
                        ["guild"] = 1,
                        ["buyer"] = 300,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1632983636,
                        ["quant"] = 1,
                        ["id"] = "1690151881",
                        ["itemLink"] = 304,
                    },
                    [3] = 
                    {
                        ["price"] = 10236,
                        ["guild"] = 1,
                        ["buyer"] = 2075,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633307858,
                        ["quant"] = 1,
                        ["id"] = "1692821601",
                        ["itemLink"] = 2955,
                    },
                    [4] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 2075,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1633307859,
                        ["quant"] = 1,
                        ["id"] = "1692821607",
                        ["itemLink"] = 304,
                    },
                    [5] = 
                    {
                        ["price"] = 19995,
                        ["guild"] = 1,
                        ["buyer"] = 2256,
                        ["wasKiosk"] = true,
                        ["seller"] = 975,
                        ["timestamp"] = 1632864540,
                        ["quant"] = 1,
                        ["id"] = "1689262147",
                        ["itemLink"] = 3324,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [119705] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_alchemy.dds",
                ["itemDesc"] = "Sealed Alchemy Writ",
                ["oldestTime"] = 1633108767,
                ["wasAltered"] = true,
                ["newestTime"] = 1633208282,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7200,
                        ["guild"] = 1,
                        ["buyer"] = 974,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633108767,
                        ["quant"] = 1,
                        ["id"] = "1691027505",
                        ["itemLink"] = 1309,
                    },
                    [2] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 974,
                        ["wasKiosk"] = true,
                        ["seller"] = 975,
                        ["timestamp"] = 1633108768,
                        ["quant"] = 1,
                        ["id"] = "1691027517",
                        ["itemLink"] = 1310,
                    },
                    [3] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 903,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633208282,
                        ["quant"] = 1,
                        ["id"] = "1691886193",
                        ["itemLink"] = 2263,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [69530] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 21: Ancient Orc Boots",
                ["oldestTime"] = 1633052146,
                ["wasAltered"] = true,
                ["newestTime"] = 1633071237,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13999,
                        ["guild"] = 1,
                        ["buyer"] = 242,
                        ["wasKiosk"] = false,
                        ["seller"] = 163,
                        ["timestamp"] = 1633052146,
                        ["quant"] = 1,
                        ["id"] = "1690627477",
                        ["itemLink"] = 899,
                    },
                    [2] = 
                    {
                        ["price"] = 13999,
                        ["guild"] = 1,
                        ["buyer"] = 844,
                        ["wasKiosk"] = true,
                        ["seller"] = 163,
                        ["timestamp"] = 1633071237,
                        ["quant"] = 1,
                        ["id"] = "1690785679",
                        ["itemLink"] = 899,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [139400] = 
        {
            ["1:0:1:29:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Pewter Ring",
                ["oldestTime"] = 1632879748,
                ["wasAltered"] = true,
                ["newestTime"] = 1632879748,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10355,
                        ["guild"] = 1,
                        ["buyer"] = 983,
                        ["wasKiosk"] = true,
                        ["seller"] = 2123,
                        ["timestamp"] = 1632879748,
                        ["quant"] = 1,
                        ["id"] = "1689394157",
                        ["itemLink"] = 3447,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal jewelry apparel ring harmony",
            },
        },
        [119403] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Common Table, Slanted",
                ["oldestTime"] = 1632874521,
                ["wasAltered"] = true,
                ["newestTime"] = 1632874521,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 83,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632874521,
                        ["quant"] = 1,
                        ["id"] = "1689336307",
                        ["itemLink"] = 3405,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [45213] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_light_shoulders_d.dds",
                ["itemDesc"] = "Ancestor Silk Epaulets of Stamina",
                ["oldestTime"] = 1632944589,
                ["wasAltered"] = true,
                ["newestTime"] = 1632944589,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 120,
                        ["guild"] = 1,
                        ["buyer"] = 2561,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632944589,
                        ["quant"] = 1,
                        ["id"] = "1689831895",
                        ["itemLink"] = 3784,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel shoulders infused",
            },
            ["50:16:3:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_light_shoulders_d.dds",
                ["itemDesc"] = "Ancestor Silk Epaulets of Stamina",
                ["oldestTime"] = 1633185975,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185975,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 204,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633185975,
                        ["quant"] = 1,
                        ["id"] = "1691640469",
                        ["itemLink"] = 2042,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel shoulders infused",
            },
        },
        [172190] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_bow_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Bow",
                ["oldestTime"] = 1633180972,
                ["wasAltered"] = true,
                ["newestTime"] = 1633180972,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 425,
                        ["guild"] = 1,
                        ["buyer"] = 1370,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633180972,
                        ["quant"] = 1,
                        ["id"] = "1691592329",
                        ["itemLink"] = 1929,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set deadlands assassin bow two-handed defending",
            },
        },
        [45038] = 
        {
            ["50:16:2:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_shoulders_d.dds",
                ["itemDesc"] = "Ancestor Silk Epaulets of Magicka",
                ["oldestTime"] = 1632857765,
                ["wasAltered"] = true,
                ["newestTime"] = 1632857765,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1632857765,
                        ["quant"] = 1,
                        ["id"] = "1689212037",
                        ["itemLink"] = 3285,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel shoulders sturdy",
            },
        },
        [156576] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 77: Stags of Z'en Boots",
                ["oldestTime"] = 1633052858,
                ["wasAltered"] = true,
                ["newestTime"] = 1633118572,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 47000,
                        ["guild"] = 1,
                        ["buyer"] = 719,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1633052858,
                        ["quant"] = 1,
                        ["id"] = "1690633831",
                        ["itemLink"] = 920,
                    },
                    [2] = 
                    {
                        ["price"] = 45000,
                        ["guild"] = 1,
                        ["buyer"] = 1038,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633118572,
                        ["quant"] = 1,
                        ["id"] = "1691095857",
                        ["itemLink"] = 920,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [43698] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Khenarthi's Roost Treasure Map IV",
                ["oldestTime"] = 1633006764,
                ["wasAltered"] = true,
                ["newestTime"] = 1633006764,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 424,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633006764,
                        ["quant"] = 1,
                        ["id"] = "1690269619",
                        ["itemLink"] = 435,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [123040] = 
        {
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_hlaalu_medium_hands_a.dds",
                ["itemDesc"] = "Defiler's Bracers",
                ["oldestTime"] = 1632845217,
                ["wasAltered"] = true,
                ["newestTime"] = 1632845217,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2195,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1632845217,
                        ["quant"] = 1,
                        ["id"] = "1689102081",
                        ["itemLink"] = 3191,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set defiler hands well-fitted",
            },
        },
        [139073] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_inc_paintingwood005.dds",
                ["itemDesc"] = "Painting of Summerset Coast, Refined",
                ["oldestTime"] = 1632841949,
                ["wasAltered"] = true,
                ["newestTime"] = 1632841949,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1847,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1632841949,
                        ["quant"] = 1,
                        ["id"] = "1689073703",
                        ["itemLink"] = 3158,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings gallery",
            },
        },
        [132583] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 57: Ebonshadow Belts",
                ["oldestTime"] = 1632841712,
                ["wasAltered"] = true,
                ["newestTime"] = 1632852099,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7495,
                        ["guild"] = 1,
                        ["buyer"] = 2185,
                        ["wasKiosk"] = true,
                        ["seller"] = 2186,
                        ["timestamp"] = 1632841712,
                        ["quant"] = 1,
                        ["id"] = "1689072591",
                        ["itemLink"] = 3156,
                    },
                    [2] = 
                    {
                        ["price"] = 7495,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 2186,
                        ["timestamp"] = 1632852091,
                        ["quant"] = 1,
                        ["id"] = "1689159937",
                        ["itemLink"] = 3156,
                    },
                    [3] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 161,
                        ["timestamp"] = 1632852099,
                        ["quant"] = 1,
                        ["id"] = "1689160019",
                        ["itemLink"] = 3156,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [56997] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Late-Summer Corn Slaw",
                ["oldestTime"] = 1633267913,
                ["wasAltered"] = true,
                ["newestTime"] = 1633267913,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1100,
                        ["guild"] = 1,
                        ["buyer"] = 1864,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633267913,
                        ["quant"] = 1,
                        ["id"] = "1692383875",
                        ["itemLink"] = 2648,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [46139] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_wood_sanded_birch.dds",
                ["itemDesc"] = "Sanded Birch",
                ["oldestTime"] = 1633007633,
                ["wasAltered"] = true,
                ["newestTime"] = 1633007633,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 175,
                        ["guild"] = 1,
                        ["buyer"] = 432,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633007633,
                        ["quant"] = 10,
                        ["id"] = "1690275231",
                        ["itemLink"] = 438,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [94354] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_heavy_shoulders_d.dds",
                ["itemDesc"] = "Pauldron of the Veiled Heritance",
                ["oldestTime"] = 1632835997,
                ["wasAltered"] = true,
                ["newestTime"] = 1632835997,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 490,
                        ["guild"] = 1,
                        ["buyer"] = 2156,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1632835997,
                        ["quant"] = 1,
                        ["id"] = "1689034257",
                        ["itemLink"] = 3102,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set armor of the veiled heritance shoulders impenetrable",
            },
        },
        [68191] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Lilmoth Garlic Hagfish",
                ["oldestTime"] = 1633150988,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305806,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 27,
                        ["guild"] = 1,
                        ["buyer"] = 1262,
                        ["wasKiosk"] = true,
                        ["seller"] = 78,
                        ["timestamp"] = 1633150988,
                        ["quant"] = 1,
                        ["id"] = "1691399221",
                        ["itemLink"] = 1724,
                    },
                    [2] = 
                    {
                        ["price"] = 79,
                        ["guild"] = 1,
                        ["buyer"] = 1262,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633150989,
                        ["quant"] = 1,
                        ["id"] = "1691399233",
                        ["itemLink"] = 1724,
                    },
                    [3] = 
                    {
                        ["price"] = 145,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1633243995,
                        ["quant"] = 1,
                        ["id"] = "1692225797",
                        ["itemLink"] = 1724,
                    },
                    [4] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633305802,
                        ["quant"] = 1,
                        ["id"] = "1692798371",
                        ["itemLink"] = 1724,
                    },
                    [5] = 
                    {
                        ["price"] = 445,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633305806,
                        ["quant"] = 1,
                        ["id"] = "1692798393",
                        ["itemLink"] = 1724,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [71573] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 23: Malacath Gloves",
                ["oldestTime"] = 1633310880,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310880,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 2091,
                        ["wasKiosk"] = true,
                        ["seller"] = 155,
                        ["timestamp"] = 1633310880,
                        ["quant"] = 1,
                        ["id"] = "1692858633",
                        ["itemLink"] = 2998,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [74666] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 35: Dro-m'Athra Swords",
                ["oldestTime"] = 1633297453,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297453,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 2028,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633297453,
                        ["quant"] = 1,
                        ["id"] = "1692715445",
                        ["itemLink"] = 2890,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [43693] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Betnikh Treasure Map I",
                ["oldestTime"] = 1633310237,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310237,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633310237,
                        ["quant"] = 1,
                        ["id"] = "1692851357",
                        ["itemLink"] = 2991,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [171948] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Frostbite",
                ["oldestTime"] = 1633042159,
                ["wasAltered"] = true,
                ["newestTime"] = 1633298140,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 615,
                        ["guild"] = 1,
                        ["buyer"] = 646,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633042159,
                        ["quant"] = 1,
                        ["id"] = "1690529849",
                        ["itemLink"] = 815,
                    },
                    [2] = 
                    {
                        ["price"] = 720,
                        ["guild"] = 1,
                        ["buyer"] = 705,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633051801,
                        ["quant"] = 1,
                        ["id"] = "1690624233",
                        ["itemLink"] = 815,
                    },
                    [3] = 
                    {
                        ["price"] = 734,
                        ["guild"] = 1,
                        ["buyer"] = 705,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1633051802,
                        ["quant"] = 1,
                        ["id"] = "1690624257",
                        ["itemLink"] = 815,
                    },
                    [4] = 
                    {
                        ["price"] = 1314,
                        ["guild"] = 1,
                        ["buyer"] = 1046,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1633119601,
                        ["quant"] = 1,
                        ["id"] = "1691102641",
                        ["itemLink"] = 815,
                    },
                    [5] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 197,
                        ["timestamp"] = 1633163909,
                        ["quant"] = 1,
                        ["id"] = "1691490307",
                        ["itemLink"] = 815,
                    },
                    [6] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 1389,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633185043,
                        ["quant"] = 1,
                        ["id"] = "1691629465",
                        ["itemLink"] = 815,
                    },
                    [7] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1159,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633191578,
                        ["quant"] = 1,
                        ["id"] = "1691708361",
                        ["itemLink"] = 815,
                    },
                    [8] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1813,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633249724,
                        ["quant"] = 1,
                        ["id"] = "1692268857",
                        ["itemLink"] = 815,
                    },
                    [9] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 42,
                        ["wasKiosk"] = false,
                        ["seller"] = 662,
                        ["timestamp"] = 1633295299,
                        ["quant"] = 1,
                        ["id"] = "1692693257",
                        ["itemLink"] = 815,
                    },
                    [10] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2032,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633298115,
                        ["quant"] = 1,
                        ["id"] = "1692722263",
                        ["itemLink"] = 815,
                    },
                    [11] = 
                    {
                        ["price"] = 1050,
                        ["guild"] = 1,
                        ["buyer"] = 2032,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1633298140,
                        ["quant"] = 1,
                        ["id"] = "1692722513",
                        ["itemLink"] = 815,
                    },
                },
                ["totalCount"] = 11,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set frostbite ring arcane",
            },
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Frostbite",
                ["oldestTime"] = 1633063302,
                ["wasAltered"] = true,
                ["newestTime"] = 1633218646,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 801,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633063302,
                        ["quant"] = 1,
                        ["id"] = "1690734483",
                        ["itemLink"] = 1040,
                    },
                    [2] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633218644,
                        ["quant"] = 1,
                        ["id"] = "1691997129",
                        ["itemLink"] = 1040,
                    },
                    [3] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 1148,
                        ["timestamp"] = 1633218646,
                        ["quant"] = 1,
                        ["id"] = "1691997149",
                        ["itemLink"] = 1040,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set frostbite ring arcane",
            },
            ["50:16:2:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Frostbite",
                ["oldestTime"] = 1633182280,
                ["wasAltered"] = true,
                ["newestTime"] = 1633191575,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 387,
                        ["guild"] = 1,
                        ["buyer"] = 1377,
                        ["wasKiosk"] = true,
                        ["seller"] = 662,
                        ["timestamp"] = 1633182280,
                        ["quant"] = 1,
                        ["id"] = "1691606377",
                        ["itemLink"] = 1935,
                    },
                    [2] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1159,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633191574,
                        ["quant"] = 1,
                        ["id"] = "1691708313",
                        ["itemLink"] = 1935,
                    },
                    [3] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1159,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633191575,
                        ["quant"] = 1,
                        ["id"] = "1691708323",
                        ["itemLink"] = 1935,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set frostbite ring arcane",
            },
        },
        [115885] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Wood Elf Bedding, Layered",
                ["oldestTime"] = 1633150066,
                ["wasAltered"] = true,
                ["newestTime"] = 1633150066,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1255,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633150066,
                        ["quant"] = 1,
                        ["id"] = "1691391611",
                        ["itemLink"] = 1717,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [95406] = 
        {
            ["50:16:4:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_medium_feet_a.dds",
                ["itemDesc"] = "Sabatons of the Fire",
                ["oldestTime"] = 1633244652,
                ["wasAltered"] = true,
                ["newestTime"] = 1633244652,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 1791,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633244652,
                        ["quant"] = 1,
                        ["id"] = "1692231083",
                        ["itemLink"] = 2564,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set way of fire feet sturdy",
            },
        },
        [82095] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 40: Order Hour Helmets",
                ["oldestTime"] = 1632965804,
                ["wasAltered"] = true,
                ["newestTime"] = 1632965804,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 2656,
                        ["wasKiosk"] = true,
                        ["seller"] = 163,
                        ["timestamp"] = 1632965804,
                        ["quant"] = 1,
                        ["id"] = "1690013621",
                        ["itemLink"] = 3954,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [43685] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Coldharbour Treasure Map I",
                ["oldestTime"] = 1633310217,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310233,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 386,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633310217,
                        ["quant"] = 1,
                        ["id"] = "1692851193",
                        ["itemLink"] = 2985,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633310233,
                        ["quant"] = 1,
                        ["id"] = "1692851317",
                        ["itemLink"] = 2985,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [140465] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 65: Huntsman Boots",
                ["oldestTime"] = 1632996923,
                ["wasAltered"] = true,
                ["newestTime"] = 1632996923,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 385,
                        ["wasKiosk"] = true,
                        ["seller"] = 386,
                        ["timestamp"] = 1632996923,
                        ["quant"] = 1,
                        ["id"] = "1690217385",
                        ["itemLink"] = 384,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [27058] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_dust_004.dds",
                ["itemDesc"] = "Seasoning",
                ["oldestTime"] = 1633042298,
                ["wasAltered"] = true,
                ["newestTime"] = 1633042298,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1800,
                        ["guild"] = 1,
                        ["buyer"] = 648,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1633042298,
                        ["quant"] = 200,
                        ["id"] = "1690531043",
                        ["itemLink"] = 820,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [140440] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 64: Pyandonean Shoulders",
                ["oldestTime"] = 1633293014,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293014,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 1986,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633293014,
                        ["quant"] = 1,
                        ["id"] = "1692662997",
                        ["itemLink"] = 2850,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [126900] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Hlaalu Jar, Sealed Malachite",
                ["oldestTime"] = 1633232460,
                ["wasAltered"] = true,
                ["newestTime"] = 1633232460,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 44000,
                        ["guild"] = 1,
                        ["buyer"] = 1705,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633232460,
                        ["quant"] = 1,
                        ["id"] = "1692139781",
                        ["itemLink"] = 2448,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [172213] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_staff_c.dds",
                ["itemDesc"] = "Deadlands Assassin's Lightning Staff",
                ["oldestTime"] = 1633278036,
                ["wasAltered"] = true,
                ["newestTime"] = 1633278036,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1999,
                        ["guild"] = 1,
                        ["buyer"] = 1914,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633278036,
                        ["quant"] = 1,
                        ["id"] = "1692495175",
                        ["itemLink"] = 2715,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set deadlands assassin lightning staff two-handed sharpened",
            },
        },
        [118966] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: High Elf End Table, Verdant",
                ["oldestTime"] = 1633098588,
                ["wasAltered"] = true,
                ["newestTime"] = 1633098588,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 936,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633098588,
                        ["quant"] = 1,
                        ["id"] = "1690945879",
                        ["itemLink"] = 1273,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [27063] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/monster_plant_creature_seeds_001.dds",
                ["itemDesc"] = "Saltrice",
                ["oldestTime"] = 1633042320,
                ["wasAltered"] = true,
                ["newestTime"] = 1633042320,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 648,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633042320,
                        ["quant"] = 200,
                        ["id"] = "1690531187",
                        ["itemLink"] = 826,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [27064] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_bread_004.dds",
                ["itemDesc"] = "Millet",
                ["oldestTime"] = 1633305829,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305829,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633305829,
                        ["quant"] = 200,
                        ["id"] = "1692798703",
                        ["itemLink"] = 2936,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [156821] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Style Page: Opal Bloodspawn Battle Axe",
                ["oldestTime"] = 1633292475,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292475,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 1145,
                        ["timestamp"] = 1633292475,
                        ["quant"] = 1,
                        ["id"] = "1692657081",
                        ["itemLink"] = 2836,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [43706] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Cyrodiil Treasure Map IV",
                ["oldestTime"] = 1633148098,
                ["wasAltered"] = true,
                ["newestTime"] = 1633148098,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 682,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633148098,
                        ["quant"] = 1,
                        ["id"] = "1691374589",
                        ["itemLink"] = 1694,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [127099] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Telvanni Arched Light, Organic Azure",
                ["oldestTime"] = 1633292286,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292286,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 190000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633292286,
                        ["quant"] = 1,
                        ["id"] = "1692654903",
                        ["itemLink"] = 2817,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [119819] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_alchemy.dds",
                ["itemDesc"] = "Sealed Alchemy Writ",
                ["oldestTime"] = 1632881446,
                ["wasAltered"] = true,
                ["newestTime"] = 1633307861,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 2,
                        ["buyer"] = 139,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1633205962,
                        ["quant"] = 1,
                        ["id"] = "1691854351",
                        ["itemLink"] = 155,
                    },
                    [2] = 
                    {
                        ["price"] = 5555,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 26,
                        ["timestamp"] = 1633057831,
                        ["quant"] = 1,
                        ["id"] = "1690688745",
                        ["itemLink"] = 974,
                    },
                    [3] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 974,
                        ["wasKiosk"] = true,
                        ["seller"] = 975,
                        ["timestamp"] = 1633108771,
                        ["quant"] = 1,
                        ["id"] = "1691027545",
                        ["itemLink"] = 155,
                    },
                    [4] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 903,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633208281,
                        ["quant"] = 1,
                        ["id"] = "1691886181",
                        ["itemLink"] = 974,
                    },
                    [5] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 1836,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633259919,
                        ["quant"] = 1,
                        ["id"] = "1692324675",
                        ["itemLink"] = 155,
                    },
                    [6] = 
                    {
                        ["price"] = 12200,
                        ["guild"] = 1,
                        ["buyer"] = 2075,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1633307861,
                        ["quant"] = 1,
                        ["id"] = "1692821619",
                        ["itemLink"] = 974,
                    },
                    [7] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1065,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632881446,
                        ["quant"] = 1,
                        ["id"] = "1689410831",
                        ["itemLink"] = 974,
                    },
                },
                ["totalCount"] = 7,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [176573] = 
        {
            ["1:0:2:47:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_shield.dds",
                ["itemDesc"] = "Companion's Shield",
                ["oldestTime"] = 1633271515,
                ["wasAltered"] = true,
                ["newestTime"] = 1633271515,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1882,
                        ["wasKiosk"] = true,
                        ["seller"] = 663,
                        ["timestamp"] = 1633271515,
                        ["quant"] = 1,
                        ["id"] = "1692421037",
                        ["itemLink"] = 2675,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine apparel weapon shield off hand aggressive",
            },
        },
        [100286] = 
        {
            ["50:16:2:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_medium_chest_d.dds",
                ["itemDesc"] = "Fiord's Jack",
                ["oldestTime"] = 1633291938,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291938,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 348,
                        ["timestamp"] = 1633291938,
                        ["quant"] = 1,
                        ["id"] = "1692651177",
                        ["itemLink"] = 2796,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set fiord's legacy chest reinforced",
            },
        },
        [153535] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_gems_cyclops_bone.dds",
                ["itemDesc"] = "Skeletal Marionette Parts",
                ["oldestTime"] = 1633165395,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165395,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 199980,
                        ["guild"] = 1,
                        ["buyer"] = 1320,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1633165395,
                        ["quant"] = 10,
                        ["id"] = "1691498001",
                        ["itemLink"] = 1837,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable trophy",
            },
        },
        [139456] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_book_002.dds",
                ["itemDesc"] = "Big-Eared Ginger Kitten's \"Care and Feeding\" Guide",
                ["oldestTime"] = 1633103050,
                ["wasAltered"] = true,
                ["newestTime"] = 1633103050,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 739,
                        ["wasKiosk"] = false,
                        ["seller"] = 957,
                        ["timestamp"] = 1633103050,
                        ["quant"] = 1,
                        ["id"] = "1690984579",
                        ["itemLink"] = 1290,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [68212] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Colovian Ginger Beer",
                ["oldestTime"] = 1633261632,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261632,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633261632,
                        ["quant"] = 1,
                        ["id"] = "1692334553",
                        ["itemLink"] = 2627,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [165826] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_inc_woodframepainting001.dds",
                ["itemDesc"] = "Fields of Plenty Painting, Wood",
                ["oldestTime"] = 1633058107,
                ["wasAltered"] = true,
                ["newestTime"] = 1633058107,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 709,
                        ["timestamp"] = 1633058107,
                        ["quant"] = 1,
                        ["id"] = "1690691331",
                        ["itemLink"] = 984,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings gallery",
            },
        },
        [116163] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing2.dds",
                ["itemDesc"] = "Diagram: Nord Candle, Tealight",
                ["oldestTime"] = 1632905683,
                ["wasAltered"] = true,
                ["newestTime"] = 1632905683,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 2452,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632905683,
                        ["quant"] = 1,
                        ["id"] = "1689584631",
                        ["itemLink"] = 3587,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [30148] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_mushroom_blue_entoloma_cap_r1.dds",
                ["itemDesc"] = "Blue Entoloma",
                ["oldestTime"] = 1632981216,
                ["wasAltered"] = true,
                ["newestTime"] = 1633042853,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 265,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1632981216,
                        ["quant"] = 200,
                        ["id"] = "1690137733",
                        ["itemLink"] = 270,
                    },
                    [2] = 
                    {
                        ["price"] = 19990,
                        ["guild"] = 1,
                        ["buyer"] = 652,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1633042853,
                        ["quant"] = 200,
                        ["id"] = "1690536699",
                        ["itemLink"] = 270,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [167365] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_3.dds",
                ["itemDesc"] = "Pattern: Solitude Stall, Covered Merchant",
                ["oldestTime"] = 1632961831,
                ["wasAltered"] = true,
                ["newestTime"] = 1632961831,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2636,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632961831,
                        ["quant"] = 1,
                        ["id"] = "1689974015",
                        ["itemLink"] = 3929,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45254] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_medium_head_d.dds",
                ["itemDesc"] = "Rubedo Leather Helmet of Magicka",
                ["oldestTime"] = 1633023049,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023049,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633023049,
                        ["quant"] = 1,
                        ["id"] = "1690391037",
                        ["itemLink"] = 671,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel head invigorating",
            },
        },
        [122823] = 
        {
            ["50:16:3:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_telvanni_staff_a.dds",
                ["itemDesc"] = "War Maiden's Inferno Staff",
                ["oldestTime"] = 1633208861,
                ["wasAltered"] = true,
                ["newestTime"] = 1633208861,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 90000,
                        ["guild"] = 1,
                        ["buyer"] = 158,
                        ["wasKiosk"] = false,
                        ["seller"] = 493,
                        ["timestamp"] = 1633208861,
                        ["quant"] = 1,
                        ["id"] = "1691892999",
                        ["itemLink"] = 2268,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set war maiden flame staff two-handed powered",
            },
        },
        [126842] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing4.dds",
                ["itemDesc"] = "Diagram: Daedric Chandelier, Ritual",
                ["oldestTime"] = 1633242876,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242876,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1331,
                        ["wasKiosk"] = true,
                        ["seller"] = 159,
                        ["timestamp"] = 1633242876,
                        ["quant"] = 1,
                        ["id"] = "1692217647",
                        ["itemLink"] = 2556,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [33993] = 
        {
            ["10:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_tea_005.dds",
                ["itemDesc"] = "Sweetsting Tea",
                ["oldestTime"] = 1633316240,
                ["wasAltered"] = true,
                ["newestTime"] = 1633316240,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 66,
                        ["guild"] = 2,
                        ["buyer"] = 1006,
                        ["wasKiosk"] = false,
                        ["seller"] = 1007,
                        ["timestamp"] = 1633316240,
                        ["quant"] = 11,
                        ["id"] = "1692917523",
                        ["itemLink"] = 1370,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr10 green fine consumable drink",
            },
        },
        [45678] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Grape-Glazed Bantam Guar",
                ["oldestTime"] = 1633242684,
                ["wasAltered"] = true,
                ["newestTime"] = 1633267829,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 88,
                        ["guild"] = 1,
                        ["buyer"] = 348,
                        ["wasKiosk"] = false,
                        ["seller"] = 149,
                        ["timestamp"] = 1633242684,
                        ["quant"] = 1,
                        ["id"] = "1692215189",
                        ["itemLink"] = 2544,
                    },
                    [2] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1864,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633267829,
                        ["quant"] = 1,
                        ["id"] = "1692383037",
                        ["itemLink"] = 2544,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [176587] = 
        {
            ["1:0:3:47:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_chest_medium.dds",
                ["itemDesc"] = "Companion's Jack",
                ["oldestTime"] = 1633137527,
                ["wasAltered"] = true,
                ["newestTime"] = 1633315230,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 59999,
                        ["guild"] = 1,
                        ["buyer"] = 91,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633315230,
                        ["quant"] = 1,
                        ["id"] = "1692906329",
                        ["itemLink"] = 68,
                    },
                    [2] = 
                    {
                        ["price"] = 59999,
                        ["guild"] = 1,
                        ["buyer"] = 434,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633137527,
                        ["quant"] = 1,
                        ["id"] = "1691266653",
                        ["itemLink"] = 68,
                    },
                    [3] = 
                    {
                        ["price"] = 59999,
                        ["guild"] = 1,
                        ["buyer"] = 1784,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633242328,
                        ["quant"] = 1,
                        ["id"] = "1692213137",
                        ["itemLink"] = 68,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior medium apparel chest aggressive",
            },
        },
        [30156] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_mushroom_imp_stool_r2.dds",
                ["itemDesc"] = "Imp Stool",
                ["oldestTime"] = 1633100249,
                ["wasAltered"] = true,
                ["newestTime"] = 1633251980,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24400,
                        ["guild"] = 1,
                        ["buyer"] = 941,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1633100249,
                        ["quant"] = 200,
                        ["id"] = "1690959177",
                        ["itemLink"] = 1280,
                    },
                    [2] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 599,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633220054,
                        ["quant"] = 200,
                        ["id"] = "1692013033",
                        ["itemLink"] = 1280,
                    },
                    [3] = 
                    {
                        ["price"] = 990,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633251980,
                        ["quant"] = 11,
                        ["id"] = "1692285165",
                        ["itemLink"] = 1280,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [43725] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Craglorn Treasure Map V",
                ["oldestTime"] = 1633149351,
                ["wasAltered"] = true,
                ["newestTime"] = 1633149351,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1250,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633149351,
                        ["quant"] = 1,
                        ["id"] = "1691385351",
                        ["itemLink"] = 1708,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [139417] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_flower_wormwood_r3.dds",
                ["itemDesc"] = "Pulverized Aurbic Amber",
                ["oldestTime"] = 1632872307,
                ["wasAltered"] = true,
                ["newestTime"] = 1633097101,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4653,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 486,
                        ["timestamp"] = 1633097101,
                        ["quant"] = 3,
                        ["id"] = "1690936841",
                        ["itemLink"] = 1269,
                    },
                    [2] = 
                    {
                        ["price"] = 3505,
                        ["guild"] = 1,
                        ["buyer"] = 1729,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632872307,
                        ["quant"] = 5,
                        ["id"] = "1689317573",
                        ["itemLink"] = 1269,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials raw trait",
            },
        },
        [126958] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_4.dds",
                ["itemDesc"] = "Blueprint: Hlaalu Nightstand, Formal",
                ["oldestTime"] = 1633227739,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227739,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 70000,
                        ["guild"] = 1,
                        ["buyer"] = 521,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633227739,
                        ["quant"] = 1,
                        ["id"] = "1692093309",
                        ["itemLink"] = 2411,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [96951] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/container_sealed_polymorph_001.dds",
                ["itemDesc"] = "Runebox: Nordic Bather's Towel",
                ["oldestTime"] = 1632848593,
                ["wasAltered"] = true,
                ["newestTime"] = 1633207737,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20999,
                        ["guild"] = 1,
                        ["buyer"] = 1383,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633183829,
                        ["quant"] = 1,
                        ["id"] = "1691619949",
                        ["itemLink"] = 1966,
                    },
                    [2] = 
                    {
                        ["price"] = 29995,
                        ["guild"] = 1,
                        ["buyer"] = 511,
                        ["wasKiosk"] = true,
                        ["seller"] = 975,
                        ["timestamp"] = 1633207737,
                        ["quant"] = 1,
                        ["id"] = "1691878601",
                        ["itemLink"] = 1966,
                    },
                    [3] = 
                    {
                        ["price"] = 29995,
                        ["guild"] = 1,
                        ["buyer"] = 2207,
                        ["wasKiosk"] = true,
                        ["seller"] = 975,
                        ["timestamp"] = 1632848593,
                        ["quant"] = 1,
                        ["id"] = "1689132433",
                        ["itemLink"] = 1966,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 gold legendary consumable container",
            },
        },
        [172007] = 
        {
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_hands_a.dds",
                ["itemDesc"] = "Gloves of Frostbite",
                ["oldestTime"] = 1633215989,
                ["wasAltered"] = true,
                ["newestTime"] = 1633215989,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 995,
                        ["guild"] = 1,
                        ["buyer"] = 327,
                        ["wasKiosk"] = false,
                        ["seller"] = 142,
                        ["timestamp"] = 1633215989,
                        ["quant"] = 1,
                        ["id"] = "1691968325",
                        ["itemLink"] = 2314,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set frostbite hands well-fitted",
            },
        },
        [171986] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_leyawiinmil_lgt_hands_a.dds",
                ["itemDesc"] = "Gloves of Frostbite",
                ["oldestTime"] = 1633138179,
                ["wasAltered"] = true,
                ["newestTime"] = 1633138179,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1690,
                        ["guild"] = 1,
                        ["buyer"] = 1166,
                        ["wasKiosk"] = true,
                        ["seller"] = 1112,
                        ["timestamp"] = 1633138179,
                        ["quant"] = 1,
                        ["id"] = "1691274015",
                        ["itemLink"] = 1583,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set frostbite hands divines",
            },
        },
        [135137] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_pewter_dust.dds",
                ["itemDesc"] = "Pewter Dust",
                ["oldestTime"] = 1632952935,
                ["wasAltered"] = true,
                ["newestTime"] = 1633247648,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1574,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633214350,
                        ["quant"] = 200,
                        ["id"] = "1691953115",
                        ["itemLink"] = 2297,
                    },
                    [2] = 
                    {
                        ["price"] = 4800,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633239792,
                        ["quant"] = 32,
                        ["id"] = "1692195761",
                        ["itemLink"] = 2297,
                    },
                    [3] = 
                    {
                        ["price"] = 6100,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633239793,
                        ["quant"] = 41,
                        ["id"] = "1692195767",
                        ["itemLink"] = 2297,
                    },
                    [4] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1805,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633247648,
                        ["quant"] = 80,
                        ["id"] = "1692255571",
                        ["itemLink"] = 2297,
                    },
                    [5] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1574,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632952935,
                        ["quant"] = 200,
                        ["id"] = "1689900687",
                        ["itemLink"] = 2297,
                    },
                    [6] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 1574,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632952936,
                        ["quant"] = 200,
                        ["id"] = "1689900697",
                        ["itemLink"] = 2297,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [45044] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_medium_head_d.dds",
                ["itemDesc"] = "Rubedo Leather Helmet of Stamina",
                ["oldestTime"] = 1633023048,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023048,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633023048,
                        ["quant"] = 1,
                        ["id"] = "1690391035",
                        ["itemLink"] = 670,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel head sturdy",
            },
        },
        [43672] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Shadowfen Treasure Map VI",
                ["oldestTime"] = 1633202882,
                ["wasAltered"] = true,
                ["newestTime"] = 1633202882,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1504,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633202882,
                        ["quant"] = 1,
                        ["id"] = "1691820997",
                        ["itemLink"] = 2222,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [26582] = 
        {
            ["50:15:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_armor_magickaboost.dds",
                ["itemDesc"] = "Superb Glyph of Magicka",
                ["oldestTime"] = 1632826532,
                ["wasAltered"] = true,
                ["newestTime"] = 1633259334,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1244,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633148054,
                        ["quant"] = 1,
                        ["id"] = "1691374211",
                        ["itemLink"] = 1690,
                    },
                    [2] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1244,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633148055,
                        ["quant"] = 1,
                        ["id"] = "1691374217",
                        ["itemLink"] = 1690,
                    },
                    [3] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1244,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633148055,
                        ["quant"] = 1,
                        ["id"] = "1691374219",
                        ["itemLink"] = 1690,
                    },
                    [4] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1244,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633148056,
                        ["quant"] = 1,
                        ["id"] = "1691374229",
                        ["itemLink"] = 1690,
                    },
                    [5] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1244,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633148056,
                        ["quant"] = 1,
                        ["id"] = "1691374233",
                        ["itemLink"] = 1690,
                    },
                    [6] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1244,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633148057,
                        ["quant"] = 1,
                        ["id"] = "1691374237",
                        ["itemLink"] = 1690,
                    },
                    [7] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186109,
                        ["quant"] = 1,
                        ["id"] = "1691641911",
                        ["itemLink"] = 1690,
                    },
                    [8] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186110,
                        ["quant"] = 1,
                        ["id"] = "1691641919",
                        ["itemLink"] = 1690,
                    },
                    [9] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186111,
                        ["quant"] = 1,
                        ["id"] = "1691641925",
                        ["itemLink"] = 1690,
                    },
                    [10] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186112,
                        ["quant"] = 1,
                        ["id"] = "1691641935",
                        ["itemLink"] = 1690,
                    },
                    [11] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186113,
                        ["quant"] = 1,
                        ["id"] = "1691641943",
                        ["itemLink"] = 1690,
                    },
                    [12] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186113,
                        ["quant"] = 1,
                        ["id"] = "1691641945",
                        ["itemLink"] = 1690,
                    },
                    [13] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186114,
                        ["quant"] = 1,
                        ["id"] = "1691641947",
                        ["itemLink"] = 1690,
                    },
                    [14] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186114,
                        ["quant"] = 1,
                        ["id"] = "1691641951",
                        ["itemLink"] = 1690,
                    },
                    [15] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186115,
                        ["quant"] = 1,
                        ["id"] = "1691641955",
                        ["itemLink"] = 1690,
                    },
                    [16] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186116,
                        ["quant"] = 1,
                        ["id"] = "1691641963",
                        ["itemLink"] = 1690,
                    },
                    [17] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186116,
                        ["quant"] = 1,
                        ["id"] = "1691641967",
                        ["itemLink"] = 1690,
                    },
                    [18] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186117,
                        ["quant"] = 1,
                        ["id"] = "1691641971",
                        ["itemLink"] = 1690,
                    },
                    [19] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186117,
                        ["quant"] = 1,
                        ["id"] = "1691641975",
                        ["itemLink"] = 1690,
                    },
                    [20] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186118,
                        ["quant"] = 1,
                        ["id"] = "1691641979",
                        ["itemLink"] = 1690,
                    },
                    [21] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186119,
                        ["quant"] = 1,
                        ["id"] = "1691641987",
                        ["itemLink"] = 1690,
                    },
                    [22] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186120,
                        ["quant"] = 1,
                        ["id"] = "1691641995",
                        ["itemLink"] = 1690,
                    },
                    [23] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186120,
                        ["quant"] = 1,
                        ["id"] = "1691642003",
                        ["itemLink"] = 1690,
                    },
                    [24] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186121,
                        ["quant"] = 1,
                        ["id"] = "1691642011",
                        ["itemLink"] = 1690,
                    },
                    [25] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186122,
                        ["quant"] = 1,
                        ["id"] = "1691642013",
                        ["itemLink"] = 1690,
                    },
                    [26] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186122,
                        ["quant"] = 1,
                        ["id"] = "1691642023",
                        ["itemLink"] = 1690,
                    },
                    [27] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186123,
                        ["quant"] = 1,
                        ["id"] = "1691642029",
                        ["itemLink"] = 1690,
                    },
                    [28] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186124,
                        ["quant"] = 1,
                        ["id"] = "1691642037",
                        ["itemLink"] = 1690,
                    },
                    [29] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186124,
                        ["quant"] = 1,
                        ["id"] = "1691642041",
                        ["itemLink"] = 1690,
                    },
                    [30] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633186125,
                        ["quant"] = 1,
                        ["id"] = "1691642047",
                        ["itemLink"] = 1690,
                    },
                    [31] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186126,
                        ["quant"] = 1,
                        ["id"] = "1691642063",
                        ["itemLink"] = 1690,
                    },
                    [32] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186127,
                        ["quant"] = 1,
                        ["id"] = "1691642073",
                        ["itemLink"] = 1690,
                    },
                    [33] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186128,
                        ["quant"] = 1,
                        ["id"] = "1691642081",
                        ["itemLink"] = 1690,
                    },
                    [34] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186129,
                        ["quant"] = 1,
                        ["id"] = "1691642089",
                        ["itemLink"] = 1690,
                    },
                    [35] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186129,
                        ["quant"] = 1,
                        ["id"] = "1691642095",
                        ["itemLink"] = 1690,
                    },
                    [36] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186132,
                        ["quant"] = 1,
                        ["id"] = "1691642115",
                        ["itemLink"] = 1690,
                    },
                    [37] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186133,
                        ["quant"] = 1,
                        ["id"] = "1691642125",
                        ["itemLink"] = 1690,
                    },
                    [38] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186134,
                        ["quant"] = 1,
                        ["id"] = "1691642139",
                        ["itemLink"] = 1690,
                    },
                    [39] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186134,
                        ["quant"] = 1,
                        ["id"] = "1691642145",
                        ["itemLink"] = 1690,
                    },
                    [40] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186135,
                        ["quant"] = 1,
                        ["id"] = "1691642151",
                        ["itemLink"] = 1690,
                    },
                    [41] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186136,
                        ["quant"] = 1,
                        ["id"] = "1691642165",
                        ["itemLink"] = 1690,
                    },
                    [42] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186136,
                        ["quant"] = 1,
                        ["id"] = "1691642169",
                        ["itemLink"] = 1690,
                    },
                    [43] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186137,
                        ["quant"] = 1,
                        ["id"] = "1691642177",
                        ["itemLink"] = 1690,
                    },
                    [44] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186138,
                        ["quant"] = 1,
                        ["id"] = "1691642179",
                        ["itemLink"] = 1690,
                    },
                    [45] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186138,
                        ["quant"] = 1,
                        ["id"] = "1691642187",
                        ["itemLink"] = 1690,
                    },
                    [46] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186139,
                        ["quant"] = 1,
                        ["id"] = "1691642197",
                        ["itemLink"] = 1690,
                    },
                    [47] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186140,
                        ["quant"] = 1,
                        ["id"] = "1691642207",
                        ["itemLink"] = 1690,
                    },
                    [48] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186141,
                        ["quant"] = 1,
                        ["id"] = "1691642217",
                        ["itemLink"] = 1690,
                    },
                    [49] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633186142,
                        ["quant"] = 1,
                        ["id"] = "1691642223",
                        ["itemLink"] = 1690,
                    },
                    [50] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259310,
                        ["quant"] = 1,
                        ["id"] = "1692322109",
                        ["itemLink"] = 1690,
                    },
                    [51] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259311,
                        ["quant"] = 1,
                        ["id"] = "1692322115",
                        ["itemLink"] = 1690,
                    },
                    [52] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259312,
                        ["quant"] = 1,
                        ["id"] = "1692322117",
                        ["itemLink"] = 1690,
                    },
                    [53] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259314,
                        ["quant"] = 1,
                        ["id"] = "1692322121",
                        ["itemLink"] = 1690,
                    },
                    [54] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259315,
                        ["quant"] = 1,
                        ["id"] = "1692322125",
                        ["itemLink"] = 1690,
                    },
                    [55] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259316,
                        ["quant"] = 1,
                        ["id"] = "1692322131",
                        ["itemLink"] = 1690,
                    },
                    [56] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259317,
                        ["quant"] = 1,
                        ["id"] = "1692322135",
                        ["itemLink"] = 1690,
                    },
                    [57] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259318,
                        ["quant"] = 1,
                        ["id"] = "1692322137",
                        ["itemLink"] = 1690,
                    },
                    [58] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259318,
                        ["quant"] = 1,
                        ["id"] = "1692322139",
                        ["itemLink"] = 1690,
                    },
                    [59] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259319,
                        ["quant"] = 1,
                        ["id"] = "1692322141",
                        ["itemLink"] = 1690,
                    },
                    [60] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259320,
                        ["quant"] = 1,
                        ["id"] = "1692322145",
                        ["itemLink"] = 1690,
                    },
                    [61] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259321,
                        ["quant"] = 1,
                        ["id"] = "1692322147",
                        ["itemLink"] = 1690,
                    },
                    [62] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259322,
                        ["quant"] = 1,
                        ["id"] = "1692322151",
                        ["itemLink"] = 1690,
                    },
                    [63] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259322,
                        ["quant"] = 1,
                        ["id"] = "1692322153",
                        ["itemLink"] = 1690,
                    },
                    [64] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259323,
                        ["quant"] = 1,
                        ["id"] = "1692322159",
                        ["itemLink"] = 1690,
                    },
                    [65] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259324,
                        ["quant"] = 1,
                        ["id"] = "1692322167",
                        ["itemLink"] = 1690,
                    },
                    [66] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259325,
                        ["quant"] = 1,
                        ["id"] = "1692322175",
                        ["itemLink"] = 1690,
                    },
                    [67] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259326,
                        ["quant"] = 1,
                        ["id"] = "1692322187",
                        ["itemLink"] = 1690,
                    },
                    [68] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259327,
                        ["quant"] = 1,
                        ["id"] = "1692322195",
                        ["itemLink"] = 1690,
                    },
                    [69] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259328,
                        ["quant"] = 1,
                        ["id"] = "1692322207",
                        ["itemLink"] = 1690,
                    },
                    [70] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259329,
                        ["quant"] = 1,
                        ["id"] = "1692322211",
                        ["itemLink"] = 1690,
                    },
                    [71] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259330,
                        ["quant"] = 1,
                        ["id"] = "1692322219",
                        ["itemLink"] = 1690,
                    },
                    [72] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259330,
                        ["quant"] = 1,
                        ["id"] = "1692322223",
                        ["itemLink"] = 1690,
                    },
                    [73] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259331,
                        ["quant"] = 1,
                        ["id"] = "1692322227",
                        ["itemLink"] = 1690,
                    },
                    [74] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259332,
                        ["quant"] = 1,
                        ["id"] = "1692322235",
                        ["itemLink"] = 1690,
                    },
                    [75] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259333,
                        ["quant"] = 1,
                        ["id"] = "1692322245",
                        ["itemLink"] = 1690,
                    },
                    [76] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259333,
                        ["quant"] = 1,
                        ["id"] = "1692322249",
                        ["itemLink"] = 1690,
                    },
                    [77] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 1835,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633259334,
                        ["quant"] = 1,
                        ["id"] = "1692322253",
                        ["itemLink"] = 1690,
                    },
                    [78] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632826532,
                        ["quant"] = 1,
                        ["id"] = "1688972381",
                        ["itemLink"] = 1690,
                    },
                    [79] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632826532,
                        ["quant"] = 1,
                        ["id"] = "1688972385",
                        ["itemLink"] = 1690,
                    },
                    [80] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632826533,
                        ["quant"] = 1,
                        ["id"] = "1688972393",
                        ["itemLink"] = 1690,
                    },
                    [81] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881756,
                        ["quant"] = 1,
                        ["id"] = "1689414845",
                        ["itemLink"] = 1690,
                    },
                    [82] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881757,
                        ["quant"] = 1,
                        ["id"] = "1689414863",
                        ["itemLink"] = 1690,
                    },
                    [83] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881759,
                        ["quant"] = 1,
                        ["id"] = "1689414881",
                        ["itemLink"] = 1690,
                    },
                    [84] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881760,
                        ["quant"] = 1,
                        ["id"] = "1689414903",
                        ["itemLink"] = 1690,
                    },
                    [85] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881761,
                        ["quant"] = 1,
                        ["id"] = "1689414917",
                        ["itemLink"] = 1690,
                    },
                    [86] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881762,
                        ["quant"] = 1,
                        ["id"] = "1689414941",
                        ["itemLink"] = 1690,
                    },
                    [87] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881763,
                        ["quant"] = 1,
                        ["id"] = "1689414957",
                        ["itemLink"] = 1690,
                    },
                    [88] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881764,
                        ["quant"] = 1,
                        ["id"] = "1689414979",
                        ["itemLink"] = 1690,
                    },
                    [89] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881764,
                        ["quant"] = 1,
                        ["id"] = "1689414995",
                        ["itemLink"] = 1690,
                    },
                    [90] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881765,
                        ["quant"] = 1,
                        ["id"] = "1689415019",
                        ["itemLink"] = 1690,
                    },
                    [91] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881766,
                        ["quant"] = 1,
                        ["id"] = "1689415037",
                        ["itemLink"] = 1690,
                    },
                    [92] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881767,
                        ["quant"] = 1,
                        ["id"] = "1689415053",
                        ["itemLink"] = 1690,
                    },
                    [93] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881767,
                        ["quant"] = 1,
                        ["id"] = "1689415065",
                        ["itemLink"] = 1690,
                    },
                    [94] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881768,
                        ["quant"] = 1,
                        ["id"] = "1689415081",
                        ["itemLink"] = 1690,
                    },
                    [95] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881769,
                        ["quant"] = 1,
                        ["id"] = "1689415101",
                        ["itemLink"] = 1690,
                    },
                    [96] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881770,
                        ["quant"] = 1,
                        ["id"] = "1689415115",
                        ["itemLink"] = 1690,
                    },
                    [97] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881770,
                        ["quant"] = 1,
                        ["id"] = "1689415127",
                        ["itemLink"] = 1690,
                    },
                    [98] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881771,
                        ["quant"] = 1,
                        ["id"] = "1689415137",
                        ["itemLink"] = 1690,
                    },
                    [99] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881772,
                        ["quant"] = 1,
                        ["id"] = "1689415147",
                        ["itemLink"] = 1690,
                    },
                    [100] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881772,
                        ["quant"] = 1,
                        ["id"] = "1689415157",
                        ["itemLink"] = 1690,
                    },
                    [101] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881773,
                        ["quant"] = 1,
                        ["id"] = "1689415165",
                        ["itemLink"] = 1690,
                    },
                    [102] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881774,
                        ["quant"] = 1,
                        ["id"] = "1689415171",
                        ["itemLink"] = 1690,
                    },
                    [103] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881774,
                        ["quant"] = 1,
                        ["id"] = "1689415177",
                        ["itemLink"] = 1690,
                    },
                    [104] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881775,
                        ["quant"] = 1,
                        ["id"] = "1689415185",
                        ["itemLink"] = 1690,
                    },
                    [105] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881776,
                        ["quant"] = 1,
                        ["id"] = "1689415193",
                        ["itemLink"] = 1690,
                    },
                    [106] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881777,
                        ["quant"] = 1,
                        ["id"] = "1689415203",
                        ["itemLink"] = 1690,
                    },
                    [107] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881779,
                        ["quant"] = 1,
                        ["id"] = "1689415219",
                        ["itemLink"] = 1690,
                    },
                    [108] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632881780,
                        ["quant"] = 1,
                        ["id"] = "1689415237",
                        ["itemLink"] = 1690,
                    },
                    [109] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885362,
                        ["quant"] = 1,
                        ["id"] = "1689456661",
                        ["itemLink"] = 1690,
                    },
                    [110] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885363,
                        ["quant"] = 1,
                        ["id"] = "1689456671",
                        ["itemLink"] = 1690,
                    },
                    [111] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885364,
                        ["quant"] = 1,
                        ["id"] = "1689456675",
                        ["itemLink"] = 1690,
                    },
                    [112] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885365,
                        ["quant"] = 1,
                        ["id"] = "1689456681",
                        ["itemLink"] = 1690,
                    },
                    [113] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885366,
                        ["quant"] = 1,
                        ["id"] = "1689456687",
                        ["itemLink"] = 1690,
                    },
                    [114] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885367,
                        ["quant"] = 1,
                        ["id"] = "1689456699",
                        ["itemLink"] = 1690,
                    },
                    [115] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885368,
                        ["quant"] = 1,
                        ["id"] = "1689456709",
                        ["itemLink"] = 1690,
                    },
                    [116] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885369,
                        ["quant"] = 1,
                        ["id"] = "1689456715",
                        ["itemLink"] = 1690,
                    },
                    [117] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885370,
                        ["quant"] = 1,
                        ["id"] = "1689456737",
                        ["itemLink"] = 1690,
                    },
                    [118] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885372,
                        ["quant"] = 1,
                        ["id"] = "1689456753",
                        ["itemLink"] = 1690,
                    },
                    [119] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885373,
                        ["quant"] = 1,
                        ["id"] = "1689456769",
                        ["itemLink"] = 1690,
                    },
                    [120] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885374,
                        ["quant"] = 1,
                        ["id"] = "1689456777",
                        ["itemLink"] = 1690,
                    },
                    [121] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885375,
                        ["quant"] = 1,
                        ["id"] = "1689456795",
                        ["itemLink"] = 1690,
                    },
                    [122] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885376,
                        ["quant"] = 1,
                        ["id"] = "1689456811",
                        ["itemLink"] = 1690,
                    },
                    [123] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885377,
                        ["quant"] = 1,
                        ["id"] = "1689456827",
                        ["itemLink"] = 1690,
                    },
                    [124] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885378,
                        ["quant"] = 1,
                        ["id"] = "1689456839",
                        ["itemLink"] = 1690,
                    },
                    [125] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885380,
                        ["quant"] = 1,
                        ["id"] = "1689456851",
                        ["itemLink"] = 1690,
                    },
                    [126] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885381,
                        ["quant"] = 1,
                        ["id"] = "1689456859",
                        ["itemLink"] = 1690,
                    },
                    [127] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885382,
                        ["quant"] = 1,
                        ["id"] = "1689456865",
                        ["itemLink"] = 1690,
                    },
                    [128] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885383,
                        ["quant"] = 1,
                        ["id"] = "1689456877",
                        ["itemLink"] = 1690,
                    },
                    [129] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885384,
                        ["quant"] = 1,
                        ["id"] = "1689456889",
                        ["itemLink"] = 1690,
                    },
                    [130] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885385,
                        ["quant"] = 1,
                        ["id"] = "1689456905",
                        ["itemLink"] = 1690,
                    },
                    [131] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885386,
                        ["quant"] = 1,
                        ["id"] = "1689456913",
                        ["itemLink"] = 1690,
                    },
                    [132] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885387,
                        ["quant"] = 1,
                        ["id"] = "1689456923",
                        ["itemLink"] = 1690,
                    },
                    [133] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885389,
                        ["quant"] = 1,
                        ["id"] = "1689456935",
                        ["itemLink"] = 1690,
                    },
                    [134] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885390,
                        ["quant"] = 1,
                        ["id"] = "1689456937",
                        ["itemLink"] = 1690,
                    },
                    [135] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885391,
                        ["quant"] = 1,
                        ["id"] = "1689456949",
                        ["itemLink"] = 1690,
                    },
                    [136] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632885392,
                        ["quant"] = 1,
                        ["id"] = "1689456957",
                        ["itemLink"] = 1690,
                    },
                    [137] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892249,
                        ["quant"] = 1,
                        ["id"] = "1689510567",
                        ["itemLink"] = 1690,
                    },
                    [138] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892250,
                        ["quant"] = 1,
                        ["id"] = "1689510573",
                        ["itemLink"] = 1690,
                    },
                    [139] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892250,
                        ["quant"] = 1,
                        ["id"] = "1689510577",
                        ["itemLink"] = 1690,
                    },
                    [140] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892251,
                        ["quant"] = 1,
                        ["id"] = "1689510581",
                        ["itemLink"] = 1690,
                    },
                    [141] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892251,
                        ["quant"] = 1,
                        ["id"] = "1689510591",
                        ["itemLink"] = 1690,
                    },
                    [142] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892252,
                        ["quant"] = 1,
                        ["id"] = "1689510597",
                        ["itemLink"] = 1690,
                    },
                    [143] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892252,
                        ["quant"] = 1,
                        ["id"] = "1689510603",
                        ["itemLink"] = 1690,
                    },
                    [144] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892253,
                        ["quant"] = 1,
                        ["id"] = "1689510605",
                        ["itemLink"] = 1690,
                    },
                    [145] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892253,
                        ["quant"] = 1,
                        ["id"] = "1689510609",
                        ["itemLink"] = 1690,
                    },
                    [146] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892254,
                        ["quant"] = 1,
                        ["id"] = "1689510611",
                        ["itemLink"] = 1690,
                    },
                    [147] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892254,
                        ["quant"] = 1,
                        ["id"] = "1689510613",
                        ["itemLink"] = 1690,
                    },
                    [148] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892255,
                        ["quant"] = 1,
                        ["id"] = "1689510615",
                        ["itemLink"] = 1690,
                    },
                    [149] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892255,
                        ["quant"] = 1,
                        ["id"] = "1689510619",
                        ["itemLink"] = 1690,
                    },
                    [150] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892256,
                        ["quant"] = 1,
                        ["id"] = "1689510623",
                        ["itemLink"] = 1690,
                    },
                    [151] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892258,
                        ["quant"] = 1,
                        ["id"] = "1689510637",
                        ["itemLink"] = 1690,
                    },
                    [152] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892259,
                        ["quant"] = 1,
                        ["id"] = "1689510659",
                        ["itemLink"] = 1690,
                    },
                    [153] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892259,
                        ["quant"] = 1,
                        ["id"] = "1689510663",
                        ["itemLink"] = 1690,
                    },
                    [154] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892260,
                        ["quant"] = 1,
                        ["id"] = "1689510669",
                        ["itemLink"] = 1690,
                    },
                    [155] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892261,
                        ["quant"] = 1,
                        ["id"] = "1689510679",
                        ["itemLink"] = 1690,
                    },
                    [156] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632892261,
                        ["quant"] = 1,
                        ["id"] = "1689510689",
                        ["itemLink"] = 1690,
                    },
                    [157] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632921143,
                        ["quant"] = 1,
                        ["id"] = "1689658317",
                        ["itemLink"] = 1690,
                    },
                    [158] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632921144,
                        ["quant"] = 1,
                        ["id"] = "1689658323",
                        ["itemLink"] = 1690,
                    },
                    [159] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632921144,
                        ["quant"] = 1,
                        ["id"] = "1689658329",
                        ["itemLink"] = 1690,
                    },
                    [160] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632921145,
                        ["quant"] = 1,
                        ["id"] = "1689658335",
                        ["itemLink"] = 1690,
                    },
                    [161] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632921145,
                        ["quant"] = 1,
                        ["id"] = "1689658339",
                        ["itemLink"] = 1690,
                    },
                    [162] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 2419,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632921146,
                        ["quant"] = 1,
                        ["id"] = "1689658349",
                        ["itemLink"] = 1690,
                    },
                    [163] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 932,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632921357,
                        ["quant"] = 1,
                        ["id"] = "1689660227",
                        ["itemLink"] = 1690,
                    },
                    [164] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 932,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632921358,
                        ["quant"] = 1,
                        ["id"] = "1689660233",
                        ["itemLink"] = 1690,
                    },
                    [165] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 932,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632921359,
                        ["quant"] = 1,
                        ["id"] = "1689660239",
                        ["itemLink"] = 1690,
                    },
                    [166] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 932,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632921360,
                        ["quant"] = 1,
                        ["id"] = "1689660243",
                        ["itemLink"] = 1690,
                    },
                    [167] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 932,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632921361,
                        ["quant"] = 1,
                        ["id"] = "1689660249",
                        ["itemLink"] = 1690,
                    },
                    [168] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 932,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632921362,
                        ["quant"] = 1,
                        ["id"] = "1689660251",
                        ["itemLink"] = 1690,
                    },
                    [169] = 
                    {
                        ["price"] = 650,
                        ["guild"] = 1,
                        ["buyer"] = 932,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632921363,
                        ["quant"] = 1,
                        ["id"] = "1689660259",
                        ["itemLink"] = 1690,
                    },
                    [170] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2666,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632967011,
                        ["quant"] = 1,
                        ["id"] = "1690024575",
                        ["itemLink"] = 1690,
                    },
                    [171] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2666,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632967013,
                        ["quant"] = 1,
                        ["id"] = "1690024585",
                        ["itemLink"] = 1690,
                    },
                    [172] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2666,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632967015,
                        ["quant"] = 1,
                        ["id"] = "1690024607",
                        ["itemLink"] = 1690,
                    },
                    [173] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2666,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632967016,
                        ["quant"] = 1,
                        ["id"] = "1690024619",
                        ["itemLink"] = 1690,
                    },
                    [174] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2666,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632967017,
                        ["quant"] = 1,
                        ["id"] = "1690024627",
                        ["itemLink"] = 1690,
                    },
                    [175] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2666,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632967018,
                        ["quant"] = 1,
                        ["id"] = "1690024637",
                        ["itemLink"] = 1690,
                    },
                    [176] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2666,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632967019,
                        ["quant"] = 1,
                        ["id"] = "1690024643",
                        ["itemLink"] = 1690,
                    },
                },
                ["totalCount"] = 176,
                ["itemAdderText"] = "cp150 purple epic miscellaneous armor glyph",
            },
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_armor_magickaboost.dds",
                ["itemDesc"] = "Truly Superb Glyph of Magicka",
                ["oldestTime"] = 1632826384,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297964,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633032463,
                        ["quant"] = 1,
                        ["id"] = "1690460887",
                        ["itemLink"] = 730,
                    },
                    [2] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1025,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633115975,
                        ["quant"] = 1,
                        ["id"] = "1691078627",
                        ["itemLink"] = 1406,
                    },
                    [3] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 1244,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633148040,
                        ["quant"] = 1,
                        ["id"] = "1691374111",
                        ["itemLink"] = 1685,
                    },
                    [4] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1639,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633224717,
                        ["quant"] = 1,
                        ["id"] = "1692061289",
                        ["itemLink"] = 2375,
                    },
                    [5] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1639,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633224723,
                        ["quant"] = 1,
                        ["id"] = "1692061321",
                        ["itemLink"] = 2377,
                    },
                    [6] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 1639,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633225359,
                        ["quant"] = 1,
                        ["id"] = "1692068047",
                        ["itemLink"] = 2383,
                    },
                    [7] = 
                    {
                        ["price"] = 196,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633251479,
                        ["quant"] = 1,
                        ["id"] = "1692280589",
                        ["itemLink"] = 2383,
                    },
                    [8] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633251490,
                        ["quant"] = 1,
                        ["id"] = "1692280647",
                        ["itemLink"] = 1406,
                    },
                    [9] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633251491,
                        ["quant"] = 1,
                        ["id"] = "1692280649",
                        ["itemLink"] = 2603,
                    },
                    [10] = 
                    {
                        ["price"] = 128,
                        ["guild"] = 1,
                        ["buyer"] = 1866,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1633267873,
                        ["quant"] = 1,
                        ["id"] = "1692383633",
                        ["itemLink"] = 2375,
                    },
                    [11] = 
                    {
                        ["price"] = 132,
                        ["guild"] = 1,
                        ["buyer"] = 1866,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1633267873,
                        ["quant"] = 1,
                        ["id"] = "1692383639",
                        ["itemLink"] = 2603,
                    },
                    [12] = 
                    {
                        ["price"] = 127,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633297963,
                        ["quant"] = 1,
                        ["id"] = "1692720449",
                        ["itemLink"] = 1406,
                    },
                    [13] = 
                    {
                        ["price"] = 127,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633297964,
                        ["quant"] = 1,
                        ["id"] = "1692720457",
                        ["itemLink"] = 2603,
                    },
                    [14] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632826384,
                        ["quant"] = 1,
                        ["id"] = "1688971281",
                        ["itemLink"] = 2383,
                    },
                    [15] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632826387,
                        ["quant"] = 1,
                        ["id"] = "1688971333",
                        ["itemLink"] = 1406,
                    },
                    [16] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632845891,
                        ["quant"] = 1,
                        ["id"] = "1689109379",
                        ["itemLink"] = 2375,
                    },
                    [17] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2201,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632846652,
                        ["quant"] = 1,
                        ["id"] = "1689115609",
                        ["itemLink"] = 3199,
                    },
                    [18] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2201,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632846654,
                        ["quant"] = 1,
                        ["id"] = "1689115619",
                        ["itemLink"] = 2375,
                    },
                    [19] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2201,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632846655,
                        ["quant"] = 1,
                        ["id"] = "1689115623",
                        ["itemLink"] = 730,
                    },
                    [20] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632885353,
                        ["quant"] = 1,
                        ["id"] = "1689456603",
                        ["itemLink"] = 2375,
                    },
                    [21] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632885357,
                        ["quant"] = 1,
                        ["id"] = "1689456627",
                        ["itemLink"] = 2377,
                    },
                    [22] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632885360,
                        ["quant"] = 1,
                        ["id"] = "1689456649",
                        ["itemLink"] = 2383,
                    },
                    [23] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 2425,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632893292,
                        ["quant"] = 1,
                        ["id"] = "1689518729",
                        ["itemLink"] = 1685,
                    },
                    [24] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 2425,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632893293,
                        ["quant"] = 1,
                        ["id"] = "1689518747",
                        ["itemLink"] = 2603,
                    },
                },
                ["totalCount"] = 24,
                ["itemAdderText"] = "cp160 white normal miscellaneous armor glyph",
            },
            ["50:16:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_armor_magickaboost.dds",
                ["itemDesc"] = "Truly Superb Glyph of Magicka",
                ["oldestTime"] = 1633198148,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311809,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 5,
                        ["wasKiosk"] = true,
                        ["seller"] = 6,
                        ["timestamp"] = 1633311234,
                        ["quant"] = 1,
                        ["id"] = "1692862931",
                        ["itemLink"] = 3,
                    },
                    [2] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633311808,
                        ["quant"] = 1,
                        ["id"] = "1692867681",
                        ["itemLink"] = 16,
                    },
                    [3] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633311808,
                        ["quant"] = 1,
                        ["id"] = "1692867685",
                        ["itemLink"] = 16,
                    },
                    [4] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633311809,
                        ["quant"] = 1,
                        ["id"] = "1692867693",
                        ["itemLink"] = 16,
                    },
                    [5] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 382,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633198148,
                        ["quant"] = 1,
                        ["id"] = "1691770471",
                        ["itemLink"] = 16,
                    },
                    [6] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 802,
                        ["wasKiosk"] = false,
                        ["seller"] = 24,
                        ["timestamp"] = 1633213951,
                        ["quant"] = 1,
                        ["id"] = "1691948735",
                        ["itemLink"] = 16,
                    },
                    [7] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 1737,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633236351,
                        ["quant"] = 1,
                        ["id"] = "1692170557",
                        ["itemLink"] = 16,
                    },
                    [8] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 1737,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633236352,
                        ["quant"] = 1,
                        ["id"] = "1692170561",
                        ["itemLink"] = 16,
                    },
                    [9] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 1737,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633236353,
                        ["quant"] = 1,
                        ["id"] = "1692170567",
                        ["itemLink"] = 16,
                    },
                    [10] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 1737,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633236354,
                        ["quant"] = 1,
                        ["id"] = "1692170573",
                        ["itemLink"] = 16,
                    },
                    [11] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 1737,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633236354,
                        ["quant"] = 1,
                        ["id"] = "1692170577",
                        ["itemLink"] = 16,
                    },
                },
                ["totalCount"] = 11,
                ["itemAdderText"] = "cp160 purple epic miscellaneous armor glyph",
            },
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_armor_magickaboost.dds",
                ["itemDesc"] = "Truly Superb Glyph of Magicka",
                ["oldestTime"] = 1632908553,
                ["wasAltered"] = true,
                ["newestTime"] = 1633314680,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6210,
                        ["guild"] = 1,
                        ["buyer"] = 83,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633314677,
                        ["quant"] = 1,
                        ["id"] = "1692898373",
                        ["itemLink"] = 62,
                    },
                    [2] = 
                    {
                        ["price"] = 6210,
                        ["guild"] = 1,
                        ["buyer"] = 83,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633314680,
                        ["quant"] = 1,
                        ["id"] = "1692898441",
                        ["itemLink"] = 62,
                    },
                    [3] = 
                    {
                        ["price"] = 6210,
                        ["guild"] = 1,
                        ["buyer"] = 1656,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633226863,
                        ["quant"] = 1,
                        ["id"] = "1692084261",
                        ["itemLink"] = 62,
                    },
                    [4] = 
                    {
                        ["price"] = 6210,
                        ["guild"] = 1,
                        ["buyer"] = 1997,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633298157,
                        ["quant"] = 1,
                        ["id"] = "1692722671",
                        ["itemLink"] = 62,
                    },
                    [5] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 881,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633301755,
                        ["quant"] = 1,
                        ["id"] = "1692758681",
                        ["itemLink"] = 62,
                    },
                    [6] = 
                    {
                        ["price"] = 6210,
                        ["guild"] = 1,
                        ["buyer"] = 1330,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1632908553,
                        ["quant"] = 1,
                        ["id"] = "1689596895",
                        ["itemLink"] = 62,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous armor glyph",
            },
        },
        [95703] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_medium_shoulders_a.dds",
                ["itemDesc"] = "Arm Cops of the Air",
                ["oldestTime"] = 1633023041,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023041,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633023041,
                        ["quant"] = 1,
                        ["id"] = "1690390993",
                        ["itemLink"] = 665,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set way of air shoulders well-fitted",
            },
        },
        [114566] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_light_waist_a.dds",
                ["itemDesc"] = "Sash of Bahraha's Curse",
                ["oldestTime"] = 1633017981,
                ["wasAltered"] = true,
                ["newestTime"] = 1633017981,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5041,
                        ["guild"] = 1,
                        ["buyer"] = 489,
                        ["wasKiosk"] = true,
                        ["seller"] = 494,
                        ["timestamp"] = 1633017981,
                        ["quant"] = 1,
                        ["id"] = "1690349293",
                        ["itemLink"] = 565,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set bahraha's curse waist impenetrable",
            },
        },
        [45834] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_019.dds",
                ["itemDesc"] = "Okoma",
                ["oldestTime"] = 1632978531,
                ["wasAltered"] = true,
                ["newestTime"] = 1633281978,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 239,
                        ["guild"] = 1,
                        ["buyer"] = 250,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632978531,
                        ["quant"] = 8,
                        ["id"] = "1690122439",
                        ["itemLink"] = 251,
                    },
                    [2] = 
                    {
                        ["price"] = 94,
                        ["guild"] = 1,
                        ["buyer"] = 897,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633178195,
                        ["quant"] = 3,
                        ["id"] = "1691571815",
                        ["itemLink"] = 251,
                    },
                    [3] = 
                    {
                        ["price"] = 160,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1633281978,
                        ["quant"] = 5,
                        ["id"] = "1692536817",
                        ["itemLink"] = 251,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 white normal materials essence runestone",
            },
        },
        [159450] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_uni_duc_pedestalhourglass001.dds",
                ["itemDesc"] = "Hourglass Pedestal, Square",
                ["oldestTime"] = 1633271637,
                ["wasAltered"] = true,
                ["newestTime"] = 1633271639,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 1883,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633271637,
                        ["quant"] = 1,
                        ["id"] = "1692422013",
                        ["itemLink"] = 2676,
                    },
                    [2] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 1883,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633271639,
                        ["quant"] = 1,
                        ["id"] = "1692422023",
                        ["itemLink"] = 2676,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings undercroft",
            },
        },
        [172308] = 
        {
            ["50:16:2:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_1haxe_a.dds",
                ["itemDesc"] = "Bog Raider's Axe",
                ["oldestTime"] = 1633200583,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200583,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 144,
                        ["guild"] = 1,
                        ["buyer"] = 1490,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633200583,
                        ["quant"] = 1,
                        ["id"] = "1691795681",
                        ["itemLink"] = 2189,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set bog raider axe one-handed powered",
            },
        },
        [26588] = 
        {
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_armor_staminaboost.dds",
                ["itemDesc"] = "Truly Superb Glyph of Stamina",
                ["oldestTime"] = 1632863782,
                ["wasAltered"] = true,
                ["newestTime"] = 1633208959,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 1233,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1633147650,
                        ["quant"] = 1,
                        ["id"] = "1691371427",
                        ["itemLink"] = 1677,
                    },
                    [2] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 1233,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1633147651,
                        ["quant"] = 1,
                        ["id"] = "1691371437",
                        ["itemLink"] = 1677,
                    },
                    [3] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 340,
                        ["wasKiosk"] = false,
                        ["seller"] = 673,
                        ["timestamp"] = 1633208959,
                        ["quant"] = 1,
                        ["id"] = "1691893729",
                        ["itemLink"] = 1677,
                    },
                    [4] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 2254,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1632863782,
                        ["quant"] = 1,
                        ["id"] = "1689256991",
                        ["itemLink"] = 1677,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous armor glyph",
            },
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_armor_staminaboost.dds",
                ["itemDesc"] = "Truly Superb Glyph of Stamina",
                ["oldestTime"] = 1632826385,
                ["wasAltered"] = true,
                ["newestTime"] = 1633267871,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 398,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633001131,
                        ["quant"] = 1,
                        ["id"] = "1690240011",
                        ["itemLink"] = 401,
                    },
                    [2] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 398,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633001134,
                        ["quant"] = 1,
                        ["id"] = "1690240037",
                        ["itemLink"] = 405,
                    },
                    [3] = 
                    {
                        ["price"] = 151,
                        ["guild"] = 1,
                        ["buyer"] = 398,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633001134,
                        ["quant"] = 1,
                        ["id"] = "1690240041",
                        ["itemLink"] = 406,
                    },
                    [4] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633032460,
                        ["quant"] = 1,
                        ["id"] = "1690460849",
                        ["itemLink"] = 727,
                    },
                    [5] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 1244,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633148042,
                        ["quant"] = 1,
                        ["id"] = "1691374131",
                        ["itemLink"] = 405,
                    },
                    [6] = 
                    {
                        ["price"] = 122,
                        ["guild"] = 1,
                        ["buyer"] = 1866,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1633267871,
                        ["quant"] = 1,
                        ["id"] = "1692383609",
                        ["itemLink"] = 727,
                    },
                    [7] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2119,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632826385,
                        ["quant"] = 1,
                        ["id"] = "1688971301",
                        ["itemLink"] = 401,
                    },
                    [8] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632881735,
                        ["quant"] = 1,
                        ["id"] = "1689414571",
                        ["itemLink"] = 401,
                    },
                    [9] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632881738,
                        ["quant"] = 1,
                        ["id"] = "1689414615",
                        ["itemLink"] = 406,
                    },
                    [10] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632885354,
                        ["quant"] = 1,
                        ["id"] = "1689456607",
                        ["itemLink"] = 406,
                    },
                    [11] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632885356,
                        ["quant"] = 1,
                        ["id"] = "1689456621",
                        ["itemLink"] = 3503,
                    },
                    [12] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 2425,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632893293,
                        ["quant"] = 1,
                        ["id"] = "1689518741",
                        ["itemLink"] = 3548,
                    },
                },
                ["totalCount"] = 12,
                ["itemAdderText"] = "cp160 white normal miscellaneous armor glyph",
            },
            ["50:16:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_armor_staminaboost.dds",
                ["itemDesc"] = "Truly Superb Glyph of Stamina",
                ["oldestTime"] = 1633186125,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311814,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633311803,
                        ["quant"] = 1,
                        ["id"] = "1692867629",
                        ["itemLink"] = 15,
                    },
                    [2] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633311804,
                        ["quant"] = 1,
                        ["id"] = "1692867633",
                        ["itemLink"] = 15,
                    },
                    [3] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633311805,
                        ["quant"] = 1,
                        ["id"] = "1692867641",
                        ["itemLink"] = 15,
                    },
                    [4] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633311805,
                        ["quant"] = 1,
                        ["id"] = "1692867657",
                        ["itemLink"] = 15,
                    },
                    [5] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633311807,
                        ["quant"] = 1,
                        ["id"] = "1692867675",
                        ["itemLink"] = 15,
                    },
                    [6] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633311810,
                        ["quant"] = 1,
                        ["id"] = "1692867709",
                        ["itemLink"] = 15,
                    },
                    [7] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633311811,
                        ["quant"] = 1,
                        ["id"] = "1692867719",
                        ["itemLink"] = 15,
                    },
                    [8] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633311811,
                        ["quant"] = 1,
                        ["id"] = "1692867725",
                        ["itemLink"] = 15,
                    },
                    [9] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633311812,
                        ["quant"] = 1,
                        ["id"] = "1692867729",
                        ["itemLink"] = 15,
                    },
                    [10] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633311813,
                        ["quant"] = 1,
                        ["id"] = "1692867731",
                        ["itemLink"] = 15,
                    },
                    [11] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633311814,
                        ["quant"] = 1,
                        ["id"] = "1692867743",
                        ["itemLink"] = 15,
                    },
                    [12] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 23,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633311814,
                        ["quant"] = 1,
                        ["id"] = "1692867751",
                        ["itemLink"] = 15,
                    },
                    [13] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633186125,
                        ["quant"] = 1,
                        ["id"] = "1691642049",
                        ["itemLink"] = 15,
                    },
                    [14] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 209,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633187588,
                        ["quant"] = 1,
                        ["id"] = "1691658669",
                        ["itemLink"] = 15,
                    },
                    [15] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 209,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633187589,
                        ["quant"] = 1,
                        ["id"] = "1691658693",
                        ["itemLink"] = 15,
                    },
                    [16] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 209,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633187591,
                        ["quant"] = 1,
                        ["id"] = "1691658709",
                        ["itemLink"] = 15,
                    },
                    [17] = 
                    {
                        ["price"] = 2030,
                        ["guild"] = 1,
                        ["buyer"] = 209,
                        ["wasKiosk"] = true,
                        ["seller"] = 24,
                        ["timestamp"] = 1633187617,
                        ["quant"] = 1,
                        ["id"] = "1691658979",
                        ["itemLink"] = 15,
                    },
                },
                ["totalCount"] = 17,
                ["itemAdderText"] = "cp160 purple epic miscellaneous armor glyph",
            },
            ["50:15:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_armor_staminaboost.dds",
                ["itemDesc"] = "Superb Glyph of Stamina",
                ["oldestTime"] = 1632967021,
                ["wasAltered"] = true,
                ["newestTime"] = 1632974037,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 198,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632974031,
                        ["quant"] = 1,
                        ["id"] = "1690090353",
                        ["itemLink"] = 211,
                    },
                    [2] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 198,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632974032,
                        ["quant"] = 1,
                        ["id"] = "1690090367",
                        ["itemLink"] = 211,
                    },
                    [3] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 198,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632974033,
                        ["quant"] = 1,
                        ["id"] = "1690090375",
                        ["itemLink"] = 211,
                    },
                    [4] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 198,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632974036,
                        ["quant"] = 1,
                        ["id"] = "1690090399",
                        ["itemLink"] = 211,
                    },
                    [5] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 198,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632974037,
                        ["quant"] = 1,
                        ["id"] = "1690090407",
                        ["itemLink"] = 211,
                    },
                    [6] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2666,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632967021,
                        ["quant"] = 1,
                        ["id"] = "1690024653",
                        ["itemLink"] = 211,
                    },
                    [7] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2666,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632967023,
                        ["quant"] = 1,
                        ["id"] = "1690024683",
                        ["itemLink"] = 211,
                    },
                    [8] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2666,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632967025,
                        ["quant"] = 1,
                        ["id"] = "1690024695",
                        ["itemLink"] = 211,
                    },
                    [9] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2666,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632967026,
                        ["quant"] = 1,
                        ["id"] = "1690024705",
                        ["itemLink"] = 211,
                    },
                    [10] = 
                    {
                        ["price"] = 530,
                        ["guild"] = 1,
                        ["buyer"] = 2666,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632967027,
                        ["quant"] = 1,
                        ["id"] = "1690024709",
                        ["itemLink"] = 211,
                    },
                },
                ["totalCount"] = 10,
                ["itemAdderText"] = "cp150 purple epic miscellaneous armor glyph",
            },
        },
        [140509] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 67: Welkynar Staves",
                ["oldestTime"] = 1633114866,
                ["wasAltered"] = true,
                ["newestTime"] = 1633114866,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 1015,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633114866,
                        ["quant"] = 1,
                        ["id"] = "1691071331",
                        ["itemLink"] = 1388,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [33758] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_veg_001.dds",
                ["itemDesc"] = "Potato",
                ["oldestTime"] = 1632901815,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305869,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1625,
                        ["guild"] = 1,
                        ["buyer"] = 731,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633056909,
                        ["quant"] = 25,
                        ["id"] = "1690676669",
                        ["itemLink"] = 958,
                    },
                    [2] = 
                    {
                        ["price"] = 1625,
                        ["guild"] = 1,
                        ["buyer"] = 731,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633056912,
                        ["quant"] = 25,
                        ["id"] = "1690676733",
                        ["itemLink"] = 958,
                    },
                    [3] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 731,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633209704,
                        ["quant"] = 25,
                        ["id"] = "1691902557",
                        ["itemLink"] = 958,
                    },
                    [4] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 731,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633209705,
                        ["quant"] = 25,
                        ["id"] = "1691902565",
                        ["itemLink"] = 958,
                    },
                    [5] = 
                    {
                        ["price"] = 1625,
                        ["guild"] = 1,
                        ["buyer"] = 731,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633209711,
                        ["quant"] = 25,
                        ["id"] = "1691902621",
                        ["itemLink"] = 958,
                    },
                    [6] = 
                    {
                        ["price"] = 1625,
                        ["guild"] = 1,
                        ["buyer"] = 731,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633209712,
                        ["quant"] = 25,
                        ["id"] = "1691902625",
                        ["itemLink"] = 958,
                    },
                    [7] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 1658,
                        ["timestamp"] = 1633251993,
                        ["quant"] = 30,
                        ["id"] = "1692285337",
                        ["itemLink"] = 958,
                    },
                    [8] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 2030,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633297943,
                        ["quant"] = 20,
                        ["id"] = "1692720293",
                        ["itemLink"] = 958,
                    },
                    [9] = 
                    {
                        ["price"] = 1625,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633305858,
                        ["quant"] = 25,
                        ["id"] = "1692799037",
                        ["itemLink"] = 958,
                    },
                    [10] = 
                    {
                        ["price"] = 1625,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633305859,
                        ["quant"] = 25,
                        ["id"] = "1692799057",
                        ["itemLink"] = 958,
                    },
                    [11] = 
                    {
                        ["price"] = 1625,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633305861,
                        ["quant"] = 25,
                        ["id"] = "1692799069",
                        ["itemLink"] = 958,
                    },
                    [12] = 
                    {
                        ["price"] = 1625,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633305861,
                        ["quant"] = 25,
                        ["id"] = "1692799075",
                        ["itemLink"] = 958,
                    },
                    [13] = 
                    {
                        ["price"] = 1625,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633305862,
                        ["quant"] = 25,
                        ["id"] = "1692799081",
                        ["itemLink"] = 958,
                    },
                    [14] = 
                    {
                        ["price"] = 1625,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633305862,
                        ["quant"] = 25,
                        ["id"] = "1692799089",
                        ["itemLink"] = 958,
                    },
                    [15] = 
                    {
                        ["price"] = 1625,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633305863,
                        ["quant"] = 25,
                        ["id"] = "1692799097",
                        ["itemLink"] = 958,
                    },
                    [16] = 
                    {
                        ["price"] = 1625,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633305863,
                        ["quant"] = 25,
                        ["id"] = "1692799105",
                        ["itemLink"] = 958,
                    },
                    [17] = 
                    {
                        ["price"] = 1625,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633305864,
                        ["quant"] = 25,
                        ["id"] = "1692799117",
                        ["itemLink"] = 958,
                    },
                    [18] = 
                    {
                        ["price"] = 1625,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633305865,
                        ["quant"] = 25,
                        ["id"] = "1692799133",
                        ["itemLink"] = 958,
                    },
                    [19] = 
                    {
                        ["price"] = 1625,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633305866,
                        ["quant"] = 25,
                        ["id"] = "1692799137",
                        ["itemLink"] = 958,
                    },
                    [20] = 
                    {
                        ["price"] = 1625,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633305867,
                        ["quant"] = 25,
                        ["id"] = "1692799141",
                        ["itemLink"] = 958,
                    },
                    [21] = 
                    {
                        ["price"] = 1625,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1633305869,
                        ["quant"] = 25,
                        ["id"] = "1692799155",
                        ["itemLink"] = 958,
                    },
                    [22] = 
                    {
                        ["price"] = 1750,
                        ["guild"] = 1,
                        ["buyer"] = 2448,
                        ["wasKiosk"] = true,
                        ["seller"] = 758,
                        ["timestamp"] = 1632901815,
                        ["quant"] = 25,
                        ["id"] = "1689568227",
                        ["itemLink"] = 958,
                    },
                },
                ["totalCount"] = 22,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [73183] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_thievesguildv2_1hsword_a.dds",
                ["itemDesc"] = "Sword of Bahraha's Curse",
                ["oldestTime"] = 1633193185,
                ["wasAltered"] = true,
                ["newestTime"] = 1633193185,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12999,
                        ["guild"] = 1,
                        ["buyer"] = 1432,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633193185,
                        ["quant"] = 1,
                        ["id"] = "1691725885",
                        ["itemLink"] = 2119,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set bahraha's curse sword one-handed defending",
            },
        },
        [119699] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_alchemy.dds",
                ["itemDesc"] = "Sealed Alchemy Writ",
                ["oldestTime"] = 1632714194,
                ["wasAltered"] = true,
                ["newestTime"] = 1633307852,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 2,
                        ["buyer"] = 129,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1632714194,
                        ["quant"] = 1,
                        ["id"] = "1688086579",
                        ["itemLink"] = 113,
                    },
                    [2] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 974,
                        ["wasKiosk"] = true,
                        ["seller"] = 975,
                        ["timestamp"] = 1633108770,
                        ["quant"] = 1,
                        ["id"] = "1691027535",
                        ["itemLink"] = 1311,
                    },
                    [3] = 
                    {
                        ["price"] = 6528,
                        ["guild"] = 1,
                        ["buyer"] = 1836,
                        ["wasKiosk"] = true,
                        ["seller"] = 327,
                        ["timestamp"] = 1633259920,
                        ["quant"] = 1,
                        ["id"] = "1692324677",
                        ["itemLink"] = 113,
                    },
                    [4] = 
                    {
                        ["price"] = 7152,
                        ["guild"] = 1,
                        ["buyer"] = 1836,
                        ["wasKiosk"] = true,
                        ["seller"] = 501,
                        ["timestamp"] = 1633259920,
                        ["quant"] = 1,
                        ["id"] = "1692324679",
                        ["itemLink"] = 113,
                    },
                    [5] = 
                    {
                        ["price"] = 7500,
                        ["guild"] = 1,
                        ["buyer"] = 2075,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1633307852,
                        ["quant"] = 1,
                        ["id"] = "1692821551",
                        ["itemLink"] = 2951,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [56033] = 
        {
            ["1:0:1:26:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_bow_a.dds",
                ["itemDesc"] = "Maple Bow",
                ["oldestTime"] = 1632870356,
                ["wasAltered"] = true,
                ["newestTime"] = 1633304485,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 50,
                        ["wasKiosk"] = false,
                        ["seller"] = 207,
                        ["timestamp"] = 1633036851,
                        ["quant"] = 1,
                        ["id"] = "1690491309",
                        ["itemLink"] = 774,
                    },
                    [2] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 1859,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633267093,
                        ["quant"] = 1,
                        ["id"] = "1692375769",
                        ["itemLink"] = 2642,
                    },
                    [3] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 1964,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633287338,
                        ["quant"] = 1,
                        ["id"] = "1692596627",
                        ["itemLink"] = 774,
                    },
                    [4] = 
                    {
                        ["price"] = 32999,
                        ["guild"] = 1,
                        ["buyer"] = 2061,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633304485,
                        ["quant"] = 1,
                        ["id"] = "1692785217",
                        ["itemLink"] = 774,
                    },
                    [5] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 2287,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1632870356,
                        ["quant"] = 1,
                        ["id"] = "1689305631",
                        ["itemLink"] = 774,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 white normal weapon bow two-handed nirnhoned",
            },
        },
        [151701] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_fur_housingwidebookcase001.dds",
                ["itemDesc"] = "Elsweyr Bookshelf, Short Elegant Full",
                ["oldestTime"] = 1633040018,
                ["wasAltered"] = true,
                ["newestTime"] = 1633040018,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 621,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633040018,
                        ["quant"] = 1,
                        ["id"] = "1690513249",
                        ["itemLink"] = 785,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings library",
            },
        },
        [119702] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_alchemy.dds",
                ["itemDesc"] = "Sealed Alchemy Writ",
                ["oldestTime"] = 1632983637,
                ["wasAltered"] = true,
                ["newestTime"] = 1633307855,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 300,
                        ["wasKiosk"] = true,
                        ["seller"] = 301,
                        ["timestamp"] = 1632983637,
                        ["quant"] = 1,
                        ["id"] = "1690151891",
                        ["itemLink"] = 305,
                    },
                    [2] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 974,
                        ["wasKiosk"] = true,
                        ["seller"] = 975,
                        ["timestamp"] = 1633108769,
                        ["quant"] = 1,
                        ["id"] = "1691027525",
                        ["itemLink"] = 305,
                    },
                    [3] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 974,
                        ["wasKiosk"] = true,
                        ["seller"] = 975,
                        ["timestamp"] = 1633108772,
                        ["quant"] = 1,
                        ["id"] = "1691027557",
                        ["itemLink"] = 305,
                    },
                    [4] = 
                    {
                        ["price"] = 5747,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633198653,
                        ["quant"] = 1,
                        ["id"] = "1691775939",
                        ["itemLink"] = 305,
                    },
                    [5] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633198655,
                        ["quant"] = 1,
                        ["id"] = "1691775981",
                        ["itemLink"] = 305,
                    },
                    [6] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2075,
                        ["wasKiosk"] = true,
                        ["seller"] = 622,
                        ["timestamp"] = 1633307855,
                        ["quant"] = 1,
                        ["id"] = "1692821571",
                        ["itemLink"] = 305,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [56036] = 
        {
            ["1:0:1:26:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_staff_a.dds",
                ["itemDesc"] = "Maple Lightning Staff",
                ["oldestTime"] = 1633138939,
                ["wasAltered"] = true,
                ["newestTime"] = 1633138939,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 745,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633138939,
                        ["quant"] = 1,
                        ["id"] = "1691280933",
                        ["itemLink"] = 1591,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal weapon lightning staff two-handed nirnhoned",
            },
        },
        [22757] = 
        {
            ["50:16:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_neck_a.dds",
                ["itemDesc"] = "Chain of Hist's Power",
                ["oldestTime"] = 1633163916,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163916,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 530,
                        ["timestamp"] = 1633163916,
                        ["quant"] = 1,
                        ["id"] = "1691490349",
                        ["itemLink"] = 1812,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set robes of the hist neck arcane",
            },
        },
        [119703] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_alchemy.dds",
                ["itemDesc"] = "Sealed Alchemy Writ",
                ["oldestTime"] = 1632714188,
                ["wasAltered"] = true,
                ["newestTime"] = 1633086550,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 2,
                        ["buyer"] = 129,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1632714188,
                        ["quant"] = 1,
                        ["id"] = "1688086537",
                        ["itemLink"] = 112,
                    },
                    [2] = 
                    {
                        ["price"] = 1300,
                        ["guild"] = 1,
                        ["buyer"] = 200,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632974026,
                        ["quant"] = 1,
                        ["id"] = "1690090325",
                        ["itemLink"] = 209,
                    },
                    [3] = 
                    {
                        ["price"] = 6995,
                        ["guild"] = 1,
                        ["buyer"] = 903,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1633086550,
                        ["quant"] = 1,
                        ["id"] = "1690867049",
                        ["itemLink"] = 1221,
                    },
                    [4] = 
                    {
                        ["price"] = 9999,
                        ["guild"] = 1,
                        ["buyer"] = 2222,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632852351,
                        ["quant"] = 1,
                        ["id"] = "1689161609",
                        ["itemLink"] = 209,
                    },
                    [5] = 
                    {
                        ["price"] = 19995,
                        ["guild"] = 1,
                        ["buyer"] = 2256,
                        ["wasKiosk"] = true,
                        ["seller"] = 975,
                        ["timestamp"] = 1632864540,
                        ["quant"] = 1,
                        ["id"] = "1689262161",
                        ["itemLink"] = 112,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [45543] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Sweet Lemonale",
                ["oldestTime"] = 1633179327,
                ["wasAltered"] = true,
                ["newestTime"] = 1633179327,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1078,
                        ["guild"] = 1,
                        ["buyer"] = 1361,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633179327,
                        ["quant"] = 1,
                        ["id"] = "1691581325",
                        ["itemLink"] = 1911,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [165608] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_skr_con_vampirechest001.dds",
                ["itemDesc"] = "Vampiric Trunk, Ornate Metal",
                ["oldestTime"] = 1633165784,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165784,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633165784,
                        ["quant"] = 1,
                        ["id"] = "1691499587",
                        ["itemLink"] = 1839,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings suite",
            },
        },
        [45289] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_medium_head_d.dds",
                ["itemDesc"] = "Rubedo Leather Helmet of Magicka",
                ["oldestTime"] = 1633113345,
                ["wasAltered"] = true,
                ["newestTime"] = 1633113345,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1001,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1633113345,
                        ["quant"] = 1,
                        ["id"] = "1691060353",
                        ["itemLink"] = 1362,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel head divines",
            },
        },
        [132586] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 57: Ebonshadow Chests",
                ["oldestTime"] = 1633230001,
                ["wasAltered"] = true,
                ["newestTime"] = 1633230001,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12999,
                        ["guild"] = 1,
                        ["buyer"] = 1687,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633230001,
                        ["quant"] = 1,
                        ["id"] = "1692115817",
                        ["itemLink"] = 2438,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [33771] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_smith_potion_vendor_003.dds",
                ["itemDesc"] = "Jasmine",
                ["oldestTime"] = 1633156801,
                ["wasAltered"] = true,
                ["newestTime"] = 1633156801,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 1286,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633156801,
                        ["quant"] = 200,
                        ["id"] = "1691444691",
                        ["itemLink"] = 1769,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [115734] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Argonian Table, Rough",
                ["oldestTime"] = 1633195652,
                ["wasAltered"] = true,
                ["newestTime"] = 1633195652,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 27,
                        ["guild"] = 1,
                        ["buyer"] = 1449,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633195652,
                        ["quant"] = 1,
                        ["id"] = "1691747747",
                        ["itemLink"] = 2140,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [56045] = 
        {
            ["1:0:1:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daedric_light_robe_a.dds",
                ["itemDesc"] = "Homespun Robe",
                ["oldestTime"] = 1632874759,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238424,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 820,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633065460,
                        ["quant"] = 1,
                        ["id"] = "1690751429",
                        ["itemLink"] = 1061,
                    },
                    [2] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 902,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633086650,
                        ["quant"] = 1,
                        ["id"] = "1690867449",
                        ["itemLink"] = 1224,
                    },
                    [3] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 1635,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633224213,
                        ["quant"] = 1,
                        ["id"] = "1692056219",
                        ["itemLink"] = 1224,
                    },
                    [4] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 1750,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633238424,
                        ["quant"] = 1,
                        ["id"] = "1692188275",
                        ["itemLink"] = 1224,
                    },
                    [5] = 
                    {
                        ["price"] = 4499,
                        ["guild"] = 1,
                        ["buyer"] = 2320,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1632874759,
                        ["quant"] = 1,
                        ["id"] = "1689339109",
                        ["itemLink"] = 1224,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 white normal light apparel chest nirnhoned",
            },
        },
        [161006] = 
        {
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Ring of Eternal Vigor",
                ["oldestTime"] = 1633151278,
                ["wasAltered"] = true,
                ["newestTime"] = 1633151512,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4999,
                        ["guild"] = 1,
                        ["buyer"] = 1259,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633151278,
                        ["quant"] = 1,
                        ["id"] = "1691402011",
                        ["itemLink"] = 1726,
                    },
                    [2] = 
                    {
                        ["price"] = 4999,
                        ["guild"] = 1,
                        ["buyer"] = 1265,
                        ["wasKiosk"] = true,
                        ["seller"] = 12,
                        ["timestamp"] = 1633151512,
                        ["quant"] = 1,
                        ["id"] = "1691404613",
                        ["itemLink"] = 1726,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set eternal vigor ring healthy",
            },
        },
        [30146] = 
        {
            ["50:15:1:9:1114373"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/consumable_potion_012_type_005.dds",
                ["itemDesc"] = "Essence of Weapon Crit",
                ["oldestTime"] = 1633194364,
                ["wasAltered"] = true,
                ["newestTime"] = 1633194364,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1442,
                        ["wasKiosk"] = true,
                        ["seller"] = 1417,
                        ["timestamp"] = 1633194364,
                        ["quant"] = 200,
                        ["id"] = "1691737431",
                        ["itemLink"] = 2130,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 white normal consumable potion",
            },
        },
        [135152] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/jewelrycrafting_booster_raw_iridium.dds",
                ["itemDesc"] = "Iridium Grains",
                ["oldestTime"] = 1632866645,
                ["wasAltered"] = true,
                ["newestTime"] = 1633288874,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11664,
                        ["guild"] = 1,
                        ["buyer"] = 635,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1633041386,
                        ["quant"] = 8,
                        ["id"] = "1690523625",
                        ["itemLink"] = 805,
                    },
                    [2] = 
                    {
                        ["price"] = 3300,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 179,
                        ["timestamp"] = 1633109929,
                        ["quant"] = 3,
                        ["id"] = "1691035887",
                        ["itemLink"] = 805,
                    },
                    [3] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 179,
                        ["timestamp"] = 1633109930,
                        ["quant"] = 5,
                        ["id"] = "1691035889",
                        ["itemLink"] = 805,
                    },
                    [4] = 
                    {
                        ["price"] = 6600,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1633288874,
                        ["quant"] = 6,
                        ["id"] = "1692613879",
                        ["itemLink"] = 805,
                    },
                    [5] = 
                    {
                        ["price"] = 7290,
                        ["guild"] = 1,
                        ["buyer"] = 2270,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632866645,
                        ["quant"] = 5,
                        ["id"] = "1689278963",
                        ["itemLink"] = 805,
                    },
                    [6] = 
                    {
                        ["price"] = 8748,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632892021,
                        ["quant"] = 6,
                        ["id"] = "1689508485",
                        ["itemLink"] = 805,
                    },
                    [7] = 
                    {
                        ["price"] = 2916,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632892131,
                        ["quant"] = 2,
                        ["id"] = "1689509153",
                        ["itemLink"] = 805,
                    },
                    [8] = 
                    {
                        ["price"] = 6750,
                        ["guild"] = 1,
                        ["buyer"] = 2504,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632927068,
                        ["quant"] = 5,
                        ["id"] = "1689701125",
                        ["itemLink"] = 805,
                    },
                    [9] = 
                    {
                        ["price"] = 12100,
                        ["guild"] = 1,
                        ["buyer"] = 2515,
                        ["wasKiosk"] = true,
                        ["seller"] = 179,
                        ["timestamp"] = 1632954616,
                        ["quant"] = 11,
                        ["id"] = "1689915387",
                        ["itemLink"] = 805,
                    },
                },
                ["totalCount"] = 9,
                ["itemAdderText"] = "rr01 blue superior materials raw plating",
            },
        },
        [43561] = 
        {
            ["50:14:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Electrum Necklace",
                ["oldestTime"] = 1633188994,
                ["wasAltered"] = true,
                ["newestTime"] = 1633290156,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 398,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633188994,
                        ["quant"] = 1,
                        ["id"] = "1691678011",
                        ["itemLink"] = 2089,
                    },
                    [2] = 
                    {
                        ["price"] = 190,
                        ["guild"] = 1,
                        ["buyer"] = 817,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633239078,
                        ["quant"] = 1,
                        ["id"] = "1692191669",
                        ["itemLink"] = 2518,
                    },
                    [3] = 
                    {
                        ["price"] = 515,
                        ["guild"] = 1,
                        ["buyer"] = 1978,
                        ["wasKiosk"] = true,
                        ["seller"] = 1004,
                        ["timestamp"] = 1633290156,
                        ["quant"] = 1,
                        ["id"] = "1692628897",
                        ["itemLink"] = 2780,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp140 white normal jewelry apparel neck",
            },
        },
        [33218] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_flower_ironweed.dds",
                ["itemDesc"] = "Raw Ironweed",
                ["oldestTime"] = 1633185024,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185027,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1389,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633185024,
                        ["quant"] = 200,
                        ["id"] = "1691629357",
                        ["itemLink"] = 1981,
                    },
                    [2] = 
                    {
                        ["price"] = 9300,
                        ["guild"] = 1,
                        ["buyer"] = 1389,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633185027,
                        ["quant"] = 93,
                        ["id"] = "1691629391",
                        ["itemLink"] = 1981,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [180467] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_light_legs_a.dds",
                ["itemDesc"] = "Breeches of Dark Convergence",
                ["oldestTime"] = 1633225758,
                ["wasAltered"] = true,
                ["newestTime"] = 1633225758,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 1646,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633225758,
                        ["quant"] = 1,
                        ["id"] = "1692071853",
                        ["itemLink"] = 2390,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set dark convergence legs divines",
            },
        },
        [68340] = 
        {
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_056.dds",
                ["itemDesc"] = "Itade",
                ["oldestTime"] = 1632714123,
                ["wasAltered"] = true,
                ["newestTime"] = 1632714123,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 134,
                        ["guild"] = 2,
                        ["buyer"] = 129,
                        ["wasKiosk"] = false,
                        ["seller"] = 115,
                        ["timestamp"] = 1632714123,
                        ["quant"] = 3,
                        ["id"] = "1688086033",
                        ["itemLink"] = 109,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal materials potency runestone",
            },
        },
        [112425] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/event_newlifefestival_2016_dancersfestival_soup.dds",
                ["itemDesc"] = "Lava Foot Soup-and-Saltrice",
                ["oldestTime"] = 1632943469,
                ["wasAltered"] = true,
                ["newestTime"] = 1633280061,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20999,
                        ["guild"] = 1,
                        ["buyer"] = 265,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632981338,
                        ["quant"] = 100,
                        ["id"] = "1690138247",
                        ["itemLink"] = 277,
                    },
                    [2] = 
                    {
                        ["price"] = 20999,
                        ["guild"] = 1,
                        ["buyer"] = 265,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632981339,
                        ["quant"] = 100,
                        ["id"] = "1690138249",
                        ["itemLink"] = 277,
                    },
                    [3] = 
                    {
                        ["price"] = 21500,
                        ["guild"] = 1,
                        ["buyer"] = 265,
                        ["wasKiosk"] = true,
                        ["seller"] = 144,
                        ["timestamp"] = 1632981355,
                        ["quant"] = 100,
                        ["id"] = "1690138361",
                        ["itemLink"] = 277,
                    },
                    [4] = 
                    {
                        ["price"] = 19999,
                        ["guild"] = 1,
                        ["buyer"] = 1278,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633155212,
                        ["quant"] = 100,
                        ["id"] = "1691432657",
                        ["itemLink"] = 277,
                    },
                    [5] = 
                    {
                        ["price"] = 19999,
                        ["guild"] = 1,
                        ["buyer"] = 1336,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633170431,
                        ["quant"] = 100,
                        ["id"] = "1691521853",
                        ["itemLink"] = 277,
                    },
                    [6] = 
                    {
                        ["price"] = 19999,
                        ["guild"] = 1,
                        ["buyer"] = 1336,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633170431,
                        ["quant"] = 100,
                        ["id"] = "1691521859",
                        ["itemLink"] = 277,
                    },
                    [7] = 
                    {
                        ["price"] = 18500,
                        ["guild"] = 1,
                        ["buyer"] = 1482,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633199642,
                        ["quant"] = 100,
                        ["id"] = "1691785849",
                        ["itemLink"] = 277,
                    },
                    [8] = 
                    {
                        ["price"] = 19999,
                        ["guild"] = 1,
                        ["buyer"] = 1798,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633245372,
                        ["quant"] = 100,
                        ["id"] = "1692236065",
                        ["itemLink"] = 277,
                    },
                    [9] = 
                    {
                        ["price"] = 19999,
                        ["guild"] = 1,
                        ["buyer"] = 1925,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633280061,
                        ["quant"] = 100,
                        ["id"] = "1692516107",
                        ["itemLink"] = 277,
                    },
                    [10] = 
                    {
                        ["price"] = 19999,
                        ["guild"] = 1,
                        ["buyer"] = 632,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632943469,
                        ["quant"] = 100,
                        ["id"] = "1689821741",
                        ["itemLink"] = 277,
                    },
                    [11] = 
                    {
                        ["price"] = 19999,
                        ["guild"] = 1,
                        ["buyer"] = 1534,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632958369,
                        ["quant"] = 100,
                        ["id"] = "1689946575",
                        ["itemLink"] = 277,
                    },
                },
                ["totalCount"] = 11,
                ["itemAdderText"] = "rr01 blue superior consumable food",
            },
        },
        [119701] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_alchemy.dds",
                ["itemDesc"] = "Sealed Alchemy Writ",
                ["oldestTime"] = 1633108773,
                ["wasAltered"] = true,
                ["newestTime"] = 1633307854,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14150,
                        ["guild"] = 1,
                        ["buyer"] = 974,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633108773,
                        ["quant"] = 1,
                        ["id"] = "1691027567",
                        ["itemLink"] = 1312,
                    },
                    [2] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 2075,
                        ["wasKiosk"] = true,
                        ["seller"] = 1429,
                        ["timestamp"] = 1633307854,
                        ["quant"] = 1,
                        ["id"] = "1692821563",
                        ["itemLink"] = 1312,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [177019] = 
        {
            ["1:0:3:50:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_chest_medium.dds",
                ["itemDesc"] = "Companion's Jack",
                ["oldestTime"] = 1633178806,
                ["wasAltered"] = true,
                ["newestTime"] = 1633178806,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 658,
                        ["wasKiosk"] = true,
                        ["seller"] = 573,
                        ["timestamp"] = 1633178806,
                        ["quant"] = 1,
                        ["id"] = "1691576557",
                        ["itemLink"] = 1908,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior medium apparel chest bolstered",
            },
        },
        [160504] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 84: Blackreach Vanguard Shields",
                ["oldestTime"] = 1632852109,
                ["wasAltered"] = true,
                ["newestTime"] = 1632929269,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1632852109,
                        ["quant"] = 1,
                        ["id"] = "1689160053",
                        ["itemLink"] = 3248,
                    },
                    [2] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 2510,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632929269,
                        ["quant"] = 1,
                        ["id"] = "1689715923",
                        ["itemLink"] = 3248,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [125689] = 
        {
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Impregnable Armor Ring",
                ["oldestTime"] = 1632830277,
                ["wasAltered"] = true,
                ["newestTime"] = 1632830277,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2134,
                        ["wasKiosk"] = true,
                        ["seller"] = 237,
                        ["timestamp"] = 1632830277,
                        ["quant"] = 1,
                        ["id"] = "1689000087",
                        ["itemLink"] = 3067,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set impregnable armor ring healthy",
            },
        },
        [114889] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_furniture_base_regulus.dds",
                ["itemDesc"] = "Regulus",
                ["oldestTime"] = 1632869343,
                ["wasAltered"] = true,
                ["newestTime"] = 1633282966,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5965,
                        ["guild"] = 1,
                        ["buyer"] = 262,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632980786,
                        ["quant"] = 200,
                        ["id"] = "1690134153",
                        ["itemLink"] = 267,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 166,
                        ["timestamp"] = 1633043592,
                        ["quant"] = 100,
                        ["id"] = "1690542385",
                        ["itemLink"] = 267,
                    },
                    [3] = 
                    {
                        ["price"] = 10710,
                        ["guild"] = 1,
                        ["buyer"] = 460,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1633044803,
                        ["quant"] = 126,
                        ["id"] = "1690554485",
                        ["itemLink"] = 267,
                    },
                    [4] = 
                    {
                        ["price"] = 5720,
                        ["guild"] = 1,
                        ["buyer"] = 508,
                        ["wasKiosk"] = false,
                        ["seller"] = 449,
                        ["timestamp"] = 1633130162,
                        ["quant"] = 200,
                        ["id"] = "1691187795",
                        ["itemLink"] = 267,
                    },
                    [5] = 
                    {
                        ["price"] = 5708,
                        ["guild"] = 1,
                        ["buyer"] = 1263,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633151341,
                        ["quant"] = 200,
                        ["id"] = "1691402951",
                        ["itemLink"] = 267,
                    },
                    [6] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1302,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1633160167,
                        ["quant"] = 200,
                        ["id"] = "1691465619",
                        ["itemLink"] = 267,
                    },
                    [7] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1302,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1633160169,
                        ["quant"] = 200,
                        ["id"] = "1691465631",
                        ["itemLink"] = 267,
                    },
                    [8] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1302,
                        ["wasKiosk"] = true,
                        ["seller"] = 229,
                        ["timestamp"] = 1633160174,
                        ["quant"] = 200,
                        ["id"] = "1691465675",
                        ["itemLink"] = 267,
                    },
                    [9] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 229,
                        ["timestamp"] = 1633193967,
                        ["quant"] = 200,
                        ["id"] = "1691734597",
                        ["itemLink"] = 267,
                    },
                    [10] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 229,
                        ["timestamp"] = 1633193967,
                        ["quant"] = 200,
                        ["id"] = "1691734609",
                        ["itemLink"] = 267,
                    },
                    [11] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 229,
                        ["timestamp"] = 1633193968,
                        ["quant"] = 200,
                        ["id"] = "1691734621",
                        ["itemLink"] = 267,
                    },
                    [12] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 229,
                        ["timestamp"] = 1633193969,
                        ["quant"] = 200,
                        ["id"] = "1691734627",
                        ["itemLink"] = 267,
                    },
                    [13] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 229,
                        ["timestamp"] = 1633193969,
                        ["quant"] = 200,
                        ["id"] = "1691734633",
                        ["itemLink"] = 267,
                    },
                    [14] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 229,
                        ["timestamp"] = 1633193970,
                        ["quant"] = 200,
                        ["id"] = "1691734649",
                        ["itemLink"] = 267,
                    },
                    [15] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 229,
                        ["timestamp"] = 1633193971,
                        ["quant"] = 200,
                        ["id"] = "1691734661",
                        ["itemLink"] = 267,
                    },
                    [16] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 229,
                        ["timestamp"] = 1633193972,
                        ["quant"] = 200,
                        ["id"] = "1691734671",
                        ["itemLink"] = 267,
                    },
                    [17] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 1942,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1633282964,
                        ["quant"] = 200,
                        ["id"] = "1692546723",
                        ["itemLink"] = 267,
                    },
                    [18] = 
                    {
                        ["price"] = 79800,
                        ["guild"] = 1,
                        ["buyer"] = 1942,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1633282965,
                        ["quant"] = 200,
                        ["id"] = "1692546727",
                        ["itemLink"] = 267,
                    },
                    [19] = 
                    {
                        ["price"] = 79800,
                        ["guild"] = 1,
                        ["buyer"] = 1942,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1633282966,
                        ["quant"] = 200,
                        ["id"] = "1692546735",
                        ["itemLink"] = 267,
                    },
                    [20] = 
                    {
                        ["price"] = 79800,
                        ["guild"] = 1,
                        ["buyer"] = 1942,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1633282966,
                        ["quant"] = 200,
                        ["id"] = "1692546741",
                        ["itemLink"] = 267,
                    },
                    [21] = 
                    {
                        ["price"] = 79800,
                        ["guild"] = 1,
                        ["buyer"] = 236,
                        ["wasKiosk"] = false,
                        ["seller"] = 571,
                        ["timestamp"] = 1632869343,
                        ["quant"] = 200,
                        ["id"] = "1689298405",
                        ["itemLink"] = 267,
                    },
                    [22] = 
                    {
                        ["price"] = 79800,
                        ["guild"] = 1,
                        ["buyer"] = 236,
                        ["wasKiosk"] = false,
                        ["seller"] = 571,
                        ["timestamp"] = 1632869345,
                        ["quant"] = 200,
                        ["id"] = "1689298431",
                        ["itemLink"] = 267,
                    },
                    [23] = 
                    {
                        ["price"] = 90000,
                        ["guild"] = 1,
                        ["buyer"] = 236,
                        ["wasKiosk"] = false,
                        ["seller"] = 476,
                        ["timestamp"] = 1632869346,
                        ["quant"] = 200,
                        ["id"] = "1689298443",
                        ["itemLink"] = 267,
                    },
                    [24] = 
                    {
                        ["price"] = 90000,
                        ["guild"] = 1,
                        ["buyer"] = 236,
                        ["wasKiosk"] = false,
                        ["seller"] = 476,
                        ["timestamp"] = 1632869349,
                        ["quant"] = 200,
                        ["id"] = "1689298459",
                        ["itemLink"] = 267,
                    },
                    [25] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 229,
                        ["timestamp"] = 1632938697,
                        ["quant"] = 200,
                        ["id"] = "1689785457",
                        ["itemLink"] = 267,
                    },
                    [26] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 571,
                        ["wasKiosk"] = false,
                        ["seller"] = 229,
                        ["timestamp"] = 1632938698,
                        ["quant"] = 200,
                        ["id"] = "1689785461",
                        ["itemLink"] = 267,
                    },
                    [27] = 
                    {
                        ["price"] = 7990,
                        ["guild"] = 1,
                        ["buyer"] = 2583,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632950622,
                        ["quant"] = 94,
                        ["id"] = "1689878871",
                        ["itemLink"] = 267,
                    },
                },
                ["totalCount"] = 27,
                ["itemAdderText"] = "rr01 white normal materials furnishing",
            },
        },
        [125691] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Impregnable Armor Ring",
                ["oldestTime"] = 1632839082,
                ["wasAltered"] = true,
                ["newestTime"] = 1632839082,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4999,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1632839082,
                        ["quant"] = 1,
                        ["id"] = "1689055057",
                        ["itemLink"] = 3125,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set impregnable armor ring robust",
            },
        },
        [102080] = 
        {
            ["50:16:2:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_draugr_bow_a.dds",
                ["itemDesc"] = "Stygian Bow",
                ["oldestTime"] = 1633102052,
                ["wasAltered"] = true,
                ["newestTime"] = 1633102052,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 954,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633102052,
                        ["quant"] = 1,
                        ["id"] = "1690973201",
                        ["itemLink"] = 1288,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set stygian bow two-handed infused",
            },
        },
        [56028] = 
        {
            ["1:0:1:26:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_1hsword_a.dds",
                ["itemDesc"] = "Iron Sword",
                ["oldestTime"] = 1632990230,
                ["wasAltered"] = true,
                ["newestTime"] = 1633097036,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1632990230,
                        ["quant"] = 1,
                        ["id"] = "1690188537",
                        ["itemLink"] = 350,
                    },
                    [2] = 
                    {
                        ["price"] = 34999,
                        ["guild"] = 1,
                        ["buyer"] = 902,
                        ["wasKiosk"] = true,
                        ["seller"] = 207,
                        ["timestamp"] = 1633097036,
                        ["quant"] = 1,
                        ["id"] = "1690936481",
                        ["itemLink"] = 350,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal weapon sword one-handed nirnhoned",
            },
        },
        [30153] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_mushroom_namiras_rot_r1.dds",
                ["itemDesc"] = "Namira's Rot",
                ["oldestTime"] = 1632862983,
                ["wasAltered"] = true,
                ["newestTime"] = 1633008110,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10750,
                        ["guild"] = 1,
                        ["buyer"] = 436,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1633008110,
                        ["quant"] = 50,
                        ["id"] = "1690277511",
                        ["itemLink"] = 441,
                    },
                    [2] = 
                    {
                        ["price"] = 3383,
                        ["guild"] = 1,
                        ["buyer"] = 549,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632862983,
                        ["quant"] = 17,
                        ["id"] = "1689251485",
                        ["itemLink"] = 441,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [175615] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_fur_leytablerectsmall001.dds",
                ["itemDesc"] = "Leyawiin Table, Formal",
                ["oldestTime"] = 1633029177,
                ["wasAltered"] = true,
                ["newestTime"] = 1633029177,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 557,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1633029177,
                        ["quant"] = 1,
                        ["id"] = "1690438303",
                        ["itemLink"] = 708,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings dining",
            },
        },
    },
}
