GS03DataSavedVariables =
{
    ["listingseu"] = 
    {
    },
    ["listingsna"] = 
    {
    },
    ["dataeu"] = 
    {
    },
    ["datana"] = 
    {
        [71680] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 28: Ra Gada Helmets",
                ["oldestTime"] = 1633008890,
                ["wasAltered"] = true,
                ["newestTime"] = 1633219936,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3250,
                        ["guild"] = 1,
                        ["buyer"] = 430,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1633008890,
                        ["quant"] = 1,
                        ["id"] = "1690282139",
                        ["itemLink"] = 448,
                    },
                    [2] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 1210,
                        ["wasKiosk"] = true,
                        ["seller"] = 734,
                        ["timestamp"] = 1633143175,
                        ["quant"] = 1,
                        ["id"] = "1691327315",
                        ["itemLink"] = 448,
                    },
                    [3] = 
                    {
                        ["price"] = 3682,
                        ["guild"] = 1,
                        ["buyer"] = 1607,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633219936,
                        ["quant"] = 1,
                        ["id"] = "1692011511",
                        ["itemLink"] = 448,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [166913] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Solitude Serving Dish, Wood",
                ["oldestTime"] = 1632920939,
                ["wasAltered"] = true,
                ["newestTime"] = 1632920939,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2486,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1632920939,
                        ["quant"] = 1,
                        ["id"] = "1689657647",
                        ["itemLink"] = 3653,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [141826] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_sum_fur_bedsimplefloating001.dds",
                ["itemDesc"] = "Alinor Bed, Levitating",
                ["oldestTime"] = 1633159496,
                ["wasAltered"] = true,
                ["newestTime"] = 1633166699,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 1297,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633159496,
                        ["quant"] = 1,
                        ["id"] = "1691462211",
                        ["itemLink"] = 1784,
                    },
                    [2] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 1327,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633166699,
                        ["quant"] = 1,
                        ["id"] = "1691503569",
                        ["itemLink"] = 1784,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary furnishings suite",
            },
        },
        [45316] = 
        {
            ["50:15:1:19:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_light_legs_d.dds",
                ["itemDesc"] = "Ancestor Silk Breeches",
                ["oldestTime"] = 1633022974,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022974,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 430,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 528,
                        ["timestamp"] = 1633022974,
                        ["quant"] = 1,
                        ["id"] = "1690390371",
                        ["itemLink"] = 614,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 white normal light apparel legs ornate",
            },
        },
        [71686] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 28: Ra Gada Swords",
                ["oldestTime"] = 1632938220,
                ["wasAltered"] = true,
                ["newestTime"] = 1633219934,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 957,
                        ["timestamp"] = 1633125656,
                        ["quant"] = 1,
                        ["id"] = "1691147499",
                        ["itemLink"] = 1478,
                    },
                    [2] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1607,
                        ["wasKiosk"] = true,
                        ["seller"] = 61,
                        ["timestamp"] = 1633219934,
                        ["quant"] = 1,
                        ["id"] = "1692011495",
                        ["itemLink"] = 1478,
                    },
                    [3] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1872,
                        ["wasKiosk"] = true,
                        ["seller"] = 729,
                        ["timestamp"] = 1632938220,
                        ["quant"] = 1,
                        ["id"] = "1689782817",
                        ["itemLink"] = 1478,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45832] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_023.dds",
                ["itemDesc"] = "Makko",
                ["oldestTime"] = 1632852303,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305391,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19800,
                        ["guild"] = 1,
                        ["buyer"] = 984,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1633110959,
                        ["quant"] = 200,
                        ["id"] = "1691043395",
                        ["itemLink"] = 1327,
                    },
                    [2] = 
                    {
                        ["price"] = 19800,
                        ["guild"] = 1,
                        ["buyer"] = 984,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1633110961,
                        ["quant"] = 200,
                        ["id"] = "1691043431",
                        ["itemLink"] = 1327,
                    },
                    [3] = 
                    {
                        ["price"] = 7400,
                        ["guild"] = 1,
                        ["buyer"] = 984,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633110964,
                        ["quant"] = 100,
                        ["id"] = "1691043467",
                        ["itemLink"] = 1327,
                    },
                    [4] = 
                    {
                        ["price"] = 240,
                        ["guild"] = 1,
                        ["buyer"] = 897,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633178206,
                        ["quant"] = 6,
                        ["id"] = "1691571849",
                        ["itemLink"] = 1327,
                    },
                    [5] = 
                    {
                        ["price"] = 2512,
                        ["guild"] = 1,
                        ["buyer"] = 1839,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633261436,
                        ["quant"] = 50,
                        ["id"] = "1692333869",
                        ["itemLink"] = 1327,
                    },
                    [6] = 
                    {
                        ["price"] = 2512,
                        ["guild"] = 1,
                        ["buyer"] = 1839,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633261439,
                        ["quant"] = 50,
                        ["id"] = "1692333873",
                        ["itemLink"] = 1327,
                    },
                    [7] = 
                    {
                        ["price"] = 2512,
                        ["guild"] = 1,
                        ["buyer"] = 1839,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633261440,
                        ["quant"] = 50,
                        ["id"] = "1692333879",
                        ["itemLink"] = 1327,
                    },
                    [8] = 
                    {
                        ["price"] = 2512,
                        ["guild"] = 1,
                        ["buyer"] = 1839,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1633261441,
                        ["quant"] = 50,
                        ["id"] = "1692333887",
                        ["itemLink"] = 1327,
                    },
                    [9] = 
                    {
                        ["price"] = 19800,
                        ["guild"] = 1,
                        ["buyer"] = 40,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1633305391,
                        ["quant"] = 200,
                        ["id"] = "1692793885",
                        ["itemLink"] = 1327,
                    },
                    [10] = 
                    {
                        ["price"] = 19800,
                        ["guild"] = 1,
                        ["buyer"] = 984,
                        ["wasKiosk"] = true,
                        ["seller"] = 571,
                        ["timestamp"] = 1632852303,
                        ["quant"] = 200,
                        ["id"] = "1689161247",
                        ["itemLink"] = 1327,
                    },
                },
                ["totalCount"] = 10,
                ["itemAdderText"] = "rr01 white normal materials essence runestone",
            },
        },
        [97035] = 
        {
            ["50:16:4:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Plague Doctor's Ring",
                ["oldestTime"] = 1632839075,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163938,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 195,
                        ["timestamp"] = 1633163938,
                        ["quant"] = 1,
                        ["id"] = "1691490507",
                        ["itemLink"] = 1828,
                    },
                    [2] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1601,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1632839075,
                        ["quant"] = 1,
                        ["id"] = "1689054985",
                        ["itemLink"] = 1828,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set plague doctor ring healthy",
            },
            ["50:16:2:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Plague Doctor's Ring",
                ["oldestTime"] = 1632842943,
                ["wasAltered"] = true,
                ["newestTime"] = 1632842943,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 451,
                        ["wasKiosk"] = false,
                        ["seller"] = 354,
                        ["timestamp"] = 1632842943,
                        ["quant"] = 1,
                        ["id"] = "1689083691",
                        ["itemLink"] = 3163,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set plague doctor ring healthy",
            },
            ["50:16:3:21:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Plague Doctor's Ring",
                ["oldestTime"] = 1633286989,
                ["wasAltered"] = true,
                ["newestTime"] = 1633286989,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 1959,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633286989,
                        ["quant"] = 1,
                        ["id"] = "1692592017",
                        ["itemLink"] = 2760,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set plague doctor ring healthy",
            },
        },
        [97292] = 
        {
            ["50:16:4:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_d.dds",
                ["itemDesc"] = "Lightning Staff of a Mother's Sorrow",
                ["oldestTime"] = 1633037794,
                ["wasAltered"] = true,
                ["newestTime"] = 1633037794,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 80000,
                        ["guild"] = 1,
                        ["buyer"] = 612,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1633037794,
                        ["quant"] = 1,
                        ["id"] = "1690497489",
                        ["itemLink"] = 777,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set mother's sorrow lightning staff two-handed defending",
            },
            ["50:16:2:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_d.dds",
                ["itemDesc"] = "Lightning Staff of a Mother's Sorrow",
                ["oldestTime"] = 1632872507,
                ["wasAltered"] = true,
                ["newestTime"] = 1632872507,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 17850,
                        ["guild"] = 1,
                        ["buyer"] = 2302,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1632872507,
                        ["quant"] = 1,
                        ["id"] = "1689318933",
                        ["itemLink"] = 3395,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set mother's sorrow lightning staff two-handed defending",
            },
        },
        [43533] = 
        {
            ["50:16:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ashlanderv_2hhammer_a.dds",
                ["itemDesc"] = "Rubedite Maul of Frost",
                ["oldestTime"] = 1632826498,
                ["wasAltered"] = true,
                ["newestTime"] = 1632826498,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 527,
                        ["timestamp"] = 1632826498,
                        ["quant"] = 1,
                        ["id"] = "1688972067",
                        ["itemLink"] = 3052,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon mace two-handed",
            },
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_2hhammer_d.dds",
                ["itemDesc"] = "Rubedite Maul",
                ["oldestTime"] = 1632826455,
                ["wasAltered"] = true,
                ["newestTime"] = 1632826473,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 166,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632826455,
                        ["quant"] = 1,
                        ["id"] = "1688971639",
                        ["itemLink"] = 3034,
                    },
                    [2] = 
                    {
                        ["price"] = 228,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 275,
                        ["timestamp"] = 1632826473,
                        ["quant"] = 1,
                        ["id"] = "1688971711",
                        ["itemLink"] = 3044,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 white normal weapon mace two-handed",
            },
        },
        [175887] = 
        {
            ["1:0:4:43:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_shoulders_medium.dds",
                ["itemDesc"] = "Companion's Arm Cops",
                ["oldestTime"] = 1632853842,
                ["wasAltered"] = true,
                ["newestTime"] = 1632853842,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 299999,
                        ["guild"] = 1,
                        ["buyer"] = 2228,
                        ["wasKiosk"] = true,
                        ["seller"] = 951,
                        ["timestamp"] = 1632853842,
                        ["quant"] = 1,
                        ["id"] = "1689173977",
                        ["itemLink"] = 3258,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic medium apparel shoulders quickened",
            },
        },
        [119312] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Redguard Tapestry, Starry",
                ["oldestTime"] = 1633227752,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227752,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 521,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633227752,
                        ["quant"] = 1,
                        ["id"] = "1692093357",
                        ["itemLink"] = 2413,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [45329] = 
        {
            ["16:0:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_staff_b.dds",
                ["itemDesc"] = "Oak Inferno Staff",
                ["oldestTime"] = 1632843157,
                ["wasAltered"] = true,
                ["newestTime"] = 1632843157,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 910,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632843157,
                        ["quant"] = 1,
                        ["id"] = "1689085093",
                        ["itemLink"] = 3172,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr16 white normal weapon flame staff two-handed intricate",
            },
            ["1:0:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_staff_a.dds",
                ["itemDesc"] = "Maple Inferno Staff",
                ["oldestTime"] = 1633084670,
                ["wasAltered"] = true,
                ["newestTime"] = 1633084670,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 120,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633084670,
                        ["quant"] = 1,
                        ["id"] = "1690857157",
                        ["itemLink"] = 1197,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal weapon flame staff two-handed intricate",
            },
            ["50:16:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_primative_staff_c.dds",
                ["itemDesc"] = "Ruby Ash Inferno Staff",
                ["oldestTime"] = 1632826490,
                ["wasAltered"] = true,
                ["newestTime"] = 1633135850,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633083995,
                        ["quant"] = 1,
                        ["id"] = "1690854383",
                        ["itemLink"] = 1146,
                    },
                    [2] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1633083998,
                        ["quant"] = 1,
                        ["id"] = "1690854409",
                        ["itemLink"] = 1149,
                    },
                    [3] = 
                    {
                        ["price"] = 228,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633084000,
                        ["quant"] = 1,
                        ["id"] = "1690854417",
                        ["itemLink"] = 1149,
                    },
                    [4] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633084004,
                        ["quant"] = 1,
                        ["id"] = "1690854461",
                        ["itemLink"] = 1152,
                    },
                    [5] = 
                    {
                        ["price"] = 288,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633084007,
                        ["quant"] = 1,
                        ["id"] = "1690854477",
                        ["itemLink"] = 1156,
                    },
                    [6] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633084012,
                        ["quant"] = 1,
                        ["id"] = "1690854507",
                        ["itemLink"] = 1160,
                    },
                    [7] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633084013,
                        ["quant"] = 1,
                        ["id"] = "1690854513",
                        ["itemLink"] = 1160,
                    },
                    [8] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633084020,
                        ["quant"] = 1,
                        ["id"] = "1690854553",
                        ["itemLink"] = 1160,
                    },
                    [9] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633135850,
                        ["quant"] = 1,
                        ["id"] = "1691251889",
                        ["itemLink"] = 1563,
                    },
                    [10] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632826490,
                        ["quant"] = 1,
                        ["id"] = "1688971927",
                        ["itemLink"] = 1149,
                    },
                    [11] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2133,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632830265,
                        ["quant"] = 1,
                        ["id"] = "1688999933",
                        ["itemLink"] = 1156,
                    },
                    [12] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2133,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632830269,
                        ["quant"] = 1,
                        ["id"] = "1688999975",
                        ["itemLink"] = 3066,
                    },
                    [13] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632842522,
                        ["quant"] = 1,
                        ["id"] = "1689079119",
                        ["itemLink"] = 1146,
                    },
                    [14] = 
                    {
                        ["price"] = 273,
                        ["guild"] = 1,
                        ["buyer"] = 2408,
                        ["wasKiosk"] = true,
                        ["seller"] = 240,
                        ["timestamp"] = 1632889281,
                        ["quant"] = 1,
                        ["id"] = "1689487551",
                        ["itemLink"] = 3532,
                    },
                    [15] = 
                    {
                        ["price"] = 158,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1632956367,
                        ["quant"] = 1,
                        ["id"] = "1689931045",
                        ["itemLink"] = 1160,
                    },
                    [16] = 
                    {
                        ["price"] = 271,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956381,
                        ["quant"] = 1,
                        ["id"] = "1689931289",
                        ["itemLink"] = 1156,
                    },
                    [17] = 
                    {
                        ["price"] = 271,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956381,
                        ["quant"] = 1,
                        ["id"] = "1689931303",
                        ["itemLink"] = 1160,
                    },
                    [18] = 
                    {
                        ["price"] = 271,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956381,
                        ["quant"] = 1,
                        ["id"] = "1689931317",
                        ["itemLink"] = 1156,
                    },
                },
                ["totalCount"] = 18,
                ["itemAdderText"] = "cp160 white normal weapon flame staff two-handed intricate",
            },
            ["50:15:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Inferno Staff",
                ["oldestTime"] = 1632826484,
                ["wasAltered"] = true,
                ["newestTime"] = 1633135851,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009390,
                        ["quant"] = 1,
                        ["id"] = "1690285715",
                        ["itemLink"] = 504,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633009395,
                        ["quant"] = 1,
                        ["id"] = "1690285787",
                        ["itemLink"] = 509,
                    },
                    [3] = 
                    {
                        ["price"] = 176,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633028887,
                        ["quant"] = 1,
                        ["id"] = "1690436661",
                        ["itemLink"] = 694,
                    },
                    [4] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633131451,
                        ["quant"] = 1,
                        ["id"] = "1691202143",
                        ["itemLink"] = 504,
                    },
                    [5] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633131465,
                        ["quant"] = 1,
                        ["id"] = "1691202323",
                        ["itemLink"] = 509,
                    },
                    [6] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633131465,
                        ["quant"] = 1,
                        ["id"] = "1691202325",
                        ["itemLink"] = 1530,
                    },
                    [7] = 
                    {
                        ["price"] = 152,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633135850,
                        ["quant"] = 1,
                        ["id"] = "1691251881",
                        ["itemLink"] = 509,
                    },
                    [8] = 
                    {
                        ["price"] = 360,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633135851,
                        ["quant"] = 1,
                        ["id"] = "1691251895",
                        ["itemLink"] = 694,
                    },
                    [9] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632826484,
                        ["quant"] = 1,
                        ["id"] = "1688971843",
                        ["itemLink"] = 3048,
                    },
                    [10] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2133,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632830260,
                        ["quant"] = 1,
                        ["id"] = "1688999861",
                        ["itemLink"] = 694,
                    },
                    [11] = 
                    {
                        ["price"] = 198,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632956370,
                        ["quant"] = 1,
                        ["id"] = "1689931097",
                        ["itemLink"] = 3873,
                    },
                    [12] = 
                    {
                        ["price"] = 238,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956374,
                        ["quant"] = 1,
                        ["id"] = "1689931167",
                        ["itemLink"] = 509,
                    },
                    [13] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632956401,
                        ["quant"] = 1,
                        ["id"] = "1689931605",
                        ["itemLink"] = 694,
                    },
                },
                ["totalCount"] = 13,
                ["itemAdderText"] = "cp150 white normal weapon flame staff two-handed intricate",
            },
        },
        [45330] = 
        {
            ["1:0:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_a.dds",
                ["itemDesc"] = "Maple Ice Staff",
                ["oldestTime"] = 1633268063,
                ["wasAltered"] = true,
                ["newestTime"] = 1633268063,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 175,
                        ["guild"] = 1,
                        ["buyer"] = 1001,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1633268063,
                        ["quant"] = 1,
                        ["id"] = "1692385889",
                        ["itemLink"] = 2650,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal weapon frost staff two-handed intricate",
            },
            ["50:15:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Ice Staff",
                ["oldestTime"] = 1632830262,
                ["wasAltered"] = true,
                ["newestTime"] = 1633268060,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 152,
                        ["guild"] = 1,
                        ["buyer"] = 842,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1633071017,
                        ["quant"] = 1,
                        ["id"] = "1690783797",
                        ["itemLink"] = 1086,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633131462,
                        ["quant"] = 1,
                        ["id"] = "1691202291",
                        ["itemLink"] = 1528,
                    },
                    [3] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633131464,
                        ["quant"] = 1,
                        ["id"] = "1691202317",
                        ["itemLink"] = 1528,
                    },
                    [4] = 
                    {
                        ["price"] = 155,
                        ["guild"] = 1,
                        ["buyer"] = 1001,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633268060,
                        ["quant"] = 1,
                        ["id"] = "1692385877",
                        ["itemLink"] = 1086,
                    },
                    [5] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2133,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632830262,
                        ["quant"] = 1,
                        ["id"] = "1688999893",
                        ["itemLink"] = 3065,
                    },
                    [6] = 
                    {
                        ["price"] = 246,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956375,
                        ["quant"] = 1,
                        ["id"] = "1689931187",
                        ["itemLink"] = 1528,
                    },
                    [7] = 
                    {
                        ["price"] = 246,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956375,
                        ["quant"] = 1,
                        ["id"] = "1689931195",
                        ["itemLink"] = 3876,
                    },
                    [8] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632956385,
                        ["quant"] = 1,
                        ["id"] = "1689931383",
                        ["itemLink"] = 1528,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "cp150 white normal weapon frost staff two-handed intricate",
            },
            ["38:0:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_staff_d.dds",
                ["itemDesc"] = "Hickory Ice Staff",
                ["oldestTime"] = 1633084671,
                ["wasAltered"] = true,
                ["newestTime"] = 1633084671,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 144,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633084671,
                        ["quant"] = 1,
                        ["id"] = "1690857181",
                        ["itemLink"] = 1199,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr38 white normal weapon frost staff two-handed intricate",
            },
            ["50:16:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_staff_d.dds",
                ["itemDesc"] = "Ruby Ash Ice Staff",
                ["oldestTime"] = 1632820777,
                ["wasAltered"] = true,
                ["newestTime"] = 1633305607,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 287,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633009380,
                        ["quant"] = 1,
                        ["id"] = "1690285573",
                        ["itemLink"] = 492,
                    },
                    [2] = 
                    {
                        ["price"] = 328,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633009381,
                        ["quant"] = 1,
                        ["id"] = "1690285593",
                        ["itemLink"] = 492,
                    },
                    [3] = 
                    {
                        ["price"] = 285,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633084006,
                        ["quant"] = 1,
                        ["id"] = "1690854473",
                        ["itemLink"] = 1155,
                    },
                    [4] = 
                    {
                        ["price"] = 263,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633131449,
                        ["quant"] = 1,
                        ["id"] = "1691202115",
                        ["itemLink"] = 1525,
                    },
                    [5] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633131458,
                        ["quant"] = 1,
                        ["id"] = "1691202213",
                        ["itemLink"] = 1525,
                    },
                    [6] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633131459,
                        ["quant"] = 1,
                        ["id"] = "1691202225",
                        ["itemLink"] = 1526,
                    },
                    [7] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633131461,
                        ["quant"] = 1,
                        ["id"] = "1691202259",
                        ["itemLink"] = 1527,
                    },
                    [8] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633131463,
                        ["quant"] = 1,
                        ["id"] = "1691202299",
                        ["itemLink"] = 1526,
                    },
                    [9] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633131464,
                        ["quant"] = 1,
                        ["id"] = "1691202307",
                        ["itemLink"] = 1529,
                    },
                    [10] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633131465,
                        ["quant"] = 1,
                        ["id"] = "1691202329",
                        ["itemLink"] = 1531,
                    },
                    [11] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633305607,
                        ["quant"] = 1,
                        ["id"] = "1692796445",
                        ["itemLink"] = 1155,
                    },
                    [12] = 
                    {
                        ["price"] = 185,
                        ["guild"] = 1,
                        ["buyer"] = 850,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632820777,
                        ["quant"] = 1,
                        ["id"] = "1688947537",
                        ["itemLink"] = 1155,
                    },
                    [13] = 
                    {
                        ["price"] = 228,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1632826474,
                        ["quant"] = 1,
                        ["id"] = "1688971729",
                        ["itemLink"] = 1155,
                    },
                    [14] = 
                    {
                        ["price"] = 271,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1632826503,
                        ["quant"] = 1,
                        ["id"] = "1688972135",
                        ["itemLink"] = 3053,
                    },
                    [15] = 
                    {
                        ["price"] = 237,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 896,
                        ["timestamp"] = 1632842520,
                        ["quant"] = 1,
                        ["id"] = "1689079107",
                        ["itemLink"] = 1525,
                    },
                    [16] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632842521,
                        ["quant"] = 1,
                        ["id"] = "1689079109",
                        ["itemLink"] = 1525,
                    },
                    [17] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1632842521,
                        ["quant"] = 1,
                        ["id"] = "1689079111",
                        ["itemLink"] = 1525,
                    },
                    [18] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632842522,
                        ["quant"] = 1,
                        ["id"] = "1689079125",
                        ["itemLink"] = 1529,
                    },
                    [19] = 
                    {
                        ["price"] = 287,
                        ["guild"] = 1,
                        ["buyer"] = 2408,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632889281,
                        ["quant"] = 1,
                        ["id"] = "1689487555",
                        ["itemLink"] = 3533,
                    },
                    [20] = 
                    {
                        ["price"] = 185,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1632956368,
                        ["quant"] = 1,
                        ["id"] = "1689931053",
                        ["itemLink"] = 492,
                    },
                    [21] = 
                    {
                        ["price"] = 270,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956380,
                        ["quant"] = 1,
                        ["id"] = "1689931279",
                        ["itemLink"] = 1526,
                    },
                    [22] = 
                    {
                        ["price"] = 285,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632956383,
                        ["quant"] = 1,
                        ["id"] = "1689931351",
                        ["itemLink"] = 3882,
                    },
                    [23] = 
                    {
                        ["price"] = 285,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632956384,
                        ["quant"] = 1,
                        ["id"] = "1689931361",
                        ["itemLink"] = 1525,
                    },
                    [24] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632956387,
                        ["quant"] = 1,
                        ["id"] = "1689931405",
                        ["itemLink"] = 1525,
                    },
                    [25] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632956400,
                        ["quant"] = 1,
                        ["id"] = "1689931587",
                        ["itemLink"] = 3892,
                    },
                    [26] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632956402,
                        ["quant"] = 1,
                        ["id"] = "1689931617",
                        ["itemLink"] = 1526,
                    },
                },
                ["totalCount"] = 26,
                ["itemAdderText"] = "cp160 white normal weapon frost staff two-handed intricate",
            },
            ["26:0:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_staff_c.dds",
                ["itemDesc"] = "Beech Ice Staff",
                ["oldestTime"] = 1633043194,
                ["wasAltered"] = true,
                ["newestTime"] = 1633043194,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 170,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1633043194,
                        ["quant"] = 1,
                        ["id"] = "1690539697",
                        ["itemLink"] = 832,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr26 white normal weapon frost staff two-handed intricate",
            },
        },
        [77587] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_poisonmaking_reagent_fleshfly_larva.dds",
                ["itemDesc"] = "Fleshfly Larva",
                ["oldestTime"] = 1632871478,
                ["wasAltered"] = true,
                ["newestTime"] = 1633297848,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10716,
                        ["guild"] = 1,
                        ["buyer"] = 265,
                        ["wasKiosk"] = true,
                        ["seller"] = 266,
                        ["timestamp"] = 1632981213,
                        ["quant"] = 200,
                        ["id"] = "1690137725",
                        ["itemLink"] = 269,
                    },
                    [2] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 278,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1632981511,
                        ["quant"] = 200,
                        ["id"] = "1690139317",
                        ["itemLink"] = 269,
                    },
                    [3] = 
                    {
                        ["price"] = 6765,
                        ["guild"] = 1,
                        ["buyer"] = 787,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633060383,
                        ["quant"] = 123,
                        ["id"] = "1690713539",
                        ["itemLink"] = 269,
                    },
                    [4] = 
                    {
                        ["price"] = 4900,
                        ["guild"] = 1,
                        ["buyer"] = 1080,
                        ["wasKiosk"] = true,
                        ["seller"] = 616,
                        ["timestamp"] = 1633125153,
                        ["quant"] = 100,
                        ["id"] = "1691143585",
                        ["itemLink"] = 269,
                    },
                    [5] = 
                    {
                        ["price"] = 407,
                        ["guild"] = 1,
                        ["buyer"] = 900,
                        ["wasKiosk"] = true,
                        ["seller"] = 99,
                        ["timestamp"] = 1633297848,
                        ["quant"] = 8,
                        ["id"] = "1692719379",
                        ["itemLink"] = 269,
                    },
                    [6] = 
                    {
                        ["price"] = 11800,
                        ["guild"] = 1,
                        ["buyer"] = 2292,
                        ["wasKiosk"] = true,
                        ["seller"] = 9,
                        ["timestamp"] = 1632871478,
                        ["quant"] = 200,
                        ["id"] = "1689312805",
                        ["itemLink"] = 269,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [147733] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 75: Sunspire Boots",
                ["oldestTime"] = 1633052837,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052837,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 719,
                        ["wasKiosk"] = true,
                        ["seller"] = 709,
                        ["timestamp"] = 1633052837,
                        ["quant"] = 1,
                        ["id"] = "1690633591",
                        ["itemLink"] = 917,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45335] = 
        {
            ["50:16:1:10:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_nord_1hsword_d.dds",
                ["itemDesc"] = "Rubedite Sword",
                ["oldestTime"] = 1633185910,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185911,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 540,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633185910,
                        ["quant"] = 1,
                        ["id"] = "1691639741",
                        ["itemLink"] = 2010,
                    },
                    [2] = 
                    {
                        ["price"] = 540,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633185911,
                        ["quant"] = 1,
                        ["id"] = "1691639749",
                        ["itemLink"] = 2011,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 white normal weapon sword one-handed ornate",
            },
        },
        [74264] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_abahswatch_staff_a.dds",
                ["itemDesc"] = "Inferno Staff of Transmutation",
                ["oldestTime"] = 1633142246,
                ["wasAltered"] = true,
                ["newestTime"] = 1633142246,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1200,
                        ["wasKiosk"] = true,
                        ["seller"] = 1201,
                        ["timestamp"] = 1633142246,
                        ["quant"] = 1,
                        ["id"] = "1691316263",
                        ["itemLink"] = 1622,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set robes of transmutation flame staff two-handed sharpened",
            },
        },
        [90137] = 
        {
            ["50:16:4:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_2haxe_a.dds",
                ["itemDesc"] = "Battle Axe of Ancient Grace",
                ["oldestTime"] = 1632988915,
                ["wasAltered"] = true,
                ["newestTime"] = 1632988915,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 339,
                        ["wasKiosk"] = true,
                        ["seller"] = 77,
                        ["timestamp"] = 1632988915,
                        ["quant"] = 1,
                        ["id"] = "1690180429",
                        ["itemLink"] = 343,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set grace of the ancients axe two-handed precise",
            },
        },
        [43546] = 
        {
            ["50:16:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_light_legs_d.dds",
                ["itemDesc"] = "Ancestor Silk Breeches of Health",
                ["oldestTime"] = 1633022963,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022963,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 171,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633022963,
                        ["quant"] = 1,
                        ["id"] = "1690390307",
                        ["itemLink"] = 603,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel legs",
            },
            ["50:16:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_light_legs_d.dds",
                ["itemDesc"] = "Ancestor Silk Breeches",
                ["oldestTime"] = 1633022962,
                ["wasAltered"] = true,
                ["newestTime"] = 1633022962,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 115,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1633022962,
                        ["quant"] = 1,
                        ["id"] = "1690390297",
                        ["itemLink"] = 601,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal light apparel legs",
            },
        },
        [115995] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing4.dds",
                ["itemDesc"] = "Diagram: Breton Lamp, Oil",
                ["oldestTime"] = 1633234982,
                ["wasAltered"] = true,
                ["newestTime"] = 1633234982,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 15,
                        ["timestamp"] = 1633234982,
                        ["quant"] = 1,
                        ["id"] = "1692160621",
                        ["itemLink"] = 2476,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [176156] = 
        {
            ["1:0:3:44:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_shoulders_medium.dds",
                ["itemDesc"] = "Companion's Arm Cops",
                ["oldestTime"] = 1633117427,
                ["wasAltered"] = true,
                ["newestTime"] = 1633117427,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6902,
                        ["guild"] = 1,
                        ["buyer"] = 1032,
                        ["wasKiosk"] = true,
                        ["seller"] = 1033,
                        ["timestamp"] = 1633117427,
                        ["quant"] = 1,
                        ["id"] = "1691087823",
                        ["itemLink"] = 1415,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior medium apparel shoulders prolific",
            },
        },
        [43549] = 
        {
            ["50:16:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_bow_c.dds",
                ["itemDesc"] = "Ruby Ash Bow of Shock",
                ["oldestTime"] = 1632826465,
                ["wasAltered"] = true,
                ["newestTime"] = 1632826465,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 533,
                        ["timestamp"] = 1632826465,
                        ["quant"] = 1,
                        ["id"] = "1688971675",
                        ["itemLink"] = 3040,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon bow two-handed",
            },
        },
        [71199] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_woodworking_rough_ruby_ash.dds",
                ["itemDesc"] = "Rough Ruby Ash",
                ["oldestTime"] = 1632845830,
                ["wasAltered"] = true,
                ["newestTime"] = 1633298933,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6444,
                        ["guild"] = 1,
                        ["buyer"] = 143,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632973214,
                        ["quant"] = 200,
                        ["id"] = "1690084273",
                        ["itemLink"] = 203,
                    },
                    [2] = 
                    {
                        ["price"] = 6444,
                        ["guild"] = 1,
                        ["buyer"] = 143,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632973214,
                        ["quant"] = 200,
                        ["id"] = "1690084279",
                        ["itemLink"] = 203,
                    },
                    [3] = 
                    {
                        ["price"] = 6487,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632983128,
                        ["quant"] = 200,
                        ["id"] = "1690148389",
                        ["itemLink"] = 203,
                    },
                    [4] = 
                    {
                        ["price"] = 7319,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633001210,
                        ["quant"] = 200,
                        ["id"] = "1690240325",
                        ["itemLink"] = 203,
                    },
                    [5] = 
                    {
                        ["price"] = 7319,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633001211,
                        ["quant"] = 200,
                        ["id"] = "1690240327",
                        ["itemLink"] = 203,
                    },
                    [6] = 
                    {
                        ["price"] = 7319,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633001211,
                        ["quant"] = 200,
                        ["id"] = "1690240331",
                        ["itemLink"] = 203,
                    },
                    [7] = 
                    {
                        ["price"] = 7319,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633001212,
                        ["quant"] = 200,
                        ["id"] = "1690240335",
                        ["itemLink"] = 203,
                    },
                    [8] = 
                    {
                        ["price"] = 7319,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633001212,
                        ["quant"] = 200,
                        ["id"] = "1690240337",
                        ["itemLink"] = 203,
                    },
                    [9] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 267,
                        ["timestamp"] = 1633001213,
                        ["quant"] = 200,
                        ["id"] = "1690240339",
                        ["itemLink"] = 203,
                    },
                    [10] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 400,
                        ["wasKiosk"] = true,
                        ["seller"] = 267,
                        ["timestamp"] = 1633001213,
                        ["quant"] = 200,
                        ["id"] = "1690240341",
                        ["itemLink"] = 203,
                    },
                    [11] = 
                    {
                        ["price"] = 6606,
                        ["guild"] = 1,
                        ["buyer"] = 578,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633033317,
                        ["quant"] = 200,
                        ["id"] = "1690465815",
                        ["itemLink"] = 203,
                    },
                    [12] = 
                    {
                        ["price"] = 7299,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633035228,
                        ["quant"] = 200,
                        ["id"] = "1690477711",
                        ["itemLink"] = 203,
                    },
                    [13] = 
                    {
                        ["price"] = 7299,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633035228,
                        ["quant"] = 200,
                        ["id"] = "1690477719",
                        ["itemLink"] = 203,
                    },
                    [14] = 
                    {
                        ["price"] = 7299,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633035229,
                        ["quant"] = 200,
                        ["id"] = "1690477725",
                        ["itemLink"] = 203,
                    },
                    [15] = 
                    {
                        ["price"] = 7299,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633035230,
                        ["quant"] = 200,
                        ["id"] = "1690477729",
                        ["itemLink"] = 203,
                    },
                    [16] = 
                    {
                        ["price"] = 7299,
                        ["guild"] = 1,
                        ["buyer"] = 594,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633035231,
                        ["quant"] = 200,
                        ["id"] = "1690477733",
                        ["itemLink"] = 203,
                    },
                    [17] = 
                    {
                        ["price"] = 6182,
                        ["guild"] = 1,
                        ["buyer"] = 742,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633054856,
                        ["quant"] = 200,
                        ["id"] = "1690653299",
                        ["itemLink"] = 203,
                    },
                    [18] = 
                    {
                        ["price"] = 6182,
                        ["guild"] = 1,
                        ["buyer"] = 742,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633054858,
                        ["quant"] = 200,
                        ["id"] = "1690653335",
                        ["itemLink"] = 203,
                    },
                    [19] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 742,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633054860,
                        ["quant"] = 200,
                        ["id"] = "1690653387",
                        ["itemLink"] = 203,
                    },
                    [20] = 
                    {
                        ["price"] = 7000,
                        ["guild"] = 1,
                        ["buyer"] = 742,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633054862,
                        ["quant"] = 200,
                        ["id"] = "1690653425",
                        ["itemLink"] = 203,
                    },
                    [21] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 742,
                        ["wasKiosk"] = true,
                        ["seller"] = 244,
                        ["timestamp"] = 1633054864,
                        ["quant"] = 200,
                        ["id"] = "1690653457",
                        ["itemLink"] = 203,
                    },
                    [22] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 742,
                        ["wasKiosk"] = true,
                        ["seller"] = 244,
                        ["timestamp"] = 1633054868,
                        ["quant"] = 200,
                        ["id"] = "1690653509",
                        ["itemLink"] = 203,
                    },
                    [23] = 
                    {
                        ["price"] = 6520,
                        ["guild"] = 1,
                        ["buyer"] = 924,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633094909,
                        ["quant"] = 200,
                        ["id"] = "1690918593",
                        ["itemLink"] = 203,
                    },
                    [24] = 
                    {
                        ["price"] = 6520,
                        ["guild"] = 1,
                        ["buyer"] = 924,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633094911,
                        ["quant"] = 200,
                        ["id"] = "1690918603",
                        ["itemLink"] = 203,
                    },
                    [25] = 
                    {
                        ["price"] = 7295,
                        ["guild"] = 1,
                        ["buyer"] = 924,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633094913,
                        ["quant"] = 200,
                        ["id"] = "1690918619",
                        ["itemLink"] = 203,
                    },
                    [26] = 
                    {
                        ["price"] = 7295,
                        ["guild"] = 1,
                        ["buyer"] = 924,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633094914,
                        ["quant"] = 200,
                        ["id"] = "1690918623",
                        ["itemLink"] = 203,
                    },
                    [27] = 
                    {
                        ["price"] = 6277,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633105277,
                        ["quant"] = 200,
                        ["id"] = "1691004037",
                        ["itemLink"] = 203,
                    },
                    [28] = 
                    {
                        ["price"] = 7295,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 242,
                        ["timestamp"] = 1633114466,
                        ["quant"] = 200,
                        ["id"] = "1691069241",
                        ["itemLink"] = 203,
                    },
                    [29] = 
                    {
                        ["price"] = 6079,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 10,
                        ["timestamp"] = 1633114467,
                        ["quant"] = 165,
                        ["id"] = "1691069247",
                        ["itemLink"] = 203,
                    },
                    [30] = 
                    {
                        ["price"] = 7400,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 486,
                        ["timestamp"] = 1633114470,
                        ["quant"] = 200,
                        ["id"] = "1691069281",
                        ["itemLink"] = 203,
                    },
                    [31] = 
                    {
                        ["price"] = 6605,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1633147968,
                        ["quant"] = 200,
                        ["id"] = "1691373669",
                        ["itemLink"] = 203,
                    },
                    [32] = 
                    {
                        ["price"] = 6545,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 21,
                        ["timestamp"] = 1633148116,
                        ["quant"] = 200,
                        ["id"] = "1691374871",
                        ["itemLink"] = 203,
                    },
                    [33] = 
                    {
                        ["price"] = 6546,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 21,
                        ["timestamp"] = 1633148118,
                        ["quant"] = 200,
                        ["id"] = "1691374923",
                        ["itemLink"] = 203,
                    },
                    [34] = 
                    {
                        ["price"] = 7294,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633154470,
                        ["quant"] = 200,
                        ["id"] = "1691427499",
                        ["itemLink"] = 203,
                    },
                    [35] = 
                    {
                        ["price"] = 7294,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633154472,
                        ["quant"] = 200,
                        ["id"] = "1691427515",
                        ["itemLink"] = 203,
                    },
                    [36] = 
                    {
                        ["price"] = 7294,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633154473,
                        ["quant"] = 200,
                        ["id"] = "1691427521",
                        ["itemLink"] = 203,
                    },
                    [37] = 
                    {
                        ["price"] = 7294,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633154473,
                        ["quant"] = 200,
                        ["id"] = "1691427527",
                        ["itemLink"] = 203,
                    },
                    [38] = 
                    {
                        ["price"] = 7294,
                        ["guild"] = 1,
                        ["buyer"] = 693,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633154475,
                        ["quant"] = 200,
                        ["id"] = "1691427543",
                        ["itemLink"] = 203,
                    },
                    [39] = 
                    {
                        ["price"] = 6234,
                        ["guild"] = 1,
                        ["buyer"] = 1364,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633180209,
                        ["quant"] = 200,
                        ["id"] = "1691586751",
                        ["itemLink"] = 203,
                    },
                    [40] = 
                    {
                        ["price"] = 1170,
                        ["guild"] = 1,
                        ["buyer"] = 35,
                        ["wasKiosk"] = false,
                        ["seller"] = 320,
                        ["timestamp"] = 1633181870,
                        ["quant"] = 30,
                        ["id"] = "1691602459",
                        ["itemLink"] = 203,
                    },
                    [41] = 
                    {
                        ["price"] = 6289,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1633234943,
                        ["quant"] = 200,
                        ["id"] = "1692160437",
                        ["itemLink"] = 203,
                    },
                    [42] = 
                    {
                        ["price"] = 6289,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 80,
                        ["timestamp"] = 1633234946,
                        ["quant"] = 200,
                        ["id"] = "1692160457",
                        ["itemLink"] = 203,
                    },
                    [43] = 
                    {
                        ["price"] = 6437,
                        ["guild"] = 1,
                        ["buyer"] = 1248,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633241493,
                        ["quant"] = 200,
                        ["id"] = "1692208397",
                        ["itemLink"] = 203,
                    },
                    [44] = 
                    {
                        ["price"] = 6437,
                        ["guild"] = 1,
                        ["buyer"] = 1248,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633241493,
                        ["quant"] = 200,
                        ["id"] = "1692208403",
                        ["itemLink"] = 203,
                    },
                    [45] = 
                    {
                        ["price"] = 6079,
                        ["guild"] = 1,
                        ["buyer"] = 1848,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633264397,
                        ["quant"] = 165,
                        ["id"] = "1692354049",
                        ["itemLink"] = 203,
                    },
                    [46] = 
                    {
                        ["price"] = 3799,
                        ["guild"] = 1,
                        ["buyer"] = 2035,
                        ["wasKiosk"] = true,
                        ["seller"] = 277,
                        ["timestamp"] = 1633298933,
                        ["quant"] = 100,
                        ["id"] = "1692730395",
                        ["itemLink"] = 203,
                    },
                    [47] = 
                    {
                        ["price"] = 6480,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632845830,
                        ["quant"] = 200,
                        ["id"] = "1689108339",
                        ["itemLink"] = 203,
                    },
                    [48] = 
                    {
                        ["price"] = 6580,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632845831,
                        ["quant"] = 200,
                        ["id"] = "1689108349",
                        ["itemLink"] = 203,
                    },
                    [49] = 
                    {
                        ["price"] = 6580,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632845831,
                        ["quant"] = 200,
                        ["id"] = "1689108361",
                        ["itemLink"] = 203,
                    },
                    [50] = 
                    {
                        ["price"] = 6296,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632872351,
                        ["quant"] = 200,
                        ["id"] = "1689317797",
                        ["itemLink"] = 203,
                    },
                    [51] = 
                    {
                        ["price"] = 6233,
                        ["guild"] = 1,
                        ["buyer"] = 1706,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632890591,
                        ["quant"] = 200,
                        ["id"] = "1689496235",
                        ["itemLink"] = 203,
                    },
                    [52] = 
                    {
                        ["price"] = 6233,
                        ["guild"] = 1,
                        ["buyer"] = 1706,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632890593,
                        ["quant"] = 200,
                        ["id"] = "1689496265",
                        ["itemLink"] = 203,
                    },
                    [53] = 
                    {
                        ["price"] = 6299,
                        ["guild"] = 1,
                        ["buyer"] = 121,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1632932732,
                        ["quant"] = 200,
                        ["id"] = "1689742387",
                        ["itemLink"] = 203,
                    },
                    [54] = 
                    {
                        ["price"] = 6309,
                        ["guild"] = 1,
                        ["buyer"] = 121,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632932732,
                        ["quant"] = 200,
                        ["id"] = "1689742395",
                        ["itemLink"] = 203,
                    },
                    [55] = 
                    {
                        ["price"] = 6309,
                        ["guild"] = 1,
                        ["buyer"] = 121,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632932733,
                        ["quant"] = 200,
                        ["id"] = "1689742405",
                        ["itemLink"] = 203,
                    },
                },
                ["totalCount"] = 55,
                ["itemAdderText"] = "rr01 white normal materials raw",
            },
        },
        [172321] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_hvy_chest_a.dds",
                ["itemDesc"] = "Bog Raider's Cuirass",
                ["oldestTime"] = 1633160268,
                ["wasAltered"] = true,
                ["newestTime"] = 1633160268,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 8,
                        ["wasKiosk"] = false,
                        ["seller"] = 530,
                        ["timestamp"] = 1633160268,
                        ["quant"] = 1,
                        ["id"] = "1691466087",
                        ["itemLink"] = 1788,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set bog raider chest divines",
            },
        },
        [160546] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 85: Greymoor Bows",
                ["oldestTime"] = 1632929258,
                ["wasAltered"] = true,
                ["newestTime"] = 1633133937,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5999,
                        ["guild"] = 1,
                        ["buyer"] = 1127,
                        ["wasKiosk"] = true,
                        ["seller"] = 2,
                        ["timestamp"] = 1633133937,
                        ["quant"] = 1,
                        ["id"] = "1691230237",
                        ["itemLink"] = 1547,
                    },
                    [2] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 2510,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632929258,
                        ["quant"] = 1,
                        ["id"] = "1689715891",
                        ["itemLink"] = 1547,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [167971] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 96: Arkthzand Armory Shields",
                ["oldestTime"] = 1633001369,
                ["wasAltered"] = true,
                ["newestTime"] = 1633240442,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 405,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1633001369,
                        ["quant"] = 1,
                        ["id"] = "1690241087",
                        ["itemLink"] = 414,
                    },
                    [2] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1772,
                        ["wasKiosk"] = true,
                        ["seller"] = 1720,
                        ["timestamp"] = 1633240442,
                        ["quant"] = 1,
                        ["id"] = "1692201201",
                        ["itemLink"] = 414,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45351] = 
        {
            ["50:16:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_light_legs_d.dds",
                ["itemDesc"] = "Ancestor Silk Breeches",
                ["oldestTime"] = 1632826515,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185992,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633084071,
                        ["quant"] = 1,
                        ["id"] = "1690854837",
                        ["itemLink"] = 1170,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084094,
                        ["quant"] = 1,
                        ["id"] = "1690854993",
                        ["itemLink"] = 1181,
                    },
                    [3] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 539,
                        ["timestamp"] = 1633084113,
                        ["quant"] = 1,
                        ["id"] = "1690855091",
                        ["itemLink"] = 1191,
                    },
                    [4] = 
                    {
                        ["price"] = 171,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633146929,
                        ["quant"] = 1,
                        ["id"] = "1691365229",
                        ["itemLink"] = 1660,
                    },
                    [5] = 
                    {
                        ["price"] = 234,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633185978,
                        ["quant"] = 1,
                        ["id"] = "1691640475",
                        ["itemLink"] = 2043,
                    },
                    [6] = 
                    {
                        ["price"] = 252,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633185992,
                        ["quant"] = 1,
                        ["id"] = "1691640615",
                        ["itemLink"] = 1191,
                    },
                    [7] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632826515,
                        ["quant"] = 1,
                        ["id"] = "1688972281",
                        ["itemLink"] = 3056,
                    },
                    [8] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632826516,
                        ["quant"] = 1,
                        ["id"] = "1688972295",
                        ["itemLink"] = 1191,
                    },
                    [9] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632841096,
                        ["quant"] = 1,
                        ["id"] = "1689067949",
                        ["itemLink"] = 1660,
                    },
                    [10] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632841097,
                        ["quant"] = 1,
                        ["id"] = "1689067957",
                        ["itemLink"] = 3153,
                    },
                    [11] = 
                    {
                        ["price"] = 244,
                        ["guild"] = 1,
                        ["buyer"] = 2165,
                        ["wasKiosk"] = true,
                        ["seller"] = 600,
                        ["timestamp"] = 1632841098,
                        ["quant"] = 1,
                        ["id"] = "1689067963",
                        ["itemLink"] = 3153,
                    },
                    [12] = 
                    {
                        ["price"] = 257,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 240,
                        ["timestamp"] = 1632885654,
                        ["quant"] = 1,
                        ["id"] = "1689459599",
                        ["itemLink"] = 1181,
                    },
                },
                ["totalCount"] = 12,
                ["itemAdderText"] = "cp160 white normal light apparel legs intricate",
            },
            ["1:0:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ashlanderv_light_legs_a.dds",
                ["itemDesc"] = "Homespun Breeches",
                ["oldestTime"] = 1632944590,
                ["wasAltered"] = true,
                ["newestTime"] = 1632944590,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 125,
                        ["guild"] = 1,
                        ["buyer"] = 2561,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632944590,
                        ["quant"] = 1,
                        ["id"] = "1689831901",
                        ["itemLink"] = 3785,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal light apparel legs intricate",
            },
            ["50:15:1:20:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_light_legs_d.dds",
                ["itemDesc"] = "Ancestor Silk Breeches",
                ["oldestTime"] = 1632913791,
                ["wasAltered"] = true,
                ["newestTime"] = 1633186014,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633009357,
                        ["quant"] = 1,
                        ["id"] = "1690285329",
                        ["itemLink"] = 469,
                    },
                    [2] = 
                    {
                        ["price"] = 365,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633009358,
                        ["quant"] = 1,
                        ["id"] = "1690285349",
                        ["itemLink"] = 471,
                    },
                    [3] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633084685,
                        ["quant"] = 1,
                        ["id"] = "1690857385",
                        ["itemLink"] = 1211,
                    },
                    [4] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1633186014,
                        ["quant"] = 1,
                        ["id"] = "1691640763",
                        ["itemLink"] = 1211,
                    },
                    [5] = 
                    {
                        ["price"] = 198,
                        ["guild"] = 1,
                        ["buyer"] = 2202,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632913791,
                        ["quant"] = 1,
                        ["id"] = "1689616129",
                        ["itemLink"] = 3634,
                    },
                    [6] = 
                    {
                        ["price"] = 243,
                        ["guild"] = 1,
                        ["buyer"] = 2561,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632944590,
                        ["quant"] = 1,
                        ["id"] = "1689831907",
                        ["itemLink"] = 469,
                    },
                    [7] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2561,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632944593,
                        ["quant"] = 1,
                        ["id"] = "1689831921",
                        ["itemLink"] = 3786,
                    },
                    [8] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1632956413,
                        ["quant"] = 1,
                        ["id"] = "1689931743",
                        ["itemLink"] = 469,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "cp150 white normal light apparel legs intricate",
            },
        },
        [129832] = 
        {
            ["50:16:3:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_snowreach_medium_head_a.dds",
                ["itemDesc"] = "Briarheart Helmet",
                ["oldestTime"] = 1632857784,
                ["wasAltered"] = true,
                ["newestTime"] = 1632857784,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1632857784,
                        ["quant"] = 1,
                        ["id"] = "1689212215",
                        ["itemLink"] = 3288,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set briarheart head sturdy",
            },
        },
        [123433] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_2haxe_a.dds",
                ["itemDesc"] = "Coward's Gear Battle Axe",
                ["oldestTime"] = 1632960126,
                ["wasAltered"] = true,
                ["newestTime"] = 1632960126,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 1077,
                        ["timestamp"] = 1632960126,
                        ["quant"] = 1,
                        ["id"] = "1689961123",
                        ["itemLink"] = 3918,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set coward's gear axe two-handed sharpened",
            },
        },
        [139309] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_sum_topiaryspiral002.dds",
                ["itemDesc"] = "Alinor Potted Plant, Twin Saplings",
                ["oldestTime"] = 1633060731,
                ["wasAltered"] = true,
                ["newestTime"] = 1633060731,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 33000,
                        ["guild"] = 1,
                        ["buyer"] = 788,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633060731,
                        ["quant"] = 2,
                        ["id"] = "1690716453",
                        ["itemLink"] = 1020,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings conservatory",
            },
        },
        [166704] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_cartographers_feet.dds",
                ["itemDesc"] = "Cartographer's Boots",
                ["oldestTime"] = 1633117390,
                ["wasAltered"] = true,
                ["newestTime"] = 1633117390,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 366,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633117390,
                        ["quant"] = 1,
                        ["id"] = "1691087661",
                        ["itemLink"] = 1414,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [77361] = 
        {
            ["50:16:2:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_darkbrotherhoodv2_light_robe_a.dds",
                ["itemDesc"] = "Sithis' Robe",
                ["oldestTime"] = 1632870297,
                ["wasAltered"] = true,
                ["newestTime"] = 1632870297,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 174,
                        ["guild"] = 2,
                        ["buyer"] = 114,
                        ["wasKiosk"] = false,
                        ["seller"] = 116,
                        ["timestamp"] = 1632870297,
                        ["quant"] = 1,
                        ["id"] = "1689305291",
                        ["itemLink"] = 139,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set sithis' touch chest reinforced",
            },
        },
        [166706] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_cartographers_backpack.dds",
                ["itemDesc"] = "Cartographer's Rucksack",
                ["oldestTime"] = 1632950867,
                ["wasAltered"] = true,
                ["newestTime"] = 1633136066,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 268,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632981324,
                        ["quant"] = 1,
                        ["id"] = "1690138215",
                        ["itemLink"] = 276,
                    },
                    [2] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1138,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633136066,
                        ["quant"] = 1,
                        ["id"] = "1691253391",
                        ["itemLink"] = 276,
                    },
                    [3] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 2588,
                        ["wasKiosk"] = true,
                        ["seller"] = 281,
                        ["timestamp"] = 1632950867,
                        ["quant"] = 1,
                        ["id"] = "1689880723",
                        ["itemLink"] = 276,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 purple epic consumable trophy",
            },
        },
        [126772] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_uni_inc_yarnball002.dds",
                ["itemDesc"] = "Khajiit Ponder Sphere",
                ["oldestTime"] = 1633065637,
                ["wasAltered"] = true,
                ["newestTime"] = 1633065637,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 821,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633065637,
                        ["quant"] = 1,
                        ["id"] = "1690752623",
                        ["itemLink"] = 1065,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings undercroft",
            },
        },
        [172341] = 
        {
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_hvy_chest_a.dds",
                ["itemDesc"] = "Bog Raider's Cuirass",
                ["oldestTime"] = 1633293818,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293818,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 8,
                        ["wasKiosk"] = false,
                        ["seller"] = 530,
                        ["timestamp"] = 1633293818,
                        ["quant"] = 1,
                        ["id"] = "1692673765",
                        ["itemLink"] = 2860,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set bog raider chest well-fitted",
            },
        },
        [156215] = 
        {
            ["50:16:5:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_staff_d.dds",
                ["itemDesc"] = "New Moon Acolyte's Inferno Staff",
                ["oldestTime"] = 1633248794,
                ["wasAltered"] = true,
                ["newestTime"] = 1633248794,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 65000,
                        ["guild"] = 1,
                        ["buyer"] = 1808,
                        ["wasKiosk"] = true,
                        ["seller"] = 1318,
                        ["timestamp"] = 1633248794,
                        ["quant"] = 1,
                        ["id"] = "1692262369",
                        ["itemLink"] = 2587,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary weapon set new moon acolyte flame staff two-handed infused",
            },
        },
        [176696] = 
        {
            ["1:0:2:48:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_shoulders_medium.dds",
                ["itemDesc"] = "Companion's Arm Cops",
                ["oldestTime"] = 1632978966,
                ["wasAltered"] = true,
                ["newestTime"] = 1633190173,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 251,
                        ["wasKiosk"] = true,
                        ["seller"] = 252,
                        ["timestamp"] = 1632978966,
                        ["quant"] = 1,
                        ["id"] = "1690125685",
                        ["itemLink"] = 256,
                    },
                    [2] = 
                    {
                        ["price"] = 900,
                        ["guild"] = 1,
                        ["buyer"] = 1413,
                        ["wasKiosk"] = true,
                        ["seller"] = 532,
                        ["timestamp"] = 1633190173,
                        ["quant"] = 1,
                        ["id"] = "1691689665",
                        ["itemLink"] = 256,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine medium apparel shoulders soothing",
            },
        },
        [96826] = 
        {
            ["50:16:3:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_heavy_hands_d.dds",
                ["itemDesc"] = "Gauntlets of the Wyrd Tree",
                ["oldestTime"] = 1632950136,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950136,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1632950136,
                        ["quant"] = 1,
                        ["id"] = "1689875289",
                        ["itemLink"] = 3831,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior heavy apparel set wyrd tree's blessing hands well-fitted",
            },
        },
        [171323] = 
        {
            ["10:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crownstore_consumable_entremet_cake.dds",
                ["itemDesc"] = "Colovian War Torte",
                ["oldestTime"] = 1633311276,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311276,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 885,
                        ["guild"] = 1,
                        ["buyer"] = 1,
                        ["wasKiosk"] = false,
                        ["seller"] = 10,
                        ["timestamp"] = 1633311276,
                        ["quant"] = 1,
                        ["id"] = "1692863419",
                        ["itemLink"] = 6,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr10 gold legendary consumable food",
            },
        },
        [83516] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/container_sealed_polymorph_001.dds",
                ["itemDesc"] = "Runebox: Pumpkin Spectre Mask",
                ["oldestTime"] = 1632844992,
                ["wasAltered"] = true,
                ["newestTime"] = 1632844992,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 399999,
                        ["guild"] = 1,
                        ["buyer"] = 2194,
                        ["wasKiosk"] = true,
                        ["seller"] = 2123,
                        ["timestamp"] = 1632844992,
                        ["quant"] = 1,
                        ["id"] = "1689099797",
                        ["itemLink"] = 3189,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable container",
            },
        },
        [151616] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Northern Elsweyr Treasure Map IV",
                ["oldestTime"] = 1633274311,
                ["wasAltered"] = true,
                ["newestTime"] = 1633274311,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 399,
                        ["guild"] = 1,
                        ["buyer"] = 396,
                        ["wasKiosk"] = true,
                        ["seller"] = 164,
                        ["timestamp"] = 1633274311,
                        ["quant"] = 1,
                        ["id"] = "1692454715",
                        ["itemLink"] = 2696,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [151618] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Northern Elsweyr Treasure Map VI",
                ["oldestTime"] = 1633149341,
                ["wasAltered"] = true,
                ["newestTime"] = 1633149341,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1250,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633149341,
                        ["quant"] = 1,
                        ["id"] = "1691385187",
                        ["itemLink"] = 1703,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [74565] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 33: Thieves Guild Maces",
                ["oldestTime"] = 1632907769,
                ["wasAltered"] = true,
                ["newestTime"] = 1632907769,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2999,
                        ["guild"] = 1,
                        ["buyer"] = 2457,
                        ["wasKiosk"] = true,
                        ["seller"] = 283,
                        ["timestamp"] = 1632907769,
                        ["quant"] = 1,
                        ["id"] = "1689595071",
                        ["itemLink"] = 3594,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [151622] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_dragonthread.dds",
                ["itemDesc"] = "Dragonthread",
                ["oldestTime"] = 1633048123,
                ["wasAltered"] = true,
                ["newestTime"] = 1633048123,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 97,
                        ["guild"] = 1,
                        ["buyer"] = 151,
                        ["wasKiosk"] = false,
                        ["seller"] = 502,
                        ["timestamp"] = 1633048123,
                        ["quant"] = 1,
                        ["id"] = "1690587229",
                        ["itemLink"] = 875,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [139079] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_tre_sum_coraltree003.dds",
                ["itemDesc"] = "Coral Formation, Fan Cluster",
                ["oldestTime"] = 1633042124,
                ["wasAltered"] = true,
                ["newestTime"] = 1633042124,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 645,
                        ["wasKiosk"] = true,
                        ["seller"] = 323,
                        ["timestamp"] = 1633042124,
                        ["quant"] = 2,
                        ["id"] = "1690529451",
                        ["itemLink"] = 809,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings conservatory",
            },
        },
        [97355] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_d.dds",
                ["itemDesc"] = "Lightning Staff of a Mother's Sorrow",
                ["oldestTime"] = 1632977448,
                ["wasAltered"] = true,
                ["newestTime"] = 1632989159,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 238,
                        ["wasKiosk"] = false,
                        ["seller"] = 195,
                        ["timestamp"] = 1632977448,
                        ["quant"] = 1,
                        ["id"] = "1690114173",
                        ["itemLink"] = 244,
                    },
                    [2] = 
                    {
                        ["price"] = 18116,
                        ["guild"] = 1,
                        ["buyer"] = 341,
                        ["wasKiosk"] = true,
                        ["seller"] = 237,
                        ["timestamp"] = 1632989159,
                        ["quant"] = 1,
                        ["id"] = "1690182155",
                        ["itemLink"] = 244,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior weapon set mother's sorrow lightning staff two-handed decisive",
            },
        },
        [180813] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_dagger_a.dds",
                ["itemDesc"] = "Hrothgar's Dagger",
                ["oldestTime"] = 1633112437,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112437,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9876,
                        ["guild"] = 1,
                        ["buyer"] = 991,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633112437,
                        ["quant"] = 1,
                        ["id"] = "1691055217",
                        ["itemLink"] = 1347,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set hrothgar's chill dagger one-handed precise",
            },
        },
        [155216] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Dragonguard Elite's Amulet",
                ["oldestTime"] = 1633163906,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163913,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 655,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633163906,
                        ["quant"] = 1,
                        ["id"] = "1691490283",
                        ["itemLink"] = 1795,
                    },
                    [2] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1633163913,
                        ["quant"] = 1,
                        ["id"] = "1691490333",
                        ["itemLink"] = 1795,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set dragonguard elite neck robust",
            },
        },
        [144978] = 
        {
            ["50:16:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_bow_a.dds",
                ["itemDesc"] = "Battalion Defender Bow",
                ["oldestTime"] = 1633060221,
                ["wasAltered"] = true,
                ["newestTime"] = 1633060221,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 784,
                        ["wasKiosk"] = true,
                        ["seller"] = 785,
                        ["timestamp"] = 1633060221,
                        ["quant"] = 1,
                        ["id"] = "1690711747",
                        ["itemLink"] = 1006,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set battalion defender bow two-handed training",
            },
        },
        [160596] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 89: Ancestral High Elf Boots",
                ["oldestTime"] = 1633028182,
                ["wasAltered"] = true,
                ["newestTime"] = 1633028182,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 548,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633028182,
                        ["quant"] = 1,
                        ["id"] = "1690430015",
                        ["itemLink"] = 690,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45909] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Camlorn Pork Sausage",
                ["oldestTime"] = 1633140923,
                ["wasAltered"] = true,
                ["newestTime"] = 1633140923,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 60,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 502,
                        ["timestamp"] = 1633140923,
                        ["quant"] = 1,
                        ["id"] = "1691300611",
                        ["itemLink"] = 1605,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [167769] = 
        {
            ["50:16:2:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Witch-Knight's Amulet",
                ["oldestTime"] = 1633029858,
                ["wasAltered"] = true,
                ["newestTime"] = 1633029858,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 450,
                        ["guild"] = 1,
                        ["buyer"] = 559,
                        ["wasKiosk"] = true,
                        ["seller"] = 535,
                        ["timestamp"] = 1633029858,
                        ["quant"] = 1,
                        ["id"] = "1690442981",
                        ["itemLink"] = 710,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine jewelry apparel set witch-knight's defiance neck robust",
            },
        },
        [139099] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_vrd_duc_sconce001.dds",
                ["itemDesc"] = "Dark Elf Brazier, Ancestral Tomb",
                ["oldestTime"] = 1633289939,
                ["wasAltered"] = true,
                ["newestTime"] = 1633289939,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 1942,
                        ["wasKiosk"] = true,
                        ["seller"] = 669,
                        ["timestamp"] = 1633289939,
                        ["quant"] = 1,
                        ["id"] = "1692626535",
                        ["itemLink"] = 2779,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [115804] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Argonian Jug, Ritual",
                ["oldestTime"] = 1633227085,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227085,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1657,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633227085,
                        ["quant"] = 1,
                        ["id"] = "1692086089",
                        ["itemLink"] = 2402,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [139101] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_cav_min_crystalformations_010.dds",
                ["itemDesc"] = "Blue Crystal Cluster, Large",
                ["oldestTime"] = 1632966535,
                ["wasAltered"] = true,
                ["newestTime"] = 1632966537,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 249999,
                        ["guild"] = 1,
                        ["buyer"] = 2662,
                        ["wasKiosk"] = true,
                        ["seller"] = 283,
                        ["timestamp"] = 1632966535,
                        ["quant"] = 5,
                        ["id"] = "1690019943",
                        ["itemLink"] = 3970,
                    },
                    [2] = 
                    {
                        ["price"] = 249999,
                        ["guild"] = 1,
                        ["buyer"] = 2662,
                        ["wasKiosk"] = true,
                        ["seller"] = 283,
                        ["timestamp"] = 1632966537,
                        ["quant"] = 5,
                        ["id"] = "1690019971",
                        ["itemLink"] = 3970,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic furnishings lighting",
            },
        },
        [180830] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_2haxe_a.dds",
                ["itemDesc"] = "Hrothgar's Battle Axe",
                ["oldestTime"] = 1633056999,
                ["wasAltered"] = true,
                ["newestTime"] = 1633056999,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 760,
                        ["wasKiosk"] = true,
                        ["seller"] = 762,
                        ["timestamp"] = 1633056999,
                        ["quant"] = 1,
                        ["id"] = "1690678601",
                        ["itemLink"] = 962,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set hrothgar's chill axe two-handed defending",
            },
        },
        [96351] = 
        {
            ["50:16:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_staff_d.dds",
                ["itemDesc"] = "Inferno Staff of the Trainee",
                ["oldestTime"] = 1632933584,
                ["wasAltered"] = true,
                ["newestTime"] = 1632933584,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2516,
                        ["wasKiosk"] = true,
                        ["seller"] = 92,
                        ["timestamp"] = 1632933584,
                        ["quant"] = 1,
                        ["id"] = "1689747949",
                        ["itemLink"] = 3722,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set armor of the trainee flame staff two-handed training",
            },
        },
        [96352] = 
        {
            ["50:16:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_staff_d.dds",
                ["itemDesc"] = "Ice Staff of the Trainee",
                ["oldestTime"] = 1632843682,
                ["wasAltered"] = true,
                ["newestTime"] = 1632843682,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632843682,
                        ["quant"] = 1,
                        ["id"] = "1689089149",
                        ["itemLink"] = 3184,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set armor of the trainee frost staff two-handed training",
            },
        },
        [97379] = 
        {
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_robe_d.dds",
                ["itemDesc"] = "Robe of a Mother's Sorrow",
                ["oldestTime"] = 1633223977,
                ["wasAltered"] = true,
                ["newestTime"] = 1633223977,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1633,
                        ["wasKiosk"] = true,
                        ["seller"] = 94,
                        ["timestamp"] = 1633223977,
                        ["quant"] = 1,
                        ["id"] = "1692053735",
                        ["itemLink"] = 2370,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set mother's sorrow chest training",
            },
        },
        [126052] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_telvanni_staff_a.dds",
                ["itemDesc"] = "Tear-Stained Staff of the War Maiden",
                ["oldestTime"] = 1633016098,
                ["wasAltered"] = true,
                ["newestTime"] = 1633016098,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 469,
                        ["wasKiosk"] = true,
                        ["seller"] = 348,
                        ["timestamp"] = 1633016098,
                        ["quant"] = 1,
                        ["id"] = "1690334233",
                        ["itemLink"] = 537,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set war maiden healing staff two-handed defending",
            },
        },
        [160614] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 88: Ancestral Orc Bows",
                ["oldestTime"] = 1632852221,
                ["wasAltered"] = true,
                ["newestTime"] = 1633161551,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1310,
                        ["wasKiosk"] = true,
                        ["seller"] = 1214,
                        ["timestamp"] = 1633161551,
                        ["quant"] = 1,
                        ["id"] = "1691474095",
                        ["itemLink"] = 1792,
                    },
                    [2] = 
                    {
                        ["price"] = 7800,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632852221,
                        ["quant"] = 1,
                        ["id"] = "1689160633",
                        ["itemLink"] = 1792,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [93817] = 
        {
            ["50:16:3:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_medium_feet_a.dds",
                ["itemDesc"] = "Boots of Cyrodiil's Ward",
                ["oldestTime"] = 1632965846,
                ["wasAltered"] = true,
                ["newestTime"] = 1632965846,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 281,
                        ["timestamp"] = 1632965846,
                        ["quant"] = 1,
                        ["id"] = "1690013949",
                        ["itemLink"] = 3955,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set ward of cyrodiil feet impenetrable",
            },
        },
        [45160] = 
        {
            ["50:16:1:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_1hsword_d.dds",
                ["itemDesc"] = "Rubedite Sword",
                ["oldestTime"] = 1632936806,
                ["wasAltered"] = true,
                ["newestTime"] = 1632975198,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 141,
                        ["guild"] = 1,
                        ["buyer"] = 209,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632975198,
                        ["quant"] = 1,
                        ["id"] = "1690096973",
                        ["itemLink"] = 219,
                    },
                    [2] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 226,
                        ["wasKiosk"] = false,
                        ["seller"] = 501,
                        ["timestamp"] = 1632936806,
                        ["quant"] = 1,
                        ["id"] = "1689773923",
                        ["itemLink"] = 3739,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 white normal weapon sword one-handed defending",
            },
        },
        [76905] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 38: Draugr Shields",
                ["oldestTime"] = 1633293511,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293511,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 293,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633293511,
                        ["quant"] = 1,
                        ["id"] = "1692669423",
                        ["itemLink"] = 2855,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [175978] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing4.dds",
                ["itemDesc"] = "Diagram: Leyawiin Chandelier, Grand Brass",
                ["oldestTime"] = 1632883895,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292437,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 899995,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 322,
                        ["timestamp"] = 1633292437,
                        ["quant"] = 1,
                        ["id"] = "1692656701",
                        ["itemLink"] = 2834,
                    },
                    [2] = 
                    {
                        ["price"] = 675000,
                        ["guild"] = 1,
                        ["buyer"] = 2377,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1632883895,
                        ["quant"] = 1,
                        ["id"] = "1689437299",
                        ["itemLink"] = 2834,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [45675] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Punkin Bunny",
                ["oldestTime"] = 1632874529,
                ["wasAltered"] = true,
                ["newestTime"] = 1633306748,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 348,
                        ["wasKiosk"] = false,
                        ["seller"] = 222,
                        ["timestamp"] = 1633242685,
                        ["quant"] = 1,
                        ["id"] = "1692215199",
                        ["itemLink"] = 2545,
                    },
                    [2] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633306748,
                        ["quant"] = 1,
                        ["id"] = "1692807055",
                        ["itemLink"] = 2545,
                    },
                    [3] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 1186,
                        ["wasKiosk"] = true,
                        ["seller"] = 443,
                        ["timestamp"] = 1632874529,
                        ["quant"] = 1,
                        ["id"] = "1689336419",
                        ["itemLink"] = 2545,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [58476] = 
        {
            ["50:16:4:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ancient_elf_medium_chest_a.dds",
                ["itemDesc"] = "Jack of the Twice-Born Star",
                ["oldestTime"] = 1633292232,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292232,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1990,
                        ["wasKiosk"] = true,
                        ["seller"] = 832,
                        ["timestamp"] = 1633292232,
                        ["quant"] = 1,
                        ["id"] = "1692654143",
                        ["itemLink"] = 2812,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel set twice-born star chest divines",
            },
        },
        [75373] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_style_item_draugr_r2.dds",
                ["itemDesc"] = "Pristine Shroud",
                ["oldestTime"] = 1632970332,
                ["wasAltered"] = true,
                ["newestTime"] = 1633299791,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 165,
                        ["wasKiosk"] = true,
                        ["seller"] = 166,
                        ["timestamp"] = 1632970332,
                        ["quant"] = 7,
                        ["id"] = "1690059835",
                        ["itemLink"] = 179,
                    },
                    [2] = 
                    {
                        ["price"] = 35,
                        ["guild"] = 1,
                        ["buyer"] = 2041,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633299791,
                        ["quant"] = 1,
                        ["id"] = "1692738795",
                        ["itemLink"] = 179,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [118193] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bre_inc_elixir001.dds",
                ["itemDesc"] = "Bottle, Elixir",
                ["oldestTime"] = 1632962526,
                ["wasAltered"] = true,
                ["newestTime"] = 1632962526,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 14500,
                        ["guild"] = 1,
                        ["buyer"] = 2642,
                        ["wasKiosk"] = true,
                        ["seller"] = 312,
                        ["timestamp"] = 1632962526,
                        ["quant"] = 1,
                        ["id"] = "1689980741",
                        ["itemLink"] = 3934,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings hearth",
            },
        },
        [171735] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Imperial Champion Shield",
                ["oldestTime"] = 1632953412,
                ["wasAltered"] = true,
                ["newestTime"] = 1632953419,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 2603,
                        ["wasKiosk"] = true,
                        ["seller"] = 201,
                        ["timestamp"] = 1632953412,
                        ["quant"] = 1,
                        ["id"] = "1689904883",
                        ["itemLink"] = 3856,
                    },
                    [2] = 
                    {
                        ["price"] = 333,
                        ["guild"] = 1,
                        ["buyer"] = 2603,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1632953419,
                        ["quant"] = 1,
                        ["id"] = "1689905063",
                        ["itemLink"] = 3856,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [166000] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_skr_nicotiana005.dds",
                ["itemDesc"] = "Flower Patch, Hawkmoth Cabbage",
                ["oldestTime"] = 1632872222,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238236,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 18000,
                        ["guild"] = 1,
                        ["buyer"] = 1745,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633238236,
                        ["quant"] = 2,
                        ["id"] = "1692187115",
                        ["itemLink"] = 2510,
                    },
                    [2] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 2299,
                        ["wasKiosk"] = true,
                        ["seller"] = 225,
                        ["timestamp"] = 1632872222,
                        ["quant"] = 2,
                        ["id"] = "1689316955",
                        ["itemLink"] = 2510,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior furnishings conservatory",
            },
        },
        [43633] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Grahtwood Treasure Map III",
                ["oldestTime"] = 1632999555,
                ["wasAltered"] = true,
                ["newestTime"] = 1633202870,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 640,
                        ["guild"] = 1,
                        ["buyer"] = 392,
                        ["wasKiosk"] = true,
                        ["seller"] = 175,
                        ["timestamp"] = 1632999555,
                        ["quant"] = 1,
                        ["id"] = "1690231045",
                        ["itemLink"] = 393,
                    },
                    [2] = 
                    {
                        ["price"] = 459,
                        ["guild"] = 1,
                        ["buyer"] = 1504,
                        ["wasKiosk"] = true,
                        ["seller"] = 164,
                        ["timestamp"] = 1633202870,
                        ["quant"] = 1,
                        ["id"] = "1691820741",
                        ["itemLink"] = 393,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [180850] = 
        {
            ["50:16:3:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_2haxe_a.dds",
                ["itemDesc"] = "Hrothgar's Battle Axe",
                ["oldestTime"] = 1633112463,
                ["wasAltered"] = true,
                ["newestTime"] = 1633112463,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 991,
                        ["wasKiosk"] = true,
                        ["seller"] = 761,
                        ["timestamp"] = 1633112463,
                        ["quant"] = 1,
                        ["id"] = "1691055395",
                        ["itemLink"] = 1353,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set hrothgar's chill axe two-handed sharpened",
            },
        },
        [95347] = 
        {
            ["50:16:2:13:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_heavy_hands_a.dds",
                ["itemDesc"] = "Gauntlets of the Fire",
                ["oldestTime"] = 1632950133,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950133,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1632950133,
                        ["quant"] = 1,
                        ["id"] = "1689875267",
                        ["itemLink"] = 3826,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine heavy apparel set way of fire hands reinforced",
            },
        },
        [149282] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_pellitine_light_shoulder_a.dds",
                ["itemDesc"] = "Crafty Alfiq's Epaulets",
                ["oldestTime"] = 1632951030,
                ["wasAltered"] = true,
                ["newestTime"] = 1632951030,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2160,
                        ["guild"] = 1,
                        ["buyer"] = 631,
                        ["wasKiosk"] = true,
                        ["seller"] = 600,
                        ["timestamp"] = 1632951030,
                        ["quant"] = 1,
                        ["id"] = "1689881929",
                        ["itemLink"] = 3842,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel set crafty alfiq shoulders divines",
            },
        },
        [68213] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Markarth Mead",
                ["oldestTime"] = 1632989955,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261637,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20,
                        ["guild"] = 1,
                        ["buyer"] = 345,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1632989955,
                        ["quant"] = 1,
                        ["id"] = "1690186947",
                        ["itemLink"] = 346,
                    },
                    [2] = 
                    {
                        ["price"] = 20,
                        ["guild"] = 1,
                        ["buyer"] = 184,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633244974,
                        ["quant"] = 1,
                        ["id"] = "1692233587",
                        ["itemLink"] = 346,
                    },
                    [3] = 
                    {
                        ["price"] = 35,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 399,
                        ["timestamp"] = 1633261637,
                        ["quant"] = 1,
                        ["id"] = "1692334593",
                        ["itemLink"] = 346,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [92278] = 
        {
            ["50:16:2:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_staff_d.dds",
                ["itemDesc"] = "Restoration Staff of the Twin Sisters",
                ["oldestTime"] = 1633292077,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292077,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 51,
                        ["timestamp"] = 1633292077,
                        ["quant"] = 1,
                        ["id"] = "1692652531",
                        ["itemLink"] = 2810,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set twin sisters healing staff two-handed infused",
            },
        },
        [45839] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_runestones_017.dds",
                ["itemDesc"] = "Dekeipa",
                ["oldestTime"] = 1632950326,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950326,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 36000,
                        ["guild"] = 1,
                        ["buyer"] = 2572,
                        ["wasKiosk"] = true,
                        ["seller"] = 171,
                        ["timestamp"] = 1632950326,
                        ["quant"] = 100,
                        ["id"] = "1689876773",
                        ["itemLink"] = 3838,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials essence runestone",
            },
        },
        [180600] = 
        {
            ["50:16:3:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Plaguebreak Ring",
                ["oldestTime"] = 1632958760,
                ["wasAltered"] = true,
                ["newestTime"] = 1633315786,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 103,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1633315786,
                        ["quant"] = 1,
                        ["id"] = "1692912799",
                        ["itemLink"] = 75,
                    },
                    [2] = 
                    {
                        ["price"] = 7801,
                        ["guild"] = 1,
                        ["buyer"] = 760,
                        ["wasKiosk"] = true,
                        ["seller"] = 48,
                        ["timestamp"] = 1633267035,
                        ["quant"] = 1,
                        ["id"] = "1692375495",
                        ["itemLink"] = 2641,
                    },
                    [3] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 760,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1633267036,
                        ["quant"] = 1,
                        ["id"] = "1692375509",
                        ["itemLink"] = 2641,
                    },
                    [4] = 
                    {
                        ["price"] = 12684,
                        ["guild"] = 1,
                        ["buyer"] = 334,
                        ["wasKiosk"] = false,
                        ["seller"] = 408,
                        ["timestamp"] = 1632958760,
                        ["quant"] = 1,
                        ["id"] = "1689950341",
                        ["itemLink"] = 2641,
                    },
                    [5] = 
                    {
                        ["price"] = 13999,
                        ["guild"] = 1,
                        ["buyer"] = 334,
                        ["wasKiosk"] = false,
                        ["seller"] = 451,
                        ["timestamp"] = 1632958767,
                        ["quant"] = 1,
                        ["id"] = "1689950393",
                        ["itemLink"] = 2641,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set plaguebreak ring robust",
            },
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Plaguebreak Ring",
                ["oldestTime"] = 1633059515,
                ["wasAltered"] = true,
                ["newestTime"] = 1633301963,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15555,
                        ["guild"] = 1,
                        ["buyer"] = 781,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633059515,
                        ["quant"] = 1,
                        ["id"] = "1690705783",
                        ["itemLink"] = 1004,
                    },
                    [2] = 
                    {
                        ["price"] = 15555,
                        ["guild"] = 1,
                        ["buyer"] = 450,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633088149,
                        ["quant"] = 1,
                        ["id"] = "1690876879",
                        ["itemLink"] = 1004,
                    },
                    [3] = 
                    {
                        ["price"] = 35000,
                        ["guild"] = 1,
                        ["buyer"] = 2050,
                        ["wasKiosk"] = true,
                        ["seller"] = 47,
                        ["timestamp"] = 1633301963,
                        ["quant"] = 1,
                        ["id"] = "1692761477",
                        ["itemLink"] = 2918,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set plaguebreak ring robust",
            },
        },
        [129657] = 
        {
            ["50:16:2:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_bow_a.dds",
                ["itemDesc"] = "Bow of the Pariah",
                ["oldestTime"] = 1633228146,
                ["wasAltered"] = true,
                ["newestTime"] = 1633228146,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 940,
                        ["wasKiosk"] = true,
                        ["seller"] = 474,
                        ["timestamp"] = 1633228146,
                        ["quant"] = 1,
                        ["id"] = "1692098499",
                        ["itemLink"] = 2422,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon set mark of the pariah bow two-handed sharpened",
            },
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_bow_a.dds",
                ["itemDesc"] = "Bow of the Pariah",
                ["oldestTime"] = 1632888699,
                ["wasAltered"] = true,
                ["newestTime"] = 1632888699,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2406,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632888699,
                        ["quant"] = 1,
                        ["id"] = "1689484615",
                        ["itemLink"] = 3529,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set mark of the pariah bow two-handed sharpened",
            },
        },
        [45337] = 
        {
            ["50:16:1:10:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_2hhammer_d.dds",
                ["itemDesc"] = "Rubedite Maul",
                ["oldestTime"] = 1632950120,
                ["wasAltered"] = true,
                ["newestTime"] = 1632950120,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 582,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1632950120,
                        ["quant"] = 1,
                        ["id"] = "1689875115",
                        ["itemLink"] = 3816,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal weapon mace two-handed ornate",
            },
        },
        [139591] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Alinor Table, Decorative Marble",
                ["oldestTime"] = 1632943447,
                ["wasAltered"] = true,
                ["newestTime"] = 1632943447,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 40000,
                        ["guild"] = 1,
                        ["buyer"] = 2557,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632943447,
                        ["quant"] = 1,
                        ["id"] = "1689821439",
                        ["itemLink"] = 3780,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [68472] = 
        {
            ["50:16:2:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_snowreach_medium_head_a.dds",
                ["itemDesc"] = "Briarheart Helmet",
                ["oldestTime"] = 1632936839,
                ["wasAltered"] = true,
                ["newestTime"] = 1632936839,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 226,
                        ["wasKiosk"] = false,
                        ["seller"] = 532,
                        ["timestamp"] = 1632936839,
                        ["quant"] = 1,
                        ["id"] = "1689774047",
                        ["itemLink"] = 3747,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set briarheart head well-fitted",
            },
        },
        [144253] = 
        {
            ["50:16:3:15:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_aldmeri_shield_a.dds",
                ["itemDesc"] = "Spell Strategist Shield",
                ["oldestTime"] = 1633291955,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291955,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 445,
                        ["wasKiosk"] = false,
                        ["seller"] = 257,
                        ["timestamp"] = 1633291955,
                        ["quant"] = 1,
                        ["id"] = "1692651313",
                        ["itemLink"] = 2803,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior apparel weapon set spell strategist shield off hand training",
            },
        },
        [121214] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning5.dds",
                ["itemDesc"] = "Design: Orcish Skull Goblet, Full",
                ["oldestTime"] = 1633205039,
                ["wasAltered"] = true,
                ["newestTime"] = 1633205039,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 75800,
                        ["guild"] = 1,
                        ["buyer"] = 1520,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633205039,
                        ["quant"] = 1,
                        ["id"] = "1691842895",
                        ["itemLink"] = 2245,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable recipe",
            },
        },
        [126989] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Telvanni Table, Organic Game",
                ["oldestTime"] = 1632881482,
                ["wasAltered"] = true,
                ["newestTime"] = 1632881482,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 99999,
                        ["guild"] = 1,
                        ["buyer"] = 2360,
                        ["wasKiosk"] = true,
                        ["seller"] = 951,
                        ["timestamp"] = 1632881482,
                        ["quant"] = 1,
                        ["id"] = "1689411437",
                        ["itemLink"] = 3467,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [176000] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting3.dds",
                ["itemDesc"] = "Praxis: Leyawiin Potted Plant, Aspen Sapling",
                ["oldestTime"] = 1633041362,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292243,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 634,
                        ["wasKiosk"] = true,
                        ["seller"] = 406,
                        ["timestamp"] = 1633041362,
                        ["quant"] = 1,
                        ["id"] = "1690523491",
                        ["itemLink"] = 804,
                    },
                    [2] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1448,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633195541,
                        ["quant"] = 1,
                        ["id"] = "1691746913",
                        ["itemLink"] = 804,
                    },
                    [3] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633292243,
                        ["quant"] = 1,
                        ["id"] = "1692654267",
                        ["itemLink"] = 804,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [167305] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/container_sealed_polymorph_001.dds",
                ["itemDesc"] = "Runebox: Timbercrow Wanderer Costume",
                ["oldestTime"] = 1632934994,
                ["wasAltered"] = true,
                ["newestTime"] = 1632934994,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1090000,
                        ["guild"] = 1,
                        ["buyer"] = 2525,
                        ["wasKiosk"] = true,
                        ["seller"] = 550,
                        ["timestamp"] = 1632934994,
                        ["quant"] = 1,
                        ["id"] = "1689760521",
                        ["itemLink"] = 3725,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable container",
            },
        },
        [161435] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_heavy_waist_d.dds",
                ["itemDesc"] = "Stuhn's Girdle",
                ["oldestTime"] = 1632930947,
                ["wasAltered"] = true,
                ["newestTime"] = 1632930947,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 2517,
                        ["wasKiosk"] = true,
                        ["seller"] = 819,
                        ["timestamp"] = 1632930947,
                        ["quant"] = 1,
                        ["id"] = "1689728915",
                        ["itemLink"] = 3711,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set stuhn's favor waist impenetrable",
            },
        },
        [151697] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_fur_housinglowbookcase001.dds",
                ["itemDesc"] = "Elsweyr Bookshelf, Wooden Full",
                ["oldestTime"] = 1632880477,
                ["wasAltered"] = true,
                ["newestTime"] = 1632880477,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 2354,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1632880477,
                        ["quant"] = 1,
                        ["id"] = "1689401945",
                        ["itemLink"] = 3462,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings library",
            },
        },
        [57580] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 15: Dwemer Helmets",
                ["oldestTime"] = 1632929238,
                ["wasAltered"] = true,
                ["newestTime"] = 1632929238,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2510,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632929238,
                        ["quant"] = 1,
                        ["id"] = "1689715827",
                        ["itemLink"] = 3693,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [116101] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Khajiit Bookshelf, Arched",
                ["oldestTime"] = 1633058508,
                ["wasAltered"] = true,
                ["newestTime"] = 1633058508,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 776,
                        ["wasKiosk"] = true,
                        ["seller"] = 100,
                        ["timestamp"] = 1633058508,
                        ["quant"] = 1,
                        ["id"] = "1690695311",
                        ["itemLink"] = 987,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [180445] = 
        {
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ebonheart_light_head_a.dds",
                ["itemDesc"] = "Hat of Dark Convergence",
                ["oldestTime"] = 1632961321,
                ["wasAltered"] = true,
                ["newestTime"] = 1633242758,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1276,
                        ["wasKiosk"] = true,
                        ["seller"] = 42,
                        ["timestamp"] = 1633242758,
                        ["quant"] = 1,
                        ["id"] = "1692216307",
                        ["itemLink"] = 2553,
                    },
                    [2] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 2628,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1632961321,
                        ["quant"] = 1,
                        ["id"] = "1689970331",
                        ["itemLink"] = 2553,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 purple epic light apparel set dark convergence head infused",
            },
        },
        [95367] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_yokudan_heavy_hands_a.dds",
                ["itemDesc"] = "Gauntlets of the Fire",
                ["oldestTime"] = 1633203206,
                ["wasAltered"] = true,
                ["newestTime"] = 1633203206,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1200,
                        ["guild"] = 1,
                        ["buyer"] = 1507,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633203206,
                        ["quant"] = 1,
                        ["id"] = "1691824983",
                        ["itemLink"] = 2227,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set way of fire hands impenetrable",
            },
        },
        [68251] = 
        {
            ["50:15:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_cooking_open_top_pie.dds",
                ["itemDesc"] = "Capon Tomato-Beet Casserole",
                ["oldestTime"] = 1632920846,
                ["wasAltered"] = true,
                ["newestTime"] = 1632920846,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 2485,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1632920846,
                        ["quant"] = 100,
                        ["id"] = "1689656917",
                        ["itemLink"] = 3651,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 purple epic consumable food",
            },
        },
        [171913] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 102: Sul-Xan Axes",
                ["oldestTime"] = 1633008422,
                ["wasAltered"] = true,
                ["newestTime"] = 1633008422,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100000,
                        ["guild"] = 1,
                        ["buyer"] = 437,
                        ["wasKiosk"] = true,
                        ["seller"] = 153,
                        ["timestamp"] = 1633008422,
                        ["quant"] = 1,
                        ["id"] = "1690279325",
                        ["itemLink"] = 445,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [43658] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Stonefalls Treasure Map IV",
                ["oldestTime"] = 1632825709,
                ["wasAltered"] = true,
                ["newestTime"] = 1632825709,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2117,
                        ["wasKiosk"] = true,
                        ["seller"] = 86,
                        ["timestamp"] = 1632825709,
                        ["quant"] = 1,
                        ["id"] = "1688967769",
                        ["itemLink"] = 3024,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [57014] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Sweetroll",
                ["oldestTime"] = 1632913065,
                ["wasAltered"] = true,
                ["newestTime"] = 1632913065,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 2471,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632913065,
                        ["quant"] = 1,
                        ["id"] = "1689612519",
                        ["itemLink"] = 3627,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [43660] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Stonefalls Treasure Map VI",
                ["oldestTime"] = 1633182512,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310218,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 359,
                        ["guild"] = 1,
                        ["buyer"] = 389,
                        ["wasKiosk"] = false,
                        ["seller"] = 164,
                        ["timestamp"] = 1633182512,
                        ["quant"] = 1,
                        ["id"] = "1691608125",
                        ["itemLink"] = 1951,
                    },
                    [2] = 
                    {
                        ["price"] = 404,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 246,
                        ["timestamp"] = 1633310218,
                        ["quant"] = 1,
                        ["id"] = "1692851195",
                        ["itemLink"] = 1951,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [117805] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_inc_rugrunner001.dds",
                ["itemDesc"] = "Redguard Runner, Oasis",
                ["oldestTime"] = 1632977239,
                ["wasAltered"] = true,
                ["newestTime"] = 1632977239,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10328,
                        ["guild"] = 1,
                        ["buyer"] = 235,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1632977239,
                        ["quant"] = 1,
                        ["id"] = "1690112671",
                        ["itemLink"] = 241,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings parlor",
            },
        },
        [68494] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_snowreach_medium_head_a.dds",
                ["itemDesc"] = "Briarheart Helmet",
                ["oldestTime"] = 1632901974,
                ["wasAltered"] = true,
                ["newestTime"] = 1632901974,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1290,
                        ["wasKiosk"] = true,
                        ["seller"] = 1689,
                        ["timestamp"] = 1632901974,
                        ["quant"] = 1,
                        ["id"] = "1689568711",
                        ["itemLink"] = 3577,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel set briarheart head divines",
            },
        },
        [87695] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/event_halloween_2016_skull_cup_eyeballs.dds",
                ["itemDesc"] = "Ghastly Eye Bowl",
                ["oldestTime"] = 1632822920,
                ["wasAltered"] = true,
                ["newestTime"] = 1633293101,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9499,
                        ["guild"] = 1,
                        ["buyer"] = 180,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632971216,
                        ["quant"] = 100,
                        ["id"] = "1690068097",
                        ["itemLink"] = 194,
                    },
                    [2] = 
                    {
                        ["price"] = 9499,
                        ["guild"] = 1,
                        ["buyer"] = 265,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632981372,
                        ["quant"] = 100,
                        ["id"] = "1690138523",
                        ["itemLink"] = 194,
                    },
                    [3] = 
                    {
                        ["price"] = 9499,
                        ["guild"] = 1,
                        ["buyer"] = 265,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632981373,
                        ["quant"] = 100,
                        ["id"] = "1690138527",
                        ["itemLink"] = 194,
                    },
                    [4] = 
                    {
                        ["price"] = 11000,
                        ["guild"] = 1,
                        ["buyer"] = 337,
                        ["wasKiosk"] = true,
                        ["seller"] = 226,
                        ["timestamp"] = 1632988466,
                        ["quant"] = 100,
                        ["id"] = "1690177891",
                        ["itemLink"] = 194,
                    },
                    [5] = 
                    {
                        ["price"] = 9499,
                        ["guild"] = 1,
                        ["buyer"] = 658,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633043498,
                        ["quant"] = 100,
                        ["id"] = "1690541595",
                        ["itemLink"] = 194,
                    },
                    [6] = 
                    {
                        ["price"] = 9499,
                        ["guild"] = 1,
                        ["buyer"] = 386,
                        ["wasKiosk"] = false,
                        ["seller"] = 34,
                        ["timestamp"] = 1633085534,
                        ["quant"] = 100,
                        ["id"] = "1690861033",
                        ["itemLink"] = 194,
                    },
                    [7] = 
                    {
                        ["price"] = 9499,
                        ["guild"] = 1,
                        ["buyer"] = 458,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633095104,
                        ["quant"] = 100,
                        ["id"] = "1690919623",
                        ["itemLink"] = 194,
                    },
                    [8] = 
                    {
                        ["price"] = 9499,
                        ["guild"] = 1,
                        ["buyer"] = 858,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633187133,
                        ["quant"] = 100,
                        ["id"] = "1691653437",
                        ["itemLink"] = 194,
                    },
                    [9] = 
                    {
                        ["price"] = 9499,
                        ["guild"] = 1,
                        ["buyer"] = 1740,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633236824,
                        ["quant"] = 100,
                        ["id"] = "1692174451",
                        ["itemLink"] = 194,
                    },
                    [10] = 
                    {
                        ["price"] = 9499,
                        ["guild"] = 1,
                        ["buyer"] = 1909,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633277189,
                        ["quant"] = 100,
                        ["id"] = "1692488111",
                        ["itemLink"] = 194,
                    },
                    [11] = 
                    {
                        ["price"] = 9499,
                        ["guild"] = 1,
                        ["buyer"] = 1997,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633293099,
                        ["quant"] = 100,
                        ["id"] = "1692664267",
                        ["itemLink"] = 194,
                    },
                    [12] = 
                    {
                        ["price"] = 9499,
                        ["guild"] = 1,
                        ["buyer"] = 1997,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633293101,
                        ["quant"] = 100,
                        ["id"] = "1692664297",
                        ["itemLink"] = 194,
                    },
                    [13] = 
                    {
                        ["price"] = 9499,
                        ["guild"] = 1,
                        ["buyer"] = 2109,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632822920,
                        ["quant"] = 100,
                        ["id"] = "1688954997",
                        ["itemLink"] = 194,
                    },
                    [14] = 
                    {
                        ["price"] = 9499,
                        ["guild"] = 1,
                        ["buyer"] = 2150,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632834762,
                        ["quant"] = 100,
                        ["id"] = "1689025479",
                        ["itemLink"] = 194,
                    },
                    [15] = 
                    {
                        ["price"] = 9499,
                        ["guild"] = 1,
                        ["buyer"] = 1526,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632868378,
                        ["quant"] = 100,
                        ["id"] = "1689290667",
                        ["itemLink"] = 194,
                    },
                    [16] = 
                    {
                        ["price"] = 9499,
                        ["guild"] = 1,
                        ["buyer"] = 1526,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632868380,
                        ["quant"] = 100,
                        ["id"] = "1689290683",
                        ["itemLink"] = 194,
                    },
                    [17] = 
                    {
                        ["price"] = 9300,
                        ["guild"] = 1,
                        ["buyer"] = 1482,
                        ["wasKiosk"] = true,
                        ["seller"] = 65,
                        ["timestamp"] = 1632877345,
                        ["quant"] = 100,
                        ["id"] = "1689365189",
                        ["itemLink"] = 194,
                    },
                    [18] = 
                    {
                        ["price"] = 9499,
                        ["guild"] = 1,
                        ["buyer"] = 2429,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632895085,
                        ["quant"] = 100,
                        ["id"] = "1689530009",
                        ["itemLink"] = 194,
                    },
                    [19] = 
                    {
                        ["price"] = 9499,
                        ["guild"] = 1,
                        ["buyer"] = 2613,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1632956104,
                        ["quant"] = 100,
                        ["id"] = "1689928447",
                        ["itemLink"] = 194,
                    },
                },
                ["totalCount"] = 19,
                ["itemAdderText"] = "rr01 blue superior consumable drink",
            },
        },
        [85113] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_altmer_shield_d.dds",
                ["itemDesc"] = "Shield of Syrabane",
                ["oldestTime"] = 1632912385,
                ["wasAltered"] = true,
                ["newestTime"] = 1632912385,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 675,
                        ["guild"] = 1,
                        ["buyer"] = 2467,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1632912385,
                        ["quant"] = 1,
                        ["id"] = "1689610045",
                        ["itemLink"] = 3619,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine apparel weapon set syrabane's grip shield off hand divines",
            },
        },
        [43665] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Deshaan Treasure Map V",
                ["oldestTime"] = 1632854200,
                ["wasAltered"] = true,
                ["newestTime"] = 1632854200,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 733,
                        ["wasKiosk"] = true,
                        ["seller"] = 86,
                        ["timestamp"] = 1632854200,
                        ["quant"] = 1,
                        ["id"] = "1689177661",
                        ["itemLink"] = 3261,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [51602] = 
        {
            ["50:16:5:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_bow_d.dds",
                ["itemDesc"] = "Bow of Hunding's Rage",
                ["oldestTime"] = 1632872924,
                ["wasAltered"] = true,
                ["newestTime"] = 1632872924,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 79999,
                        ["guild"] = 1,
                        ["buyer"] = 2286,
                        ["wasKiosk"] = true,
                        ["seller"] = 220,
                        ["timestamp"] = 1632872924,
                        ["quant"] = 1,
                        ["id"] = "1689322691",
                        ["itemLink"] = 3397,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary weapon set hunding's rage bow two-handed infused",
            },
        },
        [151699] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_fur_housingmedbookcase001.dds",
                ["itemDesc"] = "Elsweyr Bookshelf, Elegant Wooden Full",
                ["oldestTime"] = 1633040021,
                ["wasAltered"] = true,
                ["newestTime"] = 1633040021,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 621,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633040021,
                        ["quant"] = 1,
                        ["id"] = "1690513271",
                        ["itemLink"] = 786,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings library",
            },
        },
        [129684] = 
        {
            ["50:16:3:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_malacath_staff_a.dds",
                ["itemDesc"] = "Lightning Staff of the Pariah",
                ["oldestTime"] = 1633278431,
                ["wasAltered"] = true,
                ["newestTime"] = 1633278431,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1450,
                        ["guild"] = 1,
                        ["buyer"] = 1902,
                        ["wasKiosk"] = true,
                        ["seller"] = 360,
                        ["timestamp"] = 1633278431,
                        ["quant"] = 1,
                        ["id"] = "1692499857",
                        ["itemLink"] = 2721,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set mark of the pariah lightning staff two-handed training",
            },
        },
        [46129] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_ingot_moonstone.dds",
                ["itemDesc"] = "Quicksilver Ingot",
                ["oldestTime"] = 1632883780,
                ["wasAltered"] = true,
                ["newestTime"] = 1632883780,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 2374,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1632883780,
                        ["quant"] = 200,
                        ["id"] = "1689436329",
                        ["itemLink"] = 3492,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [101014] = 
        {
            ["50:16:4:14:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_light_shoulders_d.dds",
                ["itemDesc"] = "Smuggler's Epaulets",
                ["oldestTime"] = 1632936828,
                ["wasAltered"] = true,
                ["newestTime"] = 1632936828,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 226,
                        ["wasKiosk"] = false,
                        ["seller"] = 655,
                        ["timestamp"] = 1632936828,
                        ["quant"] = 1,
                        ["id"] = "1689774007",
                        ["itemLink"] = 3744,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set skooma smuggler shoulders well-fitted",
            },
        },
        [161431] = 
        {
            ["50:16:4:12:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_heavy_hands_d.dds",
                ["itemDesc"] = "Stuhn's Gauntlets",
                ["oldestTime"] = 1632930927,
                ["wasAltered"] = true,
                ["newestTime"] = 1632930927,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 2517,
                        ["wasKiosk"] = true,
                        ["seller"] = 819,
                        ["timestamp"] = 1632930927,
                        ["quant"] = 1,
                        ["id"] = "1689728793",
                        ["itemLink"] = 3710,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel set stuhn's favor hands impenetrable",
            },
        },
        [151690] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_fur_throne001.dds",
                ["itemDesc"] = "Elsweyr Throne, Elegant Wooden",
                ["oldestTime"] = 1632880468,
                ["wasAltered"] = true,
                ["newestTime"] = 1632880468,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22000,
                        ["guild"] = 1,
                        ["buyer"] = 2354,
                        ["wasKiosk"] = true,
                        ["seller"] = 73,
                        ["timestamp"] = 1632880468,
                        ["quant"] = 1,
                        ["id"] = "1689401891",
                        ["itemLink"] = 3461,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [71577] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 23: Malacath Shields",
                ["oldestTime"] = 1633287306,
                ["wasAltered"] = true,
                ["newestTime"] = 1633287306,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 1963,
                        ["wasKiosk"] = true,
                        ["seller"] = 722,
                        ["timestamp"] = 1633287306,
                        ["quant"] = 1,
                        ["id"] = "1692596049",
                        ["itemLink"] = 2763,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [44698] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_book_001.dds",
                ["itemDesc"] = "Crafting Motif 7: Khajiit Style",
                ["oldestTime"] = 1632820717,
                ["wasAltered"] = true,
                ["newestTime"] = 1633017934,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 272,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632981450,
                        ["quant"] = 1,
                        ["id"] = "1690138829",
                        ["itemLink"] = 283,
                    },
                    [2] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 484,
                        ["wasKiosk"] = true,
                        ["seller"] = 493,
                        ["timestamp"] = 1633017934,
                        ["quant"] = 1,
                        ["id"] = "1690349017",
                        ["itemLink"] = 283,
                    },
                    [3] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 2103,
                        ["wasKiosk"] = true,
                        ["seller"] = 104,
                        ["timestamp"] = 1632820717,
                        ["quant"] = 1,
                        ["id"] = "1688947269",
                        ["itemLink"] = 283,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior consumable motif",
            },
        },
        [99739] = 
        {
            ["50:16:4:7:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_dagger_d.dds",
                ["itemDesc"] = "Spinner's Dagger",
                ["oldestTime"] = 1632977495,
                ["wasAltered"] = true,
                ["newestTime"] = 1632977495,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 48000,
                        ["guild"] = 1,
                        ["buyer"] = 239,
                        ["wasKiosk"] = true,
                        ["seller"] = 240,
                        ["timestamp"] = 1632977495,
                        ["quant"] = 1,
                        ["id"] = "1690114479",
                        ["itemLink"] = 245,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set spinner's garments dagger one-handed sharpened",
            },
        },
        [118189] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bre_con_baskettall002.dds",
                ["itemDesc"] = "Basket of Gourds",
                ["oldestTime"] = 1632879732,
                ["wasAltered"] = true,
                ["newestTime"] = 1632879732,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 2349,
                        ["wasKiosk"] = true,
                        ["seller"] = 17,
                        ["timestamp"] = 1632879732,
                        ["quant"] = 1,
                        ["id"] = "1689394053",
                        ["itemLink"] = 3446,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings hearth",
            },
        },
        [45981] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Mazte",
                ["oldestTime"] = 1632896551,
                ["wasAltered"] = true,
                ["newestTime"] = 1632896551,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 2,
                        ["buyer"] = 133,
                        ["wasKiosk"] = false,
                        ["seller"] = 128,
                        ["timestamp"] = 1632896551,
                        ["quant"] = 1,
                        ["id"] = "1689539613",
                        ["itemLink"] = 143,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [45214] = 
        {
            ["50:16:2:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_light_waist_d.dds",
                ["itemDesc"] = "Ancestor Silk Sash of Stamina",
                ["oldestTime"] = 1632847689,
                ["wasAltered"] = true,
                ["newestTime"] = 1633135264,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 96,
                        ["guild"] = 1,
                        ["buyer"] = 983,
                        ["wasKiosk"] = true,
                        ["seller"] = 7,
                        ["timestamp"] = 1633135264,
                        ["quant"] = 1,
                        ["id"] = "1691245117",
                        ["itemLink"] = 1557,
                    },
                    [2] = 
                    {
                        ["price"] = 143,
                        ["guild"] = 1,
                        ["buyer"] = 2203,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1632847689,
                        ["quant"] = 1,
                        ["id"] = "1689125531",
                        ["itemLink"] = 3211,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp160 green fine light apparel waist infused",
            },
        },
        [45215] = 
        {
            ["50:16:2:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_bow_d.dds",
                ["itemDesc"] = "Ruby Ash Bow of Shock",
                ["oldestTime"] = 1632826459,
                ["wasAltered"] = true,
                ["newestTime"] = 1632826459,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 199,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1632826459,
                        ["quant"] = 1,
                        ["id"] = "1688971651",
                        ["itemLink"] = 3037,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon bow two-handed training",
            },
        },
        [156618] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 81: New Moon Priest Maces",
                ["oldestTime"] = 1632879073,
                ["wasAltered"] = true,
                ["newestTime"] = 1632879073,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1250,
                        ["guild"] = 1,
                        ["buyer"] = 1208,
                        ["wasKiosk"] = true,
                        ["seller"] = 374,
                        ["timestamp"] = 1632879073,
                        ["quant"] = 1,
                        ["id"] = "1689385123",
                        ["itemLink"] = 3441,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [139612] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_jewelry_2.dds",
                ["itemDesc"] = "Sketch: Alinor Goblet, Silver Plain",
                ["oldestTime"] = 1632865565,
                ["wasAltered"] = true,
                ["newestTime"] = 1632958391,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2194,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632865565,
                        ["quant"] = 1,
                        ["id"] = "1689269111",
                        ["itemLink"] = 3355,
                    },
                    [2] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1472,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632958391,
                        ["quant"] = 1,
                        ["id"] = "1689946717",
                        ["itemLink"] = 3355,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [171597] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Style Page: Stonekeeper Shoulder",
                ["oldestTime"] = 1633292482,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292482,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 725000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1633292482,
                        ["quant"] = 1,
                        ["id"] = "1692657201",
                        ["itemLink"] = 2837,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [27043] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_honeycomb_001.dds",
                ["itemDesc"] = "Honey",
                ["oldestTime"] = 1632958021,
                ["wasAltered"] = true,
                ["newestTime"] = 1633093793,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 923,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633093793,
                        ["quant"] = 200,
                        ["id"] = "1690912899",
                        ["itemLink"] = 1247,
                    },
                    [2] = 
                    {
                        ["price"] = 2913,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 243,
                        ["timestamp"] = 1632958021,
                        ["quant"] = 200,
                        ["id"] = "1689943867",
                        ["itemLink"] = 1247,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [139568] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Alinor Jewelry Box, Polished",
                ["oldestTime"] = 1632865536,
                ["wasAltered"] = true,
                ["newestTime"] = 1632960925,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632865536,
                        ["quant"] = 1,
                        ["id"] = "1689268883",
                        ["itemLink"] = 3345,
                    },
                    [2] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 2471,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632960925,
                        ["quant"] = 1,
                        ["id"] = "1689967715",
                        ["itemLink"] = 3345,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [139570] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Alinor Jewelry Box, Octagonal",
                ["oldestTime"] = 1632865531,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865531,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1632865531,
                        ["quant"] = 1,
                        ["id"] = "1689268861",
                        ["itemLink"] = 3341,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [126374] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_vrd_inc_hlaurn002.dds",
                ["itemDesc"] = "Hlaalu Jar, Garden Moss",
                ["oldestTime"] = 1633165815,
                ["wasAltered"] = true,
                ["newestTime"] = 1633165815,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1322,
                        ["wasKiosk"] = true,
                        ["seller"] = 323,
                        ["timestamp"] = 1633165815,
                        ["quant"] = 1,
                        ["id"] = "1691499671",
                        ["itemLink"] = 1842,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings hearth",
            },
        },
        [45058] = 
        {
            ["50:16:3:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_2hsword_d.dds",
                ["itemDesc"] = "Rubedite Greatsword of Shock",
                ["oldestTime"] = 1632856315,
                ["wasAltered"] = true,
                ["newestTime"] = 1632856315,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 399,
                        ["guild"] = 1,
                        ["buyer"] = 656,
                        ["wasKiosk"] = true,
                        ["seller"] = 142,
                        ["timestamp"] = 1632856315,
                        ["quant"] = 1,
                        ["id"] = "1689200581",
                        ["itemLink"] = 3270,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon sword two-handed charged",
            },
            ["50:16:2:2:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redguard_2hsword_d.dds",
                ["itemDesc"] = "Rubedite Greatsword of Flame",
                ["oldestTime"] = 1632936805,
                ["wasAltered"] = true,
                ["newestTime"] = 1632936805,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 325,
                        ["guild"] = 1,
                        ["buyer"] = 226,
                        ["wasKiosk"] = false,
                        ["seller"] = 501,
                        ["timestamp"] = 1632936805,
                        ["quant"] = 1,
                        ["id"] = "1689773907",
                        ["itemLink"] = 3738,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon sword two-handed charged",
            },
        },
        [137930] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 62: Sapiarch Maces",
                ["oldestTime"] = 1632852085,
                ["wasAltered"] = true,
                ["newestTime"] = 1632929252,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6833,
                        ["guild"] = 1,
                        ["buyer"] = 545,
                        ["wasKiosk"] = true,
                        ["seller"] = 2186,
                        ["timestamp"] = 1632852085,
                        ["quant"] = 1,
                        ["id"] = "1689159881",
                        ["itemLink"] = 3246,
                    },
                    [2] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 2510,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1632929252,
                        ["quant"] = 1,
                        ["id"] = "1689715877",
                        ["itemLink"] = 3246,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [160937] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_greyhostmed_feet_a.dds",
                ["itemDesc"] = "Venomous Boots",
                ["oldestTime"] = 1633291852,
                ["wasAltered"] = true,
                ["newestTime"] = 1633291852,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 1965,
                        ["wasKiosk"] = true,
                        ["seller"] = 274,
                        ["timestamp"] = 1633291852,
                        ["quant"] = 1,
                        ["id"] = "1692650037",
                        ["itemLink"] = 2792,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior medium apparel set venomous smite feet invigorating",
            },
        },
        [160582] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 87: Ancestral Nord Daggers",
                ["oldestTime"] = 1632846173,
                ["wasAltered"] = true,
                ["newestTime"] = 1632846173,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4999,
                        ["guild"] = 1,
                        ["buyer"] = 2197,
                        ["wasKiosk"] = true,
                        ["seller"] = 163,
                        ["timestamp"] = 1632846173,
                        ["quant"] = 1,
                        ["id"] = "1689112147",
                        ["itemLink"] = 3196,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [118187] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bre_con_basketapples002.dds",
                ["itemDesc"] = "Basket of Apples, Full",
                ["oldestTime"] = 1632824896,
                ["wasAltered"] = true,
                ["newestTime"] = 1632824896,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 2114,
                        ["wasKiosk"] = true,
                        ["seller"] = 17,
                        ["timestamp"] = 1632824896,
                        ["quant"] = 1,
                        ["id"] = "1688963615",
                        ["itemLink"] = 3020,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior furnishings hearth",
            },
        },
        [167596] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Amulet of the Voidcaller",
                ["oldestTime"] = 1633163933,
                ["wasAltered"] = true,
                ["newestTime"] = 1633163933,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2990,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633163933,
                        ["quant"] = 1,
                        ["id"] = "1691490469",
                        ["itemLink"] = 1825,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set voidcaller neck arcane",
            },
        },
        [45997] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Lotus Tea",
                ["oldestTime"] = 1633052930,
                ["wasAltered"] = true,
                ["newestTime"] = 1633052930,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 717,
                        ["wasKiosk"] = true,
                        ["seller"] = 723,
                        ["timestamp"] = 1633052930,
                        ["quant"] = 1,
                        ["id"] = "1690634849",
                        ["itemLink"] = 925,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [172354] = 
        {
            ["50:16:3:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_dagger_a.dds",
                ["itemDesc"] = "Bog Raider's Dagger",
                ["oldestTime"] = 1632830327,
                ["wasAltered"] = true,
                ["newestTime"] = 1632830327,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2134,
                        ["wasKiosk"] = true,
                        ["seller"] = 353,
                        ["timestamp"] = 1632830327,
                        ["quant"] = 1,
                        ["id"] = "1689000395",
                        ["itemLink"] = 3075,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set bog raider dagger one-handed defending",
            },
        },
        [76880] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 34: Assassins League Belts",
                ["oldestTime"] = 1632823541,
                ["wasAltered"] = true,
                ["newestTime"] = 1632823541,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 2112,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632823541,
                        ["quant"] = 1,
                        ["id"] = "1688958789",
                        ["itemLink"] = 3017,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [137932] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 62: Sapiarch Shoulders",
                ["oldestTime"] = 1633219230,
                ["wasAltered"] = true,
                ["newestTime"] = 1633219230,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5800,
                        ["guild"] = 1,
                        ["buyer"] = 160,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633219230,
                        ["quant"] = 1,
                        ["id"] = "1692004845",
                        ["itemLink"] = 2339,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [43697] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Khenarthi's Roost Treasure Map III",
                ["oldestTime"] = 1633006763,
                ["wasAltered"] = true,
                ["newestTime"] = 1633006763,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 424,
                        ["wasKiosk"] = true,
                        ["seller"] = 285,
                        ["timestamp"] = 1633006763,
                        ["quant"] = 1,
                        ["id"] = "1690269609",
                        ["itemLink"] = 434,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [178450] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_bad_inc_leywoodpaintinglarge004.dds",
                ["itemDesc"] = "Harvest's Gifts Painting, Wood",
                ["oldestTime"] = 1633309593,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309593,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 37667,
                        ["guild"] = 1,
                        ["buyer"] = 2084,
                        ["wasKiosk"] = true,
                        ["seller"] = 152,
                        ["timestamp"] = 1633309593,
                        ["quant"] = 1,
                        ["id"] = "1692844715",
                        ["itemLink"] = 2972,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings gallery",
            },
        },
        [57586] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 15: Dwemer Swords",
                ["oldestTime"] = 1633309286,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309286,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3654,
                        ["guild"] = 1,
                        ["buyer"] = 2082,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1633309286,
                        ["quant"] = 1,
                        ["id"] = "1692840847",
                        ["itemLink"] = 2966,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [115892] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_provisioning4.dds",
                ["itemDesc"] = "Design: Wood Elf Bin, Blue Feathers",
                ["oldestTime"] = 1633130982,
                ["wasAltered"] = true,
                ["newestTime"] = 1633130982,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 42500,
                        ["guild"] = 1,
                        ["buyer"] = 1105,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1633130982,
                        ["quant"] = 1,
                        ["id"] = "1691196259",
                        ["itemLink"] = 1513,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [172431] = 
        {
            ["50:16:4:6:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_swamplegion_2haxe_a.dds",
                ["itemDesc"] = "Bog Raider's Battle Axe",
                ["oldestTime"] = 1633308596,
                ["wasAltered"] = true,
                ["newestTime"] = 1633308596,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 850,
                        ["guild"] = 1,
                        ["buyer"] = 2079,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1633308596,
                        ["quant"] = 1,
                        ["id"] = "1692830161",
                        ["itemLink"] = 2960,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set bog raider axe two-handed training",
            },
        },
        [51638] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_book_001.dds",
                ["itemDesc"] = "Crafting Motif 11: Ancient Elf Style",
                ["oldestTime"] = 1632849323,
                ["wasAltered"] = true,
                ["newestTime"] = 1633002666,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 411,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633002666,
                        ["quant"] = 1,
                        ["id"] = "1690247255",
                        ["itemLink"] = 418,
                    },
                    [2] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 2210,
                        ["wasKiosk"] = true,
                        ["seller"] = 51,
                        ["timestamp"] = 1632849323,
                        ["quant"] = 1,
                        ["id"] = "1689138411",
                        ["itemLink"] = 418,
                    },
                    [3] = 
                    {
                        ["price"] = 2100,
                        ["guild"] = 1,
                        ["buyer"] = 2273,
                        ["wasKiosk"] = true,
                        ["seller"] = 533,
                        ["timestamp"] = 1632867041,
                        ["quant"] = 1,
                        ["id"] = "1689281617",
                        ["itemLink"] = 418,
                    },
                    [4] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 2519,
                        ["wasKiosk"] = true,
                        ["seller"] = 435,
                        ["timestamp"] = 1632931444,
                        ["quant"] = 1,
                        ["id"] = "1689732097",
                        ["itemLink"] = 418,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [45996] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Jasmine Tea",
                ["oldestTime"] = 1633214828,
                ["wasAltered"] = true,
                ["newestTime"] = 1633214828,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 45,
                        ["guild"] = 1,
                        ["buyer"] = 1578,
                        ["wasKiosk"] = true,
                        ["seller"] = 222,
                        ["timestamp"] = 1633214828,
                        ["quant"] = 1,
                        ["id"] = "1691957403",
                        ["itemLink"] = 2305,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [121528] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_enchanting.dds",
                ["itemDesc"] = "Sealed Enchanting Writ",
                ["oldestTime"] = 1632837625,
                ["wasAltered"] = true,
                ["newestTime"] = 1633221137,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6995,
                        ["guild"] = 1,
                        ["buyer"] = 824,
                        ["wasKiosk"] = true,
                        ["seller"] = 211,
                        ["timestamp"] = 1633066311,
                        ["quant"] = 1,
                        ["id"] = "1690758237",
                        ["itemLink"] = 1067,
                    },
                    [2] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 20,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633105333,
                        ["quant"] = 1,
                        ["id"] = "1691004539",
                        ["itemLink"] = 1296,
                    },
                    [3] = 
                    {
                        ["price"] = 9000,
                        ["guild"] = 1,
                        ["buyer"] = 824,
                        ["wasKiosk"] = true,
                        ["seller"] = 216,
                        ["timestamp"] = 1633110944,
                        ["quant"] = 1,
                        ["id"] = "1691043161",
                        ["itemLink"] = 1325,
                    },
                    [4] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 709,
                        ["timestamp"] = 1633184375,
                        ["quant"] = 1,
                        ["id"] = "1691623917",
                        ["itemLink"] = 1973,
                    },
                    [5] = 
                    {
                        ["price"] = 4999,
                        ["guild"] = 1,
                        ["buyer"] = 173,
                        ["wasKiosk"] = false,
                        ["seller"] = 246,
                        ["timestamp"] = 1633184444,
                        ["quant"] = 1,
                        ["id"] = "1691624375",
                        ["itemLink"] = 1977,
                    },
                    [6] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 824,
                        ["wasKiosk"] = true,
                        ["seller"] = 155,
                        ["timestamp"] = 1633221137,
                        ["quant"] = 1,
                        ["id"] = "1692023179",
                        ["itemLink"] = 2351,
                    },
                    [7] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 2163,
                        ["wasKiosk"] = true,
                        ["seller"] = 205,
                        ["timestamp"] = 1632837625,
                        ["quant"] = 1,
                        ["id"] = "1689045799",
                        ["itemLink"] = 3113,
                    },
                    [8] = 
                    {
                        ["price"] = 32000,
                        ["guild"] = 1,
                        ["buyer"] = 2163,
                        ["wasKiosk"] = true,
                        ["seller"] = 205,
                        ["timestamp"] = 1632837627,
                        ["quant"] = 1,
                        ["id"] = "1689045803",
                        ["itemLink"] = 3114,
                    },
                    [9] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 2163,
                        ["wasKiosk"] = true,
                        ["seller"] = 533,
                        ["timestamp"] = 1632837628,
                        ["quant"] = 1,
                        ["id"] = "1689045807",
                        ["itemLink"] = 3115,
                    },
                },
                ["totalCount"] = 9,
                ["itemAdderText"] = "rr01 gold legendary consumable master writ",
            },
        },
        [43705] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Cyrodiil Treasure Map III",
                ["oldestTime"] = 1633148095,
                ["wasAltered"] = true,
                ["newestTime"] = 1633148095,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 682,
                        ["wasKiosk"] = true,
                        ["seller"] = 1236,
                        ["timestamp"] = 1633148095,
                        ["quant"] = 1,
                        ["id"] = "1691374555",
                        ["itemLink"] = 1691,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [117711] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_fur_chair001.dds",
                ["itemDesc"] = "Redguard Armchair, Cushioned",
                ["oldestTime"] = 1632879629,
                ["wasAltered"] = true,
                ["newestTime"] = 1633294733,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 16000,
                        ["guild"] = 1,
                        ["buyer"] = 2011,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633294733,
                        ["quant"] = 2,
                        ["id"] = "1692686905",
                        ["itemLink"] = 2870,
                    },
                    [2] = 
                    {
                        ["price"] = 55434,
                        ["guild"] = 1,
                        ["buyer"] = 2349,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1632879629,
                        ["quant"] = 6,
                        ["id"] = "1689392789",
                        ["itemLink"] = 2870,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior furnishings dining",
            },
        },
        [57019] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Aqua Vitae",
                ["oldestTime"] = 1633267909,
                ["wasAltered"] = true,
                ["newestTime"] = 1633267909,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 1864,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633267909,
                        ["quant"] = 1,
                        ["id"] = "1692383845",
                        ["itemLink"] = 2646,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [115900] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_clothier_4.dds",
                ["itemDesc"] = "Pattern: Wood Elf Bedding, Padded",
                ["oldestTime"] = 1632865544,
                ["wasAltered"] = true,
                ["newestTime"] = 1632865544,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24250,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1632865544,
                        ["quant"] = 1,
                        ["id"] = "1689268955",
                        ["itemLink"] = 3348,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [126838] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting4.dds",
                ["itemDesc"] = "Praxis: Daedric Base, Ashen",
                ["oldestTime"] = 1633292408,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292408,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 533,
                        ["guild"] = 1,
                        ["buyer"] = 1992,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633292408,
                        ["quant"] = 1,
                        ["id"] = "1692656411",
                        ["itemLink"] = 2831,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [119486] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_alchemy4.dds",
                ["itemDesc"] = "Formula: Vial, Delicate",
                ["oldestTime"] = 1633075152,
                ["wasAltered"] = true,
                ["newestTime"] = 1633075152,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 15619,
                        ["guild"] = 1,
                        ["buyer"] = 862,
                        ["wasKiosk"] = true,
                        ["seller"] = 279,
                        ["timestamp"] = 1633075152,
                        ["quant"] = 1,
                        ["id"] = "1690811703",
                        ["itemLink"] = 1107,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [173247] = 
        {
            ["50:16:3:31:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Amulet of Diamond's Victory",
                ["oldestTime"] = 1632873291,
                ["wasAltered"] = true,
                ["newestTime"] = 1633013029,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 54999,
                        ["guild"] = 1,
                        ["buyer"] = 313,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632984956,
                        ["quant"] = 1,
                        ["id"] = "1690159801",
                        ["itemLink"] = 318,
                    },
                    [2] = 
                    {
                        ["price"] = 54999,
                        ["guild"] = 1,
                        ["buyer"] = 459,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633013029,
                        ["quant"] = 1,
                        ["id"] = "1690309889",
                        ["itemLink"] = 318,
                    },
                    [3] = 
                    {
                        ["price"] = 54999,
                        ["guild"] = 1,
                        ["buyer"] = 2310,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632873291,
                        ["quant"] = 1,
                        ["id"] = "1689325599",
                        ["itemLink"] = 318,
                    },
                    [4] = 
                    {
                        ["price"] = 54999,
                        ["guild"] = 1,
                        ["buyer"] = 2651,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632964352,
                        ["quant"] = 1,
                        ["id"] = "1689998857",
                        ["itemLink"] = 318,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp160 blue superior jewelry apparel set diamond's victory neck bloodthirsty",
            },
        },
        [86189] = 
        {
            ["50:16:4:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of the Withered Hand",
                ["oldestTime"] = 1633277732,
                ["wasAltered"] = true,
                ["newestTime"] = 1633277732,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1913,
                        ["wasKiosk"] = true,
                        ["seller"] = 655,
                        ["timestamp"] = 1633277732,
                        ["quant"] = 1,
                        ["id"] = "1692492923",
                        ["itemLink"] = 2713,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set robes of the withered hand neck arcane",
            },
            ["24:0:3:22:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of the Withered Hand",
                ["oldestTime"] = 1632929483,
                ["wasAltered"] = true,
                ["newestTime"] = 1632929483,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 800,
                        ["guild"] = 1,
                        ["buyer"] = 966,
                        ["wasKiosk"] = false,
                        ["seller"] = 739,
                        ["timestamp"] = 1632929483,
                        ["quant"] = 1,
                        ["id"] = "1689718083",
                        ["itemLink"] = 3696,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr24 blue superior jewelry apparel set robes of the withered hand neck arcane",
            },
        },
        [125473] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_researchscroll_blacksmith.dds",
                ["itemDesc"] = "Research Scroll, Blacksmithing, 1 Day",
                ["oldestTime"] = 1632838753,
                ["wasAltered"] = true,
                ["newestTime"] = 1633014282,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 325,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632987012,
                        ["quant"] = 2,
                        ["id"] = "1690169677",
                        ["itemLink"] = 330,
                    },
                    [2] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 421,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633006346,
                        ["quant"] = 2,
                        ["id"] = "1690267037",
                        ["itemLink"] = 330,
                    },
                    [3] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 463,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1633014282,
                        ["quant"] = 2,
                        ["id"] = "1690318539",
                        ["itemLink"] = 330,
                    },
                    [4] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 696,
                        ["wasKiosk"] = false,
                        ["seller"] = 90,
                        ["timestamp"] = 1632838753,
                        ["quant"] = 2,
                        ["id"] = "1689052819",
                        ["itemLink"] = 330,
                    },
                    [5] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 2492,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632923567,
                        ["quant"] = 2,
                        ["id"] = "1689676527",
                        ["itemLink"] = 330,
                    },
                    [6] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 2520,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632932723,
                        ["quant"] = 2,
                        ["id"] = "1689742283",
                        ["itemLink"] = 330,
                    },
                    [7] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 2520,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632932725,
                        ["quant"] = 2,
                        ["id"] = "1689742307",
                        ["itemLink"] = 330,
                    },
                    [8] = 
                    {
                        ["price"] = 10400,
                        ["guild"] = 1,
                        ["buyer"] = 745,
                        ["wasKiosk"] = true,
                        ["seller"] = 90,
                        ["timestamp"] = 1632948817,
                        ["quant"] = 2,
                        ["id"] = "1689864153",
                        ["itemLink"] = 330,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "rr01 gold legendary consumable trophy",
            },
        },
        [28610] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_grapes.dds",
                ["itemDesc"] = "Jazbay Grapes",
                ["oldestTime"] = 1633054108,
                ["wasAltered"] = true,
                ["newestTime"] = 1633054108,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2500,
                        ["guild"] = 1,
                        ["buyer"] = 731,
                        ["wasKiosk"] = true,
                        ["seller"] = 260,
                        ["timestamp"] = 1633054108,
                        ["quant"] = 200,
                        ["id"] = "1690646555",
                        ["itemLink"] = 936,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [147687] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 72: Meridian Chests",
                ["oldestTime"] = 1633261795,
                ["wasAltered"] = true,
                ["newestTime"] = 1633261795,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 90000,
                        ["guild"] = 1,
                        ["buyer"] = 1327,
                        ["wasKiosk"] = true,
                        ["seller"] = 712,
                        ["timestamp"] = 1633261795,
                        ["quant"] = 1,
                        ["id"] = "1692336171",
                        ["itemLink"] = 2631,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [26591] = 
        {
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_weakeningenchant.dds",
                ["itemDesc"] = "Superb Glyph of Weakening",
                ["oldestTime"] = 1632881733,
                ["wasAltered"] = true,
                ["newestTime"] = 1632881733,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 125,
                        ["guild"] = 1,
                        ["buyer"] = 2361,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632881733,
                        ["quant"] = 1,
                        ["id"] = "1689414549",
                        ["itemLink"] = 3469,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 green fine miscellaneous weapon glyph",
            },
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_weakeningenchant.dds",
                ["itemDesc"] = "Truly Superb Glyph of Weakening",
                ["oldestTime"] = 1632908224,
                ["wasAltered"] = true,
                ["newestTime"] = 1632908224,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1714,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1632908224,
                        ["quant"] = 1,
                        ["id"] = "1689595983",
                        ["itemLink"] = 3595,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous weapon glyph",
            },
            ["50:15:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_weakeningenchant.dds",
                ["itemDesc"] = "Superb Glyph of Weakening",
                ["oldestTime"] = 1633251482,
                ["wasAltered"] = true,
                ["newestTime"] = 1633251482,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633251482,
                        ["quant"] = 1,
                        ["id"] = "1692280599",
                        ["itemLink"] = 2599,
                    },
                    [2] = 
                    {
                        ["price"] = 550,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 108,
                        ["timestamp"] = 1633251482,
                        ["quant"] = 1,
                        ["id"] = "1692280601",
                        ["itemLink"] = 2599,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "cp150 purple epic miscellaneous weapon glyph",
            },
        },
        [45253] = 
        {
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_medium_hands_d.dds",
                ["itemDesc"] = "Rubedo Leather Bracers of Health",
                ["oldestTime"] = 1632922806,
                ["wasAltered"] = true,
                ["newestTime"] = 1632922806,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 300,
                        ["guild"] = 1,
                        ["buyer"] = 166,
                        ["wasKiosk"] = false,
                        ["seller"] = 104,
                        ["timestamp"] = 1632922806,
                        ["quant"] = 1,
                        ["id"] = "1689672083",
                        ["itemLink"] = 3670,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic medium apparel hands invigorating",
            },
        },
        [46150] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_metals_argentum.dds",
                ["itemDesc"] = "Argentum",
                ["oldestTime"] = 1633227319,
                ["wasAltered"] = true,
                ["newestTime"] = 1633227319,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2085,
                        ["guild"] = 1,
                        ["buyer"] = 1660,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633227319,
                        ["quant"] = 139,
                        ["id"] = "1692088403",
                        ["itemLink"] = 2405,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal materials style",
            },
        },
        [29030] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_components_bread_001.dds",
                ["itemDesc"] = "Rice",
                ["oldestTime"] = 1632918049,
                ["wasAltered"] = true,
                ["newestTime"] = 1633221258,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 3313,
                        ["guild"] = 1,
                        ["buyer"] = 1616,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1633221258,
                        ["quant"] = 200,
                        ["id"] = "1692024441",
                        ["itemLink"] = 2353,
                    },
                    [2] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 605,
                        ["wasKiosk"] = false,
                        ["seller"] = 148,
                        ["timestamp"] = 1632918049,
                        ["quant"] = 200,
                        ["id"] = "1689640487",
                        ["itemLink"] = 2353,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials ingredient",
            },
        },
        [119413] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing3.dds",
                ["itemDesc"] = "Diagram: Cauldron of Soup",
                ["oldestTime"] = 1633047918,
                ["wasAltered"] = true,
                ["newestTime"] = 1633265421,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 271,
                        ["wasKiosk"] = false,
                        ["seller"] = 625,
                        ["timestamp"] = 1633047918,
                        ["quant"] = 1,
                        ["id"] = "1690584947",
                        ["itemLink"] = 872,
                    },
                    [2] = 
                    {
                        ["price"] = 2555,
                        ["guild"] = 1,
                        ["buyer"] = 972,
                        ["wasKiosk"] = true,
                        ["seller"] = 633,
                        ["timestamp"] = 1633107480,
                        ["quant"] = 1,
                        ["id"] = "1691018231",
                        ["itemLink"] = 872,
                    },
                    [3] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1361,
                        ["wasKiosk"] = true,
                        ["seller"] = 256,
                        ["timestamp"] = 1633265421,
                        ["quant"] = 1,
                        ["id"] = "1692363737",
                        ["itemLink"] = 872,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [82055] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 36: Dark Brotherhood Axes",
                ["oldestTime"] = 1633314368,
                ["wasAltered"] = true,
                ["newestTime"] = 1633314368,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6259,
                        ["guild"] = 1,
                        ["buyer"] = 68,
                        ["wasKiosk"] = true,
                        ["seller"] = 69,
                        ["timestamp"] = 1633314368,
                        ["quant"] = 1,
                        ["id"] = "1692894093",
                        ["itemLink"] = 51,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [43722] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Craglorn Treasure Map II",
                ["oldestTime"] = 1633310234,
                ["wasAltered"] = true,
                ["newestTime"] = 1633310234,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2087,
                        ["wasKiosk"] = true,
                        ["seller"] = 75,
                        ["timestamp"] = 1633310234,
                        ["quant"] = 1,
                        ["id"] = "1692851341",
                        ["itemLink"] = 2990,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [167179] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 92: Ancestral Akaviri Daggers",
                ["oldestTime"] = 1633037051,
                ["wasAltered"] = true,
                ["newestTime"] = 1633037051,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 199990,
                        ["guild"] = 1,
                        ["buyer"] = 607,
                        ["wasKiosk"] = true,
                        ["seller"] = 608,
                        ["timestamp"] = 1633037051,
                        ["quant"] = 1,
                        ["id"] = "1690492415",
                        ["itemLink"] = 775,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [176588] = 
        {
            ["1:0:3:47:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_shoulders_medium.dds",
                ["itemDesc"] = "Companion's Arm Cops",
                ["oldestTime"] = 1632908447,
                ["wasAltered"] = true,
                ["newestTime"] = 1633209478,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24000,
                        ["guild"] = 1,
                        ["buyer"] = 1213,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1633143457,
                        ["quant"] = 1,
                        ["id"] = "1691331137",
                        ["itemLink"] = 1640,
                    },
                    [2] = 
                    {
                        ["price"] = 59999,
                        ["guild"] = 1,
                        ["buyer"] = 1550,
                        ["wasKiosk"] = true,
                        ["seller"] = 93,
                        ["timestamp"] = 1633209478,
                        ["quant"] = 1,
                        ["id"] = "1691899809",
                        ["itemLink"] = 1640,
                    },
                    [3] = 
                    {
                        ["price"] = 59999,
                        ["guild"] = 1,
                        ["buyer"] = 1082,
                        ["wasKiosk"] = false,
                        ["seller"] = 93,
                        ["timestamp"] = 1632908447,
                        ["quant"] = 1,
                        ["id"] = "1689596699",
                        ["itemLink"] = 1640,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior medium apparel shoulders aggressive",
            },
        },
        [97229] = 
        {
            ["50:16:3:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_d.dds",
                ["itemDesc"] = "Lightning Staff of a Mother's Sorrow",
                ["oldestTime"] = 1632989286,
                ["wasAltered"] = true,
                ["newestTime"] = 1632989286,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 341,
                        ["wasKiosk"] = true,
                        ["seller"] = 70,
                        ["timestamp"] = 1632989286,
                        ["quant"] = 1,
                        ["id"] = "1690182743",
                        ["itemLink"] = 345,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon set mother's sorrow lightning staff two-handed infused",
            },
            ["50:16:5:4:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_staff_d.dds",
                ["itemDesc"] = "Lightning Staff of a Mother's Sorrow",
                ["oldestTime"] = 1632897971,
                ["wasAltered"] = true,
                ["newestTime"] = 1632897971,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 108713,
                        ["guild"] = 1,
                        ["buyer"] = 2440,
                        ["wasKiosk"] = true,
                        ["seller"] = 243,
                        ["timestamp"] = 1632897971,
                        ["quant"] = 1,
                        ["id"] = "1689548247",
                        ["itemLink"] = 3569,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary weapon set mother's sorrow lightning staff two-handed infused",
            },
        },
        [119052] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Orcish Counter, Branded",
                ["oldestTime"] = 1632519477,
                ["wasAltered"] = true,
                ["newestTime"] = 1632939591,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 2,
                        ["buyer"] = 114,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1632519477,
                        ["quant"] = 1,
                        ["id"] = "1686349023",
                        ["itemLink"] = 86,
                    },
                    [2] = 
                    {
                        ["price"] = 2499,
                        ["guild"] = 1,
                        ["buyer"] = 936,
                        ["wasKiosk"] = true,
                        ["seller"] = 4,
                        ["timestamp"] = 1632939591,
                        ["quant"] = 1,
                        ["id"] = "1689792347",
                        ["itemLink"] = 86,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [132559] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_cwc_inc_scrollplate001.dds",
                ["itemDesc"] = "Crafting Motif 56: Apostle Maces",
                ["oldestTime"] = 1633214039,
                ["wasAltered"] = true,
                ["newestTime"] = 1633219228,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1571,
                        ["wasKiosk"] = true,
                        ["seller"] = 479,
                        ["timestamp"] = 1633214039,
                        ["quant"] = 1,
                        ["id"] = "1691950069",
                        ["itemLink"] = 2295,
                    },
                    [2] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 160,
                        ["wasKiosk"] = true,
                        ["seller"] = 151,
                        ["timestamp"] = 1633219228,
                        ["quant"] = 1,
                        ["id"] = "1692004789",
                        ["itemLink"] = 2295,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [81616] = 
        {
            ["50:16:4:25:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_orc_heavy_hands_d.dds",
                ["itemDesc"] = "Exemplary Nirnhoned Gauntlets",
                ["oldestTime"] = 1633299433,
                ["wasAltered"] = true,
                ["newestTime"] = 1633299433,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 2039,
                        ["wasKiosk"] = true,
                        ["seller"] = 199,
                        ["timestamp"] = 1633299433,
                        ["quant"] = 1,
                        ["id"] = "1692735851",
                        ["itemLink"] = 2910,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic heavy apparel hands nirnhoned",
            },
        },
        [94109] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_nib_lsb_lamphanginglitonly001.dds",
                ["itemDesc"] = "Imperial Lantern, Wall",
                ["oldestTime"] = 1633214682,
                ["wasAltered"] = true,
                ["newestTime"] = 1633214682,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 120,
                        ["guild"] = 1,
                        ["buyer"] = 1576,
                        ["wasKiosk"] = true,
                        ["seller"] = 99,
                        ["timestamp"] = 1633214682,
                        ["quant"] = 2,
                        ["id"] = "1691955767",
                        ["itemLink"] = 2300,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine furnishings lighting",
            },
        },
        [99098] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_shield_d.dds",
                ["itemDesc"] = "Shield of the Hatchling's Shell",
                ["oldestTime"] = 1633131411,
                ["wasAltered"] = true,
                ["newestTime"] = 1633131411,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 5000,
                        ["guild"] = 1,
                        ["buyer"] = 1111,
                        ["wasKiosk"] = true,
                        ["seller"] = 188,
                        ["timestamp"] = 1633131411,
                        ["quant"] = 1,
                        ["id"] = "1691201647",
                        ["itemLink"] = 1523,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine apparel weapon set hatchling's shell shield off hand divines",
            },
        },
        [122643] = 
        {
            ["50:16:5:1:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_redoran_staff_a.dds",
                ["itemDesc"] = "Warrior-Poet's Restoration Staff",
                ["oldestTime"] = 1632973169,
                ["wasAltered"] = true,
                ["newestTime"] = 1632973169,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100000,
                        ["guild"] = 1,
                        ["buyer"] = 191,
                        ["wasKiosk"] = true,
                        ["seller"] = 192,
                        ["timestamp"] = 1632973169,
                        ["quant"] = 1,
                        ["id"] = "1690084055",
                        ["itemLink"] = 202,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 gold legendary weapon set warrior-poet healing staff two-handed powered",
            },
        },
        [54484] = 
        {
            ["50:4:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_berserking.dds",
                ["itemDesc"] = "Greater Glyph of Weapon Damage",
                ["oldestTime"] = 1633251491,
                ["wasAltered"] = true,
                ["newestTime"] = 1633251491,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1000,
                        ["guild"] = 1,
                        ["buyer"] = 1743,
                        ["wasKiosk"] = true,
                        ["seller"] = 1004,
                        ["timestamp"] = 1633251491,
                        ["quant"] = 1,
                        ["id"] = "1692280655",
                        ["itemLink"] = 2604,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp40 green fine miscellaneous weapon glyph",
            },
            ["50:15:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_berserking.dds",
                ["itemDesc"] = "Superb Glyph of Weapon Damage",
                ["oldestTime"] = 1633298997,
                ["wasAltered"] = true,
                ["newestTime"] = 1633298997,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 2031,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633298997,
                        ["quant"] = 1,
                        ["id"] = "1692731227",
                        ["itemLink"] = 2907,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp150 green fine miscellaneous weapon glyph",
            },
            ["50:16:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/enchantment_weapon_berserking.dds",
                ["itemDesc"] = "Truly Superb Glyph of Weapon Damage",
                ["oldestTime"] = 1632930533,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238244,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6185,
                        ["guild"] = 1,
                        ["buyer"] = 211,
                        ["wasKiosk"] = false,
                        ["seller"] = 84,
                        ["timestamp"] = 1633031451,
                        ["quant"] = 1,
                        ["id"] = "1690454033",
                        ["itemLink"] = 718,
                    },
                    [2] = 
                    {
                        ["price"] = 6185,
                        ["guild"] = 1,
                        ["buyer"] = 818,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633065456,
                        ["quant"] = 1,
                        ["id"] = "1690751401",
                        ["itemLink"] = 718,
                    },
                    [3] = 
                    {
                        ["price"] = 6185,
                        ["guild"] = 1,
                        ["buyer"] = 818,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1633065457,
                        ["quant"] = 1,
                        ["id"] = "1690751409",
                        ["itemLink"] = 718,
                    },
                    [4] = 
                    {
                        ["price"] = 6199,
                        ["guild"] = 1,
                        ["buyer"] = 818,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633065458,
                        ["quant"] = 1,
                        ["id"] = "1690751415",
                        ["itemLink"] = 718,
                    },
                    [5] = 
                    {
                        ["price"] = 6199,
                        ["guild"] = 1,
                        ["buyer"] = 818,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633065459,
                        ["quant"] = 1,
                        ["id"] = "1690751421",
                        ["itemLink"] = 718,
                    },
                    [6] = 
                    {
                        ["price"] = 6200,
                        ["guild"] = 1,
                        ["buyer"] = 818,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1633065460,
                        ["quant"] = 1,
                        ["id"] = "1690751425",
                        ["itemLink"] = 718,
                    },
                    [7] = 
                    {
                        ["price"] = 6199,
                        ["guild"] = 1,
                        ["buyer"] = 158,
                        ["wasKiosk"] = false,
                        ["seller"] = 778,
                        ["timestamp"] = 1633122333,
                        ["quant"] = 1,
                        ["id"] = "1691121783",
                        ["itemLink"] = 718,
                    },
                    [8] = 
                    {
                        ["price"] = 6199,
                        ["guild"] = 1,
                        ["buyer"] = 1375,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633182024,
                        ["quant"] = 1,
                        ["id"] = "1691603937",
                        ["itemLink"] = 718,
                    },
                    [9] = 
                    {
                        ["price"] = 6199,
                        ["guild"] = 1,
                        ["buyer"] = 209,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633187542,
                        ["quant"] = 1,
                        ["id"] = "1691657931",
                        ["itemLink"] = 718,
                    },
                    [10] = 
                    {
                        ["price"] = 6199,
                        ["guild"] = 1,
                        ["buyer"] = 803,
                        ["wasKiosk"] = false,
                        ["seller"] = 778,
                        ["timestamp"] = 1633196088,
                        ["quant"] = 1,
                        ["id"] = "1691751269",
                        ["itemLink"] = 718,
                    },
                    [11] = 
                    {
                        ["price"] = 6199,
                        ["guild"] = 1,
                        ["buyer"] = 340,
                        ["wasKiosk"] = false,
                        ["seller"] = 778,
                        ["timestamp"] = 1633208924,
                        ["quant"] = 1,
                        ["id"] = "1691893513",
                        ["itemLink"] = 718,
                    },
                    [12] = 
                    {
                        ["price"] = 6199,
                        ["guild"] = 1,
                        ["buyer"] = 1606,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633219843,
                        ["quant"] = 1,
                        ["id"] = "1692010255",
                        ["itemLink"] = 718,
                    },
                    [13] = 
                    {
                        ["price"] = 6199,
                        ["guild"] = 1,
                        ["buyer"] = 1608,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633220318,
                        ["quant"] = 1,
                        ["id"] = "1692015189",
                        ["itemLink"] = 718,
                    },
                    [14] = 
                    {
                        ["price"] = 6199,
                        ["guild"] = 1,
                        ["buyer"] = 1608,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633220319,
                        ["quant"] = 1,
                        ["id"] = "1692015213",
                        ["itemLink"] = 718,
                    },
                    [15] = 
                    {
                        ["price"] = 6199,
                        ["guild"] = 1,
                        ["buyer"] = 1608,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633220766,
                        ["quant"] = 1,
                        ["id"] = "1692019821",
                        ["itemLink"] = 718,
                    },
                    [16] = 
                    {
                        ["price"] = 6199,
                        ["guild"] = 1,
                        ["buyer"] = 1610,
                        ["wasKiosk"] = true,
                        ["seller"] = 778,
                        ["timestamp"] = 1633226801,
                        ["quant"] = 1,
                        ["id"] = "1692083595",
                        ["itemLink"] = 718,
                    },
                    [17] = 
                    {
                        ["price"] = 6200,
                        ["guild"] = 1,
                        ["buyer"] = 1610,
                        ["wasKiosk"] = true,
                        ["seller"] = 673,
                        ["timestamp"] = 1633226874,
                        ["quant"] = 1,
                        ["id"] = "1692084341",
                        ["itemLink"] = 718,
                    },
                    [18] = 
                    {
                        ["price"] = 6300,
                        ["guild"] = 1,
                        ["buyer"] = 1671,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633228856,
                        ["quant"] = 1,
                        ["id"] = "1692105603",
                        ["itemLink"] = 718,
                    },
                    [19] = 
                    {
                        ["price"] = 6300,
                        ["guild"] = 1,
                        ["buyer"] = 1712,
                        ["wasKiosk"] = true,
                        ["seller"] = 35,
                        ["timestamp"] = 1633233263,
                        ["quant"] = 1,
                        ["id"] = "1692147247",
                        ["itemLink"] = 718,
                    },
                    [20] = 
                    {
                        ["price"] = 6500,
                        ["guild"] = 1,
                        ["buyer"] = 1712,
                        ["wasKiosk"] = true,
                        ["seller"] = 173,
                        ["timestamp"] = 1633233264,
                        ["quant"] = 1,
                        ["id"] = "1692147251",
                        ["itemLink"] = 718,
                    },
                    [21] = 
                    {
                        ["price"] = 6300,
                        ["guild"] = 1,
                        ["buyer"] = 827,
                        ["wasKiosk"] = false,
                        ["seller"] = 35,
                        ["timestamp"] = 1633238244,
                        ["quant"] = 1,
                        ["id"] = "1692187209",
                        ["itemLink"] = 718,
                    },
                    [22] = 
                    {
                        ["price"] = 6185,
                        ["guild"] = 1,
                        ["buyer"] = 1327,
                        ["wasKiosk"] = true,
                        ["seller"] = 84,
                        ["timestamp"] = 1632930533,
                        ["quant"] = 1,
                        ["id"] = "1689725877",
                        ["itemLink"] = 718,
                    },
                },
                ["totalCount"] = 22,
                ["itemAdderText"] = "cp160 gold legendary miscellaneous weapon glyph",
            },
        },
        [1749] = 
        {
            ["50:16:2:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_light_feet_d.dds",
                ["itemDesc"] = "Nereid's Slippers",
                ["oldestTime"] = 1633057443,
                ["wasAltered"] = true,
                ["newestTime"] = 1633057443,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 767,
                        ["wasKiosk"] = true,
                        ["seller"] = 190,
                        ["timestamp"] = 1633057443,
                        ["quant"] = 1,
                        ["id"] = "1690684593",
                        ["itemLink"] = 966,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine light apparel feet divines",
            },
        },
        [176029] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing3.dds",
                ["itemDesc"] = "Diagram: Deadlands Urn, Inscribed",
                ["oldestTime"] = 1633210731,
                ["wasAltered"] = true,
                ["newestTime"] = 1633210731,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1551,
                        ["wasKiosk"] = true,
                        ["seller"] = 354,
                        ["timestamp"] = 1633210731,
                        ["quant"] = 1,
                        ["id"] = "1691912299",
                        ["itemLink"] = 2275,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [115927] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_enchanting2.dds",
                ["itemDesc"] = "Praxis: Breton Amphora, Ceramic",
                ["oldestTime"] = 1633204779,
                ["wasAltered"] = true,
                ["newestTime"] = 1633204779,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 50,
                        ["guild"] = 1,
                        ["buyer"] = 1427,
                        ["wasKiosk"] = true,
                        ["seller"] = 182,
                        ["timestamp"] = 1633204779,
                        ["quant"] = 1,
                        ["id"] = "1691840409",
                        ["itemLink"] = 2235,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [140504] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 67: Welkynar Helmets",
                ["oldestTime"] = 1632874038,
                ["wasAltered"] = true,
                ["newestTime"] = 1633306661,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 10000,
                        ["guild"] = 1,
                        ["buyer"] = 978,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633109284,
                        ["quant"] = 1,
                        ["id"] = "1691030847",
                        ["itemLink"] = 1314,
                    },
                    [2] = 
                    {
                        ["price"] = 15500,
                        ["guild"] = 1,
                        ["buyer"] = 1640,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1633224791,
                        ["quant"] = 1,
                        ["id"] = "1692062187",
                        ["itemLink"] = 1314,
                    },
                    [3] = 
                    {
                        ["price"] = 15500,
                        ["guild"] = 1,
                        ["buyer"] = 1728,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1633235041,
                        ["quant"] = 1,
                        ["id"] = "1692160943",
                        ["itemLink"] = 1314,
                    },
                    [4] = 
                    {
                        ["price"] = 15500,
                        ["guild"] = 1,
                        ["buyer"] = 1871,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1633269900,
                        ["quant"] = 1,
                        ["id"] = "1692403585",
                        ["itemLink"] = 1314,
                    },
                    [5] = 
                    {
                        ["price"] = 15500,
                        ["guild"] = 1,
                        ["buyer"] = 2071,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1633306661,
                        ["quant"] = 1,
                        ["id"] = "1692806055",
                        ["itemLink"] = 1314,
                    },
                    [6] = 
                    {
                        ["price"] = 14000,
                        ["guild"] = 1,
                        ["buyer"] = 2083,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1632874038,
                        ["quant"] = 1,
                        ["id"] = "1689331593",
                        ["itemLink"] = 1314,
                    },
                },
                ["totalCount"] = 6,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [77589] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_poisonmaking_reagent_scrib_jelly.dds",
                ["itemDesc"] = "Scrib Jelly",
                ["oldestTime"] = 1632865461,
                ["wasAltered"] = true,
                ["newestTime"] = 1633283377,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 22531,
                        ["guild"] = 1,
                        ["buyer"] = 265,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1632981235,
                        ["quant"] = 66,
                        ["id"] = "1690137809",
                        ["itemLink"] = 272,
                    },
                    [2] = 
                    {
                        ["price"] = 27750,
                        ["guild"] = 1,
                        ["buyer"] = 338,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632988606,
                        ["quant"] = 50,
                        ["id"] = "1690178363",
                        ["itemLink"] = 272,
                    },
                    [3] = 
                    {
                        ["price"] = 4758,
                        ["guild"] = 1,
                        ["buyer"] = 787,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633060337,
                        ["quant"] = 14,
                        ["id"] = "1690712991",
                        ["itemLink"] = 272,
                    },
                    [4] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 859,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633074265,
                        ["quant"] = 20,
                        ["id"] = "1690806297",
                        ["itemLink"] = 272,
                    },
                    [5] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 923,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633093838,
                        ["quant"] = 20,
                        ["id"] = "1690913025",
                        ["itemLink"] = 272,
                    },
                    [6] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 923,
                        ["wasKiosk"] = true,
                        ["seller"] = 786,
                        ["timestamp"] = 1633093841,
                        ["quant"] = 20,
                        ["id"] = "1690913055",
                        ["itemLink"] = 272,
                    },
                    [7] = 
                    {
                        ["price"] = 1600,
                        ["guild"] = 1,
                        ["buyer"] = 787,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1633151802,
                        ["quant"] = 4,
                        ["id"] = "1691406391",
                        ["itemLink"] = 272,
                    },
                    [8] = 
                    {
                        ["price"] = 78400,
                        ["guild"] = 1,
                        ["buyer"] = 644,
                        ["wasKiosk"] = true,
                        ["seller"] = 327,
                        ["timestamp"] = 1633215528,
                        ["quant"] = 200,
                        ["id"] = "1691962931",
                        ["itemLink"] = 272,
                    },
                    [9] = 
                    {
                        ["price"] = 11185,
                        ["guild"] = 1,
                        ["buyer"] = 1616,
                        ["wasKiosk"] = true,
                        ["seller"] = 80,
                        ["timestamp"] = 1633231187,
                        ["quant"] = 33,
                        ["id"] = "1692125619",
                        ["itemLink"] = 272,
                    },
                    [10] = 
                    {
                        ["price"] = 110000,
                        ["guild"] = 1,
                        ["buyer"] = 1616,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633231198,
                        ["quant"] = 200,
                        ["id"] = "1692125737",
                        ["itemLink"] = 272,
                    },
                    [11] = 
                    {
                        ["price"] = 110000,
                        ["guild"] = 1,
                        ["buyer"] = 1616,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633231216,
                        ["quant"] = 200,
                        ["id"] = "1692125939",
                        ["itemLink"] = 272,
                    },
                    [12] = 
                    {
                        ["price"] = 150000,
                        ["guild"] = 1,
                        ["buyer"] = 1710,
                        ["wasKiosk"] = true,
                        ["seller"] = 41,
                        ["timestamp"] = 1633232954,
                        ["quant"] = 200,
                        ["id"] = "1692144493",
                        ["itemLink"] = 272,
                    },
                    [13] = 
                    {
                        ["price"] = 590,
                        ["guild"] = 1,
                        ["buyer"] = 1857,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633283373,
                        ["quant"] = 1,
                        ["id"] = "1692550165",
                        ["itemLink"] = 272,
                    },
                    [14] = 
                    {
                        ["price"] = 590,
                        ["guild"] = 1,
                        ["buyer"] = 1857,
                        ["wasKiosk"] = true,
                        ["seller"] = 647,
                        ["timestamp"] = 1633283375,
                        ["quant"] = 1,
                        ["id"] = "1692550173",
                        ["itemLink"] = 272,
                    },
                    [15] = 
                    {
                        ["price"] = 5391,
                        ["guild"] = 1,
                        ["buyer"] = 1857,
                        ["wasKiosk"] = true,
                        ["seller"] = 865,
                        ["timestamp"] = 1633283377,
                        ["quant"] = 9,
                        ["id"] = "1692550201",
                        ["itemLink"] = 272,
                    },
                    [16] = 
                    {
                        ["price"] = 3570,
                        ["guild"] = 1,
                        ["buyer"] = 34,
                        ["wasKiosk"] = false,
                        ["seller"] = 158,
                        ["timestamp"] = 1632865461,
                        ["quant"] = 7,
                        ["id"] = "1689268497",
                        ["itemLink"] = 272,
                    },
                    [17] = 
                    {
                        ["price"] = 160000,
                        ["guild"] = 1,
                        ["buyer"] = 2381,
                        ["wasKiosk"] = true,
                        ["seller"] = 41,
                        ["timestamp"] = 1632884248,
                        ["quant"] = 200,
                        ["id"] = "1689442113",
                        ["itemLink"] = 272,
                    },
                    [18] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 2422,
                        ["wasKiosk"] = true,
                        ["seller"] = 775,
                        ["timestamp"] = 1632892439,
                        ["quant"] = 10,
                        ["id"] = "1689512159",
                        ["itemLink"] = 272,
                    },
                    [19] = 
                    {
                        ["price"] = 14500,
                        ["guild"] = 1,
                        ["buyer"] = 2488,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1632921430,
                        ["quant"] = 25,
                        ["id"] = "1689660809",
                        ["itemLink"] = 272,
                    },
                },
                ["totalCount"] = 19,
                ["itemAdderText"] = "rr01 green fine materials reagent",
            },
        },
        [147512] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_ring_a.dds",
                ["itemDesc"] = "Deadly Ring",
                ["oldestTime"] = 1633033785,
                ["wasAltered"] = true,
                ["newestTime"] = 1633251164,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 581,
                        ["wasKiosk"] = true,
                        ["seller"] = 340,
                        ["timestamp"] = 1633033785,
                        ["quant"] = 1,
                        ["id"] = "1690468195",
                        ["itemLink"] = 752,
                    },
                    [2] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 581,
                        ["wasKiosk"] = true,
                        ["seller"] = 340,
                        ["timestamp"] = 1633033786,
                        ["quant"] = 1,
                        ["id"] = "1690468203",
                        ["itemLink"] = 752,
                    },
                    [3] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 1605,
                        ["wasKiosk"] = true,
                        ["seller"] = 38,
                        ["timestamp"] = 1633226739,
                        ["quant"] = 1,
                        ["id"] = "1692082795",
                        ["itemLink"] = 752,
                    },
                    [4] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 864,
                        ["wasKiosk"] = true,
                        ["seller"] = 38,
                        ["timestamp"] = 1633251164,
                        ["quant"] = 1,
                        ["id"] = "1692279077",
                        ["itemLink"] = 752,
                    },
                },
                ["totalCount"] = 4,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set deadly strike ring robust",
            },
        },
        [56863] = 
        {
            ["1:0:1:26:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_potent_nirncrux_dust.dds",
                ["itemDesc"] = "Potent Nirncrux",
                ["oldestTime"] = 1632825531,
                ["wasAltered"] = true,
                ["newestTime"] = 1633302519,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 27336,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632973572,
                        ["quant"] = 1,
                        ["id"] = "1690087179",
                        ["itemLink"] = 206,
                    },
                    [2] = 
                    {
                        ["price"] = 54672,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632973573,
                        ["quant"] = 2,
                        ["id"] = "1690087187",
                        ["itemLink"] = 206,
                    },
                    [3] = 
                    {
                        ["price"] = 54673,
                        ["guild"] = 1,
                        ["buyer"] = 194,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632973574,
                        ["quant"] = 2,
                        ["id"] = "1690087193",
                        ["itemLink"] = 206,
                    },
                    [4] = 
                    {
                        ["price"] = 26400,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633003771,
                        ["quant"] = 1,
                        ["id"] = "1690252905",
                        ["itemLink"] = 206,
                    },
                    [5] = 
                    {
                        ["price"] = 26400,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633003772,
                        ["quant"] = 1,
                        ["id"] = "1690252907",
                        ["itemLink"] = 206,
                    },
                    [6] = 
                    {
                        ["price"] = 26400,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633003773,
                        ["quant"] = 1,
                        ["id"] = "1690252909",
                        ["itemLink"] = 206,
                    },
                    [7] = 
                    {
                        ["price"] = 26400,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633003773,
                        ["quant"] = 1,
                        ["id"] = "1690252911",
                        ["itemLink"] = 206,
                    },
                    [8] = 
                    {
                        ["price"] = 26400,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633003774,
                        ["quant"] = 1,
                        ["id"] = "1690252921",
                        ["itemLink"] = 206,
                    },
                    [9] = 
                    {
                        ["price"] = 27091,
                        ["guild"] = 1,
                        ["buyer"] = 453,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633011572,
                        ["quant"] = 1,
                        ["id"] = "1690301105",
                        ["itemLink"] = 206,
                    },
                    [10] = 
                    {
                        ["price"] = 54182,
                        ["guild"] = 1,
                        ["buyer"] = 518,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633022175,
                        ["quant"] = 2,
                        ["id"] = "1690385291",
                        ["itemLink"] = 206,
                    },
                    [11] = 
                    {
                        ["price"] = 54183,
                        ["guild"] = 1,
                        ["buyer"] = 518,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633022177,
                        ["quant"] = 2,
                        ["id"] = "1690385315",
                        ["itemLink"] = 206,
                    },
                    [12] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 732,
                        ["timestamp"] = 1633054180,
                        ["quant"] = 1,
                        ["id"] = "1690647325",
                        ["itemLink"] = 206,
                    },
                    [13] = 
                    {
                        ["price"] = 27255,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633054180,
                        ["quant"] = 1,
                        ["id"] = "1690647337",
                        ["itemLink"] = 206,
                    },
                    [14] = 
                    {
                        ["price"] = 54510,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633055907,
                        ["quant"] = 2,
                        ["id"] = "1690663297",
                        ["itemLink"] = 206,
                    },
                    [15] = 
                    {
                        ["price"] = 27900,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633055912,
                        ["quant"] = 1,
                        ["id"] = "1690663365",
                        ["itemLink"] = 206,
                    },
                    [16] = 
                    {
                        ["price"] = 260000,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 700,
                        ["timestamp"] = 1633068264,
                        ["quant"] = 10,
                        ["id"] = "1690768779",
                        ["itemLink"] = 206,
                    },
                    [17] = 
                    {
                        ["price"] = 26928,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633097085,
                        ["quant"] = 1,
                        ["id"] = "1690936701",
                        ["itemLink"] = 206,
                    },
                    [18] = 
                    {
                        ["price"] = 53857,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633097087,
                        ["quant"] = 2,
                        ["id"] = "1690936715",
                        ["itemLink"] = 206,
                    },
                    [19] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 41,
                        ["timestamp"] = 1633097088,
                        ["quant"] = 1,
                        ["id"] = "1690936727",
                        ["itemLink"] = 206,
                    },
                    [20] = 
                    {
                        ["price"] = 27900,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 397,
                        ["timestamp"] = 1633114492,
                        ["quant"] = 1,
                        ["id"] = "1691069365",
                        ["itemLink"] = 206,
                    },
                    [21] = 
                    {
                        ["price"] = 27900,
                        ["guild"] = 1,
                        ["buyer"] = 145,
                        ["wasKiosk"] = false,
                        ["seller"] = 397,
                        ["timestamp"] = 1633114493,
                        ["quant"] = 1,
                        ["id"] = "1691069369",
                        ["itemLink"] = 206,
                    },
                    [22] = 
                    {
                        ["price"] = 27900,
                        ["guild"] = 1,
                        ["buyer"] = 1062,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633121993,
                        ["quant"] = 1,
                        ["id"] = "1691119437",
                        ["itemLink"] = 206,
                    },
                    [23] = 
                    {
                        ["price"] = 27499,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633129275,
                        ["quant"] = 1,
                        ["id"] = "1691178235",
                        ["itemLink"] = 206,
                    },
                    [24] = 
                    {
                        ["price"] = 27499,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633134417,
                        ["quant"] = 1,
                        ["id"] = "1691234921",
                        ["itemLink"] = 206,
                    },
                    [25] = 
                    {
                        ["price"] = 27499,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633134419,
                        ["quant"] = 1,
                        ["id"] = "1691234929",
                        ["itemLink"] = 206,
                    },
                    [26] = 
                    {
                        ["price"] = 27499,
                        ["guild"] = 1,
                        ["buyer"] = 215,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633134419,
                        ["quant"] = 1,
                        ["id"] = "1691234935",
                        ["itemLink"] = 206,
                    },
                    [27] = 
                    {
                        ["price"] = 27499,
                        ["guild"] = 1,
                        ["buyer"] = 1176,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633139600,
                        ["quant"] = 1,
                        ["id"] = "1691286535",
                        ["itemLink"] = 206,
                    },
                    [28] = 
                    {
                        ["price"] = 27499,
                        ["guild"] = 1,
                        ["buyer"] = 1176,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633139601,
                        ["quant"] = 1,
                        ["id"] = "1691286537",
                        ["itemLink"] = 206,
                    },
                    [29] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 15,
                        ["timestamp"] = 1633154978,
                        ["quant"] = 1,
                        ["id"] = "1691431277",
                        ["itemLink"] = 206,
                    },
                    [30] = 
                    {
                        ["price"] = 54238,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633154978,
                        ["quant"] = 2,
                        ["id"] = "1691431285",
                        ["itemLink"] = 206,
                    },
                    [31] = 
                    {
                        ["price"] = 54238,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1633154979,
                        ["quant"] = 2,
                        ["id"] = "1691431299",
                        ["itemLink"] = 206,
                    },
                    [32] = 
                    {
                        ["price"] = 27499,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 56,
                        ["timestamp"] = 1633165092,
                        ["quant"] = 1,
                        ["id"] = "1691496587",
                        ["itemLink"] = 206,
                    },
                    [33] = 
                    {
                        ["price"] = 27499,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 56,
                        ["timestamp"] = 1633165093,
                        ["quant"] = 1,
                        ["id"] = "1691496591",
                        ["itemLink"] = 206,
                    },
                    [34] = 
                    {
                        ["price"] = 26400,
                        ["guild"] = 1,
                        ["buyer"] = 1342,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633171882,
                        ["quant"] = 1,
                        ["id"] = "1691529055",
                        ["itemLink"] = 206,
                    },
                    [35] = 
                    {
                        ["price"] = 26400,
                        ["guild"] = 1,
                        ["buyer"] = 1342,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633171884,
                        ["quant"] = 1,
                        ["id"] = "1691529059",
                        ["itemLink"] = 206,
                    },
                    [36] = 
                    {
                        ["price"] = 26400,
                        ["guild"] = 1,
                        ["buyer"] = 1342,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633171886,
                        ["quant"] = 1,
                        ["id"] = "1691529061",
                        ["itemLink"] = 206,
                    },
                    [37] = 
                    {
                        ["price"] = 26400,
                        ["guild"] = 1,
                        ["buyer"] = 1342,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633171888,
                        ["quant"] = 1,
                        ["id"] = "1691529063",
                        ["itemLink"] = 206,
                    },
                    [38] = 
                    {
                        ["price"] = 27900,
                        ["guild"] = 1,
                        ["buyer"] = 1342,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633171904,
                        ["quant"] = 1,
                        ["id"] = "1691529121",
                        ["itemLink"] = 206,
                    },
                    [39] = 
                    {
                        ["price"] = 27900,
                        ["guild"] = 1,
                        ["buyer"] = 1342,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633171906,
                        ["quant"] = 1,
                        ["id"] = "1691529145",
                        ["itemLink"] = 206,
                    },
                    [40] = 
                    {
                        ["price"] = 27416,
                        ["guild"] = 1,
                        ["buyer"] = 1069,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633186767,
                        ["quant"] = 1,
                        ["id"] = "1691649809",
                        ["itemLink"] = 206,
                    },
                    [41] = 
                    {
                        ["price"] = 27416,
                        ["guild"] = 1,
                        ["buyer"] = 1426,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1633192316,
                        ["quant"] = 1,
                        ["id"] = "1691716191",
                        ["itemLink"] = 206,
                    },
                    [42] = 
                    {
                        ["price"] = 27900,
                        ["guild"] = 1,
                        ["buyer"] = 1426,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1633192318,
                        ["quant"] = 1,
                        ["id"] = "1691716207",
                        ["itemLink"] = 206,
                    },
                    [43] = 
                    {
                        ["price"] = 140000,
                        ["guild"] = 1,
                        ["buyer"] = 1426,
                        ["wasKiosk"] = true,
                        ["seller"] = 299,
                        ["timestamp"] = 1633192319,
                        ["quant"] = 5,
                        ["id"] = "1691716217",
                        ["itemLink"] = 206,
                    },
                    [44] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 1426,
                        ["wasKiosk"] = true,
                        ["seller"] = 171,
                        ["timestamp"] = 1633192323,
                        ["quant"] = 1,
                        ["id"] = "1691716257",
                        ["itemLink"] = 206,
                    },
                    [45] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 1426,
                        ["wasKiosk"] = true,
                        ["seller"] = 171,
                        ["timestamp"] = 1633192324,
                        ["quant"] = 1,
                        ["id"] = "1691716261",
                        ["itemLink"] = 206,
                    },
                    [46] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 1426,
                        ["wasKiosk"] = true,
                        ["seller"] = 171,
                        ["timestamp"] = 1633192324,
                        ["quant"] = 1,
                        ["id"] = "1691716275",
                        ["itemLink"] = 206,
                    },
                    [47] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 1426,
                        ["wasKiosk"] = true,
                        ["seller"] = 171,
                        ["timestamp"] = 1633192326,
                        ["quant"] = 1,
                        ["id"] = "1691716291",
                        ["itemLink"] = 206,
                    },
                    [48] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 518,
                        ["wasKiosk"] = true,
                        ["seller"] = 41,
                        ["timestamp"] = 1633200093,
                        ["quant"] = 1,
                        ["id"] = "1691791011",
                        ["itemLink"] = 206,
                    },
                    [49] = 
                    {
                        ["price"] = 274999,
                        ["guild"] = 1,
                        ["buyer"] = 1802,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1633246953,
                        ["quant"] = 10,
                        ["id"] = "1692248941",
                        ["itemLink"] = 206,
                    },
                    [50] = 
                    {
                        ["price"] = 53906,
                        ["guild"] = 1,
                        ["buyer"] = 414,
                        ["wasKiosk"] = true,
                        ["seller"] = 1899,
                        ["timestamp"] = 1633275568,
                        ["quant"] = 2,
                        ["id"] = "1692470527",
                        ["itemLink"] = 206,
                    },
                    [51] = 
                    {
                        ["price"] = 50200,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633280915,
                        ["quant"] = 2,
                        ["id"] = "1692524015",
                        ["itemLink"] = 206,
                    },
                    [52] = 
                    {
                        ["price"] = 50200,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633280917,
                        ["quant"] = 2,
                        ["id"] = "1692524029",
                        ["itemLink"] = 206,
                    },
                    [53] = 
                    {
                        ["price"] = 50200,
                        ["guild"] = 1,
                        ["buyer"] = 3,
                        ["wasKiosk"] = true,
                        ["seller"] = 58,
                        ["timestamp"] = 1633280918,
                        ["quant"] = 2,
                        ["id"] = "1692524049",
                        ["itemLink"] = 206,
                    },
                    [54] = 
                    {
                        ["price"] = 27000,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 343,
                        ["timestamp"] = 1633302519,
                        ["quant"] = 1,
                        ["id"] = "1692766699",
                        ["itemLink"] = 206,
                    },
                    [55] = 
                    {
                        ["price"] = 54400,
                        ["guild"] = 1,
                        ["buyer"] = 1252,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1632825531,
                        ["quant"] = 2,
                        ["id"] = "1688966341",
                        ["itemLink"] = 206,
                    },
                    [56] = 
                    {
                        ["price"] = 54400,
                        ["guild"] = 1,
                        ["buyer"] = 1252,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1632825532,
                        ["quant"] = 2,
                        ["id"] = "1688966343",
                        ["itemLink"] = 206,
                    },
                    [57] = 
                    {
                        ["price"] = 53693,
                        ["guild"] = 1,
                        ["buyer"] = 1252,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632825535,
                        ["quant"] = 2,
                        ["id"] = "1688966349",
                        ["itemLink"] = 206,
                    },
                    [58] = 
                    {
                        ["price"] = 53693,
                        ["guild"] = 1,
                        ["buyer"] = 1252,
                        ["wasKiosk"] = true,
                        ["seller"] = 21,
                        ["timestamp"] = 1632825535,
                        ["quant"] = 2,
                        ["id"] = "1688966351",
                        ["itemLink"] = 206,
                    },
                    [59] = 
                    {
                        ["price"] = 53694,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632852919,
                        ["quant"] = 2,
                        ["id"] = "1689166425",
                        ["itemLink"] = 206,
                    },
                    [60] = 
                    {
                        ["price"] = 53694,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632852919,
                        ["quant"] = 2,
                        ["id"] = "1689166433",
                        ["itemLink"] = 206,
                    },
                    [61] = 
                    {
                        ["price"] = 53694,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632852920,
                        ["quant"] = 2,
                        ["id"] = "1689166437",
                        ["itemLink"] = 206,
                    },
                    [62] = 
                    {
                        ["price"] = 53694,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632852923,
                        ["quant"] = 2,
                        ["id"] = "1689166451",
                        ["itemLink"] = 206,
                    },
                    [63] = 
                    {
                        ["price"] = 26847,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632852925,
                        ["quant"] = 1,
                        ["id"] = "1689166469",
                        ["itemLink"] = 206,
                    },
                    [64] = 
                    {
                        ["price"] = 53695,
                        ["guild"] = 1,
                        ["buyer"] = 321,
                        ["wasKiosk"] = true,
                        ["seller"] = 449,
                        ["timestamp"] = 1632852926,
                        ["quant"] = 2,
                        ["id"] = "1689166475",
                        ["itemLink"] = 206,
                    },
                    [65] = 
                    {
                        ["price"] = 25999,
                        ["guild"] = 1,
                        ["buyer"] = 2247,
                        ["wasKiosk"] = true,
                        ["seller"] = 158,
                        ["timestamp"] = 1632861548,
                        ["quant"] = 1,
                        ["id"] = "1689241455",
                        ["itemLink"] = 206,
                    },
                    [66] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 719,
                        ["wasKiosk"] = true,
                        ["seller"] = 244,
                        ["timestamp"] = 1632883748,
                        ["quant"] = 1,
                        ["id"] = "1689436059",
                        ["itemLink"] = 206,
                    },
                    [67] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 719,
                        ["wasKiosk"] = true,
                        ["seller"] = 244,
                        ["timestamp"] = 1632883748,
                        ["quant"] = 1,
                        ["id"] = "1689436063",
                        ["itemLink"] = 206,
                    },
                    [68] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 719,
                        ["wasKiosk"] = true,
                        ["seller"] = 244,
                        ["timestamp"] = 1632883749,
                        ["quant"] = 1,
                        ["id"] = "1689436065",
                        ["itemLink"] = 206,
                    },
                    [69] = 
                    {
                        ["price"] = 28000,
                        ["guild"] = 1,
                        ["buyer"] = 518,
                        ["wasKiosk"] = true,
                        ["seller"] = 62,
                        ["timestamp"] = 1632884743,
                        ["quant"] = 1,
                        ["id"] = "1689448971",
                        ["itemLink"] = 206,
                    },
                    [70] = 
                    {
                        ["price"] = 29500,
                        ["guild"] = 1,
                        ["buyer"] = 2401,
                        ["wasKiosk"] = true,
                        ["seller"] = 276,
                        ["timestamp"] = 1632887762,
                        ["quant"] = 1,
                        ["id"] = "1689477323",
                        ["itemLink"] = 206,
                    },
                    [71] = 
                    {
                        ["price"] = 28999,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632912749,
                        ["quant"] = 1,
                        ["id"] = "1689611225",
                        ["itemLink"] = 206,
                    },
                    [72] = 
                    {
                        ["price"] = 28999,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632912750,
                        ["quant"] = 1,
                        ["id"] = "1689611231",
                        ["itemLink"] = 206,
                    },
                    [73] = 
                    {
                        ["price"] = 28999,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632912750,
                        ["quant"] = 1,
                        ["id"] = "1689611233",
                        ["itemLink"] = 206,
                    },
                    [74] = 
                    {
                        ["price"] = 28999,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632912751,
                        ["quant"] = 1,
                        ["id"] = "1689611237",
                        ["itemLink"] = 206,
                    },
                    [75] = 
                    {
                        ["price"] = 28999,
                        ["guild"] = 1,
                        ["buyer"] = 273,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632912759,
                        ["quant"] = 1,
                        ["id"] = "1689611259",
                        ["itemLink"] = 206,
                    },
                    [76] = 
                    {
                        ["price"] = 26000,
                        ["guild"] = 1,
                        ["buyer"] = 2626,
                        ["wasKiosk"] = true,
                        ["seller"] = 343,
                        ["timestamp"] = 1632960283,
                        ["quant"] = 1,
                        ["id"] = "1689961901",
                        ["itemLink"] = 206,
                    },
                    [77] = 
                    {
                        ["price"] = 28500,
                        ["guild"] = 1,
                        ["buyer"] = 2626,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632960297,
                        ["quant"] = 1,
                        ["id"] = "1689961963",
                        ["itemLink"] = 206,
                    },
                    [78] = 
                    {
                        ["price"] = 28500,
                        ["guild"] = 1,
                        ["buyer"] = 2626,
                        ["wasKiosk"] = true,
                        ["seller"] = 295,
                        ["timestamp"] = 1632960299,
                        ["quant"] = 1,
                        ["id"] = "1689961975",
                        ["itemLink"] = 206,
                    },
                    [79] = 
                    {
                        ["price"] = 28999,
                        ["guild"] = 1,
                        ["buyer"] = 2671,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632967918,
                        ["quant"] = 1,
                        ["id"] = "1690033889",
                        ["itemLink"] = 206,
                    },
                    [80] = 
                    {
                        ["price"] = 28999,
                        ["guild"] = 1,
                        ["buyer"] = 2671,
                        ["wasKiosk"] = true,
                        ["seller"] = 56,
                        ["timestamp"] = 1632967919,
                        ["quant"] = 1,
                        ["id"] = "1690033905",
                        ["itemLink"] = 206,
                    },
                },
                ["totalCount"] = 80,
                ["itemAdderText"] = "rr01 white normal materials weapon trait nirnhoned",
            },
        },
        [171885] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 103: Black Fin Legion Gloves",
                ["oldestTime"] = 1632856449,
                ["wasAltered"] = true,
                ["newestTime"] = 1633292530,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 60000,
                        ["guild"] = 1,
                        ["buyer"] = 186,
                        ["wasKiosk"] = true,
                        ["seller"] = 43,
                        ["timestamp"] = 1632972225,
                        ["quant"] = 1,
                        ["id"] = "1690078347",
                        ["itemLink"] = 199,
                    },
                    [2] = 
                    {
                        ["price"] = 62699,
                        ["guild"] = 1,
                        ["buyer"] = 281,
                        ["wasKiosk"] = false,
                        ["seller"] = 43,
                        ["timestamp"] = 1633021600,
                        ["quant"] = 1,
                        ["id"] = "1690379855",
                        ["itemLink"] = 199,
                    },
                    [3] = 
                    {
                        ["price"] = 43000,
                        ["guild"] = 1,
                        ["buyer"] = 1989,
                        ["wasKiosk"] = true,
                        ["seller"] = 624,
                        ["timestamp"] = 1633292530,
                        ["quant"] = 1,
                        ["id"] = "1692657907",
                        ["itemLink"] = 199,
                    },
                    [4] = 
                    {
                        ["price"] = 50000,
                        ["guild"] = 1,
                        ["buyer"] = 2236,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1632856449,
                        ["quant"] = 1,
                        ["id"] = "1689201419",
                        ["itemLink"] = 199,
                    },
                    [5] = 
                    {
                        ["price"] = 65000,
                        ["guild"] = 1,
                        ["buyer"] = 2626,
                        ["wasKiosk"] = true,
                        ["seller"] = 397,
                        ["timestamp"] = 1632960389,
                        ["quant"] = 1,
                        ["id"] = "1689962625",
                        ["itemLink"] = 199,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [151773] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_els_str_merchantdeck001.dds",
                ["itemDesc"] = "Elsweyr Platform, Wooden Large",
                ["oldestTime"] = 1633116964,
                ["wasAltered"] = true,
                ["newestTime"] = 1633238362,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 30000,
                        ["guild"] = 1,
                        ["buyer"] = 1029,
                        ["wasKiosk"] = true,
                        ["seller"] = 311,
                        ["timestamp"] = 1633116964,
                        ["quant"] = 2,
                        ["id"] = "1691084497",
                        ["itemLink"] = 1410,
                    },
                    [2] = 
                    {
                        ["price"] = 15000,
                        ["guild"] = 1,
                        ["buyer"] = 1513,
                        ["wasKiosk"] = true,
                        ["seller"] = 312,
                        ["timestamp"] = 1633204140,
                        ["quant"] = 1,
                        ["id"] = "1691834633",
                        ["itemLink"] = 1410,
                    },
                    [3] = 
                    {
                        ["price"] = 8835,
                        ["guild"] = 1,
                        ["buyer"] = 1749,
                        ["wasKiosk"] = true,
                        ["seller"] = 99,
                        ["timestamp"] = 1633238362,
                        ["quant"] = 1,
                        ["id"] = "1692187935",
                        ["itemLink"] = 1410,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 green fine furnishings structures",
            },
        },
        [140510] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 67: Welkynar Swords",
                ["oldestTime"] = 1633269923,
                ["wasAltered"] = true,
                ["newestTime"] = 1633269923,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 12000,
                        ["guild"] = 1,
                        ["buyer"] = 1871,
                        ["wasKiosk"] = true,
                        ["seller"] = 1039,
                        ["timestamp"] = 1633269923,
                        ["quant"] = 1,
                        ["id"] = "1692403709",
                        ["itemLink"] = 2663,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [130015] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 52: Redoran Chests",
                ["oldestTime"] = 1633177655,
                ["wasAltered"] = true,
                ["newestTime"] = 1633177655,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 24999,
                        ["guild"] = 1,
                        ["buyer"] = 202,
                        ["wasKiosk"] = false,
                        ["seller"] = 149,
                        ["timestamp"] = 1633177655,
                        ["quant"] = 1,
                        ["id"] = "1691567971",
                        ["itemLink"] = 1906,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [119520] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_blacksmithing4.dds",
                ["itemDesc"] = "Diagram: Cage, Covered",
                ["oldestTime"] = 1633302810,
                ["wasAltered"] = true,
                ["newestTime"] = 1633302810,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 2,
                        ["buyer"] = 127,
                        ["wasKiosk"] = false,
                        ["seller"] = 119,
                        ["timestamp"] = 1633302810,
                        ["quant"] = 1,
                        ["id"] = "1692769877",
                        ["itemLink"] = 160,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic consumable recipe",
            },
        },
        [45090] = 
        {
            ["50:16:3:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_imperial_1hsword_d.dds",
                ["itemDesc"] = "Rubedite Sword of Shock",
                ["oldestTime"] = 1633185916,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185916,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 950,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633185916,
                        ["quant"] = 1,
                        ["id"] = "1691639801",
                        ["itemLink"] = 2013,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon sword one-handed precise",
            },
            ["50:16:1:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ashlanderv_1hsword_a.dds",
                ["itemDesc"] = "Rubedite Sword",
                ["oldestTime"] = 1633041001,
                ["wasAltered"] = true,
                ["newestTime"] = 1633041001,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 141,
                        ["guild"] = 1,
                        ["buyer"] = 631,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633041001,
                        ["quant"] = 1,
                        ["id"] = "1690521061",
                        ["itemLink"] = 802,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal weapon sword one-handed precise",
            },
            ["50:16:2:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_1hsword_d.dds",
                ["itemDesc"] = "Rubedite Sword of Shock",
                ["oldestTime"] = 1633185892,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185892,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 144,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633185892,
                        ["quant"] = 1,
                        ["id"] = "1691639385",
                        ["itemLink"] = 1994,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine weapon sword one-handed precise",
            },
        },
        [177222] = 
        {
            ["1:0:4:42:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_infernostaff.dds",
                ["itemDesc"] = "Companion's Inferno Staff",
                ["oldestTime"] = 1633204089,
                ["wasAltered"] = true,
                ["newestTime"] = 1633204089,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25000,
                        ["guild"] = 1,
                        ["buyer"] = 1512,
                        ["wasKiosk"] = true,
                        ["seller"] = 583,
                        ["timestamp"] = 1633204089,
                        ["quant"] = 1,
                        ["id"] = "1691834263",
                        ["itemLink"] = 2233,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic weapon flame staff two-handed vigorous",
            },
        },
        [43747] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Clockwork City Treasure Map II",
                ["oldestTime"] = 1633149336,
                ["wasAltered"] = true,
                ["newestTime"] = 1633149336,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 480,
                        ["guild"] = 1,
                        ["buyer"] = 1250,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1633149336,
                        ["quant"] = 1,
                        ["id"] = "1691385135",
                        ["itemLink"] = 1700,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior miscellaneous trophy",
            },
        },
        [135140] = 
        {
            ["1:0:1:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_copper_refined.dds",
                ["itemDesc"] = "Copper Ounce",
                ["oldestTime"] = 1633017539,
                ["wasAltered"] = true,
                ["newestTime"] = 1633179779,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 750,
                        ["guild"] = 1,
                        ["buyer"] = 487,
                        ["wasKiosk"] = true,
                        ["seller"] = 46,
                        ["timestamp"] = 1633017539,
                        ["quant"] = 25,
                        ["id"] = "1690345269",
                        ["itemLink"] = 553,
                    },
                    [2] = 
                    {
                        ["price"] = 285,
                        ["guild"] = 1,
                        ["buyer"] = 387,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1633179779,
                        ["quant"] = 25,
                        ["id"] = "1691583943",
                        ["itemLink"] = 553,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 white normal materials",
            },
        },
        [86757] = 
        {
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_shield_d.dds",
                ["itemDesc"] = "Shield of Necropotence",
                ["oldestTime"] = 1632970981,
                ["wasAltered"] = true,
                ["newestTime"] = 1632970981,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 176,
                        ["wasKiosk"] = true,
                        ["seller"] = 177,
                        ["timestamp"] = 1632970981,
                        ["quant"] = 1,
                        ["id"] = "1690065583",
                        ["itemLink"] = 189,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic apparel weapon set necropotence shield off hand infused",
            },
        },
        [175782] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_summerset_completed_report.dds",
                ["itemDesc"] = "Style Page: Old Orsinium Mace",
                ["oldestTime"] = 1632769500,
                ["wasAltered"] = true,
                ["newestTime"] = 1632830844,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 2,
                        ["buyer"] = 124,
                        ["wasKiosk"] = false,
                        ["seller"] = 130,
                        ["timestamp"] = 1632769500,
                        ["quant"] = 1,
                        ["id"] = "1688524991",
                        ["itemLink"] = 122,
                    },
                    [2] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 84,
                        ["wasKiosk"] = false,
                        ["seller"] = 649,
                        ["timestamp"] = 1632830844,
                        ["quant"] = 1,
                        ["id"] = "1689002929",
                        ["itemLink"] = 122,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 gold legendary consumable collectible",
            },
        },
        [79335] = 
        {
            ["50:16:4:3:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_1hsword_c.dds",
                ["itemDesc"] = "Briarheart Sword",
                ["oldestTime"] = 1633220201,
                ["wasAltered"] = true,
                ["newestTime"] = 1633220201,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 19500,
                        ["guild"] = 1,
                        ["buyer"] = 1608,
                        ["wasKiosk"] = true,
                        ["seller"] = 515,
                        ["timestamp"] = 1633220201,
                        ["quant"] = 1,
                        ["id"] = "1692013983",
                        ["itemLink"] = 2343,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set briarheart sword one-handed precise",
            },
        },
        [123737] = 
        {
            ["50:16:4:16:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_light_feet_a.dds",
                ["itemDesc"] = "Wizard's Riposte Shoes",
                ["oldestTime"] = 1633200757,
                ["wasAltered"] = true,
                ["newestTime"] = 1633200757,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 1491,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633200757,
                        ["quant"] = 1,
                        ["id"] = "1691797271",
                        ["itemLink"] = 2199,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set wizard's riposte feet infused",
            },
        },
        [119017] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_2.dds",
                ["itemDesc"] = "Blueprint: Orcish Bar, Long Block",
                ["oldestTime"] = 1633158050,
                ["wasAltered"] = true,
                ["newestTime"] = 1633158050,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 100,
                        ["guild"] = 1,
                        ["buyer"] = 1293,
                        ["wasKiosk"] = true,
                        ["seller"] = 1108,
                        ["timestamp"] = 1633158050,
                        ["quant"] = 1,
                        ["id"] = "1691454629",
                        ["itemLink"] = 1780,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [27245] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_book_001.dds",
                ["itemDesc"] = "Crafting Motif 2: Dark Elf Style",
                ["oldestTime"] = 1632820736,
                ["wasAltered"] = true,
                ["newestTime"] = 1633196359,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 180,
                        ["guild"] = 1,
                        ["buyer"] = 940,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1633196359,
                        ["quant"] = 1,
                        ["id"] = "1691752965",
                        ["itemLink"] = 2149,
                    },
                    [2] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 2103,
                        ["wasKiosk"] = true,
                        ["seller"] = 491,
                        ["timestamp"] = 1632820736,
                        ["quant"] = 1,
                        ["id"] = "1688947403",
                        ["itemLink"] = 2149,
                    },
                    [3] = 
                    {
                        ["price"] = 1500,
                        ["guild"] = 1,
                        ["buyer"] = 2103,
                        ["wasKiosk"] = true,
                        ["seller"] = 51,
                        ["timestamp"] = 1632899018,
                        ["quant"] = 1,
                        ["id"] = "1689552501",
                        ["itemLink"] = 2149,
                    },
                },
                ["totalCount"] = 3,
                ["itemAdderText"] = "rr01 blue superior consumable motif",
            },
        },
        [123842] = 
        {
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_ordinator_light_feet_a.dds",
                ["itemDesc"] = "Wizard's Riposte Shoes",
                ["oldestTime"] = 1633195728,
                ["wasAltered"] = true,
                ["newestTime"] = 1633195728,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1452,
                        ["wasKiosk"] = true,
                        ["seller"] = 1239,
                        ["timestamp"] = 1633195728,
                        ["quant"] = 1,
                        ["id"] = "1691748705",
                        ["itemLink"] = 2146,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set wizard's riposte feet invigorating",
            },
        },
        [152044] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_woodworking_3.dds",
                ["itemDesc"] = "Blueprint: Elsweyr Bookshelf, Short Elegant",
                ["oldestTime"] = 1632939688,
                ["wasAltered"] = true,
                ["newestTime"] = 1633033721,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8500,
                        ["guild"] = 1,
                        ["buyer"] = 580,
                        ["wasKiosk"] = true,
                        ["seller"] = 52,
                        ["timestamp"] = 1633033721,
                        ["quant"] = 1,
                        ["id"] = "1690467645",
                        ["itemLink"] = 751,
                    },
                    [2] = 
                    {
                        ["price"] = 13000,
                        ["guild"] = 1,
                        ["buyer"] = 2540,
                        ["wasKiosk"] = true,
                        ["seller"] = 288,
                        ["timestamp"] = 1632939688,
                        ["quant"] = 1,
                        ["id"] = "1689792899",
                        ["itemLink"] = 751,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [97773] = 
        {
            ["50:16:4:23:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_neck_a.dds",
                ["itemDesc"] = "Necklace of Night Terror",
                ["oldestTime"] = 1633087212,
                ["wasAltered"] = true,
                ["newestTime"] = 1633087212,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 4537,
                        ["guild"] = 1,
                        ["buyer"] = 906,
                        ["wasKiosk"] = true,
                        ["seller"] = 721,
                        ["timestamp"] = 1633087212,
                        ["quant"] = 1,
                        ["id"] = "1690871265",
                        ["itemLink"] = 1227,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic jewelry apparel set night terror neck robust",
            },
        },
        [135150] = 
        {
            ["1:0:5:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/jewelrycrafting_booster_refined_chromium.dds",
                ["itemDesc"] = "Chromium Plating",
                ["oldestTime"] = 1632840473,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311917,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 215000,
                        ["guild"] = 1,
                        ["buyer"] = 29,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633311917,
                        ["quant"] = 1,
                        ["id"] = "1692868741",
                        ["itemLink"] = 20,
                    },
                    [2] = 
                    {
                        ["price"] = 214999,
                        ["guild"] = 1,
                        ["buyer"] = 403,
                        ["wasKiosk"] = true,
                        ["seller"] = 34,
                        ["timestamp"] = 1633001218,
                        ["quant"] = 1,
                        ["id"] = "1690240363",
                        ["itemLink"] = 20,
                    },
                    [3] = 
                    {
                        ["price"] = 214950,
                        ["guild"] = 1,
                        ["buyer"] = 783,
                        ["wasKiosk"] = true,
                        ["seller"] = 63,
                        ["timestamp"] = 1633061134,
                        ["quant"] = 1,
                        ["id"] = "1690719491",
                        ["itemLink"] = 20,
                    },
                    [4] = 
                    {
                        ["price"] = 215000,
                        ["guild"] = 1,
                        ["buyer"] = 783,
                        ["wasKiosk"] = true,
                        ["seller"] = 146,
                        ["timestamp"] = 1633061135,
                        ["quant"] = 1,
                        ["id"] = "1690719501",
                        ["itemLink"] = 20,
                    },
                    [5] = 
                    {
                        ["price"] = 215000,
                        ["guild"] = 1,
                        ["buyer"] = 783,
                        ["wasKiosk"] = true,
                        ["seller"] = 146,
                        ["timestamp"] = 1633061135,
                        ["quant"] = 1,
                        ["id"] = "1690719507",
                        ["itemLink"] = 20,
                    },
                    [6] = 
                    {
                        ["price"] = 215000,
                        ["guild"] = 1,
                        ["buyer"] = 783,
                        ["wasKiosk"] = true,
                        ["seller"] = 510,
                        ["timestamp"] = 1633061137,
                        ["quant"] = 1,
                        ["id"] = "1690719523",
                        ["itemLink"] = 20,
                    },
                    [7] = 
                    {
                        ["price"] = 215000,
                        ["guild"] = 1,
                        ["buyer"] = 783,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633061137,
                        ["quant"] = 1,
                        ["id"] = "1690719529",
                        ["itemLink"] = 20,
                    },
                    [8] = 
                    {
                        ["price"] = 209999,
                        ["guild"] = 1,
                        ["buyer"] = 1228,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1633145904,
                        ["quant"] = 1,
                        ["id"] = "1691355721",
                        ["itemLink"] = 20,
                    },
                    [9] = 
                    {
                        ["price"] = 210000,
                        ["guild"] = 1,
                        ["buyer"] = 1228,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633145906,
                        ["quant"] = 1,
                        ["id"] = "1691355743",
                        ["itemLink"] = 20,
                    },
                    [10] = 
                    {
                        ["price"] = 210000,
                        ["guild"] = 1,
                        ["buyer"] = 1228,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633145910,
                        ["quant"] = 1,
                        ["id"] = "1691355775",
                        ["itemLink"] = 20,
                    },
                    [11] = 
                    {
                        ["price"] = 210000,
                        ["guild"] = 1,
                        ["buyer"] = 1228,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633145911,
                        ["quant"] = 1,
                        ["id"] = "1691355787",
                        ["itemLink"] = 20,
                    },
                    [12] = 
                    {
                        ["price"] = 212499,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 34,
                        ["timestamp"] = 1633165074,
                        ["quant"] = 1,
                        ["id"] = "1691496531",
                        ["itemLink"] = 20,
                    },
                    [13] = 
                    {
                        ["price"] = 217713,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 243,
                        ["timestamp"] = 1633165076,
                        ["quant"] = 1,
                        ["id"] = "1691496537",
                        ["itemLink"] = 20,
                    },
                    [14] = 
                    {
                        ["price"] = 217000,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 173,
                        ["timestamp"] = 1633165077,
                        ["quant"] = 1,
                        ["id"] = "1691496539",
                        ["itemLink"] = 20,
                    },
                    [15] = 
                    {
                        ["price"] = 217000,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 616,
                        ["timestamp"] = 1633165077,
                        ["quant"] = 1,
                        ["id"] = "1691496543",
                        ["itemLink"] = 20,
                    },
                    [16] = 
                    {
                        ["price"] = 216500,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 616,
                        ["timestamp"] = 1633165077,
                        ["quant"] = 1,
                        ["id"] = "1691496545",
                        ["itemLink"] = 20,
                    },
                    [17] = 
                    {
                        ["price"] = 216000,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 616,
                        ["timestamp"] = 1633165078,
                        ["quant"] = 1,
                        ["id"] = "1691496547",
                        ["itemLink"] = 20,
                    },
                    [18] = 
                    {
                        ["price"] = 215900,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 173,
                        ["timestamp"] = 1633165078,
                        ["quant"] = 1,
                        ["id"] = "1691496549",
                        ["itemLink"] = 20,
                    },
                    [19] = 
                    {
                        ["price"] = 215500,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 616,
                        ["timestamp"] = 1633165079,
                        ["quant"] = 1,
                        ["id"] = "1691496551",
                        ["itemLink"] = 20,
                    },
                    [20] = 
                    {
                        ["price"] = 214999,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 56,
                        ["timestamp"] = 1633165079,
                        ["quant"] = 1,
                        ["id"] = "1691496553",
                        ["itemLink"] = 20,
                    },
                    [21] = 
                    {
                        ["price"] = 212499,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 34,
                        ["timestamp"] = 1633165080,
                        ["quant"] = 1,
                        ["id"] = "1691496557",
                        ["itemLink"] = 20,
                    },
                    [22] = 
                    {
                        ["price"] = 212499,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 34,
                        ["timestamp"] = 1633165080,
                        ["quant"] = 1,
                        ["id"] = "1691496559",
                        ["itemLink"] = 20,
                    },
                    [23] = 
                    {
                        ["price"] = 200000,
                        ["guild"] = 1,
                        ["buyer"] = 1457,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633196726,
                        ["quant"] = 1,
                        ["id"] = "1691755693",
                        ["itemLink"] = 20,
                    },
                    [24] = 
                    {
                        ["price"] = 205000,
                        ["guild"] = 1,
                        ["buyer"] = 1457,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633196727,
                        ["quant"] = 1,
                        ["id"] = "1691755701",
                        ["itemLink"] = 20,
                    },
                    [25] = 
                    {
                        ["price"] = 205000,
                        ["guild"] = 1,
                        ["buyer"] = 1457,
                        ["wasKiosk"] = true,
                        ["seller"] = 1163,
                        ["timestamp"] = 1633196728,
                        ["quant"] = 1,
                        ["id"] = "1691755705",
                        ["itemLink"] = 20,
                    },
                    [26] = 
                    {
                        ["price"] = 215000,
                        ["guild"] = 1,
                        ["buyer"] = 511,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633203777,
                        ["quant"] = 1,
                        ["id"] = "1691830817",
                        ["itemLink"] = 20,
                    },
                    [27] = 
                    {
                        ["price"] = 214000,
                        ["guild"] = 1,
                        ["buyer"] = 1568,
                        ["wasKiosk"] = true,
                        ["seller"] = 148,
                        ["timestamp"] = 1633213546,
                        ["quant"] = 1,
                        ["id"] = "1691945445",
                        ["itemLink"] = 20,
                    },
                    [28] = 
                    {
                        ["price"] = 210000,
                        ["guild"] = 1,
                        ["buyer"] = 1318,
                        ["wasKiosk"] = false,
                        ["seller"] = 343,
                        ["timestamp"] = 1633302543,
                        ["quant"] = 1,
                        ["id"] = "1692766991",
                        ["itemLink"] = 20,
                    },
                    [29] = 
                    {
                        ["price"] = 210000,
                        ["guild"] = 1,
                        ["buyer"] = 2179,
                        ["wasKiosk"] = true,
                        ["seller"] = 1535,
                        ["timestamp"] = 1632840473,
                        ["quant"] = 1,
                        ["id"] = "1689063083",
                        ["itemLink"] = 20,
                    },
                    [30] = 
                    {
                        ["price"] = 210000,
                        ["guild"] = 1,
                        ["buyer"] = 2179,
                        ["wasKiosk"] = true,
                        ["seller"] = 95,
                        ["timestamp"] = 1632840474,
                        ["quant"] = 1,
                        ["id"] = "1689063087",
                        ["itemLink"] = 20,
                    },
                    [31] = 
                    {
                        ["price"] = 214990,
                        ["guild"] = 1,
                        ["buyer"] = 1614,
                        ["wasKiosk"] = true,
                        ["seller"] = 76,
                        ["timestamp"] = 1632845933,
                        ["quant"] = 1,
                        ["id"] = "1689109811",
                        ["itemLink"] = 20,
                    },
                    [32] = 
                    {
                        ["price"] = 200000,
                        ["guild"] = 1,
                        ["buyer"] = 1354,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1632963591,
                        ["quant"] = 1,
                        ["id"] = "1689992003",
                        ["itemLink"] = 20,
                    },
                },
                ["totalCount"] = 32,
                ["itemAdderText"] = "rr01 gold legendary materials plating",
            },
        },
        [45551] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Clamberskull",
                ["oldestTime"] = 1632913051,
                ["wasAltered"] = true,
                ["newestTime"] = 1632913051,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 700,
                        ["guild"] = 1,
                        ["buyer"] = 2471,
                        ["wasKiosk"] = true,
                        ["seller"] = 227,
                        ["timestamp"] = 1632913051,
                        ["quant"] = 1,
                        ["id"] = "1689612451",
                        ["itemLink"] = 3625,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [45285] = 
        {
            ["50:16:3:8:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_bow_d.dds",
                ["itemDesc"] = "Ruby Ash Bow of Shock",
                ["oldestTime"] = 1633180213,
                ["wasAltered"] = true,
                ["newestTime"] = 1633180213,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 339,
                        ["guild"] = 1,
                        ["buyer"] = 1363,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633180213,
                        ["quant"] = 1,
                        ["id"] = "1691586771",
                        ["itemLink"] = 1923,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior weapon bow two-handed decisive",
            },
        },
        [160754] = 
        {
            ["50:16:3:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_blackreachexlgt_waist.dds",
                ["itemDesc"] = "Sash of Winter's Respite",
                ["oldestTime"] = 1633060772,
                ["wasAltered"] = true,
                ["newestTime"] = 1633060772,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 1900,
                        ["guild"] = 1,
                        ["buyer"] = 790,
                        ["wasKiosk"] = true,
                        ["seller"] = 474,
                        ["timestamp"] = 1633060772,
                        ["quant"] = 1,
                        ["id"] = "1690716705",
                        ["itemLink"] = 1022,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set winter's respite waist invigorating",
            },
        },
        [180466] = 
        {
            ["50:16:3:18:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_daggerfall_light_head_a.dds",
                ["itemDesc"] = "Hat of Dark Convergence",
                ["oldestTime"] = 1633313774,
                ["wasAltered"] = true,
                ["newestTime"] = 1633313774,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2222,
                        ["guild"] = 1,
                        ["buyer"] = 64,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633313774,
                        ["quant"] = 1,
                        ["id"] = "1692888489",
                        ["itemLink"] = 48,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 blue superior light apparel set dark convergence head divines",
            },
        },
        [45043] = 
        {
            ["50:16:2:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_medium_hands_d.dds",
                ["itemDesc"] = "Rubedo Leather Bracers of Health",
                ["oldestTime"] = 1633023007,
                ["wasAltered"] = true,
                ["newestTime"] = 1633023007,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 525,
                        ["wasKiosk"] = true,
                        ["seller"] = 526,
                        ["timestamp"] = 1633023007,
                        ["quant"] = 1,
                        ["id"] = "1690390655",
                        ["itemLink"] = 630,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 green fine medium apparel hands sturdy",
            },
            ["50:16:1:11:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_medium_hands_d.dds",
                ["itemDesc"] = "Rubedo Leather Bracers",
                ["oldestTime"] = 1632936846,
                ["wasAltered"] = true,
                ["newestTime"] = 1632936846,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 600,
                        ["guild"] = 1,
                        ["buyer"] = 226,
                        ["wasKiosk"] = false,
                        ["seller"] = 379,
                        ["timestamp"] = 1632936846,
                        ["quant"] = 1,
                        ["id"] = "1689774081",
                        ["itemLink"] = 3749,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 white normal medium apparel hands sturdy",
            },
        },
        [45300] = 
        {
            ["50:15:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_1hsword_d.dds",
                ["itemDesc"] = "Rubedite Sword",
                ["oldestTime"] = 1632826457,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309692,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633009379,
                        ["quant"] = 1,
                        ["id"] = "1690285563",
                        ["itemLink"] = 490,
                    },
                    [2] = 
                    {
                        ["price"] = 338,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1633009382,
                        ["quant"] = 1,
                        ["id"] = "1690285609",
                        ["itemLink"] = 494,
                    },
                    [3] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633309692,
                        ["quant"] = 1,
                        ["id"] = "1692845807",
                        ["itemLink"] = 2974,
                    },
                    [4] = 
                    {
                        ["price"] = 195,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632826457,
                        ["quant"] = 1,
                        ["id"] = "1688971645",
                        ["itemLink"] = 3036,
                    },
                    [5] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 2516,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1632930822,
                        ["quant"] = 1,
                        ["id"] = "1689728237",
                        ["itemLink"] = 2974,
                    },
                    [6] = 
                    {
                        ["price"] = 158,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 97,
                        ["timestamp"] = 1632956371,
                        ["quant"] = 1,
                        ["id"] = "1689931115",
                        ["itemLink"] = 3874,
                    },
                    [7] = 
                    {
                        ["price"] = 318,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632956386,
                        ["quant"] = 1,
                        ["id"] = "1689931401",
                        ["itemLink"] = 3883,
                    },
                    [8] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2605,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632956402,
                        ["quant"] = 1,
                        ["id"] = "1689931623",
                        ["itemLink"] = 3874,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "cp150 white normal weapon sword one-handed intricate",
            },
            ["50:16:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_khajiit_1hsword_d.dds",
                ["itemDesc"] = "Rubedite Sword",
                ["oldestTime"] = 1632838991,
                ["wasAltered"] = true,
                ["newestTime"] = 1633185908,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 298,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633084010,
                        ["quant"] = 1,
                        ["id"] = "1690854489",
                        ["itemLink"] = 1158,
                    },
                    [2] = 
                    {
                        ["price"] = 340,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633084012,
                        ["quant"] = 1,
                        ["id"] = "1690854503",
                        ["itemLink"] = 1159,
                    },
                    [3] = 
                    {
                        ["price"] = 200,
                        ["guild"] = 1,
                        ["buyer"] = 1238,
                        ["wasKiosk"] = true,
                        ["seller"] = 107,
                        ["timestamp"] = 1633146946,
                        ["quant"] = 1,
                        ["id"] = "1691365497",
                        ["itemLink"] = 1675,
                    },
                    [4] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 1395,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1633185908,
                        ["quant"] = 1,
                        ["id"] = "1691639721",
                        ["itemLink"] = 2007,
                    },
                    [5] = 
                    {
                        ["price"] = 340,
                        ["guild"] = 1,
                        ["buyer"] = 2167,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632838991,
                        ["quant"] = 1,
                        ["id"] = "1689054205",
                        ["itemLink"] = 3120,
                    },
                    [6] = 
                    {
                        ["price"] = 340,
                        ["guild"] = 1,
                        ["buyer"] = 2167,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1632838992,
                        ["quant"] = 1,
                        ["id"] = "1689054211",
                        ["itemLink"] = 3121,
                    },
                    [7] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 162,
                        ["timestamp"] = 1632865272,
                        ["quant"] = 1,
                        ["id"] = "1689266435",
                        ["itemLink"] = 3330,
                    },
                    [8] = 
                    {
                        ["price"] = 984,
                        ["guild"] = 1,
                        ["buyer"] = 2260,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1632865273,
                        ["quant"] = 1,
                        ["id"] = "1689266447",
                        ["itemLink"] = 1159,
                    },
                    [9] = 
                    {
                        ["price"] = 291,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1632885681,
                        ["quant"] = 1,
                        ["id"] = "1689459775",
                        ["itemLink"] = 3517,
                    },
                    [10] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 768,
                        ["wasKiosk"] = true,
                        ["seller"] = 218,
                        ["timestamp"] = 1632885684,
                        ["quant"] = 1,
                        ["id"] = "1689459803",
                        ["itemLink"] = 1159,
                    },
                    [11] = 
                    {
                        ["price"] = 500,
                        ["guild"] = 1,
                        ["buyer"] = 2424,
                        ["wasKiosk"] = true,
                        ["seller"] = 444,
                        ["timestamp"] = 1632897935,
                        ["quant"] = 1,
                        ["id"] = "1689547909",
                        ["itemLink"] = 3517,
                    },
                },
                ["totalCount"] = 11,
                ["itemAdderText"] = "cp160 white normal weapon sword one-handed intricate",
            },
        },
        [134485] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/crafting_planfurniture_alchemy2.dds",
                ["itemDesc"] = "Formula: Fabricant Shrub, Copper",
                ["oldestTime"] = 1633173974,
                ["wasAltered"] = true,
                ["newestTime"] = 1633173974,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 20000,
                        ["guild"] = 1,
                        ["buyer"] = 1349,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1633173974,
                        ["quant"] = 1,
                        ["id"] = "1691541261",
                        ["itemLink"] = 1895,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine consumable recipe",
            },
        },
        [45302] = 
        {
            ["1:0:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_dunmer_2hhammer_a.dds",
                ["itemDesc"] = "Iron Maul",
                ["oldestTime"] = 1633084672,
                ["wasAltered"] = true,
                ["newestTime"] = 1633084672,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 150,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 379,
                        ["timestamp"] = 1633084672,
                        ["quant"] = 1,
                        ["id"] = "1690857201",
                        ["itemLink"] = 1200,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 white normal weapon mace two-handed intricate",
            },
            ["50:16:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_bosmer_2hhammer_d.dds",
                ["itemDesc"] = "Rubedite Maul",
                ["oldestTime"] = 1632826466,
                ["wasAltered"] = true,
                ["newestTime"] = 1633084025,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 400,
                        ["guild"] = 1,
                        ["buyer"] = 440,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633009384,
                        ["quant"] = 1,
                        ["id"] = "1690285615",
                        ["itemLink"] = 495,
                    },
                    [2] = 
                    {
                        ["price"] = 285,
                        ["guild"] = 1,
                        ["buyer"] = 556,
                        ["wasKiosk"] = true,
                        ["seller"] = 242,
                        ["timestamp"] = 1633028897,
                        ["quant"] = 1,
                        ["id"] = "1690436707",
                        ["itemLink"] = 698,
                    },
                    [3] = 
                    {
                        ["price"] = 228,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 257,
                        ["timestamp"] = 1633084001,
                        ["quant"] = 1,
                        ["id"] = "1690854427",
                        ["itemLink"] = 1150,
                    },
                    [4] = 
                    {
                        ["price"] = 295,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 67,
                        ["timestamp"] = 1633084009,
                        ["quant"] = 1,
                        ["id"] = "1690854483",
                        ["itemLink"] = 1157,
                    },
                    [5] = 
                    {
                        ["price"] = 984,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 10,
                        ["timestamp"] = 1633084025,
                        ["quant"] = 1,
                        ["id"] = "1690854567",
                        ["itemLink"] = 1166,
                    },
                    [6] = 
                    {
                        ["price"] = 220,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 389,
                        ["timestamp"] = 1632826466,
                        ["quant"] = 1,
                        ["id"] = "1688971679",
                        ["itemLink"] = 3041,
                    },
                    [7] = 
                    {
                        ["price"] = 275,
                        ["guild"] = 1,
                        ["buyer"] = 2120,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1632826500,
                        ["quant"] = 1,
                        ["id"] = "1688972087",
                        ["itemLink"] = 698,
                    },
                    [8] = 
                    {
                        ["price"] = 350,
                        ["guild"] = 1,
                        ["buyer"] = 1365,
                        ["wasKiosk"] = true,
                        ["seller"] = 234,
                        ["timestamp"] = 1632838954,
                        ["quant"] = 1,
                        ["id"] = "1689053961",
                        ["itemLink"] = 698,
                    },
                },
                ["totalCount"] = 8,
                ["itemAdderText"] = "cp160 white normal weapon mace two-handed intricate",
            },
            ["50:15:1:9:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_breton_2hhammer_d.dds",
                ["itemDesc"] = "Rubedite Maul",
                ["oldestTime"] = 1632843152,
                ["wasAltered"] = true,
                ["newestTime"] = 1633309706,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 275,
                        ["guild"] = 1,
                        ["buyer"] = 895,
                        ["wasKiosk"] = true,
                        ["seller"] = 332,
                        ["timestamp"] = 1633084675,
                        ["quant"] = 1,
                        ["id"] = "1690857259",
                        ["itemLink"] = 1202,
                    },
                    [2] = 
                    {
                        ["price"] = 250,
                        ["guild"] = 1,
                        ["buyer"] = 1146,
                        ["wasKiosk"] = true,
                        ["seller"] = 156,
                        ["timestamp"] = 1633309706,
                        ["quant"] = 1,
                        ["id"] = "1692845961",
                        ["itemLink"] = 2982,
                    },
                    [3] = 
                    {
                        ["price"] = 422,
                        ["guild"] = 1,
                        ["buyer"] = 516,
                        ["wasKiosk"] = true,
                        ["seller"] = 202,
                        ["timestamp"] = 1632843152,
                        ["quant"] = 1,
                        ["id"] = "1689085073",
                        ["itemLink"] = 3169,
                    },
                    [4] = 
                    {
                        ["price"] = 296,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632950115,
                        ["quant"] = 1,
                        ["id"] = "1689875043",
                        ["itemLink"] = 3809,
                    },
                    [5] = 
                    {
                        ["price"] = 296,
                        ["guild"] = 1,
                        ["buyer"] = 572,
                        ["wasKiosk"] = true,
                        ["seller"] = 1664,
                        ["timestamp"] = 1632950115,
                        ["quant"] = 1,
                        ["id"] = "1689875051",
                        ["itemLink"] = 3810,
                    },
                },
                ["totalCount"] = 5,
                ["itemAdderText"] = "cp150 white normal weapon mace two-handed intricate",
            },
        },
        [120753] = 
        {
            ["1:0:2:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_veg_aqa_kelp_pile001.dds",
                ["itemDesc"] = "Kelp, Green Pile",
                ["oldestTime"] = 1633170857,
                ["wasAltered"] = true,
                ["newestTime"] = 1633220091,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1337,
                        ["wasKiosk"] = true,
                        ["seller"] = 30,
                        ["timestamp"] = 1633170857,
                        ["quant"] = 1,
                        ["id"] = "1691524439",
                        ["itemLink"] = 1881,
                    },
                    [2] = 
                    {
                        ["price"] = 6000,
                        ["guild"] = 1,
                        ["buyer"] = 1609,
                        ["wasKiosk"] = true,
                        ["seller"] = 512,
                        ["timestamp"] = 1633220091,
                        ["quant"] = 3,
                        ["id"] = "1692013293",
                        ["itemLink"] = 1881,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 green fine furnishings conservatory",
            },
        },
        [176120] = 
        {
            ["1:0:2:44:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/companions_u30_equipment_shoulders_medium.dds",
                ["itemDesc"] = "Companion's Arm Cops",
                ["oldestTime"] = 1633145640,
                ["wasAltered"] = true,
                ["newestTime"] = 1633145640,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 281,
                        ["guild"] = 1,
                        ["buyer"] = 1227,
                        ["wasKiosk"] = true,
                        ["seller"] = 331,
                        ["timestamp"] = 1633145640,
                        ["quant"] = 1,
                        ["id"] = "1691353021",
                        ["itemLink"] = 1650,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 green fine medium apparel shoulders prolific",
            },
        },
        [147705] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_letter_002.dds",
                ["itemDesc"] = "Crafting Motif 73: Anequina Gloves",
                ["oldestTime"] = 1632939825,
                ["wasAltered"] = true,
                ["newestTime"] = 1633209392,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 8000,
                        ["guild"] = 1,
                        ["buyer"] = 1547,
                        ["wasKiosk"] = true,
                        ["seller"] = 1548,
                        ["timestamp"] = 1633209392,
                        ["quant"] = 1,
                        ["id"] = "1691898799",
                        ["itemLink"] = 2270,
                    },
                    [2] = 
                    {
                        ["price"] = 6900,
                        ["guild"] = 1,
                        ["buyer"] = 1872,
                        ["wasKiosk"] = true,
                        ["seller"] = 633,
                        ["timestamp"] = 1632939825,
                        ["quant"] = 1,
                        ["id"] = "1689793899",
                        ["itemLink"] = 2270,
                    },
                },
                ["totalCount"] = 2,
                ["itemAdderText"] = "rr01 purple epic consumable motif",
            },
        },
        [117793] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_red_fur_varrectangulartablelarge003.dds",
                ["itemDesc"] = "Redguard Table, Formal",
                ["oldestTime"] = 1633166402,
                ["wasAltered"] = true,
                ["newestTime"] = 1633166402,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 13500,
                        ["guild"] = 1,
                        ["buyer"] = 1324,
                        ["wasKiosk"] = true,
                        ["seller"] = 508,
                        ["timestamp"] = 1633166402,
                        ["quant"] = 1,
                        ["id"] = "1691502615",
                        ["itemLink"] = 1861,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings dining",
            },
        },
        [126459] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/housing_vrd_inc_hlatablerunner005.dds",
                ["itemDesc"] = "Redoran Table Runner, Gilded Ochre",
                ["oldestTime"] = 1633118859,
                ["wasAltered"] = true,
                ["newestTime"] = 1633118859,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 25606,
                        ["guild"] = 1,
                        ["buyer"] = 1040,
                        ["wasKiosk"] = true,
                        ["seller"] = 236,
                        ["timestamp"] = 1633118859,
                        ["quant"] = 2,
                        ["id"] = "1691097525",
                        ["itemLink"] = 1426,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 purple epic furnishings parlor",
            },
        },
        [98812] = 
        {
            ["50:16:4:17:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_argonian_light_feet_d.dds",
                ["itemDesc"] = "Shoes of Hist Sap",
                ["oldestTime"] = 1633087848,
                ["wasAltered"] = true,
                ["newestTime"] = 1633087848,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2600,
                        ["guild"] = 1,
                        ["buyer"] = 165,
                        ["wasKiosk"] = true,
                        ["seller"] = 237,
                        ["timestamp"] = 1633087848,
                        ["quant"] = 1,
                        ["id"] = "1690875565",
                        ["itemLink"] = 1231,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic light apparel set robes of the hist feet invigorating",
            },
        },
        [119564] = 
        {
            ["1:0:4:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/master_writ_enchanting.dds",
                ["itemDesc"] = "Sealed Enchanting Writ",
                ["oldestTime"] = 1632453015,
                ["wasAltered"] = true,
                ["newestTime"] = 1633311891,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 2345,
                        ["guild"] = 1,
                        ["buyer"] = 25,
                        ["wasKiosk"] = true,
                        ["seller"] = 26,
                        ["timestamp"] = 1633311891,
                        ["quant"] = 1,
                        ["id"] = "1692868411",
                        ["itemLink"] = 17,
                    },
                    [2] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 2,
                        ["buyer"] = 110,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1632453015,
                        ["quant"] = 1,
                        ["id"] = "1685859055",
                        ["itemLink"] = 82,
                    },
                    [3] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 2,
                        ["buyer"] = 110,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1632453016,
                        ["quant"] = 1,
                        ["id"] = "1685859093",
                        ["itemLink"] = 83,
                    },
                    [4] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 2,
                        ["buyer"] = 110,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1632453018,
                        ["quant"] = 1,
                        ["id"] = "1685859131",
                        ["itemLink"] = 84,
                    },
                    [5] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 2,
                        ["buyer"] = 139,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1633205954,
                        ["quant"] = 1,
                        ["id"] = "1691854181",
                        ["itemLink"] = 153,
                    },
                    [6] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 2,
                        ["buyer"] = 139,
                        ["wasKiosk"] = false,
                        ["seller"] = 112,
                        ["timestamp"] = 1633205956,
                        ["quant"] = 1,
                        ["id"] = "1691854215",
                        ["itemLink"] = 154,
                    },
                    [7] = 
                    {
                        ["price"] = 3400,
                        ["guild"] = 1,
                        ["buyer"] = 488,
                        ["wasKiosk"] = true,
                        ["seller"] = 79,
                        ["timestamp"] = 1633017609,
                        ["quant"] = 1,
                        ["id"] = "1690345637",
                        ["itemLink"] = 554,
                    },
                    [8] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633032674,
                        ["quant"] = 1,
                        ["id"] = "1690462273",
                        ["itemLink"] = 742,
                    },
                    [9] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1633032679,
                        ["quant"] = 1,
                        ["id"] = "1690462283",
                        ["itemLink"] = 744,
                    },
                    [10] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 824,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633110939,
                        ["quant"] = 1,
                        ["id"] = "1691043067",
                        ["itemLink"] = 1321,
                    },
                    [11] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 824,
                        ["wasKiosk"] = true,
                        ["seller"] = 971,
                        ["timestamp"] = 1633110941,
                        ["quant"] = 1,
                        ["id"] = "1691043097",
                        ["itemLink"] = 1322,
                    },
                    [12] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 824,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633110942,
                        ["quant"] = 1,
                        ["id"] = "1691043115",
                        ["itemLink"] = 1323,
                    },
                    [13] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 824,
                        ["wasKiosk"] = true,
                        ["seller"] = 466,
                        ["timestamp"] = 1633110943,
                        ["quant"] = 1,
                        ["id"] = "1691043135",
                        ["itemLink"] = 1324,
                    },
                    [14] = 
                    {
                        ["price"] = 3000,
                        ["guild"] = 1,
                        ["buyer"] = 1323,
                        ["wasKiosk"] = true,
                        ["seller"] = 957,
                        ["timestamp"] = 1633166248,
                        ["quant"] = 1,
                        ["id"] = "1691502051",
                        ["itemLink"] = 1860,
                    },
                    [15] = 
                    {
                        ["price"] = 3500,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 150,
                        ["timestamp"] = 1633198615,
                        ["quant"] = 1,
                        ["id"] = "1691775513",
                        ["itemLink"] = 2165,
                    },
                    [16] = 
                    {
                        ["price"] = 4500,
                        ["guild"] = 1,
                        ["buyer"] = 57,
                        ["wasKiosk"] = true,
                        ["seller"] = 320,
                        ["timestamp"] = 1633198638,
                        ["quant"] = 1,
                        ["id"] = "1691775727",
                        ["itemLink"] = 2168,
                    },
                    [17] = 
                    {
                        ["price"] = 4000,
                        ["guild"] = 1,
                        ["buyer"] = 1536,
                        ["wasKiosk"] = true,
                        ["seller"] = 1417,
                        ["timestamp"] = 1633207674,
                        ["quant"] = 1,
                        ["id"] = "1691877581",
                        ["itemLink"] = 2258,
                    },
                    [18] = 
                    {
                        ["price"] = 4990,
                        ["guild"] = 1,
                        ["buyer"] = 824,
                        ["wasKiosk"] = true,
                        ["seller"] = 333,
                        ["timestamp"] = 1632819253,
                        ["quant"] = 1,
                        ["id"] = "1688939969",
                        ["itemLink"] = 3008,
                    },
                    [19] = 
                    {
                        ["price"] = 5992,
                        ["guild"] = 1,
                        ["buyer"] = 824,
                        ["wasKiosk"] = true,
                        ["seller"] = 600,
                        ["timestamp"] = 1632819254,
                        ["quant"] = 1,
                        ["id"] = "1688939971",
                        ["itemLink"] = 83,
                    },
                    [20] = 
                    {
                        ["price"] = 2000,
                        ["guild"] = 1,
                        ["buyer"] = 1868,
                        ["wasKiosk"] = true,
                        ["seller"] = 54,
                        ["timestamp"] = 1632828469,
                        ["quant"] = 1,
                        ["id"] = "1688988053",
                        ["itemLink"] = 3062,
                    },
                    [21] = 
                    {
                        ["price"] = 1580,
                        ["guild"] = 1,
                        ["buyer"] = 25,
                        ["wasKiosk"] = true,
                        ["seller"] = 739,
                        ["timestamp"] = 1632860369,
                        ["quant"] = 1,
                        ["id"] = "1689233329",
                        ["itemLink"] = 1321,
                    },
                    [22] = 
                    {
                        ["price"] = 834,
                        ["guild"] = 1,
                        ["buyer"] = 2454,
                        ["wasKiosk"] = true,
                        ["seller"] = 388,
                        ["timestamp"] = 1632906422,
                        ["quant"] = 1,
                        ["id"] = "1689588797",
                        ["itemLink"] = 744,
                    },
                    [23] = 
                    {
                        ["price"] = 5500,
                        ["guild"] = 1,
                        ["buyer"] = 824,
                        ["wasKiosk"] = true,
                        ["seller"] = 441,
                        ["timestamp"] = 1632955921,
                        ["quant"] = 1,
                        ["id"] = "1689926877",
                        ["itemLink"] = 3865,
                    },
                    [24] = 
                    {
                        ["price"] = 6400,
                        ["guild"] = 1,
                        ["buyer"] = 824,
                        ["wasKiosk"] = true,
                        ["seller"] = 105,
                        ["timestamp"] = 1632955923,
                        ["quant"] = 1,
                        ["id"] = "1689926887",
                        ["itemLink"] = 3866,
                    },
                },
                ["totalCount"] = 24,
                ["itemAdderText"] = "rr01 purple epic consumable master writ",
            },
        },
        [45548] = 
        {
            ["1:0:3:0:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/quest_scroll_001.dds",
                ["itemDesc"] = "Recipe: Anequina Stout",
                ["oldestTime"] = 1632975964,
                ["wasAltered"] = true,
                ["newestTime"] = 1632975964,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 999,
                        ["guild"] = 1,
                        ["buyer"] = 217,
                        ["wasKiosk"] = true,
                        ["seller"] = 149,
                        ["timestamp"] = 1632975964,
                        ["quant"] = 1,
                        ["id"] = "1690102367",
                        ["itemLink"] = 230,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "rr01 blue superior consumable recipe",
            },
        },
        [79359] = 
        {
            ["50:16:4:5:0"] = 
            {
                ["itemIcon"] = "/esoui/art/icons/gear_reach_1hsword_c.dds",
                ["itemDesc"] = "Briarheart Sword",
                ["oldestTime"] = 1632990221,
                ["wasAltered"] = true,
                ["newestTime"] = 1632990221,
                ["sales"] = 
                {
                    [1] = 
                    {
                        ["price"] = 9999,
                        ["guild"] = 1,
                        ["buyer"] = 347,
                        ["wasKiosk"] = true,
                        ["seller"] = 163,
                        ["timestamp"] = 1632990221,
                        ["quant"] = 1,
                        ["id"] = "1690188481",
                        ["itemLink"] = 349,
                    },
                },
                ["totalCount"] = 1,
                ["itemAdderText"] = "cp160 purple epic weapon set briarheart sword one-handed defending",
            },
        },
    },
}
